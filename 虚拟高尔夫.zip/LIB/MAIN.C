#include <dos.h>
#include <stdio.h>
#include <string.h>
#include "basics.h"
#include "midi.h"
#include "digi.h"

/****************************************************************************/

char	*backscr;
char	game_palette[256][3];
char	exitstr[1024];

char	last_fname[128];
long	last_flen;
int	last_error;
int	last_fmode;
int	last_handle = 0;
int	last_memsize = 0;

short	scrxsize = 320;			//either 288*224 or 320*200
short	scrysize = 200;

word	mouse_buttons = 0;

char	*block_addr = NULL;
char	*map_addr = NULL;

char	curdrive = 'C';

CFIG	config = {0,11,11,0,1,2,0,0,0,0,0x388,0x220,1,5,5,0x220,1,5,0};

/****************************************************************************/

void
main(void)
{
	int n;

	if (n = setup())
		getout(n);

	while (get_key());

	for(;;keydata->last_key = get_key())
		{
		ifkey(K_ESC)
			break;


		copysource = backscr; 	// copy screen over
		copydest = (char *)MCGA_RAM;
		dump_screen();

		copydest = backscr;		// clear back screen
		clr_screen();

		read_mouse();
		read_joy();

		print(0, 0, "Shell up and running.");
		print(0, 8, "Mouse x = %d, y = %d",mx ,my);
		print(0, 16, "Joy x = %d, y = %d, fire = %d",joy1_x ,joy1_y, joy1_fire);

		}

	getout(E_OK);
}

/****************************************************************************/

void
clear_keyb(void)
{
	while (get_key());
	return;
}

/****************************************************************************/

