Bloodwych

Presented by Home of the Underdogs, http://www.the-underdogs.org/

Big thanks to Unofficial Bloodwych Site at http://classicgaming.com/bloodwych/ for bonus files :)

Zip contents:

bwych-game.zip		- 	The game, of course!

bwych-fix.zip		-	A very useful patch that fixes the Welcome back" bug (There 
				shouldn't be a wall at the other end! :) To run this just 
				go to DOS command prompt and run the program followed by the 
				name of faulty savegame file you want to fix

bwych-chareditor.zip	- 	BLEdit, character editor for Windows. This version also supports
				Atari ST Save games (You will need VB40032.dll to run it) 

VB40032.zip		-	Contains Visual Basic 4 DLL file - unzip this to your
				C:\WINDOWS\SYSTEM directory or wherever you install BLEdit

bwych-mapeditor.zip	- 	Map editor for the game created by Jorg Nieberg

bwych-mapviewer.zip	-	Map Viewer for the Windows - allows you to view game maps and 
				export the images to a file

Enjoy!
-Underdogs

September 10, 2003

