The Solution to The Koshan Conspiracy

The Game.

The Koshan Conspiracy, also known as B.A.T 2, is a computer game by UBI Soft and the French company Computer's Dream. It has a very cool, comic-book-like feel to it. The world is large (by 1993 computer game standards) and you can wander for hours. However, completing the game is another story. While you may occasionally encounter a brown question mark icon indicating you are missing some item needed to proceed, there is never any indication as to what that item might be. This page serves as the basic plot line to The Koshan Conspiracy, as an aid to all those struggling gamers who just want to finish the game. (I've owned the game 10 years now and have only now finished it!)

The Setting.

You are a secret agent working for the Bureau of Astral Troubleshooters. You are impersonating Shedish citizen Jehan Menasis, whom BAT had imprisoned on fake drug possession charges. (See the Scenario booklet, if you have it.) You were sent to the planet Shedishan in order to aid in the mission of Helaine Vertex, another BAT agent. Vertex is masquerading as Sylvia Hadford (actually deceased), daughter of an important explorer Ernest Hadford. Her objective is to break the monopoly of the Koshan Corporation on the mining and production of Echiatone 21 (whatever that is). BAT has determined that the best way to do this is by gaining a controlling interest in the Shedishan asteroid Bedhin 6, the prime source of Echiatone 21. Deeds to the Bedhin 6 asteroid were granted to a number of different people by an old Shedishan king. Koshan currently claims possession of 200 of these deeds. "Sylvia Hadford" currently has 30 deeds, but has claimed to Shedishan courts that she actually has 280. Currently, Koshan's mining of Bedhin 6 has been shut down, pending a full investigation. Your mission is to procure the extra deeds BAT needs to control Bedhin 6. Since you work for a top-secret military/spy agency, you can use whatever means necessary.

General Tips

Character generation is a little confusing. Although you can slide the attribute scales, you can't actually change any of the pre-set agents. What you can do is specify what you think the perfect agent for the job is, and then hit search to find the closest match. Otherwise cycle through the pre-set agents to find the best one. You can then shore up his deficiencies with the 8 weeks of training on the next screen.
Program your B.O.B. computer to interpret Shedish for you so you can speak to everyone in the game. Also program it to tell you when your agent is hungry, thirsty, or tired to avoid a drop in stats due to fatigue.
Use the magnifying glass in the inventory to search for stuff lying around. Check every screen if you can. Sometimes you have to click 5 or 6 times before you find anything.
Steal what you can. Remember, you work for a secret bureau that engages in assassinations, embezzlement, and fraud. What's a little pickpocketing and shoplifting along the way? That said, don't push people too far. Stop when they get irritated (white spikey speech bubbles), and definitely stop when they get furious (red spikey speech bubbles). If they call the cataphractaires (cops), it will get in the way of your mission. If you actually kill a cataphractaire, you're as good as dead, since the rest will just hunt you down. Sell back stolen coins for extra money. Putting everything into a disposable bag while in buy mode and then stealing the bag is quite effective.
Buy or steal food whenever you find it. Your agent eats constantly.
Play the games in the arcade to get extra money. You can get about 20,000 pretty easily. (10,000 on one game of Chidam, and 5,000 each from Quattro and Tubular, one 500 game at a time.) You only need about 30,000 to comfortably play the game.
To recruit people, they must first really like you. This is shown by speech bubbles bordered with flowers. You might run into this if you have a very charismatic agent. Otherwise, you can buy some friendship by giving someone an aureus (worth 40,000 credits). This is a good use for one, since no one will buy it from you anyway; they'll just tell you its worthless since they don't have the cash to pay for it. It doesn't seem necessary to recruit anyone to beat the game.
If people talk you to about an object, you need it to complete the game.
The Plot.

(This is not a complete walk-through, but a general storyline. It covers the major stumbling blocks, but you'll have to work out the smaller details for yourself.)

Go find Sylvia in one of the hotels. She'll get you started by telling you to find out more at the AIC. There, you learn who is known to have deeds:
Koshan Corporation (Koshan Tower): 200
Massiglia (Carmenta Tower): 50
Senator Jugh'ahih (Vermentus Tower) : 10
Citizen Bogli Izae (Welco, Industrial Sector): 25
Last transaction: 100 royal treasury deeds to Koshan.
There's also a number of unregistered deeds out there too.

(Note: The scenario booklet says the original king issued only 400 deeds, but AIC lists 500. I now believe that the 100 royal treasury deeds are new deeds, issued to Koshan Corporation by the current king.)

Now start making the rounds. Bogli Izae has been murdered and his deeds stolen. But if you hang around outside for awhile, the two thugs who did it (a small Shedish guy and a blond human guy with red glasses) will inexplicably attack you. (Maybe they think you're on to them?) After you kill them, search the area for the 25 deeds.

Senator Jugh'ahih doesn't have his anymore. (Who knows why. I think I was once found 10 deeds somewhere, but I could just be remembering Bogli Izae's 25 deeds.)

You can't buy Massaglia's deeds because you don't have the money. But record your conversation with him using the voice retrieval system! (Just have the VRS on you; the blank tape will become a recorded tape when you've done it.) Then Sylvia will tell you to rob the bank to get the deeds. Head to the North sector to buy a memory chip from the thugs in the back of the Peristyle bar. Use this to make contact lenses to get by the laser security system. Pick up an axial sucker system and some ditroxyl. Take the cleaning transport out to Carmenta tower, burn your way through the wall, and break into the bank. Search for the deeds. (You can also get some credit cards and papers, but they don't seem to be much use.)

Now try to find someone with a newspaper and learn about the royal page Banafoosh who was murdered (although "not for political reasons"; yeah, right!). Head to his place in the Ashan district with a rope and climb up his balcony. In his secret room, you will find his journal and 80 deeds. His journal will mention that the King is getting a little loopy, and that maybe the deeds of an old friend of his are still on Bedhin 6. Talk to Sylvia and she'll agree that you had better get out to Bedhin 6.

They're not just going to let just anyone out there--you'll have to go as praetor. Get a false praetor's card and some clothes, then go to Janus Tower. Find someone on adjournment so he won't notice the switch for a while, and steal his card, replacing it with the false one. Don't take anything else from the sauna (or presumably they notice the theft and report it; I don't know). Take the spaceship out to Bedhin 6, get past the guard with your nifty disguise, and hop in the driller. Up in the top right corner of the map, you'll find a tunnel with a cave-in of sorts. (I found that I died inexplicably if I got near any of the other red exits. Echiatone 21 poisoning, maybe? Sometimes you have to provide your own meaning to this artistic game.) There your agent will recover the 100 lost deeds.

You now have 25 + 50 + 80 + 100 = 255 deeds. That's more than Koshan, so you have a controlling interest in Bedhin 6 and BAT can put some major pressure on them. But, when you fly back to Shedishan, you are arrested for the murder of Sylvia Hadford. Ah, the plot thickens!

You are thrown into prison and become a technoglad. Hopefully you've been keeping your agent well-fed, because now you'll have nothing in your inventory. You get fed twice a day, just enough to keep you alive. Once a day you can enter the arena to fight. Eventually, during a meal, one inmate will attack another. Grab the food from your plate and then get involved. You'll be thrown in the holding cell for 24 hours, but while you're there you can swap your food for the aggressor's electronic pain stick. Once you have the pain stick, you have to win 3 battles in the arena and follow the dictates of the crowd. Then you'll be taken before the king. Despite tradition, he will refuse to pardon you. You panic and attack him with the pain stick. The resulting explosion reveals that the King was actually a robot of sorts, which explains his recent eccentricities. You get knocked out by a guard.

When you awake, a fast-scrolling explanation of what's going on (complete with many typos and misspellings) will bring you back up to speed. Koshan had tried to control the King by replacing him. (Remember how they got their controlling interest by a gift of 100 deeds from the king?) You're now a Shedishan hero for unmasking the plot and have the right to ascend to the throne. However, Koshan still survived by making their second-in-command take all the blame. To seal Koshan's fate, BAT plans to fake your assassination, as follows: You will abdicate the throne to another BAT agent (how convenient for BAT to pick up direct control of a planet during this mission, eh?). However, as you do so, you will be attacked by an assassin who thinks he has been hired by Koshan. An investigation will reveal a murder contract in Koshan's safe, and, driven by the public grief over your death, they will be convicted. However, before this can all take place, you have to get the murder contract into Koshan and then get to your coronation/abdication to get "murdered."

You get your credit card back, but none of your former inventory. Pick up some more ditroxyl and head out to Koshan Tower. Turn off the security camera and crack the code on the door circuit board... if you can (see next section). You plant the fake contract. BAT's plan goes flawlessly for once. You fake your own death, and head home... mission accomplished!

The circuit board puzzle

This is the last puzzle in the game, and, sadly, it is the biggest disappointment in the game. It looks like this:

Screen shot of Koshan Tower security panel.
The four lights on the top change randomly, which in turn changes the four lights on the right in predicable ways based on the circuit gates. You can click on any of the 16 blue lights on the left. Most clicks will immediately kill you. A few clicks will change the light setup. And a single magic click will win you the game.

I have never figured out the logic behind this; if you do, please let me know. Even when the top four lights show the same combination as the last time you tried it, clicking the same blue light can produce different results. In my case, I saved the game with the top four lights showing OBBB (as shown in the picture). If, when I reloaded my game, the next change was to BBOB, clicking the 11th blue light from the top would win the game. However, if I waited until BBOB came up again, the 11th blue light would then not win me the game, but usually kill me instead. If the next change was not OBBB to BBOB, clicking the 11th blue light was still usually a safe bet in that it produced a change in the light setup rather than death. Possibly, the whole thing is just random, which would be a very disappointing last puzzle indeed.

In any case, my advice is to save your game and just try each button in turn on the next lighting change, and then reload if it didn't work. Again, let me know if you find any logic behind this one.

I hope this document has been of some help. Good luck!