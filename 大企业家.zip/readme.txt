Controls:
* For increasing bid in market F2 ,decrease bid with F1 (these are for player one only ) other players must have some other ctrls..
*Save game using numbers that u get on clicking the portrait of "flounder" .Those numbers are actually game slots
*You can select end product in the begining b4 the actual game starts.
*PAUSE: By clicking on clock
* Esc :To end turn in main screen
If you are in R&D screen, ESC goes back to main screen (board room) where meetings take place
*Shortcuts :Pressing initial letter in board room for eg : If you press R while you are in board room, you go to R&D room, pressing P to jump to Production screen
Hope it helps