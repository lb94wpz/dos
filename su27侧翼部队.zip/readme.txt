SU-27 FLANKER V1.1 READ ME FILE  05/02/96 CCN
(c) 1996 Strategic Simulations, Inc.  A Mindscape Company.


This file contains important information regarding this release of Su-27.

-------

Important information for MS-DOS users:

The Su-27 manual contains screen shots of the Windows 95 version. While the screens are 
presented in a different style, the functionality is the same.

The ON-LINE manual is only available to users with Microsoft Windows 3.1 +. You will need to 
access this while in Windows and not from within DOS Su-27 Flanker.

-------

Errata for the Keyboard and Joypad Reference Card

Mechanics

Ctrl+E  to eject                    NOT Ctrl-A

E       to toggle active jamming    NOT A

Thrustmaster FCS, FLCS and CH FlightStick Pro

The "Hat" switches will only function if you also have a corresponding throttle control system
for your particular joystick.  The hat functions are digital and must be configured using the
throttle configuration files included with your Thrustmaster or CH product.

---------


Additional functionality information

GAI missions contain one waypoint; all other mission types require a minimum 
of two waypoints to function.

To designate a target for your wingman, use BVR mode to highlight a 
potential target and press '[' to give the order to your wingman to attack 
the selected target.

The imperial / metric conversion function is only applicable inside the 
mission editor.

Manual references to 'GREY_' keys refer to the Numeric Keypad.

Manual references to 'General mission' refers to the Military ranking.  
Using these files allow you to command all Russian units in the region.  
You are, in effect, the General Officer in command.  

When using the General missions you will be required to save the mission 
prior to running the mission in the simulation.  Since all mission files 
are Read Only, a Save As dialog box will appear.  Save the file with a name 
of your choice.  Each time you use a General mission you can save your 
Order of Battle and replay a particular mission.

The briefing text contained within a TRK file cannot be edited.  TRK files
are missions that have been previously flown and recorded.  To view the 
recording after loading the TRK mission, you must select PLAY from the 
FLIGHT pull-down menu.  If you use the Start button on the tool bar or 
select START from the FLIGHT pull-down menu, you will be placed in the 
cockpit and able to fly that particular mission without viewing the 
recording.  While running a recorded mission you can take over the controls 
at any time by hitting ESC.

When attempting to open a new mission, please ensure that you close the 
current mission briefing window first. If you do not, the brief text will 
not be updated with the relevant information for the new mission.

-------

Helpful hints

When modifying the mission start time, note that sunrise in the Crimea is 
0500 and sunset 2100.

To increase performance, turn ground detail off when flying night missions.

If you change your screen resolution after running Su-27 for the first time, 
you may experience difficulties using dialogue boxes within the mission 
editor. To rectify this problem, delete the file 'SU27.INI' and start the 
program again in the new screen resolution.


---------


Su-27 Flanker V1.1  Changes & Additions 
----------------------------------------

Please see the below information regarding additions to the software since version 1.0:

Omissions

The 'Show Grid' function has not been incorporated into the software due to technical 
limitations. 

-------

Various additional features have been added and problems encountered have been resolved 
since the original release of Su-27 V1.0; these have been listed below:

--------
Fixes

Flight Model

1. Mirrors have now been incorporated.

2. Clouds have now been incorporated.

3. Head to Head play has been implemented over IPX; co-operative and non co-operative. 
H2H over network can also be achieved using TCP/IP for Windows 95.

4. You cannot be hit by AAMs or SAMs without prior warning of your aircraft being 
painted in formation.

5. ECM light fixed.

6. Neutral trim light fixed.

7. The CCIP pipper no longer jumps when dive bombing.

8. No more keyboard inactivity after selecting CTRL+Q "NO" has been corrected.

9. Requester boxes now display in the correct resolution.

10. Missiles do not pass through certain areas of target models anymore.

11. Missiles, rockets and shells now explode correctly; nearer target.

12. The Grisha frigate will now engage targets.

13. BetAB-500 does not veer off and miss runways anymore on the final leg.

14. S_LEAD_4 is now classified as Sq. Leader mission rather than Pilot.

15. The spin ball now functions correctly.

16. Ctrl F6 'view last launched weapon' has been enabled.


Mission Editor

1. Colour preferences has been implemented. WINDOWS 95 ONLY

2. Preview of aircraft, ships, SAMs and ground objects has been implemented.

3. Network play option has now been added to the Flight menu.

4. Selecting OK will now save changes to all Preference pages. WINDOWS 95 ONLY

5. Rear-view mirror option has now been added.

6. F1 key now invokes the on-line manual. WINDOWS 95 ONLY

7. Detail levels are now in the correct order.

8. Dialogue boxes will not 'disappear' off screen anymore.

9. Ground attack and ground attack / CAS payloads are corrected.

10. Threat areas are now implemented.

----------

Enhancements

Flight Model

1. The Tilde key can cycle through padlock targets in visible range in CAC, Helmet, 
F10 and LMA modes.

2. Radar detection ranges now depend on the target's aspect angle.

3. GAI aircraft can now spot targets within a 10 km range. To let them see beyond 10 km, 
place an EWR station nearby.

4. Deployment of unguided rockets in mountainous areas is more effective.

5. AI aircraft use their guns more effectively.

6. Drogue chutes are now replaced when refuelling.

7. CRTL+W reloads your weapons when you are on the runway.

8. The range of the R-77 has been increased slightly.

9. The recharge rate of the IGLA has been increased to 2 minutes.

10. Spin and stall modelling has been improved.

11. Missiles are now visible at 8-10 km, aircraft at 10-14 km and ships and SAM's are now 
visible earlier.

12. External view rotation can be increased by using the CTRL key.

13. Computer aircraft now deploy guided bombs.

14. Bombs can now be hit by missiles; for example IGLAs.

15. The sun graphic has been improved.


Mission Editor

1. Fuel consumption estimates have been added to the summary dialogue box.

2. External views can now be disabled.

3. The mission editor can now run in a higher resolution than 256 colours. WINDOWS 95 ONLY.

4. Auto resolution mode switch to 640 x 480 has been incorporated. WINDOWS 95 ONLY. 
Please note: This only applies when in 256 colour mode.

5. Additional missions have been included.

------------

New Features

Flight Model

1. The pilot's field of vision has been increased to 240 degrees ( 4 to 8 o'clock ).

2. You can now padlock ground targets in A2G mode.

3. Dog fight view (F9) has been added.

4. Right shift with the function keys (F2 to F9) will cycle through friendly objects and 
left shift will cycle through enemy objects. CTRL and either shift key will cycle through 
objects in reverse.

5. New aircraft added - the MiG-31 with two new missiles; R-33e and R-40TD.

6. An instant cockpit view (0) has been implemented.

7. Wingmen messages have now been added.


Network Head to Head play

Su-27 Flanker 1.1 allows two players to link two computers across a network and fly together, 
either cooperatively or competitively.

If both players are set to different nationalities, then each player can lock onto each other 
with missiles. If both players are set to the same nationality, then you will not be able to 
fire on each other with missiles, although you are still free to use guns. 

There are a number of network missions already included with the CD. Missions beginning with 
the letters NC are cooperative missions, while those beginning with NO are competitive. You can 
also create your own head to head missions using the mission editor. To do this, an aircraft�s 
leader can now be set to �remote�. The aircraft set to �me� will be piloted by the player with 
the mission loaded, while the other player will pilot the �remote� aircraft.

To start a Head to Head mission, do the following:

1.  Make sure both computers are connected through a network running the IPX protocol 
(or additionally TCP/IP for Windows 95).
2.  Both players select �Network Play� from the flight menu.
3.  The player with the mission to be flown selects �master�, the other player selects �slave�.
4.  Both players select the same IPX channel number (from 0 to 9).
5.  If TCP/IP is being used (Windows 95 only), both players should select �TCP/IP for windows� 
and the player set to �slave� should enter the TCP/IP address of the other machine in the text box.
6.  Both players click RUN to enter the simulation.

If the player connected as master exits the simulation and returns to the mission editor, 
the other player is informed and is automatically returned to the mission editor. 
If the player connected as slave leaves the mission, the other player will be informed 
but will be able to carry on with the mission.

Please note that during a head to head mission, it is not possible to pause the simulation 
or accelerate time.



Modem play using Windows 95 Plus Dial Up Server 

***IMPORTANT NOTE***  The ability to play Su-27 over the modem using the Windows 95 Dial Up 
Server feature found in the Microsoft Plus Pack is a feature that was discovered while Su-27 
V1.1 was in testing.  While many of our testers have reported success in using the modem with 
the Dial Up Server to play Su-27, there are still performance problems using this configuration.  
We have included instructions below for those of you that wish to attempt modem play.  Please 
understand that since modem play is not a planned design feature for Su-27 Flanker,  we at SSI 
can not provide technical support in this area.    

Configuring Dial-up Connections

 Setting Up as the Host Machine

 In order to install the Dial-up Server software, you must have the Plus
 Pack. If you do not install the Dial-Up Server software, you will still be
 able to play via dialup IPX but you must be the caller and your oponent
 must have the dial up server software running.

 Dial Up Server from the Plus Pack

  1. Install the Plus Pack
  2. Make sure you checked the dial up adapter option on the plus pack when
     you installed it

 Configuring the Server

  1. After installation, goto My Computer
  2. Click on Dial Up Networking
  3. Click on "Connections" on the menu bar
  4. You should now see the following list of items on the Connections pull
     down menu
        o connections
        o make new connections
        o settings
        o dial up server
  5. Click Dial up server
  6. Click the "allow caller access" button
  7. You can leave the "server type" to default and leave all buttons as is
  8. You can change password or leave it blank
  9. To add a first time password..just enter the new password and
     re-confirm it..DONT enter an OLD password..leave that line blank.
     Seems like most everyone is using "flanker' for a password :-)
 10. If you decide to not use a password...just let everyone know who wants
     to connect to you that they wont need a password

 Setting Up IPX/SPX Compatible Protocol

  1. Now you must bind IPX to your dial up adapter
  2. From control panel click "network"
  3. Click Add
  4. Click Protocol
  5. Click Add
  6. Click Microsoft on the left list
  7. Select IPX/SPX Compatible protocol
  8. Click OK and Reboot
  9. Thats that!
 10. To receive the incoming phone call, leave the Dial Up Server window
     open. When the phone rings, the "monitoring" field will show the
     status
 11. Afer the connection is made, run Flanker. Select a H2H mission and
     click Network play. One must select Master and the other Slave. Select
     the agreed upon IPX channel number and then click RUN

 Setting Up as the Client Machine

 If you do not have the Windows 95 CD Rom of the Plus Pack, you will not be
 able to install the Dial Up Server software. To play Flanker via direct
 modem, you must setup a new dial up connection and use it to call someone
 who is running the Dial Up Server. You must also install the IPX/SPX
 protocol. The following steps will guide you through the entire process.

 Creating a New Dial Up Connection

  1. Click My Computer
  2. Click "Dial Up Networking"
  3. Click "Make New Connection"
  4. Enter a name for the new connection (i.e. Flanker Dial Up)
  5. Click "Next"
  6. Enter the phone number of the person you are going to call
  7. Click "Next"
  8. Click "Finish"
  9. Drag a shortcut to your new connection onto your desktop

 Install the IPX/SPX Compatible Protocol

  1. From control panel click "network"
  2. Click Add
  3. Click Protocol
  4. Click Add
  5. Click Microsoft on the left list
  6. Select IPX/SPX Compatible protocol
  7. Click OK and Reboot

 You are now ready to dial up to your oponents computer. Simply double click
 on the new connection you made. (NOTE: Instead of making multiple
 connections for each person you end up calling, you can simply change the
 phone number at this stage when the Dial Up Networking window pops up) Once
 connected, run Flanker and select either Master or Slave and the correct
 channel number (whichever you and your oponent decided on in advance)

---------

Web Pages

Further information on Su-27 can be found on the following World Wide Web pages:

http://www.nwlink.com/~mikej/su27.html

http://www.ssionline.com

http://www.mindscapeuk.com