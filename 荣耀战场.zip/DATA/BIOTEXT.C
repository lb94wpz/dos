;Name
Napoleon Bonaparte
;Erfahrung 
;5
;
Titel
Kaiser von Frankreich
;F�hrungsqualit�ten 
;4
;
Daten
1769-1821
;Pers�nlichkeit
;5
;
;Lebenslauf
Die bedeutendste milit�rische Karriere aller Zeiten begann, als Napoleon nach Absolvieren 
der 
Milit�rschule in den Dienst der Artillerie gestellt wurde. Das intensive Studium milit�rischer 
Strategien zahlte sich bei der Zur�ckeroberung Toulons aus, und dieses "Pulverschnuppern" 
brachte ihm die Gunst von Barras ein, dem Leiter des Direktoriums, welcher Napoleon zum 
Kommandeur der Armee in Italien und �gypten ernannte. Sein ungeheurer Erfolg in der 
Kriegf�hrung bildete das Sprungbrett f�r den Staatsstreich im Jahre 1799 und seine 
�bernahme 
des kaiserlichen Thrones 1804. Danach feuerte seine unanfechtbare Macht �ber Frankreich 
seine milit�rischen Eroberungen und sein Streben nach einem europ�ischen Reich weiter an. 
Seine milit�rischen F�higkeiten basierten auf der tiefgreifenden Kenntnis von Strategie, 
mathematischer Genauigkeit bei der Truppenbewegung und seinem Gesp�r f�r die 
Schw�chen 
des Feindes, sowie deren Vergeltung. Napoleons auffallendste Eigenschaft war seine 
Energie. 
Seine st�mmige Figur eilte gesch�ftig zwischen den einzelnen Punkten der Schlacht hin und 
her, 
und das Chaos auf dem Schlachtfeld nahm unter seinem durchdringenden Blick eine 
sinnvolle 
Form an. Seine F�hrungsqualit�ten, durch die von patriotischen Franzosen bewiesene 
Ergebenheit f�r den "petit corporal" noch angespornt, wurden nur dadurch getr�bt, da� er 
untergebene Gener�le nicht mit der Unabh�ngigkeit betraute, die jene forderten. Seine 
charismatische Pers�nlichkeit, die in der pers�nlichen Beziehung zu zahlreichen seiner 
Truppen 
ihren Ausdruck fand, inspirierte die franz�sische Nation noch 37 Jahre nach Waterloo, als 
sein 
Neffe Louis Napoleon das "Second Empire" gr�ndete.
..................................................................
;Name
Michel Ney
;Erfahrung
;3;
;
Titel
F�rst von der Moskwa
Franz�sischer Marschall
;F�hrungsqualit�ten
;3
;
Daten
1769-1815
;Pers�nlichkeit
;5
;
;Lebenslauf
Ney meldete sich im Alter von 18 Jahren zum Dienst in der franz�sischen Armee und stieg 
durch 
Wahl w�hrend der Revolutionskriege rasch durch die verschiedenen R�nge auf. Nachdem er 
bei 
der Belagerung von Maastricht eine schwere Verletzung in der linken Schulter erlitten hatte, 
wurde er 1798 zum Generalmajor ernannt. 1804 erhob ihn Napoleon zu einem der ersten 
Marsch�lle des Reiches. Ney hatte den Oberbefehl �ber das VI. Korps in Jena, Eylau und 
Friedland, verlor seine Stellung jedoch infolge von Gehorsamsverweigerung. Er entwickelte 
einen aktiven und selbstbewu�ten F�hrungsstil, der jedoch vielleicht ein wenig zu eigenwillig 
war: Napoleon verfluchte ihn f�r seinen verfr�hten Angriff bei Jena und nannte ihn den 
"Kollegen, der am wenigsten zur Zusammenarbeit bereit ist". Ney k�mpfte beherzt in der 
Schlacht bei Borodino und befehligte die Nachhut w�hrend des katastrophalen R�ckzugs aus 
Moskau 1812. Im Feldzug des Jahres 1813 f�hrte Ney den linken Fl�gel bei Bautzen an und 
wurde bei Leipzig erneut verwundet. Nachdem die Bourbonen den Thron wieder bestiegen 
hatten, �bernahm Ney das Kommando �ber die Kavallerie von Ludwig XVIII. Als Napoleon 
1815 
im S�den Frankreichs landete, schwor Ney, Napoleon "in einem eisernen K�fig" nach Paris 
zur�ckzubringen. Als er seinem fr�heren Kaiser jedoch leibhaftig gegen�berstand, schlug er 
sich 
wieder auf dessen Seite. Im Feldzug bei Waterloo f�hrte Ney den Oberbefehl �ber den linken 
Fl�gel, aber seine taktischen F�higkeiten lie�en ihn bei Quatre Bras im Stich.
Nach der endg�ltigen Niederlage Napoleons wurde Ney von einem Exekutionskommando am 
7. 
Dezember 1815 nach einer Gerichtsverhandlung erschossen, die f�r die furchtbare Rache 
der 
Royalisten bezeichnend war.
..................................................................
;Name
Marquis Emmanuel de Grouchy
;Erfahrung
;3
;
Titel
Franz�sischer Marschall
;F�hrungsqualit�ten
;4
;
Daten
1766-1847
;Pers�nlichkeit
;3
;
;Lebenslauf
Als einziger Adliger, der in Napoleons Armee zum Marschall ernannt wurde, stieg de 
Grouchy in 
der franz�sischen Armee rasch auf. 1793 wurde er jedoch aufgrund seiner adligen Herkunft 
vom 
aktiven Dienst befreit. 1794 wurde er wieder eingestellt und k�mpfte in der Vend�e und der 
Bretagne. Im Jahre 1805 hatte er den Oberbefehl �ber eine Infanteriedivision im II. Korps, 
seine 
gr��ten Erfolge verbuchte er jedoch 1806-07 als Kommandeur der 2. Dragonerdivision bei 
Jena 
und Eylau. 1808 diente Grouchy als Gouverneur von Madrid, wo er einen Aufstand 
verhinderte. 
Im Jahre 1809 versah er wieder den aktiven Dienst in Italien und nahm an der Schlacht bei 
Wagram teil. Im Ru�landfeldzug befehligte er das 3. Reservekorps der Kavallerie. Der 
Feldzug 
forderte jedoch seinen Preis,s und er zog sich nach seiner R�ckkehr nach Frankreich in den 
Ruhestand zur�ck. Dieser war jedoch nicht von langer Dauer, denn schon nach drei Monaten 
nahm er den Dienst wieder auf. W�hrend der Verteidigung Frankreichs im Jahre 1814 
zeichnete 
er sich bei Vauchamps, Troyes und Craonne durch hervorragende Leistungen aus. Unter den 
Bourbonen wurde er zum Generalinspekteur ernannt. De Grouchy unterst�tzte Napoleon bei 
dessen R�ckkehr nach Frankreich im M�rz 1815. Er zerschmetterte einen Aufstand der 
Royalisten in S�dfrankreich und wurde mit der Erhebung ins Amt des 26. Reichsmarschalls 
belohnt. Grouchy befehligte den rechten Fl�gel der Arm�e du Nord bei Ligny und Wavre, 
schaffte es jedoch nicht bis nach Waterloo. Als ihn die Nachricht von Napoleons Niederlage 
erreichte, gelang ihm der geschickte R�ckzug bis nach Paris. Daraufhin floh er nach 
Amerika, 
wo er sich bis 1820 aufhielt und dann wieder nach Frankreich zur�ckkehrte. Im Jahre 1831 
wurde er wieder in den Rang eines Marschalls erhoben.
...........................................................
;Name
Graf Alexandre Drouot
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;4
;
Daten
1773-1847
;Pers�nlichkeit
;3
;
;Lebenslauf
Als meistgefeiertes "Produkt" der �cole Polytechnique bewies Drouot mehr taktische 
Initiative 
als alle anderen franz�sischen Gener�le, ausgenommen Napoleon. Im Jahr 1813 dr�ngte er 
bei 
Lutzen eine ganze Batterie von Artillerie auf recht unsanfte Weise bis in k�rzeste Entfernung 
zu 
den Linien der Verb�ndeten zur�ck. Im darauffolgenden Kugelhagel fiel der Feind zur�ck und 
verlor die Kontrolle �ber das Schlachtfeld. Seine au�erordentlich bewunderte Taktik bestand 
jedoch in der Kombination aus schwerem Artilleriefeuer und einem Angriff der Kavallerie. 
Auf 
diese Weise schnitt er bei Hanau 1814 durch eine weit �berlegene Bayerische Truppe. 
Drouot 
war einer der ersten Gener�le, der sich im M�rz 1815 Napoleon anschlo�, und wurde als 
Dank 
mit der F�hrung der ber�hmten Kaiserlichen Garde betraut, obgleich er als 
Infanteriekommandeur keinerlei Erfahrung vorzuweisen hatte.
..................................................................
;Name
Marquis Jean Baptiste d'Erlon
;Erfahrung
;2
;
Titel
Franz�sischer Marschall
;F�hrungsqualit�ten
;3
;
Daten
1766-1844
;Pers�nlichkeit
;5
;
;Lebenslauf
D'Erlon meldete sich 1782 freiwillig zum Dienst, wurde jedoch nicht bef�rdert, bis er 
w�hrend der 
Revolutionsjahre dem Reims-Bataillon beitrat. Sein republikanischer Geist und seine 
hochgewachsene, gebieterische Gestalt inspirierten seine M�nner, die ihn 1792 zum 
Hauptmann 
und 1795 zum Bataillonschef w�hlten. 
Nach seiner Bef�rderung zum Generalmajor der 2. Infanteriedivision im Jahre 1803, stand er 
bei 
Austerlitz (1805), Jena (1806) und Wagram (1809) an der Front. W�hrend des Krieges auf 
der 
Pyren�enhalbinsel f�hrten eine Reihe von Fehlern und Auseinandersetzungen mit anderen 
Gener�len dazu, da� er sich f�r kurze Zeit in die Verst�rkung zur�ckziehen mu�te. Als 
Napoleon 
1814 gest�rzt war, wurden d'Erlons Verbindungen zu den Royalisten enth�llt. Unter Ludwig 
XVIII. 
erhielt er eine hohe Stellung, schlo� sich aber dennoch im M�rz 1815 wieder Napoleon an. 
Nach 
der Niederlage des Kaisers floh d'Erlon nach Deutschland und kehrte erst wieder nach 
Frankreich zur�ck, als das �ber ihn verh�ngte Todesurteil anl��lich der Thronbesteigung von 
Charles X. aufgehoben worden war.
.................................................................
;Name
Honor� Reille
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1775-1860
;Pers�nlichkeit
;4
;
;Lebenslauf
Aus dem Rang eines freiwilligen Grenadiers stieg Reille 1791 zum Brigadegeneral auf, 
nachdem 
er die britische Seeblockade durchbrochen hatte, um sich Massena anzuschlie�en, der in 
Genua 
belagert wurde. Nach der Schlacht bei Jena (1806) wurde er zum Generalmajor bef�rdert 
und 
nach der Schlacht bei Friedland (1807) zum Grafen ernannt. Sp�ter wurde er nach Spanien 
versetzt, wo er in den Ruf geriet, mit Offizierskollegen Streitigkeiten vom Zaun zu brechen 
und 
Befehle zu verweigern. Dennoch k�mpfte er im Krieg auf der Pyren�enhalbinsel mit 
Auszeichnung und bot Wellington in der Schlacht von Vitoria 1813 heftige Gegenwehr. 
W�hrend 
der ber�hmten "100 Tage" f�hrte er den Oberbefehl �ber das II. Korps. Nach der Niederlage 
des 
Kaisers fiel Reille neben vielen anderen unter die Amnestie von Ludwig XVIII. und wurde 
1819 in 
den Adelsstand erhoben. Im Jahre 1847 empfing er schlie�lich den Kommandostab des 
Marschallsranges.
..................................................................
;Name
Comte Georges Mouton de Lobau
;Erfahrung 
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1770-1838
;Pers�nlichkeit
;2
;
;Lebenslauf
Mouton meldete sich als Freiwilliger zum Dienst in der franz�sischen Armee und wurde 
1792 
zum Leutnant ernannt. Seine ersten Dienstjahre verbrachte er in Italien (1795-1801), wo er 
zweimal verwundet wurde. Als Brigadegeneral (1805 bef�rdert) begleitete er Napoleon nach 
Austerlitz (1805), Jena (1806) und Eylau (1807), bevor er bei Friedland (1807) schwer 
verwundet 
wurde. Bei Landshut f�hrte er das Kommando an, das die brennende Br�cke einnahm, im 
allgemeinen waren seine unabh�ngigen Handlungen jedoch selten, und seine Hauptaufgabe 
war 
die des Beraters Napoleons. Der Kaiser bewunderte Moutons Loyalit�t und Tapferkeit und 
machte ihn 1809 zum Grafen von Lobau. Nachdem er bei Dresden in Gefangenschaft 
geraten 
war, entkam er nach Frankreich, um sich Napoleon anzuschlie�en, wurde aber nach der 
Schlacht bei Waterloo erneut gefangengenommen. Sp�ter wurde er in den Rang eines 
franz�sischen Marschalls erhoben und starb 1838, als sich eine alte Wunde wieder neu 
entz�ndete. 
..................................................................
;Name
Fran�ois Etienne Kellerman
;Erfahrung
;3
;
Titel
Comte de Valmy
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1770-1835
;Pers�nlichkeit
;2
;
;Lebenslauf
Kellerman wurde 1785 von den Husaren aufgenommen und mit der franz�sischen Botschaft 
im 
Jahre 1791 in die USA entsandt. Aufgrund seiner adligen Herkunft wurde er verhaftet und 
gewann erst durch seine in der Italienarmee bewiesene Tapferkeit wieder an Ansehen, 
insbesondere durch einen gefeierten Angriff, der die Schlacht bei Marengo (1800) zu seinen 
Gunsten wendete. Als Anerkennung wurde er zum Generalmajor bef�rdert. 
Kellerman wurde bei Austerlitz verwundet (1805) und versah den gr��ten Teil seines 
Dienstes in 
Spanien. Im Jahre 1813 wurde er jedoch aufgrund seiner angegriffenen Gesundheit in den 
Ruhestand versetzt. Nach der Schlacht bei Leipzig (1813) trat er wieder in die Armee ein, 
um in 
den letzten Schlachten den Befehl �ber die Kavallerie zu f�hren. Nachdem er den Bourbonen 
f�r 
kurze Zeit gedient hatte, schlo� er sich 1815 wieder Napoleon an und tat sich bei Quatre 
Bras im 
Kampf hervor, wo es ihm beinahe gelang, die Kreuzung einzunehmen. Nach der Schlacht bei 
Waterloo zog sich Kellerman aus dem �ffentlichen Leben zur�ck. Im Jahre 1820 erbte er den 
Titel des Herzogtums von Valmy, wo er 1835 starb.
..................................................................
;Name
Comte Edouard Jean Baptiste Milhaud
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1766-1833
;Pers�nlichkeit
;3
;
;Lebenslauf
Milhaud, ein stolzer Revolution�r und Mitglied der Nationalgarde, k�mpfte in der Schlacht bei 
Bassano (1796) und wurde nach seiner Teilnahme an Napoleons Coup im Brumaire 1799 in 
den 
Rang des Brigadegenerals erhoben. Milhaud befehligte die Leichten Kavallerieaufstellungen 
bei 
Austerlitz (1805) und Eylau (1807). Im Jahre 1806 wurde er zum Generalmajor ernannt und 
nach 
Spanien versetzt, wo er bei Talavera (1809) verwundet wurde. Milhaud zog sich mit 
Napoleons 
Fall aus dem Dienst zur�ck, wurde jedoch f�r die Schlachten bei Ligny und Waterloo wieder 
zum 
Kommandeur einer K�rassierdivision berufen. Nachdem er im Jahre 1817 von der Anklage 
des 
K�nigsmordes freigesprochen worden war, blieb er bis zu seinem Tod 1833 in der 
Kavallerie-
Reserve.
.......................................................
;Name
Dominique Vandamme
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1770-1830
;Pers�nlichkeit
;5
;
;Lebenslauf
Vandamme wurde von seinem Vater in die Armee eingeschrieben, nachdem jener eine 
unerfreuliche Verbindung zwischen dem Sechzehnj�hrigen und einer Dame der Gesellschaft 
aufgedeckt hatte. Er wurde unverz�glich zu einem Bataillon auf Martinique gesandt, 
desertierte 
jedoch und kehrte nach Frankreich zur�ck, wo er sich der Brie-Infanterie unter einem 
falschen 
Namen anschlo�. W�hrend der Revolution verschaffte ihm sein Organisationstalent einen 
schnellen Aufstieg. Er geno� es, die Rolle des heldenhaften Soldaten zu spielen, und war in 
der 
Pariser Gesellschaft bald f�r seine eleganten Uniformen bekannt. Vandamme h�ufte jedoch 
einen ungeheuren Schuldenberg an und geriet in den Verdacht, die Kriegsbeute des 
Austerlitz-
Feldzuges (1805) f�r sich behalten zu haben. 
Von Belgien wurde er nach Frankreich abberufen, nahm es jedoch mit Gelassenheit. Nach 
der 
Schlacht bei Waterloo wurde er aus Frankreich ausgewiesen. Von 1816 bis 1819 lebte er in 
den 
Vereinigten Staaten, verbrachte aber seine letzten Jahre im Ruhestand in Nordfrankreich.
..................................................................
;Name
Maurice-Etienne G�rard
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1773-1853
;Pers�nlichkeit
;2
;
;Lebenslauf
Im Alter von 15 Jahren meldete sich G�rard zum Dienst im Husarenregiment, in dem sein 
Vater 
als Hauptmann t�tig war. Bald darauf ging er zu den Grenadieren, wo er 1792 in den Rang 
des 
Leutnants und 1796 zum Hauptmann aufstieg. Napoleon teilte ihn dem Stab Bernadottes zu, 
wo 
er zehn Jahre als Adjutant t�tig war und bei Austerlitz (1805) und Eylau (1807) 
entscheidende 
Kavallerieangriffe durchf�hrte. W�hrend des R�ckzugs aus Ru�land 1812 wurde er in einem 
Hinterhalt verwundet und zog sich nach Schweden zur�ck, wo ihn Bernadotte zum 
Stabsoffizier 
seiner Ehrenlegion bef�rderte. 
G�rard vergab es Bernadotte nie, da� jener Napoleon im Stich gelassen hatte, und machte 
sich 
heimlich nach Frankreich auf, als ihm die Nachricht von der R�ckkehr des Kaisers zu Ohren 
kam. Nachdem er bei Wavre und Ligny gek�mpft hatte, zog er sich in die Politik zur�ck, wo 
er 
w�hrend der 1840er Jahre als Kriegsminister wirkte.
..................................................................
;Name
Claude Pierre Pajol
;Erfahrung 
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1772-1844
;Pers�nlichkeit
;3
;
;Lebenslauf
Pajol wurde von seinem Freiwilligen-Bataillon 1791 zum Oberfeldwebel gew�hlt und im 
darauffolgenden Jahr in den Dienst der Gefechtslinieninfanterie gestellt. Von der Front aus 
f�hrte 
er die Grenadiere w�hrend der Revolutionskriege an und erlitt verschiedene Verwundungen 
am 
Kopf. F�r seine Tapferkeit in Italien wurde ihm der Ehrens�bel verliehen. 1807 wurde er zum 
Brigadegeneral bef�rdert und 1808 zum Baron ernannt. Pajol zeichnete sich bei Eckm�hl 
(1809) 
und Wagram (1809) mit hervorragenden Leistungen aus, erlitt jedoch eine schwere 
Verletzung, 
als er beim Angriff einer Leichten Kavalleriedivision bei Borodino (1812) an der Spitze ritt. 
Bei 
Montereau, das er mit Hilfe eines ausgezeichneten Einkreisungsman�vers einnahm, wurde er 
im 
Jahre 1814 erneut verwundet. Nach der Abdankung des Kaisers 1814 zog sich Pajol in den 
Ruhestand zur�ck, schlo� sich Napoleon jedoch 1815 wieder an. Er k�mpfte bei Ligny und 
Wavre, zog sich erneut zur�ck und nahm an aufr�hrerischen Handlungen gegen die 
Bourbonen 
teil, die schlie�lich in der Revolution von 1830 gipfelten. Zum Zeitpunkt seines Todes im 
Jahre 
1844 befand sich Pajol immer noch im aktiven Milit�rdienst. 
..................................................................
;Name
Graf Exelmans
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1775-1852
;Pers�nlichkeit
;3
;
;Lebenslauf
Exelmans meldete sich w�hrend der Verteidigung Frankreichs (1793) als Freiwilliger und 
k�mpfte als Unterleutnant in Holland (1794-98). In Italien trug er entscheidend zur Einnahme 
Neapels bei (1799) und wurde von Napoleon direkt anschlie�end zum Hauptmann bef�rdert. 
Exelmans schlo� sich den J�gern vor der Schlacht von Austerlitz (1805) an, wurde jedoch 
von 
den Engl�ndern zu Beginn des Krieges auf der Pyren�enhalbinsel gefangengenommen und 
verbrachte nahezu vier Jahre als Kriegsgefangener in Portsmouth. Er floh im Jahre 1811 und 
wurde wieder als F�hrer einer J�gerdivision eingesetzt. W�hrend der erneuten 
Thron�bernahme 
durch die Bourbonen 1814 wurde ein Brief abgefangen, in welchem er Napoleon seiner 
ungebrochenen Unterst�tzung versicherte. Daraufhin war er gezwungen, sich verborgen zu 
halten, bis er 1815 wieder auftauchte, um sich der Arm�e du Nord anzuschlie�en. Exelmans 
tendierte dazu, Anweisungen nur sehr z�gerlich auszuf�hren. So verlor er vor Waterloo, 
entgegen de Grouchys Anweisungen, die Preu�en aus den Augen. Nach der Schlacht bei 
Waterloo ging er ins Exil, wurde jedoch begnadigt und im Jahre 1822 zum Inspekteur der 
Kavallerie ernannt. 
..................................................................
;Name
Jacques-Louis Saint-Maurice
;Erfahrung 
;5
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1749-1828
;Pers�nlichkeit
;2
;
;Lebenslauf
St. Maurice, der vor der Revolution seinen Lebensunterhalt als Gesch�ftsmann verdient 
hatte, 
trat in die Zivilmiliz ein, als die Engl�nder 1793 Toulouse angriffen. Er blieb zeitlebens in der 
Armee, k�mpfte auf Korsika und wurde 1799 zum Hauptmann ernannt.
Seine weiteren Taten ab 1815 sind leider unbekannt, sein Name erscheint erst wieder in den 
Sterbeb�chern des Klosters Bl�r� im Jahre 1828.
..................................................................
;Name
Comte Louis Friant
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1758-1829
;Pers�nlichkeit
;3
;
;Lebenslauf
Friant schlo� sich 1781 der franz�sischen Garde an. W�hrend der Revolutionskriege diente 
er 
im Arsenal und wurde 1795 in den Rang des Brigadegenerals erhoben. In �gypten erwarb er 
sich 
Napoleons besonderen Dank, als er bei Aboumanah (1799) die Stellung hielt, bis 
Verst�rkung 
eintraf. Nach seiner R�ckkehr nach Frankreich wurde er zum Generalinspekteur der Infanterie 
bef�rdert. Zweimal entging er t�dlichen Verletzungen nur um Haaresbreite - bei Eylau (1807) 
und bei der Belagerung von Smolensk (1812). In der Schlacht bei Waterloo wurde er erneut 
verwundet und sp�ter in die Reserveeinheiten aufgenommen, wo er f�r den Rest seiner 
Karriere 
blieb. 
..................................................................
;Name
Charles-Antoine Morand
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1771-1835
;Pers�nlichkeit
;3
;
;Lebenslauf
Morand wurde in eine mit dem Milit�r verbundene Familie hineingeboren und schon im 
zarten 
Alter von 20 Jahren mit dem Oberbefehl �ber ein Freiwilligenbataillon betreut. Im Jahre 
1793 traf 
dieses Bataillon als erstes im Dorf Handschoote ein, wof�r Morand als Belohnung in die 
Rheinarmee versetzt wurde. Dort leistete er seinen Dienst bei der Eroberung von Kreuznach, 
bevor er erst nach Italien und dann nach �gypten gesandt wurde. In Bernadottes III. Korps 
diente 
er als General der 1. Division und wurde beim Anf�hren verschiedener Angriffe bei Austerlitz 
(1805), Auerstedt (1806) und Eylau (1807) verletzt. Nach der Schlacht bei Waterloo 
fl�chtete er 
nach Polen und wurde w�hrend seiner Abwesenheit zum Tode verurteilt. Als er jedoch 1821 
wieder zur�ckkehrte, wurde er von einem Milit�rgericht freigesprochen. Im Jahre 1830 
wurde 
Morand schlie�lich mit dem Gro�kreuz der Ehrenlegion ausgezeichnet. 
..................................................................
;Name
Comte Philbert-Guillaume Duhesme
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1766-1815
;Pers�nlichkeit
;4
;
;Lebenslauf
Der in der Schweiz geborene Duhesme befehligte die Nationalgarde seines Kantons und 
diente 
in Napoleons Helvetischer Republik, bis er 1800 in die franz�sische Armee eintrat. Seine 
erste 
Glanzleistung bestand im Niederbrennen der Br�cke bei N�rnberg im Jahre 1804. Dadurch 
gelang es ihm, zu verhindern, da� die Verst�rkung der Verb�ndeten zum Schlachtfeld 
gelangte. 
In Spanien wurde er durch die Hand geschossen, als er den Vormarsch �ber die Pont d'El 
Rey 
anf�hrte. Eine weitere Kugel prallte gerade noch an einem Jackenknopf ab. Bei seiner 
R�ckkehr 
nach Frankreich wurde er zum Offizier der Ehrenlegion sowie zum Generalmajor ernannt. 
Duhesme aber zog aufgrund seiner schlechten Gesundheit die Rolle als Inspekteur vor und 
kehrte nur f�r den Feldzug nach Waterloo in den aktiven Dienst zur�ck. Im Kampf im 
franz�sischen rechten Fl�gel wurde er in der N�he von Plancenoit t�dlich verwundet. 
..................................................................
;Name
Graf Charles Lef�bvre-Desnouettes
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1773-1822
;Pers�nlichkeit
;2
;
;Lebenslauf
Lef�bvre-Desnouettes diente w�hrend der Revolutionskriege in der Kavallerie. Im Jahre 1800 
�bernahm er die T�tigkeit als Napoleons Adjutant w�hrend des Marengo-Feldzuges. 1806 
wurde 
er zum Brigadegeneral bef�rdert und k�mpfte in den Jahren 1806 und 1807 tapfer an der 
Spitze 
seiner Kavallerie. Zu Beginn des Krieges auf der Pyren�enhalbinsel wurde er erneut 
bef�rdert, 
dieses Mal in den Rang des Generalmajors, und erhielt den Oberbefehl �ber die Berittenen 
Gardej�ger. 1808 geriet er bei Benavente in britische Gefangenschaft und wurde bis 1812 
gefangengehalten, woraufhin er endlich nach Frankreich zur�ckkehren durfte. W�hrend der 
�brigen Feldz�ge Napoleons bet�tigte sich Lef�bvre-Desnouettes als Kommandeur der 
Gardekavallerie. Im Jahre 1822 kam er auf der �berfahrt zu den Vereinigten Staaten von 
Amerika in einem Sturm ums Leben. 
..................................................................
;Name
Comte Claude-Etienne Guyot
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1768-1837
;Pers�nlichkeit
;2
;
;Lebenslauf
Nachdem er 1790 in den Dienst der Bretonischen Kavallerie gestellt worden war, stieg 
Guyot 
1793 in den Rang eines stellvertretenden Leutnants auf. 1799 wurde er zum Hauptmann 
ernannt 
und k�mpfte 1805 in der Schlacht bei Austerlitz. Napoleon, der eine Vorliebe f�r Guyot 
hatte, 
ernannte ihn zum Kommandeur der Ehrenlegion und F�hrer der Kavalleriebrigade in Ru�land. 
Guyot aber lief zu den Bourbonen �ber, war jedoch nicht gerade begeistert, als er unter Pajol 
in 
die Garde des Duc de Bourbon plaziert wurde. Wieder schlo� er sich Napoleon an und wurde 
bei 
Waterloo zweimal verwundet, setzte danach jedoch seine milit�rische Karriere fort. Guyot 
wurde 
f�r seine Taten bei Austerlitz auf dem Arc de Triomphe ein ewiges Denkmal gesetzt.
..................................................................
;Name
Jean-Charles Desales
;Erfahrung
;4
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;2
;
Daten
1768-1830
;Pers�nlichkeit
;2
;
;Lebenslauf
Desales k�mpfte w�hrend der Revolutionskriege in der Arm�e du Nord und erhielt f�r seine 
bei 
der Verteidigung des Lagers bei Maulde bewiesene Tapferkeit eine Auszeichnung. Im Jahre 
1792 wurde er zum Hauptmann ernannt und diente in Italien, wo er beim Erklimmen der 
Mauern 
von Gradisca verwundet wurde. 1805 wurde er zum Kommandanten der Ehrenlegion und 
zum 
Brigadegeneral bef�rdert. In der Schlacht bei Wagram 1809 stellte er seine Artillerie nur 500 
Yards vom Feind entfernt auf, womit er in der �sterreichischen Linie Verwirrung ausl�ste, 
bevor 
er �berrannt und von der gegnerischen Kavallerie fast get�tet wurde. Im Milit�rkrankenhaus 
bei 
Montreuil starb Desales im Jahre 1830 einen friedlichen Tod.
..................................................................
;Name
Baron Joachim Quiot du Passage
;Erfahrung
;4
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;2
;
Daten
1775-1849
;Pers�nlichkeit
;2
;
;Lebenslauf
Quiot, der mit 16 Jahren schon Grenadier und mit 17 Jahren Oberfeldwebel wurde, war ein 
milit�risches Naturtalent und besa� einen scharfen taktischen Verstand. Den gr��ten Teil 
seiner 
Karriere verbrachte er als Berater von rangh�heren Offizieren. 
Nichtsdestoweniger war er in allen wichtigen napoleonischen Feldz�gen im Einsatz und 
k�mpfte 
bei Jena (1806), Albufera (1811), Badajoz (1812) und Kulm (1813). Auf der 
Pyren�enhalbinsel 
erst�rmte er Ballesteros in der N�he von Niebla (1811) und wurde bald darauf zum 
Brigadegeneral bef�rdert. Nach dem Sturz Napoleons kehrte er zu seinen f�rstlichen 
L�ndereien 
zur�ck, schlo� sich jedoch dem Kaiser sofort bei dessen R�ckkehr wieder an. 
Nach der Schlacht bei Waterloo wurde er von den Bourbonen, die die Macht wieder ergriffen 
hatten, verbannt, sp�ter jedoch begnadigt.
..................................................................
;Name
Baron Fran�ois-Xavier Donzelot
;Erfahrung
;5
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1764-1843
;Pers�nlichkeit
;3
;
;Lebenslauf
Donzelot trat an seinem Geburtsort auf Korsika 1783 in die Garnison ein und versah danach 
w�hrend der fr�hen Revolutionsjahre seinen Dienst im Kriegsministerium. 1795 trat er in der 
Rheinarmee wieder in den aktiven Dienst ein, wurde jedoch bei der Verteidigung der Br�cke 
von 
Huningue verwundet. Er diente au�erdem als Stabschef in der Orientarmee, die von 
Napoleon in 
�gypten zur�ckgelassen wurde, und k�mpfte bei Sediman und Kosseir auf dem qualvollen 
R�ckmarsch nach Frankreich. Nachdem er 1799 in den Rang des Brigadegenerals 
aufgestiegen 
war, blieb Donzelot auch weiterhin im Orient, wo er Aufst�nde in Kairo und auf Korfu 
niederschlug. Erst unter den Bourbonen kehrte er 1814 in die franz�sische Staatsarmee 
zur�ck, 
diente jedoch im Jahre 1815 unter Napoleon. Nach der Schlacht bei Waterloo nahm er eine 
Stelle in der Regierung an. Die Gr�nde f�r seinen Tod im Jahre 1843 sind unbekannt.
..................................................................
;Name
Baron Pierre-Louis Binet de Marcognet
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1765-1854
;Pers�nlichkeit
;2
;
;Lebenslauf
Wie Napoleon war auch Marcognet ein Sch�ler an der Milit�rschule und erlebte vor der 
Revolution einen raschen Aufstieg in der Armee. Er erhielt den Hauptmannsrang, nahm aber 
am 
gr��ten Teil der Revolutionskriege nicht teil, da er sich von einer Schu�wunde erholte, die er 
sich in der Schlacht bei Bodenthal 1793 zugezogen hatte. 
Bei seiner R�ckkehr wurde er aufgrund seiner adligen Herkunft unverz�glich suspendiert, 
was 
seine Bef�rderung zum Brigadegeneral trotz seiner wertvollen strategischen F�higkeiten 
verz�gerte. Seine Karriere wurde f�r ein weiteres Jahr unterbrochen, als er in 
Gefangenschaft 
geriet und bei Hohenlinden festgehalten wurde (1801). Sp�ter diente er in Spanien und 
wurde 
1808 zum Reichsbaron ernannt. Im Jahre 1814 wurde er von den Bourbonen zum 
Gro�offizier 
der Ehrenlegion gemacht. Nach der Schlacht bei Waterloo verfolgte er weiterhin seine 
milit�rische Karriere und zog sich 1831 schlie�lich in den Reservistenstand zur�ck. 
..................................................................
;Name
Graf Durette
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;2
;
Daten
1754-1816
;Pers�nlichkeit
;1
;
;Lebenslauf
Zu Anfang seiner milit�rischen Laufbahn diente Durette 1772 bei den Dragonern, zum 
Zeitpunkt 
der Revolution jedoch leitete er den Oberbefehl �ber ein Infanteriebataillon in der 
Alpenarmee. 
Vom Revolutionsrat wurde er als regierungstreuer Verschw�rer zum Tode verurteilt und war 
erst 
nach Napoleons Staatsstreich am 18. Brumaire wieder in der Lage, seine milit�rische Karriere 
aufzunehmen. W�hrend des Krieges auf der Pyren�enhalbinsel erlangte er den Ruf, harte 
Disziplin auszu�ben und Anweisungen genau Folge zu leisten. Bei Waterloo wurde Durette 
bei 
dem Versuch verwundet, den Bauernhof bei Hougoumont einzunehmen und erlag seiner 
Verwundung schlie�lich 1816 im Milit�rkrankenhaus in Caen.
..................................................................
;Name
Baron Charles-Claude Jacquinot
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1772-1848
;Pers�nlichkeit
;4
;
;Lebenslauf
Als Sch�ler an der Milit�rschule von Pont-Mousson schrieb sich Jacquinot als Leutnant bei 
den 
Grenadieren ein und diente 1792 bei Jemappes. Als ber�chtigter Reiter wurde er 1796 zum 
Hauptmann der 1. J�gerbrigade ernannt und diente in der Rheinarmee. Nachdem er erst bei 
Hohenlinden (1800) durch Artilleriefeuer verwundet worden war und sich danach bei Jena 
noch 
ernstlichere Verletzungen zugezogen hatte, ernannte man ihn zu Durocs Berater. Im Jahre 
1809 
wurde er zum Brigadegeneral bef�rdert und verfolgte den sich zur�ckziehenden Feind bei 
Wagram. W�hrend des Ru�landfeldzuges 1812 diente er in den Reserveeinheiten der 
Kavallerie, erfuhr jedoch nichts von Napoleons Niedergang, da er sich bei Dennewitz (1813) 
eine 
schwere Verwundung zugezogen hatte. Auf dem Wiener Kongress im Jahre 1814 wurde er 
als 
Kommission�r von K�nig Ludwig XVIII. mit der Aufgabe betraut, den Austausch von 
Kriegsgefangenen zu regeln. 
Bei Jacquinots R�ckkehr begegnete Napoleon ihm voller Mi�trauen, bis ihn der Mangel an 
ausgebildeten Anf�hrern der Kavallerie dazu zwang, ihn zum Generalmajor zu ernennen. 
Nach der Schlacht bei Waterloo verbrachte Jacquinot mehr als zwanzig Jahre als 
Generalinspekteur der Kavallerie.
..................................................................
;Name
Baron Jean Baptiste Pelletier
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1777-1862
;Pers�nlichkeit
;2
;
;Lebenslauf
Als Arbeitersohn gilt Pelletier als typisches Beispiel f�r den m�glichen milit�rischen und 
sozialen 
Aufstieg in der franz�sischen napoleonischen Armee. W�hrend der Revolution erhielt er 
einen 
Platz an der Artillerieschule und diente in der Artillerie der Infanterie am Rhein und in Italien. 
Nachdem er 1804 zum Kommandeur der Reserveartillerie ernannt worden war, stieg er mehr 
durch sein Wissen als aufgrund seiner aktiven milit�rischen Leistungen auf. Im Jahre 1808 
wurde er zum Reichsbaron und Brigadegeneral ernannt. Nach seiner Gefangennahme in 
Ru�land (1812) kehrte er erst im Jahre 1814 nach kurzem Dienst im polnischen Heer nach 
Frankreich zur�ck. Nach der Schlacht bei Waterloo machte Pelletier in den Armeeschulen 
Karriere und empfing zu seinem 80. Geburtstag 1857 das Gro�kreuz der Ehrenlegion. 
.......................................................
;Name
Baron Gilbert D�sir�e Joseph Bachelu
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1777-1849
;Pers�nlichkeit
;3
;
;Lebenslauf
Bachelu galt an der Milit�rschule in Metz als gefeierter Sch�ler. W�hrend der 
Revolutionskriege 
diente er in der Rheinarmee und als Leutnant in der �gypten-Armee, wo er sich bei der 
Belagerung von Kairo im Jahre 1800 mit besonderen Leistungen hervortat. Bei seiner 
R�ckkehr 
nach Frankreich 1801 wurde er zum stellvertretenden Direktor der Festungsanlagen ernannt. 
Bachelu diente au�erdem von 1806-1809 in Dalmatien und sp�ter in Ru�land (1812), als es 
ihm 
bei Tilsit gelang, den R�cken der Armee zu decken, und er so den Hauptteil der Armee vor 
weiterem Schaden bewahrte. Nach der Kapitulation von 1814 wurde er zum 
Kriegsgefangenen 
und kehrte kurz vor Napoleon 1815 nach Frankreich zur�ck. Nach der Schlacht bei Waterloo 
wurde Bachelu bis 1817 aus Frankreich verbannt, als er zum bonapartistischen 
Abgeordneten 
wurde. Er setzte seine politische Karriere bis 1849 fort. 
..................................................................
;Name
Prinz J�r�me Bonaparte
;Erfahrung
;1
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1784-1860
;Pers�nlichkeit
;5
;
;Lebenslauf
J�r�me war der j�ngste und am wenigsten begabte unter Bonapartes Br�dern. Sein 
Leichtsinn 
brachte ihm eine im Duell zugezogene Wunde und den von Napoleon selbst gepr�gten 
Spottnamen "Lausebengel" ein. Napoleon untersagte J�r�mes erster Frau, einer 
Amerikanerin, 
die Einreise nach Frankreich. Den gr��ten Teil der Eink�nfte seiner zweiten Frau aus dem 
K�nigreich Westfalen verschwendete J�r�me f�r seine kleinen Extravaganzen. Aufgrund 
seiner 
Tr�gheit wurde ihm der Oberbefehl �ber das Westf�lische Korps in Ru�land aberkannt. Als 
ihm 
die F�hrung einer Division bei Waterloo �bertragen wurde, unternahm er den ganzen Tag 
kostspielige und unsinnige Angriffe auf Hougoumont. Nachdem er bis 1847 in Italien im Exil 
gelebt hatte, war er bis zu seinem Tod im Jahre 1860 Senatspr�sident unter Napoleon III.
..................................................................
;Name
Baron Jean Baptiste Girard
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1775-1815
;Pers�nlichkeit
;2
;
;Lebenslauf
Girard meldete sich 1793 als Freiwilliger bei seinem �rtlichen Bataillon und diente in Italien 
unter 
Massena. Bei la Brenta wurde er im Jahre 1797 verwundet und 1798 zum Bataillonschef 
ernannt. Er k�mpfte bei N�rnberg, Austerlitz und Jena, woraufhin er in den Rang des 
Brigadegenerals erhoben wurde. 1808 wurde er zum Reichsbaron gemacht, und man 
�bertrug 
ihm den Oberbefehl �ber die 1. Division des V. Korps, eine der wenigen Divisionen, die 
sp�ter 
nach ihrem Sieg bei Villagarcia (1810) und der erfolgreichen Belagerung von Olivanza (1811) 
unter Ehren aus Spanien abzogen. Girard wurde beim Kampf im hinteren Teil der auf dem 
R�ckzug befindlichen Armee in Ru�land verwundet und konnte sich gl�cklich sch�tzen, 
verschiedene Kopfwunden aus der Schlacht bei Lutzen (1813) zu �berleben. Im Jahre 1814 
wurde er daran gehindert, nach Frankreich zur�ckzukehren. Dennoch schlo� er sich 
Napoleon 
an, als jener in der N�he von Marseille landete. Nachdem er, als er das Dorf Saint-Amand am 
16. Juni 1815 mit einer Garnison belegt hielt, von einem Heckensch�tzen getroffen worden 
war, 
erlag er am 27. Juni schlie�lich seinen t�dlichen Wunden. 
..................................................................
;Name
Comte Maximilien Foy
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1775-1825
;Pers�nlichkeit
;2
;
;Lebenslauf
Foy trat 1790 in den Dienst der Artillerie ein und k�mpfte in den Revolutionskriegen in der 
Arm�e du Nord. Als Freund des einflu�reichen Girondin wurde er von einem 
Revolutionstribunal 
der Erfindung von Kosten f�r die Umverteilung milit�rischer Nahrungsvorr�te f�r schuldig 
befunden. Nach seiner Begnadigung 1795 kehrte er zu seinem Posten als Hauptmann der 
Artillerie zur�ck. Foy erlitt bei seinem Dienst in der Rheinarmee 1797 Verwundungen und 
k�mpfte zwischen 1795 und 1808 in insgesamt �ber 20 Schlachten. Im Jahre 1808 wurde 
er in 
den Rang des Brigadegenerals erhoben. Als er w�hrend seines Dienstes in Spanien 
verwundet 
wurde, fiel er in die H�nde der Portugiesen, die ihn folterten und in einem Brunnen 
gefangenhielten. Schlie�lich wurde er von franz�sischen Truppen gerettet und ging bald 
darauf 
siegreich aus den K�mpfen bei Arroyo del Puerco und Cacares hervor. Zum Lohn f�r seine 
auf 
dem Schlachtfeld bei Torres-Vedras (1810) bewiesene Tapferkeit, wo er Napoleon trotz 
fehlender Deckung wichtige Botschaften �berbrachte, wurde er mit der Offiziersw�rde der 
Ehrenlegion ausgezeichnet. 
Bei Waterloo erlitt Foy w�hrend des Angriffs auf Hougoumont einen Schu� durch die 
Schulter 
und konzentrierte sich nach seiner Genesung auf die Politik. Zum Zeitpunkt seines Todes 
war er 
ein Abgeordneter der Bonapartisten im 3. Pariser Arondissement. 
..................................................................
;Name
Baron Hippolyte Pire
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1778-1850
;Pers�nlichkeit
;4
;
;Lebenslauf
Pire erhielt 1792 eine Stellung in der k�niglichen Garde und schlo� sich nach der Exekution 
des 
K�nigs 1793 den Verbannten in Gro�britannien an, da er als Bote im Dienst von Ludwig 
XVIII. 
stand. 1796 lief er zur franz�sischen republikanischen Armee �ber und unterst�tzte sie bei 
ihrem 
Versuch, den Aufstand der Royalisten im Vend�e sp�ter im selben Jahr zu zerschmettern. 
Vom 
Hauptmann in Austerlitz (1805) stieg er 1808 zum Reichsbaron auf, als er seinen Dienst in 
Spanien antrat. Als Napoleon 1814 ins Exil verbannt wurde, trat er aus der Armee aus, 
kehrte 
jedoch wieder zur�ck, um das nach Napoleons Flucht von Elba erneut begr�ndete Reich zu 
verk�nden. Nach der Schlacht bei Waterloo suchte er in Ru�land Zuflucht und kehrte erst 
1819 
nach Frankreich zur�ck, wo er seine milit�rische Karriere wieder aufnahm, bis der Tod ihr ein 
Ende machte.
.............................................................
;Name
Baron Henri-Marie Noury
;Erfahrung 
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1771-1839
;Pers�nlichkeit
;2
;
;Lebenslauf
Noury, der die Milit�rschulen von Pont-Mousson und Metz besucht hatte, wurde sp�ter als 
die 
administrative Kraft in der franz�sischen Artillerie und als ausgezeichneter Taktiker 
gew�rdigt. Er 
diente als Adjutant unter de Grouchy in der Italienarmee, verbrachte jedoch den gr��ten Teil 
seiner Karriere damit, die Organisation der Artillerie zu erforschen. Nach der Schlacht bei 
Waterloo diente er in verschiedenen Komitees, die sich mit Aufr�stung und 
Befestigungsanlagen 
befa�ten.
..................................................................
;Name
Baron Fran�ois-Martin-Valentin Simmer
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1776-1847
;Pers�nlichkeit
;4
;
;Lebenslauf
Simmer, dem bei der Befreiung Maastrichts der rechte Arm zerschmettert wurde, diente 
w�hrend 
der Revolutionskriege in der Arm�e du Nord. Sein kurzer Einsatz in der Kavallerie wurde 
durch 
eine zweite, von der Artillerie verursachte, Verwundung an der linken Schulter beendet. Als 
Hauptmann im VII. Korps wurde Simmer bei Friedland f�r die Tapferkeit ausgezeichnet, die 
er 
trotz einer weiteren Verwundung bewies. Nach der Schlacht bei Waterloo wurde er aus dem 
aktiven Dienst entlassen und diente noch f�r kurze Zeit als Abgeordneter.
..................................................................
;Name
Baron Jean Baptiste Jeanin
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1769-1830
;Pers�nlichkeit
;3
;
;Lebenslauf
Jeanin diente gemeinsam mit anderen Freiwilligen beim Massenangriff auf Wissembourg und 
bei der Belagerung der Mannheimer Festung am Rhein. In �gypten k�mpfte er in der 
Schlacht 
um die Pyramiden und wurde bei der Belagerung von Akko verwundet. Des weiteren 
k�mpfte er 
bei Aboukir und Heliopolis, bevor er, vier Jahre nach Beginn seiner Reise, Frankreich 1801 
wieder erreichte. Sp�ter diente Jeanin in Spanien und wurde im Jahre 1808 zum 
Reichsbaron 
ernannt. 1809 erlangte er den Rang des Brigadegenerals und wurde f�r sein umsichtiges 
Verhalten bei der Evakuierung von Karlstadt (1813) mit einem Ruhegeld belohnt. Als die 
Bourbonen wieder die Macht ergriffen, war er beide Male gezwungen, sich zur�ckzuziehen. 
Infolgedessen erhielt er 1825 nur noch eine symbolische Stellung.
..................................................................
;Name
Baron Fran�ois-Antoine Teste
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1775-1862
;Pers�nlichkeit
;2
;
;Lebenslauf
Teste war der Bruder jenes Finanzministers, dem es nicht gelang, Frankreich in den Jahren 
1788-89 vor dem Bankrott und der Revolution zu bewahren. Schon wenige Tage, nachdem 
er 
sich 1793 bei den Grenadiereinheiten gemeldet hatte, wurde Teste zum Lohn f�r sein 
schnelles 
Handeln, als er furchtlos in ein Lager von Meuterern hineinmarschierte, zum Feldwebel 
bef�rdert. Der Verdacht, da� er die gleichen Verbindungen mit adligen H�usern pflegte wie 
sein 
Bruder, f�hrte zu seiner Suspendierung. Obgleich er 1796 begnadigt wurde, blieb es ihm bis 
zum 
Italienfeldzug 1798 versagt, den Dienst wieder aufzunehmen. 
Teste war ein treuer Freund und ergebener Diener Massenas. Nachdem er im Jahre 1812 in 
Moskau ernsthaft verwundet worden war, wurde ihm eine administrative Aufgabe 
zugewiesen. 
Erst bei der verzweifelten Verteidigung Frankreichs 1814 wurde er wieder in die Armee 
einberufen. Nach Waterloo zog er sich aus dem aktiven Dienst zur�ck und bet�tigte sich als 
Inspekteur, bis ihm 1849 anl��lich seiner Versetzung in den Ruhestand das Ehrenkreuz 
verliehen wurde.
..................................................................
;Name
Baron Samuel-Fran�ois L'Heritier
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1772-1829
;Pers�nlichkeit
;3
;
;Lebenslauf
W�hrend der Revolutionskriege diente L'Heritier in der Rheinarmee und verteidigte die 
franz�sische Grenze. Nachdem er w�hrend dieser Zeit in den Rang des Hauptmanns 
aufgestiegen war, wurde er im Jahre 1800 bei Marengo in den Oberschenkel getroffen, was 
ihn 
jedoch nicht davon abhielt, 1801 in eine Dragonerdivision �berzuwechseln. Zwischen 1805 
und 
1812 diente er in den Feldz�gen gegen Preu�en, �sterreich und Ru�land und erhielt den 
Oberbefehl �ber eine Division der Schweren Kavallerie. Mit dieser Division schlug er im 
Jahre 
1813 einen schweren Angriff der Kosaken auf die franz�sische Grenze zur�ck.
W�hrend der beiden Wiedereinsetzungen der Bourbonen wurde er aus dem aktiven Dienst 
abgezogen und in einen Posten als Inspekteur der Kavallerie versetzt, in dem er bis zu 
seinem 
Tod 1829 verblieb.
..................................................................
;Name
Comte Getil de Saint-Alphonse
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1777-1837
;Pers�nlichkeit
;2
;
;Lebenslauf
Saint-Alphonse diente zwischen 1793-99 in der Rheinarmee und wurde dann in die Kolonie 
Tobago versetzt. Bei seiner R�ckkehr wurde er Adjutant f�r Bernadotte und versah seinen 
Dienst 
w�hrend der Eins�tze in Jena, Wagram und Moskau in verschiedenen Kavalleriedivisionen. 
Zuerst befehligte er eine Kavalleriebrigade gegen Ende der Verteidigung Italiens im Jahre 
1813. 
Nach der Schlacht bei Waterloo zog er sich aus dem aktiven Dienst zur�ck, um eine 
administrative Laufbahn einzuschlagen, in der er schlie�lich zum Sekret�r des Obersten 
Kriegsrates aufstieg.
..................................................................
;Name
Baron Jacques Antoine Adrien Delort
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1773-1846
;Pers�nlichkeit
;2
;
;Lebenslauf
Als Freiwilliger stieg Delort durch seinen tapferen Dienst bei der Verteidigung Frankreichs 
durch 
die revolution�ren Kr�fte zum Hauptmann seiner Kavalleriebrigade auf. Auf dem Schlachtfeld 
bei Pastrengo wurde er zum F�hrer einer Dragonerdivision ernannt, eine Entscheidung, die 
von 
Napoleon sp�ter bekr�ftigt wurde. Er f�hrte 1805 bei Austerlitz die Angriffe auf die Kosaken 
und 
wurde zweimal von Lanzen verwundet. Delort diente in Spanien, wo er durch mehrere 
S�belhiebe ernsthaft verwundet wurde, als seine Kavalleriedivision, ohne Raum zum 
Man�vrieren oder zum Angriff zu haben, bei Valls (1811) eingeschlossen war. Nach 
Waterloo 
zog er sich aus der Armee zur�ck und ging in die Politik, wo er schlie�lich bis zum Posten 
eines 
Beamten im Finanzministerium aufstieg.
..................................................................
;Name
Baron J�r�me Dogereau
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1772-1843
;Pers�nlichkeit
;2
;
;Lebenslauf
Dogereau erhielt seine Ausbildung f�r den Dienst in der Artillerie an der Milit�rschule in 
Metz, 
sein Kurs wurde jedoch durch die Krisensituation w�hrend der Revolutionskriege abrupt 
abgebrochen. Bei der Verteidigung Frankreichs wurde ihm der Befehl �ber ein 
Reserveartillerieregiment �bertragen. Sp�ter wurde er in �gypten zum Hauptmann bef�rdert 
und 
1808 als Generalmajor nach Spanien entsandt. Sein Artilleriebataillon bewies eine 
herausragende Leistung, als es die russische Truppenverst�rkung auf eine falsche F�hrte 
lockte, 
w�hrend der entscheidende Angriff auf Smolensk durchgef�hrt wurde (1812). Nach 
Waterloo 
wurde Dogereau von Ludwig XVIII. mit der Aufgabe eines Inspekteurs der Artillerie betraut 
und 
so vom aktiven Dienst befreit.
..................................................................
;Name
Baron Etienne-Nicolas Lefol
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1764-1840
;Pers�nlichkeit
;3
;Lebenslauf
Lefol wurde in seinem Dragonerregiment zum Hauptmann ernannt, als er in den Jahren 1791 
und 1792 seinen Dienst in Belgien versah. Er diente f�r aufeinanderfolgende Bataillonschefs 
in 
der Arm�e du Nord als Generaladjutant, bis er 1800 f�r ein Jahr in �sterreichische 
Kriegsgefangenschaft geriet. Zwischen 1805 und 1807 diente er in �sterreich, Preu�en und 
Polen, bevor er zum Brigadegeneral ernannt und mit dem I. Korps nach Spanien entsandt 
wurde. Beim R�ckzug aus Spanien 1813 l�ste sich Lefols Brigade auf, woraufhin er erst 
wieder 
f�r die Schlacht um Leipzig im Oktober 1813 in den Dienst berufen wurde. Nachdem er bei 
Ligny 
gek�mpft hatte, wurde er unter den Bourbonen in die Reserveeinheit beordert.
..................................................................
;Name
Baron Pierre-Joseph Habert
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1773-1825
;Pers�nlichkeit
;3
;
;Lebenslauf
Habert schlo� sich dem Milit�r in der allgemeinen Aufbruchsstimmung von 1792 an und 
wurde 
noch im selben Jahr zum Hauptmann seines Regiments gew�hlt. Innerhalb von zwei Jahren 
durchlief er vier verschiedene Posten und wurde schlie�lich 1794 zum Bataillonschef 
ernannt. 
Ziel seines ersten Feldzuges war Irland, von wo er 1797 wieder nach Frankreich 
zur�ckkehrte. 
Im Jahre 1800 wurde er zum zweiten Mal auf einen Feldzug gesandt und geriet bei einer 
Schlacht im irischen Kanal in Gefangenschaft. Aufgrund eines Gefangenenaustauschs kehrte 
er 
wieder zur�ck. Danach diente Habert in �gypten, wo er auf dem Schlachtfeld von Canupe 
zum 
Brigadechef ernannt wurde. In der Schlacht bei Heilsberg 1813 stieg er in den Rang des 
Brigadegenerals auf, kurz nachdem er zwei Schu�verletzungen erlitten hatte. Trotz seiner 
ernsthaften Verwundung bei Waterloo setzte Habert seine milit�rische Karriere bis zu seinem 
Tod in Montreal 1825 fort.
..................................................................
;Name
Baron Pierre Berthez�ne
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1775-1847
;Pers�nlichkeit
;2
;
;Lebenslauf
Berthez�ne, der w�hrend der Revolution als freiwilliger Soldat gedient hatte, wurde 
wiederholt 
f�r seine Tapferkeit bei Scharm�tzeln in den Pyren�en gelobt und stieg 1793 zum 
Oberfeldwebel 
auf. Berthez�ne diente in Italien, wo er zum Hauptmann bef�rdert und bei Pozzolo am 
rechten 
Bein verwundet wurde. Nachdem er als Gesandter und Repr�sentant in die neugegr�ndeten 
deutschen Staaten abkommandiert worden war, erhielt er f�r den Waterloo-Feldzug erneut 
einen 
Einzugsbefehl von der Arm�e du Nord. Da er sich selbst nach Waterloo weigerte, die 
Niederlage 
zu akzeptieren, erregte er den Zorn der Bourbonen und blieb infolgedessen f�r den Rest 
seiner 
Laufbahn Inspekteur der Infanterie.
..................................................................
;Name
Baltus de Pouilly
;Erfahrung
;3
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;3
;
Daten
1777-1849
;Pers�nlichkeit
;1
;Lebenslauf
Baltus de Pouilly verbrachte f�nf Jahre an der Milit�rschule in Metz. Er gelangte in den Ruf, 
ein 
Taktiktheoretiker zu sein, der sogar unter feindlichem Feuer noch die Nerven bewahrte. Sein 
Organisationstalent wurde erstmals bemerkt, als er 1798 den Artilleriebeschu� der Festung 
von 
Malta mit den Angriffen der Infanterie auf die Festung koordinierte. Danach diente er in 
�gypten 
und erhielt als Geheimagent den Auftrag, die Lage auszukundschaften und die Invasion in 
Holland im Jahre 1810 vorzubereiten. Er diente als Attach� f�r Napoleons Kabinett in 
Ru�land, 
wo seine ausgezeichneten Ratschl�ge ihm nicht nur Respekt, sondern auch die Bef�rderung 
zum Brigadegeneral einbrachten. Nach der Schlacht bei Waterloo zog sich de Pouilly aus der 
Armee zur�ck und setzte seine administrativen F�higkeiten im Ministerium f�r staatliche 
Bauvorhaben ein.
..................................................................
;Name
Baron Marc-Nicolas-Louis P�cheux
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1769-1831
;Pers�nlichkeit
;2
;
;Lebenslauf
P�cheux stieg w�hrend der Revolutionskriege zum Brigadechef auf. Im Jahre 1804 wurde er 
zum Oberst der 95. Gefechtslinieninfanterie ernannt und k�mpfte bei Austerlitz und der 
Eroberung von L�beck 1805. In Spanien zeichnete sich P�cheux bei der Eroberung Madrids 
durch besondere Leistungen aus. Als Hannover im Jahre 1813 mit einer Garnison belegt 
war, 
wurde seine Division von den im R�ckzug begriffenen Franzosen zur�ckgelassen. Daraufhin 
hielt er bis zum Maifrieden 1814 in Hannover die Stellung. F�r den Waterloo-Feldzug stieg 
P�cheux in der Arm�e du Nord in den Rang eines Generalmajors auf. Nach Waterloo wurde 
er 
1815 aus dem aktiven Dienst entlassen. Im Jahre 1818 erhielt P�cheux den Posten als 
Inspekteur und kehrte 1821 als Oberbefehlshaber �ber eine Reservedivision wieder in den 
aktiven Dienst zur�ck.
..................................................................
;Name
Baron Louis-Joseph Vichery
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1767-1831
;Pers�nlichkeit
;3
;
;Lebenslauf
Vichery trat 1781 in Kanada in die Armee ein und diente sp�ter in der franz�sischen 
Nationalgarde, die dazu beitrug, die Revolution erfolgreich zu Ende zu f�hren. F�r kurze Zeit 
diente er sowohl in der holl�ndischen als auch in der franz�sisch-holl�ndischen Armee, bis er 
sich 1805 in �sterreich wieder der franz�sischen Nationalarmee anschlo�. Sp�ter diente er 
erneut unter den Holl�ndern als Brigadier. 1810, nach Hollands Eingliederung ins 
napoleonische 
Reich, trat er als Generalmajor wieder in die franz�sische Armee ein. Als Kommandant der 
Ehrenlegion k�mpfte Vichery auch nach Waterloo weiter und gab seinen Posten in der 
Armee 
erst auf, als die Bourbonen wieder die Macht ergriffen. Er starb im Jahre 1831 an einem 
Schlaganfall.
..................................................................
;Name
Comte Louis de Bourmont
;Erfahrung
;4
;
Titel
Franz�sischer Marschall
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1773-1846
;Pers�nlichkeit
;4
;
;Lebenslauf
Bourmont verpflichtete sich 1788 f�r die franz�sische Garde, wechselte jedoch in die Armee 
der 
Vend�e �ber, als seine Familie nach Turin auswanderte. Er stieg in den Rang eines Generals 
auf, bevor er 1800 als Hauptmann in die franz�sische Armee zur�ckkehrte. Im Jahre 1804 
wurde 
er wegen Mitt�terschaft in einem politischen Skandal verhaftet und erst 1809 wieder 
freigelassen. Nachdem er einen besonderen Antrag gestellt hatte, durfte er f�r den 
Ru�landfeldzug erneut in die Armee eintreten und seinen Posten als Bataillonsf�hrer wieder 
aufnehmen. Dort zeichnete er sich durch seine au�ergew�hnlichen Leistungen beim R�ckzug 
aus Moskau aus. Bourmont wurde im Jahre 1813 von Napoleon zum franz�sischen 
Marschall 
ernannt, desertierte jedoch am 14. Juni mitsamt seinem Stab zur Koalition. Nach Waterloo 
nahm 
er einen Posten in Algerien an. 1832 erkannte man ihm seinen Rang ab, und er wurde 
wegen 
Verrats zum Tode verurteilt. Schlie�lich wurde ihm jedoch die Gnade gew�hrt, bis zum Ende 
seiner Tage auf seinen franz�sischen L�ndereien zu leben, wo er in seinem Schlo� im Jahre 
1846 starb.
..................................................................
;Name
Baron Antoine Maurin
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1771-1830
;Pers�nlichkeit
;3
;
;Lebenslauf
Maurin schlo� sich 1792 einem Kavallerieregiment an und zeichnete sich in der Schlacht bei 
Maastricht (1794) durch besondere Leistungen aus. In Roer (1794) geh�rte er zu jenen, die 
durch den Flu� schwammen, um zu den feindlichen Verschanzungen zu gelangen. Er f�hrte 
den 
Angriff bei Kreuznach 1795 und wurde 1796 im Kampf gegen die Hannoveraner bei 
Burgwindsheim durch verschiedene S�belhiebe verwundet. Maurin wurde vom Direktorium 
in 
den Rang eines Leutnants erhoben und im Jahre 1798 zum Adjutanten Bernadottes ernannt, 
in 
dessen Diensten er in der Westarmee stand. F�r kurze Zeit wandte er sich auf Seiten 
Bernadottes gegen Napoleon und diente als Kommandeur seiner k�niglichen Garde in 
Schweden, schlo� sich jedoch 1815 dem Kaiser an. Sp�ter fand Maurin eine Anstellung im 
Kriegsministerium.
..................................................................
;Name
Baron Pierre-Beno�t Soult
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten 
1770-1843
;Pers�nlichkeit
;3
;
;Lebenslauf
Soult diente in den Revolutionskriegen in der 33. Infanterie und wurde 1793 bei Saverne 
verwundet. Er bet�tigte sich als Adjutant seines Bruders, des sp�teren Herzogs von 
Dalmatien 
und Pr�sidenten von Frankreich, bis er 1797 zum Leutnant ernannt wurde. Soult folgte 
seinem 
Bruder im Jahre 1800 in die Italienarmee, wo beide in der Schlacht von Monte-Cretto in 
Gefangenschaft gerieten. Nachdem er in Heilsberg 1807 verwundet worden war, stieg Soult 
in 
den Rang eines Brigadegenerals auf. In Spanien, wo er erneut unter seinem Bruder diente, 
zeichnete sich Soult bei Alba-de-Tormes 1812 durch besondere Leistungen aus, als er einen 
Angriff der Kavallerie anf�hrte, obwohl sein Arm von Schrapnell zerschmettert war. Gleich 
seinem Bruder schmeichelte sich Soult bei den eintreffenden Bourbonen ein, nur um sich 
dann 
wieder der Arm�e du Nord anzuschlie�en. Sp�ter begann er als Pr�fekt seine politische 
Karriere 
und erhielt 1831 das Kreuz der Ehrenlegion.
..................................................................
;Name
Baron Jacques-Gervais Subervie
;Erfahrung 
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1776-1856
;Pers�nlichkeit
;2
;
;Lebenslauf
Subervie schrieb sich 1792 f�r den Feldzug in den Pyren�en zum Dienst in einer 
Kavalleriedivision ein. Er wurde mit der Armee in den Orient entsandt und k�mpfte bei der 
Eroberung Maltas 1798, sah sich jedoch aufgrund von Krankheit gezwungen, dort 
zur�ckzubleiben. Erst als die Briten die Insel im Jahre 1800 zur�ckeroberten, kehrte er nach 
Frankreich zur�ck. Subervie k�mpfte in den Feldz�gen gegen �sterreich, Preu�en und 
Ru�land 
in den Jahren 1805-07. 1811 wurde er zum Brigadegeneral bef�rdert und 1812 w�hrend 
des 
Ru�landfeldzuges in Moskau durch zwei Lanzenstiche verwundet. Bei der Verteidigung von 
Paris 1814 wurde er erneut auf �hnliche Weise verwundet. Nach Napoleons Abdankung im 
Jahre 1814 wurde Subervie von den zur�ckkehrenden Bourbonen aus dem Dienst entlassen, 
bei 
Napoleons R�ckkehr jedoch wieder als Brigadegeneral eingesetzt. Nach der Schlacht bei 
Waterloo wurde er Inspekteur der Kavallerie. 
..................................................................
;Name
Chevalier Jean-Baptiste Strolz
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1771-1841
;Pers�nlichkeit
;4
;
;Lebenslauf
Strolz trat 1793 als Kavalier in die 1. J�gereinheit der franz�sischen Armee ein. 1796 wurde 
er 
nach seinem Dienst an der Mosel zum Leutnant ernannt und handelte als Adjutant Moreaus 
in 
Italien den Waffenstillstand von Parsdorf im Jahre 1800 aus. Sp�ter diente er in der Armee 
von 
Neapel unter Murat und wurde zum Chevalier des Ordens der beiden Sizilien geschlagen. 
1814 
kehrte er als Brigadegeneral in die franz�sische Armee zur�ck und trat als Adjutant in den 
Dienst 
Joseph Bonapartes.
..................................................................
;Name
Baron Louis Pierre Chastel
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1774-1826
;Pers�nlichkeit
;3
;
;Lebenslauf
Chastel diente zuerst in der Belagerung von Toulon im Jahre 1793. 1797 wurde er zum 
Hauptmann der Dragoner ernannt und versah seinen Dienst in Italien. Weiterhin diente er im 
�gyptenfeldzug 1798, auf dem er die Tierkreisdarstellungen zu Dendera entdeckte. In den 
Jahren 1805 und 1806 begab er sich in den Dienst der Grand Arm�e und nahm an den 
Feldz�gen teil, die zu den Schlachten bei Austerlitz und Jena f�hren sollten. 1807 wurde er 
zum 
Majoroberst bef�rdert und 1808 zum Reichsbaron ernannt. Im Jahre 1815 stieg er f�r den 
Waterloo-Feldzug in den Rang eines Generalmajors auf, wurde jedoch bei der R�ckkehr der 
Bourbonen mit einer nichtmilit�rischen Aufgabe bedacht. 
..................................................................
;Name
Baron Jean-Simon Domon
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1774-1830
;Pers�nlichkeit
;1
;
;Lebenslauf
Domon diente in den Jahren 1792-95 in der Arm�e du Nord. Er k�mpfte bei Courtrai und 
Jemappes und erlitt w�hrend des Angriffs auf Nechin 1794 eine Schu�wunde in der rechten 
Hand. 1795 wurde er vom Komitee f�r �ffentliche Sicherheit zum Adjutanten des G�n�ral 
Comp�re ernannt, kehrte aber f�r die Feldz�ge in �sterreich und Preu�en (1805-07) in die 
Grand Arm�e zur�ck. Als Murats Adjutant in Neapel weigerte er sich, mit diesem 1814 zur 
Koalition �berzulaufen. 
Domon wurde bei Waterloo w�hrend eines Angriffs, der Bl�chers weiteres Vorr�cken 
verhindern 
sollte, verwundet. 
Nach Waterloo verbrachte er 5 Jahre im "Exil" in den Provinzen, bevor es ihm gestattet 
wurde, 
seine milit�rische Karriere als Kommandant der Dragoner wieder aufzunehmen.
..................................................................
;Name
Baron Fran�ois-Nicolas Haxo
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1774-1838
;Pers�nlichkeit
;2
;
;Lebenslauf
Haxo, der seine F�higkeiten an der Artillerieschule erlernt hatte, versah seinen ersten Dienst 
im 
Jahre 1794 bei der Verteidigung von Landau. Danach absolvierte er einen Kurs f�r 
Milit�ringenieure an der �cole Polytechnique und schlo� sich der Armee wieder rechtzeitig 
an, 
um in Italien k�mpfen zu k�nnen, wo er die Befestigungsanlagen bei Roca d'Anfo entwarf. 
Im 
Jahre 1807 wurde er als Bote nach Konstantinopel entsandt, um den T�rken bei der 
Befestigung 
der Dardanellen gegen die Briten zu helfen. In den Jahren 1812 und 1813 �bernahm er die 
Verantwortung f�r die vordere Grenzverteidigung des Kaiserreiches an Oder, Elbe und 
Weichsel. Nachdem er verwundet und bei der Belagerung von Kulm 1813 
gefangengenommen 
worden war, begann er seinen langen R�ckweg �ber Ungarn nach Paris. 1815 plante er die 
Befestigungsanlagen von Paris und diente dann bei Waterloo. Nach Napoleons Niederlage 
bezichtigte Marschall Davout, der die Verantwortung f�r die Verteidigung von Paris trug, 
Haxo 
heimlicher Verhandlungen mit den Anh�ngern des Bourbonen Ludwig XVIII. In sp�teren 
Jahren 
besch�ftigte Haxo sich mit dem Entwurf von Kan�len und besann sich in den Zwanziger 
Jahren 
wieder der milit�rischen Ingenieurstechnik, seinem urspr�nglichen Wirkungsfeld.
..................................................................
;Name
Baron Marie-Th�odore Garbe
;Erfahrung
;2
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;2
;
Daten
1769-1831
;Pers�nlichkeit
;3
;
;Lebenslauf
Nach Absolvieren der Milit�rschule in Metz wurde Garbe w�hrend seines Dienstes in Italien 
1796 
zum Hauptmann ernannt. In �gypten k�mpfte er bei der Eroberung Alexandrias und wurde 
bei 
Sediman verwundet. 1801 wurde er zum stellvertretenden Direktor f�r Befestigungsanlagen 
und 
1805 zum Ingenieuroberst ernannt. Nachdem er in Waterloo gek�mpft hatte, zog er sich aus 
der 
Armee zur�ck, trat jedoch sp�ter als Inspekteur der Ingenieure (1816-22) und als Berater f�r 
Waffensysteme wieder in die Armee ein. Im Jahre 1830 begann er als Abgeordneter seine 
politische Karriere.
..................................................................
;Name
Baron Camus de Richemont
;Erfahrung 
;4
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;3
;
Daten
1774-1813
;Pers�nlichkeit
;3
;
;Lebenslauf
Im Jahre 1792 schlo� sich Richemont einem Regiment an, das aus Anw�rtern f�r Pl�tze an 
der 
Artillerieschule bestand, und erhielt schlie�lich, nachdem er in den Ardennen gek�mpft hatte, 
einen Studienplatz. Als Leutnant im 3. Regiment der Infanterieartillerie kam er danach wieder 
zum Milit�r. Er wurde 1799 zum Hauptmann und 1809 zum Reichsbaron ernannt. W�hrend 
der 
Verteidigung des Rheins erhielt er den Titel eines Brigadegenerals. In Leipzig wurde er durch 
Bajonette schwer verletzt und erlag kurz darauf seinen Wunden. [Anm.: Soll bei Waterloo 
nicht 
dabei gewesen sein.]
..................................................................
;Name
Jean Isaac Sabatier
;Erfahrung
;4
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;2
;
Daten
1756-1829
;Pers�nlichkeit
;4
;
;Lebenslauf
Sabatier meldete sich 1773 beim Regiment von Sarre, nur um bald darauf zu desertieren und 
sich 1774 in einer Str�flingskolonne wiederzufinden. 1789 stellte er in Nevers die 
Nationalgarde 
zusammen und wurde 1792 zum Hauptmann der Grenadiere gew�hlt. Als leidenschaftlicher 
Republikaner wurde er im Rang des Brigadegenerals ausgesandt, um die Royalisten in der 
Vend�e zu zerschmettern. Er wurde jedoch vom Dienst suspendiert und ins Gef�ngnis 
gesteckt, 
als das Direktorium den Spie� gegen die blutd�rstigsten Revolution�re umdrehte. Nachdem 
er 
eine Zeitlang im S�den Frankreichs als Zollbeamter t�tig gewesen war, organisierte er die 
Verteidigung Cayennes gegen die Portugiesen im Jahr 1809. Diese herausragende Leistung 
gab 
seiner milit�rischen Laufbahn neuen Schwung, und w�hrend der 100 Tage stieg er in den 
Rang 
des Brigadegenerals auf. Er starb 1829 im Milit�rhospiz von Avignon.
..................................................................
;Name
Chevalier Pierre Michel Nempde-Dupoyet Nempde
;Erfahrung
;3
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;2
;
Daten
1775-1833
;Pers�nlichkeit
;3
;
;Lebenslauf
Nempde besuchte die Artillerieschule bis 1795. W�hrend er in der Italienarmee diente, wurde 
er 
zum Hauptmann bef�rdert. Bei der Belagerung von Gaete wurden die Ingenieure, die sich 
bem�hten, die �sterreichische Verteidigung zu untergraben, durch die feindliche Infanterie 
gefangengenommen. Nempde wurde mit dem Bajonett verwundet und in ein Gef�ngnis 
geworfen, wo er elendig sterben sollte. Im Jahre 1807 wurde er jedoch befreit, als die 
�sterreicher sich aus Italien zur�ckzogen. Er diente in Spanien und wurde bei Saragossa 
erneut 
verwundet. Danach ernannte man ihn zum stellvertretenden Direktor der 
Befestigungsanlagen 
von Ostende und im Jahre 1813 zum Brigadegeneral. Nach der Schlacht von Waterloo blieb 
Nempde weiterhin ein Mitglied des Komitees f�r Befestigungsanlagen. Er starb 1833 
w�hrend 
einer Choleraepidemie. 
..................................................................
;Name
Eleonor-Bernard Dufriche de Valaze 
;Erfahrung
;4
;
Titel
Brigadegeneral
Kommandeur des 4. Ingenieurskorps
;F�hrungsqualit�ten
;2
;
Daten
1780-1838
;Pers�nlichkeit
;2
;
;Lebenslauf
De Valaze wurde sowohl an der �cole Polytechnique als auch an der Artillerieschule 
ausgebildet. 
In der Schlacht bei Austerlitz (1805) wurde er verwundet und bei seiner R�ckkehr zum 
Kommandeur der Ingenieure im I. Korps ernannt. In Spanien befehligte er die Belagerung von 
Astorga, wurde jedoch w�hrend des entscheidenden Angriffs am Kopf verwundet. 
Als Napoleon sich nach Elba ins Exil begab, �bernahm de Valaze eine zivile Anstellung an 
der 
Schule von Metz, schlo� sich dann jedoch wieder Napoleon an und k�mpfte im Waterloo-
Feldzug. Sp�ter wurde sein Wirkungsfeld auf die Aufgabe als Inspekteur der Verteidigung 
entlang des Rheins eingeschr�nkt.
..................................................................
;Name
Baron Roussel d' Hurbal
;Erfahrung
;5
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1770-1830
;Pers�nlichkeit
;3
;
;Lebenslauf
D'Hurbal, ein junger Adliger mit Beziehungen zum Haus der Bourbonen, kam 1787 zur 
k�niglichen Kavalleriegarde von Ludwig XVI., sah sich jedoch gezwungen, w�hrend der 
schrecklichen Zeit von 1793-94 aus Frankreich zu fliehen. 
Er kehrte in die Stellung als Hauptmann der 12. Kavalleriedivision zur�ck und leistete seinen 
Dienst in den Feldz�gen von Austerlitz, Jena und Wagram. Unter Pagnol wurde er in Spanien 
zum Generalmajor bef�rdert. Nach Waterloo zeigten die Bourbonen Nachsicht mit ihm, 
weswegen er auch weiterhin im Milit�rdienst bleiben durfte, bis ihn seine Gesundheit im 
Jahre 
1827 dazu zwang, sich auf seine L�ndereien zur�ckzuziehen. 
..................................................................
;Britische Gener�le
;Name
Arthur Wellesley
;Erfahrung
;5
;
Titel
Herzog von Wellington
Feldmarschall
;F�hrungsqualit�ten 
;4
;
Daten
1769-1852
;Pers�nlichkeit
;3
;
;Lebenslauf
Arthur Wellesley, seinem Bruder Richard geistig unterlegen, wurde als ausschlie�lich f�r eine 
milit�rische Laufbahn geeignet betrachtet. Nach einer Reihe kleinerer Eins�tze erhielt er 
schlie�lich 1793 den Befehl �ber die 33. Infanterie. Es war jedoch der kommende Krieg mit 
Frankreich, in dem sich seine au�erordentliche milit�rische Begabung und seine Siegernatur 
zeigen sollten. Im weiteren Verlauf seiner Laufbahn �bernahm er den Oberbefehl �ber die 
Armee in Indien und sp�ter in Spanien und Portugal. Durch seine sorgf�ltige Organisation 
und 
strikte Disziplin gewann Wellington den Respekt (jedoch nicht die Sympathie) seiner 
Truppen, da 
er sich furchtlos immer mitten auf dem Schlachtfeld befand. Obgleich er nur von 
mittelgro�er 
Gestalt war, hatte Wellington zu Pferde eine ehrfurchtgebietende Pr�senz, und sein 
Erscheinen 
an den entscheidenden Punkten einer Schlacht wurde f�r die britischen Truppen bald zum 
Symbol ihres Erfolges. Obwohl seine F�higkeiten in der Verteidigung oft als seine St�rke 
betrachtet wurden, so bewies er doch auch h�ufig entscheidende Initiative in 
Angriffsschlachten, 
wie aus seinen Siegen bei Salamanca (1812) und Vitoria (1813) ersichtlich wird. Nachdem 
er f�r 
seinen Triumph �ber Napoleon im Krieg auf der Pyren�enhalbinsel und dem Waterloo-Feldzug 
gefeiert worden war, �bernahm er das Amt des Premierministers von Gro�britannien. Er 
starb 
1852 und erhielt ein feierliches Staatsbegr�bnis in der St. Pauls-Kathedrale.
..................................................................
;Name
Wilhelm von Oranien
;Erfahrung
;3
;
Titel
S.K.H. Prinz von Oranien
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1792-1849
;Pers�nlichkeit
;4
;
;Lebenslauf
Als �ltester Sohn und Erbe von Wilhelm Friedrich, dem K�nig der Niederlande, lebte Prinz 
Wilhelm seit dem zarten Alter von drei Jahren im Exil. W�hrend des Krieges auf der 
Pyren�enhalbinsel diente er als Wellingtons Adjutant. 1815 wurde ihm trotz seiner 
begrenzten 
milit�rischen Erfahrung der Oberbefehl �ber ein Korps der Koalitionsarmee �bertragen. 
Wenngleich �ber die Tapferkeit des Prinzen nie Zweifel bestanden, so lie�en doch seine 
taktischen F�higkeiten zu w�nschen �brig. W�hrend des Feldzuges verschwendete er 
verschiedene Einheiten und wurde nur durch eine Schu�wunde, die ihn dazu zwang, das 
Schlachtfeld zu verlassen, davon abgehalten, noch mehr katastrophale Fehler zu begehen. 
1840 
trat er die Thronfolge seines Vater an und wurde Wilhelm II., K�nig von Holland. 
..................................................................
;Name
Sir Rowland Hill
;Erfahrung
;4
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;2
;
Daten
1772-1842
;Pers�nlichkeit
;2
;
;Lebenslauf
Rowland Hill wurde erstmals 1790 in den Dienst gestellt. W�hrend des Krieges auf der 
Pyren�enhalbinsel diente er in Talavera erst als Kommandeur einer Brigade und dann als 
Kommandeur einer Division. Er trug entscheidend zum Erfolg des Krieges bei, indem er die 
franz�sischen Truppen bei Arroyo dos Molinos in die Flucht schlug. Als er bei St. Pierre 
(1811) 
von Wellington getrennt wurde, wehrte er mit 15 000 M�nnern erfolgreich die mit 30 000 
Mann 
durchgef�hrten Angriffe des Marschall Soult ab. Mit seiner G�te gewann er die Loyalit�t und 
Mitarbeit seiner untergebenen Offiziere und erwarb sich den Spitznamen "Daddy Hill". 
Wellington sch�tzte ihn f�r seine au�ergew�hnliche P�nktlichkeit, seinen Gehorsam und die 
Tatsache, da� er nicht jenen rastlosen Ehrgeiz besa�, der M�nner dazu bringt, mehr an die 
Gelegenheiten zu denken, in denen sie sich hervortun k�nnen, als an die Durchf�hrung ihrer 
Befehle. Hill bewies im 100-Tage-Feldzug in der N�he der britischen Mitte ungeheures 
Geschick 
in der Durchf�hrung seiner Aufgaben. 1825 wurde er General und von 1828 bis 1842 
milit�rischer Oberbefehlshaber in England. 
..................................................................
;Name
Sir George Cooke
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1769 - 1837
;Pers�nlichkeit
;2
;
;Lebenslauf
Cooke wurde 1784 in den Dienst der Infanteriegarden aufgenommen und acht Jahre sp�ter 
zum 
Hauptmann bef�rdert. Er k�mpfte in Flandern (1794) und Holland (1799), verbrachte jedoch 
den 
gr��ten Teil der napoleonischen Kriege damit, die Kolonialgarnisonen zu befehligen. Im Jahre 
1811 wurde er zum Generalmajor ernannt und �bernahm die Verantwortung f�r die 
Gardedivisionen. In der Schlacht bei Waterloo b��te er seinen rechten Arm im Kampf ein.
..................................................................
;Name
Graf Karl von Alten
;Erfahrung
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;3
;
Daten
1764-1840
;Pers�nlichkeit
;2
;
;Lebenslauf
Von Alten diente von 1783 bis 1803 in der hannoverschen Armee, bis er in den Dienst der 
Briten 
versetzt wurde. Er k�mpfte 1807 in Kopenhagen und mit der K�niglich-deutschen Legion im 
Krieg auf der Pyren�enhalbinsel. 1816 wurde er zum Generalmajor bef�rdert und erreichte 
sp�ter in der neu eingerichteten hannoverschen Armee den Rang des Feldmarschalls.
..................................................................
;Name
Baron David Henry Chasse
;Erfahrung
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;4
;
Daten
1765-1849
;Pers�nlichkeit
;3
;
;Lebenslauf
Nach dem Dienst in der holl�ndischen Armee wechselte Chasse 1792 zu den franz�sischen 
Truppen �ber. Bei seiner R�ckkehr ins von den Franzosen kontrollierte Holland wurde er 
1806 
zum Generalmajor bef�rdert. Er k�mpfte bei Talavera auf franz�sischer Seite und wurde 
1810 in 
den Rang des Brigadegenerals erhoben. Napoleon ehrte ihn, indem er ihn zum Baron machte, 
nachdem er sich in der Schlacht von Maya 1813 durch hervorragende Leistungen 
ausgezeichnet 
hatte. Im Jahr 1814 wurde Chasse verwundet und kehrte in das soeben wieder unabh�ngig 
gewordene Holland zur�ck, wo er wieder in die Armee eintrat und im Waterloo-Feldzug eine 
Division gegen die Franzosen befehligte. 1830 verteidigte er Antwerpen gegen die 
Revolution�re 
und hielt in der Zitadelle bis 1832 die Stellung. Nachdem er f�r kurze Zeit Gefangener 
gewesen 
war, wurde er von der holl�ndischen Armee wieder angenommen und zum Infanteriegeneral 
bef�rdert.
..................................................................
;Name
Sir Henry Clinton
;Erfahrung
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten
;3
;
Daten
1771-1829
;Pers�nlichkeit
;2
;--*--
;Lebenslauf
Als zweit�ltester Sohn des Oberbefehlshabers der britischen Truppen in Amerika wurde 
Henry 
Clinton im Alter von 16 Jahren w�hrend der dortigen Revolution eingezogen und diente in 
Holland. 
1795 wurde er zum Oberstleutnant bef�rdert, war dann jedoch von 1796-97 in 
franz�sischer 
Gefangenschaft. Er diente im Krieg auf der Pyren�enhalbinsel und befehligte die 6. Division 
bei 
Salamanca. 1813 wurde er zum Ritter geschlagen, und 1814 erlangte er den 
Generalleutnantsrang.
..................................................................
;Name
Sir Charles Colville
;Erfahrung
;4
;
Titel
Generalleutnant
;F�hrungsqualit�ten
;2
;
Daten
1770-1843
;Pers�nlichkeit
;3
;
;Lebenslauf
Colville trat im Alter von 18 Jahren in die Leichte Infanterie ein und zeichnete sich im 
Feldzug 
zur Verteidigung Hollands (1797-99) aus, der sich leider als vergeblich erwies. Nachdem er 
einige Zeit zu Hause verbracht hatte, wurde er zum Generalleutnant bef�rdert und 1808 auf 
die 
Pyren�enhalbinsel entsandt. Dort wurde er bei dem von ihm gef�hrten entscheidenden 
Angriff 
bei Bajadoz verwundet. Colville befehligte die britischen Truppen bei der Belagerung von 
Cambray und diente sp�ter als Gouverneur von Mauritius.
..................................................................
;Name
Sir Thomas Picton
;Erfahrung 
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;3
;
Daten
1758-1815
;Pers�nlichkeit
;4
;
;Lebenslauf
Picton war ein guter Soldat mit unersch�tterlichem Selbstvertrauen. Nach seinem Eintritt in 
die 
Armee im Alter von dreizehn Jahren wurde er nach Ausbruch der Revolutionskriege rasch 
bef�rdert und so 1794 zum Hauptmann und 1797 zum Gouverneur von Trinidad ernannt. 
Seine 
schonungslose Haltung bei der Wiederherstellung der Ordnung auf der gerade eroberten 
Insel 
hatte eine Anklage wegen der Folterung einer Frau zur Folge, nach seiner R�ckkehr nach 
England wurde er jedoch 1799 von der britischen Armee zum Brigadegeneral bef�rdert. Beim 
Sturm auf Bajadoz machte Picton den Vorschlag, einen Angriff �ber Leitern zu versuchen, 
und 
f�hrte diesen auch durch. Damit hatte er Erfolg, wo Wellingtons Hauptangriff fehlgeschlagen 
war. Bei Quatre Bras, wo seine 5. Veteranen-Division sich Neys Angriff widersetzte, wurde 
er 
von einer Musketenkugel getroffen, die zwei Rippen brach. Picton weigerte sich jedoch, das 
Schlachtfeld zu verlassen. Er setzte den Kampf am 17. und 18. fort und wurde bei Waterloo 
schlie�lich in den Kopf getroffen, w�hrend er den entscheidenden Angriff anf�hrte, der 
d'Erlons 
Korps von den H�hen des Mont St. Jean vertrieb. Picton war f�r seine eigenwillige Kleidung 
bekannt. Er zog es vor, anstatt der Armeeuniform zivile Kleidung zu tragen, und es wird 
berichtet, da� er in der Schlacht bei Busaco mit seiner Nachtm�tze auf dem Kopf in den 
Kampf 
ging.
..................................................................
;Name
Sir Galbraith Lowry Cole
;Erfahrung
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten
;3
;
Daten
1772-1842
;Pers�nlichkeit
;2
;
;Lebenslauf
Cole wurde 1787 eingezogen und diente auf den Westindischen Inseln, in Irland, �gypten 
und 
Sizilien. Zwischen 1803 und 1823 war er Mitglied des Parlaments von Fermanagh und 
wurde 
1813 zum Ritter geschlagen und zum Generalleutnant bef�rdert. Cole, der ein gro�er 
K�mpfer 
war, gab bei Albufera ohne Beresfords Zustimmung den Befehl f�r das ber�hmte Vorr�cken 
der 
Infanteriebrigade, was kurz vor der Niederlage das Blatt zugunsten der Briten wendete. 
Obgleich 
er seine taktischen F�higkeiten bei Salamanca, Vitoria und im Freisch�rlerkrieg in den 
Pyren�en 
unter Beweis stellte, wurde er nie mit einem unabh�ngigen Befehl betraut, bis er 1830 
schlie�lich 
zum General bef�rdert wurde.
..................................................................
;Name
Herzog Wilhelm Friedrich von Braunschweig
;Erfahrung
;3
;
Titel
General
;F�hrungsqualit�ten 
;3
;
Daten
1771-1815
;Pers�nlichkeit
;4
;
;Lebenslauf
Von Braunschweig war ein erbitterter Gegner Napoleons, welcher seine L�ndereien im 
Rahmen 
des Friedens von Tilsit mit Alexander I. 1806 konfisziert hatte. Er trug einen wichtigen Teil 
zur 
Gr�ndung der "Schwarzen Legion" bei, um 1809 im Dienst der �sterreicher zu k�mpfen. Mit 
der 
Niederlage �sterreichs marschierten die Braunschweiger durch Deutschland, um schlie�lich 
von 
einer britischen Flotte aufgenommen zu werden und unter der britischen Fahne zu k�mpfen. 
Im 
Jahre 1813 erhielt er sein Herzogtum zur�ck, wo er eine neue Armee aufstellte, um gegen 
die 
Franzosen anzutreten. Der Herzog fiel in der Schlacht von Quatre Bras an der Spitze seines 
Braunschweiger Korps. 
..................................................................
;Name
Arioff-Henri von Kruse
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1765-1819
;Pers�nlichkeit
;3
;
;Lebenslauf
Von Kruse diente von 1782 bis 1819 im Nassauer Truppenkontingent. In diesem Zeitraum 
k�mpfte er gegen die Franzosen, wurde Soldat in Napoleons Armee in Ru�land und k�mpfte 
w�hrend des Waterloo-Feldzugs auf seiten der Verb�ndeten. �ber seine fr�he Laufbahn ist 
nicht 
viel bekannt, sowohl vor als auch nach Waterloo diente er jedoch auf dem Wiener Kongre� 
als 
milit�rischer Berater des Nassauer Truppenkontingents.
..................................................................
;Name
Earl of Uxbridge
;Erfahrung
;4
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;4
;
Daten
1769-1854
;Pers�nlichkeit
;3
;
;Lebenslauf
Uxbridge, der in der Kavallerie ausgezeichnete Arbeit leistete, begann seine Laufbahn in der 
Infanterie. 1795 wechselte er zur Kavallerie �ber und machte sein Regiment, die 7. Leichte 
Dragonereinheit, schon nach kurzer Zeit zu einem der besten dienenden Regimenter. Im 
Jahre 
1808 k�mpfte er in Spanien. Nachdem er jedoch mit Wellingtons Schw�gerin durchgebrannt 
war, waren seine F�higkeiten nicht mehr sonderlich gefragt. In den darauffolgenden Jahren 
bet�tigte er sich als Parlamentsabgeordneter f�r Milbourne Port und, nachdem er 1812 
seinen 
Lordtitel �bernommen hatte, erhielt er einen Sitz im Oberhaus. Im Jahre 1815 wurde ihm der 
Befehl �ber die Kavallerie der Koalitionstruppen �bertragen. Bei Waterloo wurde er ins Bein 
getroffen, was eine Amputation zur Folge hatte. Als er sein zerschmettertes Bein erblickte, 
bemerkte er zu Wellington: "Mein Gott, Sir, ich habe mein Bein verloren!" Der Herzog, der 
ihm 
hilfreich zur Seite stand, blickte nach unten und sagte:" Mein Gott, Sir, das haben Sie!" In 
Anerkennung seiner Dienste wurde Uxbridge am 23. Juni 1815 in den Stand des Marquis 
von 
Anglesey erhoben. 
Mit einem k�nstlichen Bein versehen, diente er als Vizek�nig von Irland und wurde 1846 
zum 
Feldmarschall bef�rdert.
..................................................................
;Name
Baron Jean Alphonse de Collaert
;Erfahrung 
;4
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;2
;
Daten
1763-1830
;Pers�nlichkeit
;3
;
;Lebenslauf
De Collaert meldete sich im Alter von 16 Jahren bei den holl�ndischen Garden und 
verdankte 
dem Prinzen Friedrich, welcher sich w�hrend der Man�ver mit ihm angefreundet hatte, seine 
rasche Bef�rderung zum Hauptmann. Er wurde als diplomatischer Vertreter ausgesandt, um 
mit 
den Briten �ber die Verteidigung Hollands zu verhandeln (1799). Nachdem Holland jedoch 
von 
Napoleon erobert worden war, trat de Collaert in die franz�sische Armee ein. Seine 
Leistungen 
bei der Unterdr�ckung des holl�ndischen Nationalismus erwiesen sich als so wertvoll, da� 
Napoleon ihn zum Reichsbaron und Generalmajor in der franz�sischen Kavallerie ernannte. 
Als 
Holland 1814 endlich befreit war, stieg de Collaert in den Rang des leitenden 
Kavallerieoffiziers 
auf und behielt diese Stellung auch nach der Schlacht bei Waterloo. 
..................................................................
;Name
Wilhelm Karl Friedrich
;Erfahrung 
;3
;
Titel
Prinz der Niederlande
;F�hrungsqualit�ten 
;4
;
Daten
1797-1881
;Pers�nlichkeit
;3
;
;Lebenslauf
Als j�ngster Sohn K�nig Wilhelms I. k�mpfte Wilhelm Karl Friedrich im Feldzug 1813 auf der 
Seite der Verb�ndeten und bewies in der F�hrung seines undisziplinierten und ungen�gend 
ausgebildeten Korps bei Waterloo gro�e Besonnenheit. Im Jahre 1830 gelang es ihm nicht, 
einen Aufstand in Br�ssel zu unterdr�cken, woraufhin er sich aus dem �ffentlichen Leben 
zur�ckzog. Nach 51 Jahren in v�lliger Zur�ckgezogenheit starb er in Den Haag. 
..................................................................
;Name
Donald McKenzie
;Erfahrung
;
;
Titel
Generalmajor
;F�hrungsqualit�ten
;
;
Daten
1786-1853
;Pers�nlichkeit
;
;
;Lebenslauf
McKenzie wurde 1806 eingezogen und 1807 zum Leutnant des 42. Infanterieregiments 
ernannt. 
Den gr��ten Teil seiner Karriere verbrachte McKenzie in seiner T�tigkeit als Berater und als 
Organisator der zuhause stationierten Reserveeinheiten. Er nahm jedoch auch zeitweise am 
Krieg auf der Pyren�enhalbinsel teil und k�mpfte im Jahre 1812 bei Salamanca unter 
Wellington. Zu Beginn des Waterloo-Feldzuges wurde er zum Generalmajor bef�rdert. 
McKenzie 
verfolgte seine milit�rische Laufbahn bis 1832. Da ihm der Sprung in die politische Laufbahn 
verwehrt blieb, ging er stattdessen in den Ruhestand. 
..................................................................
;Name
James Carmichael Smyth
;Erfahrung
;3
;
Titel
Oberstleutnant
;F�hrungsqualit�ten 
;2
;
Daten
1780-1838
;Pers�nlichkeit
;2
;
;Lebenslauf
Wellington hatte es Smyths Karte des Schlachtfeldes zu verdanken, da� er am 18. Juni 
seine 
Truppen so schnell und vorteilhaft plazieren konnte. Smyth wurde sp�ter zum Gouverneur 
von 
Britisch Guyana ernannt, wo er im Jahre 1838 starb.
..................................................................
;Name
Lord Edward Somerset
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1776-1842
;Pers�nlichkeit
;2
;
;Lebenslauf
Lord Somerset, zweit�ltester Sohn des Herzogs von Beufort, trat 1799 in den Dienst der 
holl�ndischen Kavallerie. Nach seinem Amtsantritt 1802 befehligte er die 4. Leichte 
Dragonereinheit f�r nahezu 40 Jahre. W�hrend dieser Zeit k�mpfte er unter anderem im 
Krieg 
auf der Pyren�enhalbinsel und bei Waterloo. Er besa� die Befehlsgewalt �ber die gesamte 
britische Kavallerie, die 1815 Frankreich besetzte, und wurde schlie�lich im Jahre 1841 in 
den 
Rang des Generals erhoben. 
..................................................................
;Name
Hon. Sir William Ponsonby
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1772-1815
;Pers�nlichkeit
;4
;
;Lebenslauf
Ponsonby erhielt im Jahre 1803 den Befehl �ber die 5. Dragonergarde und diente von 1811-
14 in 
Spanien. Bei Vitoria befehligte er eine Kavalleriebrigade und wurde 1815 kurz vor dem 100-
Tage-Feldzug zum Ritter geschlagen. Bei Waterloo f�hrte Ponsonby den Angriff, der d'Erlons 
Korps zerschmetterte, drang jedoch zu weit vor und wurde get�tet, als sein Pferd im 
Schlamm 
steckenblieb. 
..................................................................
;Name
Sir William B. Dornberg
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1775-1822
;Pers�nlichkeit
;1
;
;Lebenslauf
Dornberg wurde in Hannover geboren. Da sein Vater jedoch in die Dienste von Georg III. von 
England trat, wuchs er in enger Verbindung mit dem k�niglichen Hof auf. Er trat 1799 als 
Hauptmann in die 3. Kavalleriebrigade ein und diente dort bis zu seinem fr�hen, durch einen 
Reitunfall verursachten Tod im Jahre 1822.
..................................................................
;Name
Sir John Vandaleur
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1763-1849
;Pers�nlichkeit
;2
;
;Lebenslauf
Vandaleur diente in Indien unter Lord Lake und befehligte w�hrend des Krieges auf der 
Pyren�enhalbinsel eine Kavalleriebrigade. Im Jahre 1830 wurde er zum General und 
Regimentschef der 16. Leichten Dragonereinheit ernannt.
..................................................................
;Name
Sir Colquhoun Grant
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1764-1835
;Pers�nlichkeit
;3
;
;Lebenslauf
Grants �u�erst abwechslungsreiche milit�rische Laufbahn bestand unter anderem in einer 
Expedition zum Kap der Guten Hoffnung, wo er verwundet wurde, aber nichtsdestotrotz 
weiterk�mpfte. Diese Tat wurde in Depeschen lobenswert erw�hnt. 1799 k�mpfte er bei 
Seringapatam in Indien. Nachdem er 1808 zum Oberstleutnant bef�rdert worden war, zeigte 
er 
im Krieg auf der Pyren�enhalbinsel ausgezeichnete Leistungen und gewann die Zuneigung 
seiner Truppen. Als er in der Schlacht bei Waterloo eine Husarenbrigade befehligte, wurden 
f�nf 
Pferde unter ihm get�tet, Grant selbst blieb jedoch unverletzt.
..................................................................
;Name
Sir Hussey Vivian
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1775-1842
;Pers�nlichkeit
;2
;
;Lebenslauf
Vivian kam w�hrend der Revolutionskriege als F�hnrich in die Armee und diente in den 
Jahren 
1795 und 1799 in Holland. W�hrend des britischen R�ckzugs von Coru�a 1808 wurde er 
verwundet. Weitere Verwundungen erlitt er w�hrend der Invasion in Frankreich 1813 und 
w�hrend eines tapferen Angriffs auf Toulouse. Seine Kavalleriebrigade antwortete mit den 
begeisterten Worten: "Egal wohin, wir folgen unserem General", als er seinen Leuten den 
Befehl 
gab, sich bei Waterloo in eine ungesch�tzte Stellung zu begeben.
..................................................................
;Name
Sir Frederick Arenschildt
;Erfahrung
;3
;
Titel
Oberst
;F�hrungsqualit�ten 
;3
;
Daten
1778-1834
;Pers�nlichkeit
;5
;
;Lebenslauf
Arenschildt hatte einen dramatischen Auftritt, als er seinen verwundeten Kommandeur, Sir 
James Robertson, von einer ungesch�tzten Stellung unterhalb der Mauern von Mons (1794) 
zur 
7. Kavalleriebrigade zur�cktrug. Er war nicht nur f�r seine Tapferkeit, sondern bald auch f�r 
seinen Leichtsinn ber�hmt und wurde f�r einen unerlaubten Angriff w�hrend des Krieges auf 
der 
Pyren�enhalbinsel schwer gema�regelt. 1812 wurde er zum Oberst bef�rdert und zeichnete 
sich 
bei Waterloo durch besondere Leistungen aus, wurde jedoch sp�ter aufgrund von frechem 
Verhalten
gegen�ber einem vorgesetzten Offizier vom Dienst suspendiert. 
................................................................
;Name
Baron Friedrich Estorff
;Erfahrung
;3
;
Titel
Oberst
;F�hrungsqualit�ten 
;2
;
Daten
1773-1837
;Pers�nlichkeit
;3
;
;Lebenslauf
Estorff begann seinen Dienst in der hannoverschen Armee in den 1790ern und verteidigte 
das 
Heilige R�mische Reich Deutscher Nation gegen die franz�sische revolution�re Armee. 
W�hrend des Krieges auf der Pyren�enhalbinsel trat er in die K�niglich-deutsche Legion ein 
und 
wurde an der Schulter verwundet. Im Jahre 1813 kehrte er als Oberst der hannoverschen 
Armee 
wieder in den aktiven Dienst zur�ck. Zu diesem Zeitpunkt war die hannoversche Armee 
schon 
Teil der britischen Kommandostruktur f�r den vereinten Kampf gegen Napoleon. Nach der 
Schlacht bei Waterloo gewann die hannoversche Armee wieder mehr Unabh�ngigkeit, und 
Estorff wurde vor seinem Tod im Jahr 1837 zum Generalleutnant bef�rdert.
..................................................................
;Name
Anders Detmund Trip
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1770-1826
;Pers�nlichkeit
;2
;
;Lebenslauf
Aufgrund von Trips Kraft und seinem Geschick im Umgang mit gro�en Pferden eignete er 
sich 
hervorragend f�r die Position als Offizier der Schweren Brigade. Zun�chst k�mpfte er im 
Feldzug gegen die franz�sische revolution�re Armee, sp�ter diente er jedoch unter Napoleon 
bei 
der Invasion in Norddeutschland im Jahre 1810. Vor dem Waterloo-Feldzug wurde er zum 
Generalmajor der Kavallerie bef�rdert und stieg weiter bis in den Rang des Generalleutnants 
auf. Wellington nannte ihn einen "zuverl�ssigen und h�chst leistungsstarken Offizier". Dies 
war 
einer der wenigen lobenden Kommentare, die der Herzog �ber die holl�ndische Armee 
verlauten 
lie�. 
..................................................................
;Name
Baron Philippe de Ghigny
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1775-1831
;Pers�nlichkeit
;2
;
;Lebenslauf
�ber de Ghignys fr�he Laufbahn k�nnen nur Vermutungen angestellt werden, aber sicher 
ist, 
da� er schon 1804 als Brigadegeneral in Napoleons Armee erscheint. Er k�mpfte im Krieg 
auf 
der Pyren�enhalbinsel, geriet in Gefangenschaft und kehrte nie wieder nach Frankreich 
zur�ck. 
Stattdessen half er bei der Aufstellung eines belgischen Truppenkontingents, als die 
Verb�ndeten Napoleon im Jahre 1814 aus Belgien vertrieben. Nach Waterloo blieb er auch 
weiterhin in der belgischen Armee, bis er w�hrend der franz�sischen Invasion in Belgien 
1830 
schwer verwundet wurde und seinen Verletzungen im darauffolgenden Jahr erlag. 
..................................................................
;Name
Jan Brucke van Merlen
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1770-1843
;Pers�nlichkeit
;3
;
;Lebenslauf
Bis zur franz�sischen Invasion im Jahre 1800 verdiente van Merlen sich seinen 
Lebensunterhalt 
in Br�gge als Gesch�ftsmann. Danach diente er in der belgischen Miliz und meldete sich 
schlie�lich 1804 zum Dienst in der Kavallerie. 
Er k�mpfte im Krieg auf der Pyren�enhalbinsel, verbrachte jedoch den Gro�teil der Zeit mit 
der 
Verteidigung der belgischen K�ste, die er schlie�lich im Jahre 1814 an die vorr�ckende 
Koalition 
abtrat. Das belgische Volk verabscheute Napoleon, der seine Unabh�ngigkeit beschnitten 
und 
ihm hohe Steuern auferlegt hatte. Van Merlen k�mpfte bei Waterloo und in einer weiteren 
Schlacht im Jahre 1830 gegen die Franzosen. 
..................................................................
;Preu�ische Gener�le
;Name
Gebhard Leberecht von Bl�cher
;Erfahrung
;5
;
Titel
F�rst von Wahlstatt
Feldmarschall
;F�hrungsqualit�ten
;4
;
Daten
1742-1819
;Pers�nlichkeit
;4
;
;Lebenslauf
Von Bl�cher diente zun�chst in der schwedischen Armee, geriet jedoch 1760 in preu�ische 
Gefangenschaft und wurde zum Husarenoffizier gemacht. Er trat aus der Armee aus und 
widmete sich f�nfzehn Jahre lang der Landwirtschaft, nachdem seine direkt an Friedrich den 
Gro�en gerichtete Bitte um Bef�rderung von diesem mit den Worten "Hauptmann Bl�cher 
soll 
sich zum Teufel scheren" beantwortet wurde. Er stieg erst zu einem sp�ten Zeitpunkt seiner 
Karriere auf, nachdem er gegen die revolution�ren Franzosen mit Auszeichnung gek�mpft 
hatte. 
Bei Ratkau k�mpfte er im Jahre 1806 auch nach dem Zusammenbruch der preu�ischen 
Truppen 
weiter, bis ihm die Munition ausging. Er half beim Wiederaufbau der preu�ischen Armee, 
galt als 
erbitterter Feind Napoleons und lehnte selbst kurzzeitige �bereink�nfte ab. Im 
"Befreiungskrieg" 
von 1813 befehligte er die schlesische Armee, die starken Druck auf Napoleon aus�bte, und 
nutzte seinen Vorteil aus, als er bei Leipzig schlie�lich Napoleons Truppen spaltete. In der 
Schlacht von Ligny wurde von Bl�cher unter seinem toten Pferd begraben. Daher ging der 
Oberbefehl f�r kurze Zeit auf Gneisenau �ber, der die defensive Neuorganisation im Gebiet 
von 
Wavre bef�rwortete. Nachdem von Bl�cher der drohenden Gefangenschaft durch die 
Franzosen 
um Haaresbreite entkommen war, st�rzte er die Entscheidung Gneisenaus und marschierte 
zu 
Wellingtons Unterst�tzung nach Waterloo. Er leitete die Verfolgung der Franzosen bis Paris, 
bevor er sich erneut auf seinen Bauernhof zur�ckzog. Von Bl�cher starb am 12. September 
1819 auf seinen schlesischen L�ndereien. 
.................................................................. 
;Name
Hans Ernst Ziethen
;Erfahrung
;4
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;3
;
Daten
1770-1848
;Pers�nlichkeit
;2
;
;Lebenslauf
Von 1806 an diente er in den preu�ischen Dragonereinheiten der K�nigin. 1813 f�hrte er 
den 
Befehl �ber eine Brigade unter General Kleist und zeichnete sich bei Leipzig durch 
hervorragende Leistungen aus. Im Jahre 1815 wurde er zum Generalleutnant bef�rdert und 
spielte 1815 bei Ligny und Waterloo eine entscheidende Rolle. Nach der Schlacht bei 
Waterloo 
wurde er zum Kommandeur der preu�ischen Besatzungsarmee in Frankreich. Nachdem er 
1835 
in den Rang eines Feldmarschalls aufgestiegen war, kam er 1848 in den Wirren der 
Revolution 
um. 
..................................................................
;Name
Georg Dubislav Ludwig von Pirch (I)
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1763-1838
;Pers�nlichkeit
;2
;
;Lebenslauf
Der aus Magdeburg stammende von Pirch begann seine fr�he Laufbahn in der preu�ischen 
Armee im Jahre 1775. Kurz vor dem Waterloo-Feldzug wurde er zum Kommandeur des 2. 
Korps 
bef�rdert und ersetzte General Borstell, der gegen die schwere Bestrafung seiner 
aufst�ndischen 
s�chsischen Truppen Einspruch eingelegt hatte. Sein Korps marschierte von Namur nach 
Sombreffe, um Ziethen zu unterst�tzen, und spielte in der Schlacht von Ligny eine 
entscheidende Rolle. Am 18. Juni folgte er B�lows Korps aus Wavre durch den Bois de 
Paris, 
um bei Waterloo Napoleons rechte Flanke anzugreifen und erreichte die Gegend um 
Plancenoit 
gegen 6 Uhr abends. Im Jahr 1816 zog er sich aus der preu�ischen Armee zur�ck. 
..................................................................
;Name
Johann Adolf Freiherr von Thielemann
;Erfahrung
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten 
;3
;
Daten
1765-1824
;Pers�nlichkeit
;2
;
;Lebenslauf
Der in Dresden geborene von Thielemann trat 1780 in die s�chsische Armee ein und 
k�mpfte 
w�hrend der Revolutionskriege als Husar. Nach der Schlacht bei Jena verb�ndete sich auch 
Sachsen gezwungenerma�en mit Napoleon. Von Thielemanns erste bedeutende Schlachten 
gegen die Russen fanden im Feldzug von 1812 statt. Bei Borodino f�hrte er einen 
Kavallerieangriff, der beinahe die Entschlossenheit der Russen gebrochen und die blutige 
Pattsituation mit einer Entscheidung zu seinen Gunsten beendet h�tte. Als Napoleon ihn 
1813 zu 
sich befahl, lief er zu den Russen �ber und k�mpfte bei Lutzen und Leipzig. Im Jahr 1815 
ging er 
mit dem Rang des Generalleutnants zur preu�ischen Armee und f�hrte den Befehl �ber das 
3. 
Korps, das bei Ligny �bel zugerichtet wurde. Daraufhin zog er sich nach Wavre zur�ck, wo 
es 
ihm gelang, Grouchys Angriffe abzuwehren. Dies erm�glichte es dem Rest der preu�ischen 
Armee, sich Wellington bei Waterloo anzuschlie�en. Von Thielemann starb im Jahr 1824.
..................................................................
;Name
Friedrich Wilhelm Graf B�low von Dennewitz
;Erfahrung
;4
;
Titel
General der Infanterie
;F�hrungsqualit�ten 
;3
;
Daten
1755-1816
;Pers�nlichkeit
;2
;
;Lebenslauf
B�low trat 1768 in die preu�ische Armee ein und war 1797 Kommandeur eines der 
Elitebataillone der Infanterie. Er nahm an der Schlacht bei Jena nicht teil, wurde aber im 
Feldzug 
von 1807 verwundet. Nachdem er f�r den Sieg �ber Oudinot bei Gro�beeren das Eiserne 
Kreuz 
1. Klasse und f�r den Sieg �ber Ney bei Dennewitz den Orden "Pour le M�rite" empfangen 
hatte, 
wurde er 1814 zum General bef�rdert. Aufgrund seines versp�teten Erscheinens konnte er 
an 
der Schlacht von Ligny 1815 nicht mehr teilnehmen, sein Korps spielte jedoch in der 
Schlacht 
bei Waterloo in den K�mpfen um Plancenoit eine entscheidende Rolle.
..................................................................
;Name
Karl Friedrich Franziskus von Steinmetz
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1768-1837
;Pers�nlichkeit
;2
;
;Lebenslauf
Von Steinmetz' Vater starb als Kommandeur eines Freikorps im Dienste Friedrichs des 
Gro�en, 
woraufhin seine vier S�hne in das Kadettenkorps eintraten. Von Steinmetz wurde 1786 in 
die 
k�nigliche Garde versetzt und durchlief eine erfolgreiche Laufbahn. Nach seiner Teilnahme an 
der Verteidigung von Kolberg 1807 wurde ihm der Befehl �ber das 1. Bataillon des Elite-
Berufsregiments �bertragen. Im Jahre 1812 k�mpfte er in Ru�land und 1813 bei Lutzen, 
Bautzen, Gro�beeren, Dennewitz und Leipzig, woraufhin er zum Generalmajor bef�rdert 
wurde. 
Bei Ligny erlitt seine Brigade schwere Verluste, marschierte aber dennoch zwei Tage sp�ter 
nach Waterloo, wo sie in der Schlacht eine bedeutende Rolle spielte. F�r seine Leistungen 
bei 
Waterloo wurde von Steinmetz mit dem Orden "Pour le M�rite" ausgezeichnet. Er starb 
1837 in 
Potsdam, wo er auch seine letzte Ruhe fand. 
..................................................................
;Name
Otto Karl Lorenz von Pirch (II)
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1765-1824
;Pers�nlichkeit
;3
;
;Lebenslauf
Der j�ngere Bruder von Pirchs (I) ging 1775 zur preu�ischen Armee. Als Mitglied im Stab 
des 
Herzogs von Braunschweig k�mpfte er 1806 bei Auerstedt. Da die k�nigliche Familie ihm 
wohlgesonnen war, stieg er in den Reihen der Armee auf und wurde 1813 zum 
Generalmajor 
bef�rdert. Im selben Jahr k�mpfte er bei Lutzen, Bautzen, am Katzbach (ausgezeichnet mit 
dem 
Eisernen Kreuz 2. Klasse) und bei Leipzig (Eisernes Kreuz 1. Klasse). Seine Brigade, die 
1815 
Ziethens Korps zugeteilt war, gl�nzte bei Ligny und Waterloo mit hervorragenden Leistungen 
und beschlagnahmte w�hrend der Verfolgung 14 franz�sische Kanonen. Nach der Schlacht 
bei 
Waterloo zog er sich aus der Armee zur�ck und starb 1824 in Berlin.
..................................................................
;Name
Friedrich Wilhelm Christian Ludwig von Jagow
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;4
;
Daten
1771-1857
;Pers�nlichkeit
;1
;
;Lebenslauf
Von Jagow meldete sich 1785 zum Dienst in der preu�ischen Armee, k�mpfte 1806 bei 
Auerstedt und geriet bei der Kapitulation von Prenzlau in Gefangenschaft. Nachdem er 1807 
in 
den Rang eines Majors aufgestiegen war, befehligte er ein Bataillon der k�niglichen Garde. 
Im 
M�rz 1813 wurde ihm der Befehl �ber eine Infanteriebrigade �bertragen, woraufhin er in 
Lutzen 
(verwundet), Bautzen, Dresden, Kulm und Leipzig (Eisernes Kreuz 1. Klasse) k�mpfte. Nach 
der 
Schlacht bei Waterloo setzte von Jagow seine milit�rische Laufbahn f�r weitere zwanzig 
Jahre 
fort und ging 1836 in den Ruhestand. Er starb 1857 in Berlin. 
..................................................................
;Name
August von Schutter
;Erfahrung 
;2
;
Titel
Oberst
;F�hrungsqualit�ten 
;4
;
Daten
1770-1850
;Pers�nlichkeit
;5
;
;Lebenslauf
Von Schutter trat 1789 dem Teutonenorden, einer milit�rischen Bruderschaft aus dem 
Mittelalter, 
bei. Seine eigentliche milit�rische Laufbahn begann jedoch erst nach der vernichtenden 
Niederlage der Preu�en durch Napoleon 1806. Seine Energie und Zuversicht bahnten ihm 
den 
Weg nach oben. Nach den Reformen unter Stein wurde er in der Armee zum Oberst 
bef�rdert. 
Seine Brigade spielte sowohl bei Leipzig (1812) als auch bei Dresden (1813) eine 
bedeutende 
Rolle, wo seine M�nner beinahe seiner wilden Entschlossenheit zum Opfer fielen, den 
fliehenden 
Feind wegen des lockenden Ruhmes zu verfolgen. Nach Waterloo baute von Schutter seine 
milit�rische Laufbahn weiter aus und stieg trotz seiner betr�chtlichen M�ngel in der 
taktischen 
F�hrung in den Rang eines Generalleutnants auf.
..................................................................
;Name
Friedrich Erhard Leopold von Roeder
;Erfahrung
;3
;
Titel
Generalleutnant 
;F�hrungsqualit�ten 
;3
;
Daten
1776-1846
;Pers�nlichkeit
;2
;
;Lebenslauf
Von Roeder, Patenkind von Friedrich dem Gro�en, schlo� sich dem K�rassierregiment seines 
Vaters im Jahre 1781 als F�hnrich an. Als Adjutant des Prinzen von Hohenlohe k�mpfte er 
1806 
bei Jena und marschierte 1812 als Offizier in Grawerts Stab nach Ru�land, um bei Eckau zu 
k�mpfen. F�r seine Teilnahme an diesem Feldzug wurde er nicht nur mit dem Orden "Pour le 
M�rite" sondern auch mit der franz�sischen Ehrenlegion ausgezeichnet. Als Kommandeur 
einer 
Brigade k�mpfte er bei Lutzen, Bautzen, Dresden, Kulm und 1813 bei Leipzig. Nach der 
Schlacht bei Waterloo hatte er verschiedene h�here Stellungen in der preu�ischen Armee 
inne, 
bis er 1832 in den Ruhestand ging. Er starb zwei Jahre sp�ter.
..................................................................
;Name
Karl Alexander Wilhelm von Treskow
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;3
;
Daten
1764-1823
;Pers�nlichkeit
;4
;
;Lebenslauf
Von Treskow schrieb sich im Jahre 1778 f�r den Dienst in den preu�ischen 
Dragonereinheiten 
ein. 1811 wurde er zum Kommandeur der 2. westpreu�ischen Dragonereinheit ernannt und 
nahm am Ru�landfeldzug von 1812 teil. 1813 k�mpfte er bei Gro�beeren und Dennewitz. 
Kurz 
nach der Schlacht bei Waterloo zog er sich aus der Armee zur�ck und starb 1823 in Berlin.
..................................................................
;Name
Karl Friedrich von Holtzendorff
;Erfahrung
;4
;
Titel
Generalmajor 
;F�hrungsqualit�ten
;2
;
Daten
1770-1828
;Pers�nlichkeit
;4
;
;Lebenslauf
Von Holtzendorff, Sohn eines der Gener�le von Friedrich dem Gro�en, trat 1778 in die 
preu�ische Artillerie ein und entwickelte sich zu einem einfallsreichen und erfolgreichen 
Offizier. 
1813 k�mpfte er bei Gro�beeren (Eisernes Kreuz 1. Klasse), Dennewitz und Leipzig 
(schwedischer Kronenorden 3. Klasse). Aufgrund seiner Verwundung in Ligny nahm er an 
der 
Schlacht bei Waterloo nicht teil. Nach Waterloo wurde er zum in ganz Europa gefeierten 
Artillerieexperten und besch�ftigte sich bis zu seinem Tod 1828 mit der Ausbildung der 
preu�ischen Armee.
..................................................................
;Name
Ernst Ludwig von Tippelskirch
;Erfahrung 
;3
;
Titel
Oberst
;F�hrungsqualit�ten 
;2
;
Daten
1774-1840
;Pers�nlichkeit
;1
;
;Lebenslauf
Von Tippelskirch ging 1785 als Kadett zur preu�ischen Armee. Als Veteran der 
Revolutionskriege k�mpfte er 1806 bei Jena. Im Jahre 1807 k�mpfte er mit Scharnhorst bei 
Eylau und wurde 1811 zum Kommandeur des Berufsregiments ernannt. Bei seiner R�ckkehr 
aus 
Ru�land gegen Ende des Jahres 1812 erhielt er das Kommando �ber die Infanteriegarden. 
Als 
Kommandeur einer Brigade k�mpfte er in den Feldz�gen von 1813 und wurde f�r seinen 
Einsatz 
bei Lutzen mit dem Eisernen Kreuz 2. Klasse ausgezeichnet. Nach Waterloo wurde er 
Inspekteur 
der Reserveeinheiten. Er starb 1840 in Berlin.
..................................................................
;Name
Karl August Adolf von Krafft
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;4
;
Daten
1764-1840
;Pers�nlichkeit
;2
;
;Lebenslauf
Von Krafft trat 1778 in die Armee ein. Seine Feuertaufe erlebte er 1794 in Polen. Nach 
seiner 
Verwundung bei Auerstedt im Jahre 1806 wurde er zum Kommandeur des (Leichten) 
F�silierbataillons im Elite-Berufsregiment ernannt. Als Kommandeur einer Brigade k�mpfte 
von 
Krafft in den Schlachten von Gro�beeren, Dennewitz und Leipzig. Im Jahre 1832 zog er sich 
aus 
dem Vollzeitdienst in der Armee zur�ck. Er starb 1840 in K�nigsberg.
..................................................................
;Name
Friedrich August Wilhelm von Brause
;Erfahrung
;4
;
Titel 
Generalmajor
;F�hrungsqualit�ten 
;2
;
Daten
1769-1836
;Pers�nlichkeit
;3
;
;Lebenslauf
Von Brause, ein begabter Soldat, meldete sich 1781 zum Dienst in der s�chsischen Armee 
und 
stieg allm�hlich durch die verschiedenen R�nge auf, bis er im November 1813 zum 
Generalmajor bef�rdert wurde. Er k�mpfte 1806 als Verb�ndeter der Preu�en bei Jena, 
1812 in 
Ru�land auf der Seite der Franzosen und 1813 bei Bautzen, Gro�beeren, Dennewitz und 
Leipzig 
gegen die Preu�en. Bei Leipzig schlugen sich die Sachsen auf die andere Seite, woraufhin 
von 
Brause in die preu�ische Armee eintrat und in den Feldz�gen von 1814 und 1815 als 
preu�ischer General k�mpfte.
..................................................................
;Name
Karl August Joseph Friedrich von B�se
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten 
;4
;
Daten
1763-1826
;Pers�nlichkeit
;2
;
;Lebenslauf
Der in Th�ringen geborene von B�se trat 1774 als Kadett in die s�chsische Armee ein und 
wurde 
sieben Jahre darauf zum Leutnant in den Berufsgrenadiergarden ernannt. Im Jahre 1809 
ging er 
bei Wagram gegen die �sterreicher in die Schlacht und befehligte 1813 eine s�chsische 
Brigade, mit der er bis vor Leipzig gegen die Preu�en k�mpfte. 1815 ging er als 
Generalmajor in 
die preu�ische Armee, zog sich 1825 in den Ruhestand zur�ck und starb im darauffolgenden 
Jahr.
..................................................................
;Name
Alexander Georg Ludwig Moritz Konstantin Maximilian von Wahlen-Jurgass
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1758-1833
;Pers�nlichkeit
;4
;
;Lebenslauf
Der volle Name von Wahlen-Jurgass laute Alexander Georg Ludwig Moritz Konstantin 
Maximilian von Wahlen-Jurgass. Nachdem er von 1772 bis 1775 die Milit�rschule besucht 
hatte, trat von Wahlen-Jurgass 1775 als F�hnrich in das Elite-Regiment der Gendarme ein. 
Nach seiner Verwundung bei Auerstedt im Jahre 1806 geriet er bei Anklam in franz�sische 
Gefangenschaft. Nach seiner Ernennung zum Kommandeur der brandenburgischen Dragoner 
(1809) machte er sich mit einem Teil seines Regiments 1812 nach Ru�land auf, wo er sich 
den Orden "Pour le M�rite" verdiente. 1813 wurde er zum Kommandeur einer 
Kavalleriebrigade ernannt und k�mpfte mit dem Schwert in der Hand bei Lutzen (verwundet, 
Eisernes Kreuz 2. Klasse), Hanau (Eisernes Kreuz 1. Klasse), Katzbach und Leipzig. 1815 
wurde er bei Ligny erneut verwundet. Er ging 1816 in den Ruhestand.
..................................................................
;Name
Ernst Andreas von Roehl
;Erfahrung 
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;1
;
Daten
1761-1830
;Pers�nlichkeit
;4
;
;Lebenslauf
Der aus einfachen Verh�ltnissen stammende von Roehl meldete sich 1777 als einfacher 
Kanonier zum Dienst in der preu�ischen Artillerie. Aufgrund seiner Begabung arbeitete er 
sich 
ziemlich rasch nach oben und wurde im Feldzug von 1792 in Frankreich zum Adjutanten des 
Generals M�ller. Seinen erfolgreichsten Feldzug erlebte er 1813; er verdiente sich bei Vehlitz 
das Eiserne Kreuz 2. Klasse, wurde in den Depeschen f�r seine Rolle bei Gro�beeren und 
Dennewitz lobend erw�hnt und mit dem Eisernen Kreuz 1. Klasse ausgezeichnet. F�r seine 
Leistungen bei Leipzig erhielt er den russischen Stanislav-Orden 2. Klasse. Nach der 
Schlacht 
bei Waterloo hatte er in der preu�ischen Armee eine h�here Stellung inne und wurde 
weiterhin 
mit Auszeichnungen �berh�uft. Er starb im Jahre 1830 in Breslau. Von Roehls Karriere "vom 
Bettler zum Million�r" zeigt ganz deutlich die grunds�tzliche soziale Unbeweglichkeit der 
preu�ischen Armee.
..................................................................
;Name
Karl August Ferdinand von Borcke
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1776-1830
;Pers�nlichkeit
;3
;
;Lebenslauf
Von Borcke ging 1789 als Kadett zur preu�ischen Armee. Aufgrund seiner einzigartigen 
mathematischen Begabung verbrachte er einige Zeit als Lehrer an der Milit�rakademie. Nach 
seiner Ernennung zum Kommandeur des brandenburgischen Infanterieregiments im Juli 1813 
nahm er am Herbstfeldzug teil. Er wurde bei Leipzig verwundet, wo er sich das Eiserne 
Kreuz 1. 
Klasse, den schwedischen Schwert-Orden und den russischen Vladimir-Orden 3. Klasse 
verdiente. Er setzte seine milit�rische Laufbahn bis zu seinem Tod im Jahre 1830 fort.
..................................................................
;Name
Johann Wilhelm von Krauseneck
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten
;2
;
Daten
1774-1850
;Pers�nlichkeit
;1
;
;Lebenslauf
Von Krauseneck begann seine milit�rische Laufbahn 1791 als Kadett im �rtlichen 
Artillerietruppenkontingent in Ansbach. 1792 ging er zu den preu�ischen Ingenieuren und 
k�mpfte 1807 bei Heilsberg (Orden "Pour le M�rite") und Eylau, bis er zum Kommandeur 
des 
F�silierbataillons der Infanteriegarden ernannt wurde. Nachdem er 1813 in Bl�chers Stab 
eingetreten war, k�mpfte er bei Lutzen (verwundet, Eisernes Kreuz 2. Klasse, russischer 
Stanislav-Orden 2. Klasse) und Bautzen. 1838 wurde er zum General bef�rdert. Zehn Jahre 
darauf zog er sich aus der Armee zur�ck und starb im Jahre 1850 in Berlin. 
..................................................................
;Name
Hans Philipp August von Luck und Witten
;Erfahrung
;3
;
Titel
Oberst
;F�hrungsqualit�ten 
;3
;
Daten
1775-1859
;Pers�nlichkeit
;2
;
;Lebenslauf
Von Luck und Witten trat 1785 als Kadett in die preu�ische Armee ein und erlebte in den 
Revolutionskriegen zum erstenmal die Realit�t des Krieges. 1806 k�mpfte er bei Saalfeld und 
Jena und zog sich nach diesen Niederlagen nach Danzig zur�ck. Als Gouverneur des 
preu�ischen Kronprinzen wurde er erst dem Stab Bl�chers und sp�ter in den Feldz�gen von 
1813 dem Stab Kleists zugeteilt. Bei der Schlacht von Waterloo besa� er selbst schon 
Befehlsgewalt und verfolgte danach eine �u�erst erfolgreiche Laufbahn in der Armee. 1848 
zog 
er sich aus dem Dienst zur�ck und starb 1859 in Potsdam. 
..................................................................
;Name
Wolf Wilhelm Ferdinand von St�lpnagel
;Erfahrung
;3
;
Titel
Oberst
;F�hrungsqualit�ten
;4
;
Daten
1781-1839
;Pers�nlichkeit
;3
;
;Lebenslauf
Von St�lpnagel stammte aus einer der ber�hmtesten preu�ischen Familien, deren S�hne 
schon 
seit Generationen in der Armee dienten. Dieser besondere Spr��ling des preu�ischen Adels 
trat 
1790 als Kadett in die Armee ein. Im Jahre 1806 geriet er nach Bl�chers Kapitulation bei 
Ratkau 
in franz�sische Gefangenschaft. Bei seiner R�ckkehr nach Hause (1808) ging er f�r eine 
Weile 
zum Berufsregiment, bis ihm der Sold zur H�lfte gek�rzt wurde. 1812 trat er in die russische 
Armee ein und wurde Offizier in der russisch-deutschen Legion. Nachdem er 1815 in den 
Dienst 
unter den Preu�en zur�ckgekehrt war, k�mpfte er bei Ligny und Wavre. Er setzte seine 
milit�rische Laufbahn bis zu seinem Tod im Jahre 1839 fort. 
..................................................................
;Name
Karl Friedrich Bernhard Helmuth von Hobe
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;4
;
Daten
1765-1822
;Pers�nlichkeit
;3
;
;Lebenslauf
Von Hobe trat im Jahre 1778 als Kadett in Bl�chers altes Husarenregiment ein. Bis 1805 
stieg er 
zum Major auf, k�mpfte 1806 bei Jena und erhielt 1808 seine eigene Schwadron. In den 
Feldz�gen von 1813 k�mpfte er in den meisten der bedeutenderen Schlachten. In 
Anerkennung 
seiner Leistungen auf dem Schlachtfeld wurde er 1814 zum Generalmajor bef�rdert und 
erhielt 
den Orden "Pour le M�rite". F�r seine Leistung in der Schlacht von Waterloo wurde er mit 
dem 
Rotadlerorden 3. Klasse ausgezeichnet. Seine milit�rische Laufbahn verlief bis zu seinem Tod 
im Jahre 1822 weiterhin erfolgreich.
..................................................................
;Name
Eberhard Franz Ernst Friedrich von Monhaupt
;Erfahrung
;3
;
Titel
Oberst
;F�hrungsqualit�ten 
;3
;
Daten
1775-1835
;Pers�nlichkeit
;1
;
;Lebenslauf
Der aus ziemlich einfachen Verh�ltnissen stammende von Monhaupt begann seine Laufbahn 
1790 in der preu�ischen Artillerie. Als Veteran der Revolutionskriege k�mpfte er bei Jena 
und 
geriet bei Ratkau gemeinsam mit Bl�cher in Gefangenschaft. Nach Jena stagnierte seine 
Laufbahn, daher trat er im Jahre 1812 in die russische Armee ein und �bernahm den Befehl 
�ber 
die Berittene Artillerie der russisch-deutschen Legion. Im Jahre 1815 kehrte er im Rang eines 
Oberst in den preu�ischen Dienst zur�ck. Nach der Schlacht bei Waterloo verfa�te er 
zahlreiche 
Werke �ber den taktischen Einsatz der Berittenen Artillerie. Er zog sich 1834 aus dem Dienst 
zur�ck und starb im darauffolgenden Jahr in Berlin. 
..................................................................
;Name
Albrecht Georg Ernst Karl von Hake
;Erfahrung
;4
;
Titel
Generalleutnant 
;F�hrungsqualit�ten
;2
;
Daten
1768-1835
;Pers�nlichkeit
;1
;
;Lebenslauf
Von Hake schlo� sich 1785 als F�hnrich dem Garderegiment der preu�ischen Armee an. Er 
zeichnete sich in den Revolutionskriegen durch besondere Leistungen aus und verdiente sich 
den Orden "Pour le M�rite" bei Pirmasens. 
1792 nahm er an der Kanonade von Valmy teil. Obgleich er bei Leipzig dabei gewesen war, 
k�mpfte von Hake im Feldzug von 1814 weiter, wurde verwundet und mit zwei Eisernen 
Kreuzen 
ausgezeichnet. Von 1819 bis 1833 hatte er das Amt des Kriegsministers inne. Er starb im 
Jahre 
1835 in Italien.
..................................................................
;Name
Friedrich Wihelm von Funck
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1774-1830
;Pers�nlichkeit
;5
;
;Lebenslauf
Von Funck meldete sich 1792 zum Dienst in der preu�ischen Armee, gerade rechtzeitig, um 
in 
den Revolutionskriegen eingesetzt zu werden. Nach seiner Verwundung bei Jena wurde ihm 
1807 der Sold um die H�lfte gek�rzt. Nachdem er im Jahre 1808 seinen Dienst als Major 
wieder 
aufgenommen hatte, erhielt er drei Jahre sp�ter sein eigenes Bataillon. 1812 verdiente er 
sich 
den Orden "Pour le M�rite" in Ru�land. Im Herbst des Jahres 1813 befehligte er ein 
Infanterieregiment und k�mpfte bei Dresden, Kulm und Leipzig. Er wurde 1821 zum 
Kommandeur der Festung in Kolberg ernannt, wo er neun Jahre sp�ter starb. 
..................................................................
;Name
Michael Heinrich von Losthin
;Erfahrung
;3
;
Titel
Generalmajor
;F�hrungsqualit�ten
;2
;
Daten
1762-1839
;Pers�nlichkeit
;1
;
;Lebenslauf
Von Losthin trat 1773 als Kadett in die preu�ische Armee ein. Er k�mpfte 1806 bei Jena 
und floh 
nach der Schlacht nach Schlesien, wo er ein Grenadierbataillon aufstellte, das sp�ter im 
Freisch�rlerkrieg gegen die Franzosen in Schlesien Ber�hmtheit erlangte. F�r seine dortigen 
Leistungen wurde von Losthin mit dem Orden "Pour le M�rite" ausgezeichnet. Im Jahre 
1809 
wurde er zum Kommandeur eines Infanterieregiments ernannt. 1813 erhielt er den Befehl 
�ber 
eine Brigade und verdiente sich bei Wartenburg das Eiserne Kreuz 2. Klasse. Im selben Jahr 
wurde er bei Leipzig verwundet und erhielt daf�r das Eiserne Kreuz 1. Klasse. Kurz nach der 
Schlacht von Waterloo zog er sich zur�ck. Er starb im Jahre 1839.
..................................................................
;Name
Johann Friedrich Hiller von Gaertringen
;Erfahrung
;4
;
Titel
Oberst
;F�hrungsqualit�ten
;4
;
Daten
1772-1856
;Pers�nlichkeit
;3
;
;Lebenslauf
Der volle Name von Gaertringen laute Johann Friedrich August Freiherr Hiller von 
Gaertringen. Von Gaertringen meldete sich 1784 zum Dienst in der preu�ischen Armee und 
k�mpfte 1787 in Holland (verwundet) und in den Revolutionskriegen. Sein n�chster Einsatz 
war im Jahre 1812 in Ru�land. Er engagierte sich au�erordentlich in den Schlachten von 
1813, wobei er einmal verwundet wurde (Lutzen) und sich sowohl beide Klassen des 
Eisernen Kreuzes als auch eine Auswahl an russischen und schwedischen Auszeichnungen 
verdiente. Im Jahre 1830 ging er in den Ruhestand. 
..................................................................
;Name
Hans Joachim Friedrich von Sydow
;Erfahrung
;2
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1762-1823
;Pers�nlichkeit
;3
;
;Lebenslauf
Von Sydow trat 1775 als Kadett in Bl�chers altes Husarenregiment ein, wo er f�r seine 
Leistungen viel Lob empfing. In den Revolutionskriegen verdiente er sich durch seine 
ausgezeichneten Leistungen bei Kaiserslautern (wo er au�erdem verwundet wurde) den 
Orden 
"Pour le M�rite". Nach seiner zweiten Verwundung bei Auerstedt stieg von Sydow 1809 
zum 
Kommandeur seines Regimentes auf. Im Herbst 1813 befehligte er eine Brigade der Miliz-
Kavallerie. Nach der Schlacht von Waterloo wurde ihm in den Reservetruppen ein h�herer 
Befehl �bertragen. Er starb ein Jahr nachdem er sich in den Ruhestand begeben hatte.
..................................................................
;Name
Johann Karl Ludwig Braun
;Erfahrung
;4
;
Titel
Generalmajor
;F�hrungsqualit�ten
;3
;
Daten
1771-1835
;Pers�nlichkeit
;
;Lebenslauf
Braun meldete sich 1788 zum Dienst in der preu�ischen Artillerie und k�mpfte 1806 als 
Stabsoffizier bei Jena. Im Jahre 1813 k�mpfte er bei Lutzen, Bautzen (Eisernes Kreuz 2. 
Klasse, 
russischer St. Annen-Orden 3. Klasse), Dresden, Kulm (Eisernes Kreuz 1. Klasse) und 
Leipzig 
(russischer St. Georgs-Orden 3. Klasse). Nach der Schlacht von Waterloo wurde er 
Inspekteur 
der Artillerie. Er starb 1835 in Berlin.
..................................................................
;Name
A. Macdonald
;Erfahrung
;3
;
Titel
Oberstleutnant
;F�hrungsqualit�ten
;2
;
Daten
1774-1852
;Pers�nlichkeit 
;3
;
;Lebenslauf
Macdonald trat 1793 in die Kavallerie ein und wurde bald darauf zum Hauptmann in der 
Pferdeartillerie ernannt. W�hrend der Verteidigung von Holland (1796-99) wurde er 
verwundet 
und gefangengenommen und verbrachte zwei Jahre als Kriegsgefangener. Bei seiner 
R�ckkehr 
nach England nach dem Frieden von Amiens erfuhr er seine Bef�rderung zum Oberstleutnant 
in 
der Kavallerieartillerie. Macdonald k�mpfte unter Wellington im Feldzug auf der 
Pyren�enhalbinsel und stieg im Jahre 1813 in den Rang eines Oberst auf. 1825 zwang ihn 
seine 
angegriffene Gesundheit dazu, den Posten eines Inspekteurs anzunehmen. 
..................................................................
;Name
Baron Etienne Hulot de Mazerny
;Erfahrung 
;4
;
Titel
Brigadegeneral
;F�hrungsqualit�ten 
;4
;
Daten
1774-1850
;Pers�nlichkeit
;3
;
;Lebenslauf
Der am 15. Februar 1774 in Hulot geborene de Mazerny war noch ein Obersch�ler, als er 
sich im 
April 1793 dazu entschlo�, als Freiwilliger zur Infanterie zu gehen. Nach seinem Dienst 
w�hrend 
der Revolutionskriege wurde er im November 1805 zu Soults Adjutant bestimmt. Kurz 
darauf 
wurde er zum Oberst bef�rdert und befehligte das Elitebataillon der "Tirailleurs du Po" und 
wurde 
bei Austerlitz verwundet. Im Jahre 1808 wurde Hulot nach Spanien entsandt. Nach seiner 
Bef�rderung zum Brigadegeneral am 9. August 1812 wurde er f�r die Feldz�ge von 1813 
nach 
Deutschland zur�ckbeordert und sowohl bei Juterbug als auch bei Hanau verwundet. 1815 
�bernahm Hulot den Befehl �ber die 14. Infanteriedivision, nachdem Bourmont am Vorabend 
des Feldzuges desertiert war. 1819 gab er seinen Ruhestand wieder auf und wurde 
Generalinspekteur der Infanterie. Er starb am 3. September 1850 in Nancy.
..................................................................
;Name
Prinz Wilhelm von Preu�en
;Erfahrung
;2
;
Titel
General der Kavallerie
;F�hrungsqualit�ten
;4
;
Daten
1797-1888
;Pers�nlichkeit
;3
;
;Lebenslauf
Wilhelm, am 22. M�rz 1797 in Berlin geboren, war der zweit�lteste Sohn des preu�ischen 
K�nigs Friedrich Wilhelm III. und seiner Gattin K�nigin Luise. Einen Gro�teil der 
napoleonischen 
Kriege verbrachte Wilhelm wegen Krankheit in K�nigsberg, Memel und St. Petersburg. Er 
nahm 
jedoch am Befreiungskrieg (1813-14) und am darauffolgenden 100-Tage-Feldzug teil. Bei 
Bar-
sur-Aube verdiente er sich das Eiserne Kreuz und wurde an seinem einundzwanzigsten 
Geburtstag zum Generalmajor bef�rdert. Nach dem Krieg wurde er im Jahre 1840 mit der 
Thronbesteigung seines kinderlosen Bruders Friedrich Wilhelm IV. zum mutma�lichen Erben. 
Im 
Jahre 1854 stieg er in den Rang des Feldmarschalls auf und �bernahm schlie�lich 1861 den 
k�niglichen Thron von seinem Bruder. Aufgrund seines tiefgreifenden militaristischen 
Konservatismus wurde er auch "Patronenprinz" genannt. 
.........................................
;Name
Heinrich Christopher Karl Hermann Lottum
;Erfahrung
;4
;
Titel
Graf von Wylich und Lottum
;F�hrungsqualit�ten 
;4
;
Daten
1773-1830
;Pers�nlichkeit
;3
;
;Lebenslauf
Lottum trat 1786 als Kadett ins Dragonerregiment Graf Lottum ein. Im Jahre 1787 wurde er 
zum 
F�hnrich, 1788 zum Unterleutnant bef�rdert. 1792 diente er in Valmy und Kaiserslautern. 
1798 
wurde er zum Oberleutnant bef�rdert, 1803 zum Stabshauptmann, 1806 zum Hauptmann 
und 
schlie�lich 1808 zum Major. Nach seiner �bernahme des Befehls �ber das 2. 
Brandenburgische 
Regiment im Jahre 1813 diente er im selben Jahr bei Gro�goerschen, Dennewitz und Leipzig 
und wurde mit dem Eisernen Kreuz 2. Klasse ausgezeichnet. Nach seiner Bef�rderung zum 
Oberstleutnant (August 1813) und zum Oberst im Dezember des gleichen Jahres wurde er 
1814 
mit dem schwedischen Schwert-Orden ausgezeichnet. Er f�hrte den Oberbefehl �ber die 2. 
Kavalleriebrigade des 3. preu�ischen Korps bei Ligny und Waterloo und erhielt sowohl den 
russischen St. Annen-Orden (2. Klasse) und den Vladimir-Orden (3. Klasse) als auch das 
Eiserne Kreuz 1. Klasse. 
.........................................
;Name
Friedrich August Ludwig von der Marwitz
;Erfahrung
;4
;
Titel
Oberst
;F�hrungsqualit�ten 
;4
;
Daten
1777-1837
;Pers�nlichkeit
;4
;
;Lebenslauf
Von der Marwitz meldete sich 1790 als Kadett im Regiment der Gendarme zum Dienst. Im 
Jahre 
1791 wurde er zum F�hnrich der Reiterei bef�rdert, 1797 zum Unterleutnant, 1802 zum 
Oberleutnant und 1806 schlie�lich zum Hauptmann. Er diente 1806 bei Jena und befehligte 
im 
Jahre 1807 das Freikorps. Daraufhin schlo� er sich Bl�cher an und wurde zum Major 
bef�rdert. 
1813 wurde er zum Kommandeur einer Brigade der Kurmark-Miliz und im selben Jahr noch 
zum 
Oberstleutnant ernannt. Er diente bei Hagleberg und wurde mit dem russischen St. Annen-
Orden 
(2. Klasse) und dem Eisernen Kreuz 2. Klasse ausgezeichnet. Im Jahre 1814 diente er in der 
Belagerung von Wesel und wurde daraufhin mit dem Eisernen Kreuz 1. Klasse 
ausgezeichnet. 
Nach seiner Bef�rderung zum Oberst 1815 diente er bei Ligny, Wavre und Waterloo als 
Kommandeur der 2. Kavalleriebrigade im 3. preu�ischen Korps.
.........................................
;Name
Joseph Adolf Achaz von der Schulenburg
;Erfahrung 
;3
;
Titel
Graf von der Schulenburg
;F�hrungsqualit�ten 
;3
;
Daten
1776-1827
;Pers�nlichkeit
;2
;
;Lebenslauf
Von der Schulenburg begann seine milit�rische Laufbahn 1791 als F�hnrich im 
K�rassierregiment von Ilow. 1792 wurde er zum F�hnrich der Reiterei bef�rdert und diente 
bei 
Kaiserslautern, wo er f�r den Orden "Pour le M�rite" empfohlen wurde. 1794 wurde er zum 
Unterleutnant ernannt und in die Garde du Corps (die k�nigliche Leibwache) versetzt. 
Weitere 
Bef�rderungen: Oberleutnant (1799), Stabshauptmann (1803), Major (1809), Oberstleutnant 
und 
Kommandeur der k�niglichen Leibwache (1813). Er diente bei Gro�goerschen, wo er das 
Eiserne Kreuz 2. Klasse erhielt, und bei Bautzen, Leipzig und Arcis sur Aube. 1815 k�mpfte 
er 
bei Ligny und Waterloo, wo er f�r seine Leistungen mit dem Eisernen Kreuz 1. Klasse 
ausgezeichnet wurde. 
.........................................
;Name
Friedrich Georg Ludwig von Sohr
;Erfahrung
;4
;
Titel
Oberstleutnant
;F�hrungsqualit�ten
;4
;
Daten
1775-1845
;Pers�nlichkeit
;4
;
;Lebenslauf
Von Sohr trat 1791 als Kadett der Berufshusaren in die Armee ein. 1790 wurde er zum 
F�hnrich 
der Reiterei bef�rdert und diente 1792 bei Valmy und Kaiserslautern, wobei er in beiden 
Schlachten verwundet wurde. 1793 nahm er an der Belagerung von Mainz teil und wurde 
noch 
im selben Jahr zum Leutnant bef�rdert. 1795 erhielt er den Orden "Pour le M�rite". Im Jahre 
1804 wurde er zum Oberleutnant und 1806 zum Stabshauptmann ernannt. 1807 kam er in 
von 
der Marwitz' Freikorps. 1809 wurde er zum Hauptmann und zum Kommandeur einer 
Schwadron 
in der brandenburgischen Husareneinheit ernannt. Nach seiner Bef�rderung zum Major 
(1812) 
wurde 1813 f�r Sohr zu einem �u�erst ereignisreichen Jahr, denn er erlangte den Rang des 
Oberstleutnants und diente sowohl bei Gro�goerschen, Bautzen und Hanau (wo er mit dem 
Eisernen Kreuz 2. Klasse ausgezeichnet wurde) als auch bei Katzbach und Leipzig, wo er 
verwundet wurde und den russischen St. Annen-Orden (2. Klasse) empfing. Im Jahre 1814 
erhielt er den schwedischen Schwert-Orden, den russischen St. Georgs-Orden und das 
Eiserne 
Kreuz 1. Klasse. 
.........................................
;Name
Baron Hendrik George Graf de Perponcher-Sedlnitzky
;Erfahrung
;3
;
Titel
Generalleutnant
;F�hrungsqualit�ten
;3
;
Daten
1771-1856
;Pers�nlichkeit
;3
; 
;Lebenslauf
Hendrik war der Bruder des besser bekannten Willem Karel de Perponcher, der vor ihm in der 
preu�ischen Armee unter Bl�cher gedient hatte. Im Krieg von 1793 diente Hendrik als Prinz 
Friedrichs Adjutant, eine Stellung, die er auch zum Zeitpunkt von Friedrichs Tod in Padua 
1799 
noch innehatte. Im Jahre 1795 suchte er in England Zuflucht, und 1800 ging er in den 
Dienst der 
englischen Armee, wo er vor seiner R�ckkehr nach Holland in der Schlacht von Leipzig 
(1813) 
gegen die Franzosen k�mpfte. Er erhielt die Aufforderung, nach England zur�ckzukehren, um 
den Prinzen von Oranien zur R�ckkehr nach Holland aufzufordern. Als Oberst nahm er 
Gorinchem ein und diente bei Quatre Bras und Waterloo erneut als Generalleutnant. Er 
bewies 
auch hier ausgezeichnete Leistungen. Seine 2. Holl�ndisch-belgische Infanteriedivision erlitt 
bei 
Waterloo als Folge des Bombardements durch die franz�sische Grand Batterie schwere 
Verluste. Von 1815 bis 1842 diente er im Amt des holl�ndischen Botschafters in Berlin.
.........................................
11. Kompanie 6. Unberittenes Artillerieregiment / 1. Reservekorps der Artillerie
Kommandeur:
Hauptmann Didier
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen der 11. Kompanie des 6. Unberittenen 
Artillerieregiments.|
..........................
1. Brigade / 1. Infanteriedivision
Kommandeur: 
Brigadegeneral|Baron Quiot du Passage
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
54. Gefechtslinienregiment
Oberst Charlet
55. Gefechtslinienregiment
Oberst Morin
,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
In Vertretung von Generalmajor Graf Allix de Vaux befehligte Quiot die 1. Division w�hrend 
des 
Feldzugs.|
|
Eins�tze des 54. Gefechtslinienregiments:|
|
Austerlitz (1805), Jena (1806), Friedland (1807), Aspern-Essling (1809),
Wagram (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 55. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.
...........................................
2. Brigade / 1. Infanteriedivision 
Kommandeur:
Brigadegeneral|Baron Bourgeois
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
28. Gefechtslinienregiment
Bataillonskommandeur Senac
105. Gefechtslinienregiment
Oberst Gentry
,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Bourgeois wurde am 16. Juni und bei Waterloo verwundet.|
|
Eins�tze des 28. Gefechtslinienregiments:|
|
Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 105. Gefechtslinienregiments:|
|
Jena (1806), Eylau (1807), Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809).|
Dieses Regiment verlor bei Waterloo seinen Adler.|
............................
20. Kompanie 6. Unberittenes Artillerieregiment / 1. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Hamelin
Portr�t: 
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 20. Kompanie des 6. Unberittenen 
Artillerieregiments.
..........................................
1. Brigade / 2. Infanteriedivision
Kommandeur: 
Brigadegeneral|Baron Schmitz
Portr�t: 
Leichtes Infanterieregiment
Zusammensetzung:
13. Leichtes Infanterieregiment
Bataillonskommandeur Gougeon
17. Gefechtslinienregiment
Oberst Chevalier Guerel
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 13. Leichten Infanterieregiments:|
|
Austerlitz (1806), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).|
|
Eins�tze des 17. Gefechtslinienregiments:|
|
Austerlitz (1806), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).
........................................
2. Brigade / 2. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Aulard
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
19. Gefechtslinienregiment
Oberst Trupel
51. Gefechtslinienregiment
Oberst Baron Rignon
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Aulard fiel bei Waterloo.|
|
Eins�tze des 19. Gefechtslinienregiments:|
|
Wagram (1809), Ru�landfeldzug.|
|
Eins�tze des 51. Gefechtslinienregiments:|
|
Austerlitz (1806), Auerstadt (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.
........................................
10. Kompanie 6. Unberittenes Artillerieregiment / 2. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Cantin
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2" Haubitzen der 10. Kompanie des 6. Unberittenen 
Artillerieregiments.
...............................................
1. Brigade / 3. Infanteriedivision
Kommandeur:
Brigadegeneral|Chevalier Nogues
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
21. Gefechtslinienregiment
Oberst Baron Carre
46. Gefechtslinienregiment
Oberst Dupr�
,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Chevalier Nogues wurde bei Waterloo verwundet.|
|
Eins�tze des 21. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).|
|
Eins�tze des 46. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Borodino (1812).
........................................
2. Brigade / 3. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Grenier
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
25. Gefechtslinienregiment
Oberst Chevalier Galte
45. Gefechtslinienregiment
Oberst Chapuset
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 25. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).|
|
Eins�tze des 45. Gefechtslinienregiments:|
|
Austerlitz (1805), Jena (1806), Friedland (1807), Eylau (1807), Aspern-Essling (1809), 
Wagram 
(1809), Krieg auf der Pyren�enhalbinsel.
........................................
19. Kompanie 6. Unberittenes Artillerieregiment / 3. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Emon
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 19. Kompanie des 6. Unberittenen 
Artillerieregiments.
......................................
1. Brigade / 4. Infanteriedivision
Kommandeur:
Brigadegeneral|Chevalier Pegot
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
8. Gefechtslinienregiment
Oberst Ruelle
29. Gefechtslinienregiment
Oberst Rousselot
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 8. Gefechtslinienregiments:|
|
Austerlitz (1805), Jena (1806), Friedland (1807), Aspern-Essling (1809), Wagram (1809), 
Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 29. Gefechtslinienregiments:|
|
Italien, Wagram (1809), Ru�landfeldzug.
........................................
2. Brigade / 4. Infanteriedivision
Kommandeur:
Brigadegeneral|Brue
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
85. Gefechtslinienregiment
Oberst Masson
95. Gefechtslinienregiment
Oberst Garnier
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 85. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).|
|
Eins�tze des 95. Gefechtslinienregiments:|
|
Austerlitz (1805), Jena (1806), Friedland (1807), Aspern-Essling (1809), Wagram (1809) 
Krieg auf der Pyren�enhalbinsel.
........................................
9. Kompanie 6. Unberittenes Artillerieregiment / 4. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Bourgeois
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 9. Kompanie des 6. Unberittenen 
Artillerieregiments.
.............................................
1. Brigade / 1. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Bruno
Portr�t:
7. Husaren-Einheit 
Zusammensetzung:
7. Husaren-Einheit 
Oberst de Marbot
3. Berittene J�ger-Einheit
Oberst Lawoestine
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 7. Husaren-Einheit:|
|
Jena (1806), Eylau (1807), Friedland (1807), Wagram (1809), Borodino (1812).|
|
Eins�tze der 3. Berittenen J�ger-Einheit:|
|
Friedland (1807), Eckm�hl (1809), Wagram (1809), Borodino (1812).
............................................				
2. Brigade / 1. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Gobrecht
Portr�t:
3. Leichte Lanzenreiter-Einheit
Zusammensetzung:
3. Leichte Lanzenreiter-Einheit
Oberst Martigue
4. Leichte Lanzenreiter-Einheit
Oberst Bro
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Gobrecht wurde bei Waterloo verwundet.|
|
Eins�tze der 3. Leichten Lanzenreiter-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel, 
Ru�landfeldzug.|
|
Eins�tze der 4. Leichten Lanzenreiter-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel, 
Borodino 
(1812).
........................................
2. Kompanie 1. Berittenes Artillerieregiment / 1. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Bourgeois
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des 1. Berittenen 
Artillerieregiments.
...............................................
7. Kompanie 2. Unberittenes Artillerieregiment / 2. Reservekorps der Artillerie
Kommandeur:
Hauptmann Gayat
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen der 7. Kompanie des 2. Unberittenen 
Artillerieregiments.
..........................
1. Brigade / 5. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Husson
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
3. Gefechtslinienregiment
Oberst Baron Vautrin
61. Gefechtslinienregiment
Oberst Bouge
,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 3. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Friedland (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Ru�landfeldzug.|
|
Eins�tze des 61. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).
........................................
2. Brigade / 5. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Campi
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
72. Gefechtslinienregiment
Oberst Thibault
108. Gefechtslinienregiment
Oberst Higonet
,,,,,,,,,,,,,,,,,,,,,,,,,,
Brigadegeneral Baron Campil wurde bei Waterloo verwundet.|
|
Eins�tze des 72. Gefechtslinienregiments:|
|
Friedland (1807), Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), Borodino 
(1812).|
|
Eins�tze des 108. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809),Wagram (1809), 
Borodino 
(1812).
........................................
18. Kompanie 6. Unberittenes Artillerieregiment / 5. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Deshaulles
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 18. Kompanie des 6. Unberittenen 
Artillerieregiments.
..........................................
1. Brigade / 6. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Bauduin
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
1. Leichtes Infanterieregiment
Oberst Despans-Cubi�res
2. Leichtes Infanterieregiment
Oberst Maigros
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Bauduin fiel bei Waterloo.|
|
Eins�tze des 1. Leichten Infanterieregiments:|
|
Italien, Pyren�enhalbinsel-Feldzug.|
|
Eins�tze des 2. Leichten Infanterieregiments:|
|
Friedland (1807), Feldzug auf der Pyren�enhalbinsel.
........................................
2. Brigade / 6. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Soye
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
1. Gefechtslinienregiment
Oberst Cornebise
2. Gefechtslinienregiment
Oberst Trippe
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 1. Gefechtslinienregiments:|
|
Italien, Wagram (1809), Feldzug auf der Pyren�enhalbinsel.|
|
Eins�tze des 2. Gefechtslinienregiments:|
|
Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), Borodino (1812).
.......................................
2. Kompanie 2. Unberittenes Artillerieregiment / 6. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Fivel
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des 2. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 7. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Devilliers
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
11. Leichtes Infanterieregiment 
Oberst Sebastiani
82. Gefechtslinienregiment
Oberst Matis
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Devilliers wurde bei Ligny verwundet.|
|
Eins�tze des 11. Leichten Infanterieregiments:|
|
Ru�landfeldzug.|
|
Eins�tze des 82. Gefechtslinienregiments:|
|
Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 7. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Piat
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
12. Leichtes Infanterieregiment
Oberst Moutett
4. Gefechtslinienregiment
Oberst Foullin
,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Piat wurde bei Ligny verwundet.|
|
Eins�tze des 12. Leichten Infanterieregiments:|
|
Friedland (1807), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 4. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Borodino (1812).
........................................
3. Kompanie 2. Unberittenes Artillerieregiment / 7. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Barbaux
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des 2. Unberittenen 
Artillerieregiments.
..........................................
1. Brigade / 9. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Gauthier
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
92. Gefechtslinienregiment
Oberst Tissot
93. Gefechtslinienregiment
Bataillonskommandeur Massot
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Gauthier wurde am 16. Juni verwundet.|
|
Eins�tze des 92. Gefechtslinienregiments:|
|
Ulm (1805), Wagram (1809), Borodino (1812).|
|
Eins�tze des 93. Gefechtslinienregiments:|
|
Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), Borodino (1812).
........................................
2. Brigade / 9. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Jamin
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
100. Gefechtslinienregiment
Oberst Braun
4. Leichtes Infanterieregiment
Oberst Peyris
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 100. Gefechtslinienregiments:|
|
Ulm (1805), Aspern-Essling (1809), Wagram (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 4. Leichten Infanterieregiments:|
|
Ulm (1805), Friedland (1807), Krieg auf der Pyren�enhalbinsel.
........................................
1. Kompanie 6. Unberittenes Artillerieregiment / 9. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Hauptmann Tacon
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 1. Kompanie des 6. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 2. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Huber
Portr�t:
6. Berittene J�ger-Einheit
Zusammensetzung:
1. Berittene J�ger-Einheit
Oberst Simoneau
6. Berittene J�ger-Einheit
Oberst Fundouas
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 1. Berittenen J�ger-Einheit:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino 
(1812).|
|			
Eins�tze der 6. Berittenen J�ger-Einheit:|
|
Wagram (1809), Ru�landfeldzug.
.......................................			
2. Brigade / 2. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Wathiez
Portr�t:
5. Leichte Lanzenreiter-Einheit
Zusammensetzung:
5. Leichte Lanzenreiter-Einheit
Oberst Jacqueminot
6. Leichte Lanzenreiter-Einheit
Oberst de Galbois
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Wathiez wurde bei Waterloo verwundet.|
|
Eins�tze der 5. Leichten Lanzenreiter:|
|
Ulm (1805), Austerlitz (1805), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel, 
Borodino (1812).|
|
Eins�tze der 6. Leichten Lanzenreiter:|
|
Italien, Neapel, Raab (1809), Wagram (1809).
........................................
2. Kompanie 4. Berittenes Artillerieregiment / 2. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Gronnier
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des 4. Berittenen 
Artillerieregiments.
...........................................
1. Brigade / 4. Kavalleriedivision
Kommandeur:
Brigadegeneral|Saint-Laurent
Portr�t:
1. Husaren-Einheit 
Zusammensetzung:
1. Husaren-Einheit 
Oberst Clary
4. Husaren-Einheit 
Oberst Blot
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 1. Husaren-Einheit:|
|
Ulm(1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze der 4. Husaren-Einheit:|
|
Austerlitz(1805), Jena (1806), Friedland (1807), Krieg auf der Pyren�enhalbinsel.	
...................................................				
2. Brigade / 4. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Ameil
Portr�t:
5. Husaren-Einheit 
Zusammensetzung:
5. Husaren-Einheit 
Oberst Baron Li�gard
,,,,,,,,,,,,,,,,,,,,,
........................................
1. Kompanie 1. Berittenes Artillerieregiment / 4. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Cotheraux
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 1. Kompanie des 1. Berittenen 
Artillerieregiments.
............................................
1. Brigade / 5. Kavalleriedivision
Kommandeur:
Brigadegeneral|Graf Louis-Pierre-Alphonse de Colbert
Portr�t:
2. Leichte Lanzenreiter-Einheit
Zusammensetzung:
1. Leichte Lanzenreiter-Einheit
Oberst Jacquinot
2. Leichte Lanzenreiter-Einheit
Oberst Sourd
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 1. Leichten Lanzenreiter-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel, 
Borodino (1812).|
|
Eins�tze der 2. Leichten Lanzenreiter-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel, 
Borodino 
(1812).
.......................................			
2. Brigade / 5. Kavalleriedivision
Kommandeur: 
Brigadegeneral|Chevalier Antoine Fran�ois Eug�ne Merlin
Portr�t:
11. Berittene J�ger-Einheit
Zusammensetzung:
11. Berittene J�ger-Einheit
Oberst Baron Nicolas
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 11. Berittenen J�ger-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl 
(1809),
Wagram (1809), Borodino (1812).
........................................
3. Kompanie 1. Berittenes Artillerieregiment / 5. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Duchemin
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des 1. Berittenen 
Artillerieregiments.
....................................
1. Brigade / 9. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Burthe
Portr�t:
5. Dragoner-Einheit 
Zusammensetzung:
5. Dragoner-Einheit 
Oberst Canevas Saint-Amand
13. Dragoner-Einheit 
Oberst Saviot
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 5. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze der 13. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.
................................
2. Brigade / 9. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Vincent
Portr�t:
15. Dragoner-Einheit 
Zusammensetzung:
15. Dragoner-Einheit 
Oberst Chaillot
20. Dragoner-Einheit 
Oberst Briqueville
,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 15. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze der 20. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.
........................................
4. Kompanie 1. Berittenes Artillerieregiment / 9. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Godet
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 4. Kompanie des 1. Berittenen 
Artillerieregiments.
...........................................
1. Brigade / 10. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Bonnemains
Portr�t:
4. Dragoner-Einheit 
Zusammensetzung:
4. Dragoner-Einheit 
Oberst Bouquerot des Essarts
12. Dragoner-Einheit 
Oberst Bureaux de Puzy
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 4. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze der 12. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.
.........................................				
2. Brigade / 10. Kavalleriedivision
Kommandeur:
Brigadegeneral|Chevalier Berton
Portr�t:
14. Dragoner-Einheit 
Zusammensetzung:
14. Dragoner-Einheit 
Oberst Seguier
17. Dragoner-Einheit 
Oberst Labifle
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 14. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.|
|
Eins�tze der 17. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.
........................................
4. Kompanie 4. Berittenes Artillerieregiment / 10. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Bernard
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 4. Kompanie des 4. Berittenen 
Artillerieregiments.
.................................................
1. Brigade / 11. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Picquet
Portr�t:
2. Dragoner-Einheit 
Zusammensetzung:
2. Dragoner-Einheit 
Oberst Planzeau
7. Dragoner-Einheit 
Oberst L�opold
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Picquet wurde bei Waterloo verwundet.|
|
Eins�tze der 2. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.|
|
Eins�tze der 7. Dragoner-Einheit:|
|
Italien, Wagram (1809), Borodino (1812).
.............................				
2. Brigade / 11. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Guiton
Portr�t: 
8. K�rassier-Einheit
Zusammensetzung:
8. K�rassier-Einheit
Oberst Garavaque
11. K�rassier-Einheit
Oberst Courtier
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Guiton wurde bei Waterloo verwundet.|
|
Eins�tze der 8. K�rassier-Einheit:|
|
Aspern-Essling (1809), Wagram (1809), Borodino (1812).|
|
Eins�tze der 11. K�rassier-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Borodino (1812).
........................................
3. Kompanie 2. Berittenes Artillerieregiment / 11. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann de Marcillac
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des 2. Berittenen 
Artillerieregiments.
................................
1. Brigade / 13. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Dubois
Portr�t:
1. K�rassier-Einheit
Zusammensetzung:
1. K�rassier-Einheit
Oberst Graf Ordener
4. K�rassier-Einheit
Oberst Habert
,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Dubois wurde bei Waterloo verwundet.|
|
Eins�tze der 1. K�rassier-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Borodino (1812).|
|
Eins�tze der 4. K�rassier-Einheit:|
|
Aspern-Essling (1809), Wagram (1809), Ru�landfeldzug.
.....................................				
2. Brigade / 13. Kavalleriedivision
Kommandeur:
Brigadegeneral|Travers, Baron von Jever
Portr�t:
12. K�rassier-Einheit
Zusammensetzung:
7. K�rassier-Einheit
Oberst Richardot
12. K�rassier-Einheit
Oberst Thurot
,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Travers wurde bei Waterloo verwundet.|
|
Eins�tze der 7. K�rassier-Einheit:|
|
Aspern-Essling (1809), Wagram (1809), Ru�landfeldzug.|
|
Eins�tze der 12. K�rassier-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl 
(1809), 
Aspern-Essling (1809), Wagram (1809), Borodino (1812).
........................................
5. Kompanie 1. Berittenes Artillerieregiment / 13. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Duchet
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 5. Kompanie des 1. Berittenen 
Artillerieregiments.
.....................................
1. Brigade / 14. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Farine du Creux
Portr�t:
5. K�rassier-Einheit
Zusammensetzung:
5. K�rassier-Einheit
Oberst Gobert
10. K�rassier-Einheit
Oberst Lahuberdi�re
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Farine du Creux wurde bei Ligny und bei Waterloo verwundet.|
|
Eins�tze der 5. K�rassier-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl 
(1809), 
Aspern-Essling (1809), Wagram (1809), Borodino (1812).|
|
Eins�tze der 10. K�rassier-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Borodino (1812).
.....................................				
2. Brigade / 14. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Vial
Portr�t:
9. K�rassier-Einheit
Zusammensetzung:
6. K�rassier-Einheit
Oberst Martin
9. K�rassier-Einheit
Oberst Bigarne
,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 6. K�rassier-Einheit:|
|
Aspern-Essling (1809), Wagram (1809), Borodino (1812).|
|
Eins�tze der 9. K�rassier-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl (1809), Wagram 
(1809), 
Borodino (1812).
........................................
4. Kompanie 3. Berittenes Artillerieregiment / 14. Kavalleriedivision
Kommandeur:
Nicht bekannt 
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 4. Kompanie des 3. Berittenen 
Artillerieregiments.
....................................
Unberittene Reserveartillerie der Kaiserlichen Garde
Kommandeur:
Brigadegeneral Baron Henry-Dominique Lallemand
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Lallemand wurde bei Waterloo verwundet.|
|
Bestehend aus vier Batterien mit je sechs 12-Pfund-Gesch�tzen und zwei 6"-Haubitzen des 
Unberittenen Artillerieregiments der Alten Garde. Die 12-Pf�nder der Kaiserlichen Garde 
hatten 
den Spitznamen "Die sch�nen T�chter".
...............................................		
1. Kompanie des Unberittenen Artillerieregiments der Alten Garde / Unberittene Artillerie der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen des Unberittenen Artillerieregiments der 
Alten 
Garde.
Die 12-Pf�nder der Kaiserlichen Garde hatten den Spitznamen "Die sch�nen T�chter".
...................................
2. Kompanie des Unberittenen Artillerieregiments der Alten Garde / Unberittene Artillerie der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen des Unberittenen Artillerieregiments der 
Alten 
Garde.
Die 12-Pf�nder der Kaiserlichen Garde hatten den Spitznamen "Die sch�nen T�chter".
...............................
3. Kompanie des Unberittenen Artillerieregiments der Alten Garde / Unberittene Artillerie der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen des Unberittenen Artillerieregiments der 
Alten 
Garde.
Die 12-Pf�nder der Kaiserlichen Garde hatten den Spitznamen "Die sch�nen T�chter".
................................
4. Kompanie des Unberittenen Artillerieregiments der Alten Garde / Unberittene Artillerie der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen des Unberittenen Artillerieregiments der 
Alten 
Garde.
Die 12-Pf�nder der Kaiserlichen Garde hatten den Spitznamen "Die sch�nen T�chter".
..............................................
1. Brigade der Grenadier-Division / Kaiserliche Garde
Kommandeur:
Generalmajor Graf Friant
Portr�t:
Kaiserliche Garde
Zusammensetzung:
1. Grenadier-Einheit (Alte Garde)
Brigadegeneral Baron Petit
2. Grenadier-Einheit (Alte Garde)
Brigadegeneral Baron Christiani
,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Kaiserliche Garde hatte eine andersartige Organisationsstruktur, in der es f�r eine 
Brigade 
zwei
Brigadegener�le gab. Aus Gr�nden der Einheitlichkeit ist Generalmajor Graf Friant als 
Kommandeur der gesamten Brigade angegeben.|
|
Eins�tze der 1. Grenadier-Einheit (Alte Garde):|
|
Marengo (1800), Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland 
(1807), Krieg auf der Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), Wagram 
(1809), Ru�landfeldzug.|
|
Eins�tze der 2. Grenadier-Einheit (Alte Garde):|
|
Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der Pyren�enhalbinsel, 
Ru�landfeldzug.
..................................
5. Kompanie des Unberittenen Artillerieregiments der Alten Garde / 1. Brigade der Grenadier-Division der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 5. Kompanie der Unberittenen 
Artillerie 
der Alten Garde.
................................
2. Brigade der Grenadier-Division / Kaiserliche Garde
Kommandeur:
Generalmajor Graf Friant
Portr�t:
Kaiserliche Garde
Zusammensetzung:
3. Grenadier-Einheit (Mittlere Garde)
Brigadegeneral Baron Poret de Morvan
4. Grenadier-Einheit (Mittlere Garde)  
Brigadegeneral Baron Harlet 
,,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Kaiserliche Garde hatte eine andersartige Organisationsstruktur, in der es f�r eine 
Brigade 
zwei Brigadegener�le gab. Aus Gr�nden der Einheitlichkeit ist Generalmajor Graf Friant als 
Kommandeur der gesamten Brigade angegeben.|
|
Eins�tze der 3. Grenadier-Einheit (Mittlere Garde):|
|
Die 3. und 4. Grenadier-Einheit wurden beide im Jahre 1815 neu aufgebaut. Die 
urspr�nglichen 
F�silier-Grenadiere und F�silier-J�ger wurden f�r den Waterloo-Feldzug nicht wieder 
aufgestellt.|
|
Brigadegeneral Baron Harlet wurde bei Waterloo verwundet.
..........................................
Unberittenes Gefechtslinienartillerie-Regiment (Hilfstruppen) / 2. Brigade der Grenadierdivision der Kaiserlichen Garde 
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen eines Unberittenen 
Gefechtslinienartillerie-
Regiments (Hilfstruppen).
............................................
1. Brigade der J�ger-Division / Kaiserliche Garde
Kommandeur:
Generalmajor Graf Michel
Portr�t:
Kaiserliche Garde
Zusammensetzung:
1. J�ger-Einheit (Alte Garde)
Brigadegeneral Graf Cambronne
2. J�ger-Einheit (Alte Garde)
Brigadegeneral Baron Pelet-Clozeau
,,,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Kaiserliche Garde hatte eine andersartige Organisationsstruktur, in der es f�r eine 
Brigade 
zwei Brigadegener�le gab. Aus Gr�nden der Einheitlichkeit ist Generalmajor Graf Michel als 
Kommandeur der gesamten Brigade angegeben.|
|
Eins�tze der 1. J�ger-Einheit (Alte Garde):|
|
Marengo (1800), Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland 
(1807), 
Krieg auf der Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), 
Ru�landfeldzug.|
|
Brigadegeneral Graf Cambronne wurde bei Waterloo verwundet und gefangengenommen.|
|
Eins�tze der 2. J�ger-Einheit (Alte Garde):|
|
Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der Pyren�enhalbinsel, 
Ru�landfeldzug.
....................................
6. Kompanie des Unberittenen Artillerieregiments der Alten Garde / 1. Brigade der J�ger-Division der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 6. Kompanie der Unberittenen 
Artillerie 
der Alten Garde.
.........................................
2. Brigade der J�ger-Division / Kaiserliche Garde
Kommandeur:
Generalmajor Graf Michel
Portr�t:
Kaiserliche Garde
Zusammensetzung:
3. J�ger-Einheit (Mittlere Garde)
Oberst Mallet
4. J�ger-Einheit (Mittlere Garde)
Brigadegeneral Baron Henrion
,,,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Kaiserliche Garde hatte eine andersartige Organisationsstruktur, in der es f�r eine 
Brigade 
zwei
Brigadegener�le gab. Aus Gr�nden der Einheitlichkeit ist Generalmajor Graf Michel als 
Kommandeur der gesamten Brigade angegeben.|
|
Die 3. und 4. J�ger-Einheit wurden beide im Jahre 1815 neu gebildet. Die urspr�nglichen 
F�silier-Grenadiere und F�silier-J�ger der Mittleren Garde 
wurden f�r den Waterloo-Feldzug nicht neu aufgestellt.|
|
Oberst Mallet wurde bei Waterloo t�dlich verwundet.|
Brigadegeneral Baron Henrion wurde bei Waterloo verwundet.
...........................................
Unberittenes Gefechtslinienartillerie-Regiment (Hilfstruppen) / 2. Brigade der J�ger-Division der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen eines Unberittenen 
Gefechtslinienartillerie-
Regiments (Hilfstruppen).
...................................................
1. Brigade der Junge Garde-Division / Kaiserliche Garde
Kommandeur:
Brigadegeneral|Chevalier Chartrand
Portr�t:
Voltigeure der Jungen Garde
Zusammensetzung:
1. Sch�tzen-Einheit
Oberst Trappier de Malcolm
1. Voltigeur-Einheit
Oberst Seretran
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 1. Sch�tzen-Einheit:|
|
Aspern-Essling (1809), Wagram (1809), Krieg auf der Pyren�enhalbinsel, Ru�landfeldzug.|
|
Eins�tze der 1. Voltigeur-Einheit:|
|
Aspern-Essling (1809), Wagram (1809), Krieg auf der Pyren�enhalbinsel, Ru�landfeldzug.
.....................................
Unberittenes Gefechtslinienartillerie-Regiment (Hilfstruppen) / 1. Brigade der Junge Garde-Division der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen eines Unberittenen 
Gefechtslinienartillerie-
Regiments (Hilfstruppen).
......................................
2. Brigade der Junge Garde-Division / Kaiserliche Garde
Kommandeur:
Brigadegeneral|Baron Guye
Portr�t:
Sch�tzen der Jungen Garde
Zusammensetzung:
3. Sch�tzen-Einheit
Oberst Pailhes
3. Voltigeur-Einheit
Oberst Hurel
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Guye wurde bei Waterloo verwundet.|
|
Eins�tze der 3. Sch�tzen-Einheit:|
|
Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze der 3. Voltigeur-Einheit:|
|
Krieg auf der Pyren�enhalbinsel.
...................................
Unberittenes Gefechtslinienartillerie-Regiment (Hilfstruppen) / 2. Brigade der Junge Garde-Division der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen eines Unberittenen 
Gefechtslinienartillerie-
Regiments (Hilfstruppen).
......................................
1. Brigade / Leichte Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Generalmajor Baron Fran�ois-Antoine Lallemand
Portr�t:
Berittene J�ger der Alten Garde
Zusammensetzung:
Berittene J�ger der Alten Garde
Generalmajor Baron Lallemand
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Baron Fran�ois-Antoine Lallemand wurde bei Waterloo verwundet.|
|
Eins�tze:|
|
Marengo (1800), Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland 
(1807), Krieg auf der Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), Wagram 
(1809), Ru�landfeldzug.
Die Leichte Kavallerie der Kaiserlichen Garde war unter den Spitznamen "Die Unbesiegbaren" 
oder "Die Lieblingskinder" bekannt.
.....................................
1. Kompanie des berittenen Artillerieregiments der Alten Garde/ 1. Brigade der Leichten Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Berittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 1. Kompanie des Berittenen 
Artillerieregiments der Alten Garde.
.................................
2. Brigade / Leichte Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Generalmajor Baron de Colbert-Chabanais
Portr�t:
"Rote" Gardelanzenreiter
Zusammensetzung:
Vier Schwadronen "Rote" Gardelanzenreiter
Generalmajor Baron de Colbert-Chabanais
Eine Schwadron polnischer Gardelanzenreiter
Generalmajor Baron de Colbert-Chabanais
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Baron de Colbert wurde am 15. Juni und noch einmal bei Waterloo verwundet.
|
Eins�tze:|
|
Krieg auf der Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), 
Ru�landfeldzug.
......................................
2. Kompanie des Berittenen Artillerieregiments der Alten Garde / 2. Brigade der Leichten Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Franz�sische Berittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des Berittenen 
Artillerieregiments der Alten Garde.
....................................
1. Brigade / Schwere Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Brigadegeneral|Jamin, Marquis von Bermuy
Portr�t:
Berittene Grenadiere der Alten Garde
Zusammensetzung:
Berittene Grenadiere der Alten Garde
Brigadegeneral Jamin
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Bermuy fiel bei Waterloo.|
|
Eins�tze:|
|
Marengo (1800), Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland 
(1807), Krieg auf der Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), Wagram 
(1809), Ru�landfeldzug.
..................................
3. Kompanie des Berittenen Artillerieregiments der Alten Garde / 1. Brigade der Schweren Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Berittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des Berittenen 
Artillerieregiments der Alten Garde.
.................................
2. Brigade / Schwere Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Brigadegeneral|Baron Letort
Portr�t:
"Dragoner der Kaiserin"
Zusammensetzung:
Vier Schwadronen Gardedragoner (der Kaiserin)
Brigadegeneral Baron Letort
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Letort wurde am 15. Juni t�dlich verwundet.|
|
Eins�tze:|
|
Friedland (1807), Krieg auf der Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), 
Wagram (1809), Ru�landfeldzug.
...................................
4. Kompanie des Berittenen Artillerieregiments der Alten Garde / 2. Brigade der Schweren Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Berittene Artillerie der Kaiserlichen Garde
,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 4. Kompanie des Berittenen 
Artillerieregiments der
Alten Garde.
...............................
3. Brigade / Schwere Kavalleriedivision der Kaiserlichen Garde
Kommandeur:
Hauptmann Dyonnet
Zusammensetzung:
Elitegendarmen-Einheit
Hauptmann Dyonnet
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel, Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), 
Ru�landfeldzug.|
|
Die Elitegendarmen erhielten den Spitznamen "Die Unsterblichen", doch nur etwa die H�lfte 
des 
Regiments nahm am 100-Tage-Feldzug teil, die andere H�lfte blieb in Paris.
.................................................
1. Kompanie 2. Unberittenes Artillerieregiment / 3. Reservekorps der Artillerie
Kommandeur: 
Hauptmann Voll�e
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen der 1. Kompanie des 2. Berittenen 
Artillerieregiments.
..........................
1. Brigade / 8. Infanteriedivision
Kommandeur:
Brigadegeneral|Billard
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
15. Leichtes Infanterieregiment
Oberst Brice
23. Gefechtslinienregiment
Oberst Baron Vernier
,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Billard wurde get�tet, als er am 15. Juni von seinem Pferd st�rzte.|
|
Eins�tze des 15. Leichten Infanterieregiments:|
|
Austerlitz (1805), Eckm�hl (1809), Wagram (1809), Borodino (1812).|
|
Eins�tze des 23. Gefechtslinienregiments:|
|
Wagram (1809), Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 8. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Corsin
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
37. Gefechtslinienregiment
Oberst Cornebise
64. Gefechtslinienregiment
Oberst Dubalen
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 37. Gefechtslinienregiments:|
|
Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), Borodino (1812).|
|
Eins�tze des 64. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Aspern-Essling (1809), Wagram (1809), Krieg auf der 
Pyren�enhalbinsel.
........................................
7. Kompanie 6. Unberittenes Artillerieregiment / 8. Infanteriedivision
Kommandeur: 
Hauptmann Chauveau
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 7. Kompanie des 6. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 10. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Gengoult
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
34. Gefechtslinienregiment
Oberst Mouton
88. Gefechtslinienregiment
Oberst Baillon
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 34. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.|
|
Eins�tze des 88. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Aspern-Essling (1809), Wagram (1809), 
Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 10. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Dupeyroux
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
22. Gefechtslinienregiment
Oberst Fantin des Odoards
70. Gefechtslinienregiment
Oberst Baron Maury
2. Fremdenregiment (Schweizer)
Oberst Stoffel
,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 22. Gefechtslinienregiments:|
|
Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 70. Gefechtslinienregiments:|
|
Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 2. Fremdenregiments (Schweizer)|
|
Dieses Regiment wurde 1815 neu aufgestellt.
....................................
18. Kompanie 2. Unberittenes Artillerieregiment / 10. Infanteriedivision
Kommandeur: 
Hauptmann Guerin
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 18. Kompanie des 2. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 11. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Dufour
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
12. Gefechtslinienregiment
Oberst Baron Beaudinot
56. Gefechtslinienregiment
Oberst Delahaye
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Dufour wurde bei Ligny verwundet.|
|
Eins�tze des 12. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram ( 1809), 
Borodino (1812).|
|
Eins�tze des 56. Gefechtslinienregiments:|
|
Eckm�hl (1809), Aspern-Essling (1809), Wagram (1809), Ru�landfeldzug.
........................................
2. Brigade / 11. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Logarde
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
33. Gefechtslinienregiment
Oberst Baron Maire
86. Gefechtslinienregiment
Oberst Pelicier
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 33. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram ( 1809), 
Borodino (1812).|
|
Eins�tze des 86. Gefechtslinienregiments:|
|
Krieg auf der Pyren�enhalbinsel.
....................................
17. Kompanie des 2. Unberittenen Artillerieregiments / 11. Infanteriedivision
Kommandeur:
Hauptmann Cheanne
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 17. Kompanie des 2. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 3. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Dommanget
Portr�t:
9. Berittene J�ger-Einheit
Zusammensetzung:
4. Berittene J�ger-Einheit
Oberst Desmichels
9. Berittene J�ger-Einheit
Oberst Dukermont
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 4. Berittenen J�ger-Einheit:|
|
Wagram (1809).|
|
Eins�tze der 9. Berittenen J�ger-Einheit:|
|
Wagram (1809).
.....................................				
2. Brigade / 3. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Vinot
Portr�t:
12. Berittene J�ger-Einheit
Zusammensetzung:
12. Berittene J�ger-Einheit
Oberst de Grouchy
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral|Baron Vinot wurde bei Ligny verwundet.|
|
Eins�tze der 12. Berittenen J�ger-Einheit:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino (1812).
........................................
4. Kompanie des 2. Berittenen Artillerieregiments / 3. Kavalleriedivision
Kommandeur:
Hauptmann Durnont
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 4. Kompanie des 2. Berittenen 
Artillerieregiments.
....................................
5. Kompanie des 5. Unberittenen Artillerieregiments / 4. Reservekorps der Artillerie
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen der 5. Kompanie des 5. Unberittenen 
Artillerieregiments.
.........................
1. Brigade / 12. Infanteriedivision
Kommandeur:
Brigadegeneral|Chevalier Rome
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
30. Gefechtslinienregiment
Oberst Ramaud
96. Gefechtslinienregiment
Oberst Jean Gougeon
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 30. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino (1812).|
|
Eins�tze des 96. Gefechtslinienregiments:|
|
Ulm (1805), Friedland (1807), Aspern-Essling (1809), Wagram (1809), Krieg auf der 
Pyren�enhalbinsel.
........................................
2. Brigade / 12. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Schaeffer
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
63. Gefechtslinienregiment
Oberst Laurede
6. Leichtes Infanterieregiment
Bataillonskommandeur Gemeau
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 63. Gefechtslinienregiments:|
|
Jena (1806), Eylau (1807), Friedland (1807), Aspern-Essling (1809), Wagram ( 1809), 
Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 6. Leichten Infanterieregiments:|
|
Ulm (1805), Jena (1806), Eylau (1807), Friedland (1807), Aspern-Essling (1809), 
Wagram (1809), Krieg auf der Pyren�enhalbinsel.
....................................
2. Kompanie des 5. Unberittenen Artillerieregiments / 12. Infanteriedivision
Kommandeur:
Hauptmann Fenouillat
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des 5. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 13. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron LeCapitaine
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
59. Gefechtslinienregiment
Oberst Chevalier Laurain
76. Gefechtslinienregiment
Bataillonskommandeur Condamy
,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron LeCapitaine fiel bei Ligny.|
|
Eins�tze des 59. Gefechtslinienregiments:|
|
Ulm (1805), Jena (1806), Eylau (1807), Friedland (1807), Aspern-Essling (1809), 
Wagram (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 76. Gefechtslinienregiments:|
|
Ulm (1805), Jena (1806), Eylau (1807), Friedland (1807), Aspern-Essling (1809), 
Wagram (1809), Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 13. Infanteriedivision
Kommandeur:
Brigadegeneral|Graf Desprez
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
48. Gefechtslinienregiment
Oberst Peraldi
69. Gefechtslinienregiment
Oberst Herv�
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 48. Gefechtslinienregiments:|
|
Austerlitz (1805) Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram (1809), 
Borodino (1812).|
|
Eins�tze des 69. Gefechtslinienregiments:|
|
Ulm (1805), Jena (1806), Eylau (1807), Friedland (1807), Aspern-Essling (1809), 
Wagram (1809), Krieg auf der Pyren�enhalbinsel.
....................................
1. Kompanie 5. Unberittenes Artillerieregiment / 13. Infanteriedivision
Kommandeur:
Hauptmann Saint-Cyr
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 1. Kompanie des 5. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 14. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Hulot de Mazerny
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
9. Leichtes Infanterieregiment
Oberst Baume
111. Gefechtslinienregiment
Oberst Baron Sausset
,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Hulot de Mazerny ersetzte den Grafen von Bourmont als 
Divisionskommandeur, 
als der Graf am 14. Juni mit seinem gesamten Stab desertierte.|
|
Eins�tze des 9. Leichten Infanterieregiments:|
|
Ulm (1805), Friedland (1807), Aspern-Essling (1809), Wagram (1809), Krieg auf der 
Pyren�enhalbinsel.|
|
Eins�tze des 111. Gefechtslinienregiments:|
|
Austerlitz (1805), Auerstadt (1806), Eylau (1807), Eckm�hl (1809), Wagram ( 1809).	
........................................
2. Brigade / 14. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Toussaint
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
44. Gefechtslinienregiment
Oberst Paolini
50. Gefechtslinienregiment
Oberst Lavigne
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 44. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 50. Gefechtslinienregiments:|
|
Ulm (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der Pyren�enhalbinsel.
....................................
3. Kompanie 5. Unberittenes Artillerieregiment / 14. Infanteriedivision
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des 5. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 6. Kavalleriedivision
Kommandeur:
Brigadegeneral|Baron Vallin
Portr�t:
6. Husaren-Einheit 
Zusammensetzung:
6. Husaren-Einheit 
Oberst F�rst von Savoyen-Carignan
8. Berittene J�ger-Einheit
Oberst Schneit
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 6. Husaren-Einheit:|
|
Ulm (1805), Wagram (1809), Ru�landfeldzug.|
|
Eins�tze der 8. Berittenen J�ger-Einheit:|
|
Wagram (1809), Ru�landfeldzug.
.....................................				
2. Brigade / 6. Kavalleriedivision
Kommandeur:
Brigadegeneral|Chevalier Berruyer
Portr�t:
16. Dragoner-Einheit 
Zusammensetzung:
6. Dragoner-Einheit 
Oberst Mugnier
16. Dragoner-Einheit 
Nicht bekannt 
,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Chevalier Berruyer wurde bei Ligny verwundet.|
|
Eins�tze der 6. Dragoner-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.|
|
Eins�tze der 16. Dragoner-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Krieg auf der 
Pyren�enhalbinsel.
........................................
3. Kompanie des 3. Berittenen Artillerieregiments / 6. Kavalleriedivision
Kommandeur:
Hauptmann Tortel
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des 3. Berittenen 
Artillerieregiments.
....................................
6. Reservekorps der Artillerie
Kommandeur:
Generalmajor Baron Noury
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Je eine Batterie der Berittenen und Unberittenen Artillerie.
.............................
4. Kompanie 8. Unberittenes Artillerieregiment / 6. Reservekorps der Artillerie
Kommandeur:
Nicht bekannt 
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 6"-Haubitzen.
.................................
3. Kompanie der Berittenen Gefechtslinienartillerie / Korps der Kaiserlichen Garde
Kommandeur:
Nicht bekannt 
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen.
................................		
1. Brigade / 19. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron de Bellair
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
5. Gefechtslinienregiment
Oberst Rousille
11. Gefechtslinienregiment
Oberst Aubr�e
,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 5. Gefechtslinienregiments:|
|
Wagram (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 11. Gefechtslinienregiments:|
|
Ulm (1805), Wagram (1809), Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 19. Infanteriedivision
Kommandeur:
Brigadegeneral|Chevalier Thevenet
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
27. Gefechtslinienregiment
Oberst Gaudin
84. Gefechtslinienregiment
Oberst Chevalier
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 27. Gefechtslinienregiments:|
|
Ulm (1805), Jena (1806), Eylau (1807), Friedland (1807), Aspern-Essling (1809), 
Wagram (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 84. Gefechtslinienregiments:|
|
Ulm (1805), Wagram (1809), Borodino (1812).
....................................
1. Kompanie des 8. Unberittenen Artillerieregiments / 19. Infanteriedivision
Kommandeur:
Hauptmann Parisot.
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 1. Kompanie des 8. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 20. Infanteriedivision
Kommandeur:
Brigadegeneral|Chevalier Bony
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
5. Leichtes Infanterieregiment
Oberst Curnier
10. Gefechtslinienregiment
Oberst Roussel
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 5. Leichten Infanterieregiments:|
|
Wagram (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 10. Gefechtslinienregiments:|
|
Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 20. Infanteriedivision
Kommandeur:
Brigadegeneral|Graf Tromelin
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
107. Gefechtslinienregiment
Oberst Drout
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze:|
|
Ulm (1805), Wagram (1809), Borodino (1812).
....................................
2. Kompanie des 8. Unberittenen Artillerieregiments / 20. Infanteriedivision
Kommandeur: 
Hauptmann Paquet.
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des 8. Unberittenen 
Artillerieregiments.
.....................................
1. Brigade / 21. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Lafitte
Portr�t:
Leichtes Infanterieregiment
Zusammensetzung:
8. Leichtes Infanterieregiment
Oberst Ricard
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze:|
|
Italien, Wagram (1809), Krieg auf der Pyren�enhalbinsel.
........................................
2. Brigade / 21. Infanteriedivision
Kommandeur:
Brigadegeneral|Baron Penne
Portr�t:
Gefechtslinieninfanterie-Regiment
Zusammensetzung:
65. Gefechtslinienregiment
Bataillonskommandeur Boumard
75. Gefechtslinienregiment
Oberst Mathivet
,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Baron Penne wurde bei Ligny verwundet und fiel bei Wavre.|
|
Eins�tze des 65. Gefechtslinienregiments:|
|
Eckm�hl (1809), Krieg auf der Pyren�enhalbinsel.|
|
Eins�tze des 75. Gefechtslinienregiments:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Krieg auf der Pyren�enhalbinsel.
....................................
3. Kompanie des 8. Unberittenen Artillerieregiments / 21. Infanteriedivision
Kommandeur:
Hauptmann Duverrey.
Portr�t:
Unberittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Kompanie des 8. Unberittenen 
Artillerieregiments.
.....................................
1. Britische Brigade / 1. Infanteriedivision
Kommandeur:
Generalmajor Peregrine Maitland
Portr�t:
1. Unberittene Garde-Einheit
Zusammensetzung
2. Bataillon 1. Unberittene Garde-Einheit
Major Henry Askew
3. Bataillon 1. Unberittene Garde-Einheit 
Major Hon. William Stewart
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Maitland wurde bei Waterloo verwundet.|
|
Eins�tze der 1. Unberittenen Garde-Einheit:|
|
Tanger (1680), Namur (1695), Blenheim (1704), Gibraltar (1704/5), Ramilles (1706), 
Oudenaarde (1708), Malplaquet (1709), Dettingen (1743), Lincelles (1793), 
Pyren�enhalbinsel, 
Coru�a (1809), Barrosa (1811), Nive (1813).
.........................................
2. Britische Brigade / 1. Infanteriedivision
Kommandeur:
Generalmajor Sir John Byng K.C.B.
Portr�t:
"Coldstream"-Garde
Zusammensetzung:
2. Bataillon der "Coldstream"-Garde
Major A.G. Woodford
2. Bataillon 3. Unberittene Garde-Einheit
Major Francis Hepburn
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der "Coldstream"-Garde:|
|
Tanger (1680), Namur (1695), Gibraltar (1704/5), Oudenaarde (1708), Malplaquet (1709), 
Dettingen (1743), Lincelles (1793), �gypten mit der Sphinx, Pyren�enhalbinsel, Talavera 
(1809), 
Barrosa (1811), Fuentes D'Onor (1811), Nive (1813).|
|
Eins�tze der 3. Unberittenen Garde-Einheit:|
|
Namur (1695), Dettingen (1743), Lincelles (1793), �gypten mit der Sphinx, 
Pyren�enhalbinsel, 
Talavera (1809), Barrosa (1811), Fuentes D'Onor (1811), Nive (1813).
...........................................
1. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Oberstleutnant Stephen G. Adye
Portr�t:
Britischer Divisionsartillerie-Offizier
,,,,,,,,,,,,,,,
Ausr�stung:|
|
Eine Batterie K�nigliche (Unberittene) Artillerie.
Eine Batterie Berittene Artillerie der K�niglich-deutschen Legion.
...........................
Brigade von Hauptmann Charles F. Sandham / K�nigliche (Unberittene) Artillerie
Kommandeur:
Hauptmann Charles F. Sandham
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
..................................
2. Berittene Artillerie-Batterie / K�niglich-deutsche Legion
Kommandeur:
Major Kuhlmann
Portr�t:
Berittene Artillerie der KDL
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...........................................
5. Britische Brigade / 3. Infanteriedivision
Kommandeur:
Generalmajor Sir Colin Halkett K.C.B.
Portr�t:
73. Unberittenes (Hochland-) Regiment
Zusammensetzung:
2. Bataillon, 30. Unberittenes Regiment
Major Morris William Bailey
33. Unberittenes Regiment
Oberstleutnant William Keith Elphinstone
2. Bataillon, 69. Unberittenes Regiment
Oberstleutnant Charles Morice
2. Bataillon, 73. Unberittenes (Hochland-) Regiment
Oberstleutnant William George Harris
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Halkett wurde bei Waterloo verwundet.|
|
Eins�tze des 30. Unberittenen Regiments:|
|
Gibraltar (1704/5), Martinique (1794), Kap der Guten Hoffnung (1806), Pyren�enhalbinsel, 
Corunna (1809), Busaco (1809), Salamanca (1812), Badajoz (1812), Vitoria (1813), San 
Sebastin (1813).|
|
Eins�tze des 33. Unberittenen Regiments:|
|
Dettingen (1743), Mysore (1792), Seringapatam (1799), Aligarh (1803), Neu-Delhi (1803), 
Deig (1804), Pyren�enhalbinsel, Corunna (1809).|
|
Eins�tze des 69. Unberittenen Regiments:|
|
St. Lucia (1782), Bourbon (1810), Java (1811), Detroit (1812), Miami (1813), Niagara 
(1813).|
|
Das 2. Bataillon des 69. Unberittenen Regiments erhielt von Nelson den Spitznamen "Die 
alten 
Agamemnons", nachdem eine Abteilung dieser Einheit auf seinem Schiff "Agamemnon" 
gedient 
hatte.|
Das Regiment verlor bei Waterloo seine Regimentsfahne, als es von Franz�sischen 
K�rassieren 
�berrannt wurde.|
|
Eins�tze des 73. Unberittenen (Hochland-) Regiments:|
|
Guadeloupe (1759), Martinique (1762), Habana (1762), Mangalore (1783), 
Pyren�enhalbinsel, 
Corunna (1809), Busaco (1809), Fuentes D'Onor (1811), Pyren�en (1813).
...........................................
2. Brigade der KDL / 3. Infanteriedivision
Kommandeur:
Oberst Baron Ompteda
Portr�t:
Leichtes Bataillon der K�niglich-deutschen Legion
Zusammensetzung:
1. Leichtes Bataillon der K�niglich-deutschen Legion
Oberstleutnant L. Bussche
2. Leichtes Bataillon der K�niglich-deutschen Legion
Major G. Baring
5. Gefechtslinienbataillon der K�niglich-deutschen Legion
Oberstleutnant W.B. Linsingen
8. Gefechtslinienbataillon der K�niglich-deutschen Legion
Major Schr�der
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Oberst Ompteda fiel bei Waterloo.|
|
Eins�tze des 1. Leichten Bataillons der K�niglich-deutschen Legion:|
|
Talavera (1809), Busaco (1810), Fuentes D'Onor (1811), Albufera (1811), Salamanca 
(1812), Vitoria (1813), Tolosa (1813), Bidassoa (1813), Urugne (1813), St. Etienne 
(1814).|
|
Eins�tze des 2. Leichten Bataillons der K�niglich-deutschen Legion:|
|
Talavera (1809), Busaco (1810), Badajoz (1811), Albufera (1811), Fuentes D'Onor 
(1811), Salamanca (1812), Vitoria (1813), San Sebasti n (1813), Bidassoa (1813), Urugne 
(1813), St Etienne (1814).|
|
Dieses Bataillon bildete zu Beginn der Schlacht bei Waterloo die gesamte Garnison von 
La Haye-Saint. 
Es hielt sie, bis ihm etwa um 18 Uhr die Munition ausging.|
|
Eins�tze des 5. Gefechtslinienbataillons der K�niglich-deutschen Legion:|
|
Talavera (1809), Busaco (1810), Fuentes D'Onor (1811), Ciudad Rodrigo (1812), 
Salamanca (1812), Vitoria (1813), Tolosa (1813), San Sebasti n (1813), Bidassoa (1813), 
Urugne (1813), St. Etienne (1814).|
|
Diesem Bataillon wurde beim Vorr�cken in der N�he von La Haye-Saint durch franz�sische 
K�rassiere schwere Verluste zugef�gt. Bei diesem Angriff fiel auch Oberst Ompteda.|
|
Eins�tze des 8. Gefechtslinienbataillons der K�niglich-deutschen Legion:|
|
Castella (1813).|
|
Dieses Bataillon verlor bei der Schlacht von Waterloo seine Fahne.
........................................
1. Hannoversche Brigade / 3. Infanteriedivision
Kommandeur:
Generalmajor Graf Kielmansegge
Portr�t:
Feldbataillon Grubenhagen
Zusammensetzung:
1. Feldbataillon des Herzogs von York
Major Baron B�low
Feldbataillon Grubenhagen
Oberstleutnant Wurmb
Feldbataillon Bremen
Oberstleutnant Langrehr
Feldbataillon Verden
Major de Schkopp
Feldbataillon L�neburg
Oberstleutnant Klencke
Zwei Kompanien des Feldj�gerkorps (Gewehre)
Hauptmann von Reden
,,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Obwohl beide den Titel "Feldbataillon" erhielten, waren die Bataillone von Grubenhagen und 
L�neburg eigentlich Leichte Bataillone.|
|
S�mtliche Kommandeure der Einheiten dieser Brigade wurden entweder bei Quatre Bras oder 
bei Waterloo verwundet oder fielen. 
Die Brigade verlor allein bei Quatre Bras sch�tzungsweise 700 Mann.
......................................
3. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Oberstleutnant J.S. Williamson
Portr�t:
Britischer Divisionsartillerie-Offizier
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Eine Batterie der K�niglichen (Unberittenen) Artillerie und eine Batterie der K�niglich-
deutschen 
Legion.
.............................
Brigade von Major William Lloyd / K�nigliche (Unberittene) Artillerie
Kommandeur:
Major William Lloyd
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
..................................
1. Unberittene Batterie / K�niglich-deutsche Legion
Kommandeur:
Hauptmann A. Cleeves
Portr�t:
Unberittene Artillerie der KDL
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...........................................
1. Holl�ndisch-belgische Brigade / 2. Holl�ndisch-belgische Infanteriedivision
Kommandeur:
Generalmajor W.F. Graf van Bijlandt
Portr�t:
Holl�ndisches Milizbataillon
Zusammensetzung:
27. Holl�ndisches J�gerbataillon
Oberstleutnant J.W. Grunebosch
7. Belgisches Gefechtslinienbataillon
Oberstleutnant F.C. Vandensande
5. Holl�ndisches Milizbataillon
Oberstleutnant J.J. Westenberg
7. Holl�ndisches Milizbataillon
Oberstleutnant H. Singendonck
8. Holl�ndisches Milizbataillon
Oberstleutnant W.A. de Jongh
,,,,,,,,,,,,,,,,,,,,,
.............................
Batterie von Bijveld / 1. Infanteriebrigade / 2. Holl�ndisch-begische Infanteriediv.
Kommandeur:
Hauptmann A. Bijveld
Portr�t:
Holl�ndische Berittene Artillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Holl�ndische Berittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.
...............................
2. Holl�ndisch-belgische Brigade / 2. Holl�ndisch-belgische Infanteriedivision
Kommandeur:
Generalmajor S.K.H. Prinz Bernhard von Sachsen-Weimar
Portr�t:
Oranisch-Nassauer Regiment
Zusammensetzung:
2. Nassauer Regiment
Oberst F.W. van Goedececke
28. Oranisch-Nassauer Regiment
Oberst Herzog von Sachsen-Weimar
Nassauer Freiwilligen-J�gerkompanie
Hauptmann E. Bergmann
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 2. Nassauer Regiment k�mpfte 1806 und 1807 gegen Preu�en und Schweden 
und nahm auch 
an der Schlacht von Jena teil.|
W�hrend des Feldzugs auf der Pyren�enhalbinsel von 1808-13 k�mpfte es gegen 
Gro�britannien und Spanien.
.............................
Batterie von Stievenart / 2. Infanteriebrigade / 2. Holl�ndisch-belgische Infanteriediv.
Kommandeur: 
Hauptmann E.J. Stievenart
Portr�t:
Belgische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Belgische Unberittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.|
|
Diese Batterie wurde bei Quatre Bras von Leichten Lanzenreitern �berrannt und brachte bei 
Waterloo nur zwei ihrer Gesch�tze ins Feld.
...............................
1. Holl�ndisch-belgische Brigade / 3. Holl�ndisch-belgische Infanteriedivision
Kommandeur:
Oberst H. Detmers
Portr�t:
Holl�ndisches Milizbataillon
Zusammensetzung:
35. Belgisches J�gerbataillon
Oberst D.P.J. Arnold
2. Holl�ndisches Gefechtslinienbataillon
Oberstleutnant J. Speelman
4. Holl�ndisches Milizbataillon
Oberst R. van Heeckeren v. Molencate
6. Holl�ndisches Milizbataillon
Oberstleutnant H. A. van Thielen
17. Holl�ndisches Milizbataillon
Oberstleutnant N. van Molz Wieling
19. Holl�ndisches Milizbataillon
Major H. Boellaerdt
,,,,,,,,,,,,,,,,,,,,,,,,,,,
.............................
Bijvelds Batterie / 1. Infanteriebrigade / 3. Holl�ndisch-belgische Infanteriediv.
Kommandeur:
Hauptmann A. Bijveld
Portr�t:
Belgische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Belgische Berittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.
.............................
2. Holl�ndisch-belgische Brigade / 3. Holl�ndisch-belgische Infanteriedivision
Kommandeur:
Generalmajor A.K.J.G. d' Aubr�me
Portr�t:
Holl�ndisches Gefechtslinienbataillon
Zusammensetzung:
36. Belgisches J�gerbataillon
Oberst Ch. Goethals
3. Belgisches Gefechtslinienbataillon
Oberstleutnant E.P. l' Honneux
12. Holl�ndisches Gefechtslinienbataillon
Oberst D.O. Bagelaar
13. Holl�ndisches Gefechtslinienbataillon
Oberstleutnant F.N.L. Aberson
3. Holl�ndisches Milizbataillon
Oberstleutnant F.E. Baron van Lawick v. Pabst
10. Holl�ndisches Milizbataillon
Oberstleutnant G.F. Brade
,,,,,,,,,,,,,,,,,,,,,,,,,,
.............................
Batterie von Lux / 2. Infanteriebrigade / 3. Holl�ndisch-belgische Infanteriediv.
Kommandeur: 
Hauptmann J.H. Lux
Portr�t:
Belgische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Belgische Unberittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.
..................................
8. Britische Brigade / 5. Infanteriedivision
Kommandeur:
Generalleutnant Sir Charles Kempt K.C.B.
Portr�t:
95. Unberittenes Regiment (Gewehre)
Zusammensetzung:
1. Bataillon, 28. Unberittenes Regiment (North Gloucester)
Oberstleutnant Sir Charles P. Belson K.C.B.
32. Unberittenes Regiment (Cornwall)
Major John Hicks
1. Bataillon, 79. Unberittenes Regiment (Cameron-Hochl�nder)
Oberstleutnant Neil Douglas
1. Bataillon, 95. Unberittenes Regiment (Gewehre)
Oberstleutnant Sir Andrew F. Barnard K.C.B.
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalleutnant Kempt wurde bei Waterloo verwundet.|
|
Eins�tze des 28. Unberittenen Regiments (North Gloucester):|
|
Ramilles (1706), Louisberg (1758), Guadeloupe ( 1759), Martinique (1762), Habana 
(1762), St. Lucia (1778), Pyren�enhalbinsel, Coru�a (1809), Talavera (1809), Barrosa 
(1811), 
Albufera (1811), Salamanca (1812), Vitoria (1813), Pyren�en (1813), Nivelle (1813), Nive 
(1813), Orthes (1814), Toulouse (1814).|
|
Eins�tze des 32. Unberittenen Regiments (Cornwall):|
|
Gibraltar (1704/5), Dettingen (1743), St. Lucia (1778), Rolica (1808), Vimiera (1808), 
Pyren�enhalbinsel, Corunna (1809), Salamanca (1812), Pyren�en (1813), Nivelle (1813), 
Nive 
(1813), Orthe (1814).|
|
Eins�tze des 79. Unberittenen Regiments (Cameron-Hochl�nder):|
|
Egmont-op-Zee (1799), Pyren�enhalbinsel, Corunna (1809), Salamanca (1812), Nivelle 
(1813), 
Nive (1813), Toulouse (1814).|
|
Eins�tze des 95. Unberittenen Regiments (Gewehre):|
|
Montevideo (1807), Rolica (1808), Vimiera (1808), Pyren�enhalbinsel, Corunna (1809), 
Talavera 
(1809), Barrosa (1811), Busaco (1809), Fuentes D'Onor (1811), Ciudad Rodrigo (1812), 
Badajoz 
(1812), Salamanca (1812), Vitoria (1813), Pyren�en (1813), Nivelle (1813), Nive (1813), 
Orthe 
(1814), Toulouse (1814).
...........................................
9. Britische Brigade / 5. Infanteriedivision
Kommandeur:
Generalmajor Sir Denis Pack K.C.B.
Portr�t:
42. Unberittenes Regiment (K�nigliche Hochl�nder)
Zusammensetzung:
3. Bataillon, 1. Unberittenes (K�niglich-schottisches) Regiment
Major Colin Campbell
2. Bataillon, 44. Unberittenes Regiment (East Essex)
Oberstleutnant John M. Hamerton
1. Bataillon, 42. Unberittenes Regiment (K�nigliche Hochl�nder)
Oberstleutnant Sir Robert Macara
1. Bataillon, 92. Unberittenes Regiment (Gordon-Hochl�nder)
Oberstleutnant John Cameron
,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Pack wurde bei Waterloo verwundet.|
|
Eins�tze des 1. Unberittenen (K�niglich-schottischen) Regiments:|
|
Namur (1695), Ramilles (1706), Oudenaarde (1708), Malplaquet (1709), Louisberg (1758), 
Habana (1762), Egmont-op-Zee (1799), �gypten mit der Sphinx, Pyren�enhalbinsel, 
Corunna 
(1809), Talavera (1809), Busaco (1809), Salamanca (1812), Vitoria (1813), San Sebasti n 
(1813), Niagara (1813), Nive (1813).|
|
Eins�tze des 44. Unberittenen Regiments (East Essex):|
|
Habana (1762), Gibraltar (1779), Pyren�enhalbinsel, Badajoz (1812), Bladensburg (1814).|
|
Eins�tze des 42. Unberittenen Regiments (K�nigliche Hochl�nder):|
|
Guadeloupe (1759), Martinique (1762), Habana (1762), Mangalore (1783), 
Pyren�enhalbinsel, 
Corunna (1809), Busaco (1809), Fuentes D'Onor (1811), Pyren�en (1813), Nivelle (1813), 
Nive 
(1813), Orthes (1814), Toulouse (1814).|
|
Eins�tze des 92. Unberittenen Regiments (Gordon-Hochl�nder):|
|
Mysore (1792), Seringapatam (1799), Egmont-op-Zee (1799), Mundora (1801), Corunna 
(1809), Fuentes D'Onor (1811), Almaraz (1811), Vitoria (1813), Pyren�en (1813), Nive 
(1813), 
Orthe (1814).
...........................................
5. Hannoversche Brigade / 5. Infanteriedivision
Kommandeur:
Oberst von Vincke
Portr�t:
Hannoversches Landwehr-Bataillon
Zusammensetzung:
Landwehr-Bataillon Giffhorn
Major G. von Hammerstein
Landwehr-Bataillon Hameln
Major von Strube
Landwehr-Bataillon Hildesheim
Major von Reden
Landwehr-Bataillon Peine
Major Westphalen
,,,,,,,,,,,,,,,,,,,,,,,,
......................................
5. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Major A. Heise
Portr�t:
Offizier der britischen Divisionsartillerie
,,,,,,,,,,,,,,,
Ausr�stung:|
|
Eine Batterie der K�niglichen (Unberittenen) Artillerie und eine Batterie der Hannoverschen 
Unberittenen Artillerie.
.............................
Brigade von Major Tomas Rogers / K�nigliche (Unberittene) Artillerie
Kommandeur:
Major Tomas Rogers
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...............................
Batterie von Braun / Hannoversche Unberittene Artillerie
Kommandeur:
Hauptmann Braun
Portr�t:
Hannoversche Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Aufgrund von Verlusten wurden diese Waffen bei Waterloo durch f�nf 6-Pfund-Gesch�tze 
ersetzt.
...........................................
10. Britische Brigade / 6. Infanteriedivision
Kommandeur:
Generalmajor Sir John Lambert K.C.B.
Portr�t:
40. Unberittenes Regiment
Zusammensetzung:
1. Bataillon, 4. Unberittenes Regiment (des K�nigs)
Oberstleutnant Francis Brooke
1. Bataillon, 27. Unberittenes Regiment (Inniskilling)
Hauptmann John Hare
1. Bataillon, 40. Unberittenes Regiment
Major Arthur R. Heyland
2. Bataillon, 81. Unberittenes Regiment
Nicht bekannt 
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 4. Unberittenen Regiments (des K�nigs):|
|
Namur (1695), Gibraltar (1704/5), Guadeloupe (1759), St. Lucia (1778), Pyren�enhalbinsel, 
Corunna (1809), Badajoz (1812), Salamanca (1812), Vitoria (1813), San Sebasti n (1813), 
Nive 
(1813), Bladensburg (1814).|
|
Eins�tze des 27. Unberittenen Regiments (Inniskilling):|
|
Martinique (1762), Habana (1762), St. Lucia (1778), Maida (1806), Pyren�enhalbinsel, 
Badajoz 
(1812), Salamanca (1812), Vitoria (1813), Pyren�en (1813), Nivelle (1813), Orthes (1814), 
Toulouse (1814).|
|
Eins�tze des 40. Unberittenen Regiments:|
|
Louisberg (1758), Martinique (1762), Habana (1762), St. Lucia (1778), Montevideo 
(1807), Rolica (1808), Viemera (1808), Pyren�enhalbinsel, Corunna (1809), Talavera 
(1809), 
Badajoz (1812), Pyren�en (1813), Nivelle (1813), Orthe (1814), Toulouse (1814).|
|
Eins�tze des 81. Unberittenen Regiments:|
|
Maida (1806), Pyren�enhalbinsel, Tarifa (1811), San Sebastin (1813).
...........................................
4. Hannoversche Brigade / 6. Infanteriedivision
Kommandeur:
Oberst Best
Portr�t:
Hannoversches Landwehr-Bataillon 
Zusammensetzung:
Landwehr-Bataillon Verden
Major de Decken
Landwehr-Bataillon L�neburg
Oberstleutnant de Ramdohr
Landwehr-Bataillon M�nden
Major de Schmidt
Landwehr-Bataillon Osterode
Major Baron Reden
,,,,,,,,,,,,,,,,,,,,,,,,,,,
......................................
6. Artillerie-Einheit der Infanteriedivision
Kommandeur:
Oberstleutnant Bruckmann
Portr�t:
Offizier der britischen Divisionsartillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Zwei Batterien der K�niglichen (Unberittenen) Artillerie.
..............................
Brigade von Hauptmann John Sinclair / K�nigliche (Unberittene) Artillerie
Kommandeur:
Hauptmann James Sinclair
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...............................
Brigade von Major George Unett / K�nigliche (Unberittene) Artillerie
Kommandeur:
Major George Unett
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...........................................
Britische Reserveartillerie
Kommandeur:
Nicht bekannt 
Portr�t:
Offizier der britischen Divisionsartillerie
,,,,,,,,,,,,,
Ausr�stung:|
|
Drei Batterien der Schweren Artillerie und zwei Batterien der K�niglichen (Berittenen) 
Artillerie.
..............................		
Brigade von Hauptmann Ilbert / K�nigliche (Unberittene) Artillerie
Kommandeur:
Hauptmann Ilbert
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 18-Pfund-Gesch�tze.|
|
Die Gesch�tze dieser Batterie wurden w�hrend des Feldzuges nicht eingesetzt. Ein Teil 
dieser 
Brigade war jedoch bei Waterloo damit beauftragt, die Munition f�r kleinere Schu�waffen zu 
verteilen.
..........................................
Brigade von Hauptmann Thomas Hutchesson / K�nigliche (Unberittene) Artillerie
Kommandeur:
Hauptmann Thomas Hutchesson
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 18-Pfund-Gesch�tze.|
|
Die Gesch�tze dieser Batterie wurden w�hrend des Feldzuges nicht eingesetzt. Ein Teil 
dieser 
Brigade war jedoch bei Waterloo damit beauftragt, die Munition f�r kleinere Schu�waffen zu 
verteilen.
..............................
Brigade von Hauptmann Morrison / K�nigliche (Unberittene) Artillerie
Kommandeur:
Hauptmann Morrison
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 18-Pfund-Gesch�tze.|
|
Diese Gesch�tze wurden im 100-Tage-Feldzug nicht eingesetzt.
..............................
Truppen von Oberstleutnant Sir Hew D. Ross / K�nigliche (Berittene) Artillerie
Kommandeur:
Oberstleutnant Sir Hew D. Ross
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Diese Truppe war unter dem Namen "The Chestnut Troop" (Die Kastanienbraunen) bekannt.
...............................
Truppen von Major George Beane / K�nigliche (Berittene) Artillerie
Kommandeur:
Major George Beane
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Major Beane fiel in der Schlacht bei Waterloo.
...........................
Avantgarde-Bataillon
Kommandeur:
Major von Rauschenplatt
Portr�t:
Avantgarde-Bataillon
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das Avantgarde-Bataillon verlor bei Quatre Bras mehr als 200 Mann.
...............................
Braunschweiger Leichte Brigade
Kommandeur:
Generalmajor Olfermans
Portr�t:
Braunschweiger Leichte Brigade
,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Leichte Brigade setzte sich aus einem Gardebataillon und drei Bataillonen der Leichten 
Infanterie zusammen. Die Leichte
Brigade verlor bei Quatre Bras mehr als 200 Mann.
................................
Braunschweiger Gefechtslinienbrigade 
Kommandeur:
Oberstleutnant von Buttler
Portr�t:
Braunschweiger Gefechtslinienbataillon
,,,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Gefechtslinienbrigade bestand aus drei Bataillonen der Leichten Infanterie. Insgesamt 
verlor 
die Gefechtslinienbrigade bei Quatre Bras fast 400 Mann.
..................................
Braunschweiger Kavalleriebrigade 
Kommandeur:
Major von Cramm
Portr�t:
Braunschweiger Husaren
,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Braunschweiger Kavalleriebrigade setzte sich aus einem Husarenregiment und einer 
Ulanenschwadron zusammen. Die Kavalleriebrigade war aus praktischen Gr�nden w�hrend 
des 
Feldzugs Teil der Organisationsstruktur der Gefechtslinienbrigade.
............................................
Braunschweiger Berittene Artillerie / Braunschweiger Kontingent
Kommandeur: 
Hauptmann von Heinemann
Portr�t:
Braunschweiger Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Acht 6-Pfund-Gesch�tze.
...............................
Braunschweiger Unberittene Artillerie / Braunschweiger Kontingent
Kommandeur: 
Major von Moll
Portr�t:
Braunschweiger Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Acht 6-Pfund-Gesch�tze.
.................................
Nassauer Reservekontingent
Kommandeur:
Generalmajor A.H.E. von Kruse
Portr�t:
Nassauer Gefechtslinie
,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das Nassauer Reservekontingent setzte sich aus zwei Gefechtslinien- und einem Landwehr-
Bataillon des 1. Nassauer Regiments zusammen. Dieses Regiment k�mpfte in den Jahren 
1806/7 gegen Schweden und Preu�en, 
1809 gegen �sterreich und w�hrend der Feldz�ge auf der Pyren�enhalbinsel gegen 
Gro�britannien und Spanien.
...................................
3. Britische Brigade / 2. Infanteriedivision
Kommandeur:
Generalmajor Frederick Adam
Portr�t:
71. Unberittenes (Hochland-) Regiment
Zusammensetzung:
1. Bataillon, 52. Unberittenes Regiment (Leichte Infanterie)
Oberstleutnant Sir John Colborne K.C.B.
1. Bataillon, 71. Unberittenes (Hochland-) Regiment (Leichte Infanterie)
Oberstleutnant Thomas Reynell
2. Bataillon, 95. Unberittenes Regiment (Gewehre)
Major Amos G. Northcott
3. Bataillon, 95. Unberittenes Regiment (Gewehre)
Major John Ross
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Adam wurde in der Schlacht bei Waterloo verwundet.|
|
Eins�tze des 52. Unberittenen Regiments (Leichte Infanterie):|
|
Quebec (1759), Martinique (1762), Habana (1762), Vimiera (1808), Pyren�enhalbinsel, 
Corunna 
(1809), Busaco (1809), Fuentes D'Onor (1811), Ciudad Rodrigo (1812), Badajoz (1812), 
Vitoria 
(1813), Nivelle (1813), Nive (1813), Toulouse (1814).|
|
Eins�tze des 71. Unberittenen (Hochland-) Regiments (Leichte Infanterie):|
|
Carnatic (1791), Gibraltar (1779), Sholingghur (1781), Mysore (1792), Seringapatam 
(1799), Assaye (1803), Kap der Guten Hoffnung (1806), Rolica (1808), Vimiera (1808), 
Pyren�enhalbinsel, Busaco (1809), Fuentes D'Onor (1811), Almaraz (1811), Ciudad Rodrigo 
(1812), Badajoz (1812), Vitoria (1813), Pyren�en (1813), Nive (1813), Orthe (1814).|
|
Eins�tze des 95. Unberittenen Regiments (Gewehre):|
|
Montevideo (1807), Rolica (1808), Vimiera (1808), Pyren�enhalbinsel, Corunna (1809), 
Talavera 
(1809), Barrosa (1811), Busaco (1809), Fuentes D'Onor (1811), Ciudad Rodrigo (1812), 
Badajoz 
(1812), Salamanca (1812), Vitoria (1813), Pyren�en (1813), Nivelle (1813), Nive (1813), 
Orthe 
(1814), Toulouse (1814).
...........................................
1. Brigade der KDL / 2. Infanteriedivision
Kommandeur:
Oberst G.C.A. du Plat
Portr�t:
Gefechtslinienbataillon der K�niglich-deutschen Legion
Zusammensetzung:
1. Gefechtslinienbataillon der K�niglich-deutschen Legion
Major W. Robertson
2. Gefechtslinienbataillon der K�niglich-deutschen Legion
Oberstleutnant J.C. von Schr�der
3. Gefechtslinienbataillon der K�niglich-deutschen Legion
Oberstleutnant F. de Wissell
4. Gefechtslinienbataillon der K�niglich-deutschen Legion
Major F. Reb
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Oberst du Plat fiel in der Schlacht bei Waterloo.|
|
Eins�tze des 1. Gefechtslinienbataillons der K�niglich-deutschen Legion:|
|
Talavera (1809), Busaco (1810), Fuentes D'Onor, Ciudad Rodrigo (1812), Salamanca 
(1812), Pyren�en (1813), San Sebasti n (1813), Bidassoa (1813), Urugne (1813), St. 
Etienne 
(1814).|
|
Eins�tze des 2. Gefechtslinienbataillons der K�niglich-deutschen Legion:|
|
Grijo (1809), Talavera (1809), Busaco (1810), Fuentes D'Onor (1811), Ciudad Rodrigo 
(1812), Salamanca (1812), Osma (1813), Tolosa (1813), San Sebasti n (1814), Urugne 
(1813), 
St. Etienne (1814).|
|
Eins�tze des 3. Gefechtslinienbataillons der K�niglich-deutschen Legion:|
|
Castalla (1813), St. Etienne (1814).|
|
Eins�tze des 4. Gefechtslinienbataillons der K�niglich-deutschen Legion:|
|
Castalla (1813), Talavera (1809).
...................................
3. Hannoversche Brigade / 2. Infanteriedivision
Kommandeur:
Oberst William Halkett
Portr�t:
Hannoversche Landwehr
Zusammensetzung:
Landwehr-Bataillon Bremerv�rde
Oberstleutnant Schulenberg
Landwehr-Bataillon Osnabr�ck
Major Graf M�nster
Landwehr-Bataillon Quackenbr�ck
Major Baron C.W. von dem Hunefeldt
Landwehr-Bataillon Salzgitter
Major von Hammerstein
,,,,,,,,,,,,,,,,,,,,,,,
......................................
2. Artillerie-Einheit der Infanteriedivision 
Kommandeur:
Oberstleutnant Charles Gold
Portr�t:
Britischer Offizier der Divisionsartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Eine Batterie der K�niglichen (Unberittenen) Artillerie und eine Batterie der Berittenen 
Artillerie 
der K�niglich-deutschen 
Legion.
............................
Brigade von Hauptmann Samuel Bolton / K�nigliche (Unberittene) Artillerie
Kommandeur:
Hauptmann Samuel Bolton
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Hauptmann Bolton fiel in der Schlacht bei Waterloo.
.......................................
1. Berittene Artilleriebatterie der K�niglich-deutschen Legion
Kommandeur: 
Major A. Sympher
Portr�t:
Berittene Artillerie der KDL
,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Major Sympher wurde bei Waterloo verwundet.
...........................................
4. Britische Brigade / 4. Infanteriedivision
Kommandeur:
Oberst Mitchell
Portr�t:
23. Unberittenes Regiment
Zusammensetzung:
3. Bataillon, 14. Unberittenes Regiment
Major Francis S. Tidy
1. Bataillon, 23. Unberittenes Regiment
Oberstleutnant Sir Henry W. Ellis K.C.B.
1. Bataillon, 51. Unberittenes Regiment (Leichte Infanterie)
Oberstleutnant Hugh Henry Mitchell
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 14. Unberittenen Regiments:|
|
Namur (1695).|
|
Eins�tze des 23. Unberittenen Regiments:|
|
Namur (1695), Blenheim (1704), Ramilles (1706), Oudenaarde (1708), Malplaquet (1709), 
Dettingen (1743), Minden (1759), Martinique (1809), Pyren�enhalbinsel, Corunna (1809), 
Albufera (1811), Badajoz (1812), Salamanca (1812), Vitoria (1813), Pyren�en (1813), 
Nivelle 
(1813), Orthe (1814), Toulouse (1814).|
|
Eins�tze des 51. Unberittenen Regiments (Leichte Infanterie):|
|
Minden (1759), Pyren�enhalbinsel, Corunna (1809), Salamanca (1812), Vitoria (1813), 
Pyren�en 
(1813), Nivelle (1813), Orthe (1814).
...........................................
6. Britische Brigade / 4. Infanteriedivision
Kommandeur:
Generalmajor Johnstone
Portr�t: 91. Unberittenes Regiment
Zusammensetzung:
2. Bataillon, 35. Unberittenes Regiment
Major C. M'Allister
1. Bataillon, 54. Unberittenes Regiment
Oberstleutnant J. Graf Waldergrave
1. Bataillon, 59. Unberittenes Regiment
Oberstleutnant H. Austin
1. Bataillon, 91. Unberittenes Regiment (Argyllshire)
Oberstleutnant Sir W. Douglas K.C.B.
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze des 35. Unberittenen Regiments:|
|
Gibraltar (1704/5), Louisberg (1758), Guadeloupe (1759), Martinique (1762), Habana 
(1762), St. Lucia (1778), Laswaree (1803), Maida (1806).|
|
Eins�tze des 54. Unberittenen Regiments:|
|
Martinique (1794), Pyren�enhalbinsel.|
|
Eins�tze des 59. Unberittenen Regiments:|
|
Kap der Guten Hoffnung (1806), Corunna (1809), Java (1811), Vitoria (1813),
San Sebasti n (1813), Nive (1813), Pyren�enhalbinsel.|
|
Eins�tze des 91. Unberittenen Regiments (Argyllshire):|
|
Kap der Guten Hoffnung (1806), Rolica (1808), Vimiera (1808), Pyren�enhalbinsel, Corunna 
(1809), Pyren�en (1813), Nivelle (1813), Nive (1813), Orthe (1814), Toulouse (1814).
..........................................
6. Hannoversche Brigade / 4. Infanteriedivision
Kommandeur:
Generalmajor Sir James Lyon K.C.B.
Portr�t:
Hannoversches Landwehr-Bataillon
Zusammensetzung:
Feldbataillon Launberg
Oberstleutnant Benort
Feldbataillon Calnberg
Major Schnehen
Landwehr-Bataillon Hoya
Oberstleutnant Grote
Landwehr-Bataillon Nieuberg
Major Hollenfer
Landwehr-Bataillon Bentheim
Major Croupp
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
......................................
;Korps von Prinz Frederick der Niederlande
Westindische Brigade
Kommandeur:
Generalleutnant C.H.W. Anthing
Portr�t:
Holl�ndisch-indische Brigade
Zusammensetzung:
5. Au�enindisches Regiment
Generalmajor G.M. Busman
Flankenbataillon
Oberstleutnant W. Schenck
10. Westindisches J�ger-Bataillon
Oberst H.W. Rancke
11. Westindisches J�ger-Bataillon
Oberstleutnant F. Knotzer
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
............................
Batterie von Riesz / Westindische Brigade
Kommandeur: 
Hauptmann C.J. Riesz
Portr�t:
Holl�ndische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 3. Unberittenen Artilleriebatterie.
..............................
1. Brigade / 1. Holl�ndisch-belgische Infanteriedivision
Kommandeur:
Generalmajor F. d' Hauw
Portr�t:
Holl�ndisches Miliz-Bataillon
Zusammensetzung:
16. Holl�ndisches J�ger-Bataillon
Oberstleutnant S.R. van Hulstein
4. Belgisches Gefechtslinienbataillon
Oberstleutnant E. de Man
6. Holl�ndisches Gefechtslinienbataillon
Oberstleutnant P.A. Twent
9. Holl�ndisches Miliz-Bataillon
Oberstleutnant J.J. Simons
14. Holl�ndisches Miliz-Bataillon
Oberstleutnant W. Poolman
15. Holl�ndisches Miliz-Bataillon
Oberstleutnant P.C. Colthoff
,,,,,,,,,,,,,,,,,,,,,,,,,
.............................
2. Brigade / 1. Holl�ndisch-belgische Infanteriedivision
Kommandeur:
Generalmajor D.J. de Eerens
Portr�t:
Holl�ndisches Miliz-Bataillon
Zusammensetzung:
18. Holl�ndisches J�ger-Bataillon
Oberstleutnant Prinz van Aremberg
1. Belgisches Gefechtslinienbataillon
Oberstleutnant W. Kuijek
1. Holl�ndisches Miliz-Bataillon
Oberstleutnant F.A. Guicherit
2. Holl�ndisches Miliz-Bataillon
Oberstleutnant A.W. Senn van Bazel
18. Holl�ndisches Miliz-Bataillon
Oberstleutnant F.W. van Ommeren
,,,,,,,,,,,,,,,,,,,,,,,,,,,,
.............................
Batterie von Wijnands / 2. Infanteriebrigade / 1. Holl�ndisch-belgische Infanteriediv.
Kommandeur:
Hauptmann P. Wijnands
Portr�t:
Holl�ndische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Holl�ndische Unberittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.
..................................
;Kavalleriekorps
1. Kavalleriebrigade
Kommandeur:
Generalmajor Lord Edward Somerset K.C.B.
Portr�t:
Leibwache
Zusammensetzung:
1. Leibwache
Oberstleutnant Samuel Ferrior
2. Leibwache
Oberstleutnant Hon. Edward P. Lygon
K�nigliche Berittene Garde ("Die Blauen")
Oberstleutnant Sir Robert C. Hill
1. Dragonergarde
Oberstleutnant William Fuller
,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 1. Leibwache:|
|
Dettingen (1743), Pyren�enhalbinsel.|
|
Eins�tze der 2. Leibwache:|
|
Dettingen (1743), Pyren�enhalbinsel.|
|
Eins�tze der K�niglichen Berittenen Garde ("Die Blauen"):|
|
Dettingen (1743), Warburg (1760), Beaumont (1794), Willems (1794), Pyren�enhalbinsel.|
|
Eins�tze der 1. Dragonergarde:|
|
Blenheim (1704), Ramilles (1706), Oudenaarde (1708), Malplaquet (1709), Dettingen 
(1743), 
Warburg (1760), Beaumont (1794), Pyren�enhalbinsel.
...........................
2. Kavalleriebrigade
Kommandeur:
Generalmajor Hon. Sir William Ponsonby K.C.B.
Portr�t:
6. Dragoner-Einheit (Inniskilling)
Zusammensetzung:
1. (K�nigliche) Dragoner-Einheit
Oberstleutnant Arthur B. Clifton
2. Dragoner-Einheit (K�niglich-schottische "Greys")
Oberstleutnant James I. Hamilton
6. Dragoner-Einheit (Inniskilling)
Oberstleutnant Joseph Muter
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Ponsonby fiel in der Schlacht bei Waterloo.|
|
Eins�tze der 1. (K�niglichen) Dragoner-Einheit:|
|
Tanger (1662-80), Dettingen (1743), Warburg (1760), Beaumont (1794), Willems 
(1794), Fuentes D'Onor (1811).|
|
Eins�tze der 2. Dragoner-Einheit (K�niglich-schottische "Greys"):|
|
Blenheim (1704), Ramilles (1706), Oudenaarde (1708), Malplaquet (1709), Dettingen 
(1743), Warburg (1760), Willems (1794).|
|
Eins�tze der 6. Dragoner-Einheit (Inniskilling):|
|
Dettingen (1743), Warburg (1760), Willems (1794).
...................................
3. Kavalleriebrigade
Kommandeur:
Generalmajor Sir William B. Dornberg
Portr�t:
1. Leichte Dragoner-Einheit der KDL
Zusammensetzung:
23. Leichte Dragoner-Einheit
Oberstleutnant Graf von Portarlington
1. Leichte Dragoner-Einheit der K�niglich-deutschen Legion
Oberstleutnant J. B�low
2. Leichte Dragoner-Einheit der K�niglich-deutschen Legion
Oberstleutnant C. de Jonquieres
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Dornberg wurde bei Waterloo verwundet.|
|
Die 23. Leichte Dragoner-Einheit wurde erstmals 1781 in Indien eingesetzt und im Jahre 
1783 in 
19. Einheit umbenannt. Eine neue 23. Einheit wurde 1794 aufgestellt und 1802 wieder 
aufgel�st, 
als die 26. Einheit diese Bezeichnung erhielt und von da an auf der Pyren�enhalbinsel 
diente.|
|
Eins�tze der 1. Leichte Dragoner-Einheit der K�niglich-deutschen Legion:|
|
Pyren�enhalbinsel.|
|
Eins�tze der 2. Leichte Dragoner-Einheit der K�niglich-deutschen Legion:|
|
Vitoria (1813), Pyren�enhalbinsel.
...............................................
4. Kavalleriebrigade
Kommandeur:
Generalmajor Sir John O. Vandeleur K.C.B.
Portr�t:
16. Leichte Dragoner-Einheit
Zusammensetzung:
11. Leichte Dragoner-Einheit
Oberstleutnant James Wallace Sleigh
12. Leichte Dragoner-Einheit (des Prinzen von Wales) 
Oberstleutnant Hon. F.C. Ponsonby
16. Leichte Dragoner-Einheit
Oberstleutnant James Hay
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 11. Leichte Dragoner-Einheit:|
|
Beaumont (1794), Willems (1794), �gypten mit der Sphinx, Salamanca (1812), 
Pyren�enhalbinsel.|
|
Eins�tze der 12. Leichte Dragoner-Einheit (Prinz von Wales):|
|
�gypten mit der Sphinx, Salamanca (1812), Pyren�enhalbinsel.|
|
Eins�tze der 16. Leichte Dragoner-Einheit:|
|
Beaumont (1794), Willems (1794), Talavera (1809), Fuentes D'Onor (1811), Salamanca 
(1812), Vitoria (1813), Pyren�enhalbinsel.
...............................................
5. Kavalleriebrigade
Kommandeur:
Generalmajor Sir Colquhoun Grant K.C.B.
Portr�t:
15. Husaren-Einheit
Zusammensetzung:
7. Husaren-Einheit (der K�nigin)
Oberstleutnant Sir Edward Kerrison
15. Husaren-Einheit (des K�nigs)
Oberstleutnant Leighton C. Dalrymple
2. Husaren-Einheit der K�niglich-deutschen Legion
Oberstleutnant Linsingen
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Generalmajor Grant wurde bei Waterloo verwundet.|
|
Eins�tze der 7. Husaren-Einheit (der K�nigin):|
|
Dettingen (1743), Warburg (1760), Beaumont (1794), Willems (1794), Orthes (1814), 
Pyren�enhalbinsel.|
|
Eins�tze der 15. Husaren-Einheit (des K�nigs):|
|
Emsdorff (1760), Villers-en-Cauchies (1794), Willems (1794), Egmont-op-Zee (1799), 
Sahagun (1808), Pyren�enhalbinsel, Vitoria (1813).|
|
Eins�tze der 2. Husaren-Einheit der K�niglich-deutschen Legion:|
|
Barossa (1811), Los Santos (1811), Salamanca (1812), Riveira (1812).
...............................................
6. Kavalleriebrigade
Kommandeur:
Generalmajor Sir Hussey Vivian K.C.B.
Portr�t:
18. Husaren-Einheit
Zusammensetzung:
10. Husaren-Einheit (Prinz von Wales)
Oberstleutnant George Quentin
18. Husaren-Einheit
Oberstleutnant Hon. Henry Murray
1. Husaren-Einheit der K�niglich-deutschen Legion
Oberstleutnant A. Wissell
,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Eins�tze der 10. Husaren-Einheit (Prinz von Wales):|
|
Warburg (1760), Pyren�enhalbinsel.|
|
Eins�tze der 18. Husaren-Einheit:|
|
Pyren�enhalbinsel.|
|
Eins�tze der 1. K�niglich-deutschen Husaren-Einheit:|
|
Talavera (1809), Salamanca (1812), Pyren�enhalbinsel, Pyren�en (1813), Toulouse (1814).
...............................................
7. Kavalleriebrigade
Kommandeur:
Oberst Sir F. Arenschildt K.C.B.
Portr�t:
3. Husaren-Einheit der K�niglich-deutschen Legion
Zusammensetzung:
13. Leichte Dragoner-Einheit
Oberstleutnant Patrick Doherty
3. Husaren-Einheit der K�niglich-deutschen Legion
Oberstleutnant F.L. Meyer
,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
 Eins�tze der 13. Leichte Dragoner-Einheit:|
|
Albufera (1811), Vitoria (1813), Orthes (1814), Toulouse (1814), Pyren�enhalbinsel.|
|
Eins�tze der 3. Husaren-Einheit der K�niglich-deutschen Legion:|
|
Pyren�enhalbinsel.
...............................................
Hannoversche Kavalleriebrigade 
Kommandeur:
Oberst Baron Estorff
Portr�t:
Husaren des Herzogs von Cumberland 
Zusammensetzung:
Husaren des Prinzregenten
Oberstleutnant Graf Kielmansegge
Bremer und Verdener Husaren
Oberst Bussche
Husaren des Herzogs von Cumberland
Nicht bekannt
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die Anwesenheit und Wirksamkeit der oben aufgef�hrten Einheiten in dem 100-Tage-Feldzug 
ist 
schwer einzusch�tzen. Es ist bekannt, da� die Husaren des Herzogs von Cumberland sich 
bei 
Waterloo blamierten, als sie sich trotz wiederholter Befehle weigerten, den Gegner 
anzugreifen, 
und anschlie�end davonliefen.
...............................................
K�nigliche (Berittene) Artillerie des Kavalleriekorps
Kommandeur:
Oberstleutnant A. Macdonald
Portr�t:
Britischer Offizier der Divisionsartillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs Truppen der K�niglichen (Berittenen) Artillerie mit einer Batterie Congreave-Raketen.
..............................
Truppe von Major Bull / K�nigliche (Berittene) Artillerie
Kommandeur:
Major Bull
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 5 1/2"-Haubitzen.|
|
Diese Truppe er�ffnete angeblich bei Waterloo von Wellingtons Position aus das Feuer. Es 
gelang ihr, drei Soldaten des 1. Leichten Infanterieregiments der Prinz Jerome-Division zu 
t�ten.
...............................
Truppe von Oberstleutnant James Webber Smith / K�nigliche (Berittene) Artillerie
Kommandeur:
Oberstleutnant James Webber Smith
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 6-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
..............................
Truppe von Oberstleutnant Sir Robert Gardiner K.C.B. / K�nigliche (Berittene) Artillerie
Kommandeur:
Oberstleutnant Sir Robert Gardiner K.C.B
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 6-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Diese Truppe deckte beim R�ckzug von Quatre Bras nach Mont Saint-Jean die 17. Einheit 
und 
nahm an der Schlacht von Waterloo teil.
...............................
Truppe von Hauptmann Edward C. Whinyate / K�nigliche (Berittene) Artillerie
Kommandeur:
Hauptmann Edward C. Whinyate
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 6-Pfund-Gesch�tze und ein Teil der Raketen.|
|
Diese Truppe feuerte in der Schlacht von Waterloo au�er der gew�hnlichen Munition 52 
Raketen ab. 
...............................
Truppe von Hauptmann Alexander C. Mercer / K�nigliche (Berittene) Artillerie
Kommandeur:
Hauptmann Alexander C. Mercer
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...............................
Truppe von Major William Norman Ramsay / K�nigliche (Berittene) Artillerie
Kommandeur:
Major William Norman Ramsay
Portr�t:
K�nigliche (Berittene) Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.|
|
Major Ramsay fiel in der Schlacht von Waterloo.
..................................
Schwere Brigade / Holl�ndisch-belgische Kavalleriedivision
Kommandeur:
Generalmajor A.D. Trip
Portr�t:
1. Holl�ndische Karabinier-Einheit
Zusammensetzung:
1. Holl�ndische Karabinier-Einheit
Oberstleutnant L.P. Coenegracht
2. Belgische Karabinier-Einheit
Oberst J.B. de Bruijn
3. Holl�ndische Karabinier-Einheit
Oberstleutnant C.M. Lechleitner
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
...............................
1. Leichte Kavalleriebrigade / Holl�ndisch-belgische Kavalleriedivision
Kommandeur:
Generalmajor Baron de Ghigny
Portr�t:
4. Einheit der Holl�ndischen Leichten Dragoner
Zusammensetzung:
4. Einheit der Holl�ndischen Leichten Dragoner
Oberstleutnant J.C. Reno
8. Belgische Husaren-Einheit
Oberstleutnant Baron L.L. Davivier
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
..............................
2. Leichte Kavalleriebrigade / Holl�ndisch-belgische Kavalleriedivision
Kommandeur:
Generalmajor J.B. van Merlen
Portr�t:
6. Holl�ndische Husaren-Einheit
Zusammensetzung:
5. Einheit der belgischen Leichten Dragoner
Leutnant E.A.J.G. de Merex
6. Holl�ndische Husaren-Einheit
Oberstleutnant W.F. Bereel
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Diese Brigade verlor bei Quatre Bras mehr als 100 Soldaten.
...............................
Angegliederte Artillerie / Holl�ndisch-belgische Kavalleriedivision
Kommandeur:
Siehe Anmerkungen zur Organisation
Portr�t:
Belgische Berittene Artillerie
,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Diese Batterie setzte sich aus zwei verschiedenen halben Batterien zusammen.|
Eine H�lfte der Batterie f�hrte drei 6-Pfund-Gesch�tze und eine 5 1/2"-Haubitze mit. Sie 
wurde 
von Hauptmann A.A. Petter befehligt. Die andere H�lfte besa� ebenfalls drei 6-Pfund-
Gesch�tze 
und eine 5 1/2"-Haubitze und wurde von Hauptmann A.R.A. Gey van Pittius befehligt.
.............................
;Preu�ische
;1. Infanteriebrigade / 1. Korps
12. Infanterieregiment
Kommandeur:
Oberstleutnant Othengraven
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 12. Infanterieregiment war das ehemalige 2. Brandenburger Infanterieregiment. Es 
setzte 
sich aus zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer J�gerabteilung des 
1. 
Westf�lischen Landwehr-Infanterieregiments zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Bautzen, L�wenberg, Goldberg, Katzbach, Bunzlau, Bischofswerda, 
Godau, 
Modern, Freiburg, Horselberg, Epernay, M�ry, Gu�, Laon, La Fert�, Paris.
..............................
24. Infanterieregiment 
Kommandeur:
Major von Laurens
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 24. Infanterieregiment war das ehemalige 4. Brandenburger Infanterieregiment . Es 
setzte 
sich aus zwei Gefechtslinienbataillonen, einem F�silierbataillon und der 2. und 3. Kompanie 
des 
schlesischen Gewehrbataillons zusammen.
|
Eins�tze: 1813-14|
|
Ludau, Geiffersdorff, Goldberg, Katzbach, Lang Wolmsdorf, Harthau, Bischofswerda, 
Godau, 
Waertenburg, Schkeuditz, Modern, Freiburg, Eisenach, Belagerung von Kastel, Bacharach, 
St. 
Johann, 
Saarbr�cken, Belagerung von Saarlouis, St. Ubold, Noisseville, Belagerung von Metz, 
Epernay, 
La Fert�-sous-Jouarre, Gu�, Laon, La Fert�-gaucher, Paris.
..............................
1. Westf�lisches Landwehr-Infanterieregiment 
Kommandeur:
Oberstleutnant Ruchel von Kleist
Portr�t:
Westf�lische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 1. Westf�lische Landwehr-Infanterieregiment war das ehemalige Landwehr-
Infanterieregiment von Cleve. Es setzte sich aus drei Landwehr-Bataillonen und einer 
J�gerabteilung des Regiments zusammen.
..............................
;2. Infanteriebrigade / 1. Korps
6. Infanterieregiment 
Kommandeur:
Oberst von Kemphen
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 6. Infanterieregiment war das ehemalige 1. Westpreu�ische Infanterieregiment. Es 
setzte 
sich aus zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer J�gerabteilung des 
Regiments zusammen.|
|
Eins�tze: 1813-14|
|
Danningloro, Gro� Gorschen, Mei�en, K�nigswartha, Bautzen, Hanau, Dresden, Gro� 
Haeselich, Falkenhain, Culm, Binnivalde, Leipzig, Belagerung von Erfurt, Beauvais, May, 
Laon, 
Bontavert f. Uisne, Fismes, Montiel, Billeparifis und Claye, Paris.
..............................
28. Infanterieregiment 
Kommandeur:
Major Baron Quadt von Hitchenbrock I
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 28. Infanterieregiment war das ehemalige 1. Infanterieregiment von Berg. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer J�gerabteilung des 
Regiments 
zusammen.|
|
Eins�tze: 1814|
|
Belagerung von Mainz.
..............................
2. Westf�lisches Landwehr-Infanterieregiment 
Kommandeur:
Major von Winterfeld
Portr�t:
Westf�lische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 2. Westf�lische Landwehr-Infanterieregiment war das ehemalige Minden-Ravensberger 
Landwehr-Infanterieregiment. Es setzte sich aus drei Bataillonen und einer J�gerabteilung 
des 
Regiments zusammen.
..............................
;3. Infanteriebrigade / 1. Korps
7. Infanterieregiment
Kommandeur:
Oberstleutnant von Sydlitz
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 7. Infanterieregiment war das ehemalige 2. Westpreu�ische Infanterieregiment. Es 
setzte 
sich aus zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer J�gerabteilung des 
3. 
Westf�lischen Landwehr-Infanterieregiments zusammen.|
|
Eins�tze: 1813-14|
|
Ulsleben, Gro� Gorschen, Colditz, K�nigswartha, Bautzen, Baldau, Dresden, Culm, 
Hellendorf, Pirna, Peterswalde, Graupen, Leipzig, Belagerung von Erfurt, Jlversgehofen, 
Etoges, 
M�ry f. S. , Gu�, Lish, May, La Fert�-Milon, Laon, Bontavaire, La Fert�-gaucher, Claye, 
Paris.
..............................
29. Infanterieregiment
Kommandeur:
Major von Hymmen
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 29. Infanterieregiment war das ehemalige 2. Infanterieregiment von Berg. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer J�gerabteilung des 
Regiments 
zusammen.|
|
Eins�tze: 1814|
|
Belagerung von Mainz.
..............................
3. Westf�lisches Landwehr-Infanterieregiment 
Kommandeur:
Major Friccius
Portr�t:
Westf�lische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|Das 3. Westf�lische Landwehr-Infanterieregiment war das ehemalige 
Landwehr-Infanterieregiment von Ost Friesland-Lingen. Es setzte sich aus
drei Bataillonen und einer J�gerabteilung des Regiments zusammen.
...................................
Schlesisches Gewehrbataillon
Kommandeur:
Major von Neumann
Portr�t:
Schlesische Gewehreinheit
,,,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Diese schlesische Gewehrabteilung setzte sich aus der 1. und 2. Kompanie des schlesischen 
Gewehrbataillons zusammen. Die beiden anderen Bataillone wurden anderen Regimentern 
zugeordnet.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Laustgl., Bautzen, Hanau, Dresden, Peterswalde, Schandau, Leipzig, 
Gtoges, Luremburg, Meaux, Laon, Bille Parisis, Paris.
..............................
4. Infanteriebrigade / 1. Korps
13. Infanterieregiment
Kommandeur:
Major Quadt von Hitchenbrock
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 13. Infanterieregiment war das ehemalige 1. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.
..............................
19. Infanterieregiment
Kommandeur:
Major von Stengel
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 19. Infanterieregiment war das ehemalige 7. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.|
|
Eins�tze: 1813-14|
|
Dresden, Culm, Hellendorf, Pirna, Rollendorf, Leipzig, Belagerung von Erfurt, Fanvilliers und 
Sarrechamps, Gu� a Tresmes, Laon, Claye, Paris.
..............................
4. Westf�lisches Landwehr-Infanterieregiment 
Kommandeur:
Major Graf von Groeben
Portr�t:
Westf�lische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|Das 4. Westf�lische Landwehr-Infanterieregiment war das ehemalige Landwehr-
Infanterieregiment von M�nster. Es setzte sich aus drei Bataillonen und einer J�gerabteilung 
des 
Regiments zusammen.
...................................
;1. Kavalleriebrigade / 1. Korps
2. Dragonerregiment
Kommandeur:
Oberstleutnant von Woisky
Portr�t:
2. Dragonerregiment
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 2. Dragonerregiment war das ehemalige 1. Westpreu�ische Dragonerregiment. Es 
bestand 
aus drei Schwadronen.|
|
Eins�tze: 1813-14|
|
Danniglow, Gro� Gorschen, K�nigswartha, Bautzen, Katzbach, Reichenbach, Modern-
Leipzig, Marfrohlitz, Manhuelles, La Chauss�e, Mareuil, Montmirail, Laon, S�zanne, Paris.
..................................
5. Dragonerregiment
Kommandeur:
Oberstleutnant von Watzdorff
Portr�t:
5. Dragonerregiment
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 5. Dragonerregiment war das ehemalige Brandenburger Prinz Wilhelm-
Dragonerregiment. 
Es bestand aus vier Schwadronen und einer Berittenen J�gerabteilung.|
|
Eins�tze: 1813-14|
|
Danniglow, Gro� Gorschen, Bautzen, Hanau, Gro� Beeren, Bahna, Dennewitz, 
Herzberg, Leipzig, Soissons, Laon.
...............................
4. Husarenregiment
Kommandeur:
Major von Engelhardt
Portr�t:
4. Husarenregiment
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 4. Husarenregiment war das ehemalige 1. Schlesische Husarenregiment. Es bestand aus 
drei Schwadronen und einer Berittenen J�gerabteilung.|
|
Eins�tze: 1813-14|
|
Belagerung von Wittenberg, Weimar, Gro� Gorschen, K�nigswartha, Bautzen, Hanau, 
Neuhausen, Dresden, Glash�tte, Culm, Peterswalde, Leipzig, Ctoges, Champaubert, Gu� a 
Tresmes, Laon, La F�re-Champenoise, Claye, Paris.
...............................
3. Ulanenregiment
Kommandeur:
Oberstleutnant von Stutterheim
Portr�t:
3. Ulanen-Einheit
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 3. Ulanen-Einheit war das ehemalige Brandenburger Ulanenregiment. Sie bestand aus 
drei 
Schwadronen.|
|
Eins�tze: 1813-14|
|
Lauterseissen, L�wenberg, Goldberg, Katzbach, Bunzlau, Hochfirch, Rothnauslitz, Modern, 
Leipzig, Montier-en-der, La Chauss�e, Ch�lons, Montmirail, Meaux, Laon, S�zanne, Paris.
...............................
;2. Kavalleriebrigade / 1. Korps
1. Kurm�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Folgersberg
Portr�t:
Kurm�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die 1. Kurm�rkische Landwehr-Kavallerie bestand aus drei Schwadronen.
...............................
2. Kurm�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Kameke
Portr�t:
Kurm�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die 2. Kurm�rkische Landwehr-Kavallerie bestand aus vier Schwadronen.
...............................
Westf�lisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Wulffen
Portr�t:
Westf�lische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Westf�lische Landwehr-Kavallerie setzte sich aus vier Schwadronen und einer berittenen 
J�gerabteilung zusammen.
...............................
6. Ulanenregiment
Kommandeur:
Oberstleutnant von L�tzow
Portr�t:
6. Ulanen-Einheit
,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 6. Ulanen-Einheit war das ehemalige L�tzower Kavallerieregiment. Es bestand aus drei 
Schwadronen.
...............................
2. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Siemon
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
.................................
6. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Reuter
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
..............................
9. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Holsche
Portr�t: Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst nach dem 18. Juni bei.
...................................
1. Unberittene Batterie
Kommandeur:
Hauptmann Huet
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung: |
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...................................
3. Unberittene Batterie
Kommandeur:
Oberleutnant Neander
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
................................
7. Unberittene Batterie
Kommandeur:
Hauptmann Schaale
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................
8. Unberittene Batterie
Kommandeur:
Hauptmann Hermann
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................
15. Unberittene Batterie
Kommandeur:
Hauptmann Anders
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................
1. Haubitzenbatterie
Kommandeur:
Hauptmann Voitus
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Acht 7-Pfund-Haubitzen.
...............................
2. Berittene Batterie
Kommandeur:
Hauptmann Borowski
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
.................................
7. Berittene Batterie
Kommandeur:
Hauptmann Richter
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
..............................
10. Berittene Batterie
Kommandeur:
Hauptmann Schaffer
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
............................
;5. Infanteriebrigade / 2. Korps
2. Infanterieregiment
Kommandeur:
Major von Cardell
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 2. Infanterieregiment war das ehemalige 1. Pommersche Infanterieregiment. Es setzte 
sich 
aus zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer J�gerabteilung 
zusammen, 
die aus dem 1. und dem F�silierbataillon des Regiments gebildet worden war.|
|
Eins�tze: 1813-14|
|
Werben, L�neburg, Danniglow, Belagerung von Magdeburg, Gohrde, Hoyerswerda, Ludau, 
Mellin, Gro� Beeren, Dennewitz, Wartenburg, Belagerung von Wittenberg, Leipzig.
..............................
25. Infanterieregiment 
Kommandeur:
Major von Petersdorff
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 25. Infanterieregiment war das ehemalige L�tzower Freikorps. Es setzte sich aus zwei 
Gefechtslinienbataillonen, einem F�silierbataillon und einer aus dem Regiment gebildeten 
J�gerabteilung zusammen.
..............................
5. Westf�lisches Landwehr-Infanterieregiment 
Kommandeur:
Oberstleutnant Ruchel von Roebel
Portr�t:
Westf�lische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 5. Westf�lische Landwehr-Infanterieregiment war das ehemalige Paderborner Landwehr-
Infanterieregiment. Es setzte sich aus drei Bataillonen und einer aus dem Regiment 
gebildeten 
J�gerabteilung zusammen.
..............................
;6. Infanteriebrigade / 2. Korps
9. Infanterieregiment 
Kommandeur:
Major von Schmidt
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 9. Infanterieregiment war das ehemalige Kolberger Infanterieregiment. Es setzte sich aus 
zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer aus dem Regiment 
gebildeten 
J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Belagerung von Wittenberg, Halle, Gro� Gorschen, Colditz, Bautzen, Belagerung von Stettin, 
Gro� Beeren, Dennewitz, Leipzig, Arnheim, Compi�gne.
..............................
26. Infanterieregiment 
Kommandeur:
Major von Reu�
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 26. Infanterieregiment war das ehemalige Elbe-Infanterieregiment. Es setzte sich aus 
zwei 
Gefechtslinienbataillonen, einem F�silierbataillon und einer aus dem Regiment gebildeten 
J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Beeren, Dennewitz, Belagerung von Wittenberg, Coswig, Arnheim.
..............................
1. Elbe-Landwehr-Infanterieregiment 
Kommandeur:
Oberstleutnant von Bismark
Portr�t:
Elbe-Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 1. Elbe-Landwehr-Infanterieregiment bestand aus drei Bataillonen.
..............................
;7. Infanteriebrigade / 2. Korps
14. Infanterieregiment
Kommandeur:
Major von Mirbach
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 14. Infanterieregiment war das ehemalige 2. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen, einem F�silierbataillon und einer aus dem Regiment 
gebildeten 
J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Belagerung von Stettin, Gro� Beeren, Schmiellendorf, Woltersdorf, Dennewitz, Belagerung 
von 
Wittenberg, Leipzig, Belagerung von Soissons.
..............................
22. Infanterieregiment
Kommandeur:
Major von Sack
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 22. Infanterieregiment war das ehemalige 10. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Bautzen, Hanau, Dresden, Culm, Hellendorf, Gro� Colditz, Rollendorf, 
Lellnitz, Frohburg, Leipzig, Luremburg, Thionville, Metz, Ctoges, Gu� a Tresmes, Laon, 
Pontavert, Courlande, Fismes, Claye, Paris.
..............................
2. Elbe-Landwehr-Infanterieregiment 
Kommandeur:
Major von Reckow
Portr�t:
Elbe-Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Elbe-Landwehr-Infanterieregiment bestand aus drei Bataillonen.
...................................
;8. Infanteriebrigade / 2. Korps
21. Infanterieregiment
Kommandeur:
Oberst von Reckow
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 21. Infanterieregiment war das ehemalige 9. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.
..............................
23. Infanterieregiment
Kommandeur:
Oberstleutnant von Wienskowski
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 23. Infanterieregiment war das ehemalige 11. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Bautzen, Dresden, Culm, Hellendorf bei Peterswalde, Leipzig, Belagerung 
von 
Erfurt, Ctoges, Laon, Claye, Paris.
..............................
3. Elbe-Landwehr-Infanterieregiment 
Kommandeur:
Oberstleutnant von Rangow
Portr�t:
Elbe-Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 3. Elbe-Landwehr-Infanterieregiment bestand aus drei Bataillonen.
...................................
;2. Kavalleriekorps
;1. Kavalleriebrigade / 2. Korps
1. Dragonerregiment
Kommandeur:
Oberstleutnant von Kameke
Portr�t:
1. Dragonerregiment
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 1. Dragoner-Einheit war auch unter dem Namen "Dragonerregiment der K�nigin" 
bekannt. 
Die Einheit bestand aus vier Schwadronen und einer berittenen J�gerabteilung.|
|
Eins�tze: 1813-14|
|
Hoyerswerda, Ludau, Wittstock, Gro� Beeren, Bahna, Dennewitz, Modern, Leipzig, Halle, 
Arnheim, Mergem, Laon, Compi�gne.
..................................
6. Dragonerregiment
Kommandeur:
Oberst von Borcke
Portr�t:
6. Dragoner-Einheit
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 6. Dragoner-Einheit war das ehemalige Neum�rkische Dragonerregiment. Die Einheit 
setzte 
sich aus vier Schwadronen und einer berittenen J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Borna, Bautzen, Rothtretscham, Hainau, Seida, Dresden, Katzbach, 
Loblowitz, Altenburg, Leipzig, Thionville, Gu� a Tremes, May, Laon, Trilport, Claye, Paris.
...............................
2. Ulanenregiment
Kommandeur:
Oberstleutnant von Schmiedeberg
Portr�t:
2. Ulanen-Einheit
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 2. Ulanen-Einheit war das ehemalige schlesische Ulanenregiment. Die Einheit bestand 
aus 
vier Schwadronen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Bautzen, Hanau, Dresden, Leipzig, Belagerung von Luremburg, Gu� a 
Tresmes, May, Laon, Paris.
...............................
;2. Kavalleriebrigade / 2. Korps
3. Husarenregiment
Kommandeur:
Major von Klinkowstroem
Portr�t:
3. Husaren-Einheit
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 3. Husaren-Einheit war das ehemalige Brandenburger Husarenregiment. Die Einheit 
setzte 
sich aus vier Schwadronen und einer berittenen J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Bautzen, Reufichen, L�wenberg, Kroitich, Bunzlau, Reichenbach, 
Dresden, Wartenburg, Modern, Leipzig, Freiburg, Hanau, Luremburg, Ch�lons, La Chauss�e, 
Montmirail, La Fert�, Meaux, Laon, Claye, Paris.
..................................
5. Husarenregiment
Kommandeur:
Major von Arnim
Portr�t:
5. Husaren-Einheit
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 5. Husaren-Einheit war das ehemalige Pommersche Husarenregiment. Die Einheit setzte 
sich aus vier Schwadronen und einer berittenen J�gerabteilung zusammen.
..................................
;3. Kavalleriebrigade / 2. Korps
4. Kurm�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Oberstleutnant von Schmeling
Portr�t:
Kurm�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 4. Kurm�rkische Landwehr-Kavallerie war das ehemalige Berliner Landwehr-
Kavallerieregiment. Die Einheit bestand aus sechs Schwadronen.
...............................
5. Kurm�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Uckermann
Portr�t:
Kurm�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die 5. Kurm�rkische Landwehr-Kavallerie war aus vier Schwadronen zusammengesetzt.
...................................
;Angegliederte Kavallerie
11. Husarenregiment
Kommandeur:
Major von Romberg
Portr�t:
11. Husaren-Einheit
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Die 11. Husaren-Einheit setzte sich aus den ehemaligen Husarenregimentern von Berg und 
Sachsen zusammen. Sie bestand aus drei Schwadronen und einer berittenen 
J�gerabteilung.|
|
Eins�tze: 1814|
|
Belagerung von Mainz.
...............................
Elbe-Landwehr-Kavallerieregiment
Kommandeur:
Oberstleutnant von Reibnitz
Portr�t:
Elbe-Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Elbe-Landwehr-Kavallerie bestand aus vier Schwadronen.
...............................
;2. Artilleriekorps
4. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Meyer
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
................................
8. Schwere Unberittene Batterie
Kommandeur:
Oberleutnant Junghaus
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
...............................
10. Schwere Unberittene Batterie
Kommandeur:
Oberleutnant Schrader
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst Ende Juni bei.
...............................
5. Unberittene Batterie
Kommandeur:
Hauptmann Michaelis
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
................................
10. Unberittene Batterie
Kommandeur:
Hauptmann Magenhofer
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
..................................
12. Unberittene Batterie
Kommandeur:
Hauptmann Bully
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................
34. Unberittene Batterie
Kommandeur:
Hauptmann Lent
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Die Gesch�tze dieser Batterie wurden in England hergestellt.
................................
37. Unberittene Batterie
Kommandeur:
Hauptmann von Numers
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie entstand aus der ehemaligen Unberittenen Artillerie von Berg.
..............................
2. Haubitzenbatterie
Kommandeur:
Hauptmann von Rode
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Acht 7-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst nach dem 18. Juni bei.
..............................		
5. Berittene Batterie
Kommandeur:
Hauptmann von Witten
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
................................		
6. Berittene Batterie
Kommandeur:
Hauptmann Jenichen
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................		
14. Berittene Batterie
Kommandeur:
Hauptmann Fritze
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
............................
;9. Infanteriebrigade / 3. Korps
8. Infanterieregiment
Kommandeur:
Major von Zepelin
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 8. Infanterieregiment war nicht mit der Preu�ischen Garde identisch, obwohl es unter 
dem 
Namen Infanterieregiment von Lieb bekannt war. Das 8. Infanterieregiment diente bis zur 
Armeereform als Garde. Danach wurde es aus dem Gefechtsliniensystem herausgenommen, 
und die restlichen Regimenter wurden umbenannt.| 
Das 8. Infanterieregiment setzte sich aus zwei Gefechtslinienbataillonen, einem 
F�silierbataillon 
und einer aus dem 1. und 2. Bataillon des Regiments gebildeten J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Lindenau, Colditz, K�nigswartha, Bautzen, Horselberg, L�wenberg, 
Bunzlau, Hochfirch, Bischofswerda, Wartenburg, Modern, Freiburg, Simmern, Brienne, 
Bitrch, La 
Chauss�e, Ch�lons, Montmirail, M�ry, Laon, Trilport, Claye, Paris.
..............................
30. Infanterieregiment 
Kommandeur:
Major Ditfurth
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 30. Infanterieregiment war das ehemalige 1. Regiment der Russisch-deutschen Legion. 
Es 
setzte sich aus zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.
..............................
1. Kurm�rkisches Landwehr-Infanterieregiment
Kommandeur:
Major von Tippelskirch
Portr�t:
Kurm�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 1. Kurm�rkische Landwehr-Infanterieregiment war das ehemalige Berliner Landwehr-
Infanterieregiment. Es bestand aus drei Bataillonen.
..............................
10. Infanteriebrigade / 2. Korps
20. Infanterieregiment 
Kommandeur:
Oberstleutnant von Natzmer
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 20. Infanterieregiment war das ehemalige 8. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.
..............................
27. Infanterieregiment
Kommandeur:
Oberstleutnant von Plessmann
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 27. Infanterieregiment setzte sich aus dem ehemaligen Ersatzbataillon des Elbe-
Infanterieregiments, dem Fremdenbataillon von Reich, dem Freikorpsbataillon von Hellwig 
und 
dem 1. Schlesischen Ersatzbataillon zusammen. Es bestand aus zwei 
Gefechtslinienbataillonen, 
einem F�silierbataillon und einer aus dem Regiment gebildeten J�gerabteilung.
..............................
2. Kurm�rkisches Landwehr-Infanterieregiment
Kommandeur:
Major von Beckendorff
Portr�t:
Kurm�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Kurm�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
..............................
;11. Infanteriebrigade / 2. Korps
3. Kurm�rkisches Landwehr-Infanterieregiment
Kommandeur:
Oberstleutnant von Zschuschen
Portr�t:
Kurm�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 3. Kurm�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
............................
4. Kurm�rkisches Landwehr-Infanterieregiment
Kommandeur:
Major von Grolman
Portr�t:
Kurm�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 4. Kurm�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
...................................
;12. Infanteriebrigade / 2. Korps
31. Infanterieregiment
Kommandeur:
Major von Ketteloot
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 31. Infanterieregiment war das ehemalige 2. Regiment der Russisch-deutschen Legion. 
Es 
setzte sich aus zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.
..............................
5. Kurm�rkisches Landwehr-Infanterieregiment
Kommandeur:
Major von Welling
Portr�t:
Kurm�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 5. Kurm�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
............................
6. Kurm�rkisches Landwehr-Infanterieregiment
Kommandeur:
Oberstleutnant von Rohr
Portr�t:
Kurm�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 6. Kurm�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
...................................
3. Kavalleriekorps
1. Kavalleriebrigade / 3. Korps
12. Husarenregiment
Kommandeur:
Oberstleutnant von Czettritz
Portr�t:
12. Husaren-Einheit
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die 12. Husaren-Einheit bestand aus drei Schwadronen.
..................................
7. Ulanenregiment
Kommandeur:
Major von Raven
Portr�t:
7. Ulanenregiment
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 7. Ulanenregiment setzte sich aus dem ehemaligen Kavalleriefreikorps von Hellwig und 
den 
s�chsischen Ulanen zusammen. Es bestand aus drei Schwadronen.
...............................		
8. Ulanenregiment
Kommandeur:
Oberst Graf zu Duhna
Portr�t:
8. Ulanenregiment
,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 8. Ulanenregiment setzte sich aus den ehemaligen Husarenregimentern der Russisch-
deutschen Legion zusammen und bestand aus vier Schwadronen und einer berittenen 
J�gerabteilung.
...............................
;2. Kavalleriebrigade / 3. Korps
7. Dragonerregiment
Kommandeur:
Oberst von der Goltz
Portr�t:
7. Dragonerregiment
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Dieses Regiment wurde neu zusammengestellt, indem man aus bereits bestehenden 
Dragonerregimentern Soldaten �bernahm. Es bestand aus drei Schwadronen.
..................................
9. Husarenregiment
Kommandeur:
Major von Hellwig
Portr�t:
9. Husarenregiment
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Dieses Regiment wurde neu zusammengestellt, indem man aus bereits bestehenden 
Husarenregimentern Soldaten �bernahm. Es bestand aus drei Schwadronen und einer 
berittenen 
J�gerabteilung.
..................................
5. Ulanenregiment
Kommandeur:
Major von Zastrow
Portr�t:
5. Ulanenregiment
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Dieses Regiment wurde neu zusammengestellt, indem man aus bereits bestehenden Ulanen- 
und Husarenregimentern Soldaten �bernahm. Es bestand aus drei Schwadronen.
.................................
;Angegliederte Kavallerie
3. Kurm�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major Graf von Finckenstein
Portr�t:
Kurm�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 3. Kurm�rkische Landwehr-Kavallerieregiment bestand aus vier Schwadronen.
...............................
6. Kurm�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Dorville
Portr�t:
Kurm�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 6. Kurm�rkische Landwehr-Kavallerieregiment bestand aus drei Schwadronen.
...............................
;3. Artilleriekorps
7. Schwere Unberittene Batterie
Kommandeur:
Oberleutnant Baldauf
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
................................		
11. Schwere Unberittene Batterie
Kommandeur:
Oberleutnant Liebermann
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst Anfang August bei.
...............................
12. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Stammer
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
..............................		
18. Unberittene Batterie
Kommandeur:
Hauptmann Sannow
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................		
24. Unberittene Batterie
Kommandeur:
Hauptmann Valenkampff
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst nach dem 6. Juli bei. Sie war mit englischen 6-Pfund-
Gesch�tzen ausger�stet.
................................
30. Unberittene Batterie
Kommandeur:
Oberleutnant Hain
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................		
35. Unberittene Batterie
Kommandeur:
Hauptmann von Wangenheim
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee am 15. Juni bei.
...............................		
36. Unberittene Batterie
Kommandeur:
Hauptmann Blesky
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst nach dem 30. Juni bei.
...............................		
3. Haubitzenbatterie
Kommandeur:
Hauptmann Kurgass
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Acht 7-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst Ende August bei.
................................		
18. Berittene Batterie
Kommandeur:
Hauptmann Hoyer
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie war die ehemalige 1. Berittene Batterie der Russisch-deutschen Legion. Ihre 6-
Pfund-Gesch�tze waren in Ru�land hergestellt worden.
..............................		
19. Berittene Batterie
Kommandeur:
Oberleutnant Dellen
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie war die ehemalige 2. Berittene Batterie der Russisch-deutschen Legion. Ihre 6-
Pfund-Gesch�tze waren in Ru�land hergestellt worden.
..............................		
20. Berittene Batterie
Kommandeur:
Stabshauptmann Vollmar
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Diese Batterie war die ehemalige Berittene Batterie von Berg.
............................
;13. Infanteriebrigade / 4. Korps
10. Infanterieregiment
Kommandeur:
Oberst von Lettow
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 10. Infanterieregiment war das ehemalige 1. Schlesische Infanterieregiment. Es bestand 
aus 
zwei Gefechtslinienbataillonen 
und einem F�silierbataillon.
..............................
2. Neum�rkisches Landwehr-Infanterieregiment
Kommandeur:
Major von Braunschweig
Portr�t:
Neum�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Neum�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
..................................
3. Neum�rkisches Landwehr-Infanterieregiment
Kommandeur:
Major von Schmalensee
Portr�t:
Neum�rkische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 3. Neum�rkische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
..............................
;13. Infanteriebrigade / 4. Korps
11. Infanterieregiment 
Kommandeur:
Major Graf von Reichenbach
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 11. Infanterieregiment war das ehemalige 2. Schlesische Infanterieregiment. Es bestand 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon.
..............................
1. Pommersches Landwehr-Infanterieregiment
Kommandeur:
Major von Brandenstein
Portr�t:
Pommersche Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 1. Pommersche Landwehr-Infanterieregiment bestand aus drei Bataillonen.
................................
2. Pommersches Landwehr-Infanterieregiment
Kommandeur:
Oberst von Pawels
Portr�t:
Pommersche Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Pommersche Landwehr-Infanterieregiment bestand aus drei Bataillonen.
..............................
;15. Infanteriebrigade / 4. Korps
18. Infanterieregiment
Kommandeur:
Oberst von Loebell
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 18. Infanterieregiment war das ehemalige 6. Reserveinfanterieregiment. Es bestand aus 
drei Gefechtslinienbataillonen.
..............................
3. Schlesisches Landwehr-Infanterieregiment 
Kommandeur:
Oberstleutnant von Thile
Portr�t:
Schlesische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 3. Schlesische Landwehr-Infanterieregiment setzte sich aus drei Bataillonen und einer 
J�gerabteilung des Regiments zusammen.
............................
4. Schlesisches Landwehr-Infanterieregiment
Kommandeur:
Oberstleutnant von Massow
Portr�t:
Schlesische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 4. Schlesische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
...................................
;16. Infanteriebrigade / 4. Korps
15. Infanterieregiment
Kommandeur:
Oberst von Creilsheim
Portr�t:
Preu�ische Gefechtslinieninfanterie
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 15. Infanterieregiment war das ehemalige 3. Reserveinfanterieregiment. Es setzte sich 
aus 
zwei Gefechtslinienbataillonen und einem F�silierbataillon zusammen.|
|
Eins�tze: 1813-14|
|
Blautenfelde, Dennewitz, Dessau, Belagerung von Magdeburg.
..............................
1. Schlesisches Landwehr-Infanterieregiment
Kommandeur:
Major von Fischer
Portr�t:
Schlesische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 1. Schlesische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
............................
2. Schlesisches Landwehr-Infanterieregiment
Kommandeur:
Oberstleutnant von Blandowski
Portr�t:
Schlesische Landwehr-Infanterie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Schlesische Landwehr-Infanterieregiment bestand aus drei Bataillonen.
...................................
4. Kavalleriekorps
;1. Kavalleriebrigade / 4. Korps
6. Husarenregiment
Kommandeur:
Oberst von Eicke
Portr�t:
6. Husarenregiment
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 6. Husarenregiment war das ehemalige 2. Schlesische Husarenregiment. Es setzte sich 
aus 
vier Schwadronen und einer berittenen J�gerabteilung zusammen.|
|
Eins�tze: 1813-14|
|
Gro� Gorschen, Gro� Beeren, Schermbeck, Wartenburg, Leipzig, K�nigswartha, 
Bautzen, Dresden, Halle, Altenburg, Leipzig, Montmirail, Laon.
............................
10. Husarenregiment
Kommandeur:
Oberstleutnant von Ledebur
Portr�t:
10. Husarenregiment
,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Das 10. Husarenregiment war das ehemalige Nationale Elbe-Kavallerieregiment. Es bestand 
aus 
vier Schwadronen.
..................................
1. Westpreu�isches Ulanenregiment
Kommandeur:
Oberstleutnant Beier
Portr�t:
Westpreu�ische Ulanen
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die 1. Westpreu�ische Ulanen-Einheit setzte sich aus vier Schwadronen und einer berittenen 
J�gerabteilung zusammen.
...............................		
;2. Kavalleriebrigade / 4. Korps
8. Husarenregiment
Kommandeur:
Major von Colomb
Portr�t:
8. Husarenregiment
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Dieses Regiment wurde neu aufgestellt, indem man Soldaten aus bestehenden 
Husarenregimentern �bernahm. Es bestand aus drei Schwadronen.
..................................
8. Dragonerregiment
Kommandeur:
Major von M�ller
Portr�t:
8. Dragonerregiment
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Dieses Regiment wurde neu aufgestellt, indem man Soldaten aus bestehenden 
Dragonerregimentern und dem Nationalen Elbe-Kavallerieregiment �bernahm. Es bestand aus 
drei Schwadronen.
.................................
;3. Kavalleriebrigade / 4. Korps
1. Neum�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Sydow
Portr�t:
Neum�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 1. Neum�rkische Landwehr-Kavallerieregiment bestand aus drei Schwadronen.
...............................
2. Neum�rkisches Landwehr-Kavallerieregiment
Kommandeur:
Major Graf von Haslingen
Portr�t:
Neum�rkische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Neum�rkische Landwehr-Kavallerieregiment bestand aus drei Schwadronen.
...............................
1. Pommersches Landwehr-Kavallerieregiment
Kommandeur:
Major von Blanckenburg
Portr�t:
Pommersche Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 1. Pommersche Landwehr-Kavallerieregiment bestand aus drei Schwadronen.
...............................
2. Pommersches Landwehr-Kavallerieregiment
Kommandeur:
Major von Kameke
Portr�t: 
Pommersche Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Pommersche Landwehr-Kavallerieregiment bestand aus drei Schwadronen.
...............................
1. Schlesisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Schill
Portr�t:
Schlesische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 1. Schlesische Landwehr-Kavallerieregiment bestand aus vier Schwadronen.
...............................
;Angegliederte Kavallerie
2. Schlesisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Schallern
Portr�t:
Schlesische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 2. Schlesische Landwehr-Kavallerieregiment bestand aus vier Schwadronen.
...............................
3. Schlesisches Landwehr-Kavallerieregiment
Kommandeur:
Major von Falckenhausen
Portr�t:
Schlesische Landwehr-Kavallerie
,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Das 3. Schlesische Landwehr-Kavallerieregiment bestand aus vier Schwadronen.
...............................
;4. Artilleriekorps
3. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Scheffler
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
..............................		
5. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Conradi
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
...............................		
13. Schwere Unberittene Batterie
Kommandeur:
Hauptmann Wocke
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 12-Pfund-Gesch�tze und zwei 10-Pfund-Haubitzen.
...............................		
2. Unberittene Batterie
Kommandeur:
Oberleutnant Schmidt
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................	
11. Unberittene Batterie
Kommandeur:
Hauptmann von Mengden
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
................................		
13. Unberittene Batterie
Kommandeur:
1. Leutnant Martitz
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
.................................		
14. Unberittene Batterie
Kommandeur:
Hauptmann Hensel
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................		
21. Unberittene Batterie
Kommandeur:
Hauptmann Koppen
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................		
4. Haubitzenbatterie
Kommandeur:
Oberleutnant Schlemmer
Portr�t:
Preu�ische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Acht 7-Pfund-Haubitzen.|
|
Diese Batterie trat der Armee erst nach dem 18. Juni bei.
..............................		
1. Berittene Batterie
Kommandeur:
Hauptmann von Zincken
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
...............................		
11. Berittene Batterie 
Kommandeur:
Hauptmann Borchard
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.|
|
Die 6-Pfund-Gesch�tze dieser Batterie waren in England hergestellt worden.
...............................
12. Berittene Batterie
Kommandeur:
Hauptmann Pfeil
Portr�t:
Preu�ische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Sechs 6-Pfund-Gesch�tze und zwei 7-Pfund-Haubitzen.
............................
7. Britische Brigade / Garnisonsdivision
Kommandeur: 
Generalmajor Mckenzie
Portr�t:
Britischer Divisionsoffizier
,,,,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
Garnison von Antwerpen:|
2. Bataillon, 25. Unberittenes Regiment|
2. Bataillon, 37. Unberittenes Regiment|
1. Fremdenbataillon|
|
Garnison von Nieuport:|
2. Bataillon 78. Unberittenes Regiment|
|
Garnison von Ostende:|
13. R. Veteranenbataillon|
2. Garnisonsbataillon|
........................
1. Brigade/ Hannoversches Reservekorps
Kommandeur:
Oberstleutnant von Bennigsen
Portr�t:
Hannoversche Landwehr
Zusammensetzung:
Landwehr-Bataillon Bremerlehe
Major A. von der Decken
Landwehr-Bataillon M�lln
Major von Donop
von Bothmers Landwehr-Bataillon
Major von Bothmer
......................................
2. Brigade/ Hannoversches Reservekorps
Kommandeur:
Oberst von Beaulieu
Portr�t:
Hannoversche Landwehr
Zusammensetzung:
Landwehr-Bataillon Nordheim
Major Delins
Landwehr-Bataillon Ahlefeldt
Major Hametberg
Landwehr-Bataillon Springe
Major von Munchhaussen
......................................
3. Brigade /Hannoversches Reservekorps
Kommandeur:
Oberstleutnant von Bodecken
Portr�t:
Hannoversche Landwehr
Zusammensetzung:
Landwehr-Bataillon Otterndorf
Major Hans von der Decken
Landwehr-Bataillon Celle
Oberstleutnant von der Knesebeck
Landwehr-Bataillon Ratzeburg
Major von Hammendein
Landwehr-Bataillon L�chow
Hauptmann Walter
......................................
4. Brigade /Hannoversches Reservekorps
Kommandeur:
Oberstleutnant von Wissel
Portr�t:
Hannoversche Landwehr
Zusammensetzung:
Landwehr-Bataillon Hannover
Major von Weyhe
Landwehr-Bataillon Uelzen
Hauptmann Kunze
Landwehr-Bataillon Neustadt
Major von Hodenberg
Landwehr-Bataillon Diepholz
Major von Par
......................................
1. Brigade / 12. Kavalleriedivision
Kommandeur:
Brigadegeneral Baron Blancard
Portr�t:
1. Karabinier-Einheit
Zusammensetzung:
1. Karabinier-Einheit
Oberst Rog�
2. Karabinier-Einheit
Oberst Beugnat
,,,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Blancard wurde bei Waterloo verwundet.|
|
Eins�tze der 1. Karabinier-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl (1809), Aspern-
Essling (1809), Wagram (1809), Borodino (1812).|
|
Eins�tze der 2. Karabinier-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl (1809), Aspern-
Essling 
(1809), Wagram (1809), Borodino (1812).
.....................................				
2. Brigade / 12. Kavalleriedivision
Kommandeur:
Brigadegeneral Chevalier Donop
Portr�t:
3. K�rassier-Einheit
Zusammensetzung:
2. K�rassier-Einheit
Oberst Grandjean
3. K�rassier-Einheit
Oberst Thurot
,,,,,,,,,,,,,,,,,,,,,,
Historischer Hintergrund|
|
Brigadegeneral Chevalier Donop wurde bei Waterloo verwundet und als vermi�t gemeldet.|
|
Eins�tze der 2. K�rassier-Einheit:|
|
Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl (1809), Wagram 
(1809), Borodino (1812).|
|
Eins�tze der 3. K�rassier-Einheit:|
|
Ulm (1805), Austerlitz (1805), Jena (1806), Eylau (1807), Friedland (1807), Eckm�hl 
(1809), Aspern-Essling (1809), Wagram (1809), Borodino (1812).
........................................
12. Artillerie-Einheit der Kavalleriedivision
Kommandeur:
Hauptmann Lebau
Portr�t:
Berittene Gefechtslinienartillerie
,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Vier 6-Pfund-Gesch�tze und zwei 5 1/2"-Haubitzen der 2. Kompanie des 2. Berittenen 
Artillerieregiments.
.....................................
Garnisonsdivision / Garnison von Antwerpen
Kommandeur:
Nicht bekannt
Portr�t:
25. Unberittenes Regiment
,,,,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
2. Bataillon, 25. Unberittenes Regiment|
2. Bataillon 37. Unberittenes Regiment|
1. Fremdenbataillon|
....................................
Garnisonsdivision / Garnison von Nieuport
Kommandeur:
Nicht bekannt
Portr�t:
78. Unberittenes Regiment
,,,,,,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
2. Bataillon 78. Unberittenes Regiment|
13. R. Veteranenbataillon
.........................................
Garnisonsdivision / Garnison von Ostende
Kommandeur:
Nicht bekannt
Portr�t:
Britisches Unberittenes Gefechtslinienregiment
,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
2. Garnisonsbataillon
.................................
Strategische Reserve / Hannoversches Reservekorps
Kommandeur:
Generalleutnant F. Baron von der Decken
Portr�t:
Fernmeldeoffizier der britischen Armee
Zusammensetzung:
1. Brigade des Hannoverschen Reservekorps
Oberstleutnant von Bennigsen
2. Brigade des Hannoverschen Reservekorps
Oberst von Beaulieu
3. Brigade des Hannoverschen Reservekorps
Oberstleutnant von Bodecken
4. Brigade des Hannoverschen Reservekorps
Nicht bekannt
,,,,,,,,,,,,,,,,,,,,,,,,,,,
......................................
Unberittene Batterie der Hannoverschen Artillerie
Kommandeur:
Hauptmann von Rettberg
Portr�t:
Unberittene Hannoversche Artillerie
,,,,,,,,,,,,,,,,,,,,
Zusammensetzung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
...........................................
Artilleriereserve der Holl�ndisch-belgischen Armee 
Kommandeur:
Nicht bekannt
Portr�t:
Offizier der Holl�ndischen Divisionsartillerie
,,,,,,,,,,,,,,,,,,,,,
Anmerkungen zur Organisation|
|
Die Artilleriereserve der Holl�ndisch-belgischen Armee setzte sich aus einer Holl�ndischen 
Unberittenen Artilleriebatterie mit sechs 12-Pfund-Gesch�tzen und zwei 5 1/2"-Haubitzen 
unter 
dem Kommando von Hauptmann L.H. du Bois sowie einer Holl�ndischen Unberittenen 
Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-Haubitzen unter dem 
Kommando von Hauptmann N.J. Kaempfer zusammen. Zu Beginn des Feldzugs war keine 
der 
Batterien im Besitz von Zugpferden, und keine beteiligte sich an den K�mpfen im Juni.
....................................
Brigade von Major Brome / K�nigliche (Unberittene) Artillerie
Kommandeur:
Major Brome
Portr�t:
K�nigliche (Unberittene) Artillerie
,,,,,,,,,,,,,,,,
Ausr�stung:|
|
F�nf 9-Pfund-Gesch�tze und eine 5 1/2"-Haubitze.
..................................
Holl�ndische Artilleriereserve
Kommandeur: 
Hauptmann L.H. du Bois
Portr�t:
Holl�ndische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Holl�ndische Unberittene Artilleriebatterie mit sechs 12-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.|
|
Dieser Batterie wurden erst Ende Juni Zugpferde zugeteilt.
..................................
Holl�ndische Artilleriereserve
Kommandeur: 
Hauptmann N.J. Kaempfer
Portr�t:
Holl�ndische Unberittene Artillerie
,,,,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Holl�ndische Unberittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.|
|
Dieser Batterie wurden erst Ende Juni Zugpferde zugeteilt.
..................................
Batterie von Bichin / 1. Holl�ndisch-belgische Infanteriebrigade / 3. HB Infanteriediv.
Kommandeur: 
Hauptmann C.F. Krahmer de Bichin
Portr�t:
Belgische Berittene Artillerie
,,,,,,,,,,,,,,,,,,,
Ausr�stung:|
|
Belgische Berittene Artilleriebatterie mit sechs 6-Pfund-Gesch�tzen und zwei 5 1/2"-
Haubitzen.
...........................................
;Name
Stellvertretender Kommandeur
;Erfahrung 
;5
;
; Titel
; 
;F�hrungsqualit�ten 
;4
#
; Daten
; 
;Pers�nlichkeit
;5
;
;Lebenslauf
Die Figur des stellvertretenden Kommandeurs zeigt an, da� die Einheit aufgrund des Todes, 
einer Verletzung oder Gefangennahme des eigentlichen Kommandeurs von einem 
untergeordneten Kommandeur �bernommen wurde. Diese zeitweiligen Bef�rderungen fanden 
regelm��ig statt und f�hrten oft zur Entdeckung verborgener Talente. Erfolg auf dem 
Schlachtfeld wurde h�ufig mit der dauerhaften Anerkennung dieser zeitweiligen Bef�rderung 
und/oder der Verleihung eines Titels nach dem Ende der Schlacht belohnt. Ein Versagen 
bedeutete Schande, und man verlor alle Gunst, wenn man nicht get�tet oder verwundet 
wurde.
........................................................................
;Name
Adolf Ludwig Wilhelm von L�tzow
;Erfahrung 
;4
;
Titel
Oberstleutnant
;F�hrungsqualit�ten 
;5
;
Daten
1782 - 1834
;Pers�nlichkeit
;5
;
;Lebenslauf
L�tzow trat 1795 der K�niglichen Garde bei, wechselte 1804 zur Kavallerie und erwarb sich 
bald 
einen Ruf f�r sein draufg�ngerisches Verhalten. L�tzow wurde in der Schlacht bei Auerstadt 
verwundet, k�mpfte sich aber bald zur�ck durch die franz�sischen Gefechtslinien, um dem 
Freikorps Schills beizutreten. Unter Gneisenaus F�hrung nahm er 1807 an der Belagerung 
von 
Kolberg teil. Im Jahre 1809 schlo� er sich Schills Aufst�ndischen an und wurde daraufhin 
entlassen. Zwei Jahre sp�ter durfte er der Armee wieder beitreten und stellte 1813 sein 
ber�hmtes Freikorps mit den schwarzen M�nteln auf. Er wurde bei Ligny erneut verwundet 
und 
von den Franzosen gefangengenommen. Bis zu seinem Ausscheiden aus der Armee im Jahre 
1833 blieb er Kavalleriekommandeur. Er starb ein Jahr sp�ter in Berlin.
.........................................
;Name
Thumen
;Erfahrung 
;4
;
Titel
Oberst
;F�hrungsqualit�ten 
;3
;
#
;Daten
;
;Pers�nlichkeit
;3
;
;Lebenslauf
�ber diesen Offizier gibt es nur sehr wenig Informationen. Ihm wurden der Orden "Pour le 
m�rite" und das Eiserne Kreuz 1. Klasse verliehen. 
..............................................
;Name
Graf von Schwerin
;Erfahrung 
;3
;
Titel 
Oberst
;F�hrungsqualit�ten 
;3
;
#
;Daten
;
;Pers�nlichkeit
;3
;
;Lebenslauf
�ber diesen Offizier gibt es nur sehr wenig Informationen. Er war Offizier der K�niglichen 
Leibwache und diente in der Kavallerie. Im Jahre 1813 wurde ihm das Eiserne Kreuz 1. 
Klasse 
verliehen.
....................................
;Name
von Watzdorff
;Erfahrung 
;3
;
Titel
Oberstleutnant
;F�hrungsqualit�ten 
;3
;
#
;Daten
;
;Pers�nlichkeit
;3
;
;Lebenslauf
�ber diesen Offizier gibt es nur sehr wenig Informationen. Er diente als Kommandeur im 
Brandenburger Dragonerregiment und erhielt 1813 das Eiserne Kreuz 1. Klasse.
..................................
;Name
J. A. Stedman
;Erfahrung 
;3
;
Title
Oberstleutnant
;F�hrungsqualit�ten
;3
;
#
; Daten
;
;Pers�nlichkeit
;3
;
;Lebenslauf
Von diesem Offiizier ist lediglich  bekannt, da� er als Oberbefehlshaber der 1. 
niederl�ndisch-belgischen 
Infanteriedivision des Korps  von Prinz Friederich  w�hrend des Waterloo-Feldzugs gedient 
hat.  
..................................	
