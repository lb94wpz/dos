NTXT  Z  8Ziel nicht festgelegt, da es nichts zum Beschie�en gibt!Ziel au�er Reichweite3Verstreute Einheiten k�nnen keine Befehle empfangenZiel ist nicht im VisierZiel ist mit uns verb�ndetBrigade kann nicht feuern'Kein Zugang zur Datenbank f�r %se Armeehat keine Kuriereist t�tlich getroffenist gefangengenommen worden&Spielen von 'Fields Of Glory' beendet
Schlacht von	Habe meinurspr�ngliches Ziel erreicht	Verluste:Meldung von:Meldung:=Ich bin im Schlachtfeld iem %s von Ihrer Position angekommen.!%s has sich weider angeschlossen.UnbedeutendLeichtM��igSchwerSehr schwerim Gebiet vonBin im Gebiet vonimNorden	NordostenOstenS�dostenS�den	S�dwestenWesten
NordwestenUhrzeit:Eure ExzellenzEuer ergebener Diener"Ich erwarte Eure weiteren Befehle.6Ich habe die sich mir bietende Gelegenheit genutzt, um4Es ist meine traurige Pflicht, Euch mitzuteilen, da�\die Ausf�hrung Eurer Befehle verz�gert. Ich bitte daher untert�nigst um zus�tzliche Truppen.Sir"Ich verbleibe Euer getreuer Diener'Ich bitte ergebenst um weitere Befehle.;Ich habe mich entschlossen, diese Gelegenheit zu nutzen, um"Ich mu� Euch leider mitteilen, da�mdie unverz�gliche Ausf�hrung Eurer Anweisungen behindert. Ich bitte daher ehrerbietig um zus�tzliche Truppen.Ergebenst Euer"Ich erwarte Eure weiteren Befehle.Ich habe mich entschlossen,"Ich mu� Euch leider mitteilen, da�]die Ausf�hrung Eurer Befehle verhindert. Ich bitte daher dringendst um weitere Unterst�tzung.
Infanterie
Kavallerie
ArtillerieVerbundene TruppenFeind ininBrigadest�rke Divisionsst�rke Korpsst�rke den Feind anzugreifenvorzur�ckenIch wurde angegriffen vonZiehe mich zur�ck+, wo ich weitere Anweisungen abwarten werdeHaltemeine Position!und warte auf weitere Anweisungen	im MomentFormiert
Ungeordnet	Verstreutbeim SammelnFormieren sichTot
Gefl�chtetLosmarschiertKolonneLinieKarreeScharm�tzelGemischtProtze	AbprotzenHaltenAngriff	VerlegungR�ckzugUnterst�tzungR�ckkehrSchwachMittelm��igDurchschnittlichGutAusgezeichnetSchwerf�llig
VorsichtigDurchschnittlichImpulsiv
UnbesonnenOhne AntriebSchwachDurchschnittlichInspirierendCharismatisch
Heerf�hrerFl�gel- kommandeurKorps- kommandeurDivisions- kommandeurBrigade- kommandeur Rekrut Profi Veteran Elite GardeLangsamNormalSchnell UnterbrochenSpiel	DatenbankInformationKartenVerlegenHervorhebenOptionenNeues SpielSpiel sichernNeue SchlachtAutom. sichern:
Realistik:Geschw.MogelnSoundMusikUnterbrechenAbbruch zu DOSStereo wechseln	Franzosen	KoalitionPreu�enDebugWetter	MeldungenUhrHeranzoomen	WegzoomenLevel:KeineHeerKorpsAlle
SpielmodusArmeeFl�gelKorpsDivisionBrigadeTruppen plazierenEinheiten verlegenEinheit bewegenRichtung �ndern"%s kann hier nicht plaziert werdenEinsatzbefehleAngriffHaltenR�ckzugKommandeurbefehle	FormationMarschbefehle
ProbefeuerBrigadebefehleUnterst�tzenHaltenZielBatteriebefehleFeindlicher KommandeurFeindliche BrigadeWiederanschlie�enWiederzuteilen
TruppenartStatusSoldatenSt�rkeProzentZusammensetzung	UnbekanntTitelDaten
Kommandeur F�higkeitenPers�nlichkeitF�hrungsqualit�tenPortr�tJanuarFebruarM�rzAprilMaiJuniJuliAugust	SeptemberOktoberNovemberDezemberUnentschieden	nur knapptaktischstrategisch Die Schlacht endet unentschieden#Sie haben %s �ber den Feind gesiegt!Der Feind hat %s �ber Sie gesiegtStabsoffiziers-berichtEigene Verluste:Verluste des Feindes:Siegespunkte:F�rGegenAngriffszieleSchlacht ladenDatenbank laden5Es ist ein Fehler beim Sichern des Spiels eingetreten$Spiel erfolgreich unter %s gesichert3Es ist ein Fehler beim Laden des Spiels eingetretenSpiel %s erfolgreich geladenOKAbbruchSpiel ladenSpiel sichernJaNein$Wollen Sie ein neues Spiel anfangen?'Wollen Sie diese Schlacht neu anfangen?%Wollen Sie Fields of Glory verlassen?0Spielen von 'Fields of Glory' mit Alt-Q beendet
KopierschutzDGeben Sie folgendes aus
dem Handbuch ein:

Seite %d
Zeile %d
Wort %dKopierschutzwort falsch!!!

Infanterie
Kavallerie
Artillerie
Spielstand%s ist wieder zur�ckgekehrtNeuer hoher Punktestand(Bitte den Namen des Kommandeurs eingebenGesamtergebnisAusZieleGESAMT	   EigeneVerlustePunkte Gegnerische