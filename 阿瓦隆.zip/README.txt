




A V A L O N
-----------
(c) 1997/1998 MiG - A Dutch National Pride


1. About Avalon

	Avalon is an RPG game with Wavetable MIDI music and mode-x graphics.


2. How to install

	To install Avalon, just copy all the files to your harddrive and start AVALON.EXE to play!
	If the music doesn't work, you can change the settings of the General Midi Port in 
	GMPORT.CFG. (The default is 330)
	Unfortunately I've lost the sources of my SOUND unit, so you won't be able to change
	those settings, which are configured at:
		Port:	220h
		IRQ:	5
		DMA:	1
	Which are the default settings for soundblaster cards.


3. How to play

	Just run C:\AVALON\AVALON.EXE to start the game.


4. How to contact the MiG

	The MiG can be reached via E-mail at:

		v972090@si.hhs.nl
		rose.derwort@gironet.nl

	The official MiG homepage is:

		http://www.gironet.nl/home/roder/

	Please let us know what you think about this game, and be sure to download MiGTracker
	if you like the game's soundtrack. (MiGTracker is the music-program used to create the
	music in the game)

