TITLE Elvira II - The Jaws of Cerberus

Front of Studio

  How do I open the studio gates?
    The control panel is in the security hut
    It's located on the desk, but you can't use it without a key
    The key is in the guard's pocket
    The guard is in the closet

Security Hut

  How do I get into the security hut?
    You don't have a key, so you'll have to break in
    Maybe if you threw a rock through the door glass
    Pick up the rock on the front path and throw it through the door glass
  I can't find the rock.  Where is it?
    Return to where you stood at the beginning of the game and face the gate
    The rock is very dark, so look long and hard
    It's on the lower right edge of the path
  What else do I need to do in the security hut?
    It's a cold night.  Would be nice if you had a jacket to wear
    Maybe you could recycle those memos and notes on the bulletin board

Parking Lot

  There's nothing in the car.  Am I missing something?
    Yes
    Did you check the trunk?
    Click on the trunk door to open it and take the contents
    Don't miss the wire cutters

Second Floor Offices

  That witch in the costume room is vicious!  What do I do?
    A man of experience can handle anybody
    She's actually pretty frail if your Exp. points are at Level 4 or higher

  I'm getting overloaded with stuff and can't carry it all.  What can I do?
    Turn things into spells as soon as you can.  Spells are weightless
    Find a central place to start a junk pile, and then carry what you need
    The hallway between the three studios is a good place for your personal heap

Basement

  The Indian janitor won't talk to me anymore.  What now?
    Did you insult him?
    If you did, you're hosed.  He's going to sulk for a long, long time.

  How about that Yeti in the boiler room?
    I think he'd make a wonderful rug, don't you?
    You'll need to throw a Fireball spell to get what you need from this room
    Fireballs are Level 4 spells.  Come back later when you reach Level 4.

Studio 1:  The Kiss of the Spider

  I get two steps into the web and die.  What's the trick?
    No tricks here.  It's just no place for rookies or wimps
    Your penknife is not an adequate weapon
    Come back when you reach Level 6, are stronger and have a serious weapon
  What's with the elevator?  How do I get it to go anywhere?
    It won't work without a key
    The key is somewhere at the top of the cave, but you have to walk there
    The upside is that the elevator brings you quickly back to the bottom level
    Remember to turn the elevator switch ON near the cave entrance
  Why can't I pick up the red, poisonous mushrooms in the rooms?
    They're not yours yet
    You must kill every worm and maggot in the room first
  Help!  I'm at the lake on Level A, and I can't swim!  What do I do?
    You need the Buoyancy and Breathe Underwater spells to survive the lake
    Good News.  To mix Breathe Underwater, you need anything edible
    Bad News.  The Buoyancy spell ingredients are in the catacombs in Studio 3
  Why should I go into the lake and risk hypothermia, malaria and drowning?
    Because there's something at the very bottom that you really, really need
    Like a rope
  How do I cross the chasm on Level C?
    You can swing across it on a vertical strand of the web
    Cut the strand on the right side of the cavern and swing across
  What do I do about the dead director in the web on Level D?
    There's something of importance in his pocket
    Like the key to the elevator
    What?  You can't reach it.  You'll need a Telekinesis spell to get it
    The main ingredient for the spell is in the upstairs studio offices
    It's the boom box in the typing pool, which contains a large magnet
  How do I get the giant spider to leave her lair?
    You'll need to attract her attention
    Firing an Ice Dart at her might do it
  How do I kill the giant spider?
    You don't
    You can, however, trap her in another part of the caves
    Make her follow you around to the elevator.
    Go through the elevator, closing both doors behind you, thus trapping her
    The path on the other side of the elevator leads you to her lair
  Elvira is NOT what she appears to be.  What happened?
    It Cerberus' idea of a little joke
    I'm obviously being held in another studio
    Kill her, and don't forget to grab the tomahawk on your way out
  I'm on my way out of the Spider Caves.  Is there anything I missed?
    Not if you've collected the following 
    Rope
    Binding spell
    Red mushrooms
    Lots of spells based on jewels
    Elevator key
    Edible mushrooms
    Tomahawk

Studio 2:  The Haunted House

  How do I get to Elvira's shadow in the hallway?
    There's a zombie in the way, right?  You'll need to get past him first
    The most effective weapon is a Turn Undead spell
    You'll need a brain (no, your own won't do; there's not enough there).
    There's a brain in a specimen jar in the basement of the house
    After all this, you discover that Elvira's shadow is only an illusion
    The real things . . . uh, thing . . . is stashed away somewhere else
  How do I get past the poltergeist guarding the library door?
    It's really just a kid at heart.  You should appeal to its instinct to play
    You could distract it with some toys, for instance
    Use the blocks on the floor of the nursery upstairs to lure the spirit away
    Be quick in entering the library before the spirit returns to guard the door
  How do you get the key from the fish tank?
    You'll have to get rid of the fish first
    Like, maybe, poison them
    There's a great poison recipe stuck between a book's pages in the library
    You'll need help mixing it up.  The Mad Scientist in the basement may help
    Poison the meat shank from the meat locker and feed it to the fish
    Reach into the tank and get the key
  What does the key to the fish take open?
    The safe in the study
    The safe is hidden behind the duck picture on the wall
    Insert the key in the safe, turn handle and click on safe
  How do I get out of the freezer when the door's locked from the outside?
    You'll need to get someone to come let you out
    Maybe if you set off the freezer alarm
    Get Elvira's butane curling iron from her dressing room
    Heat up the thermostat with the curling iron
    When the head ghoul shows up to investigate, put him on ice and leave
    If you only have a penknife select Berserk mode and hack away
  How can I get the Mad Scientist to cooperate with me?
    He hates everyone, but at least he talks to his assistants
    Maybe if you disguised yourself as a lab assistant
    There's a picture of his assistant inside the dead writer's script
    The dead writer is on the bed in the lavender bedroom upstairs
    Go to the makeup room and dress yourself up to look like the picture
    You need the white lab coat from the costume room to complete the disguise
  The Mad Scientist still won't talk to me.  What now?
    Make sure you've got all the elements of your disguise on straight
    Including the teeth, mustache, eyebrows, wig, half glasses and lab coat
    Did you ask if you could help?  He likes it when you kiss up to him
  I've always wanted to be a Mad Scientist.  How can I make Frankie go?
    You can do it, but it takes a lot of electricity to get the apparatus going
    For instance, you could harness the energy from an electrical storm
    Get the copper rod in the boiler room located in the studio office basement
    Get the ladder from the storage room upstairs
    Place the ladder against the skylight in the attic
    Don't know how to get rid of the vampire?  See clues under ATTIC section
    Put the copper rod on the chimney.  How do I get some lightning?
    Invoke the Summon Storm spell to draw lightning down the rod into the house
    Return to the basement and raise the lever on the right
    When the gauges on the left move into the red, throw the other switch . . .
    And watch him go!
  Ok, Frankie's not moving!  What happened?
    Did you already mess with his head before hitting him with the juice?
    Reload a file which you saved prior to messin' with Frankie, then juice him
  Ok, I've got Frankie moving!  Quick, how do I stop him?
    You'll need to cut off his power supply
    With the wire cutters in your inventory, click the pointer on his wires
  What happened to Elvira?
    She turned into a mass of decayed flesh, and you had to terminate her
    At least you've got the Chief's magic bag, right?
  What's with the dead guy on the bed in the lavender room?
    Fire a few Ice Darts at his wight, and he'll rest more peacefully
    Don't forget to get the script from him
  Anything else of interest here?
    Did you look under the bed?
    Push the red button and see what happens.
    Enter the Black Chapel behind the bed; take black candles & gold chalice
    Don't mess with the vampires hanging from the rafters in the secret room
    Carry your silver cross, unless you want to be attacked by the vampires
  The succubus is beautiful!  But how can I survive her attention?
    The key is not to be afraid of her
    Turn on a Courage spell before entering the room
  How do I get past the vampire?
    Remember that sunlight is very bad for a vampire's health
    If you break the skylight, you could shed a little light on the subject
    Force won't do it; there's got to be another sound method
    There's a tuning fork under the pillow in the succubus room
    Use the fork the instant you get to the top of the attic stairs
  How do I get up to the roof?
    You could fly, I suppose.  But a ladder might be easier
    There's one in the storage room across the hall from the lavender room

Studio 3:  It Came From Beyond the Grave

  That stupid bat won't let up.  How do I get rid of it?
    You could try to kill it, or . . .
    Just hurry up and get inside the church!
  What do I do about the dead priest behind the pew?
    You'll need a lot of experience before you can resurrect him
    If you don't have the experience, just leave him alone until you do
    If you're a Level 10 magician, you've got what it takes to do the job . . .
    . . . as long as you also have a Resurrect spell ready to go
    The spell requires Frankie's brain and scalp; the heart in the lab (more)
    . . . the eggs from the kitchen; and the prayer book from the church pulpit
  What do I say to the priest to make him cooperate?
    Actually, once you ask him for his help . . .
    . . . and tell him about Cerberus . . .
    . . . and ask him to draw you a pentacle in blood . . .
    . . . geez, he'll be glad to do what he can
    Did you give the priest the gold chalice from the Black Chapel?
    Before talking to the priest, did you ask the Indian how you could help?
    Did you read THE STUDY OF DEMONOLOGY in the house library's Humor section?
  Where are the $%^& Catacombs?
    There's a trap door in the church floor
    It's under the pulpit
    Drag the pulpit to the left, open the door, and go below
    Then go through the second trap door, and climb to the bottom of the pit
  Every time I take something out of an alcove, I die.  What gives?
    Every room and alcove in the Catacombs is rigged one way or another
    You'll need to use spells such as Breathe Underwater, Resist Fire . . .
    . . . or cut trip wires using your wire cutters
  I don't have enough magic & hit points to make it through.  What do I do
    There are lots of objects down here that will help keep you going
    The various potions can help you recover your health & magic power
    A dagger in an alcove on Level 2 restores powers points each time it's used
    There are also 2 shields and another dagger that'll improve your durability
  About the sorcerer . . . how do I get past him?
    He might be more cooperative if he thought he knew you
    Or that you were a fellow initiate of the Wizard's Guild
    Find a photo of a wizard in the dead writer's script in the lavender room
    Take it to the studio office makeup room and create a disguise to match
    You'll also need the Wizard's robe from the costume room
    Wear the disguise before you approach the Sorcerer.
    When he asks where you've been, tell him you've had food poisoning
  I just saw Elvira - and she disappeared.  Where'd she go?
    Tricked again, eh?  Too bad.
    Don't leave here without the lance.  And keep looking for me.  I'll turn up

The Defeat of Cerberus

  I found Elvira!!  Now what do I do?
    Well, you could go back to my dressing room and celebrate . . . 
    But don't forget that the Top Dog's still running loose in the neighborhood
    The directions for getting rid of him are in the library book called (more)
    . . . THE STUDY OF DEMONOLOGY in the Humor section
  Defeating Cerberus seems complicated.  What's needed to do the job?
    A Resurrect spell (see STUDIO 3:  IT CAME FROM BEYOND THE GRAVE section)
    A Bind Demon spell, using the scroll of binding & rope from the caves
    The Chief's magic bag, tomahawk and war lance (be sure he's blessed them)
    10 black candles from the Black Chapel hidden behind the lavender room
    Matches from the tea chest in the storage room
  The chief won't bless the bag, tomahawk and lance.  Now what?
    Still miffed at you for insulting him?
    Or did you just forget to bring him his peace pipe?
  Ok, I've got everything I need.  Now what?
    You'll need some help from a holy man
    The dead priest, for example
    Use the Resurrect spell to get his attention
    Tell him about Cerberus and ask him to draw you a pentacle
    When you get out to the parking lot, the pentacle will be all laid out
  Nice pentacle.  What do I do first?
    Lay out the 10 black candles on the junctions of the pentacle
    With the matches in your inventory, click on the candles to light them
  The candles are going.  What then?
    Have the blessed items INSTANTLY available in the inventory window
    You won't have time to go scrolling around looking for them
  Ok, my inventory is organized.  Now what?
    Use the magic bag to summon Cerberus
    When he shows up, use the Bind Demon spell
    When the lightning binding him dies down, throw the lance at his middle eye
    When he starts to cough up fire, throw the tomahawk at his heart
    If you do this right, that should be the end of the game!

CREDIT Elvira II hints written by Sarah Reeder/Adapted by Mark Ybarra