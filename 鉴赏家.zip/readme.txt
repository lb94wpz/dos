Virtuoso Copy Protection

NOTE: Not 100% complete.

Page	Para.	Line	Word
1	2	3	1	helmet
2	1	2	1	minimum
2	3	2	4	unsure
3	1	1	4	number
3	2	3	1	midi
3	7	1	4	password
4	1	2	2	clicking
4	3	1	2	screen
4	3	4	6	altered
5	1	1	4	allows
5	1	1	12	previously
5	1	3	4	highlighter
6	1	1	1	preventing
6	1	1	11	marauding
6	2	2	1	always
6	9	3	1	it
7	9	1	9	mission
8	6	1	3	your
8	7	4	3	contact	
9	2	2	14	floppy
