                    ____________________________________________
                    |    Ween: The Prophecy FAQ/Walkthrough    |
                    |             by TuxedoCyan                |
                    |          tuxedocyan@hotmail.com          |
                    |              Version 1.0                 |
                    |  Updated: December 21, 2001 06:10PM CST  |
                    ��������������������������������������������


                                     Contents

                        1. Introduction
                        2. Version/Updates
                        3. Walkthrough
                        - 3.1 The Cabin & Lab
                        - 3.2 Precipice
                        - 3.3 Stele
                        - 3.4 The Bridge
                        - 3.4.1 Crossing the Bridge
                        - 3.4.2 Underwater
                        - 3.5 Temple Entrance & Dragon
                        - 3.6 Maze & The Guardian
                        - 3.7 Sanctuary & Corridor Doors
                        - 3.7.1 Statue & Pond
                        - 3.7.2 Courtyard & The Queen
                        - 3.8 Staircase
                        - 3.9 The Beach & The Boat
                        - 3.10 Volcano Island
                        - 3.11 Plant Monster
                        - 3.12 Entrance to Volcano
                        - 3.13 Inside the Volcano
                        - 3.14 The Prison & The Revuss
                        4. FAQ
                        5. Credits
                        6. Copyright Info

___________________
| 1. Introduction |
������������������?
   Welcome to my Ween: The Prophecy FAQ/Walkthrough. This game is a Adventure/
Puzzle, First Person, point and click style game. I say this game is roughly
10 hours if you can get through the puzzles quick. Well, I made this
Walkthrough because there might be some puzzles that some people just cannot
figure out. I personally think that cheating takes the fun out of solving the
puzzles, but if you insist on help, then you are at the right place. Have Fun!

______________________
| 2. Version/Updates |
����������������������
Version 1.0 ; Updated December 21, 2001 6:10PM CST
- Guide Completed

Version 0.9 ; Updated December 20, 2001 5:52PM CST
- Finished sections 3.9 through 3.14

Version 0.6 ; Updated December 12, 2001 2:27PM CST
- Finished sections 3.6 through 3.8

Version 0.4 ; Updated December 10, 2001 1:20PM CST
- Finished sections 3.1 through 3.5

Version 0.2 ; Created December 7, 2001 4:36PM CST
 - Began Walkthrough

__________________
| 3. Walkthrough |
������������������
   I've divided the game into sections. I will show what Items you start out
with in each section, and explain how to accomplish each section of the game.
Also throughout the game, you have to put items together, or mix items to
form or get a new item. To do this, you go to your items list (from the menu,
or with right clicking), select the item, then go up to the menu and pull down
the items list and click the item you wish to use it with. Does that make
sense? Well, Good Luck!


----- 3.1 The Cabin & Lab -----


      Starting Items: Strawberries


         Getting started, Click on the crystal ball. It will become a Copper
      Ball. You will also learn that you need a Flute now to call Urm.
      Click and take the Tongs next to the fireplace. Click and open the
      cupboard. Take the Lard and then click on the lower shelf of the
      cupboard and take the Knife. Now click and go to the back room.

         Here in the lab, move and click on the brown Tablet to the right and
      take it. You will see there's a gold pad lock that keeps the trap door
      locked. That is the exit of this level. If you tried, you will notice
      the key laying there does not work on the gold padlock. You need a
      Golden Key. Look to the right and pick up the digitalis (small bottle).
      Underneath the table is a bag of Seeds, Click and take it.

      You will notice that the skull seems to have something inside of it.
      Pick of the key and use it on the skull to break the skull open (You can
      also use the Copper Ball on the skull to get the same results). Inside
      the Skull is a Ring, take it. Click on the Picture and move it over to
      the hook on the wall. Click on the hole in the wall and discover a nasty
      rodent. This little guy is guarding something. To get him out of the
      way, go to your items, click on the digitalis, then go up to the menu,
      go to items again, and click the digitalis on the seeds.

      Now take the Drug and give them to the rodent. This will put him to
      sleep. Move your mouse around to the right of him to find a Mold. Now
      you have what you need for a key, now you just need some melted gold to
      pour in it to have a nice golden key. Exit the Lab back to the Main
      room.

      Now take the left door and go outside.

         Outside, take the straw that is sitting on the handrail. The handrail 
      would make a good set of wood. Use the Tongs on the handrail to receive
      The wood. Pull out your Knife and use it on the Reed. Use the Knife
      again on the Reed in your inventory to make a Flute out of it. Go back
      inside the Cabin.

      Once Inside, your two new friends will show you that if you put the Ring
      and the Copper Ball together, you will get a Cauldron. You can use the
      Ring on the Cauldron again to get the Copper Ball back. Now select the
      Flute, take it up to the menu, go to the people icon, and Click on Ween.
      This is how you summon your friend Urm the Vampire Bat. Urm usually will
      only help you if you give him some fruit. After you summon him, Give him
      the Strawberries. Urm will trade you for some Gold. Now all you need to
      do is melt the gold right?

      Urm will knock over some stuff, so pick up the Jar that falls on the
      floor. Toss the Wood and the Straw into the fireplace. Now you need a
      fire. Call Urm with the Flute again and give him the Jam. He will ask
      you what you want him to use his powers on. Click him on the fireplace,
      and now you've got a fire! Put the Cauldron in the fireplace, then put
      the Gold bar into the Cauldron. Now take the Cauldron use it on the
      Mold. Now you've got A Golden Key. Go back into the lab, Use the Gold
      Key on the Gold Padlock. Take the Half-Statue Fish that forms, and
      exit the level.


----- 3.2 Precipice -----


      Starting Items: Lard
                      Cauldron (Copper Ball)
                      Flute
                      Ring
                      Tablet
                      Half-Statue


         You will find yourself in an underground area now. Take the Torch and
      the red Planks underneath it. The exit is just right in front of you but
you cannot get over there without a bridge of some sort. That is where
      the Planks come in. But the Planks you have right now are too short. You
      will discover a door where the Planks were, go in. Pick up the Rope and
      use it on the Planks to get 1 long Plank. If you tried to exit the level
      now, you still would not be able to because the Plank is not strong
      enough alone.

      Notice the skull statue in the top left. To operate it, you must use
      your Copper Ball on the right eye to give the skull 2 eyes.
      Once you do this, the mouth will open. Take the Moon Stone and then try
      to operate the lever. The lever is rusted, so you need some oil. Take
      your Copper Ball back, and go back to the main room. Use the Torch on
      the hearth to start a fire. Now put your Cauldron down on the fire. Take
      your Lard and put it into the Cauldron. Now that you have the Oil, take
      it back to the other room, and pour the Oil into the Bowl. Use the Bowl
      of Oil on the opening of the mouth near the lever. You will see that
      this did not work. Use the Tibia on the opening of the mouth, and then
      use the Oil on the Tibia. Now the lever will work.

      Go back and use the Plank on the Precipice and exit to the next level.


----- 3.3 Stele -----


      Starting Items: Copper Ball
                      Flute
                      Ring
                      Tablet
                      Half-Statue
                      Torch
                      Moon Stone


Ok, Take your Torch and put it in the Torch Holder in front of you.
      Click on the skull that is on the left and watch it fall down crashing.
      Take the Sun Stone where the skull was. The door to the right is locked.
      Pick up the Spear from the statue. Pick up the Tibia off the ground
      which is kind of hidden to the bottom left. Use the Tibia on the Spear.
      Now you can reach the curtain and click on the Blackberries. You have
      fruit now, so that means it's time to summon Urm. Use the Flute and give
      Urm the Blackberries. Then point Urm to the opening above the door to
      the right. Urm will fly in and get a key. Use the key on the door lock
      to enter.

      Click and try to take the sword. After Urm makes a fool out of you, use
      the Sword on the statue. Now open the trap door. The acid must be taken
      out, so use your cauldron on the acid until it is all gone. Click on
      the mechanism to get a close up. There are 2 different codes you can
      press to get 2 items. Click the Sun, the Moon, and the crown. Click the
      Sword, the moon, and the crown. Take the Elixir and the Effigy and exit
      the room. (NOTE: The Elixir is *optional*)

      Click on the little green Borgol for some info. Click on the Stele and
      place the Sun Stone and the Moon Stone in the left niche (in any order
      you want). Use the Acid from your Cauldron to melt the rust. Place the
      Effigy in it's niche and this level is complete.


----- 3.4 The Bridge -----


      Starting Items: Cauldron (Copper Ball)
                      Flute
                      Ring
                      Tablet
                      Half-Statue
                      Elixir *Optional*
                      Grain of Sand


         First of all, try to cross the bridge. A monster will pop up and keep
      you from advancing. After talking to the beast, pick up the Feather that
      falls to the ground. Now, there are 2 different solutions to this level.
      You can take the bridge by defeating the monster *must have the Elixir*,
      or you can go for a swim. Which ever you choose will lead to the same
      goal in the end.

      If you want to take the Bridge, read on here...

         Open the chest to the right. It is empty. Use the Feather on the
         chest to discover a note, Pollen, and Venom. Get your Cauldron ready
         and use the Venom, Pollen, and Elixir (In no particular order) in the
         Cauldron. Now use the Potion 1 on the Monster, and watch him die.
         Exit across the Bridge.

         *** Go to 3.4.1 to continue ***

      If you want to go for a swim (or don't have the Elixir), read on here...

         Open the chest to the right. It is empty. Use the Feather on the
         chest to discover a note, Pollen, and Venom. Get your Cauldron ready
         and use the Venom, and the Pollen in the Cauldron. Now use the Potion
         on the leaves to the right of the chest. Take the newly formed
         Strawberries. Summon Urm with the Flute and give him the
         Strawberries. Urm will trade you with a bar of Gold. Use the bar of
         Gold on the Half-Statue in your items. The fish statue will be whole
         now. Use it on the water and exit the level.

         *** Go to 3.4.2 to continue ***


----- 3.4.1 Crossing the Bridge -----


      Starting Items: Cauldron (Copper Ball)
                      Flute
                      Ring
                      Tablet
                      Grain of Sand
                      Venom
                      Pollen


         Urm will suddenly come on screen and eat the Giant Strawberries. Urm
      will then leave you a giant pile of Gold which now blocks your exit.
      Click on one of the holes in the ground to discover a Orivor. Now you
      must catch him. Use the Sword on the rock to cover one of the holes.
      Pull out your cauldron and cover the other hole. Now click on the hole
      that is on the side of the cliff to catch the Orivor. Use the Orivor on
      the pile of Gold and exit.


----- 3.4.2 Underwater -----


      Starting Items: Cauldron (Copper Ball)
                      Flute
                      Ring
                      Tablet
                      Grain of Sand
                      Venom
                      Pollen


         Click on the staircase to try to exit. The bars will close on you.
      Try the staircase again for the same result. Notice the insect and click
      on it. Click the insect on the green electrical fish. Well that just
      feeds him right? On the far left, click on the seaweed and watch the
      little fish get eaten by the big fish you saw a while ago. Now, take
      the Insect again, and click it on the Seaweed. Watch the Electrical Fish
      get eaten by the Big fish and kill the big fish.

      Now use the little piece of Glass on the ground on the dead fish to open
      him up. Take the steel bar. There is a small crack on the rock near the
      staircase. Use the steel bar on the crack several times. Now use the
      Steel bar on the crack right next to the staircase to make a chunk of
      the wall fall off. Now try to use the stairs again to find that the bars
      get stuck in the closed position.

      Now, click on the Seaweed again to watch the fish swim over to near the
      staircase, and get eaten by another monster. Examine the fish bones he
      spits out to receive a Harpoon Point. Attach the Harpoon Point to the
      Steel Bar, to make a home made Harpoon. Click on the seaweed again, and
      then use the Harpoon to catch a fish. Now take the Harpoon with fish on
      it, click it on metal bars blocking the exit. The monster will attack
      the fish and bend the bars all at the same time... Now exit to the next
      level.


----- 3.5 Temple Entrance & Dragon -----


      Starting Items: Cauldron (Copper Ball)
                      Flute
                      Ring
                      Tablet
                      Grain of Sand
                      Venom
                      Pollen


         First of all, you should notice that you have seen this screen
      before. Pick up the Tiara. This is the second special item that can be
      used on your Copper Ball. Take out your Venom and change the Snake into
      Quartz. Use the Torch on the bushes to burn them out of the way. Use the
      Tiara on your Copper Ball to get a Pipe. Use the Pipe to reach the Wasp
      Trap. Use the Wasp Trap on the Wasps. Exit.

         Now you must defeat this weird looking Dragon monster by using the 3
      Parchments you have at the bottom left of the screen. The easiest way to
      do this, is to click the bottom parchment 5 times. The dragon will be a
      Wasp and you will be a Worm. Use the Wasp Trap on the Dragon/Wasp. Now
      click and pick up some Cherries on the ground next to the cherry tree.
      Summon Urm and give him the Cherries. Then click him on the Wasp Trap.
      The dragon has been defeated! Exit.


----- 3.6 Maze & The Guardian -----


      Starting Items: Flute
                      Ring
                      Tablet
                      Venom
                      Pollen
                      Tiara
                      Pipe (Copper Ball)
                      2 Grains


         Ok, This maze is pretty tricky, and even I haven't had the time to
      run through it and try to figure it out. But I do know the quickest
      solution. First, click on the little green Borgol for some info. Use
      your Tablet next to the green tablet to the left. Now click on the far
      left mechanism of the left door. Click the BOW, GOAT, CAULDRON, and
      ROAST in that order. Click the skull to activate, and exit through the
      door. Now, at the second door, click on the mechanism. Click and take
      the Vial. Ok, this part I am told the code changes every time you start
      a new game. Try clicking the code in this order. 1, 3, 4. If that
      doesn't work, just keep messing with it until it opens, it shouldn't
      take too long. Exit through this door when finished.

         Now you will find yourself at the Guardian the Borgol just told you
      about. First click on the Guardian for some info. You need to make a
      potion to help the Guardian. First pick up the pile of wood and place it
      on the hearth. Pick up the little gold coin (Ecu) and keep it. Place the
      Vial right where the Ecu was. Click on the fountain head. Take the
      lichen and place it on the hearth. Click on the teeth in this order, 12-
      4-6-3. Click and take the leaves from the right.

      Pick up the Hammer on the ground that is laying in between the hearth
      and the block where the Vial is. Use the Hammer on the statue arm to the
      left. Pick up the Amphora (The thing the statue was holding) and place
      it on the hearth. Pick up the Rag from the head of the statue. Use the
      Rag to clean the eyes of the statue. Pull out your Pollen and use it on
      one of the eyes to get a flower. Take your Venom and use it on the other
      eye to make a Snake.

      Click and take the flower and put it on the hearth. Pick up the Gargoyle
      off the ground next to the statue and put it on the ledge next to the
      other gargoyle. Use your Pipe on the Snake, then use the Coil on the
      gargoyles. Click on the stone wall behind the guardian to reveal sun
      light. Pick up the Magnifying glass from the ground, and use it on the
      sun beam. Pull out your leaves and use it on the hearth. Now take your
      Rag and wet it in the fountain. Put the Wet Rag on the Coil.

      Now take the finished Potion and give it to the Guardian. Take your Coil
      back and change your Pipe back to the Copper Ball. Put the Copper Ball
      on the little Statue and click the statue again. Take the Copper Ball and
      Exit.


----- 3.7 Sanctuary & Corridor Doors -----


      Starting Items: Copper Ball
                      Flute
                      Ring
                      3 Grains
                      Hammer
                      Ecu
                      Tiara


         First, click and take the Necklace. Click on the chest to the left.
      To get the Heart from under the spiders, take the Glove from the statue
      and use it to take the Heart. Put the Heart in the heart shape niche
      that is on the statue to the right. Pick up the Chalice and use it on
      the Scales the statue is holding. Click on the statue's (right) nose to
      open a path. Now click on the curtains (or tapestry) to the left of the
      altar and take the Mirrors. Check the vase to the right of the altar for
      a Key. Go into the passage. Use the Mirrors on the openings. And use the
      Key on the lock to exit.

      Now, you have a fork in the road. You can choose to go Left, or Right.
      Both paths lead to the same goal in the end.

      * If you choose the Left Door, go to 3.7.1

      * If you choose the Right Door, skip to 3.7.2


----- 3.7.1 Statue & Pond -----


      Starting Items: Copper Ball
                      Flute
                      Ring
                      3 Grains
                      Hammer
                      Ecu
                      Tiara
                      Necklace


         Your friend Urm has been turned to stone and you must bring him back
      to life. Use your Copper Ball and turn it into the Sword with the
      Necklace. Put the Sword in the Statues hand to get a Lightning Bolt. Use
      the Lightning Bolt on the pulley of the well to pull up a treasure chest.
      Take the Net that is laying on the ground between the column and the
      middle statue. Click and take the hooping from the barrel. Exit to the
      right.

      Click on the Grill. Use the Net in the water to catch a fish. Put the
      Fish in the trap and take the Crab. Use the Grating (Grill) on the
      Hooping to make a Sieve. Use the Sieve in the water to get the Nuggets.
      Exit back to the left.

      Click on the chest on the well. Use the Crab on the chest to break the
      chain. Pull your Sword out and use it to open the chest. Take the Key
      and use it on the black chest under the sleeping statue. Now put the
      Nugget, Lightning, and Sun on the pedestal to the right.

      Continue at section 3.8
 

----- 3.7.2 Courtyard & The Queen -----


      Starting Items: Copper Ball
                      Flute
                      Ring
                      3 Grains
                      Hammer
                      Ecu
                      Tiara
                      Necklace


         The Queen monster must be killed in order to get to the exit. First
      take the Bag from the far back left hand corner. Use the Bag on the
      Snake. Before you pick up the bag with the snake inside, pull the string
      closed on the bag to seal the snake inside, or else you will not be able
      to pick up the snake. Give the snake to the mongoose. Use your Sword on
      the larch tree and take the root from the bottom left. Use the root
      on the Resin and the Resin on the small monsters. Change and take out
      your Pipe. Use the Pipe on the water flow. Put the Pearls and take and
      use the Digitalis on the basin. Take the Femur from the bottom of the
      tree to the right, and use it on the basin. Use the mixture on the
      Queen. Change and use your Sword on the rope, and Exit.


----- 3.8 Staircase -----


      Starting Items: None


         Well now, your bag of stuff has been stolen. The exit is covered by
      boulders. First, grab the Horn from the skull head to the right. Place
      the Horn next to the wooden stick to the right. Click on one of the eyes
      of the skull for a worm. The worm will tell you if you put some water on
      the mushrooms, the mushrooms will grow, thus pushing the boulders out of
      the way, and then the worm can eat the mushrooms. There is a green stick
      that is in the background that can detect where water spots are in the
      ground if you want to try to find it yourself. If not, I'll tell you the
      water spot is at to bottom left.

      Take the creeper (vines) that hangs from the center rock, and use it on
      the Horn and Wood. Use the Pick Ax on the water spot. Take the Bowel or
      the Pot and fill it with water. Now toss the water on the mushrooms. Now
      during all of this, the Mosquito should have appeared and made his scene
      landing on the flower, then the Bird comes and tries to get him while he
      flies away, and this all repeats over and over again.

      Use the Bowel or the Pot and take some Resin from the tree on the far
      left. Put it on the flower so the mosquito will get stuck. When the bird
      comes back, the bird will continue to just hover there trying to get the
      mosquito. Take the Stone from the ground and use it on the Bird. Now
      click on the skull eye again to get the worm to come out and use him on
      the mushrooms. Exit.


----- 3.9 The Beach & The Boat -----


      Starting Items: None


         First, Click on the Owl to find out that he has your backpack. All
      you need to do is give the owl some gold to get your stuff back. Locate
      and pick up your Flute off the ground and take the Strawberries. Summon
      Urm and give him the Strawberries. Give the gold to the Owl and take
      back your backpack. Pick up the Oar and put it on the back of the boat
      on the notch. Click on the spider to find out that he make you a sail
      for your boat if you give him some fish eggs. Pick up the net and use
      it on the water to get a fish. Now pull out your Sword and use it on
      the Fish. Give the fish eggs to the spider and take the sail.

      Take out your Sword again and use it on the Bamboo that is over the
      spider. Now put the Bamboo on the boat. Put the Sail on the Bamboo. Now
      take out your Hammer and use it on ribs to the upper left. Put the Ribs
      on the boat. Click on the coconut tree to bring down a bundle of
      coconuts. Put the Coconuts in the lobster pots, and put the lobster
      pots on the ribs of the boat. Ok, now a little warning about the next
      part. You are kind of on a time crunch so you have to be careful.

         Ok, On the way to Volcano Island, you will get a leak in your boat. To
      plug the leak, you are going to need the cork from the bottle that is
      floating in the water. As your time goes by, the water will be filling
      up your boat. To bail the water out, use your Cauldron. Meanwhile, you
      need to use your Pipe to reach the bottle to get the cork. The front
      of the boat has a door locked with a pad lock. The key won't work so
      use your Hammer to break the pad lock. Once you have the cork, use the
      tar from the locked door on the cork. Now, all you have to do is make
      sure you can see the hole where the leak is, put the cork (with tar) in
      the hole, and then pull out your Hammer real quick and hammer it down.


----- 3.10 Volcano Island -----


      Starting Items: Cauldron (Copper Ball)
                      Flute
                      Ring
                      3 Grains
                      Ecu
                      Tiara
                      Necklace


         Now you have arrived to Volcano Island. The front gate seems to be
      locked. Take your key from the boat and use it on the lock on the shed
      to the right. Meet the old man. He says if you give him lots of treasure
      to satisfy his needs, he will let you use the lever to open the gate to
      get into the Island. Take the Shovel and go back outside. Use the Shovel
      on the sand till you have dug up 8 holes. Use the Sword on the Oyster
      to take the Pearl. Now, take the Pearl, Glass Eye, Fishbone, Diamond,
      Jewels, Sandal, Ingot (Gold Bar), and enter back into the Shed. Call Urm
      and give him the Strawberries from the table. Now, Give the old man the
      Pearl, Glass Eye, Fishbone, Diamond, Jewels, Sandal, Ingot, Ecu, and
      the Gold Urm just gave you. After he leaves, pull out your sword and
      use it on the planks (wall) behind where the old man was to reveal the
      REAL exit.


----- 3.11 Plant Monster -----


      Starting Items: Flute
                      Ring
                      3 Grains
                      Sword (Copper Ball)
                      Tiara
                      Necklace


         Ok, First take out your Sword and cut the branches on the right and
      the branch to the bottom left. Change your Sword into the Cauldron and
      plug one of the holes on the ground and click on another hole to get
      the Orivor to pop something out of the ground. Pick up the Pendulum and
      move it around the center till you see it swing. Use your Sword on the
      grass where the Pendulum was swinging to reveal some Gold. Pick up the
      Gold and give it to the Orivor and he will give you some rope.

      Pick up the Rope and use it on the curved branch at the bottom left. Now
      you have a Bow and Arrows. Pick up the Bow and shoot at the Walnut in
      the tree. You will miss and hit a bird instead. After the scene, get
      your Pipe and use it to get the feathers. Put the Feathers on the
      Arrows. Now shoot the Walnut again. Take your Sword out to cut the
      Walnut open. Exit.


----- 3.12 Entrance to Volcano -----


      Starting Items: Flute
                      Ring
                      3 Grains
                      Sword (Copper Ball)
                      Bow
                      Tiara
                      Necklace


         Pick up the Cane and use it on the Glass Eye. Talk to the old man.
      Pick up the Strawberries and summon Urm. Give him the Strawberries and
      give the Gold to the Old man. After the scene, use the Cane on the Eye
      again. Pick up the Red Currants to the bottom left and summon Urm again.
      Give Urm the Currants and use Urm on the Old man. Now before going to
      the next room. Pick up the Feather and use it on the Chest to reveal
      bottles of Pollen and Venom.

      Get your Cauldron ready, and use Pollen and Venom in the Cauldron. Use
      the Potion on the mushrooms. Pick up the Truffles. Mix up another batch
      of Potion again (Pollen & Venom) and use it on the Grass in the  center
      to the right of the ruby. Take the Chamomile. Prepare some Luciferys
      (Venom & Truffle) in the Cauldron and use it on the Ruby. Now use the
      Cauldron on the water, and put the Cauldron on the hearth. Take out the
      Chamomile and put it in the Cauldron. Now use the Cauldron (Tea) on the
      Worm, then use the worm on the mushrooms. Go to the next room.

         It seems your buddies have dropped the 3 grains of sand. First, take
      out your Sword and use it on the bush. Prepare the Cauldron again and
      Mix up a batch of Vitalys (Pollen & Truffle). Use the Vitalys on the
      Borgol. Click on the Ant at the top right-hand side. Pull out the
      Pollen and use it on the Quarts on the ground. Click on the flower and
      take the Pistil and give it to the Ant. Once you have turned into an
      Ant, take the Ax and the 3 grains back (One is under the Ax, one is
      to the far left and one is to the far right).

      Now that you have your 3 grains back, Prepare some more Vitalys (Pollen
      & Truffle) and use it on the bird statue. Lower the lever where the
      bird was. Exit back to the right to the last room. Click on the
      mechanism. Put the axle on the orifice and lower the lever. Take the
      Key and exit back to the left. Use the Key on the locked door. Prepare
      the Cauldron again and mix up a batch of Change potion (Pollen, Venom &
      Truffle). Use the Change Potion on the Grill. Use some Venom on the
      snakes. Mix up some Luciferys (Venom & Truffle) and use it on the Rubies.
      Go back to the other room and get some Water in the Cauldron. Use the
      Water on the flames and exit.


----- 3.13 Inside the Volcano -----


      Starting Items: Cauldron (Copper Ball)
                      Flute
                      Ring
                      Truffle
                      3 Grains
                      Pollen
                      Venom
                      Bow
                      Tiara
                      Necklace


         Pick up the bowel. Click on the small ornament on the statue. Use the
      Sword on the ornament and pick it up from the floor. Use the Sword four
      times on the hole that was left. Mix a batch of Luciferys (Venom &
      Truffle) and use it on the ruby. Take the jewel from where the ruby was.
      Click on the hideaway on the pillar to the far right. Click in it four
      times. Use the bowel and pick up the glue. Now you must do a rather long
      task to light up all the hideaways before you can lower the drawbridge.

      1. Prepare some Vitalys (Pollen & Truffle) and use it on the Jewel.
      2. The Firefly will fly away. Take out your Sword and use it on the
      Crack at the bottom left and the Firefly will fly down and land.
      3. Take the Firefly and use it on the Glue.

      You will need to do these steps over and over again to light up all of
      the hideaways.

      Follow the steps and use the Firefly/glue on the first dark hideaway to
      the far right. Take the Twig and use it on the top opening of the
      Statue's pipe. Take the Jewel. Prepare another Firefly/glue with the
      steps above and use the Firefly/glue on the hideaway to the left of the
      first one. Take out your Copper Ball and use it on the hole, then click
      the Copper Ball again in the hole. Take the Jewel and repeat the steps
      above again. Use the next Firefly/Glue on the hideaway of the pillar
      at the back on the left. Take the cracked jewel and use it on the glue.
      Now put the Cracked Jewel and the Broken Jewel together to form a Jewel.

      Repeat the steps again to make another Firefly/Glue and use it on the
      middle pillar to the left. Take the fallen Jewel by the drawbridge and
      repeat the steps yet again to make one more Firefly/glue. Put the final
      Firefly/glue in the left and last hideaway.

      Now, to lower the bridge. Start from the far left hideaway and click on
      the lever until you see some letters light up on the letter panel. Go to
      the next hideaway to the right and click on the lever until more letters
      light up. Just keep going to each hide away until all the letters are
      bright. Now quickly take out your Bow and shoot the letters in this
      order > K R A A L. If you did it right, this section will end. If you
missed a letter and spelled wrong, you will have to re-light up all the
      letters again with the hideaways and try again.


----- 3.14 The Prison & The Revuss -----


      Starting Items: None


         Well now, you have been thrown into a prison cell and your backpack
      has been taken by Kraal. First pick up the Heart and put it in the heart
      carving on the wall to the right of the bars. Move your mouse around on
      the far left wall near the bottom to find a Nail. Click on the Nail
      several times to take it. Click on the door lock. Put the Nail on the
      sixth hole clock wise on the right dial, then click on the needle. One
      of the prison bars will raise. Click at the bottom of where the Bar was
      and pick up the Pin. Go back to the door lock. Put the Nail in the
      seventh hole clock wise on the right dial. Now put the Pin in the third
      hole clock wise on the left dial. Click on both needles and exit.

         Now you are finally at the Revuss. Quickly click on the levers first.
      Click on the right lever 4 times, then the center one 4 times, then the
      left lever 4 times. Click on the carvings to the left and press the
      letters D J E L. Click above the hideaway and put the heart in the
      orifice. Take the knife and collect the bamboo that is laying to the
      lower right of the machine. Use the knife on the bamboo, and then do it
      again to make a new Flute. Use the Flute to call Urm. Take the stone
      Urm leaves and use it on the hole in the carving. Click the letters
      A Z E U L I S S E. Take the statue from the right hideaway and use it
      on the niche above the carving. Take the 3 Grains of sand and put them
      in the Revuss. You have completed the game!


__________
| 4. FAQ |
����������
   Q1. What can the Copper Ball be turned into and what are the three treasures
       that influence the copper ball?

   A1. Copper Ball + Ring     = Cauldron
       Copper Ball + Tiara    = Pipe
       Copper Ball + Necklace = Sword


   Q2. What can I do with the pollen, venom, elixir & truffle?

   A2. Pollen + Venom           = Potion    * For making plants grow
       Pollen + Venom + Elixir  = Potion 1  * For killing the monster(See 3.4)
       Venom  + Truffle         = Luciferys * Change ruby into fire
       Pollen + Truffle         = Vitalys   * Bring stone to life
       Pollen + Venom + Truffle = Change    * Effects silver metal

______________
| 5. Credits |
��������������
- Sierra (www.sierra.com)
For publishing this cool game.
- Gamefaqs.com (www.gamefaqs.com)
For having such a great site with so many faqs.

_____________________
| 6. Copyright Info |
��������������������?
   This document is (c) copyright of TuxedoCyan 2001-2002.  This document
and any part of this document is for public use on the www. and can not be
sold, reproduced, copied, edited, or re-written. This document was
originally posted on www.gamefaqs.com and may not be posted on any other
websites without my permission. In other words, DONT DO ANYTHING ILLEGAL
WITHOUT MY PERMISSION PERIOD! Ween: The Prophecy(tm) and all related elements
are a (tm) trademark of Sierra, and or Coktel Vision. No copyright
infringement is intended, or should be inferred.

