UNIVERSE WALKTHROUGH


LONELY ASTEROID
After the intro, you find yourself standing on a sort of bridge near a satalite dish. Your first task is to repair the satalite dish. Walk off the screen at the bottom left. You automatically jump onto the asteroid below.

Head north 2 screens and PICK UP the bent metal bar. Go north another 2 screens until you are back at the bridge screen. Go west 2 screens and PICK UP a piece of circuit board. Go east 2 screens to return to the bridge screen.

This bit is quite tricky. Stand near the left edge of the screen. As soon as the spinning asteroid appears, JUMP on it. If you miss it, just walk back south one screen and wait for it to appear again. When you (and the asteroid) are near the bridge, JUMP onto the bridge. You automatically walk back to the satalite dish.

INSERT the bent metal bar into the panel on the satallite dish to open it up. PICK UP the panel that fell to the ground. INSERT the circuit board into the panel on the satalite dish. Now USE the satallite panel. The screen displays some information. Click on "Set filtration system", then click on "Gavric Homeworld". Click on "Connect channel" then click on "Gavric Homeworld". This extends a bridge. Simply walk up, into the town.



TOWN
PICK UP the food container on the right of your screen. Look at the 2 ventilation shafts on the left of your screen. PUSH\PULL the large one. You'll find yourself back on the asteroid, along with a mirror and some garbage. PICK UP the mirror and the 3 bits of garbage. Now you want to get back to town.

Head south one screen. Stand near the left edge of the screen. When the spinning asteroid appears, jump into it. When you are near the bridge, jump onto the bridge. You automatically head back to the satalite dish. Head north into town. SAVE YOUR GAME HERE. If you get arrested, just restore your game. Do not talk to any of the robots. Walk off the screen by the top left exit.

There is a red doorway on your right. THROW the mirror at it. This destroys the lasers guarding the door. An alien will appear at the window and tell you to go and see some-one called Sylphinaa. Sylphinaa's door is at the top of the screen. USE the keypad on this door. She will open the door and let you in. Talk to her, and she will agree to help you.

When the robots are outside her door, you must SAVE YOUR GAME HERE. You need to be quick here. Look at the upper-right door. ATTACK the door keypad with your bent metal bar. You automatically walk through the door. OPEN the wardrobe door and WEAR the suit inside. The suit has some nice accessories, so make sure to check your inventory at this point.

USE your newly-acquired arm-computer on the main console above the bed to turn it on. Now USE the main computer console above the bed. Click on "Window shutter" to open the window. Right-click to close the console screen. JUMP out of the window. USE your arm-computer with the car to turn off the force field. JUMP into the car.



THE CAR
In the car, look for the card input slot for the anti-theft device. It is just below the moniter with the green cursor. INSERT your green keycard into this slot. USE the anti-theft device keypad on the right of the main navigation moniter. Type in the code 87764. After your vision, you will meet Snorglat. Be polite to him. He will help you if you give him a cheap ring.

USE the navigation screen (the main moniter, in the center). Click on 'Navigate course'. You will see a kind of map. Click on 'Lay in course' at the bottom of the screen, then click on the Balkamos 7 planet in the map. When you reach the planet, USE the navigation screen again, and click on 'Descend to planet'. Now you are hovering the surface. USE the navigation screen again and click on 'Select Quadrant'. Click on the north-east quadrant to land.


BALKAMOS 7
Head north to see the space wreck. PICK UP the droid lying near your feet. Head east 1 screen, then south 2 screens. PICK UP the canister. Head west 2 screens, then north 1 screen. You'll see some aliens vandalising your car. COMBINE your canister with the droid you picked up, then USE the droid on the aliens. JUMP into the car and USE the navigation console. Click on "Ascend from planet". USE the navigation screen again and click on "Navigate course", then "Lay in course" at the bottom of the screen. Click on the "Jor-Slov planet. When you reach the planet, USE the navigation console to "Descend to planet". USE the navigation console again to "Select quadrant", and click on the north-west quadrant.



JOR-SLOV
Head east, and you'll see an alien sucking up blue blobs. PICK UP the rock and THROW it at the alien. USE your droid with the blue blobs (not the alien), then return west to your car. JUMP into the car and USE the navigations console. Make your way to the south-east quadrant (you know how to use the navigation console now). When you land, head west 2 screens and you will see the hermit (old creature). TALK TO him, and give him the blue blobs. In return, he will give a carvite stone.

Return east to your car, and JUMP into your car. Navigate a course back to the Pfallenop Asteroid Cluster, where you started from. You will run into Snorglat again, just give him the carvite stone crystals.

Now we have an arcade sequence. You must dock you car in his space ship. I found it very hard to control the car. To move the car, left-click your mouse and use the cursor keys. To operate the grabber, right-click your mouse.



LANDING BAY
No matter what you do here, you will be shot. When you recover, jump into your car. Lay in a course for Landing Bay Ref 40e (scroll right a little bit). PUSH the robot mechanic into the hole, then PICK UP the cable from his toolbox. JUMP into your car and head for Landing Bay Ref 1h. LOOK at the sky. After your vision, go through the gate.



ENTERING WHEELWORLD
PICK UP the flask of blue liquid near the steps where you entered. Go through the gate that is middle-right of the screen. Walk onto the elevator. When it breaks, USE the cable on the elevator. TALK TO the tramp and be polite to him. Give him your blue flask and he will give you an ID pass.

Walk back beside the elevator and cable. JUMP on to the cable. Now USE your droid with the elevator controls at the top and you'll find yourself back on the road. Head north along the road to find yourself in Kaleev Way. Go up the esculator, then head right. Go up this esculator as well. There is a blue dispenser unit on your left. INSERT your blue ID car, then click on "PRESS TO ORDER".

Go back down the esculator, then head left. Enter the arcade through to door to the north.



ARCADE
Enter the arcade by the entrance at the north. If you want some fun, USE the terminals on the right (press Q to quit). LOOK at the alien guy sitting on his own. TALK to him and offer to buy him a drink. TALK to him again, and ask him if he wants another drink. COMBINE the carvite with the brandy. TALK to the alien guy again and give him the (spiked) brandy. He will pass out and you will take his badge.

Leave the arcade. Go down the esculator to the car park. SAVE YOUR GAME HERE. head south and talk to the man in trouble. He will send you after the jetpackers who stole his hand(!).

Now follows a very long and very tricky arcade sequence. You must fire constantly (stay high) at the jetpackers, and ram them into the walls. Move the mouse left and right to move you car left and right. Click the mouse to fire.

Eventually you will catch up with one of them. Persuade him to give you the healer's hand. Walk back through the gate and leave the screen bottom right.

Follow the road north (to the car park), then head east to find the healer again. TALK to the healer, and return his hand, TALK to him some more, and he gives you a starchart.



ESCAPE
After the cut-scene, you will run to the elevator. SAVE YOUR GAME HERE. JUMP down on to the elevator, then JUMP on to the ground. Run down the alley near the tramp, and walk to the opening on the bridge. JUMP on to a train. When the train stops, JUMP onto the right-hand post. Now JUMP onto the track below you. Follow the track up and right until you are in front of a door. There is an air filtering duct next to it. USE your droid on this air duct.

When you enter the spaceport, your droid will die. LOOK at the red terminal next to your droid. INSERT your blue ID card in the terminal, and click on "Mekanthallor Galaxy".

Walk over to the door on the left and USE it. USE your ticket in the terminal next to the forcefield, then exit east. SAVE YOUR GAME HERE. You must be quick here. USE the panel next to the shuttle door. You will enter the shuttle and escape.


ON THE SHUTTLE
TALK to the official standing near the window, the man sitting with a drink, and the shop assistant. The blue markings on the floor show where the elevator is. USE the control panel next to the elevator door and click on "Launch Bay".


In the launch bay, TALK to the droid next to the doors about your car, and he will yell at you. LOOK at the blue car next to the purple one. USE the console that controls the lift, and click on "Level 1". LOOK at the builder in the brown top, and TALK to him. Ask him about security services, then say you are from Wheelworld Security.

Head left a screen, then USE the door-console next to the brown door. You will enter, and get a message from the rebellion. LOOK at the console on the right (where the message came from) to discover it is used for communications. USE the communicator and click on "Level 3", then click on "Myrell".

Exit your room to the left, then head right back to the lift. USE the console that controls the lift, and click on "Level 3". When you leave the lift, head east and follow the path until you find Myrell'ss door. USE the door console to talk to him. He will let you in. TALK to him some more, and he will give you another piece of star chart. He will send you to the planet Haldebar. Exit the room west. You will be threatened by a cop - choose option 1 in the dialogue. The cop will be knocked you. PICK UP her gun and her keycard. Follow the path round until you return to the elevator. USE the lift console, then click on "Launch Bay".

JUMP into your (blue) car to escape.



ANKARLON 5
USE the navigation console to make your way to Ankarlon 5. Choose the north-west quadrant. After you land, head west, past the giant 'bug' vehicle. There is a pile of junk in the bottom left of the screen - PULL the metal bar from it. LOOK closely at the flashing light area, there is a terminal in this area. USE your old bent metal bar on the terminal to open it. Head east, back to your car, and JUMP into the car. USE the navigation console and go to Siruf 2, but don't land. From here, go to Daarlov-Korv and select the north-east quadrant.

When you land, head east 2 screens until you reach the shrine. COMBINE your 2 pieces of starchart, then COMBINE your starchart with the straight metal rod. INSERT your startchart & spindle into the recess in the shrine. You will be transported to Haldebar.



PLANET HALDEBAR
Head east, and you will see the power gem, surrounded by 6 energy beams. PICK UP the rock on the right of the screen. LOOK at the plaque on the left of the screen. This is a very tricky puzzle. The plaque shows 6 light-coloured squared that you have to step on, but it is hard working out exactly what squares it means. If you LOOK at stones on the ground (try to match it with what you see on the plaque), 6 of them will 'look slightly different'. When you step on a correct square, right-click on it and one of the energy beams will disappear. It is hard getting all 6 beams turned off at the same time, but it is possible. SAVE YOUR GAME HERE.

When all the energy beams are off, THROW the rock at the powergem. Quickly PICK UP the powergem, then run back to the vortex. JUMP over the bridge, and go back through the vortex.




BACK ON ANKARLON 5
You find yourself back at the shrine. Head west 2 screens, back to your car. JUMP into your car. USE the navigation console and head back to Siruf 2 (but don't land). From here, return to Ankerlon 5, and select the north-west quadrant.

Once you have landed, head west past the giant 'bug' vehicle. Rember that terminal near the flashing light - USE the powergem on the terminal. USE your arm-computer on the terminal, then click on "Level 3". Walk into the white beam of light that appears, and you will be transported inside the ship. TALK to the alien and ask how you can help. He will give you a cloaking device, then send you back to the planet surface. COMBINE the powergem and the cloaking drvice.

Head east back to your car, and JUMP into your car. Head for the Mekanthelor Galaxy cluster. When you are in the prison ship, talk to the Man-Brute guard. SAVE YOUR GAME HERE.


MEKANTHELOR GALAXY CLUSTER
LOOK at the wall near you. You will see a small, pale blue switch. Wait for the incoming message, then USE this switch TALK to the smugglers and agree to give them your car.

Head into town, and TALK to the waiting man (in purple). Tell him you are looking for Doshiv.

Go west back to the main square. Head south and talk to the sentinal guard robots. Tell them you won't try and pass. Head south to the main square There is a tall (ridiculas) robot pacing back and forth here. TALK to the robot. Tell him he looks very decorative, then tell him the Sentinal robots have a message for him. When he returns, mention the secret password. The robot will be destroyed.

Head south to the sentinal robot guards, and PICK UP the batteries from the ground. COMBINE the powergem and the batteries. USE your arm-computer with the powergem. Walk past the sentinal robots and exit the screen north-west. You will now get Kaleev's ID chip.

USE your arm-computer with the powergem again and head east past the sentinal robot guards, then south to the main square. Head west where the 4 robots are guarding the wall. SAVE YOUR GAME HERE.


THE DROID GUARDS
TALK to the sentinal robot nearest the bottom of the screen. Ask it to blast a hole in the wall, then command it to. You must be quick here to get rid of the droids.

Run east, then up, then east again. LOOK at the door panel in the wall. USE the door panel. Hide in the alcove, and watch the droid go through the door. USE the door panel again to trap the droid.

Now run east, then up. As soon as you see the droid, USE your bent metal bar on the rock.

Finally run east, then south, then east, then up, and then east. LOOK at the giant lizard, then THROW the ID chip at the lizard's head. Now JUMP on the lizard's tail, and wait for the droid to appear.

PICK UP the battery compartment left by the droid, and COMBINE it with the powergem. USE the arm-computer with the powergem to activate the cloaking device. LOOK at the pipe that the lizard is sitting on. JUMP onto the pipe, and exit the top of the screen.

Run west, past the robot shooting at you. Now LOOK at the robot captain (he has his back to you), then INSERT the bent metal bar into the robot captain. Head north-west, past the robot guards, and into the Citadel. TALK to the Man-Brute, and he will give you his Armour Glove.

Head west into the royal square. A giant robot (Neiamises) will appear, then Baron Kaleev will appear. TALK to Kaleev, then tell Neiamises that the gem will be his downfall. Kaleev is now banashed forever. Keep talking to Neiamises. Refuse to surrender to him, then throw the powergem at him.



Congratulations! You have now defeated evil, and brought peace to the universe.