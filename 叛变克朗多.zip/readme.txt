        BETRAYAL AT KRONDOR HINTS

     This file contains a list of hints for this Sierra/Dynamix game. I hope
that it helps you. If you are stuck on any other Sierra game we can send 
you complete walk-throughs for 30 Sierra games(See list below). If you
would like the hints just send a $15 check or money order to 2806 Silent
Spring Creek Drive, Katy, Texas, 77450. If you are writing out a check,
make it out to Houston Deeboockum. You will be enrolled in out gamers club
(CGE-Computer Gaming Experts) and will be sent new hints and info and games
when they become avaible. The $15 charge covers the cost of the disk
containing the 30 walk-throughs, enrollment in our club, and shipping &
handling. Here is a list of the game walk-throughs you would 
recieve...King's Quests 1-5 (6 is avaible online), The Colonel's Bequest,
The Dagger of Amon Ra, The Larry series (4 games), Police Quest 1-3, Quest
for Glory 1-3, Space Quest 1-5, Goblins I and II, Freddy Pharkas, Rise of
the Dragon, Willy Beamish, The Prophecy, Inca, and Betrayal at Krondor. If
you do not want walk-throughs of certain games, please specify another that
you would rather have.


Chapter 1

Locklear and Owyn escort a Moredhel prisoner named Gorath, to Krondor. 
The strategic and political importance of this trip South will become clear 
soon enough as you adventure.

Krondor

Krondor is the Southernmost city in the Kingdom of Midkemia. If you are 
having trouble finding it, refer to the color map included in your box. You 
will find it along the coast of the Bitter Sea, just East of Sorcerer's 
le.

Moredhel Word Locks

Spin the tumblers on the chest until they spell the correct answer to the 
riddle! 

Magical Trap South of Zun.

South of Zun you will encounter a magical trap with four crystals that 
rise out of the ground. You may click on your RETREAT button, (it could take 
several tries), and bypass this trap, taking another route to Krondor; or 
you could attempt to "solve" the puzzle. In this case, walking between like 
colored crystals will trigger a magical lightning bolt that could kill a 
member of your party. Try walking around the deadly pairs. Tap the "G" key 
on your keyboard if you need extra help.

Krondor

When you get close to Krondor, you will be prompted as to whether you 
want to continue following the road that leads toward the castle. Answer 
"YES" then wait until the picture of the castle appears. Move your cursor 
over this picture and you will see it change to words like "SHOP", "INN" and 
"PALACE." If you left click when the cursor says "palace" you will learn 
that the gates have been jammed. Move your cursor down to the cliff face 
beneath the gates and you will find an alternate entrance into the castle.

Sewers

You will not be able to get into the palace from the sewers until you 
have found a character named James. He has been cornered by a group of 
Nighthawks (wearing black) in the NW corner of the sewer network. You must 
kill them, then head down the side passage that branches off to the North.

The Palace Grate

James will give you a key to unlock one of the grates leading up into the 
palace. (The key will show up with your other keys automatically.) You'll 
find the grate in a room East of where you found James. When you see a 
ladder, click on it with your left mouse button. From the "lock screen" drag 
James' key to the lock and release your button.
If you've found the correct ladder, the lock will open and you will have 
successfully completed the first chapter!

Chapter 2

James and Gorath meet Owyn in the sewers under Krondor and together they 
head to the town of Romney to rendezvous with a detachment of King Lyam's 
troops at the Black Sheep Tavern.

Sewers

The sewer exit is South. You will exit the sewers through the same 
entrance that you used in chapter one.

The Nighthawks

Nighthawks dress all in black and you'll encounter a powerful group of 
them near the temple of Ruthia. If you are having trouble killing them, try 
hugging the mountain range South of the road and you should be able to slip 
past them without being detected.

Romney

Due to the Guild war in and around Romney, Mitchell Waylander will refuse 
to allow you into town without a Glazer's Guild seal. If you haven't been to 
Silden yet, you will find an important clue regarding the Guild seals in a 
chest outside the city.

A Glazer's guild seal

Search for a farmhouse just West of the town of Lyton. (You may run into 
Max Feeber, the farmer who lives there.) Search the barn and inside you will 
find four Glazer's Guild seals!

The Plague

The fever mad townsfolk who attack you outside Silden will give you the 
plague. For a cure, continue into town and left click on the ship on the 
right side of the screen---it will take you to the Temple of Eortis on 
Temple Isle. Inside the temple, left click on the curtains that lead into 
the cloisters and then choose the TALK option from the menu. The priestess 
will cure you of the plague as you leave.

Chapter 3

James, Owyn and Gorath must discover who was responsible for killing the 
King's soldiers at the Black Sheep Tavern. They must solve the mystery of 
the spyglass and the spider, then find enough evidence to convince Arutha 
that Nighthawks are operating in the area. You should start by talking to 
the people in and around Romney.

The killer of the King's men

You will uncover many clues by talking to the people in and around 
Romney, but you will learn the most valuable information by heading North 
toward the town of Kenting Rush. Check out the Temple of Kahooli North of 
town and talk to the Priest.

Priests at the temple of Kahooli

You won't learn anything at the temple of Kahooli until you have proven 
you are pious in the eyes of their god. To do this you must drop ALL your 
food in a bag, then use the ENCAMP option until all your characters are 
"starving." Only then should you enter the temple and talk to the priest.

Navon Du Sandau

The priests at the temple of Kahooli will implicate Navon Du Sandau as 
the leader of the Nighthawks and the man responsible for slaying the King's 
soldiers. You will find him on the road, in or around the town of Kenting 
Rush.

Nighthawk Headquarter's

Having killed Navon Du Sandau you must now find evidence of Nighthawk 
involvement in a Moredhel attack on the Kingdom...to take back to Prince 
Arutha in Krondor. You may find what you seek behind the waterfall, which is 
just North of the Temple of Banath, between Cavall Keep and Prank's Stone. 
It will be down a dirt road that branches West off the main road.

The locked door at the Nighthawks quarters

To enter the caverns behind the waterfall, move your cursor around near 
the base of the falls until it changes to the word ENTER, then press your 
left mouse button. You will need a "Knight's Piece" to get past the door.

Knight's piece

Head back to Kenting Rush and attempt to use the well on the South side 
of town.

The Virtue Wall

The lock on the well in Kenting Rush can only be opened with a "virtue 
key." You will find such a key in the shop in Kenting Rush. There is also a 
key located in a grave North of Prank's Stone, next to the river.

Evidence against the Nighthawks

Once you've entered the caverns behind the waterfall, head NE. You will 
need Navon Du Sandau's cellar key to get into his room. Once inside, you 
will find a Moredhel wordlock chest, which contains the evidence you need to 
end the chapter! The answer to the riddle is: "Darkness."

Chapter 4

Owyn and Gorath must escape from the dungeons at Sar-Sargoth and then 
fight their way South to The Teeth of the World...and freedom!

The Dungeons at Sar-Sargoth

The door South of your starting location when the chapter begins, is the 
only way to get to the upper level of the mine. To open that door you will 
need to find an interdictor key. You may find an interdictor key by going 
through the East door. You will need a Guildis Thorn key to open the East 
door. Once through the South door, simply head south, then west. The upper 
level is much smaller then then other levels. The exit is NE of the 
airway.

Nalar's Rib

Nalar's Rib is an extremely powerful, yet non-essential item that you may 
want to spend some time looking for. It can be tricky to find. First, you 
must collect the emerald and the note from the skull at Sar-Sargoth. Then, 
when you leave the city, head south -- off the main road -- until you hit a 
mountain and a graveyard. Go around the West side of the mountain and 
continue heading south until you trigger a magical trap with three Ogre 
magicians in it. Once this is dealt with, head SW and look for a large stone 
slab among a group of trees.

Northlands

The easiest and most painless way to get out of the Northlands is to find 
Irmelyn in the Giant's Broth Tavern in Armangar. He will ask you to rescue a 
character named Obkhar from the naphtha mines nearby.

Obkhar and the Naphtha mines

The naphtha mines are located NE of Armangar. Go around the North side of 
the mountains separating the river and the road, then follow the river 
South. You can squeeze between the river and the mountains and enter a 
secluded canyon. The entrance to the naphtha mines is across the bridge. 
Obkhar is located NE of the cave entrance. 

Cullich

Cullich can be found in a house South of Caern and West of the crossroads 
that lead to Raglam and Wyke. Use your brass spyglass, or have Owyn cast an 
Eyes of Ishap spell if you are still having trouble.

Moreaulf

Moreaulf is located in the town of Harlech in one of the Northern 
dwellings.
You will need to cast the spell "And the Light Shall Lie" in order to 
speak with him. (Only Cullich can teach you this short duration spell. HINT: 
It can be cast several times in succession to increase the duration.) 
Moreaulf will only give you the password for the guards on the bridge if you 
have talked to them first.

The bridge to northlands

Before you talk to Moreaulf (using the spell "And the Light Shall Lie, of 
course) you should attempt to cross the bridge by heading south past 
Armangar. This way you will be able to ask him about a "password." Once you 
have received the password from Moreaulf, simply head back to the bridge and 
you will be allowed across.

Chapter 5

James, Locklear and Patrus help Duke Martin and Baron Gabot prepare a 
defense for the impending Moredhel attack on Northwarden. The first place 
you should go is back to Northwarden to talk with Baron Gabot. Then head 
south and look for Duke Martin, he won't be too far from the castle.

The three chests

The three chests Duke Martin tells you to find aren't far away. Head NW 
and walk around the hills if you have to. When you find the chests the 
wordlock answers are: "onion", "outside" and "door." The only poison that 
will work on the rations is "coltari" poison, which can be purchased nearby. 
You must put the rations in your inventory, poison them, then return them to 
each chest.

Tamney the Minstrel

Tamney the Minstrel can be found in a barn near the town of Dencamp on 
the Teeth. To open the barn door, at least one member of the party must have 
a STRENGTH rating of 30 or more. If this is a problem, you can buy a 
strength booster called "Fadamor's Formula" at a shop nearby. The geomancy 
stones Tamney asks about are in a cavern East of Dencamp. There are two side 
roads that lead North to the cave entrance. Once inside you will find the 
stones in a chest to the North.

The Goblins

There are FAR too many goblins guarding the entrance from the Kingdom 
into the Northlands. You have no other choice but to pay them what they are 
asking. The quickest way to raise the money is by selling the diamonds you 
got from Tamney. It might be worth your while to search around for a shop 
that will give you the best price.

The war planes in Raglam

Captain Kroldech is occupying one of the houses in Raglam, and he has the 
plans. To get the plans away from him, talk to the engineer who lives in the 
house next to the tavern in Raglam.

The engineers

The engineer will only talk to the group if Patrus plays the lute POORLY. 
The trick here is to lower Patrus' barding skill. The easiest and safest way 
to do that is to get him drunk!
(After you fierd the catapult)
The engineer will tell you where to find the missing catapult part. 
Retrieve it from the box near the river (be careful, it is trapped), then 
head to the catapult and click on it with your left mouse button. Once the 
catapult has been activated, head back to Raglam and click on Kroldech's 
house. The plans are inside.

Moredhel spellcasters

After returning to Duke Martin with the Kroldech's plans, the Duke will 
give you one more task. This one will involve finding six invisible Moredhel 
spellcasters and eliminating them. (They are SE of Dencamp on the Teeth, 
near a house and well, which are both South of the main road.)
(Killing them....)
THIS IS AN EXTREMELY DIFFICULT COMBAT SCENARIO and it may be necessary to 
try it many times before you succeed. Here are some tips: Use restoratives 
before the combat to boost your characters up to full HEALTH, and use them 
during combat if possible. Move your fighters into their ranks -- they can't 
use their magic if you are standing right next to them. Also, make sure your 
armor and weapons are in peak condition, and if you have any potions or 
weapon or armor enhancers -- use them!

Chapter 6

Owyn and Gorath must find Pug and Gamina. Their only clue is a cryptic 
message burned onto the wall in Pug's room at Krondor: The Book of Macros. 
When the chapter begins, search the sewers carefully.

Sewers under Krondor

You will encounter a character named Katt in the SE corner, almost where 
the hallway dead ends. (Try heading East from the four way intersection near 
the entrance.) She will ask you for the Idol of Lassur, which is located in 
the second level of the sewers. The chest it is located in, is trapped.

The Pantathian serpent priests

If you head East towards Malac's Cross, watch out for the Pantathian 
serpent priests surrounding the town. There are a lot of them and they are 
very difficult to kill. Stock up on restoratives and use them before and 
during the battle if possible. This would be a good place to use your armor 
and weapons enhancers, as well. You might pay a visit to Malac's 
Dragon while you are in the area. It is NW of Malac's Cross.

Abbot Graves

When Abbott Graves asks you to find Mitchell Waylander, head to Sloop. 
His house is located near the shop. He will give you a note to take back to 
the Abbott.

The key to Stellan's house

The key to Stellan's house is located on a dead body just outside 
Krondor. Stellan's house is located in Eggley. Once inside you will find a 
map that will lead you through a secret entrance into the libraries at 
rth.

Sarth

You will not be able to get into Sarth by the normal means. Find the key 
to Stellan's house and retrieve the map that will allow you to enter the 
library through the caverns underneath. You can enter the caverns by left 
clicking near the bottom of the Sarth background, when your cursor changes 
to the word "ENTER." Once you have found the stairs leading up to the 
library, search the shelves carefully until you find the information you are 
seeking.

Elvandar forest

There is only one way to get into Elvandar: through the mines of the Mac 
Mordain Cadall. You will find the mine entrance on the Western side of the 
road, South of LaMut.
Prince Calin will help you get through the Elvandar Forest. He is located 
in the NE corner in a secluded area. Do not cross the river if you hope to 
find him.

Tomas

Tomas can be reached by either passing through the Ancient Ruins, or by 
fighting your way to the NW corner of the forest. The Ancient Ruins are 
located on the Western side of the forest, North of a river intersection. 
When you reach the Easternmost mountains, head North to avoid the deadly 
Sleeping Glades. You will need a key of lineages which you can get from 
Prince Calin.

Chapter 7

James, Locklear and Patrus search the Dimwood forest for the Rift 
Machine. To start, head SE when the chapter begins, and cross the small 
bridge when you come to it. Head SE from the bridge until you encounter Duke 
Martin. If you continue to head SE you will also run into Obkhar. Both will 
give helpful information.

Passwprd for the bridge

The password for the bridge can be found in a Moredhel lock chest in the 
NE corner of the forest. The answer to the lock chest is "snowflake."
Once you've crossed the bridge you will have to find and talk to 
Moreaulf. Head East along the river until you run into him.

The chest

The chest is located in the SW corner of the forest in a box canyon. The 
answer to the wordlock puzzle is "victory."

Path to the magical item

You will need to find Squire Phillip. Look for him due North of the 
chest, but it will be necessary to go around several mountains and 
foothills. He is heavily guarded so be careful!

The Rift machine

The Rift Machine is located near the center of the forest on a peninsula 
surrounded by rivers and mountains. One of the mountains is just an 
illusion, conjured up by enemy magicians to hide the location of the 
machine. This mountain must be walked through.

The enemies around the Rift machine

Goblins are particularly susceptible to the Mind Melt spell. If you don't 
already possess this spell it might be a good idea to find it. The other 
option would be to take a chance on Rorics Seal. This magical item will 
automatically cast Mind Melt, but there is about a 30% chance it will 
backfire and affect the caster instead.

Chapter 8

Owyn and Gorath search for Pug and Gamina on a hostile, alien world. It 
would be a good idea to head north when the chapter begins. Find the 
marble-looking pillars and click on them. It would also be a good idea to 
stock up on food...you'll need it in chapter nine!

Using magic

To use magic in this strange world, Owyn will first have to find a 
crystal staff. You can find a crystal staff in one of the dwellings in the 
NE corner of the island, next to a mountain. There may be others as well. 
You will also need crystallized manna to "rub" on the staff. Raw manna can 
be found by left clicking on certain crystal growths out in the world.

Health crisis!

There is a dangerous area in the SW corner of the island. You may not 
pass through this area until you have found the pillars to the North and 
freed Pug.

The cup of Rlnn Skrr

The cup of Rlnn Skrr is located near the SE corner of the island. You 
will find it in a dwelling, heavily guarded by Panth-Tiandns.

Pug

You will find Pug in the NE area of the island, in a dwelling next to a 
main road. If you return the cup of Rlnn Skrr to the pillar of 
Dhatsavan, then click on the pillar again you will be teleported to Pug's 
location.

Gamina

Gamina is trapped in a crystal cage in an underground cavern. The 
entrance to the cavern is west of the three bridges, and on the north side 
of the river.

The wind elementals

The Wind Elementals you will encounter in the underground cavern can ONLY 
be killed with a spell called "Strength Drain" (This spell is located in the 
SW corner of the island.) Because the Wind Elementals regain strength and 
health every turn, you must deplete them completely in order to kill them. 
The easiest way to do this is to have both Pug and Owyn cast the spell on 
the same creature. If the first blast doesn't kill it, the second surely 
will.

Chapter 9

Owyn, Gorath and Pug must prevent Makala from reaching the Lifestone. 
This means they will have to find and kill the six spellweavers that the 
Tsurani Great One brought with him from Kelewan. It is important to retrieve 
a key called a "Ward of Ralen-Sheb" from the body of a goblin in the first 
room you encounter.

The oracle of Aal

The Oracle of Aal can be found by going through the North door of the 
first room you come to. The Oracle of Aal is located in the NE area of the 
caverns.

Getting to the second level

The second level entrance is on the NE side of the caverns. Head through 
the East door and avoid the deadends to reach the entrance.

The Six

It will be necessary to search nearly every room and passageway to find 
The Six. You will discover they are all heavily guarded.

The final combat

The cup of Rlln Skrr may be used over and over again in Chapter Nine to 
learn spells. Pug will eventually learn every spell in the game, but this 
will take time and use up a lot of rations.