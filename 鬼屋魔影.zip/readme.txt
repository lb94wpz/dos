ALONE IN THE DARK -- FULL GAME

This file was downloaded from Cascade Abandonware:
http://home.c2i.net/olant/