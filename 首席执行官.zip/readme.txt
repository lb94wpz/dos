		       LAST MINUTE RECOMMENDATIONS
			-------------------------




1. ERROR MESSAGES
-----------------

If for any reason the game crashes or returns to DOS, check that you have :
	- At least 580 KB (=593920 bytes)of conventional memory,
	- At least 4 MB of RAM available,
	- At least 2.7 MB of free EMS memory.
	- A VESA compatible video card (standard video) and the appropriate 
VESA driver.
	- A Microsoft compatible mouse.
	- DOS version higher than 5.00.

If you are using QEMM, you may encounter compatibility problems with your 
video card. To solve the problem, the QEMM stealth option must be removed. If 
this option is active, you will notice in the 'CONFIG.SYS' file, a command 
line containing "ST:M", "ST:F",... In this case you can either delete the 
string "ST:M" or use the OPTIMIZE command without the stealth option.
It is also also possible, for the same reasons as in the introduction, the 
screen remains black : you can remedy this problem the same way.



2. HARDWARE PROBLEMS
--------------------

	- On computers with a slow access hard disk, the game may freeze or
the introduction sequence may loop.
In this case you must use a cache disk (such as smartdrv.exe from Microsoft) 
to be able to hear all sounds and music; otherwise use the option /C. 
(Type A4 /C at the DOS prompt, this will disable the audio ressources 
integrated in the game).

	- However,  some 'fully Sound Blaster compatible' cards are not
compatible enough to run the game properly. In that case A4 /C is the only 
solution left to enjoy the game.



3. INCREASE MEMORY
------------------

	You're able to play to play with less than 580 Ko of conventional 
memory. To do so : launch _ /C at the call of DOS. (in the directory 
INFOGRAM\NETWORKS or in the directory you have put the game)  



4. ADDITIONAL ADVICE
--------------------

	- We recommend you (especially for those who have a slow access hard
disk) to use a cache disk. You can type SMARTDRV 4096 4096 (provided that you 
have enough EMS memory!)

	- Before using the On-line competition, make sure you have played
long enough to be ranked.
	


5. LAST MINUTE CHANGES WHICH ARE NOT INTEGRATED TO THE MANUAL
-------------------------------------------------------------

	- Sub Menu SCHEDULE : You will not be able to enter this sub-menu
unless you have bought a train or a bus.

	- The former menu BALANCE SHEET is now called REPORT.

	- It is impossible to build ski resorts on the following maps :
		   - COME
		   - CLEVELAND
		   - CAYMAN ISLANDS
since as in real life there are no ski resorts in these areas.
However, you will be able to experiment with that option in Vancouver and 
GOTEBORG.

	- The largest amount of money you can borrow from the Bank is 70 % of
your assets, including possible previous loans already contracted

	- If your total amout of cash is higher than �10 billions, it is 
impossible for you to raise a loan.

	- The ultimate on line icon pops up a new menu with two codes

		1) Your personal ID code, to be used each time you want to 
send us your score.
		2) Your current score, which will be displayed on screen once
your ID code has been delivered onto our system.

	- During the installation, under DOS or WINDOWS, there's no option 
icon.

	- Following the previous point, it's impossible to do an upgrade in 
order to change the parameters, once the game is installed.


			   VERY BEST OF LUCK TO YOU ALL

