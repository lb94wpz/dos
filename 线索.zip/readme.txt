
                - FULL DOCS For THE CLUE ENGLiSH VERSiON -
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Doc typed by MINDWALKER
����������������������?


I. Loading Instructions and Installation
----------------------------------------



   Hardware Requirements
   ---------------------

The Clue is available for the Amiga 500, 500+, 600, 
A1200/A4000, CD32, IBM PC compatibles and the IBM PC CD-ROM.

AMIGA 500, 500+, 600:
The game will work on all of the above Amiga computers with 
1 Megabyte of memory minimum. External drives are detected 
and utilised by the game.

AMIGA 1200/A4000:
A special version has been written so that it uses the 
advanced chip set. Additional RAM expansions are not 
required and external drives are utilised.

CD32:
The game uses the CD32 full colour palette, a complete 
speech system has been installed, offering speech in CD 
quality.

IBM PC compatibles:
Suitable for all IBM compatible computers from the 386 
onwards, which have a capacity of at least 2 Megabytes of 
memory as well as a VGA compatible screen.

IBM PC CD-ROM:
Like the version for the CD32, this version offers 
additional graphics, as well as a full speech in CD quality.


               Loading instructions and installation
               -------------------------------------

AMIGA:
Following the instructions appearing on the screen, insert 
disk 1 into the internal drive. The game is loaded 
automatically. If it is necessary to change disks, you will 
be instructed to do so. All drives connected are supported 
automatically.

AMIGA hard disk:
If your computer is equipped with a hard disk, the game can 
be installed on it by using the programme `Installation' (on 
disk 1) from Workbench.

PC:
The game has to be installed on your hard disk by using the 
install programme on disk 1. Type either `a:' or `b:', 
according to which one is your 3.5 inch drive. Finally, 
start the installation by entering the command `Install'.

                 Preparing a Save Game Disk
                 --------------------------

This necessity only arises for users playing on the AMIGA 
and using disks. If the game is installed on a hard disk, 
the savegames will automatically be saved on it. Otherwise, 
a Save Game Disk is indespensible to be able to save a game! 
Therefore, please prepare a Sve Game Disk before starting 
the game. In principle, any disk is suitable for this task. 
However, please note that its original contents will be 
deleted. Therfore, never use a disk with important contents 
or one of your `The Clue' disks as a Save Game Disk.

Load the Workbench and insert disk 1 into any drive.

Upon activating the symbol `The Clou Disk1' twice, another 
window containing the symbol `CreateSaveDisk' will open.

Start the process by activating this symbol twice with your 
left mouse button.

   Illegal copies
   --------------

Please note that this product has been prepared with great 
care. The producers have invested a great deal of money, 
time and effort. To be able to keep supplying the software 
market with high-quality games we ask all users not to pass 
on illegal copies of this game to anyone. It is important 
that enough users decide to acquire games in the legal way - 
by buying them. Otherwise, the development of new game 
software may not be possible.

   Basic Instructions
   ------------------

Following commands apply to all versions and throughout the 
game:

Press the left mouse button, the <Return> key or the Fire 
button to select an option in the menu. By pressing the 
right mouse button or the Escape key <Esc>, the proceeding 
action can be cancelled anytime.

Pressing the Function Keys (F1 to F10) will lead you to the 
Main Menu, where a current score can be saved or loaded. 
However, saving a score is only possible with a Save Game 
Disk. (See above for preparing a Save Game Disk.)


II.Introduction
---------------


London, Victoria Station. February 3rd, 1953. In a cloud of 
steam, the 5 o'clock train from Dover arrives at the 
station. With a long, exhausted hiss, it stops. As the wagon 
doors open, crowds of people in drab clothes come pouring 
out of the train's metal body. One of them is Matt 
Stuvysunt, a young man who is destined to steal England's 
most carefully protected treasure: The legendary Crown 
Jewels.

Put yourself into Matt Stuvysunt's position and venture a 
journey into the world of secret agents and criminals, 
policemen and dealers. It is a gloomy world full of tension, 
danger and suspicion, where the terrors of the Second World 
War have not yet been forgotten. But it is also a world 
where mere accomplices may turn into real friends, and where 
a young man may meet the woman who will change his whole 
life.

Face the challenge of planning the perfect burglary. 
Organise every detail from the necessary tools to the escape 
car. Roam the bars and pubs of London to find the best 
accomplices for your coup, and win them for your plan.


III.Excerpts from Matt Stuvysunt's Diary
----------------------------------------


01-12-1937
Dear Diary, I've only just recieved you as a present. What a 
gorgeous day! When I woke up in the morning, there was one 
single thought in my mind:Today is my name day - finally!
I got up and put on the wildest pair of denims I could find 
in my cupboard - after all, a boy of my age should really 
begin to care about his reputation. My parents were already 
waiting for me in the parlour. They gave me my presents:A 
young shepherd's dog I called Albian, and you, my dear 
diary. I promise that I will tell you about every important 
incident in my future life - but not now, for Mummy is 
calling me...
   Yours, Matt

01-12-1937
Here I am again, back from my name day party. It was 
absolutely brilliant. I feel like the happiest boy in the 
world...In fact, every name day should be as wonderful as 
this one. It's time to go for a walk with Albian now. See 
you tomorrow.
   Yours, Matt

03-09-1938
I played hide and seek with Tom today. When I was hiding in 
the attic, I came across some old newspaper cuttings. They 
were about my dad! It seems that 20 years ago he was a 
famous burglar - until the police caught him and put him 
jail for 3 years! I still can't believe it - my dear daddy, 
a burglar! But the name in the newspaper articles is right: 
Dean Stuvysunt. Just imagine that, my dear diary...

03-05-1944
Oh dear, I got myself absolutely stoned yesterday...I went 
to `The Old World' with Tom. We must have drunk about half 
the beer and spirits the pub had in stock, and they finally 
had to throw us out - otherwise there would have been no 
alcohol left for the other visitors...I also smoked my first 
cigarette. It wasn't all that bad.

04-02-1945
I am in love with Mandy. It's such a shame that I do not 
have enough courage to talk to her. Every time I see her my 
heart starts beating like mad and I cannot think of anything 
to say...

27-03-1951
Tom is getting married! Gosh! I'm looking forward to his 
wedding. I still remember how he first met Julia at school - 
and now she is becoming his wife! This is crazy...

01-12-1952
I went for a drink with Dad today. In fact we ended up 
having more than just one drink. Dad also told me a few 
stories from his past. One of his old friends is now living 
in London - his name is Herbert Briggs. he used to pull a 
few jobs with Dad. Briggs was never caught by the police, 
and Dad did not even give him away when he was put in jail. 
Well, that's just like my Dad...

24-12-1952
I have made up my mind. Sooner or later I will leave this 
place and go to a bigger city. London wouldn't be bad...

30-12-1952
Today I told Tom and my mother about my plans to go to 
London. Mum was rather sad about my decisiion, but after all 
London is not as far away as Japan or Australia. And anyway, 
we don't see each other very often these days.

18-01-1953
I went to see Tom, and we went for a drink to our habitual 
haunt, `The Old World'. �t is hard for me to give up all 
this - this pub, this town, Tom, Dad...Mum...But i`ve made 
up my mind to go to London, and i'm leaving tomorrow.


IV.Operating Instructions
-------------------------

1.Screen arrangement and control functions
------------------------------------------

1.1.Screen  arrangement
-----------------------

|------------------------------|
|                              |   - (1)
|                              |
|                              |
|                              |   - (2)
|                              |
|______________________________|   - (3)
The screen consists of three areas:
The balloon area (1)
The scenery area (2)
The menu area (3)

The balloon area:

In this part of the screen, the current time is indicated, 
as well as texts such as conversations, Matt's thoughts, or 
notes with information (for example about cars or tools). 
during a conversation, Matt's options are shown in the 
balloon area.

The scenery area:

This area usually shows the player's current surroundings. 
Only during this planning stage and the course of a burglary 
a ground plan of the current target building is shown.

The menu area:

This part of the screen contains a list of the player's 
current options. More detailed information about the options 
indicated here will be given in chapters 2, 3 and 4 of this 
handbook. Moreover the current place and date is indicated 
at the top of the menu area.


1.2 Operating instructions when using a Mouse
---------------------------------------------

To select an action, move the Mouse cursor to the 
corresponding word in the menu or balloon area. The word is 
immediately marked by  a change of colour. To start the 
action, press your left Mouse button. Most actions indicated 
in the balloon area can be cancelled at any time by simply 
pressing the right Mouse button. However, some  options - 
such as saving and loading - can only be carried out using 
the keyboard. (For details see below in chapter 1.4.)


1.3 Operating instructions when using a Joystick
------------------------------------------------

With the joystick lever you can easily move between the 
words in the menu or balloon area. The current word is 
marked by a change of colour. The corresponding action is 
selected and started by pressing the `Fire'-button. However, 
some options - such as saving or loading - can only be 
carried out using the keyboard.


1.4 Operating instructions when using the keyboard
--------------------------------------------------

By pressing the cursor keys you can select an option 
indicated in the menu or balloon area. The word of your 
choice is marked by a change of colour on the screen. To 
start the correspondig action, press either the <Return> or 
the <Space> key. Most actions indicated in the balloon area 
can be cancelled by pressing the <Escape> key. The score 
display menu can be loaded by pressing any function key 
(<F1> to <F10>). (See below, 1.5.)


1.5 The Score Display Menu
--------------------------

This menu offers you the options to `Quit' or `Continue' the 
game, as well as the commands to `Save' or `Load' a score. 
The score display menu can be loaded by pressing any 
function key (<F1 to F10>). Saving is only possible when the 
player is IN FRONT OF any building in town. When loading, 
the player can chose among the scores that have been saved 
so far; however, only four different scores can be saved. 
When saving a fifth score, one of the previous scores is 
deleted from the score display menu, and the name of the new 
score is indicated instead. This name consists of Matt 
Stuvysunt's whereabouts at the time of saving and the 
current date in the game. For example, if the score is saved 
in Holland Street, Feb.3rd 1953, its name in the score 
display menu will be `Holland, 3. 2. 1953(1)'. The last 
figure (in brackets) indicates the current number of this 
score.


2. In Town - Preparing for a Burglary
-------------------------------------

Once you are in London, you can make preparations for 
different burglaries. Though you will always start planning 
a crime in your hotel room, your dangerous task will lead 
you to various other places as you go along.

During the preparatory stage, the following data will always 
be indicated on your screen:

|-------------------------------------|
|                                     |
|                                     |  - (1)
|                                     |
|                                     |
|                                     |  - (2)
|                                     |
|                                     |
|                                     |  - (3/4)
|_____________________________________|

the current time (1)
your current whereabouts (2)
the current date (3) and the name of the current whereabouts 
(4)

To take action, you only need to select one of the 
activities indicated in the menu area. Further information 
on the activity options will be given in the following 
chapters.


2.1 Walking
___________

This is the option you need to select if you wish to move 
around in England. Usually a new menu will appear on the 
screen, offering the destinations you can choose from. All 
you need to do is select the place where you want to go and 
you will be there immediately. However, the realistic 
duration of your journey is registered in the game, as you 
will see on the `Current Time' display. If there is only one 
way to leave a place, you cannot choose from a menu. In this 
case, you will automatically be taken to the only possible 
destination. For longer journeys, you need to take a taxi. 
You will find one on every street, and board it by choosing 
the corresponding option. Of course you can also call a 
taxi. Further information on how to do this and on the 
possible activities inide the taxi is given below.

2.2 Talking
-----------

This option is only given if someone you can talk to is 
close by. The conversation will differ according to the 
person, place and situation. When talking to someone at 
their place of work, the conversation will be solely 
professional, whereas it may become more private when you 
are talking to the same person in the street or in a pub. 
Private conversations are of great advantage, for they are 
the best way to gather information about the person you are 
talking to, and thuscan help you find the most useful 
accomplices for a coup.

`I've got a job for you there...'

By uttering this sentence, you can ask your current 
conversation partner to take part in one of your coups. A 
sentence like `There are 2/3/4 of us.' will give you further 
information about how expensive this person could be to you. 
The value of such an offer depends on many factors, such as 
the possible accomplices' characters, their physical and 
mental abilities and the like. Next you have to decide 
whether you are interested in working together with this 
person. If you indicate your interest (`I will call you as 
soon as...')you can use this accomplice in your plans from 
now on. However, it is advisable to be very careful! In the 
past, some excellent plans have been known to fail because 
to many people knew about them. Every additional accomplice 
also means taking an additional risk! Therefore, you have 
the possibility of `Thinking' about a person after you have 
offered them a job. `Thinking' (see below for further 
information) will help you to appreciate a persons 
advantages and disadvantages. After a successful burglary, 
the accomplices will go different ways again. To offer them 
another job, you have to contact them again - however, do 
not be suprised if the same person shows a different 
reaction than the first time.

`What's your job?'
Upon asking this question, you will be told your current 
conversation partner's actual profession.

`Have you ever had trouble with the police?'
Choosing an accomplice who is already known to the police 
means taking a great risk, for the police might easily 
suspect and arrest him during their investigations.

`Any experience?'
Ask this question to learn something about the person's 
experiences in the past.

`See you.'
This sentence will end the conversation.


2.3 Looking round (outside a building)
--------------------------------------

It is always advisable to take the time and look at what is 
going on around you. Sometimes you may find interesting 
detailsthat can help you on your way. You can either 
concentrate on the people around you, or on your general 
surroundings. The options appear in a balloon representing 
your thoughts. If you select `person', you also have to 
decide upon which single person you intend to watch. If you 
do not yet know the person of your choice, there will only 
be a short text about your first impression. (In this case, 
it is advisable to chose `Talking'.) After you have offered 
the person a job, you will be given a more detailed 
description.


2.4 Looking around (inside a building)
--------------------------------------

If you chose `Looking round' while you are inside a 
building, you will be given information concerning the 
objects around you, especially possible loot. It is 
important to watch a building before actually entering it, 
because this will increase your knowledge about the 
building's possible dangers and the best ways to break into 
it. The more time you dedicate to watching a building, the 
more information you will put down in your notebook. Once 
you have entered the target building, it is crucial to 
memorise every detail of your surroundings. Pay special 
attention to alarm systems and the electricity supply of 
objects you might need to damage or steal. When you have 
spent enough time looking round, one of the objects around 
you will be indicated by a flashing signal on the screen. 
This object is now `activated' - this means that you can 
gather further information by taking a close look at it. 
(See below, `Taking a close look'.)

`Next object'

This command will activate the next object to be looked at, 
providing that you have found out enough about the one you 
have been looking at.

`Last object'

This command will activate the previous object you have 
looked at.

`Taking a close look'

With this command you can gather more detailed information 
about the object that is currently activated. You will be 
told whether the object is connected to an alarm system or a 
switch box, and you can find out about possible contents. If 
the object happens to be a switch box, you will even be 
shown a plan of its connections with the objects it is 
controlling. This plan will stay on the screen until you 
chose to `Take a close look' at another switch box. In case 
the object activated happens to be an alarm system, you will 
be shown the connections with all objects that are protected 
by it. These connections will also remain visible until you 
`Take a close look' at another alarm system.

`Guard'

If any guards or watchmen are present in the building, you 
are informed about their usual control routes.

`Ready!'

This statement will end the process of `Looking round'.


2.5 Thinking
------------

This option gives you the possibility to concentrate on 
general problems as well as on specific matters, such as 
your car, possible accomplices, tools, buildings and loot.

`Thinking about general matters'

You will be given information about Matt Stuvysunt's mood, 
his - and your past and present situation. This includes 
assessments of the following aspects:

	Identity (name, age, sex, profession)

	Health
	A burglar should be in good physical shape, in order 
	to be prepared for the strenuous work of the burglary 
	and, of course, the escape afterwards.

	Mood
	The burglars' mood during a coup partly depends on the 
	accomplices' characters. It is important that all 
	accomplices are feeling well and secure during a 
	burglary, so that they can concentrate on working 
	quickly and avoiding mistakes.

	Intelligence
	Intelligence is needed for certain tasks during a 
	burglary (such as cracking safes), but also before and 
	afterwards (for example if the person has to hide from 
	the police).

	Physical strength
	A person's strength is important for their chances 
	during a fight, but also for carrying the loot.

	Stamina
	An accomplice with bad stamina will sometimes have to 
	rest for a short time during a burglary. Think of this 
	when you chose your accomplices! However, stamina is 
	even more crucial in other respects: Someone who is 
	exhausted and whose hands are moist with sweat will be 
	likely to act clumsily - and probably make a dangerous 
	mistake!

	Loyalty
	Your accomplices' loyalty is of great importance after 
	a burglary has gone wrong. If one member of your gang 
	is caught, you must be sure that he will notgive away 
	the names of the other accomplices.

	Dexterity
	Dexterity is important for any accomplice who has to 
	carry out manual work. Dextrous people have less 
	difficulty with acquiring new skills and may sometimes 
	have an advantage in a fight.

	Personal relationships
	Your accomplices should be professional enough to 
	forget about personal feelings during a burglary. 
	Nevertheless, if someone is caught by the police, 
	their personal relationship to the other accomplices 
	may keep them from giving away their names. Dealers, 
	as well, may make a better offer if they know the 
	person they are dealing with well enough.

	Reputation and fame
	This value shows how well-known a person is within the 
	criminal `scene' of London. When it comes to it, it 
	may well be more difficult for a famous criminal to go 
	into hiding.

	Greed
	A greedy accomplice is a bad partner to share the loot 
	with, and a greedy dealer is unlikely to make you an 
	acceptable offer.

	Nerves
	A nervous burglar is more likely to leave traces or 
	make other mistakes and therefore is a risk for his 
	accomplices. If someone is pursued or even questioned 
	by the police, the strength of his nerves may well be 
	fatal for the whole gang.

	Records existing
	Some of the possible accomplices are already 
	well-known to the local police. During their 
	investigations on a crime, the police will search 
	their files for possible culprits. Therefore, 
	accomplices with a police record existing under their 
	name are very likely to be suspected by the police, 
	even if the burglary has been successful in every 
	other way.

	Abilities
	This option will give you a list of a person's special 
	abilities. The most important of them are:


		Driving
		The ability to drive the escape car.

		Locks
		The ability to crack the locks on doors.

		Explosives
		The ability to deal with explosives.

		Electronics
		Someone with knowledge on the field of 
		electronics can turn alarm systems and switch 
		boxes on and off.

		Looking out
		Someone who has a sixth sense for danger can be 
		very useful as a look-out man during a burglary.

		Fighting
		The ability to overpower security guards.

`Thinking about your own cars'

Here you can think about the cars that you currently 
possess. You are given the following pieces of information:

	Name
	A car's `name' consists of its type, the year of 
	construction, its country of origin and age.

	Value
	This is the approximate monetary value of the car.

	Performance
	The motor's performance when new. This value can 
	decrease as the motor grows older; you can only 
	estimate the motor's current performance value.

	Speed
	This is the car's top speed when new. Just like the 
	performance, this value decreases with age.

	Registered for
	The number of persons that may legally be transported 
	in this car.

	General state
	The general state the car is in.

	Body
	The current state of the car's body. Furthermore, the 
	shape of the escape car's body, as well as its type 
	and colour, decides how conspicuous the car looks. Try 
	to chose an escape car that is not particularly 
	eye-catching.

	Tyres
	The current condition of the tyres.

	Motor
	The condition of the motor.

	Carrying capacity
	The amount of luggage, i.e. loot that can be 
	transported with this car. Do not forget that your 
	accomplices, too, need to fit into the escape car!

	Look
	Information about how conspicuous the car looks.

`Thinking about accomplices'

If you have already offered a job to a person and have also 
decided upon how to share the loot (`I'll call you as soon 
as...'), `Thinking' about this person will give you a 
complete description of them, containing all aspects listed 
under `Thinking about general matters'. When thinking about 
somebody you have not spoken with, yet, you will get less 
detailed information on the same aspects. If you have not 
yet come to an agreement with the person you are thinking 
about, there will only be a short description of their most 
prominent characteristics.

`Thinking about tools'

By choosing this option, you can take a short look at your 
notebook, where you have jotted down some information about 
your tools:

	Title
	The title/type of the tool.

	Value
	The tool's monetary value.

	Risk of injury
	This is the risk that even a competent person may be 
	injured when using this tool.

	Noise
	The amount of noise produced when using this tool.

	Necessitates
	Additional equipment needed for the tool.

	To be used for
	The tool's range of application, as well as the 
	approximate time needed when using it.

`Thinking about a building'

You cannot `Think about' a building unless you have already 
watched it, for this option shows you the notes you have put 
down while watching the target building of your choice.

Your notebook may contain the following pieces of 
information:

	Alarm margin
	If the police is alerted (by an alarm system, by a 
	neighbour or a passer-by who has noticed the 
	burglary), patrol cars will be sent to the site of 
	the crime. The alarm margin is the time taken by the 
	police car to reach the building.

	Valuables
	Possible pieces of loot in the house you have 
	chosen.

	Escape route
	Detailed information about the escape route should 
	help you to chose the right escape car for this 
	particular coup.

	Accuracy
	The accuracy of the information you have gathered on 
	this building. The more you know about a target 
	building, the easier it gets for you and your 
	accomplices to prepare for the burglary.

	Security measures
	This indicates the amount of security measures taken 
	to guard the building and its valuables from people 
	like you and your accomplices. There may be an alarm 
	system or even guards. The security of a building 
	also increases with the frequency of police patrols 
	or guards from private security services passing by 
	in the street or looking in through the window to 
	check whether everything is quiet.

	Radio communication
	If there are guards in a target building, they are 
	equipped with radios to stay in touch with each 
	other. Here, the intensity of the radio traffic is 
	indicated; the higher it is, the more likely it gets 
	for a radio message to be received.

	Training of guards
	The guards in the target building have been trained 
	in different ways. Therefore, some of them are more 
	dangerous and more difficult to be overpowered than 
	others.

	Maximum noise level
	This is the maximum amount of noise you may produce 
	during the burglary without alerting neighbours, 
	passer-byes or police patrols in the street.

`Thinking about the loot'

This will show you a list of all valuables you have stolen 
so far.


2.6 Watching
------------

Before you can start planning a burglary, you should gather 
as much information about the target building as possible. 
The more time you dedicate to watching the building, the 
more accurate informationyou can put down in your notebook. 
(See above, `Thinking about a target building'.) You can 
start the planning stage as soon as you have gathered AT 
LEAST 50% of the possible information about the target 
building. Watching the building and all activities around it 
carefully enough is necessary before you can enter it and 
will also help your accomplices to prepare for the burglary. 
However, if you watch a bulding for a very long time, you 
could start looking suspicious! Someone could remember your 
strange behaviour and thus help the police to investigate 
the crime...! When you are on your watch post, pay attention 
to the frequency of police patrols passing by, for it is 
likely that they will be patrolling the area at about the 
same time on the day of your coup. The police patrols put a 
limit to the time you can safely spend inside the building: 
There is a chance that the first, maybe even the second 
patrol that passes by the building you have broken into, 
will not notice what is going on, but from the 3rd patrol 
onwards, your chances decrease rapidly, and it is advisable 
to leave the site as fast as possible. After you have left 
your watch post, you will be shown a list of the facts you 
have jotted down in your notebook.


2.7 Calling a taxi
------------------

For longer journeys, it is necessary to take a taxi. You can 
either call a taxi or walk to the next free one that comes 
along (see above, `Walking'). Upon entering the taxi, you 
tell the driver which destination you want to be taken to.


2.8 Making a phone call
-----------------------

You wish to contact someone, but do not know their phone 
number? No problem! Simply call the telephone exchange, and 
you will be able to reach nearly every person you have got 
to know so far. If the number is engaged or nobody answers 
the phone, don't worry and try again later.


2.9 Waiting
-----------

This is the right option if you get bored waiting for 
someone or something that you wish to speed up the passing 
of time.


2.10 At the car dealer's
------------------------

Take the taxi to Wellington Road to get to the car dealer's 
- `New & Used Cars'. This is the right place to buy or sell 
a car, or to have your car repaired.

In the office

During the opeing hours you will usually find Mark Smith, 
the car dealer, in his office. You should take the 
opportunity to have a little conversation with him...

The car park

At the car park you can buy a new car - or sell one of your 
old ones, in case you already have any. To do this, Matt 
Stuvysunt can utter the following sentences:

	`Show me...'

	You will be shown a complete list of the cars that 
	are for sale at the moment. At the bootom of the 
	screen the price of each car will be indicated, as 
	well as you current savings. Upon selecting a car, 
	you will be shown its most important data. (See 
	above, `Thinking about cars.) After you have checked 
	the car's data, you have to decide whether you chose 
	to buy it or rather to look at some more cars for 
	sale.

	`I'd like to sell...'

	If you tell him that you want to sell one of your 
	cars, Mark Smith will make you an offer, which you 
	can either accept or refuse.

	`Good-bye.'

	Say this if you wish to end the conversation with 
	Mark Smith.

In the garage

In the garage you can have a car repaired or painted. In 
urgent cases, Mark Smith may even be willing to keep working 
all night - especially if you are regular customer of his 
garage. If you start the conversation by `Talking', you will 
first of all have to tell him which car you want to have 
brought into the garage.

	`What can you get out of this car?'

	If you want mark Smith to give the car a general 
	overhaul, he will tell you his price per working 
	hour. If this is too high for your budget, you can 
	refuse it; otherwise, say:

	`O.K., get on with it.'

	If you accept the car dealer's offer, he will start 
	reconditioning your car. While he is working, the 
	change of your car's condition, but also the cost of 
	Mark Smith's work and its influence on your budget 
	will be indicated in the balloon area. You can stop 
	this process at any time by pressing your left Mouse 
	button or the <Return> key.

	`Retread the tyres, please.'

	By choosing this option, you can improve the 
	condition of your tyres. This process will be very 
	similar to the general overhaul (see above).

	`Repair the motor.'

	If you want your car's motor to be repaired, the 
	following repair works will also be similar to the 
	general overhaul (see above).

	`I want the car varnished...'

	Sometimes you may chose to change the look of your 
	car. Mark Smith will make you an offer, which you 
	can either refuse or accept (`O.K., that's fine with 
	me.'). If you accept the offer, you can chose the 
	colour you want your car to be varnished.


2.11 At the tools shop
----------------------

The tools shop is in Watling Street. Here you will meet Mary 
Bolton, the shop owner's daughter. By talking with Mary, you 
can buy and sell tools, as well as get information about 
certain tools.

	`I'd like to buy...'

	You are shown a list of the tools that are for sale 
	at the moment. You current budget and the price of 
	the tools you are being shown is always indicated in 
	the menu area. To buy a tool, you only need to 
	select it. Please note that you will automatically 
	be given one tool of the kind for each of your 
	current accomplices. (For example, if there are 
	three, you do not need to go through the process of 
	buying gloves three times, but only once.)

	`I'd like to sell...'

	You are shown a list of the tools that are currently 
	in your possession. If you select a tool, Mary 
	Bolton will make you an offer. If you chose to 
	accept it, you sell the tool of your choice to her.

	`Show me...'

	With this option you can get detailed information 
	about a tool.  (See above, "Thinking about tools")

	`Tell me something about...'
	Mary Bolton will offer you a short assessment of the 
	tools qualities.

	`Good-bye'

	This option ends your conversation with Mary Bolton.


2.12 The dealer
---------------

After a sucessful burglary there should be a number of 
valuables in your possession.  You can sell the stolen goods 
to one of the dealers in London.  Even if your loot is in 
cash, you should bring it to a dealer to have it `washed'.
Most dealers specialise in certain goods - one of them will 
make you the best offer for statues, while another one will 
make you a better offer for jewels.  Sooner or later, 
however, you should decide upon one dealer; if you change to 
often, you will not be very popular with either of them, and 
this could influence thier offers in an unpleasant way... To 
start negotiating with a dealer, select `Talking'.  As an 
example,the conversation with Eric Pooly (- you will find 
him in Holland Street):

	`What kind of goods are you dealing with?'

	Upon asking this question you will be told what Eric 
	specialises in- i.e., for which valuables he is 
	prepared to pay a reasonable price.

	`Make an offer, please?'

	Eric will have to look at each of the stolen goods, 
	and if he finds anything that interests him, he will 
	make you an offer.  You can choose to either accept 
	or refuse the dealers offer.

	`Good-bye.'

	Say this to end the conversation with the dealer.


3. Organizing a Burglary
------------------------

Upon selecting the option `Planning' in your hotel room, you 
can start preparing a coup.  You need to make a lot of 
decisions concerning the target building, your accomplices, 
the escape car and its driver.

__________________________________
|                                |
|                                |  - (1) (4) (3)
|                                |  - (2) (5) (6) (7)
|                                |
|                                |
|                                |
|                                |
|                                |
|_______________________________|

The `Organisation' screen will show you the following:

The target building (1)
The escape car you have chosen (2)
The driver of the escape car (3)
The number of people there is space for in the car (4)
Details about the escape route (5)
and its length (6)
Your share of the loot (in per cent) (7)


3.1 The target building
-----------------------

After you haved watched the building, you can choose it to 
be the target of your next burglary.  Make sure you have 
gathered enough information about the building by watching 
it!  The more you know about it, the easier it becomes for 
you and your accomplices to prepare for the actual coup, and 
the more likely it is that you will suceed.


3.2 Accomplices
---------------

With this option you can choose the members of your team.  
The maximum number of accomplices is usually 3, But it may 
also be lower, depending on the carrying capacity of your 
car.  Note that selecting many accomplices does not only 
enable you to transport more loot, but also means that the 
loot has to be shared among many people - leaving a smaller 
share for each of you.

You have the following options:

	`Accept'

	With this option you can select somebody as a member 
	of your team for the next coup. You will be shown a 
	complete list of the people you have offered a job 
	so far and with whom you have come to an agreement 
	about sharing the loot.  In case you have not yet 
	met any people, it is advisable you visit one of the 
	bars or pubs.  For more information on how to offer 
	a job to a person, see above (2.1., `Talking').  
	Remember that you can also use the telephone in your 
	hotel room to contact someone.

	`Eliminate'

	If you have already accepted someone in your team 
	but have now changed your mind, the accomplice in 
	question can be eliminated from your team.

	`Ready!'

	This command finishes off the process of selecting 
	your accomplices.


3.3. The escape car
-------------------

Of the cars that are currently in your possession, choose 
the one that you believe to be most suitable to help you 
escape from the target building after the burglary.  Your 
decision should be influenced by the escape route and its 
length, but also by the number of accomplices you intend to 
take with you.


3.4. The driver of the escape car
---------------------------------

You also have to select a person who is destined to drive 
the car during the escape.  Note only people who have the 
skill of `Driving Cars' are fit for this task.


3.5. Thinking
-------------

See above (2.5. `Thinking')


3.6. Drawing up a plan
----------------------

As soon as you have chosen the target building and your 
accomplices, you can start working on the detailed plan of 
action.


3.7. Starting a burglary
------------------------

Upon selecting this option, you and your team will start 
acting according to the plan you have drawn up before.  In 
case you have worked out several different plans for the 
same burglary, they will be listed in a ballon for you to 
choose the one you wish to apply.


3.8. For little boys...
-----------------------

Planning and organising a burglary can take quite a long 
time.  In case you feel a certain...well, need to inturrupt 
this lengthy procedure - this is the right option to select.


4. The Planning Stage
---------------------

Finally the game has come to the point where you need to 
work out a detailed plan of action.  You have to fix the 
amount of time (shown in seconds) that you intend to spend 
on a certain action.  During the actual burglary these 
periods of time may be altered by unforeseen events or 
circumstances, such as the exhaustion of one of your 
accomplices.  Therefore, you should provide some spare time 
for unforeseen accidents when drawing up your plan.  Your 
plan is only completed when accomplices have reached the 
escape car (-which is symbolically shown as a little red car 
during the planning stage.)  When working out a plan, look 
out for objects marked with a red `A' or an `electricity' 
symbol, for these objects are connected to an alarm system 
or to the electricity supply, respectively.  This is the 
point where you may be glad that you gathered enough 
information about the buildings alarm system and electricity 
supply!  (See above 2.4. `Looking around inside target 
building') The time you can venture to spend inside the 
building is limited by two factors: The alarm systems and 
the alarm margin, i.e. the time taken by a police car to 
reach the site of the burglary.  (For the danger of police 
patrols that pass by in the street, see above, 2.6. 
`Watching')  Detailed information on how to handle security 
and alarm systems is given in point D of the appendix 
(`Descriptions of security systems').


4.1. Drawing up a plan
----------------------

This option will start the planning stage.
Note: You can cancel and delete any part of your plan by 
pressing the right mouse button or the <ESCAPE> key.

There are the following options:

	`Walking'             

	Select this option if you want to fix the escape 
	route along which you want an accomplice to move. 
	Use the joystick or the keyboard (i.e. the cursor 
	keys) to direct the person's movements. press the 
	right Mouse button or the <ESCAPE> key to undo a 
	movement you have planned. By pressing the <RETURN> 
	key you can leave this option. Do not forget to plan 
	short pauses, as well, as longer distances can 
	exhaust your accomplices. Note that all accomplices 
	have to be near the escape car at the end of your 
	plan - otherwise the escape is likely to be rather 
	chaotic, thus increasing the risk of traces being 
	left.

	`Use'

	If an object is within easy reach of a person, you 
	can get them to use a tool on this object by 
	selecting this option. At first, select the object 
	(or person) and then the tool you wish to be used on 
	this object or person. The time needed and the noise 
	produced when working with a tool should influence 
	your choice. Again, the time indicated may be 
	altered by unforeseen accidents or circumstances 
	during the actual burglary. Some actions may need 
	further explanation: By selecting `Use' - `window' 
	you can climb through open windows, if you have got 
	a rope ladder. `Use'- `stairs' allows a person to 
	mount or descend the stairs to another floor, if 
	there is any. The options `Use' - 
	`hand'/`foot'/`chloroform' are useful when you are 
	trying to overpower a guard. Again, such a fight may 
	not always end up the way you planned it. Therefore, 
	you should only chose accomplices for this task who 
	have a realistic chance to overcome the guard in a 
	fight.

	`Open'

	With this option you can open objects that are 
	within your reach. However, it is not all that easy 
	if the object is locked; in this case, you first 
	need to crack the lock with a suitable tool. Note 
	that guards and patrols are likely to control if 
	safes etc. are locked.

	`Close'

	It is advisable not to leave objects open, because 
	the change could easily be noticed by a guard or 
	even a police patrol that takes the time to look in 
	through the window when it passes the house. In 
	either case, the police would be alarmed.

	`Take'

	This is the right option to select if you want to 
	pick up an object. Note that every accomplice can 
	only carry  a certain weight! Of course, objects can 
	only be taken if they are accessable to you i.e. not 
	locked up in a safe, for example (in this case you 
	would have to crack the lock first).

	`Put down'

	Objects you have taken can be `put down' at any time 
	or place: The object is put into one of the bags you 
	have bought to carry the loot in, and put down on 
	the floor. Remember that you only have 8 bags! 
	Objects that have been put down can be picked up 
	(`taken') again later on.

	`Wait...'

	While they are `waiting', your accomplices get a 
	chance to recover from exhaustion. If you have the 
	impression that one of them needs a break, you 
	should select this option. Accomplices with the 
	skill of `looking out' will use the spare time you 
	give them to look out for danger, such as guards 
	patrolling the part of the building you are in. 
	(Police patrols or guards can either do a routine 
	check or be alarmed by neighbours who have noticed 
	you.) Upon selecting `Wait...' there are the 
	following options:

		`Waiting for a certain time'

		A clock is indicated in the balloon area. Using 
		the Joystick or the cursor keys you can fix the 
		exact time you want to be spent waiting.

		`Waiting for a radio message'

		You cannot select this option unless your team 
		is equipped with radios. You have to define 
		which radio message the person is to wait 
		for.

		`Ready!'

		This option ends the process of `waiting...'.

		`Sending a radio message'

		The best way to co-ordinate the accomplices' 
		activities is by sending radio messages. Define 
		which person you want to send a message, and 
		what they are to say.

		`Change person'

		With this option you can change the person you 
		are currently planning for. In case you have 
		more than one accomplice, you can chose who you 
		want to plan for next. The face of the person 
		of your choice will be shown in the top left 
		corner of the balloon area. All activities you 
		plan from now on are to be carried out by this 
		one person.

		`Ready!'

		With this command you can end the planning 
		stage.


4.2 The notebook
----------------

During the planning stage, you can look at your notebook for 
relevent data. For detailed information on the different 
notes you have taken, see above. (2.5. `Thinking')

	The target building

	You can take a look at the notes you have taken 
	while you were watching the building.

	`Accomplices'

	You will be shown a description of your accomplices' 
	characteristics and abilities.

	`The escape car'

	The data of your car.

	`Tools'

	You are shown a list of your tools and their 
	characteristics.


4.3 Saving a plan
-----------------

You can interrupt the planning stage and save the current 
plan at any time. later on you can continue working on it. 
The complete plan you intend to use for the actual burglary 
should of course be saved as well! (Otherwise your 
accomplices are not likely to know what they are meant to 
do...) The plan is saved on a disk or hard disk and can be 
loaded at any time. (See above, `Thinking about a plan') The 
maximum number of plans that can be saved for one target 
building is 4.


4.4 Continuing a plan
---------------------

If you wish to continue woking on a plan you have saved 
before, you only need to load it.


4.5 Dismissing a plan
---------------------

If you are convinced that something you have planned will be 
of no use whatsoever at any point of the game, you can 
dismiss it altogether. This is also the right option to 
select if you want to start the planning stage from scratch 
again.


4.6 Looking at a plan
---------------------

You can chose from the following options:

	Running a plan

	If you want to take a look at what you have planned 
	up to now, use the cursor keys `left' and `right' to 
	run the plan forwards or backwards second by second.

	Watching a person

	With this command you can watch any one of your 
	accomplices at any stage of the plan, and check that 
	they are co-operating in the way you want it.


5. The Burglary
---------------


5.1 Watching a person
---------------------

During a burglary, you also have the possibility to watch 
any of your accomplices while they are working. With this 
option, you can chose the person you wish to watch.


5.2 Sending a radio message to all accomplices
----------------------------------------------

With this command you can send radio messages that you want 
to be heard by all of your accomplices. For further 
information on radio messages, see below.


5.3 Sending a radio message to one accomplice
---------------------------------------------

A radio message of this kind is only destined for one 
person. You need to define the receiver and the contents of 
the message. The following information also applies to 5.2 
`Sending a radio message to all accomplices':

Note that a radio message should be formulated according to 
the current situation; for example, an optimistic message 
may not sound very convincing in a critical phase of the 
burglary, and vice versa... Your accomplices might begin to 
doubt that you are telling the truth, and this could be the 
cause of serious trouble within the team! However, there are 
some people who need to be encouraged in critical moments, 
even if you are not saying the exact truth. Also try to 
chose the right amount of radio messages, and the right time 
to send them. Being too talkative can easily decrease your 
accomplices' ability to concentrate on their work, whereas 
an encouraging message is sometimes crucila if a person is 
losing confidence. You should be especially careful with 
rude messages that might offend or injure an accomplice. 
Though some people may work better when they are angry, an 
unforgiving accomplice you have once insulted is likely to 
become dangerous in the future...


5.4 Escape
----------

If you happen to set off the alarm or to be noticed by 
neighbours, guards or police patrols during a burglary, the 
only possibility to come away unscathed is by escaping from 
the site of the crime as quickly as possible. However, you 
are likely to leave a lot of traces in the rush of escape, 
thus making life quite easy for the police. Therfore, you 
should always try to carry out the burglary according to the 
plan you have drawn up in advance. Once all accomplices have 
reached the car, you have to depend on the qualities of the 
car and its driver. Therfore, it is important to chose the 
best car and the driver who is most suitable for a coup 
BEFORE you start the burglary. The escape route and its 
length should influence your decision in this matter. During 
the escape, you will see your car on the screen, as well as 
a plan of the escape route with a little square (the colour 
of your car) indicating your current position. In case the 
police has been alerted, there will also be a little black 
square, symbolising the police car that is pursuing you. 
After an alarm, the `alarm margin' is your maximum lead on 
the police car. If you manage to reach the left end of the 
plan shown on the screen, you have made it to the car park 
of Cars & Vans, and you have managed to escape the police. 
However, if the police car manages to get as close as 50 
metres to your car, you are caught and arrested.


6. The Investigation
--------------------

After a successful burglary and escape, the police will 
start investigating the case. At first, they will search the 
site of the crime for traces. Meanwhile, a notebook is shown 
in the balloon area, indicating the chances for the police 
to suspect you or one of your accomplices. Ther are several 
aspects that may help the police:

	`Records existing'

	This is a measure for how much the police already 
	knows about a burglar in question. The more records 
	they have on a person, the more likely it gets that 
	this person is been suspected and a search is 
	started.

	`Traces left when walking'

	These are the traces a burglar has left while he was 
	moving around in the building. They mainly depend on 
	the person's nerves, stamina and dexterity.

	`Traces left when waiting'

	A nervous person is most likely to leave traces 
	while they are waiting.

	`Traces left when working'

	Traces of this kind can be caused in many ways and 
	are influenced by many different factors - starting 
	from the burglar's nerves and the tool he is using, 
	up to the personal characteristics of the respective 
	person. Whether such traces are left or not is in 
	fact influenced by nearly all factors possible.

	`Traces left during a fight'

	These traces are caused while an accomplice is 
	trying to overpower a guard.

After the police has looked for traces, all possible 
witnesses of the burglary are questioned. It may even happen 
that a passer-by or a neighbour has noticed a conspicuous 
car parking in front of the site of the crime, which may 
help the police to find the burglars. The information 
gathered by examining the traces and questioning the 
witnesses may either lead to the immediate identification of 
a burglar, or to a person being suspected because their 
police record gives them away as a possible participent in 
this burglary. In either case, the police will start a 
search for the respective person, or the car that has been 
seen. It will depend on you and your accomplices' skill at 
hiding from the police whether you are arrested or not.


V. Appendices
-------------


Appendix A: London - Descriptions of Important Buildings
--------------------------------------------------------


Bank of England
---------------

The Bank of England was founded by Royal Charter as a 
private association in 1694. Its original task was to 
provide money for the war against France. The building, 
designed by an architect called Sir John Soanes, was built 
from 1788 to 1833. Already during its construction, however, 
the original structure was considerably altered by Sir 
Herbert Baker. The sculptures above the entrance were made 
by Sir Charles Wheeler. Nowadays, the main task of the Bank 
of England's is very much like other national bank's: To 
secure the stability of the British currency by controlling 
the amount of money in circulation, and by fixing the basic 
rate of interest. Talking of interest - it may also be 
interesting to know that the British gold reserves are kept 
inside this building.


British Museum
--------------

The British Museum is a museum of world fame. Counting a 
huge number of visitors from all around the globe every 
year, it is also among the most popular sights of the 
British capital. Its collection of Egyptian, Greek and 
Assyrian sculptures is unique in the world. The museum 
originated from the collections of Sir Robert Cotton, Robert 
Harley, Earl of Oxford, and Sir Hans Solane. It was founded 
in 1753 by a parliamentary decree. After being exhibited in 
Montague House for several years, the collections were 
transported to their present location: A building of 
classicistic style designed by Robert Smirke and built by 
his brother Sydney from 1823 to 1857. Apart from the 
collections mentioned above, there are nowadays many more 
historic objects and pieces of folk art from nearly all 
cultures. The British Museum also includes a large folklore 
department, which is situated in the Museum of Mankind.


Chiswick House
--------------

This old and aristocratic mansion is situated only a few 
streets away from Turnham Green, in Richmond upon Thames. 
What is nowadays a high-class housing area, used to be the 
location of a royal castle constructed for King Edmund I. in 
medieval times. In 1639, under the rule of Charles I., huge 
hunting grounds were laid out on the area of Richmond Park. 
the mansion itself was built by Richard Boyle in 1725, by 
order of Lord Burlington. During his two journeys to Italy, 
Burlington had been impressed and inspired by the 
neo-classicistic mansions and palaces built by architects 
like Andrea Palladio. The high and lofty, but very scarcely 
furnished halls in Chiswick House are destined to create a 
strangely archaic feeling, and the whole building is full of 
mythologic allusions.


Karl Marx' Tomb
---------------

Highgate Cemetery is situated in the North of London, in the 
district of Hampstead. This part of town, livened up by many 
beautiful green lawn and romantic pond, may still be called 
London's most exquisite recreational area - a reputation 
that it has kept throughout more than a century. Especially 
artists, such as John Keats, Robert Louis Stevenson and 
George Orwell, chose Hampstead as their place of residence, 
and even Charles de Gaulle and Siegmund Freud owned houses 
in this district. 160000 people have found their last 
resting place on Highgate Cemetery. The most famous among 
them is Karl Marx. The German theorist of Socialism and 
founder of marxism lived from 1818 to 1883. From 1842 to 
1844 he was the Director of the liberal newspaper 
`Rheinische Zeitung', in Cologne. In the year 1845 he went 
to Paris, and hence to Brussels. In 1844 he started his 
intellectualcontact with Friedrich Engels, which resulted in 
the writing of the `Communist manifesto', a monument of 
political theoy originally ordered by London's Communist 
Association. In 1849, Marx moved to London, where he finally 
wrote his masterpiece `The Capital', in 1867.


Ham House
---------

Ham House is situated in the middle of a large park in 
Richmond. Originally, it was a modest country house built 
Sir Thomas Vavascour in 1610. Elisabeth, Countess of 
Drysart, inherited the building from her father in the 
middle of the 17th century. It was only after her marriage 
to the Duke of Lauderdale, a minister to Charles II., that 
the mansion was considerably enlarged in opulent baroque 
style: From 1673 to 1675, architects and artists from 
Germany, the Netherlands and Itlay were working on it. The 
result of the Lauderdales' attempts to beautify the building 
has nearly completely been kept to this very day. Just like 
Osterley House, it has become property of the National 
Trust. Nowadays it is partof the Victoria and Albert Museum, 
and open to public. Besides, there is an old rumour that the 
Duchess of Lauderdale is still haunting the chapel of this 
mansion, for her husband was buried there in 1682.


Kenwood House
-------------

Kenwood House, situated in the North of London, can probably 
be said to have the most privileged location of all mansions 
in this town. Built on one of the most elevated points of 
London, it seems to overlook the whole of the British 
capital as far as the River Thames. It is surrounded by 
majestic old Oak trees and Beeches. Kenwood House is built 
in neo-classic style. It was constructed by the Scottish 
architect Robert Adam between 1764 and 1779, by order of the 
Earl of Mansfield. During an auction of Kenwood property in 
1927, more than a thousand pieces of art were sold. The 
building's new owner, Lord Ivegah, a Maecenas in the classic 
sense, transported his large collection of paintings to 
Kenwood House. The art collection, which he donated to the 
British Empire before his death in 1928, comprises paintings 
of Reynolds, Gainsboroug, Bol, Hals, van Dyck, Vermeer and 
Rembrandt.


National Gallery
----------------

This building in classicistic style was designed by William 
Wilkins and built between 1834 and 1837. One of the most 
extensive and precious art collections in the world is 
exhibited in the National Gallery. The Gallery was founded 
as early as 1824, when the British government appropriated 
the huge sum of 57000 pounds for the purchase and exhibition 
of 38 paintings belonging to the famous Angerstein 
collection. These paintings were originally exhibited in the 
Angerstein rooms, 100, Pall Mall. In 1876, however, an 
enlargement of the National Gallery was necessitated by a 
number of purchases and gifts. At the time, the Gallery's 
dome was constructed, resulting in the nickname of `national 
spice rack'. Further enlargements took place in 1887, 1927 
and 1929. Opuses of the Italian, Flemish and Dutch schools 
form the large majority among the hundreds of paintongs that 
are nowadays exhibited in the National Gallery.


National History Museum
-----------------------

The National History Museum owes its existence to the 
genorosity of Sir Hans Slone. When the rich natural 
scientist died in 1753, he transfered his extensive 
collections to the British Empire. This was the origin of 
the National History Museum. In 1860, after it had been 
decided that the museum's natural science department should 
be located in a seperate building, the architect Alfred 
Waterhouse was ordered to build a new museum in Kensington. 
The result of accurate planning and seven years of 
construction was a huge palace looking very much like a 
cathedral. Finally, in 1881, the new National History Museum 
was opened. The building itself, a romanic, architecturally 
interesting edifice, has two steeples, each of them 64 
metres high, and is situated in famous Cromwell Road. Still 
most of the objects and curiosities exhibited are donations 
of Sir Hans Sloane, who bought them during his time as the 
physician in ordinary to the Governer in Jamaica. The 
collection's original inventory comprises about 50000 books, 
10000 animal specimens and 334 volumes of dried and pressed 
plants. During the following decades, however, several ten 
thousand objects were incorporated in the National History 
Museum.


Osterly Park House
------------------

In one of these old West London suburbs consisting mainly of 
red brick houses, in a park with ancient trees and small 
ponds, there is a mansion called Osterly Park House. It was 
built in the 18th century for the Child family, who had only 
recently come to great riches, and whose ancestors had, with 
some other goldsmiths, founded the tradition of banking in 
Britain. The architect was a man called Robert Adam. He gave 
Osterly Park House a touch of classicistic style. Lord 
Jersey, an ancestor of the Childs, donated the mansion to 
the National Trust in 1949. Thanks to this wise decision, 
Osterly Park House is nowadays a museum open to public.


Suterby's
---------

London is famous for its great number of public sale-rooms. 
Apart from the old and famous one, such as Christie's and 
Sotheby's, there are several smaller ones. Suterby's - not 
to be mixed up with the famous Sotheby's - is typical for 
this kind of English sale-rooms. It is a true El'Dorado for 
collectors. At Suterby's, everything is on sale that one 
could possibly collect.


Tower of London
---------------

The Tower of London, this gloomy and frightening edifice, is 
situated in the East of the City, just outside the old city 
walls. It is probable that already at the time of Roman 
occupation, there was a fortress on this very spot. The 
origin of today's Tower is due to William the Conquerer, who 
had a fortress built at the north shorre of the River Thames 
after the Battle of Hastings. The task of this fortress was 
to protect the city and to watch shipping on the Thames. 
This part of the fortress, called The White Tower, was 
finished in 1878 and enlarged several times during the 12th, 
13th and 14th centuries. It was finally restored again in 
the 19th century. For a long time, the Tower was the King's 
Residence, but also the State Prison. The history of this 
building is very closely connected to the history of 
England. Many a famous personality was imprisoned in the 
Tower, such as David II of Scotland (1346-1357), John the 
Benevolent (1356-1360), Duke Charles of Orleans (1415), 
James I of Scotland (1406-1407). Some of them never left the 
Tower alive: Henry VI. was executed in 1471, his brother, 
the Duke of York, in 1483, Sir Thomas More in 1535; the 
Queens Anne Boleyn and Katharine Howard had to die in 1536 
and 1542 respectively, and Thomas Cromwell was executed in 
1540. Many more names could be added to this list. Even 
during the Second World War, spies and secret agents were 
executed in the Tower. From 1941 onwards, Rudolph Hess was 
kept prisoner in these ancient rooms. Nowadays, the Crown 
Jewels, the most precious possession of the British Empire, 
are kept in this building, making the Tower one of the most 
popular tourist attractions of London.


Victoria and Albert Museum
--------------------------

The Victoria and Albert Museum, simply called V&A by the 
British, lies in South Kensington. The National History and 
the Science Museum lie in the same part of the city, making 
it a regular `museum quarter'. Prince Albert, Queen 
Victoria's husband, originally had the idea of founding a 
museum for the remarkable products of fine art and craft 
from many different cultures and times. The money for the 
realization of this idea was raised by a `Great Exhibition' 
in 1851. The museum opened in 1857, in the rooms of what is 
now the Bethnal Green Museum. The present V&A museum 
building was built between 1899 and 1909 on 
psuedo-renessaince style. In 1909, finally, King Edward VII. 
founded the `National Museum of Fine Arts'. The V&A exhibits 
valuable sculptures, fine pieces of furniture, fabric, 
pottery and architecture, as well as national costumes and 
artwork from Indian and Far Eastern cultures, Byzantine 
sculptures, ancient Italian paintings and many other old and 
valuable pieces of art. The Victoria & Albert Museum is one 
of the most distinguished art museums in the world.


Appendix B: Motor Journal
-------------------------


Cadillac Club Coupe
-------------------

PS:                          160 Top
Speed:                       160 km/h
Cubic Capacity:              5420 cm3
Engine:                      V8
Producer Country:	    USA

This enterprise was originally called Henry Ford Company, 
but a few months after its foundation the then chief 
engineer Henry Ford left the Company to found his own Ford 
Motor Company. Ford's successor, Henry Leland, renames the  
Company in honour of Antoine de la Mothe Cadillac, who had 
the city of Detroit in 1701. From 1948 onwards, the Club 
Coupe was provided with a new V8 engine and cam drive. With 
this equipment, the fastest Cadillac type produced reached a 
top speed of 99.6 mph (160 km/h) in 1949. At this time, this 
was an absolutely amazing achievement for a car of the 
Cadillac's size. The cars of `series 62', in 1949, had a 
remarkable standard equipment including back lights, and the 
`Club Coupe' was additionally fit out with hydralic window 
openers and luxurious interior furnishings. The overall 
number of `series 62' cars produced is 55,643.


Fiat Topolino
-------------

PS:			    13 Top
Speed:			    88 km/h
Cubic Capacity:	    569 cm3
Engine:			    4 cylinders aligned
Producer Country:	    Italy

The Fiat Topolino was designed by Franco Fessia. It was in 
production between 1936 and 1955. It is a small but 
extraordinary car with many technical innovations, such as 
the seperate suspension of the front wheels. In spite of its 
small size, it offers enough room for two people, a small 
amount of luggage or children. Its nickname `the mouse' is 
due to the somehow cute and loveable exterior design of the 
Fiat 500 Topolino.


Jaguar XK 120
-------------

PS:			    160 Top
Speed:			    203 km/h
Cubic Capacity:	    3400 cm3
Engine:			    5 cylinders aligned
Producer Country:	    Great Britain

The XK 120 with its new 3.4 I engine is a typical sports 
car. It was first presented at the London Motor Show in 
1949. The engine, which was developed by William Heynes, 
Wally Hassan and Claude Baily, was an interesting 
construction with the double top cam drive. Two years later, 
in 1951, Jaguar presented the model type C. It was mainly 
destined for racing. Its engine was similar to the one of 
the XK 120, but technically improved and much more 
developed.


Morris Minor
------------

PS:			    29 Top
Speed:			    100 km/h
Cubic Capacity:	    919 cm3
Engine:			    4 cylinders aligned
Producer Country:	    Great Britain

The Morris Minor was designed and, in 1948, also presented 
by Alex Issigonis. It is a small but very efficient 
four-seated car with rear-wheel drive and seperate wheel 
suspension. 1.5 million cars of this model were produced, 
and some of them are still in use. Many a British car 
mechanic still earns quite a lot of money repairing this old 
but robust car.


Opel Olympia
------------

PS:			    40 Top
Speed:			    118 km/h
Cubic Capacity:	    1488 cm3
Engine:			    4 cylinders aligned
Producer Country:	    Germany

The Opel Enterprises, whic were taken over by General Motors 
in 1928, already produced the first `Olympia' in 1935. The 
car owes its name to the Olympic Games in Berlin. It was the 
first German car with integral coach-work produced in 
quantity. The Olympia was furnished with an excellent 4 
cylinder engine, which was kept unchanged up until 1960. 
After the Second World War, Opel did not build any cars of 
this type until 1947. In 1950 the Opel Olympia was presented 
with a new body design and three gears instead of the 
previous four. 1953, however, the Olympia was replaced by 
the `Rekord' model, and its production was stopped in 1957.


Pontiac Streamliner
-------------------

PS:			    103 Top
Speed:			    140 km/h
Cubic Capacity:	    4070 cm3
Engine:			    8 cylinders aligned
Producer Country:	    USA

The Pontiac Car Enterprises were founded in 1962. The first 
Pontiac car was presented in New York. Pontiac, the 
chieftain of the Ottawa Indian tribe, whose name the 
Enterprise adopted, had supported the French in their war 
against the English from 1763 to 1764. Right from the start, 
the success of the Pontiac cars was due to their luxurious 
and comfortable furnishings, which were offered at a 
considerably low price. As the Pontiac producers have always 
kept to this principle of high quality and low cost, Pontiac 
is still a very successful company. The Streamliner was 
developed in two versions: With 6 or 8 cylinders, as `Sedan 
Coupe' or `Station Wagon', respectively. On January 5th 1942 
the production of Pontiac cars had to be stopped altogether 
because of the World War, and it was only in September 1945 
that new models could be presented. All in all. 12,742 cars 
of the six-cylinder type and 25,506 of the eight-cylinder 
model were built.


Standard Vanguard
-----------------

PS:			    68
Speed:			    120 km/h
Cubic Capacity:	    2088 cm3
Engine:			    4 cylinders aligned
Producer Country:	    Great Britain

The Vanguard was first built in 1947 as a limousine with 
four doors and integral coach-work. As its exterior design 
was very similar to American cars, it was also very popular 
in the USA and in Australia. In 1951 a `station wagon' 
version of the Standard was developed, if desired with 
overdrive. In 1962, the Vanguard disappeared as a car brand 
altogether.


Triumph Roadstar
----------------

PS:			    65
Speed:			    120 km/h
Cubic Capacity:	    1775 cm3
Engine:			    4 cylinders aligned
Producer Country:	    Great Britain

The 1800 Roadstar was the first car produced after the 
Triumph company had been taken over by Roadstar. This 
sportscar, with its long bonnet and its elegant, lean body, 
was one of the most beautiful automobiles built in the time 
shortly after the Second World War. The 1800 Roadstar was 
also the last car to have so-called `mother-in-law seats': 
Inside the boot there were two small glass panes that served 
as windscreens for the passengers on the dickey seats.


Willys Jeep
-----------

PS:			    54
Speed:			    100 km/h
Cubic Capacity:	    2199 cm3
Engine:			    4 cylinders aligned
Producer Country:	    USA

John North Willys, originally working as a car trader for 
the American Motor Car Sales Company, had just ordered 500 
Overland cars when the Overland works slid into a deep 
financial crisis. Willys was so impressed by the quality of 
the Overland cars that he simply decided to buy the whole 
company, thus founding the Willys-Overland Company. The most 
famous car he ever built was the Jeep, which he designed 
specially for the Allied Troops in 1940. Until the end of 
the Second World War, 361,349 pieces of this sturdy military 
car were produced. After the war had ended, the Jeep was 
still frequently used, and in 1945 a `station wagon' version 
of the original Jeep was presented. In 1956, Willys finally 
decided to stop producing automoboles for civil use, and in 
1963 changed the name to `Kaiser-Jeep'.


Apendix C: Description of Tools
-------------------------------


	Axe
	---

	This hand-made steel axe has an ergonomically formed 
	handle of stury Ash-wood. The blade is polished, and 
	the whole tool only weighs 1250 g, thus being very 
	easy to handle.

	Battery
	-------

	This is an ordinary 6 volt car battery. It can also 
	be used for small electric tools, such as a 
	soldering iron.

	Drill
	-----

	This is a 550 watt percussion drill with an 
	infinitely variable speed governer that ensures 
	precise working. The ergonomically formed handle 
	makes slipping impossible and makes the tool very 
	comfortable to handle.

	Drilling Winch
	--------------

	A dilling winch is the ideal tool to be used for 
	very fine and precise working. Unlike with automatic 
	drills, the user does not depend on electric supply, 
	and makes much less noise. Nevertheless, the use of 
	this very simple tool can become tiring after some 
	time.

	Jemmy
	-----

	There is not much to say about this crowbar. It is 
	commonly known that its main use is for cracking 
	doors or cupboards.

	Chloroform
	----------

	Chloroform, also called tri-methane chloride, is a 
	gase with a sickly sweet scent. It does not burn, 
	and is mostly used as a solvent. Moreover, 
	chloroform is a rather efficient narcotic.

	Picklock
	--------

	In principle, a picklock is only a piece of thin, 
	flat wire bent a certain angle. It can be used to 
	open ordinary locks. Of course using a picklock is 
	not quite as easy as simply unlocking a door with a 
	key. It takes a good deal of experience and deftness 
	to be able to open a door with a picklock.

	Dynamite
	--------

	This explosive was invented by the Swedish scientist 
	A. Nobel in 1867. It consists of 75% nitroglycerine 
	and 25% of a compound similar to silicium. Nowadays, 
	however, the latter is, often replaced by collodium 
	wool. Extreme care should be taken when handling 
	dynamite.

	Electric Hammer
	---------------

	This `electric crowbar' has a capacity of 2500 watt. 
	The integrated shock-absorber assures safe 
	application of this tool even on very strong walls. 
	However, this tool is also very heavy and can 
	therefore only be handled by physically strong 
	people.

	Electric Kit
	------------

	This electric kit consists of a 15 watt soldering 
	iron, which is ideal for precision work, different 
	pairs of tongs, a cutter, several clamps, some 
	metres of wire and everything else that can come in 
	handy in smaller electrical repairs.

	Radio
	-----

	This is a CB hand radio with 20 channels and a 
	broadcasting capacity of 2 watt. This high quality 
	product has a modern dolby system and battery 
	control.

	Hammer
	------

	This is called a fist hammer, very stable and handy. 
	The wooden handle is especially sturdy and ideal for 
	frequent and heave use.

	Gloves
	------

	These gloves, made of fine velours leather, are a 
	product of highest quality. They enable the owner to 
	have a secure grip even on smooth or slippery 
	objects.

	Glass Cutter
	------------

	This glass cutter is supplied with an industrial 
	diamond with a hardness degree of 10. It is simply 
	perfect for breaking glass. In spite of its name, 
	however, this tool will not cut the glass nicely, 
	but rather break it.

	Gound Auger
	-----------

	This ground auger can be used to drill a nucleus out 
	of walls or stone. Underground workers use the same 
	type of tool, but much bigger. It will drill even 
	bigger holes in steelwalls, if you change the drill 
	bit.

	Mask
	----

	This is an ordinary mask, which is usually worn by 
	people on carnival parties, or by those who do not 
	wish to be recognised.

	Oxygen Cutter
	-------------

	By burning pure oxygen, this oxygen cutter can reach 
	temperatures up to 3000 degrees Celsius. It will cut 
	every material, even thick steel, as easily as if it 
	were a piece of paper. It is a steel pipe filled 
	with oxygen. The pipe will gradually melt itself, 
	therefore the tool will shorten while it is used. 
	When using the oxygen cutter, it is absolutely 
	essential to wear appropriate protective clothing, 
	for the heat produced is simply too great.

	Lock Breaker
	------------

	This tool belongs to the essential equipment of 
	nearly every burglar. It is a metal rod with a 
	sharpened tip and a hook. It can be slid into 
	cylindrical locks, and by carefully moving it back 
	and forth, the experienced user will break open 
	almost every cylindrical lock with it.

	Cutting Torch
	-------------

	This cutting torch - an autogenic one, to put it 
	precisely - burns acetylen gas with oxygen. Thus the 
	heat necessary for welding is generated. Both gases 
	are stored in these steel flasks.

	Shoes
	-----

	These shoes may not look very elegant, but they were 
	produced by a world famous American shoe 
	manufactorer, `L.L.Bean' in Freeport, Maine. LLB has 
	a worldwide reputation for high quality outdoor 
	clothing, and it is a brand of good tradition. The 
	works were founded in 1911. This special pair of 
	shoes is furnished with soft rubber soles that 
	subdue the noise of walking. As a whole, they are 
	made of sturdy leather. Moreover, they are 
	waterproof.

	Protective Clothes
	------------------

	This set of protective clothes is made of a special 
	material containing asbestos. It will protect you 
	against great heat and flames - which is, for 
	example, very important when welding.

	Check Clock Card
	----------------

	This is an ordinary card to be used with any check 
	clock.

	Stethoscope
	-----------

	The word `Stethoscope' comes from the Greek term for 
	`ear-trumpet'. Physicians and doctors use it to 
	control the noises made by the different body 
	organs, such as the heart and lungs. However, 
	several people with criminal ambitions, use a 
	stethoscope to be able to hear the very slight 
	clicking of a combination lock when the right number 
	is found.

	Rope Ladder
	-----------

	This is a strong rope ladder of excellent make which 
	will even carry an overweight person.

	Generator
	---------

	This generator could almost be called a small 
	power-plant. Its 6 volt motor has a capacity of 3000 
	watt - enough for electric tools, pumps, lamps and 
	many other useful things, even far from ordinary 
	electric supply.

	Angular Grinder
	---------------

	This two-handed angular grinder can be used on the 
	hardest materials, such as stone and metal. The 
	infinitely variable gear button as well as the side 
	handle guarantee security and precision when 
	handling this tool. The stable 2000 watt motor makes 
	this tool useful in a widely ranged operational 
	area.


Appendix D: Descriptions of Security Systems
--------------------------------------------


Alarm Systems
-------------

Buildings containing valuables are especially likely to be 
fit out with an alarm system. Basically, there are three 
types of alarm systems you may have to deal with: The `X3', 
the `Z3' and the `Top' systems. These alarm systems are 
designed to keep valuable objects of all kinds from being 
touched by unauthorized persons. To turn off an alarm 
system, you will need the electric kit. After you have 
turned the system off, you will be able to handle or steal 
the objects connected to it without danger. The time neede 
to turn off an alarm system will vary according to the type: 
The `X3' is fairly easy to de-activate, wheras turning off a 
`Top' will take longest. moreover, the `Top' systems are 
fitted out with an addditional safety mechanism, which could 
become dangerous for you: As soon as the system is turned 
off, a control mechanism is started, which is to difficult 
to be turned off - even an expert would take at least 
several days to do so. However, to prevent false alarms 
after a possible power failure, this control mechanism will 
only set off the alarm siren after 15 minutes. In case an 
alarm is set off, there will be several police cars sent to 
the site of the burglary. Again, they will take a certain 
amount of time to reach the building you are in, giving you 
a chance to escape. (You will come to know this amount of 
time - the `alarm margin' - while you are observing the 
target building.) While `looking round inside a target 
building', you should also pay special attention to the type 
of alarm installed.


Microphones
-----------

Microphones are always connected to an alarm system and will 
set off an alarm siren if a certain noise level is exceeded.

Searchlights
------------

Searchlights will always be combined with cameras. If a 
person is caught by a searchlight, a photo is automatically 
taken. These photos can be an important aid to the police 
during their investigation. Searchlights are connected with 
a switchbox, where they can be turned off and on.

Check Clocks
------------

Check clocks are often installed to control the guards. If a 
check clock card is not slid into them at regular times, an 
alarm will be set off.

Switchboxes
-----------

With switchboxes, certain security systems, such as 
searchlights, can be turned on and off. However, if you 
happen to turn off an object connected to an alarm system, 
an alarm will be set off.

Guards
------

Guards usually control the inside of a building on regular 
patrols, paying special attention to objects of value. In 
case they find any change, such as cupboards or safes that 
have been opened, they will send an alarm call to the police 
via radio. Of course, they will also react if they come 
across one of your accomplices! The only way to overcome a 
guard is to attack him from the back. The guard's patrols 
may sometimes be controlled by check clocks. (See above.)

Other Security Measures
-----------------------

Police patrols and private security companies will pass by 
every target building at regular intervals. These patrols 
will look into the building through the windows. If they see 
anything suspicious, they will give alarm.

You should therefore always try to leave as few traces as 
possible inside the target building. Note that traces can 
also be caused when fighting with a guard!


