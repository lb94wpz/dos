/***********************************************************
* Mirror Magic -- McDuffin's Revenge                       *
*----------------------------------------------------------*
* (c) 1994-2001 Artsoft Entertainment                      *
*               Holger Schemel                             *
*               Detmolder Strasse 189                      *
*               33604 Bielefeld                            *
*               Germany                                    *
*               e-mail: info@artsoft.org                   *
*----------------------------------------------------------*
* main.h                                                   *
***********************************************************/

#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>

#include "libgame/libgame.h"

#define WIN_XSIZE	640
#define WIN_YSIZE	400

#if !defined(PLATFORM_MSDOS)
#define WIN_XPOS	0
#define WIN_YPOS	0
#else
#define WIN_XPOS	((XRES - WIN_XSIZE) / 2)
#define WIN_YPOS	((YRES - WIN_YSIZE) / 2)
#endif

#define SCR_FIELDX	16
#define SCR_FIELDY	12
#define STD_LEV_FIELDX  SCR_FIELDX
#define STD_LEV_FIELDY  SCR_FIELDY
#define MAX_LEV_FIELDX	SCR_FIELDX
#define MAX_LEV_FIELDY	SCR_FIELDY
#define MAX_BUF_XSIZE	SCR_FIELDX
#define MAX_BUF_YSIZE	SCR_FIELDY

#define MAX_PLAYERS     1

#define SCREENX(a)      (a)
#define SCREENY(a)      (a)
#define LEVELX(a)       (a)
#define LEVELY(a)       (a)
#define IN_VIS_FIELD(x,y) ((x)>=0 && (x)<SCR_FIELDX && (y)>=0 &&(y)<SCR_FIELDY)
#define IN_SCR_FIELD(x,y) ((x)>=BX1 && (x)<=BX2 && (y)>=BY1 &&(y)<=BY2)
#define IN_LEV_FIELD(x,y) ((x)>=0 && (x)<lev_fieldx && (y)>=0 &&(y)<lev_fieldy)
#define IN_PIX_FIELD(x,y) ((x)>=0 && (x)<SXSIZE && (y)>=0 && (y)<SYSIZE)

/* values for 'Elementeigenschaften' */
#define EP_BIT_GRID		(1 << 0)
#define EP_BIT_MCDUFFIN		(1 << 1)
#define EP_BIT_RECTANGLE	(1 << 2)
#define EP_BIT_MIRROR		(1 << 3)
#define EP_BIT_MIRROR_FIXED	(1 << 4)
#define EP_BIT_POLAR		(1 << 5)
#define EP_BIT_POLAR_CROSS	(1 << 6)
#define EP_BIT_BEAMER		(1 << 7)
#define EP_BIT_CHAR		(1 << 8)
#define EP_BIT_REFLECTING	(1 << 9)
#define EP_BIT_ABSORBING	(1 << 10)
#define EP_BIT_INACTIVE		(1 << 11)
#define EP_BIT_WALL		(1 << 12)
#define EP_BIT_PACMAN		(1 << 13)

#define IS_GRID(e)		(Elementeigenschaften[e] & EP_BIT_GRID)
#define IS_MCDUFFIN(e)		(Elementeigenschaften[e] & EP_BIT_MCDUFFIN)
#define IS_RECTANGLE(e)		(Elementeigenschaften[e] & EP_BIT_RECTANGLE)
#define IS_MIRROR(e)		(Elementeigenschaften[e] & EP_BIT_MIRROR)
#define IS_MIRROR_FIXED(e)	(Elementeigenschaften[e] & EP_BIT_MIRROR_FIXED)
#define IS_POLAR(e)		(Elementeigenschaften[e] & EP_BIT_POLAR)
#define IS_POLAR_CROSS(e)	(Elementeigenschaften[e] & EP_BIT_POLAR_CROSS)
#define IS_BEAMER_OLD(e)	(Elementeigenschaften[e] & EP_BIT_BEAMER)
#define IS_CHAR(e)		(Elementeigenschaften[e] & EP_BIT_CHAR)
#define IS_REFLECTING(e)	(Elementeigenschaften[e] & EP_BIT_REFLECTING)
#define IS_ABSORBING(e)		(Elementeigenschaften[e] & EP_BIT_ABSORBING)
#define IS_INACTIVE(e)		(Elementeigenschaften[e] & EP_BIT_INACTIVE)
#define IS_MM_WALL(e)		(Elementeigenschaften[e] & EP_BIT_WALL)
#define IS_PACMAN(e)		(Elementeigenschaften[e] & EP_BIT_PACMAN)

#define IS_WALL_STEEL(e)	((e) >= EL_WALL_STEEL_START &&		\
				 (e) <= EL_WALL_STEEL_END)
#define IS_WALL_WOOD(e)		((e) >= EL_WALL_WOOD_START &&		\
				 (e) <= EL_WALL_WOOD_END)
#define IS_WALL_ICE(e)		((e) >= EL_WALL_ICE_START &&		\
				 (e) <= EL_WALL_ICE_END)
#define IS_WALL_AMOEBA(e)	((e) >= EL_WALL_AMOEBA_START &&		\
				 (e) <= EL_WALL_AMOEBA_END)
#define IS_DF_WALL_STEEL(e)	((e) >= EL_DF_WALL_STEEL_START &&	\
				 (e) <= EL_DF_WALL_STEEL_END)
#define IS_DF_WALL_WOOD(e)	((e) >= EL_DF_WALL_WOOD_START &&	\
				 (e) <= EL_DF_WALL_WOOD_END)
#define IS_DF_WALL(e)		((e) >= EL_DF_WALL_START &&		\
				 (e) <= EL_DF_WALL_END)
#define IS_WALL(e)		(IS_MM_WALL(e) || IS_DF_WALL(e))
#define IS_WALL_CHANGING(e)	((e) >= EL_WALL_CHANGING_START &&	\
				 (e) <= EL_WALL_CHANGING_END)
#define IS_GRID_STEEL(e)	((e) >= EL_GRID_STEEL_START &&		\
				 (e) <= EL_GRID_STEEL_END)
#define IS_GRID_WOOD(e)		((e) >= EL_GRID_WOOD_START &&		\
				 (e) <= EL_GRID_WOOD_END)
#define IS_GRID_WOOD_FIXED(e)	((e) >= EL_GRID_WOOD_FIXED_START &&	\
				 (e) <= EL_GRID_WOOD_FIXED_END)
#define IS_GRID_STEEL_FIXED(e)	((e) >= EL_GRID_STEEL_FIXED_START &&	\
				 (e) <= EL_GRID_STEEL_FIXED_END)
#define IS_GRID_WOOD_AUTO(e)	((e) >= EL_GRID_WOOD_AUTO_START &&	\
				 (e) <= EL_GRID_WOOD_AUTO_END)
#define IS_GRID_STEEL_AUTO(e)	((e) >= EL_GRID_STEEL_AUTO_START &&	\
				 (e) <= EL_GRID_STEEL_AUTO_END)
#define IS_DF_GRID(e)		(IS_GRID_WOOD_FIXED(e) ||		\
				 IS_GRID_STEEL_FIXED(e) ||		\
				 IS_GRID_WOOD_AUTO(e) ||		\
				 IS_GRID_STEEL_AUTO(e))
#define IS_DF_MIRROR(e)		((e) >= EL_DF_MIRROR_START &&		\
				 (e) <= EL_DF_MIRROR_END)
#define IS_DF_MIRROR_AUTO(e)	((e) >= EL_DF_MIRROR_AUTO_START &&	\
				 (e) <= EL_DF_MIRROR_AUTO_END)
#define IS_LASER(e)		((e) >= EL_LASER_START &&		\
				 (e) <= EL_LASER_END)
#define IS_RECEIVER(e)		((e) >= EL_RECEIVER_START &&		\
				 (e) <= EL_RECEIVER_END)
#define IS_FIBRE_OPTIC(e)	((e) >= EL_FIBRE_OPTIC_START &&		\
				 (e) <= EL_FIBRE_OPTIC_END)
#define FIBRE_OPTIC_NR(e)	(((e) - EL_FIBRE_OPTIC_START) / 2)
#define IS_BEAMER(e)		((e) >= EL_BEAMER_RED_START &&		\
				 (e) <= EL_BEAMER_BLUE_END)
#define BEAMER_CLASSIC_NR(e)	(((e) - EL_BEAMER_RED_START) / 16)
#define BEAMER_NR(e)		(IS_BEAMER(e) ? BEAMER_CLASSIC_NR(e) :	\
				 IS_FIBRE_OPTIC(e) ? (FIBRE_OPTIC_NR(e)+4) : 0)
#define IS_EXPLODING(e)		((e) == EL_EXPLODING_OPAQUE ||		\
				 (e) == EL_EXPLODING_TRANSP)

#define IS_EATABLE4PACMAN(e)	((e) == EL_EMPTY ||			\
				 (e) == EL_KETTLE ||			\
				 (e) == EL_CELL ||			\
				 (e) == EL_BOMB ||			\
				 IS_WALL_AMOEBA(e))

#define CAN_MOVE(e)		((e) == EL_PACMAN)
#define IS_FREE(x,y)            (Feld[x][y] == EL_EMPTY)

#define IS_MOVING(x,y)          (MovPos[x][y] != 0)
#define IS_BLOCKED(x,y)         (Feld[x][y] == EL_BLOCKED)
#define IS_DRAWABLE(e)          ((e) < EL_BLOCKED)
#define IS_NOT_DRAWABLE(e)      ((e) >= EL_BLOCKED)

#define PLAYERINFO(x,y)         (&stored_player[StorePlayer[x][y]-EL_SPIELER1])

#define WALL_BASE(e)		((e) & 0xfff0)
#define WALL_BITS(e)		((e) & 0x000f)

/* Bitmaps with graphic file */
#define PIX_BACK		0
#define PIX_DOOR		1
#define PIX_TOONS		2
#define PIX_DF			3
#define	PIX_BIGFONT		4
#define PIX_SMALLFONT		5
#define PIX_MEDIUMFONT		6
/* Bitmaps without graphic file */
#define PIX_DB_DOOR		7

#define NUM_PICTURES		7
#define NUM_BITMAPS		8

/* boundaries of arrays etc. */
#define MAX_PLAYER_NAME_LEN	10
#define MAX_LEVEL_NAME_LEN	32
#define MAX_LEVEL_AUTHOR_LEN	32
#define MAX_SCORE_ENTRIES	100
#define MAX_ELEMENTS		700		/* 500 static + 200 runtime */
#define MAX_NUM_AMOEBA		100
#define MAX_NUM_BEAMERS		8

#define MAX_LASER_LEN		256
#define MAX_LASER_ENERGY	100
#define MAX_LASER_OVERLOAD	100

#define LEVEL_SCORE_ELEMENTS	16	/* level elements with score */

/* fundamental game speed values */
#define GAME_FRAME_DELAY	20	/* frame delay in milliseconds */
#define FFWD_FRAME_DELAY	10	/* 200% speed for fast forward */
#define FRAMES_PER_SECOND	(1000 / GAME_FRAME_DELAY)
#define MICROLEVEL_SCROLL_DELAY	50	/* delay for scrolling micro level */
#define MICROLEVEL_LABEL_DELAY	250	/* delay for micro level label */

struct HiScore
{
  char Name[MAX_PLAYER_NAME_LEN + 1];
  int Score;
};

struct SetupInfo
{
  char *player_name;

  boolean sound;
  boolean sound_loops;
  boolean sound_music;
  boolean sound_simple;
  boolean toons;
  boolean quick_doors;
  boolean handicap;
  boolean time_limit;
  boolean fullscreen;
};

struct PlayerInfo
{
  byte action;			/* action from local input device */

  int jx,jy, last_jx,last_jy;
  int MovDir, MovPos, GfxPos;
  int Frame;

  boolean Pushing;
  boolean Switching;
  boolean LevelSolved, GameOver;
  boolean snapped;

  unsigned long move_delay;
  int move_delay_value;

  int last_move_dir;

  unsigned long push_delay;
  unsigned long push_delay_value;

  int frame_reset_delay;

  unsigned long actual_frame_counter;

  int score;
  int gems_still_needed;
  int sokobanfields_still_needed;
  int lights_still_needed;
  int friends_still_needed;
  int key[4];
  int dynamite;
  int dynabomb_count, dynabomb_size, dynabombs_left, dynabomb_xl;
  int shield_passive_time_left;
  int shield_active_time_left;
};

struct LevelInfo
{
  int file_version;		/* version of file the level was stored with */
  int game_version;		/* version of game engine to play this level */
  boolean encoding_16bit_field;		/* level contains 16-bit elements */

  int fieldx;
  int fieldy;
  int time;
  int kettles_needed;
  boolean auto_count_kettles;
  boolean laser_red, laser_green, laser_blue;
  char name[MAX_LEVEL_NAME_LEN + 1];
  char author[MAX_LEVEL_AUTHOR_LEN + 1];
  int score[LEVEL_SCORE_ELEMENTS];
  int amoeba_speed;
  int time_fuse;
};

struct CycleList
{
  int x, y;
  int steps;
};

struct MovingList
{
  int x, y;
  int dir;
};

struct DamageList
{
  int x, y;
  int edge, angle;
  boolean is_mirror;
};

struct BeamerInfo
{
  int x, y;
  int num;
};

struct PacMan
{
  int XP, YP;
  int Dr;
};

#if 0
struct XY
{
  short x, y;		/* must be "short" to match "XPoint" structure! */
};
#endif

struct GameInfo
{
  struct CycleList cycle[MAX_LEV_FIELDX * MAX_LEV_FIELDY];
  int num_cycle;
  struct MovingList pacman[MAX_LEV_FIELDX * MAX_LEV_FIELDY];
  int num_pacman;

  int score;
  int energy_left;
  int kettles_still_needed;
  int lights_still_needed;
  int num_keys;

  boolean level_solved;
  boolean game_over;
  int game_over_cause;

  boolean cheat_no_overload;
  boolean cheat_no_explosion;
};

struct LaserInfo
{
  struct XY start_edge;
  int start_angle;

  int current_angle;

  /*
  int pixel_x;
  int pixel_y;
  int step_x;
  int step_y;
  int elx;
  int ely;
  */

  struct DamageList damage[MAX_LASER_LEN + 10];
  int num_damages;

  struct XY edge[MAX_LASER_LEN + 10];
  int num_edges;

  struct BeamerInfo beamer[MAX_NUM_BEAMERS][2];
  int beamer_edge[MAX_NUM_BEAMERS];
  int beamer_nr[MAX_NUM_BEAMERS];
  int num_beamers;

  boolean overloaded;
  int overload_value;

  boolean fuse_off;
  int fuse_x, fuse_y;

  int dest_element;
  boolean stops_inside_element;

  boolean redraw;

  int wall_mask;
};

struct EditorInfo
{
  boolean draw_walls_masked;
};

struct PlayerInfo_OLD
{
  char login_name[MAX_PLAYER_NAME_LEN + 1];
  char alias_name[MAX_PLAYER_NAME_LEN + 1];
  boolean last_used;
  int handicap;
  unsigned int setup;
};

struct GlobalInfo
{
  float frames_per_second;
  boolean fps_slowdown;
  int fps_slowdown_factor;
};

extern GC		tile_clip_gc, line_gc[];
extern Bitmap	       *pix[];
extern Pixmap		tile_clipmask[];
extern DrawBuffer     *fieldbuffer;
extern DrawBuffer     *drawto_field;

extern int		joystick_device;
extern char	       *joystick_device_name[];

extern int		game_status;
extern boolean		level_editor_test_game;
extern boolean		network_playing;

extern int		key_joystick_mapping;
extern int	    	global_joystick_status, joystick_status;
extern int		sound_status;
extern boolean		sound_loops_allowed;

extern boolean		redraw[MAX_BUF_XSIZE][MAX_BUF_YSIZE];
extern int		redraw_x1, redraw_y1;

extern short		Feld[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Ur[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Hit[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Box[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Angle[MAX_LEV_FIELDX][MAX_LEV_FIELDY];

extern short		MovPos[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		MovDir[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		MovDelay[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Store[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Store2[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		StorePlayer[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		Frame[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern boolean		Stop[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		JustStopped[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		AmoebaNr[MAX_LEV_FIELDX][MAX_LEV_FIELDY];
extern short		AmoebaCnt[MAX_NUM_AMOEBA], AmoebaCnt2[MAX_NUM_AMOEBA];
extern unsigned long	Elementeigenschaften[MAX_ELEMENTS];

extern int		level_nr;
extern int		lev_fieldx,lev_fieldy, scroll_x,scroll_y;

extern int		FX,FY, ScrollStepSize;
extern int		ScreenMovDir, ScreenMovPos, ScreenGfxPos;
extern int		GameFrameDelay;
extern int		FfwdFrameDelay;
extern int		BX1,BY1, BX2,BY2;
extern int		SBX_Left, SBX_Right;
extern int		SBY_Upper, SBY_Lower;
extern int		ZX,ZY, ExitX,ExitY;
extern int		AllPlayersGone;
extern int		TimeFrames, TimePlayed, TimeLeft;
extern boolean		SiebAktiv;
extern int		SiebCount;

#if 0
extern boolean		network_player_action_received;
#endif

extern struct LevelInfo		level;
#if 0
extern struct PlayerInfo	stored_player[], *local_player;
#endif
extern struct HiScore		highscore[];
extern struct TapeInfo		tape;
extern struct JoystickInfo	joystick[];
extern struct SetupInfo		setup;
extern struct GameInfo		game;
extern struct LaserInfo		laser;
extern struct EditorInfo	editor;
extern struct GlobalInfo	global;

extern short 		LX,LY, XS,YS, ELX,ELY;
extern short 		CT,Ct;

extern Pixel		pen_fg, pen_bg, pen_ray, pen_magicolor[2];
extern int		color_status;

extern struct XY	Step[];
extern short		Sign[16];

extern char		*sound_name[];
extern int		background_loop[];
extern int		num_bg_loops;
extern char		*element_info[];
extern int		num_element_info;

/* often used screen positions */
#define SX			8
#define SY			8
#define REAL_SX			(SX - 2)
#define REAL_SY			(SY - 2)
#define DX			534
#define DY			60
#define EX			DX
#define EY			(DY + 178)
#define TILEX			32
#define TILEY			32
#define MINI_TILEX		(TILEX / 2)
#define MINI_TILEY		(TILEY / 2)
#define MICRO_TILEX		(TILEX / 4)
#define MICRO_TILEY		(TILEY / 4)
#define MICRO_WALLX		(TILEX / 8)
#define MICRO_WALLY		(TILEY / 8)
#define MIDPOSX			(SCR_FIELDX / 2)
#define MIDPOSY			(SCR_FIELDY / 2)
#define SXSIZE			(SCR_FIELDX * TILEX)
#define SYSIZE			(SCR_FIELDY * TILEY)
#define FXSIZE			((SCR_FIELDX + 2) * TILEX)
#define FYSIZE			((SCR_FIELDY + 2) * TILEY)
#define DXSIZE			100
#define DYSIZE			280
#define VXSIZE			DXSIZE
#define VYSIZE			100
#define EXSIZE			DXSIZE
#define EYSIZE			(VXSIZE + 44)
#define FULL_SXSIZE		(2 + SXSIZE + 2)
#define FULL_SYSIZE		(2 + SYSIZE + 2)
#define MICROLEV_XPOS		(SX + 12 * TILEX)
#define MICROLEV_YPOS		(SY +  6 * TILEY)
#define MICROLEV_XSIZE		(STD_LEV_FIELDX * MICRO_TILEX)
#define MICROLEV_YSIZE		(STD_LEV_FIELDY * MICRO_TILEY)
#define MICROLABEL_XPOS		(SY)
#define MICROLABEL_YPOS		(SY + 352)
#define MICROLABEL_XSIZE	(SXSIZE)
#define MICROLABEL_YSIZE	(FONT4_YSIZE)

#define GFX_STARTX		SX
#define GFX_STARTY		SY
#define MINI_GFX_STARTX		(SX + 8 * TILEX)
#define MINI_GFX_STARTY		(SY + 6 * TILEY)
#define MICRO_GFX_STARTX	(MINI_GFX_STARTX + 8 * MINI_TILEX)
#define MICRO_GFX_STARTY	(MINI_GFX_STARTY + 6 * MINI_TILEY)
#define GFX_PER_LINE		16
#define MINI_GFX_PER_LINE	GFX_PER_LINE
#define MICRO_GFX_PER_LINE	GFX_PER_LINE

#define MINI_DF_STARTX		(8 * TILEX)
#define MINI_DF_STARTY		(8 * TILEY)
#define MICRO_DF_STARTX		(MINI_DF_STARTX + 8 * MINI_TILEX)
#define MICRO_DF_STARTY		(MINI_DF_STARTY + 8 * MINI_TILEY)
#define DF_PER_LINE		16
#define MINI_DF_PER_LINE	DF_PER_LINE
#define MICRO_DF_PER_LINE	DF_PER_LINE

#define MICRO_FONT_STARTX	(MICRO_DF_STARTX + 8 * MICRO_TILEX)
#define MICRO_FONT_STARTY	(MICRO_DF_STARTY + 8 * MICRO_TILEY)
#define MICRO_FONT_PER_LINE	8

/* wall positions (that can be OR'ed together) */
#define WALL_TOPLEFT		1
#define WALL_TOPRIGHT		2
#define WALL_BOTTOMLEFT		4
#define WALL_BOTTOMRIGHT	8
#define WALL_LEFT		(WALL_TOPLEFT    | WALL_BOTTOMLEFT)
#define WALL_RIGHT		(WALL_TOPRIGHT   | WALL_BOTTOMRIGHT)
#define WALL_TOP		(WALL_TOPLEFT    | WALL_TOPRIGHT)
#define WALL_BOTTOM		(WALL_BOTTOMLEFT | WALL_BOTTOMRIGHT)

/* game elements:
**	  0 - 499: real elements, stored in level file
**      500 - 699: flag elements, only used at runtime
*/
/* "real" level elements */
#define EL_EMPTY		0
#define EL_MIRROR_START		1
#define EL_MIRROR_00		(EL_MIRROR_START + 0)
#define EL_MIRROR_01		(EL_MIRROR_START + 1)
#define EL_MIRROR_02		(EL_MIRROR_START + 2)
#define EL_MIRROR_03		(EL_MIRROR_START + 3)
#define EL_MIRROR_04		(EL_MIRROR_START + 4)
#define EL_MIRROR_05		(EL_MIRROR_START + 5)
#define EL_MIRROR_06		(EL_MIRROR_START + 6)
#define EL_MIRROR_07		(EL_MIRROR_START + 7)
#define EL_MIRROR_08		(EL_MIRROR_START + 8)
#define EL_MIRROR_09		(EL_MIRROR_START + 9)
#define EL_MIRROR_10		(EL_MIRROR_START + 10)
#define EL_MIRROR_11		(EL_MIRROR_START + 11)
#define EL_MIRROR_12		(EL_MIRROR_START + 12)
#define EL_MIRROR_13		(EL_MIRROR_START + 13)
#define EL_MIRROR_14		(EL_MIRROR_START + 14)
#define EL_MIRROR_15		(EL_MIRROR_START + 15)
#define EL_MIRROR_END		EL_MIRROR_15
#define EL_GRID_STEEL_START	17
#define EL_GRID_STEEL_00	(EL_GRID_STEEL_START + 0)
#define EL_GRID_STEEL_01	(EL_GRID_STEEL_START + 1)
#define EL_GRID_STEEL_02	(EL_GRID_STEEL_START + 2)
#define EL_GRID_STEEL_03	(EL_GRID_STEEL_START + 3)
#define EL_GRID_STEEL_END	EL_GRID_STEEL_03
#define EL_MCDUFFIN_START	21
#define EL_MCDUFFIN_RIGHT	(EL_MCDUFFIN_START + 0)
#define EL_MCDUFFIN_UP		(EL_MCDUFFIN_START + 1)
#define EL_MCDUFFIN_LEFT	(EL_MCDUFFIN_START + 2)
#define EL_MCDUFFIN_DOWN	(EL_MCDUFFIN_START + 3)
#define EL_MCDUFFIN_END		EL_MCDUFFIN_DOWN
#define EL_EXIT_CLOSED		25
#define EL_EXIT_OPENING_1	26
#define EL_EXIT_OPENING_2	27
#define EL_EXIT_OPEN		28
#define EL_KETTLE		29
#define EL_BOMB			30
#define EL_PRISM		31
#define EL_WALL_START		32
#define EL_WALL_EMPTY		EL_WALL_START
#define EL_WALL_00		EL_WALL_START
#define EL_WALL_STEEL		EL_WALL_00
#define EL_WALL_STEEL_START	EL_WALL_00
#define EL_WALL_15		47
#define EL_WALL_STEEL_END	EL_WALL_15
#define EL_WALL_16		48
#define EL_WALL_WOOD		EL_WALL_16
#define EL_WALL_WOOD_START	EL_WALL_16
#define EL_WALL_31		63
#define EL_WALL_WOOD_END	EL_WALL_31
#define EL_WALL_32		64
#define EL_WALL_ICE		EL_WALL_32
#define EL_WALL_ICE_START	EL_WALL_32
#define EL_WALL_47		79
#define EL_WALL_ICE_END		EL_WALL_47
#define EL_WALL_48		80
#define EL_WALL_AMOEBA		EL_WALL_48
#define EL_WALL_AMOEBA_START	EL_WALL_48
#define EL_WALL_63		95
#define EL_WALL_AMOEBA_END	EL_WALL_63
#define EL_WALL_END		EL_WALL_63
#define EL_BLOCK_WOOD		96
#define EL_BALL_GRAY		97
#define EL_BEAMER_START		98
#define EL_BEAMER_00		(EL_BEAMER_START + 0)
#define EL_BEAMER_01		(EL_BEAMER_START + 1)
#define EL_BEAMER_02		(EL_BEAMER_START + 2)
#define EL_BEAMER_03		(EL_BEAMER_START + 3)
#define EL_BEAMER_04		(EL_BEAMER_START + 4)
#define EL_BEAMER_05		(EL_BEAMER_START + 5)
#define EL_BEAMER_06		(EL_BEAMER_START + 6)
#define EL_BEAMER_07		(EL_BEAMER_START + 7)
#define EL_BEAMER_08		(EL_BEAMER_START + 8)
#define EL_BEAMER_09		(EL_BEAMER_START + 9)
#define EL_BEAMER_10		(EL_BEAMER_START + 10)
#define EL_BEAMER_11		(EL_BEAMER_START + 11)
#define EL_BEAMER_12		(EL_BEAMER_START + 12)
#define EL_BEAMER_13		(EL_BEAMER_START + 13)
#define EL_BEAMER_14		(EL_BEAMER_START + 14)
#define EL_BEAMER_15		(EL_BEAMER_START + 15)
#define EL_BEAMER_END		EL_BEAMER_15
#define EL_FUSE_ON		114
#define EL_PACMAN_START		115
#define EL_PACMAN_RIGHT		(EL_PACMAN_START + 0)
#define EL_PACMAN_UP		(EL_PACMAN_START + 1)
#define EL_PACMAN_LEFT		(EL_PACMAN_START + 2)
#define EL_PACMAN_DOWN		(EL_PACMAN_START + 3)
#define EL_PACMAN_END		EL_PACMAN_DOWN
#define EL_POLAR_START		119
#define EL_POLAR_00		(EL_POLAR_START + 0)
#define EL_POLAR_01		(EL_POLAR_START + 1)
#define EL_POLAR_02		(EL_POLAR_START + 2)
#define EL_POLAR_03		(EL_POLAR_START + 3)
#define EL_POLAR_04		(EL_POLAR_START + 4)
#define EL_POLAR_05		(EL_POLAR_START + 5)
#define EL_POLAR_06		(EL_POLAR_START + 6)
#define EL_POLAR_07		(EL_POLAR_START + 7)
#define EL_POLAR_08		(EL_POLAR_START + 8)
#define EL_POLAR_09		(EL_POLAR_START + 9)
#define EL_POLAR_10		(EL_POLAR_START + 10)
#define EL_POLAR_11		(EL_POLAR_START + 11)
#define EL_POLAR_12		(EL_POLAR_START + 12)
#define EL_POLAR_13		(EL_POLAR_START + 13)
#define EL_POLAR_14		(EL_POLAR_START + 14)
#define EL_POLAR_15		(EL_POLAR_START + 15)
#define EL_POLAR_END		EL_POLAR_15
#define EL_POLAR_CROSS_START	135
#define EL_POLAR_CROSS_00	(EL_POLAR_CROSS_START + 0)
#define EL_POLAR_CROSS_01	(EL_POLAR_CROSS_START + 1)
#define EL_POLAR_CROSS_02	(EL_POLAR_CROSS_START + 2)
#define EL_POLAR_CROSS_03	(EL_POLAR_CROSS_START + 3)
#define EL_POLAR_CROSS_END	EL_POLAR_CROSS_03
#define EL_MIRROR_FIXED_START	139
#define EL_MIRROR_FIXED_00	(EL_MIRROR_FIXED_START + 0)
#define EL_MIRROR_FIXED_01	(EL_MIRROR_FIXED_START + 1)
#define EL_MIRROR_FIXED_02	(EL_MIRROR_FIXED_START + 2)
#define EL_MIRROR_FIXED_03	(EL_MIRROR_FIXED_START + 3)
#define EL_MIRROR_FIXED_END	EL_MIRROR_FIXED_03
#define EL_GATE_STONE		143
#define EL_KEY			144
#define EL_LIGHTBULB_OFF	145
#define EL_LIGHTBULB_ON		146
#define EL_LIGHTBALL		147
#define EL_BLOCK_STONE		148
#define EL_GATE_WOOD		149
#define EL_FUEL_FULL		150
#define EL_GRID_WOOD_START	151
#define EL_GRID_WOOD_00		(EL_GRID_WOOD_START + 0)
#define EL_GRID_WOOD_01		(EL_GRID_WOOD_START + 1)
#define EL_GRID_WOOD_02		(EL_GRID_WOOD_START + 2)
#define EL_GRID_WOOD_03		(EL_GRID_WOOD_START + 3)
#define EL_GRID_WOOD_END	EL_GRID_WOOD_03
#define EL_FUEL_EMPTY		155

#define EL_CHAR_START		160
#define EL_CHAR_ASCII0		(EL_CHAR_START-32)
#define EL_CHAR_AUSRUF		(EL_CHAR_ASCII0+33)
#define EL_CHAR_ZOLL		(EL_CHAR_ASCII0+34)
#define EL_CHAR_RAUTE		(EL_CHAR_ASCII0+35)
#define EL_CHAR_DOLLAR		(EL_CHAR_ASCII0+36)
#define EL_CHAR_PROZ		(EL_CHAR_ASCII0+37)
#define EL_CHAR_AMPERSAND	(EL_CHAR_ASCII0+38)
#define EL_CHAR_APOSTR		(EL_CHAR_ASCII0+39)
#define EL_CHAR_KLAMM1		(EL_CHAR_ASCII0+40)
#define EL_CHAR_KLAMM2		(EL_CHAR_ASCII0+41)
#define EL_CHAR_MULT		(EL_CHAR_ASCII0+42)
#define EL_CHAR_PLUS		(EL_CHAR_ASCII0+43)
#define EL_CHAR_KOMMA		(EL_CHAR_ASCII0+44)
#define EL_CHAR_MINUS		(EL_CHAR_ASCII0+45)
#define EL_CHAR_PUNKT		(EL_CHAR_ASCII0+46)
#define EL_CHAR_SLASH		(EL_CHAR_ASCII0+47)
#define EL_CHAR_0		(EL_CHAR_ASCII0+48)
#define EL_CHAR_9		(EL_CHAR_ASCII0+57)
#define EL_CHAR_DOPPEL		(EL_CHAR_ASCII0+58)
#define EL_CHAR_SEMIKL		(EL_CHAR_ASCII0+59)
#define EL_CHAR_LT		(EL_CHAR_ASCII0+60)
#define EL_CHAR_GLEICH		(EL_CHAR_ASCII0+61)
#define EL_CHAR_GT		(EL_CHAR_ASCII0+62)
#define EL_CHAR_FRAGE		(EL_CHAR_ASCII0+63)
#define EL_CHAR_AT		(EL_CHAR_ASCII0+64)
#define EL_CHAR_A		(EL_CHAR_ASCII0+65)
#define EL_CHAR_Z		(EL_CHAR_ASCII0+90)
#define EL_CHAR_AE		(EL_CHAR_ASCII0+91)
#define EL_CHAR_OE		(EL_CHAR_ASCII0+92)
#define EL_CHAR_UE		(EL_CHAR_ASCII0+93)
#define EL_CHAR_COPY		(EL_CHAR_ASCII0+94)
#define EL_CHAR_END		(EL_CHAR_START+79)

#define EL_CHAR(x)		((x) == '�' ? EL_CHAR_AE : \
				 (x) == '�' ? EL_CHAR_OE : \
				 (x) == '�' ? EL_CHAR_UE : \
				 EL_CHAR_A + (x) - 'A')

/* elements for "Deflektor" style levels */
#define EL_DF_START		240

#define EL_DF_MIRROR_START	EL_DF_START
#define EL_DF_MIRROR_00		(EL_DF_MIRROR_START + 0)
#define EL_DF_MIRROR_01		(EL_DF_MIRROR_START + 1)
#define EL_DF_MIRROR_02		(EL_DF_MIRROR_START + 2)
#define EL_DF_MIRROR_03		(EL_DF_MIRROR_START + 3)
#define EL_DF_MIRROR_04		(EL_DF_MIRROR_START + 4)
#define EL_DF_MIRROR_05		(EL_DF_MIRROR_START + 5)
#define EL_DF_MIRROR_06		(EL_DF_MIRROR_START + 6)
#define EL_DF_MIRROR_07		(EL_DF_MIRROR_START + 7)
#define EL_DF_MIRROR_08		(EL_DF_MIRROR_START + 8)
#define EL_DF_MIRROR_09		(EL_DF_MIRROR_START + 9)
#define EL_DF_MIRROR_10		(EL_DF_MIRROR_START + 10)
#define EL_DF_MIRROR_11		(EL_DF_MIRROR_START + 11)
#define EL_DF_MIRROR_12		(EL_DF_MIRROR_START + 12)
#define EL_DF_MIRROR_13		(EL_DF_MIRROR_START + 13)
#define EL_DF_MIRROR_14		(EL_DF_MIRROR_START + 14)
#define EL_DF_MIRROR_15		(EL_DF_MIRROR_START + 15)
#define EL_DF_MIRROR_END	EL_DF_MIRROR_15

#define EL_GRID_WOOD_FIXED_START 256
#define EL_GRID_WOOD_FIXED_00	(EL_GRID_WOOD_FIXED_START + 0)	/*   0.0� */
#define EL_GRID_WOOD_FIXED_01	(EL_GRID_WOOD_FIXED_START + 1)	/*  22.5� */
#define EL_GRID_WOOD_FIXED_02	(EL_GRID_WOOD_FIXED_START + 2)	/*  45.0� */
#define EL_GRID_WOOD_FIXED_03	(EL_GRID_WOOD_FIXED_START + 3)	/*  67.5� */
#define EL_GRID_WOOD_FIXED_04	(EL_GRID_WOOD_FIXED_START + 4)	/*  90.0� */
#define EL_GRID_WOOD_FIXED_05	(EL_GRID_WOOD_FIXED_START + 5)	/* 112.5� */
#define EL_GRID_WOOD_FIXED_06	(EL_GRID_WOOD_FIXED_START + 6)	/* 135.0� */ 
#define EL_GRID_WOOD_FIXED_07	(EL_GRID_WOOD_FIXED_START + 7)	/* 157.5� */
#define EL_GRID_WOOD_FIXED_END	EL_GRID_WOOD_FIXED_07

#define EL_GRID_STEEL_FIXED_START 264
#define EL_GRID_STEEL_FIXED_00	(EL_GRID_STEEL_FIXED_START + 0)	/*   0.0� */
#define EL_GRID_STEEL_FIXED_01	(EL_GRID_STEEL_FIXED_START + 1)	/*  22.5� */
#define EL_GRID_STEEL_FIXED_02	(EL_GRID_STEEL_FIXED_START + 2)	/*  45.0� */
#define EL_GRID_STEEL_FIXED_03	(EL_GRID_STEEL_FIXED_START + 3)	/*  67.5� */
#define EL_GRID_STEEL_FIXED_04	(EL_GRID_STEEL_FIXED_START + 4)	/*  90.0� */
#define EL_GRID_STEEL_FIXED_05	(EL_GRID_STEEL_FIXED_START + 5)	/* 112.5� */
#define EL_GRID_STEEL_FIXED_06	(EL_GRID_STEEL_FIXED_START + 6)	/* 135.0� */
#define EL_GRID_STEEL_FIXED_07	(EL_GRID_STEEL_FIXED_START + 7)	/* 157.5� */
#define EL_GRID_STEEL_FIXED_END	EL_GRID_STEEL_FIXED_07

#define EL_DF_WALL_WOOD		272
#define EL_DF_WALL_START	EL_DF_WALL_WOOD_START
#define EL_DF_WALL_WOOD_START	(EL_DF_WALL_WOOD + 0)
#define EL_DF_WALL_WOOD_END	(EL_DF_WALL_WOOD + 15)

#define EL_DF_WALL_STEEL	288
#define EL_DF_WALL_STEEL_START	(EL_DF_WALL_STEEL + 0)
#define EL_DF_WALL_STEEL_END	(EL_DF_WALL_STEEL + 15)
#define EL_DF_WALL_END		EL_DF_WALL_STEEL_END

#define EL_DF_EMPTY		304
#define EL_CELL			305
#define EL_MINE			306
#define EL_REFRACTOR		307

#define EL_LASER_START		308
#define EL_LASER_RIGHT		(EL_LASER_START + 0)
#define EL_LASER_UP		(EL_LASER_START + 1)
#define EL_LASER_LEFT		(EL_LASER_START + 2)
#define EL_LASER_DOWN		(EL_LASER_START + 3)
#define EL_LASER_END		EL_LASER_DOWN

#define EL_RECEIVER_START	312
#define EL_RECEIVER_RIGHT	(EL_RECEIVER_START + 0)
#define EL_RECEIVER_UP		(EL_RECEIVER_START + 1)
#define EL_RECEIVER_LEFT	(EL_RECEIVER_START + 2)
#define EL_RECEIVER_DOWN	(EL_RECEIVER_START + 3)
#define EL_RECEIVER_END		EL_RECEIVER_DOWN

#define EL_FIBRE_OPTIC_START	316
#define EL_FIBRE_OPTIC_00	(EL_FIBRE_OPTIC_START + 0)
#define EL_FIBRE_OPTIC_01	(EL_FIBRE_OPTIC_START + 1)
#define EL_FIBRE_OPTIC_02	(EL_FIBRE_OPTIC_START + 2)
#define EL_FIBRE_OPTIC_03	(EL_FIBRE_OPTIC_START + 3)
#define EL_FIBRE_OPTIC_04	(EL_FIBRE_OPTIC_START + 4)
#define EL_FIBRE_OPTIC_05	(EL_FIBRE_OPTIC_START + 5)
#define EL_FIBRE_OPTIC_06	(EL_FIBRE_OPTIC_START + 6)
#define EL_FIBRE_OPTIC_07	(EL_FIBRE_OPTIC_START + 7)
#define EL_FIBRE_OPTIC_END	EL_FIBRE_OPTIC_07

#define EL_DF_MIRROR_AUTO_START	324
#define EL_DF_MIRROR_AUTO_00	(EL_DF_MIRROR_AUTO_START + 0)
#define EL_DF_MIRROR_AUTO_01	(EL_DF_MIRROR_AUTO_START + 1)
#define EL_DF_MIRROR_AUTO_02	(EL_DF_MIRROR_AUTO_START + 2)
#define EL_DF_MIRROR_AUTO_03	(EL_DF_MIRROR_AUTO_START + 3)
#define EL_DF_MIRROR_AUTO_04	(EL_DF_MIRROR_AUTO_START + 4)
#define EL_DF_MIRROR_AUTO_05	(EL_DF_MIRROR_AUTO_START + 5)
#define EL_DF_MIRROR_AUTO_06	(EL_DF_MIRROR_AUTO_START + 6)
#define EL_DF_MIRROR_AUTO_07	(EL_DF_MIRROR_AUTO_START + 7)
#define EL_DF_MIRROR_AUTO_08	(EL_DF_MIRROR_AUTO_START + 8)
#define EL_DF_MIRROR_AUTO_09	(EL_DF_MIRROR_AUTO_START + 9)
#define EL_DF_MIRROR_AUTO_10	(EL_DF_MIRROR_AUTO_START + 10)
#define EL_DF_MIRROR_AUTO_11	(EL_DF_MIRROR_AUTO_START + 11)
#define EL_DF_MIRROR_AUTO_12	(EL_DF_MIRROR_AUTO_START + 12)
#define EL_DF_MIRROR_AUTO_13	(EL_DF_MIRROR_AUTO_START + 13)
#define EL_DF_MIRROR_AUTO_14	(EL_DF_MIRROR_AUTO_START + 14)
#define EL_DF_MIRROR_AUTO_15	(EL_DF_MIRROR_AUTO_START + 15)
#define EL_DF_MIRROR_AUTO_END	EL_DF_MIRROR_AUTO_15

#define EL_GRID_WOOD_AUTO_START 340
#define EL_GRID_WOOD_AUTO_00	(EL_GRID_WOOD_AUTO_START + 0)
#define EL_GRID_WOOD_AUTO_01	(EL_GRID_WOOD_AUTO_START + 1)
#define EL_GRID_WOOD_AUTO_02	(EL_GRID_WOOD_AUTO_START + 2)
#define EL_GRID_WOOD_AUTO_03	(EL_GRID_WOOD_AUTO_START + 3)
#define EL_GRID_WOOD_AUTO_04	(EL_GRID_WOOD_AUTO_START + 4)
#define EL_GRID_WOOD_AUTO_05	(EL_GRID_WOOD_AUTO_START + 5)
#define EL_GRID_WOOD_AUTO_06	(EL_GRID_WOOD_AUTO_START + 6)
#define EL_GRID_WOOD_AUTO_07	(EL_GRID_WOOD_AUTO_START + 7)
#define EL_GRID_WOOD_AUTO_END	EL_GRID_WOOD_AUTO_07

#define EL_GRID_STEEL_AUTO_START 348
#define EL_GRID_STEEL_AUTO_00	(EL_GRID_STEEL_AUTO_START + 0)
#define EL_GRID_STEEL_AUTO_01	(EL_GRID_STEEL_AUTO_START + 1)
#define EL_GRID_STEEL_AUTO_02	(EL_GRID_STEEL_AUTO_START + 2)
#define EL_GRID_STEEL_AUTO_03	(EL_GRID_STEEL_AUTO_START + 3)
#define EL_GRID_STEEL_AUTO_04	(EL_GRID_STEEL_AUTO_START + 4)
#define EL_GRID_STEEL_AUTO_05	(EL_GRID_STEEL_AUTO_START + 5)
#define EL_GRID_STEEL_AUTO_06	(EL_GRID_STEEL_AUTO_START + 6)
#define EL_GRID_STEEL_AUTO_07	(EL_GRID_STEEL_AUTO_START + 7)
#define EL_GRID_STEEL_AUTO_END	EL_GRID_STEEL_AUTO_07

#define EL_DF_END		355

#define EL_BEAMER_RED_START	356
#define EL_BEAMER_RED_END	(EL_BEAMER_RED_START + 15)
#define EL_BEAMER_YELLOW_START	372
#define EL_BEAMER_YELLOW_END	(EL_BEAMER_YELLOW_START + 15)
#define EL_BEAMER_GREEN_START	388
#define EL_BEAMER_GREEN_END	(EL_BEAMER_GREEN_START + 15)
#define EL_BEAMER_BLUE_START	404
#define EL_BEAMER_BLUE_END	(EL_BEAMER_BLUE_START + 15)

/* "real" (and therefore drawable) runtime elements */
#define EL_FIRST_RUNTIME_EL	500
#define EL_FUSE_OFF		501
#define EL_PACMAN		502
#define EL_EXIT_OPENING		503
#define EL_GRAY_BALL_OPENING	504

#define EL_WALL_CHANGING	512
#define EL_WALL_CHANGING_START	(EL_WALL_CHANGING + 0)
#define EL_WALL_CHANGING_END	(EL_WALL_CHANGING + 15)

#if 0
#define EL_MIRROR		5
#define EL_GRID_STEEL		5
#define EL_MCDUFFIN		5
#define EL_BEAMER		5
#define EL_POLAR		5
#define EL_POLAR_CROSS		5
#define EL_MIRROR_FIXED		5
#define EL_GRID_WOOD		5
#define EL_DF_MIRROR		5
#define EL_GRID_WOOD_FIXED	5
#define EL_GRID_STEEL_FIXED	5
#define EL_LASER		5
#define EL_RECEIVER		5
#define EL_FIBRE_OPTIC		5
#define EL_DF_MIRROR_AUTO	5
#define EL_GRID_WOOD_AUTO	5
#define EL_GRID_STEEL_AUTO	5
#endif

/* "unreal" (and therefore not drawable) runtime elements */
#define EL_BLOCKED		600
#define EL_EXPLODING_OPAQUE	601
#define EL_EXPLODING_TRANSP	602


/* game graphics:
**	  0 -  191: graphics from "MirrorScreen"
**	192 -  255: pseudo graphics mapped to "MirrorScreen"
**	256 -  511: graphics from "MirrorFont"
**	512 -  767: graphics from "MirrorDF"
*/

#define GFX_START_MIRRORSCREEN	0
#define GFX_END_MIRRORSCREEN	191
#define GFX_START_PSEUDO	192
#define GFX_END_PSEUDO		255
#define GFX_START_MIRRORFONT	256
#define GFX_END_MIRRORFONT	511
#define GFX_START_MIRRORDF	512
#define GFX_END_MIRRORDF	767

#define NUM_TILES		512

/* graphics from "MirrorScreen" */
#define GFX_EMPTY		(-1)
/* row 0 (0) */
#define GFX_MIRROR_START	0
#define GFX_MIRROR		GFX_MIRROR_START
#define GFX_MIRROR_00		(GFX_MIRROR_START + 0)
#define GFX_MIRROR_01		(GFX_MIRROR_START + 1)
#define GFX_MIRROR_02		(GFX_MIRROR_START + 2)
#define GFX_MIRROR_03		(GFX_MIRROR_START + 3)
#define GFX_MIRROR_04		(GFX_MIRROR_START + 4)
#define GFX_MIRROR_05		(GFX_MIRROR_START + 5)
#define GFX_MIRROR_06		(GFX_MIRROR_START + 6)
#define GFX_MIRROR_07		(GFX_MIRROR_START + 7)
#define GFX_MIRROR_08		(GFX_MIRROR_START + 8)
#define GFX_MIRROR_09		(GFX_MIRROR_START + 9)
#define GFX_MIRROR_10		(GFX_MIRROR_START + 10)
#define GFX_MIRROR_11		(GFX_MIRROR_START + 11)
#define GFX_MIRROR_12		(GFX_MIRROR_START + 12)
#define GFX_MIRROR_13		(GFX_MIRROR_START + 13)
#define GFX_MIRROR_14		(GFX_MIRROR_START + 14)
#define GFX_MIRROR_15		(GFX_MIRROR_START + 15)
#define GFX_MIRROR_END		GFX_MIRROR_15
/* row 1 (16) */
#define GFX_GRID_STEEL_START	16
#define GFX_GRID_STEEL		GFX_GRID_STEEL_START
#define GFX_GRID_STEEL_00	(GFX_GRID_STEEL_START + 0)
#define GFX_GRID_STEEL_01	(GFX_GRID_STEEL_START + 1)
#define GFX_GRID_STEEL_02	(GFX_GRID_STEEL_START + 2)
#define GFX_GRID_STEEL_03	(GFX_GRID_STEEL_START + 3)
#define GFX_MCDUFFIN_START	20
#define GFX_MCDUFFIN		GFX_MCDUFFIN_START
#define GFX_MCDUFFIN_RIGHT	(GFX_MCDUFFIN_START + 0)
#define GFX_MCDUFFIN_UP		(GFX_MCDUFFIN_START + 1)
#define GFX_MCDUFFIN_LEFT	(GFX_MCDUFFIN_START + 2)
#define GFX_MCDUFFIN_DOWN	(GFX_MCDUFFIN_START + 3)
#define GFX_EXIT_CLOSED		24
#define GFX_EXIT_OPENING_1	25
#define GFX_EXIT_OPENING_2	26
#define GFX_EXIT_OPEN		27
#define GFX_KETTLE		28
#define GFX_EXPLOSION_KETTLE	29
/* row 2 (32) */
#define GFX_PRISM		32
#define GFX_WALL_SEVERAL	33
#define GFX_WALL_ANIMATION	34
#define GFX_BLOCK_WOOD		36
#define GFX_BOMB		37
#define GFX_FUSE_ON		38
#define GFX_FUSE_OFF		39
#define GFX_GATE_STONE		40
#define GFX_KEY			41
#define GFX_LIGHTBULB_OFF	42
#define GFX_LIGHTBULB_ON	43
#define GFX_BALL_RED		44
#define GFX_BALL_BLUE		45
#define GFX_BALL_YELLOW		46
#define GFX_BALL_GRAY		47
/* row 3 (48) */
#define GFX_BEAMER_START	48
#define GFX_BEAMER_END		63
/* row 4 (64) */
#define GFX_PACMAN_START	64
#define GFX_PACMAN		GFX_PACMAN_START
#define GFX_PACMAN_RIGHT	(GFX_PACMAN_START + 0)
#define GFX_PACMAN_UP		(GFX_PACMAN_START + 1)
#define GFX_PACMAN_LEFT		(GFX_PACMAN_START + 2)
#define GFX_PACMAN_DOWN		(GFX_PACMAN_START + 3)
#define GFX_EXPLOSION_START	72
#define GFX_EXPLOSION_SHORT	76
#define GFX_EXPLOSION_LAST	78
/* row 5 (80) */
#define GFX_POLAR_START		80
#define GFX_POLAR_END		95
/* row 6 (96) */
#define GFX_POLAR_CROSS_START	96
#define GFX_POLAR_CROSS		GFX_POLAR_CROSS_START
#define GFX_POLAR_CROSS_00	(GFX_POLAR_CROSS_START + 0)
#define GFX_POLAR_CROSS_01	(GFX_POLAR_CROSS_START + 1)
#define GFX_POLAR_CROSS_02	(GFX_POLAR_CROSS_START + 2)
#define GFX_POLAR_CROSS_03	(GFX_POLAR_CROSS_START + 3)
#define GFX_MIRROR_FIXED_START	100
#define GFX_MIRROR_FIXED	GFX_MIRROR_FIXED_START
#define GFX_MIRROR_FIXED_00	(GFX_MIRROR_FIXED_START + 0)
#define GFX_MIRROR_FIXED_01	(GFX_MIRROR_FIXED_START + 1)
#define GFX_MIRROR_FIXED_02	(GFX_MIRROR_FIXED_START + 2)
#define GFX_MIRROR_FIXED_03	(GFX_MIRROR_FIXED_START + 3)
/* row 7 (112) */
#define GFX_BLOCK_STONE		112
#define GFX_GATE_WOOD		113
#define GFX_FUEL_FULL		114
#define GFX_FUEL_EMPTY		115
#define GFX_GRID_WOOD_00	116
#define GFX_GRID_WOOD_01	117
#define GFX_GRID_WOOD_02	118
#define GFX_GRID_WOOD_03	119
/* row 8 (128) */
#define GFX_ARROW_BLUE_LEFT	128
#define GFX_ARROW_BLUE_RIGHT	129
#define GFX_ARROW_BLUE_UP	130
#define GFX_ARROW_BLUE_DOWN	131
#define GFX_ARROW_RED_LEFT	132
#define GFX_ARROW_RED_RIGHT	133
#define GFX_ARROW_RED_UP	134
#define GFX_ARROW_RED_DOWN	135
/* row 9 (144) */
#define GFX_SCROLLBAR_BLUE	144
#define GFX_SCROLLBAR_RED	145
/* row 10 (160) */
#define GFX_MASK_CIRCLE		160
#define GFX_MASK_RECTANGLE	161
#define GFX_MASK_RECTANGLE2	162
#define GFX_MASK_RECTANGLE3	163
#define GFX_MASK_GRID_00	164
#define GFX_MASK_GRID_01	165
#define GFX_MASK_GRID_02	166
#define GFX_MASK_GRID_03	167
/* row 11 (176) */
#define GFX_MASK_MCDUFFIN_00	176
#define GFX_MASK_MCDUFFIN_01	177
#define GFX_MASK_MCDUFFIN_02	178
#define GFX_MASK_MCDUFFIN_03	179

/* pseudo-graphics; will be mapped to other graphics */
#define GFX_WALL_STEEL		192
#define GFX_WALL_WOOD		193
#define GFX_WALL_ICE		194
#define GFX_WALL_AMOEBA		195
#define GFX_DF_WALL_STEEL	196
#define GFX_DF_WALL_WOOD	197

#define GFX_KUGEL_ROT		GFX_BALL_RED
#define GFX_KUGEL_BLAU		GFX_BALL_BLUE
#define GFX_KUGEL_GELB		GFX_BALL_YELLOW
#define GFX_KUGEL_GRAU		GFX_BALL_GRAY

/* graphics from "MirrorFont" */
#define GFX_CHAR_START		(GFX_START_MIRRORFONT)
#define GFX_CHAR_ASCII0		(GFX_CHAR_START - 32)
#define GFX_CHAR_AUSRUF		(GFX_CHAR_ASCII0 + 33)
#define GFX_CHAR_ZOLL		(GFX_CHAR_ASCII0 + 34)
#define GFX_CHAR_DOLLAR		(GFX_CHAR_ASCII0 + 36)
#define GFX_CHAR_PROZ		(GFX_CHAR_ASCII0 + 37)
#define GFX_CHAR_APOSTR		(GFX_CHAR_ASCII0 + 39)
#define GFX_CHAR_KLAMM1		(GFX_CHAR_ASCII0 + 40)
#define GFX_CHAR_KLAMM2		(GFX_CHAR_ASCII0 + 41)
#define GFX_CHAR_PLUS		(GFX_CHAR_ASCII0 + 43)
#define GFX_CHAR_KOMMA		(GFX_CHAR_ASCII0 + 44)
#define GFX_CHAR_MINUS		(GFX_CHAR_ASCII0 + 45)
#define GFX_CHAR_PUNKT		(GFX_CHAR_ASCII0 + 46)
#define GFX_CHAR_SLASH		(GFX_CHAR_ASCII0 + 47)
#define GFX_CHAR_0		(GFX_CHAR_ASCII0 + 48)
#define GFX_CHAR_9		(GFX_CHAR_ASCII0 + 57)
#define GFX_CHAR_DOPPEL		(GFX_CHAR_ASCII0 + 58)
#define GFX_CHAR_SEMIKL		(GFX_CHAR_ASCII0 + 59)
#define GFX_CHAR_LT		(GFX_CHAR_ASCII0 + 60)
#define GFX_CHAR_GLEICH		(GFX_CHAR_ASCII0 + 61)
#define GFX_CHAR_GT		(GFX_CHAR_ASCII0 + 62)
#define GFX_CHAR_FRAGE		(GFX_CHAR_ASCII0 + 63)
#define GFX_CHAR_AT		(GFX_CHAR_ASCII0 + 64)
#define GFX_CHAR_A		(GFX_CHAR_ASCII0 + 65)
#define GFX_CHAR_Z		(GFX_CHAR_ASCII0 + 90)
#define GFX_CHAR_AE		(GFX_CHAR_ASCII0 + 91)
#define GFX_CHAR_OE		(GFX_CHAR_ASCII0 + 92)
#define GFX_CHAR_UE		(GFX_CHAR_ASCII0 + 93)
#define GFX_CHAR_COPY		(GFX_CHAR_ASCII0 + 94)
#define GFX_CHAR_END		(GFX_CHAR_START + 79)

/* graphics from "MirrorDF" */
#define GFX_DF_MIRROR_00	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  0)
#define GFX_DF_MIRROR_01	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  1)
#define GFX_DF_MIRROR_02	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  2)
#define GFX_DF_MIRROR_03	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  3)
#define GFX_DF_MIRROR_04	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  4)
#define GFX_DF_MIRROR_05	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  5)
#define GFX_DF_MIRROR_06	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  6)
#define GFX_DF_MIRROR_07	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  7)
#define GFX_DF_MIRROR_08	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  8)
#define GFX_DF_MIRROR_09	(GFX_START_MIRRORDF +  0 * DF_PER_LINE +  9)
#define GFX_DF_MIRROR_10	(GFX_START_MIRRORDF +  0 * DF_PER_LINE + 10)
#define GFX_DF_MIRROR_11	(GFX_START_MIRRORDF +  0 * DF_PER_LINE + 11)
#define GFX_DF_MIRROR_12	(GFX_START_MIRRORDF +  0 * DF_PER_LINE + 12)
#define GFX_DF_MIRROR_13	(GFX_START_MIRRORDF +  0 * DF_PER_LINE + 13)
#define GFX_DF_MIRROR_14	(GFX_START_MIRRORDF +  0 * DF_PER_LINE + 14)
#define GFX_DF_MIRROR_15	(GFX_START_MIRRORDF +  0 * DF_PER_LINE + 15)

#define GFX_DF_MIRROR_AUTO_00	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  0)
#define GFX_DF_MIRROR_AUTO_01	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  1)
#define GFX_DF_MIRROR_AUTO_02	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  2)
#define GFX_DF_MIRROR_AUTO_03	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  3)
#define GFX_DF_MIRROR_AUTO_04	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  4)
#define GFX_DF_MIRROR_AUTO_05	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  5)
#define GFX_DF_MIRROR_AUTO_06	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  6)
#define GFX_DF_MIRROR_AUTO_07	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  7)
#define GFX_DF_MIRROR_AUTO_08	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  8)
#define GFX_DF_MIRROR_AUTO_09	(GFX_START_MIRRORDF +  1 * DF_PER_LINE +  9)
#define GFX_DF_MIRROR_AUTO_10	(GFX_START_MIRRORDF +  1 * DF_PER_LINE + 10)
#define GFX_DF_MIRROR_AUTO_11	(GFX_START_MIRRORDF +  1 * DF_PER_LINE + 11)
#define GFX_DF_MIRROR_AUTO_12	(GFX_START_MIRRORDF +  1 * DF_PER_LINE + 12)
#define GFX_DF_MIRROR_AUTO_13	(GFX_START_MIRRORDF +  1 * DF_PER_LINE + 13)
#define GFX_DF_MIRROR_AUTO_14	(GFX_START_MIRRORDF +  1 * DF_PER_LINE + 14)
#define GFX_DF_MIRROR_AUTO_15	(GFX_START_MIRRORDF +  1 * DF_PER_LINE + 15)

#define GFX_GRID_STEEL_FIXED_00	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  0)
#define GFX_GRID_STEEL_FIXED_01	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  1)
#define GFX_GRID_STEEL_FIXED_02	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  2)
#define GFX_GRID_STEEL_FIXED_03	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  3)
#define GFX_GRID_STEEL_FIXED_04	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  4)
#define GFX_GRID_STEEL_FIXED_05	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  5)
#define GFX_GRID_STEEL_FIXED_06	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  6)
#define GFX_GRID_STEEL_FIXED_07	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  7)
#define GFX_GRID_STEEL_FIXED	GFX_GRID_STEEL_FIXED_00

#define GFX_GRID_WOOD_FIXED_00	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  8)
#define GFX_GRID_WOOD_FIXED_01	(GFX_START_MIRRORDF +  2 * DF_PER_LINE +  9)
#define GFX_GRID_WOOD_FIXED_02	(GFX_START_MIRRORDF +  2 * DF_PER_LINE + 10)
#define GFX_GRID_WOOD_FIXED_03	(GFX_START_MIRRORDF +  2 * DF_PER_LINE + 11)
#define GFX_GRID_WOOD_FIXED_04	(GFX_START_MIRRORDF +  2 * DF_PER_LINE + 12)
#define GFX_GRID_WOOD_FIXED_05	(GFX_START_MIRRORDF +  2 * DF_PER_LINE + 13)
#define GFX_GRID_WOOD_FIXED_06	(GFX_START_MIRRORDF +  2 * DF_PER_LINE + 14)
#define GFX_GRID_WOOD_FIXED_07	(GFX_START_MIRRORDF +  2 * DF_PER_LINE + 15)
#define GFX_GRID_WOOD_FIXED	GFX_GRID_WOOD_FIXED_00

#define GFX_GRID_STEEL_AUTO_00	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  0)
#define GFX_GRID_STEEL_AUTO_01	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  1)
#define GFX_GRID_STEEL_AUTO_02	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  2)
#define GFX_GRID_STEEL_AUTO_03	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  3)
#define GFX_GRID_STEEL_AUTO_04	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  4)
#define GFX_GRID_STEEL_AUTO_05	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  5)
#define GFX_GRID_STEEL_AUTO_06	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  6)
#define GFX_GRID_STEEL_AUTO_07	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  7)
#define GFX_GRID_STEEL_AUTO	GFX_GRID_STEEL_AUTO_00

#define GFX_GRID_WOOD_AUTO_00	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  8)
#define GFX_GRID_WOOD_AUTO_01	(GFX_START_MIRRORDF +  3 * DF_PER_LINE +  9)
#define GFX_GRID_WOOD_AUTO_02	(GFX_START_MIRRORDF +  3 * DF_PER_LINE + 10)
#define GFX_GRID_WOOD_AUTO_03	(GFX_START_MIRRORDF +  3 * DF_PER_LINE + 11)
#define GFX_GRID_WOOD_AUTO_04	(GFX_START_MIRRORDF +  3 * DF_PER_LINE + 12)
#define GFX_GRID_WOOD_AUTO_05	(GFX_START_MIRRORDF +  3 * DF_PER_LINE + 13)
#define GFX_GRID_WOOD_AUTO_06	(GFX_START_MIRRORDF +  3 * DF_PER_LINE + 14)
#define GFX_GRID_WOOD_AUTO_07	(GFX_START_MIRRORDF +  3 * DF_PER_LINE + 15)
#define GFX_GRID_WOOD_AUTO	GFX_GRID_WOOD_AUTO_00

#define GFX_BEAMER_RED_START	(GFX_START_MIRRORDF +  4 * DF_PER_LINE +  0)
#define GFX_BEAMER_RED_END	(GFX_START_MIRRORDF +  4 * DF_PER_LINE + 15)
#define GFX_BEAMER_YELLOW_START	(GFX_START_MIRRORDF +  5 * DF_PER_LINE +  0)
#define GFX_BEAMER_YELLOW_END	(GFX_START_MIRRORDF +  5 * DF_PER_LINE + 15)
#define GFX_BEAMER_GREEN_START	(GFX_START_MIRRORDF +  6 * DF_PER_LINE +  0)
#define GFX_BEAMER_GREEN_END	(GFX_START_MIRRORDF +  6 * DF_PER_LINE + 15)
#define GFX_BEAMER_BLUE_START	(GFX_START_MIRRORDF +  7 * DF_PER_LINE +  0)
#define GFX_BEAMER_BLUE_END	(GFX_START_MIRRORDF +  7 * DF_PER_LINE + 15)

#define GFX_DF_WALL_SEVERAL	(GFX_START_MIRRORDF +  8 * DF_PER_LINE +  0)
#define GFX_REFRACTOR		(GFX_START_MIRRORDF +  8 * DF_PER_LINE +  1)
#define GFX_CELL		(GFX_START_MIRRORDF +  8 * DF_PER_LINE +  2)
#define GFX_MINE		(GFX_START_MIRRORDF +  8 * DF_PER_LINE +  4)

#define GFX_LASER_RIGHT		(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  0)
#define GFX_LASER_UP		(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  1)
#define GFX_LASER_LEFT		(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  2)
#define GFX_LASER_DOWN		(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  3)
#define GFX_RECEIVER_RIGHT	(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  4)
#define GFX_RECEIVER_UP		(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  5)
#define GFX_RECEIVER_LEFT	(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  6)
#define GFX_RECEIVER_DOWN	(GFX_START_MIRRORDF +  9 * DF_PER_LINE +  7)

#define GFX_FIBRE_OPTIC_00	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  0)
#define GFX_FIBRE_OPTIC_01	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  1)
#define GFX_FIBRE_OPTIC_02	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  2)
#define GFX_FIBRE_OPTIC_03	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  3)
#define GFX_FIBRE_OPTIC_04	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  4)
#define GFX_FIBRE_OPTIC_05	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  5)
#define GFX_FIBRE_OPTIC_06	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  6)
#define GFX_FIBRE_OPTIC_07	(GFX_START_MIRRORDF + 10 * DF_PER_LINE +  7)

#define GFX_FIBRE_OPTIC_ED_00	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  0)
#define GFX_FIBRE_OPTIC_ED_01	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  1)
#define GFX_FIBRE_OPTIC_ED_02	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  2)
#define GFX_FIBRE_OPTIC_ED_03	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  3)
#define GFX_FIBRE_OPTIC_ED_04	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  4)
#define GFX_FIBRE_OPTIC_ED_05	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  5)
#define GFX_FIBRE_OPTIC_ED_06	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  6)
#define GFX_FIBRE_OPTIC_ED_07	(GFX_START_MIRRORDF + 11 * DF_PER_LINE +  7)

/* the names of the sounds */
#define SND_AMOEBE		0
#define SND_ANTIGRAV		1
#define SND_AUTSCH		2
#define SND_BONG		3
#define SND_FUEL		4
#define SND_HALLOFFAME		5
#define SND_HOLZ		6
#define SND_HUI			7
#define SND_KABUMM		8
#define SND_KINK		9
#define SND_KLING		10
#define SND_LASER		11
#define SND_OEFFNEN		12
#define SND_QUIEK		13
#define SND_RHYTHMLOOP		14
#define SND_ROAAAR		15
#define SND_SIRR		16
#define SND_SLURP		17
#define SND_WARNTON		18
#define SND_WHOOSH		19

#define NUM_SOUNDS		20

/* default input keys */
#define DEFAULT_KEY_LEFT	KSYM_Left
#define DEFAULT_KEY_RIGHT	KSYM_Right
#define DEFAULT_KEY_UP		KSYM_Up
#define DEFAULT_KEY_DOWN	KSYM_Down
#define DEFAULT_KEY_SNAP	KSYM_Shift_L
#define DEFAULT_KEY_BOMB	KSYM_Shift_R
#define DEFAULT_KEY_OKAY	KSYM_Return
#define DEFAULT_KEY_CANCEL	KSYM_Escape

/* directions for moving */
#define MV_NO_MOVING		0
#define MV_LEFT			(1 << 0)
#define MV_RIGHT		(1 << 1)
#define MV_UP			(1 << 2)
#define MV_DOWN	       		(1 << 3)

/* laser angles (directions) */
#define ANG_RAY_RIGHT		0
#define ANG_RAY_UP		4
#define ANG_RAY_LEFT		8
#define ANG_RAY_DOWN		12

/* laser angles (degree) */
#define ANG_RAY_0		0
#define ANG_RAY_90		4
#define ANG_RAY_180		8
#define ANG_RAY_270		12
#define IS_22_5_ANGLE(angle)	((angle) % 2)
#define IS_90_ANGLE(angle)	(!((angle) % 4))
#define IS_HORIZ_ANGLE(angle)	(!((angle) % 8))
#define IS_VERT_ANGLE(angle)	((angle) % 8)

/* mirror angles */
#define ANG_MIRROR_0		0
#define ANG_MIRROR_45		4
#define ANG_MIRROR_90		8
#define ANG_MIRROR_135		12

/* positions for checking where laser already hits element */
#define HIT_POS_CENTER		1
#define HIT_POS_EDGE		2
#define HIT_POS_BETWEEN		4

/* masks for scanning elements */
#define HIT_MASK_NO_HIT		0
#define HIT_MASK_TOPLEFT	1
#define HIT_MASK_TOPRIGHT	2
#define HIT_MASK_BOTTOMLEFT	4
#define HIT_MASK_BOTTOMRIGHT	8
#define HIT_MASK_LEFT		(HIT_MASK_TOPLEFT | HIT_MASK_BOTTOMLEFT)
#define HIT_MASK_RIGHT		(HIT_MASK_TOPRIGHT | HIT_MASK_BOTTOMRIGHT)
#define HIT_MASK_TOP		(HIT_MASK_TOPLEFT | HIT_MASK_TOPRIGHT)
#define HIT_MASK_BOTTOM		(HIT_MASK_BOTTOMLEFT | HIT_MASK_BOTTOMRIGHT)
#define HIT_MASK_ALL		(HIT_MASK_LEFT | HIT_MASK_RIGHT)

/* step values for rotating elements */
#define ROTATE_NO_ROTATING	0
#define ROTATE_LEFT		(+1)
#define ROTATE_RIGHT		(-1)
#define BUTTON_ROTATION(button)	((button) == MB_LEFTBUTTON  ? ROTATE_LEFT :  \
				 (button) == MB_RIGHTBUTTON ? ROTATE_RIGHT : \
	 			 ROTATE_NO_ROTATING)

/* game over values */
#define GAME_OVER_NO_ENERGY	1
#define GAME_OVER_OVERLOADED	2
#define GAME_OVER_BOMB		3

/* values for joystick directions and buttons */
#define JOY_LEFT                MV_LEFT
#define JOY_RIGHT               MV_RIGHT
#define JOY_UP                  MV_UP
#define JOY_DOWN                MV_DOWN
#define JOY_BUTTON_1            (1 << 4)
#define JOY_BUTTON_2            (1 << 5)
#define JOY_BUTTON              (JOY_BUTTON_1 | JOY_BUTTON_2)

/* values for game_status */
#define EXITGAME		0
#define MAINMENU		1
#define PLAYING			2
#define LEVELED			3
#define HELPSCREEN		4
#define CHOOSELEVEL		5
#define TYPENAME		6
#define HALLOFFAME		7
#define SETUP			8

/* return values for GameActions */
#define ACT_GO_ON	0
#define ACT_GAME_OVER	1
#define ACT_NEW_GAME	2

/* values for color_status */
#define STATIC_COLORS   0
#define DYNAMIC_COLORS  1

#define PROGRAM_VERSION_MAJOR	2
#define PROGRAM_VERSION_MINOR	0
#define PROGRAM_VERSION_PATCH	2
#define PROGRAM_VERSION_STRING	"2.0.2"

#define PROGRAM_TITLE_STRING	"Mirror Magic II"
#define PROGRAM_AUTHOR_STRING	"Holger Schemel"
#define PROGRAM_RIGHTS_STRING	"Copyright ^1994-2001"
#define PROGRAM_DOS_PORT_STRING	"DOS port based on code by Guido Schulz"
#define PROGRAM_IDENT_STRING	PROGRAM_VERSION_STRING " " TARGET_STRING
#define WINDOW_TITLE_STRING	PROGRAM_TITLE_STRING " " PROGRAM_IDENT_STRING
#define WINDOW_SUBTITLE_STRING	PROGRAM_RIGHTS_STRING " " PROGRAM_AUTHOR_STRING
#define ICON_TITLE_STRING	PROGRAM_TITLE_STRING
#define UNIX_USERDATA_DIRECTORY	".mirrormagic"

#define X11_ICON_FILENAME	"mirrormagic_icon.xbm"
#define X11_ICONMASK_FILENAME	"mirrormagic_iconmask.xbm"
#define MSDOS_POINTER_FILENAME	"mouse.pcx"

/* file version numbers for resource files (levels, score, setup, etc.)
** currently supported/known file version numbers:
**	1.4 (still in use)
**	2.0 (actual)
*/
#define FILE_VERSION_1_4	VERSION_IDENT(1,4,0)
#define FILE_VERSION_2_0	VERSION_IDENT(2,0,0)

/* file version does not change for every program version, but is changed
   when new features are introduced that are incompatible with older file
   versions, so that they can be treated accordingly */
#define FILE_VERSION_ACTUAL	FILE_VERSION_2_0

#define GAME_VERSION_ACTUAL	VERSION_IDENT(PROGRAM_VERSION_MAJOR, \
					      PROGRAM_VERSION_MINOR, \
					      PROGRAM_VERSION_PATCH)

/* for DrawGraphicAnimation() [tools.c] and AnimateToon() [cartoons.c] */
#define ANIM_NORMAL		0
#define ANIM_OSCILLATE		1
#define ANIM_REVERSE		2

/* sound control */

#define ST(x)           (((x)-8)*16)

#endif	/* MAIN_H */
