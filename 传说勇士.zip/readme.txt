      -----------------
                                W A R R I O R S
                                      of
                                  L E G E N D
                               -----------------

                              (Complete Solve 1.1)
                                      by

                              Nicolas L. Clement
                                   (c) 2002

***********************
*    AUTHOR NOTE      *
***********************

Hello people :) This is my first attempt to write a faq for a game. Thus I 
hope it will be entertaining and fruitful enough for you to complete this old
1993 game released by Virgin and Synergistic.

Why write a faq for an old 1993 game that barely nobody ever heard of, you may
wonder? Well, most probably because there ARE some people out there that still
enjoy oldies classics from the '90s (such as me). While "Warriors of Legend"
may not be the greatest among classics, if you are a fan of Conan-esque RPGs,
this might appeal to you.

On with the show!



***********************
*    INTRODUCTION     *
***********************

Warriors of Legend is set in the world of Conan the Barbarian (or if not.. 
it's pretty darn close). This would make plenty of sense tho since Synergistic 
released another game called Conan the Cimmerian a year before.

Thus what is presented here is a world of thievery, merchants, big hairy 
barbarians, exotic magic and obviously the evil God-Entity known as Set 
the serpent God.

The action takes place in the land of Lemuria who is recently taken aback from 
evil sorcerers of Lortai who came a few years ago from the great desert. Now 
greedy for power, these dark evil-doers corrupted and killed many of the 
rulers of the land, often taking their place... Turning the world into Chaos 
and Evilness... (how clich��)...

But ? King Osiric the Great is but the only one ruler not to fall upon the 
trap of the evil sorcerers known as the "Black Circle". He calls you,
(the brave adventurers) to purge the world of darkness and save us all...

Alright, the plot is classic trash, yet there is something about that game 
that interested me enough to finish it till the end. Probably because of the 
richness of the dialogues between the hundreads of NPCs found among the game.. 
or maybe I have something for hairy Barbarians?

Who knows.. the game is typical RPG. 
Some like it.. some don't..



***********************
*      INTERFACE      *
***********************

This game makes strong use of the mouse and a little bit of keyboard (optional)
If you ever played Dark Sun by SSI, you might feel somewhat at home.

-MENU SCREEN-

This is very straightforward with the logical options as "SAVE", "LOAD" and 
so on.


-CITY/DUNGEON SCREEN-

This is where you spend most of your time, walking around and exploring. 
Easy interface, only click the mouse button on where you want your character
to go and he will do it!
You can also use the keyboard to move in tighter restrictive spaces.

(You'll encounter some people here, click on them to talk to them).


-HOUSES/DOORS SCREEN-

This often comes to be a combat screen if there are enemies around. If not, 
you might encounter some people to talk to (click on them) or find some items.

The items are either plain in sight (just click on them to take) or hidden in 
jars, boxes, pots, chests or even behind shields or in plants. If your cursor 
turns into a small white cross, means you should investigate there to get some
hidden bounty.

(IMPORTANT: To move out of this screen either click on the little Red arrow on 
            the bottom right in order to come back the way you came or on the 
            sides of the screen if you see an opening there. Some houses have 
            more than one room!).


-TALKING SCREEN-

Pops up when you talk to someone.. Straightforward, you click on what you want 
to say from a series of phrases. (Note that you can retry any combo of phrases 
anytime you want. Seems that the people in Lemuria are pretty dumb and forget 
everything you said previously lol).


-MAP SCREEN-

If you move out of the city of Llandria, you will see a map of the region. You 
can click on the mountains, the pyramid, the ruins etc.. to go to that area.


-INVENTORY SCREEN-

*This is important*

This pops up when clicking on the pouch icon on the main or combat menu.

You will then see 10 empty inventory spots alongside a diagram of the 
armors/weapons your character can fit.

There are four types of inventory for each character, toggled by the four 
buttons at the top of the screen.  They are:

	*POUCH:	    Displays weapons and armors.

	To equip items, simply put them on your body diagram. 
	(Ex: put leather armor on torso)
	(Ex: put long sword in hand)
        (Ex: put a ring in one of the 4 ring spots on top)

	*CROSS:	    Diplays cleric spells that have been created.

	Clerical and Sorcery magic are interestingly made in this game. By 
        using formulas found in scrolls (you can buy or find scrolls) you will 
        be able to create spells.

	*BOOK:	    Displays Sorcery spells that have been created.

        (see above)

	*CAULDRON:  Displays ingredients.

        This is the screen you use to create spells. All your ingredients will 
        be placed here and what you need to do is dump them in the big cauldron 
        to create a spell.

        (Ex: bat wings + mushroom + dragon blood = FireBall 
        (which will be placed in SORCERY).


-STATUS SCREEN-

This pops up when clicking on the clipboard icon on the main or combat menu.

It shows the current character's statistics on the left, the DEFENSE and DAMAGE 
scores. Also shows if the character is healthy or poisonned.


-BATTLE SCREEN-

*important again*

In Warriors of Legend, you do lots of combat so knowning how it works is highly
important. This will happen when you enter an area with enemies. 

*If you wish to run, click on the red arrow on the bottom right of the screen.

*To use items or spells, click on the pouch icon.

*To throw spells, simply click your spell icon on the desired target or 
 anywhere in the screen for big spells like Armagedon.

*To fight:

 left click on an enemy  = one strike
 RIGHT click on an enemy = pummel till he dies! (I recommend that)

*To switch party member, simply right click on it's name and then command 
 him/her to do something.

When your character hit the enemy, a green flash will appear under it's name.
If the enemy hits YOU, a red flash will appear under the character's name.

Near each character, you have 3 monitor bars.

        BLUE  = Cleric Magic Points
        PINK  = Sorcery Magic Points
        GREEN = Health

If your characters loose all of it's green bar, the character dies...

(btw: when the enemies die, often a pouch will appear where they stood. 
 Click on it to loot goodies :)


***********************
*   THE CHARACTERS    *
***********************

In Warriors of Legend (wofl), you control 4 characters at once. They are 
pre-determined but you can change their names and modify their attributes in 
order to fit your mood better.

As you will mostly only FIGHT in this game (classic RPG, I warned you). Your 
best bet is to be well fitted for battle. And since their is ONE good weapon
in the game (Thor's Hammer), I advice you guys to have good stats in 
hand-to-hand combat.

Truthfully.. 4 heroes with 4 Thor Hammers are virtually unstoppable..

You will also need at least ONE mage since the sorcerers of the Black Circle 
can ONLY be killed by casting the correct spell on them.

A thief is also a nice thing to have to pick a few locks here and there...

Here are my following advices to make a good party of character.

BRAND    : The Strong proud Barbarian Hero of the Game

           STRENGTH     : 20
           WISDOM       : 15
           INTELLIGENCE : 15
           AGILITY      : -
           STEALTH      : -

ATARIS   : The Exotic Warrior (also known as Brand's clone).

           STRENGTH     : 20
           WISDOM       : 15
           INTELLIGENCE : 15
           AGILITY      : -
           STEALTH      : -

KEENA    : The Thief

           STRENGTH     : 20
           WISDOM       : -
           INTELLIGENCE : 10
           AGILITY      : -
           STEALTH      : 20


ASTROVIR : The Wizard

           STRENGTH     : 10
           WISDOM       : 20
           INTELLIGENCE : 20
           AGILITY      : -
           STEALTH      : -


With such a team, you should be pretty much unstoppable. Use Brand, Ataris and 
Keena to fight with Astrovir as support if needed. For lock picking doors, 
place Keena as leader (she'll open them all with her 20 in STEALTH). As for any
form of magic, Astrovir is the man. Brand and Ataris are also pretty good with 
their 15.. but you probably won't use them at all...

As you could note, none of these characters have Agility.. why? Here's why:


***********************
*      THE STATS      *
***********************

STRENGTH:     Determines how many hit points (Health) you got.
              Determines how many extra damage you make with a melee weapon 
              (sword, hammer, etc)

WISDOM:       Determines how many clerical points you got.
              (Also how fast you recover them)

INTELLIGENCE: Determines how many sorcery points you got.
              (Also how fast you recover them)

AGILITY:      Determines your successes with a bow.

STEALTH:      Determines your successes lockpicking doors and avoiding traps.


Now for a quick comparison:

A sword makes 7 damages
A bow makes 7 damages
A Thor Hammer makes 30 damages!!!

What's the point of a bow? (Especially that it cost you arrows to use??).

Conclusion: You dont need agility in this game. :)



***********************
*     GENERAL TIPS    *
***********************

This game is not hard to beat, but you need to know what to get and what to do.
If you follow these simple advices, you'll destroy anyone in no time.

You start with 1000 gold pieces, use them well.

*TIP #1*

  In the starting city of Llandria (Merchants Quarters) from the East door
  (north-east of the city). There is a merchant selling Mythril pieces of 
  armor.

  THIS IS THE BEST ARMOR IN THE GAME! 
  (So buy it as soon as you can for your 4 characters)

  Mithril Mail   : 750 gold   (25 Defense)
  Mithril Helm   : 100 gold   (10 Defense)
  Mithril Shield : 280 gold   (15 Defense)

  Leather Boots  : 20 gold    (1 Defense)  (sadly the best in the game)

  -Thus, buy yourself 4 Mithril helmets (400 gold) at the beginning-

*TIP #2*

  A bit north-west of that Mythril armor shop there's a guy selling lockpicks.
  Buy one set for 200 gold. (now you can open locked doors for extra goodies).

*TIP #3*

  STEAL STEAL STEAL!!! In this game, you dont play totally "moral" characters.
  Remember that it is a world where thieves are lords. So everytime you enter
  a house, scan everywhere on boxes, pots, plants etc... If your cursor becomes
  a little white cross, get the goodies!

  You can either keep these goods for yourself (equipment, weapons, 
  ingredients, potions, etc). Or you can go to any merchant and sell your stuff
  for extra $$$.

  (Obviously open any locked doors with your lockpick set with Keena as 
   leader for extra loot).

*TIP #4*

  LOOT EVERYONE YOU KILL!!! Again.. not very moral. When you kill people or
  monsters, get the stuff they leave behind. Keep the stuff for you or sell 
  it for extra $$$.

*TIP #5*

  GET THOR HAMMERS! This is probably the most important tip... Thor Hammers 
  are the BEST weapons in the game. They have an attack rating of 30! An 
  adventurer with that can kill a red dragon in one shot... So imagine the 
  effect on a stupid human guard.

  Thor Hammers can be bought somewhere in the city for 500 gold, but you can 
  find them pretty easily across the game. Heck, even in the starting city you 
  can find some by checking houses or by killing guards (you might get lucky, 
  this stuff is random).

*TIP #6*

  DONT KEEP THE SCROLLS! When you buy a scroll (cleric or sorcery) all it does
  is to give you the formula to create a spell. This stuff is random so 
  unfortunately I cannot give you guys the formulas in this FAQ. But.. after
  you buy a scroll, simply write the formula on a piece of paper and sell back
  the scroll for half the cost. You'll save lotsa money that way (since scrolls
  are expensive) and will also free space for your inventory.

*TIP #7*

  DONT KEEP THE KEYS! In the game you'll find lots of keys (especially near
  the end of the game) and you wont need them after the door is unlocked. Each
  key unlocks only one door, so when your done unlocking the door, sell it.
  You'll make 25 gold per key and free up a LOAD of inventory space.

  (N.B.: Only sell "normal" keys. Not the Chaos Key fragments as this is your
  quest dummy!) lol
  
  (N.B.2: If your stupid and sell a key before using it. Buy it again, the 
  merchant still have it in stock).

*TIP #8*

  BUY EMPTY FLASKS! Probably the cheapest item to buy (2 gold). In some shops
  you can buy some empty flasks. Totally worthless for now, but across your
  adventures you'll find some magical waterfalls (green, red, purple waterfalls
  etc). Simply use an empty flask on it and voila, you got a healing potion, a
  cure poison or something else! These can be useful to drink in need, but you
  can also sell them for 50 gold a pop. If you manage to find a Holy Water
  spring you can even sell those for 250 gold!!!

  Now you can be Brand the potion-merchant. Buying empty flasks for 2 gold and
  selling your potions for 50 gold... Do that 10 times and you got 480 gold
  more in your pockets...

  Easy money hey? :)


*TIP #9*

  SELL THE UNESSESARY STUFF! I still haven't found the use of the Ankh, the 
  Book of Sorcery, the Demon Amulet or the Undead Amulet... So if you find 
  those, sell 'em for a great profit!

  Also any extra rings you get, you sell them for 250 gold each. (only equip 
  Mana rings to Astrovir.. but you can equip a few Regen rings to everyone. 
  They will heal faster).

  (man this game sounds more like a trading game than an adventuring one...
   silly barbarians..)

*TIP #10*

  KEEP THE NECESSARY STUFF! On the other hand, a Stone Heart is good to use
  (that's the only thing that kills Stone golems if you place one as your 
  shield). And ARMOR AMULETS are a total MUST!!! They cost 2000 gold
  (expensive) but give you 50 Defense more...

  A character fitted in Mythril with an Armor Amulet got a Defense rating of
  more than 100...

  ...thus you can't be killed by weapons.

*TIP #11*

  Talk to everyone. Dont be cheap.. give them 5 gold if they need it to talk..
  You got plenty.

*TIP #12*

  The only important spells are: Flaming Death, Freeze, Magic Fire, Paralyze,
  Armagedon (all sorcery) and Plank (clerical).

  The rest is only to help out a bit... maybe Healing and Resurrection are
  worth it.

*TIP #13*

  There is no Tip #13, I'm just mean and giving you bad luck ;)

  (Oh allright.. tip #13, save your game often!)


***********************
*      THE SOLVE      *
***********************

This is the final section, how to solve the game per say. If you followed the
above tips your job is nearly done allready. The rest is just formalities..

Here we go.

---------------
-LLANDRIA CITY-
---------------

You begin your adventures here after escaping from Moc Madure the lizard 
Dragon Lord. In the city, follow the general tips mentioned above. Talk to 
everyone in order to learn what's going on. Steal, loot, buy mithril armors, 
get Thor Hammers... and...

Get a *Flaming Death* sorcery scroll when you can afford it 
(along with the ingredients).


----------------------------
-  EPISODE 1  - Moc Madure -
----------------------------

* When ready, exit the city from the south.
* On the map click on the mountains

*You will be in some canyons with some stupid easy human guards. Kill'em. Your
 goal here is to find the red waterfalls which is somewhere up north. This is
 a confusing area since if you go north, you dont always *seem* to go north.
 Call it an illusion place...

*In this area you can find a green waterfall (remember the empty flask trick?)
 You can easily get healing potions here.. sell them back to the city..
 make money... you know the drill..

*Once you locate the red waterfall, click on it. Behind is Moc Madure's lair.


-THE CAVES-

*You are now in a series of caves and tunnels. Filled with red dragons and
 spiders.

*The red dragons and spiders are easy to kill (with the Thor Hammers). But you
 may encounter some Stone Men also in here. These guys are invisible unless
 you carry the Stone Heart in place of a shield and start hitting on them with
 your weapon.

*You'll find lots of cave openings here and LOTS of loot (the biggest loot in
 the game in fact).

*Get all the possible loot you can, go back to the city and sell all of this.
 Back in the city you can most probably buy full Mithril armor suits for your
 characters (congratulation you now have the best armors in the game) and
 perhaps even some Armor Amulets.

*When satisfied being near-Gods, go back to the caves to slap Moc Madure silly.


-THE LAVA BRIDGE-

*As you travel east inside the caves, you will eventually reach a frightening
 lava filled area.

*Save your game as this is tricky (and stupid). Try your best to cross that
 lava bridge by doing some zig-zag... You'll die often... As I said.. 
 it's stupid.

*Eventually you'll cross the lava bridge, continue down the long corridor
 untill you reach the big solemn door. Get ready for battle.


-MOC MADURE'S LAIR-

*Enter the door and kill the two red dragon heads with Thor hammers.

*Enter the left opening and get the bounty. Return to where you encountered
 the dragons.

*Prepare a FLAMING DEATH (sorcery) spell with the necessary ingredients!

*When your all set and ready, enter the right opening and face....
 MOC MADURE HIMSELF!!!!

*He will speak.. try his best to looks real villainous and gloomy... mwhahaha..

*Quickly shut him up with a simple FLAMING DEATH spell and he's history... 

*Go in the chamber to the right and get the first part of the Chaos key (1) 
 along with the other key.

*Retrace your steps and go back to Llandria city.


----------------------------
-  EPISODE 2  - The Witch  -
----------------------------

Congratulation, you killed the first sorcerer of the Black Circle and got the 
first piece of the Chaos key used to lock Set away back in it's own plane of 
existance.

Next step will be the Witch. Before you go, you'll definitely need:

The *Freeze* Sorcery spell (along with ingredients)

When ready, exit the city and click the ruins on the map.


-THE RUINS-

*Inside the ruins, use the key you picked from Moc Madure to unlock the door.

*Go west until you reach the button and push it.

*Go north to a dead end and you will be teleported southwest of that.

*Go north to an area with two levers. Pull both of them down.

*Go south, then east past the Stone Man (don't forget your Stone Heart).

*Continue east untill you return to the doors you entered previously.

*Exit through the center door and enter the right door.

*Go east + north + east + south to the Hall of Letters. Pull down all levers
 as you go.

(Obviously enter every room, steal the loot as you travel through that)


-THE HALL OF LETTERS-

*This is another tricky part of the game so I'd recommend saving your game
 first.

*By using the keyboard (more precise), walk on the blocks to spell out 
 G-A-M-O-R-R-A-H (The witch name's btw)

*Continue to spell that (you need to about 4 or 5 times) until you reach
 south.

*Get a stone heart ready and enter the door. Slay the Stone Man.

*Enter the side chamber to get the bounty (Vision potions -IMPORTANT-)

*Prepare a FREEZE (sorcery) spell and go up.

*Meet with Gamorrah the witch, talk and quickly chill her out with the 
 Freeze Spell.

*Enter her chambers, get the Chaos Key (2) and the dead man key.

*Retrace your steps (spell H-A-R-R-O-M-A-G on your way out the Hall of Letters)
 and go to city.


----------------------------
-  EPISODE 3  - Illusions  -
----------------------------

With the 2nd sorcerer of the Dark Circle gone, your in good stance. At this 
moment, you should have gathered enough money to all have Thor Hammers for 
everyone, full Mythril armor suits and probably even Armor Amulets for 
everyone. Bottomline, money is pretty worthless from this point on...

What you need tho is a *Paralyze* (sorcery) spell and a *Magic Fire* 
(sorcery) spell.

When ready, exit the city and click the Palace on the map.


-THE PALACE OF ILLUSIONS-

*Unlock the door on the right with the key from the witch.

*As you get into the palace, you will soon note that there are some illusions 
 here...

*Drink a Vision Potion (found in Gamorrah the witch's chambers) and all is 
 revealed! (Pits and Hidden Passages)

*This section is pretty straight forward, just go fast before the powers of
 the potion faint.

*Avoiding pits you will eventually arrive at a dead end. Walk into the dead 
 end and drop into the pit.

*Another annoying illusion area filled with giant leeches. Explore a bit until
 you find a room with a star symbol on the wall. Click on the symbol. Then get
 up the ladder.

*Head north and east (avoiding traps) to reach the curtains.


-KHALIMAD-

*Before entering, prepare a PARALYZE (sorcery) and MAGIC FIRE (sorcery) spell.

*Enter the curtains and here you are greeted by Khalimad the Illusionist.

*Shoot him with the PARALYZE spell and if that doesn't kill him, with the
 MAGIC FIRE too.

*Get his Chaos Key (3) and the Mummy Key.

*Exit the room and jump into the nearest pit. 

*Climb the ladder and go north to exit the Palace.


----------------------------
-  EPISODE 4  - The Mummy  -
----------------------------

Your doing great so far :)

What you need now will be a *Plank* (clerical) spells. Actually prepare a good
few of them (5).

Also prepare a few *Armagedon* (sorcery) spells (5 also).

Finally prepare yourself one *Paralyze* (sorcery) spells.

When ready, exit the city and click on the Pyramid.


-THE HALLS OF THE ANCIENTS-

*After walking toward the Ancient caves, you meet a skeleton in a sarcophagus.

*Dispose of him by using an ARMAGEDON (sorcery) spell by clicking somewhere on
 the screen.

*Use the Mummy Key to open the sarcophagus.


-THE PYRAMID-

*Ok, this part is the most annoying one in the game. You need your PLANK 
 (cleric) spells.

*Your goal is to go down to level 16 without dying. You'll have to climb down
 a few ladders, lay planks over pits and hope for the best.

*Forget open doors as many will put you back to the beginning and nothing is
 of interest to loot in this level anyway. Just go to the only door I'll tell
 you to go.

*First step is to cast a PLANK (cleric) spell. You will see a green bar on the
 top slowly going down. This is the duration of the spell. As long as the spell
 is active, you can lay planks over pits.

*You need to go down to level 16 from the east part of the level.. so have fun.

*When you reach level 16, lay planks to the west until you see a ladder going
 up between two spikes. Climb the ladder to level 15 and wait near the door.


-BOHAN THE MUMMY-

*Prepare a few ARMAGEDON (sorcery) spells if you haven't already along with
 a PARALYZE spell.

*Enter the door and kill the skeletons with an ARMAGEDON spell. Continue on.

*You will be greeted by Bohan (the mummy) and his 2 skeleton lieutenants.

*First cast an ARMAGEDON spell to get rid of the 2 skeletons.

*Second cast a PARALYZE spell on Bohan himself. That's enough to kill him.

*Enter the side chamber, get the Chaos key (4) and another key.

*Exit, go down a ladder, head west (might have to cast PLANK again) to the
 door and exit.


----------------------------
-  EPISODE 5  -  The City  -
----------------------------

From now on, you wont leave the city of Llandria.

Get a few Plank (cleric) spells ready and most importantly, try to have lots
of free inventory left since you'll get tons of keys here.


-THE ROOFTOPS-

*Go to the Thieves Quarters (west gate). Go north and east until you reach a
 ladder in the streets. Climb on the Parapet.

*On the Parapet go east and south until you see a roof of a house you could
 go nearby. (there's a little opening on the parapet to show you where).

*Cast a PLANK (cleric) spell and start laying down planks from rooftop to
 rooftop untill you reach another parapet. On that parapet go a bit north
 untill you find another ladder going down back to the street levels.

*Go south west to the building with five doors.


-THE CITY PALACE-

*Enter one of the 5 doors (I recommend starting with the one on the far right).

*This is a very easy area to solve, but a hard one to write since it's long 
 and repetitive.

*The goal here is to find numerous keys that will permit you to open doors, 
 find more keys, open other doors etc... (Ex: blue key to open the blue door).

*These keys are scattered across the palace of 5 doors, to find them just
 check all plants, pots, chests, cabinets and so on for the keys.

*Continue unlocking doors and exploring until you find the final BRONZE KEY
 and the fifth piece of the Chaos Key (this is in the north east section of 
 the Palace).

*All along your explorations you will be attacked by Bandor the Shape-Changer
 who claim to have usurped the throne from good king Osiric. He's extremely
 easy to defeat since he only change to random monsters you fought previously
 (spiders, lions, dragons, etc). Only bash him with your weapons when he pops
 in and he wont be much trouble.

*Finally in the northeast room, get the Chaos Key (5) and the Bronze Key.

*Click on the left symbol on the wall to exit the building. 

*Return to the ladder.


----------------------------
-  EPISODE 6  - Set Temple -
----------------------------

This is the Final Episode :) You defeated all the Black Circle sorcerers and 
got 5 pieces of the Chaos Key. All you need to do is to finally go to the
Temple of Set, get the last piece of that Chaos key and seal the serpent God
(Set) to his own dimension.

An idea before going to do that would be to sell all the normal keys you got
(blue key, white key, black key, etc) since you wont need them no more.

KEEP the BRONZE KEY tho. (and the chaos pieces) since that's all you really
need from now on.

When ready, hit the rooftops once more. Going toward the north-west part of
the city...


-ROOFTOPS REVISITED-

*As you lay planks once more (PLANK spell needed again), you will eventually
 reach a rooftop with a door on it. This is the Thief-Guild, kill the 3 guards
 inside.

*Go down the stairs and you realize that the Thief-Guild is on top of a 
 Temple (how convenient).

*Exit the temple and go north to the big Temple of Set.

*Unlock the door with the BRONZE KEY and enter.


-TEMPLE OF SET-

*I said the Pyramid was annoying? Ok I lied THIS IS! I've played many games,
 but this is the first one that really makes me swear... The maze here is
 nearly impossible unless you realllly like mazes (which I dont). Thus here
 are the directions before you become insane :)

*Bare in mind that even with these directions you could get lost easily, so
 I HIGHLY suggest that you save your game before entering the Temple of Set.

Directions:

Enter the temple and slay the Orc.
NORTH
EAST
SOUTH (Kill 2 Orcs)

WEST  (Kill 1 Beholder)
EAST  (Kill 1 Demon)

***

NORTH
WEST  (Kill 2 Orcs)
SOUTH (Kill 1 Orc)
SOUTH
EAST  (Kill 2 Demons)

NORTH
WEST  (Kill 3 Beholders)
SOUTH (Kill 2 Demons)

***

EAST
NORTH (Kill 2 Orcs)
WEST  (Kill 1 Orc)

SOUTH (Kill 1 Demon)
EAST  (Kill 2 Beholders)

NORTH (Kill 2 Demons)
WEST

Finally you are in the inner Sanctum of Set.. geeeeeeeze...

EAST (Kill 2 Beholders)

NORTH AND YOU ARE FINALLY THERE!


-BATTLE WITH THE SERPENT GOD-

*After all this annoying maze you are now facing the 6th and last piece of
 the Chaos Key.

*Get the Chaos Key (6)

*Go north and you will be in front of a Portal with Set trying to get out 
 from it.

*To lock him out, you need to throw the 6 pieces of the chaos key in a
 specific order straight on it's forefront, knocking him back to his own
 realms (I find this funny lol).

*The order is easy. 
 (You can always zoom each pieces to see the details of them to see what
 I mean here).

 You need to throw the pieces in this order: C-H-A-O-S-key


-ENDING-

After Set the Serpent God tells a joke about why the Barbarian cross the road
(funny programers) to our intrepid heroes. Brand and his friends bravely throw
the chaos key pieces on the giant snake's head... The Magic works it's way,
forming a seal over the portal to the realm of Chaos.

In a scream of anger, the serpent vanished in the red hazes... Leaving our
heroes in awe.

Brand, Ataris, Keena and Astrovir smiled as the gate to Chaos was locked
forever..

Bringing peace and justice once more.. marking them...

As the Heroes of the Land of Lemuria.


***********************
*     CONCLUSION      *
***********************

There we are my friends :) The ending left a bit of a disappointment, but I
guess it went with the general flow of the rest of the game. We are treated to
a few cut scenes telling us what would happen next now that Set is banished.

As for me, this FAQ ends of now as well :)

I hope you found this informative and helpful for the very few people
(maybe one or two) who might play this old game. I had fun writing it, and
it shall serve as a fine little practice as to my future writings.


Farewell friends, and happy adventuring!


This document Copyright 2002 Nicolas L. Clement