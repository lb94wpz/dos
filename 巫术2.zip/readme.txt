Wizardry 2 - The Knight Of Diamonds
-----------------------------------

Version 3.55
Walkthrough by Mr. Kelly R. Flewin
E-Mail: K_Flewin@Yahoo.Ca


Disclaimer!!

This Guide is for private use only, and may not be reproduced or
altered in anyway. This may not be sold or used in anyway
to earn a profit, such as putting it on a CD and selling it
that way, or ANY Such manner not listed here. I am not associated
nor affiliated with the creators of this game and system. This 
Guide was written by me, K. Flewin. I am not associated nor 
affiliated with any copyrights not mentioned in this Guide.

This guide is Copyright Mr. Kelly R. Flewin, 1999-2005
              Copyright Time Traveller's Inc. 1999-2005



Revision History
----------------
3.55 - Corrected a typo, fixed a little fact and changed the email.
       Also fixed the item tables a wee bit and added a bit of new
       info.

3.50 - Updated for the New Millenium with a few new links.. nothing big,
       but it's the new Millenium :) That and fixed a little spelling
       error...  -_-;;

3.00 - Added a disclaimer and new instructions on distribution! Please
       make note of both. Also added some websites where it is to be
       found. :) Thanks to those who emailed me with links and such.
     - Also added a small FAQ section due to the overwhelming amount
       of questions I have recieved.
     - Added a few more misc items I found in my wanderings. If this list
       ain't complete.. :)

1.05 - Added John Hubbard's Email Addy. [Sorry about that John, I meant
       to add it before I sent this out, and I forgot to check for your
       addy before I did.]

       I also cheerfully raised my characters back to Levels 40+ :) I'm
       now curious if one can attain the experience level of 100 or
       greater... and what happens if you play the game long enough that
       your gold or experience maxes out... if that's even possible..

       Finally, I've added a special section for those who were kind
       enough to ask me if they could put my solve on their sites and
       such. I feel they deserve proper recognition... and to boot, you,
       the gamer, will also know where to find my further works and
       solves and updates as well... and to boot ;) You may find other
       solves you couldn't find elsewhere :) Please see Part 6 of this
       Solve for more info :)


1.00 - You're reading it :) It's kinda barebones compared to my other
       solve/walkthru for Wizardry 1, but then I literally lived and
       breathed Wizardry 1... Wizardry 2 though.. I'm still needing
       to look at my maps to navigate through some levels... but then
       after writing this, I'm almost as proficient alone without them.

       I lost my insanely high level characters of like Level 40+ and
       my backup was at the end of the scenario.. a nice 23 levels back.
       Always make double backups kids :) That and the item list is
       getting insane! Alot of similarities between part 1 and 2 and
       a whole SLEW of new items to make things interesting.

       I've transported my ancient maps to my graph paper book I used
       for my best Wizardry 1 map copies. I Kinda-sorta have a map
       made for Level 6... but it needs to be HEAVILY revised due to the
       fact that I've got a few doors wrong and DUMAPIC DOESN'T work
       on this level [Or Malor for that matter.]


Part 1 - Moving Your Heroes!
Part 2 - The Beginning
Part 3 - The Maze Itself
Part 4 - Item List 
Part 5 - Frequently Asked Questions
Part 6 - End Credits and Stuffage


 This is very different to Wizardry 1. There's only 6 Major Quest items
to be really concerned about. All 5 K.O.D. items and the major goal, the
Satff of Gnilda.

 This applies to the PC classic AND The NES version as, other then the
opening music, dungeon music and slightly better graphics, 
they're virtualy identical. The only major difference lies within the
transference of characters... you have to start from scratch in the NES
version and such. With the PC Floppy version... the instructions are
detailed in your instruction manual and requires you to have the Two
Master Disks  [1 Each for each game].  If you own the "Ultimate Wizardry
Archives" [And even tho I have the disk versions of 1-3, I own this],
it's very simple.

 Updates can be found ON ANY of the sites mentioned in Part 6 :)

 Maps may be available at the above address, but probably not. I will
email copies of it to those who want them. Unless someone wishes to host
them on their website, which if so, I will then include the link to it
in an immediate update.



Part 1 - Moving Your Heroes! 
============================


 To move your characters, simply load up Wizardry 2, go to the Utilities
menu, select the MOVE characters option and select the Wizardry 1
characters you wish to move and VOILA! They will now be PERMANENTLY moved
to Wizardry 2. Please note that in case you want to wander Wizardry 1 for
a while as the Experience and Experience levels are left as is...

 [I like to build my characters up to level 18 or so THEN move them to
K.O.D. so it's a little easier. These enemies are tough... so be warned.


Part 2 - The Beginning
======================

 In the beginning, there was darkness, suddenly a burst of light, and
poof! Whoops... wrong beginning!

 To start off, I can not stress this enough! READ THE MANUAL! I MEAN IT!
Get off your butt NOW! And read the whole thing! This is the most
valuable asset a Wizardry Player has at the beginning of a long journey.
Now, if you've already played this game before and know what you're
doing... then hurray! Remember to have the manual nearby though,
especially for the spells! [In the PC Version you have to often type
them out! Type the first letter and hit enter to make the game bring up
a list... the manual helps you by detailing what each spell does.

 I am NOT going to print out the spells here for you... you can consult
your manuals for that! For shame if you pirated this game! You deserve
to suffer! If you've honestly lost your manual... then your S.O.L....
Interplay has no tech support for any Wizardry game and the old Sir-Tech
lines don't work. Heck the newer ones don't work either :(

 Once you have your characters, go off to Boltac's Trading Post and stock
up on goodies for your gang. 

 Now that you're stocked up... EQUIP YOUR STUFF! You wouldn't imagine how
many people fail to equip their stuff and wonder why they just got
slaughtered for the umpteenth time. When you're ready, go down to the Maze
and prepare yourself for some action.

 Quick note about the dungeons! Beware what you do! Evil characters will
NOT stay with Good characters. And vice versa. Neutral characters don't
give a damn. So... unless your characters are all neutral... If you're
good, let friendly monsters leave on their own way. If you're evil,
ROAST THEM! Otherwise, you may find that your good or evil characters
just switched alignments. Now granted, they will stay with your party,
but the second you reach the surface, they'll ditch you. There IS a way
around it, but it's a bit risky. Take the characters still with you,
heal them and go into the maze. Quit! Then go back into the game and use
the character(s) who ditched you and go into the maze. (I)nspect and pick
up the characters. The one downside to leaving any character in the maze
(especially further down) is that the monsters may rob you.

 One other warning... beware where you Malor... make sure you know the
EXACT CO-ORDINATES! Otherwise you may teleport into rock.. and trust
me people.. that is the worst thing to happen... well next to your
character becoming LOST for ever or turning into permanently dead...
yes... the Temple of Cant is not always 100% perfect. In Wizardry 2...
although there's only a few ROCK places, becareful none the less....
trust me.. you don't wanna lose a level 29 Ninja... because if they die,
and you ain't fast enough, you're screwed.


 Final Thing before the walkthru! I SWEAR! This is something that the
manual does NOT advise you do (The disk version) and that's suddenly
resetting your computer or shutting it off due to the fact it usually
would happen when the game is writing to the disk... hence your
characters go byebye! [I must admit, I fell prey to the "RESET" spell
once or twice and lost my characters once.]

 BUT! Lo and Behold! There is a way around this that ALLOWS you to reset
the game! No.. not the computer! Go figure Windows 95/98 actually is
useful for a game! If you see your characters decapitated, drained levels,
activate a chest trap [Teleporter] or teleporting into rock.. etc. There
IS a save! This only works with the CD version (Ultimate Wizardry
Archives). It installs the game into a dir ?:\WIZARD15  , where ? is the
drive it's on. If you run it from the MS-Dos Prompt and something happens,
hit the Win95/98 logo key on your Win95/98 Keyboard (104 Key Keyboard
if you didn't know) to bring up the menu, hit esc and then left click the
game in the bar at the bottom and close it. From here, you just simply go
back and load your game, and you should be at the exact square before the
accident happened! The key doesn't affect the game in anyway so!!! :)
There's your failsafe, and trust me... IT IS A LIFESAVER! Unless of course
you happened to do this on a square where it's a forced fight.. then you
end up getting some random enemies right off the bat, and whether you
run or beat them, the forced fight will occur right after... and if you're
weak as heck already... ouchie.

 My apologies for all of this rambling and info, but I hope you can
benefit from it. Anyways, on with the walkthru!


Part 3 - The Maze Itself
========================


Beginning
---------
 Arr! So ye be ready to take on the 6 floors of danger down below! Do ya
gots all your equipment in order and equipped? Did ye rest at the
Adventurer's Inn so yer fresh n' ready? These enemies start off rough
and only get alot rougher. They travel more often in packs and on the
bottom floor... ooh boy do they ever pack a wallop with Mabadi's and very
strong offence. When you've stopped cowering, let's get ready to kick
some ass. Please note, with my directions, at all times I wish you to
know I give them as if I was always looking Northwards. Use a DUMAPIC
if you run into problems... hopefully my guiding is pretty straight
through.


The Maze - Floor 1
------------------

 You start off at good ol' (0E, 0N, 1D) with stairs going back to the
surface. The direction you are currently facing is North, so please
keep that in mind. Go 2 East to come to the first door. If you want to
get a taste of things to come in and you will encounter your first
forced encounter of the game. If you want to get a feel for the level
and/or raise a level or 2, this is a good way to start... just becareful
when you follow the rooms because there's a pit trap at 1E, 6N and that
is some seriously nasty damage. But I digress... after all, you want to
know where to go to get some serious action and the first glorious
artifact. From the start, travel 9 East till you come to your first
junction. Go 6 North till you come to a door. Behind here is usually
some enemies lurking, so kick their asses and go 1 North. This puts you
in the main chambers of the level. There's alot of doors to choose from,
so becareful as most of them teleport you to other places in the level.

(7E, 13N), (8E, 13N), (10E, 13N) & (11E, 13N) all teleport to (9E, 7N). 

(12E, 11N), (12E, 9N) & (12E, 8N) all teleport to (6E, 10N)

(7E, 7N), (8E, 7N) & (11E, 7N) all teleport to (9E, 13N)

(6E, 8N) teleports you to (12E, 10N)


 If you proceed straight ahead into the first door you see, you will
enter Gnilda's chamber where her vision will instruct. This is also
where you obtain the final quest item, her staff... but that comes much
later on. Anyways, back to where we were. If you're following along,
you should have just entered the chambers. Go 1 East and then go 2 South
through the door. Go 3 East to the door and get ready. Behind this
door is... LONDON! No... it's not london.. but with the damned fog,
you'd THINK it was. Here we go!

 This is where it gets a bit tricky. Go 2 South and 1 West. If you go
further West, you should get the message about a wall. Go 1 South,
West till you hit the next wall, 1 North, 1 West, 2 more South and
1 East and voila! You should now be in a small hallway with adequate
lighting. You should see a door ahead and a message. Follow the message
very carefully, as you'll NEVER reach the door otherwise. Chant Malor
here and go.. well I usually do it 3 East to get into the room past
the door. Heal up right here, as you're about to get some action. Go
1 more East and you will encounter your first Artifact... The K.O.D.
Armor! And furthermore... it's got a life of its own. It has very
strong attacks at its disposal, but a simple KATINO usually does the
job. Once you defeat it, have one of your Fighters [Or whomever is in
your front line.. unless they're a Ninja, Priest, Mage, or Bishop/Wizard.

 The best part is, later on, you can come back and kill ANOTHER one
and get yet another K.O.D. Armor and make your frontline even MORE
formidable. That and the experience you get for defeating it, ain't
half bad.

 Anyways, once you're done oohing and ahhing over the nice way the armor
reduces your armor class, go through the door to the East and you will
be greeted with the stairs to Floor 2.

 One other point of interest is the room at (4E, 12N). The only way you
can enter it is with a MALOR spell... and even then, it's not advisable.
The room is nothing but a VERY NASTY pit trap. It tends to kill 1 or
2 of your characters. The good part is there's a door out of there..
but this venture is not worth it.


The Maze - Floor 2  [Pain In The ASS!]
--------------------------------------

 Welcome to Floor 2... which was a NIGHTMARE to map out, let me tell you.
Why? Because a good quarter of the level is nothing but FOG, which made it
VERY difficult to map. As always, you're free to wander... just becareful.

 Anyways, you start of a the stairs going up at (11E, 10N). To the
West and the North are 2 doors. The West door leads to a room with a
forced encounter whereas the North does the same, but is the right
way to go. Take the West and beat the enemies if you want some more
experience. Anyways, proceed North through the door and waste the
enemies. Becareful with chests... this is one of those levels where a
triggered Teleporter and no DUMAPIC spells left could be very annoying
and possibly even costly.

 After looting the chest, if you dared, head 1 East and 2 North to the
next door [To your left.] Behind this door is another forced encounter
and opportunity to loot. You'll probably be getting crap armor and
weapons and Stones & Rings. [Which are useful for the most part, see Part
4 for more information.]  Go 2 East and 1 South to the next door [Again
to your left.] Yet another forced encounter awaits, but by now you've
started getting that feeling it was going to happen. Show them who's
boss and then go 1 East and 1 South to the next door. [To your right.]

 Follow the beaten path until you go down a long hall ending in a door.
Heal yourself and enter through the door. The room is a teleporter that
takes you to a room at (3E, 16N). If you're running low on HP, avoid
this as the only way out of here are the 3 other teleporter rooms. Go
1 North and you'll see the message explaining my point. There are 3
doors, each with a teleporter behind them.

Monty: That's right! Behind Door #1 is a teleporter to (16E, 3N)! A
       small room with 3  1-Way exits leading to a very annoying
       labryinth of rooms and enemies. *

Audience: Ooooh!

Monty: And behind Door #2 is... your MOTHER-IN-LAW! No, just kidding
       folks. Behind Door #2 is a teleporter straight to London,
       courtesy of (19E, 19N). **

Audience: Ahhh!!!

Monty: And behind Door #3 we have the correct path to go onwards! You
       and your companions will be whisked away to luxurious (0E, 0N)
       where you will be able to continue your quest for the staff.


 Hehehe... I just had to do that folks. Most of the solves and walkthru's
out there are so.. robotic and boring.. I wanted mine to stick out a bit
more and to give you all a laugh or Two :)

 Anyhoo, unless you felt like living on the edge, you most likely have
gone through Door #3 :) From here, please go 2 East & 1 more through the
door to another fixed encounter. Waste 'em and head off 3 more East and
2 North to the next door. Yet another batch of baddies is awaiting you
beyond the door, so show em "Who's The Boss". Head 3 West and go through
the door to the North. Go up another North and go through the door to
the East. Yet another lovely encounter awaits.

 Once you've whipped them into shape faster then Richard Simmon's, go
1 South, 2 East and 1 North and through the door to the East and take
the enemies down. [The West door leads to another forced fight.] Once
you've beaten them, go 1 South and 2 East. Take the door to the South
for one of the last forced fights of the level. [The Northern Door goes
to a room with a very nasty Pit Trap in it.]

 Heal up as required and get ready for a bit of footwork, hopefully
unhindered. Go 1 East and 2 South to the Two doors. Take the Eastern
door [The other leads to an empty 1 Square room.] and proceed 1 North
and 2 East. Go on through the Northern door and head 1 East and 2
North. You'll see a door in front of you and one to your Right.

 If you're running low on health and spells, go on through, go West
down the hall and through the wall [1 Way Passage] and pop through the
door to the North to be back in the hallway that leads to the first
portal room. Backtrack [3 North, 1 East, 1 North, 1 West, 1 North,
3 East, 1 North, 3 more East, 2 South, 1 West, and 3 South takes you
to the exit.]

 If you're confident you're strong, go 1 more West and enter the
Northern door. [The Southern door leads to an empty 1 Square room.]
Ignore the door in front of you unless you're low on health [Follow
above directions to get back to the stairs.] and head all the way West.
Just before you come to a door, you will be stopped with a riddle. I
admit, it took me a while to puzzle it out. If you want to do it on
your own, then good luck. The answer is at the end of the Floor guide.

 When you've solved the riddle, go through the door and get ready for
a tough battle. You're going to have to fight the second Artifict, the
K.O.D Shield. It's VERY tough and does some seriously nasty damage [60+
alot of the time.] Use a nice KATINO on it to get a break. TILTOWAIT
and the like do not work. Your reward is a VERY NICE chunk of experience
and the K.O.D. Shield.  [Just like the armor and the other 3 artifacts,
this can be gotten again and again.]  Go West through the door and stop.

 Do you have enough HP and spells to go on? If not, go North and travel
East and through the wall [1 Way passage] and follow the previous
instructions to get back to the stairs. [I also recommend a MALOR to get
back to the stairs leading to the town... just in case, but do this
only when you're back on Floor 1.]

 If you're ready, head 1 More West to the stairs to reach the stairs to
Floor 3.


*If you actually CHOSE this portal and wish to know how to get back out
 and to safety, then this is the route to follow. I apologize if this
 brevity is confusing. If it is, let me know and I will see to updating
 it in a future update. Anyways, the quickest way back to safety is;

 From (16E, 3N) [Where the teleporter takes you.] go 1 East through the
1 way door, and all the way till you can't go East no more. About face
and Go all the way North till you hit the wall. Continue West all the
way until you reach a dead-end. Go North through the 1 Way passage
and you will be in the long hall, right near the first teleporter.
[Just go North and follow it to the door with the teleporter to the 3
teleporter room and pick again.]

**Oooh boy! This is the Nightmare of which I referred you to. Now, when
  I mapped this out, I found about a little place I was unaware of before.
  It's a small 2 room section with a Wizard in it. He asks for a fee of
  either 10K or 100K... a hefty amount... for vital information. Don't
  worry about it.. I'll give it to you for free.

 Basically, in this Scenario, the Stars are aligned so some spells work
alot better then others do. The wizard mentions that spells such as
KATINO will induce longer, more powerful rests, MANIFO will work alot
better [Silence reigns supreme] and spells such as the draining MAHAMAN
will offer better boons. [I got to make a Ninja .. sure it drained me
a level or so.. but my Mage was level 28 :)] LATUMAPIC works really well
now too.


 Anyways, if you got stuck in here, here's the quickest route out of here.
[Seriously]

 From (19E, 19N) Face North [Use DUMAPIC for aid] and get ready. From
here, Go 7 West [Ignore the panel that slams behind you.] You'll hit a
wall. Go 2 South to enter a room of 1 way exits/entrances. Go South
until you hit the wall. Go West all the way till you hit the wall there
and go 1 South, 1 East, 1 South, 2 West, 2 South, 1 West and go South
4 or so spaces. You should now be at (3E, 8N)  Go 2 East and 3 North.
You'll be in a lit room now. Go 1 East through the door for a forced
encounter. When you win, go 1 North to escape back to the 4th room
of the level and safety.


Note: There is 1 alternative way out, it requires a bit more work, but
      it leads to a 1 way passage that takes you in front of Teleporter
      Door #1 [The Labryinth Door] If you wish to go there instead, follow
      these directions.

 From (19E, 19N) Face North [Use DUMAPIC for aid] and get ready. From
here, Go 7 West [Ignore the panel that slams behind you.] You'll hit a
wall. Go 2 South to enter a room of 1 way exits/entrances. Instead of
going South, go West 5 spaces till you hit the wall. Go 1 North and then
proceed 4 East [Till you hit the wall], Go North 1 and then head West
till you hit the wall. You should be at (1E, 19N)  From here go 1 South
and 1 West. Go South about 10 steps [You'll hit a wall] and then head
1 East. Go 4 North, 1 East, 1 North, 1 East, 2 North, 1 West, 1 South,
1 West and Go 3 North through a door. You should be in the lit room at
(1E, 17N) Simply go 1 East through a 1 way passage and voila! You're
back at the teleporter room... but as I said.. this is a damned pain,
especially if you misstep.


BTW: The answer to the riddle is,  "SHIELD"   [No Quotes]


The Maze - Floor 3
------------------

 This floor is where things become even more painful. It's upon this
floor that the standard 19/19 being solid walls rule disappears, which
makes mapping and roaming a bit more difficult. This is also the first
floor with SOLID ROCK... I found this out the hard way. But I digress.

 We start off at the scenic (0E, 0N). From here, go 1 North, 3 West,
1 North & 1 West to the door. Go on through and head 2 South, 1 East,
1 South, 1 West, 2 more South and then follow the long Western winding
corridor till you come to a door. Go on through and 1 more West before
going through the door to the South.

 You're now in the HUGE room of the level. When you map it, it kind of
resembles 4 square doughnuts connected together. You are currently in
the upper right quadrant/doughnut.

 The Solid Rock part is in the lower Left quadrant and is composed of
(5E, 5N), (5E, 6N), (6E, 5N) & (6E, 6N) [Please note this when MALOR'ing
around.]

 From the door, go 1 South to the wall and then proceed to go 2 East,
1 more South and 4 more East to the next wall. Go 1 North and 2 East.
This is where you MUST have a MALOR spell ready. Use it to go 1 South
through the wall. If you go North in this room, you'll go back through
a 1 way passage. Instead go South to fight the next artifact/quest item,
Hrathnir. The sword is a bit tough to defeat, being pure offense, but
it's defense is rather good... until you use a nice KATINO on it :)

 Once it's dead, claim it as yours [Best weapon in the game? Yep] heal
up and head 1 room West and 1 North to reach the stairs to Floor 4.

 If you need to get back to town to heal, follow these instructions from
the door to the huge chamber. [Backtrack from here as needed, or if you
have a MALOR handy, teleport to the co-ordinates of (9E, 10N).] From the
chamber doors, go 1 South, 1 East and then proceed 4 South to the door.
Go on through and go 1 South, 2 East, 1 North and then go through the
door to the West. This is a teleporter straight to town. The other rooms
in here lead to a nasty pit trap and/or teleport you around the maze.


The Maze - Floor 4
------------------

 Guano anyone? Yep, there's alot of BATS here.. but they ain't the
worst of your concerns. There's also a fountain that Paralyzes your
characters... but it's clearly marked by all the messages before you
reach it. [How nice] Anyhoo, you start off at (7E, 12N)   AVOID!
(8E, 14N) as it's SOLID ROCK. Sorry to scare you.

 From the stairs, go 2 North, 1 West, 3 North, 5 West, 2 South, 2 West,
1 South, 4 West, 2 South, 4 West, 2 South, 4 West, 4 South, 2 East,
[Aha! A Change! Caught ye off guard, right?] 1 South, 2 East, 1 South
and now you should be at (11E, 4N) :) Go West through the door to face
off against the K.O.D. Helmet. The usual KATINO/Slay the sleeping dog
tactic works well. Your reward is the K.O.D. Helmet.. which as usual,
can be gotten again so all your fighters can have one. When you're done,
heal up and go 1 more West for the stairs to Floor 5.

 Now, before people comment on the West/South pattern... this is the
easiest way to get to the Helmet unscathed as there are PIT Traps
and OUCH squares which drain your hp fast at the following squares which
you avoided with this route;

(16E, 13N), (9E, 11N), (3E, 6N), (18E, 5N), (14E, 2N) & (9E, 1N)
respectively. Please also note, I MAY have missed one or two... if I have
please mail me with the locations.


The Maze - Floor 5
------------------

 This is one of the most pain in the ass floors in the game... not because
of the repetitive patterns in mapping, but the chutes to the bottom floor.
These can take you there unprepared and do a nasty little number on you
if your characters aren't tough enough. But enough of this, you want to
know the route to victory :)

 We start our journey at (2E, 18N). There's some fog nearby, but don't
worry, I shalt steer thee safely through. [Begins to sing like a
gondolier].. er.. then again.. maybe no sound is better...  Anyways,
head off 2 East and 1 South. There is a door to the East, so head on
through to the other side. Go 2 more North and you're back in the clear.
From here, please go 5 West and then head 9 South, 5 West, 1 South and
finally 1 East through a 1 Way Passage. Go 2 North and then 1 East
through yet another 1 Way Passage. [I feel bad, because I realized I
marked this wrong on old maps... they're being redone anyways.] Here
is the inner sanctum of the Floor. 

 If you need to go back to town to heal, go 1 more East and 2 South
through the door. For a fee of 5000 Gold you will be whisked to
town :) But I'm sure you'd rather fight the gauntlets ;) From the
inner sanctum entrance, go 3 South, 3 West and 2 North through a secret
door. Heal up and go 1 East to face the Magic K.O.D. Gauntlets.
They are VERY TOUGH! KATINO is your best bet, along with tons of
healing spells and luck. Once they're toast, don em up and be proud of
yourself for you've now aquired the 5 main artifacts/quest items of
the game! :)


The Maze - Floor 6  [Final Floor]
---------------------------------

 This is a complete and utter bitch to map, let me tell you. I ASSUME
that the stairs are exactly at (0E, 0N)... but because DUMAPIC no
longer works here, it's VERY difficult to be sure and makes mapping even
more difficult. [Especially if you fell down a chute from level 5 into
the Fog... that's how where I started to TRY and map and came to the idea
of stairs possibly at (0E, 0N). There's secret passages GALORE! So be
aware or LOMILWA for a while. This is it... the big time.. this is where
the HARDEST of any enemies this scenario hang out... trust me.. Orc Lords
are NOT push overs... especially with MABADI and stuff being used on you
all the time.

 If you simply want to get it over with, have a SINGLE character [Yes,
I said single... this can be a Mage since you can Malor to (9E, 9N, 5D),
KATINO the Gauntlets and wittle them down and then follow these steps.
Anyways, Alone and from the stairs, go 1 North, 1 East and 1 North again.
Simple, ne? :) Herein lies the Sphinx with a nice riddle. If you honestly
want to roam this level for the 3 Clues, then I'm leaving that up to
you. Since I posed the question, of what the answer is, in my Scenario 1
Walkthrough/Solve, I FINALLY got the answer I needed, from John Hubbard.
Thank you very much John. I and many adventurers are thankful you have
been able to aid us in the answer... which after 6 years of off and on
pondering, got me mad when I saw how blatantly obvious it was! The
answer is of course....

Announcer: We interupt this Walkthrough/Solve for this important
           announcement..... and now, back to your regularly scheduled
           Walkthrough/Solve.

 Pretty obvious, isn't? I kicked myself when I found this out.. oh wait :)
You didn't hear :) It's  "THE KNIGHT OF DIAMONDS"   [No quotes]

 Once you've answered, the Sphinx is satisfied and will allow you to
pass. Go 1 North and you'll be teleported back to Floor 1, in front of
Gnilda's room. Enter and her apparation will ask for the answer once
more. Speak it again, and for the price of all 5 artifacts, she will
give you the Staff of Gnilda, the very item you need to beat the game.

 Now all you have to do is simply run all the way back to the stair
well, go up the stairs to the town and...


            CONGRATULATIONS! YOU'VE JUST BEATEN SCENARIO 2!!


 The character you chose to do this solo work will be awarded with the
symbol of Gnilda [G] and all your fellow party members will recieve
Knighthood [K] for their aid to you and the throne. From here, you may
now simply go about and level build/gather artifacts again, or you
can get ready to import them to Scenario 3, The Legacy of Llylgamyn.

 Just remember this: Your gold WILL NOT! Go with you this time, so if
you want a little advantage in the future, make a dummy character in
scenario 1, import it to scenario 2 and leave all the gold with it :)


Part 4 - Item List
==================

 Much like Scenario 1, there is quite the variety of weapons, armor and
items. Primarily in my vast journeys through this scenario, I've come
across the odd rare item and so I will chronicle them here. This is
virtually complete, but! considering the fact that there's so many things,
and most just don't pop up terribly often, I think it's as good as they
come. The quest items will be added as I find them and their use. All "-"
weapons and armor should obviously be avoided. If you find anything not
on this list, please email me a snapshot of the item, inform me of its
use and how much it sells for at Boltac's. BTW: I've removed the "How
rare is it?" chart for formatting reasons. The more expensive an item
tends to be, the more rare it is. Stuff that SOUNDS Rare, probably
is [Rod of Raising for instance]... well that and also, what may come up
rather often for me.. may not come up to often for you.


Spells                                                            Price?
------                                                            ------

* Of Latumofis         Cure Poison                                   300
* Of Dios              Restore 1-8 HP                                500
% Of Katino            Put Enemies to Sleep                          500
% Of Badios            1-8 Dmg Against an Enemy                      500
% Of Halito            1-8 Fire Dmg Against an Enemy                 500
* Of Sopic             Caster -4 AC Temp                           1,500
% Of Lomilwa           Chants Lomilwa                              2,500
% Of Dilto             Makes Enemies easier to hit                 2,500
* Of Dial              Restore 2-16 HP                             5,000
% Of Badial            2-16 Dmg Against an Enemy                   8,000



Weapons                    Effect                                 Price?

-------                    ------                                 ------
Dagger                                                                 5
Staff                                                                 10
Short Sword                                                           15
Long Sword                                                            25
Anointed Mace                                                         30
Anointed Flail                                                       150
Long Sword -1                                                      1,000
Short Sword -1                                                     1,000
Staff +2                                                           2,500
Staff of Mogref        [Use] Chants Mogref                         3,000
Dagger +2                                                          8,000
Mace -2                                                            8,000
Mace of Poison                                                    10,000
Mage Masher                                                       10,000
Slayer of Dragons                                                 10,000
Were Slayer                                                       10,000
Blade Cusinart                                                    15,000
Staff of Montino       [Use] Casts Montino                        15,000
Short Sword +1                                                    15,000
Long Sword +2                                                     20,000
Mace +2                                                           25,000
Rod of Flame           [Use] Chants Mahalito                      25,000
Dagger of Speed                                                   30,000
Short Sword +2                                                    30,000
Dagger of Thieves      Makes your thief a bad-ass Ninja           50,000
S-Sword +3 (E)         Evil Characters Only                       50,000
Shurikens              +1 HP Perm for Ninjas per use              50,000
Sword +3 (E)           Evil Characters Only                       50,000
Staff of Light         Chants Lomilwa                             60,000
Long Sword +5                                                     70,000
Priest's Mace          MASSIVE DAMAGE VS. PRIESTS!!!              75,000
Priest Puncher         MASSIVE DAMAGE VS. PRIESTS!!!              75,000
S-Sword Of Swings      Adds alot of Attacks for more Dmg :)       75,000
Staff of Curing        Uknown Effect                             100,000
Hrathnir               Price Based On Identification Cost        300,000
                       [Use] Chants Lorto
Muramasa Blade         +1 Strength to Samurai's per Use        1,000,000

Rod of Raising         Raises the Dead! [1 Use] [Kadorto]              0


Armor                                                             Price?
-----                                                             ------

Small Shield                                                          20  
Large Shield                                                          40
Robes                                                                 15 
Leather Armor                                                         50
Chain Mail                                                            90
Breast Plate                                                         200
Plate Mail                                                           750
Helm                                                                 100
Breast Plate +1                                                    1,500
Breast Plate -1                                                    1,500     
Chain Mail +1                                                      1,500
Chain Mail -1                                                      1,500     
Leather +1                                                         1,500
Leather Armor -1                                                   1,500
Plate Mail +1                                                      1,500
Shield +1                                                          1,500
Shield -1                                                          1,500
Helm +1                                                            3,000
Helm +2                                                            4,000
Gloves of Copper                                                   6,000
Chain Mail +2                                                      6,000
Plate Mail +2                                                      6,000
Shield +2                                                          7,000     
Breast Plate -2                                                    8,000
Chain +2 (E)           Evil Characters Only                        8,000
Helm +2 (E)            Evil Characters Only                        8,000
Leather -2                                                         8,000
Plate +2 (N)           Neutral Characters Only                     8,000
Robe of Curses         Gee, I wonder                               8,000
Helm of Malor          Chants Malor 1 time, then reverts to Helm  25,000
                       Mage Equippable :)
Shield +3 (E)          Evil Characters Only                       25,000
Helm of Curses         Gee I wonder                               50,000
Gloves of Silver                                                  60,000
Breast Plate +3                                                  100,000
Winter Mittens         Prevents Cold Damage                      140,000
Cold Chain Mail                                                  150,000
Plate +3 (E)           Evil Characters Only                      150,000
Robes +3               Who'd have thought this existed?          180,000
Shield +3                                                        250,000
Plate +5               Who'd have thought this existed?          275,000
Cursed Plate +1        Curses, but drops a Mage's AC BigTime!    300,000
K.O.D. Armor           Price based on identification cost        300,000
K.O.D. Gauntlets       Price based on identification cost        300,000
K.O.D. Helm            Price based on identification cost        300,000
K.O.D. Shield          Price based on identification cost        300,000
Garb of Lords          Lords only! Casts Madi! VERY RARE!      1,000,000



Stones                Effect                                      Price?
------                ------                                      ------
Stone of Piety        Adds 1 to your piety [Random Use Amount]         0
Damien Stone          Character Eradicator [Literally]                 0
Stone of Youth        Drops 1 Characters Age by 1 year                 0
Granite Stone         [Use] Chants Montino                             0
Dreamer's Stone       [Use] Chants Katino                              0
Mind Stone            Adds 1 to your IQ [Random Use Amount]            0
Blarney Stone         Adds 1 to your Luck [Random Use Amount]          0



Rings & Amulets       Effect                                      Price?
---------------       ------                                      ------
Amulet of Skill       Gives user 50,000 Experience [Random Uses]       0
Metamorph Ring        Makes ANYONE a Lord  [1 Use]                     0
Amulet of Jewels      Sell For Cash [Use] Chants Dumapic           5,000
Ring of Porfic        Chants Porfic Porficly.. er sorry :)        10,000
Amulet of Manifo      Casts Manifo                                15,000
Amulet of Makanito    Chants Makanito                             20,000      
Amulet of Cover       Gives a -3 A.C. Bonus                      120,000
Ring of Fire          Protection from Fire                       250,000
Ring of Life          Heals you 2 Hp per round                   400,000
Ring of Death         You wear it, you're cursed!                500,000
Priests Ring          ????                                       500,000



Misc                  Effect                                      Price?
----                  ------                                      ------
Coin of Power         Random Class Changer                             0
Wand of Mages         Gives all 9's for spells [VERY USEFUL]           0
Staff of Gnilda       Your Ultimate Goal                             Nil
Magic Charms          ???? Who uses them ????                    200,000


Quest Items           Effect
-----------           ------
K.O.D. Armor          Lowers A.C. by 14 / Slowly Raises HP/ Use for Matu
K.O.D. Shield         Lowers A.C. by 6 / Slowly Raises HP/ Use for Dial
K.O.D. Helm           Lowers A.C. by 4 / Slowly Raises HP/ Use for Madalto
K.O.D. Gauntlets      Lowers A.C. by 4 / Slowly Raises HP/ Use for Tiltowait
Hrathnir [Sword]      BEST WEAPON! [Lev. 27 Fighter hit a Greater Demon
                      6 Hits, 642 Damage!!! 642!!! Now THAT'S POWER!]
                      Also lowers A.C. by 1 [Go figure] / Use for Lorto



Part 5 - Frequently Asked Questions
===================================

Q: If one of my characters dies in the game right off the bat, is
   there any way to bring them back to life?  If so how?  

A: Yes there is a way, but you won't like the answer. You get a
   party together, or the remaining party members who didn't die,
   and heal them up. Go to the square where your character died and
   do a search. If you're on the correct square, and the alignment of
   the party members matches the dead character [Or you're all
   Neutral] you can pick them up and take them back to the surface.
   Go to the Temple of Cant and then gawk at the expensive price to
   revive your fallen comrade.

   In all honesty, you're better off pillaging the dead one and then
   making a new character. The Temple can screw up your fallen comrade
   by accident and cost you way more then you need to worry about so
   early in the game.

Q: Where can I find any of these games?

A: For the PC Versions, you can go to any good Computer store and pick
   yourself up a copy of the Wizardry Archives cd-rom at a decent price.
   I believe a Macintosh copy does exist, so Mac Fans, rejoice. If you
   want the old school NES Versions, I would recommend online gaming
   stores dealing in ancient games or pawn/used shops in your area.

   You could alternately go online and... no.. you would NEVER do that..
   considering it's illegal, immoral, carries a hefty fine.. etc.


Q: Where can I find the Roms?

A: You want to go the illegal route? Find them yourself as I can't
   help you.


Q: Where can I find maps for the game?

A: I am fairly sure there is at least a site or 2 on the net that has
   maps for this game. I personally have made maps for the First
   Trilogy, but only have Wizardry 1 scanned. I will be more then happy
   to email people them if requested, unless someone wishes to keep
   them up on their site for me. My connect is crap, so apologies for
   any delay in getting them to you.


Q: Can I switch my characters from Part 1 NES to Part 2 NES?

A: Sadly you can't, as there is no way to transfer the data from one
   Cartridge to another that I am aware of.


Q: Can you send me a copy of the Manual? I lost mine.

A: I'd honestly like to help you here... but then there's way too
   many people emailing me about this.. and with the roms floating
   around the net, it's virtually impossible for me to tell if the
   person asking me legitimately owns the game or they pirated the
   rom.


Part 6 - End Credits and Stuffage
=================================

 I hope this has been a great deal of help to anyone who has struggled
through this challenging game. Perhaps in a future revision I may add
a more or less completed items list, but since there isn't as huge a
variety as opposed to part 1, it's kind of doubtful. Anyways, good gaming
and see you in Scenario 3; The Legacy of Llylgamyn.

If you have any questions or comments, please direct them to me at;

K_Flewin@Yahoo.Ca
Attn: Wizardry

 Very special thanks to John Hubbard (tk421@tk421.net) for his assistance
in solving the Sphinx's riddle. I kicked myself so hard when I realized
how bloody obvious it was! 6 Years and I finally beat the game... it's
so reassuring.


 The solve you're currently reading and its subsequent updates [And
other solves/walthru's/guides/whatever I whip up] can be found at
the following sites :) I will constantly update for the sake of this
part, and because I believe the informed gamer should be aware of all
who wish to help the gaming experience :)


Game Faqs  [http://www.gamefaqs.com]

http://www.gamefaqs.com/computer/doswin/file/wizardry_ii.txt

Game Winners  [http://www.gamewinners.com]

http://www.gamewinners.com/DUO/Wizardry1And2.htm


DLH.net  [http://DLH.net]


The Cheat Empire  [http://home.planetinternet.be/~twuyts] 

http://home.planetinternet.be/~twuyts/xdown/wz2.zip


Al Amaloo's Video Game Strategies [http://vgstrategies.about.com]

http://www.gameadvice.com/cgibin/faq.cgi?game=w/Wizardry2-KFlewin.txt


Greg's RPG Realm  [http://www.rpgrealm.com]

http://www.rpgrealm.com/nesfaqs/wizardry_2.txt


Foraker's Page of Wizardry
[http://www.geocities.com/foraker.geo/wizard/index.html]

http://www.geocities.com/foraker.geo/wizard/wizardry_ii.txt


RPG Classics  [http://rpgclassics.com]

http://www.rpgclassics.com/database/wizardry2pc/1.txt


Games Domain  [http://www.gamesdomain.com] [And all mirrors]

http://www.gamesdomain.co.uk/solution/wizardry_ii_gd.txt   


Cheatsearch.Com  

http://www.cheatsearch.com/PC/unp90_20000501_00274.HTML  


Games Over  [http://www.gamesover.com]
http://www.gamesover.com/walkthroughs/wizardry2.txt



If you want to distro it, be my guest. As long as you don't edit this in
any way, unless permission is granted. You MUST ALSO Inform me of
which website you wish to add it to so I may add the link to future
updates and give my official OK. It MAY be editted to be displayed
on a web page only if my name is intact and I am notified so I may come
and marvel. :)

 It may be printed out... not like I could stop you :) Just please keep it
intact.

 Also, the walkthrough/solve for Wizardry 3 may be a while in the
making, as near the bloody start and I'm already perplexed! If someone
cares to explain how to get to Floor 2 [Since the one stair set goes
to Floor 3], what the hell to do on Floor 3 to avoid the warp traps and
make it to what seems to be the stairs, and advice on how to get through
the lake on Floor 1... I would not only greatly appreciate it, I will
also acredit you for the assistance.


Wizardry Copyright 1981-2002
Andrew Greenberg, Inc. and Robert Woodhead, Inc.
All Rights Reserved
Wizardry is a registered trademark of Sir-Tech Software, Inc.;
Reg'd TM Canada

This Walkthrough/Solve is Copyright Mr. Kelly R. Flewin, 1999-2005
                          Copyright Time Traveller's Inc. 1999-2005