ON BOARD SHIP

Pull knotted rope
Hit parrot with golf club
Get all items from tool box
Use plunger on chump
Use coin on screw
Put hook on loop
Chump gets on weight and Blount takes umbrella
Blount on hand and Chump on spring board
Take the tooth and get in the barrel
Use umbrella on barrel hole and cut rope
AFTER LEAVING SHIP

Use umbrella on hot air and look in the crevice
Use club on Herc and Gromelon
Give coin to Mac and use club
Make crumbs in helmet
Get behind Bonsai, put crumbs on him, use club
Give Kendo a hand and use club
Put shield on branch and use pepper on Zembla from behind
Chump on Django and Blount pulls tongue
Repair ladder and climb up
Chump on Punky and Blount pushes stone
DEATH

Use matches on rough stone toward top of room
Take scythe and use on 3 dens and the tube
Put spectacles on skull and open to get fire
Burn peg leg and put it out
Put fire in bowl and get cork from hand (Blount says it looks like a cork)
Use ladle on blood and put in bottle
Put bottle on pedestal for red fire, be sure to use the cork
Before picking up red fire, empty the bowl
Put red in bowl and use scythe on vampire
Yellow fire only and push button to get mirror
Add blue to yellow and put mirror in the hand
Take yellow out and add red to bowl, put spectacles on ghost
Put yellow back in bowl (blue, red, yellow)
AFTER LEAVING DUNGEON

Use hay on basin and then on fire
Use pitchfork on meat
Chump on lever and use hand on trap
Blount on lever and Chump leaps to mechanism
Talk to King
Talk to Princess
Put dolmen on thorns and talk to Knight
Get memorium from Knight
Take the engraved stone
Put coin in ear hole, memorium in basin, pitchfork in nose hole
ENTER TAVERN

Get sugar cube, put spoon on rock, Chump on spoon
Sugar cube on spoon, Chump on paprika, meat in paprika cloud
Put spiced meat on pitchfork, get coin and return to tavern
Chump on Customers', give sugar to customer
Plunger on cage and use leash, give coin to Othello
Use key on tiny door, Dragon gets paper
Talk to Captain, give paper to him for letter
Give key to Othello and stone to Korin (talk to her 2 or 3 times and maybe steal a kiss)
PEERING INSIDE KORIN'S MAGICAL KNOB

Get stick, helmet, powder, flint. Use flint on bark and fill helmet with glue.
Cut pan flute with flint, make bomb with tube-powder-wick-glue.
Use flint on rock, throw bombs at areas beneath Fourballus (brick, ledge, window, etc.).
Fuses can be gotten from small critter. Use flint on small tube, put Ooya near small critter.
Give new flute to Inca, put Ooya on condor so that Ooya gets bag of spells.
Blow up rock covering bamboo, Ooya makes bamboo grow, make big bombs.
Blow up everything beneath Ooya until he offers the last charm.
If you run out of fuses (wicks), Ooya can make the skull grow hair.
The girl is turned into a butterfly and Blount leaves for town.
TOWN

A WORD OF CAUTION! WHEN IN THE LAB, DO NOT MAKE TEARS OF JOY TILL THE THIRD POTION WHICH IS FLYIXIR.
Repair old ladies roof and talk to her, check the lever, store and young woman. She has a flower and a letter.
THE NEXT FEW LINES TELL ABOUT THINGS THAT HAS TO BE DONE, BUT YOU WILL HAVE TO THINK THINGS THROUGH FOR YOURSELF. THE GAMING SPIRIT, YOU KNOW!
Hot water bottle on boucassier egg, growixir on baby bird, Fulbert can bridge the gaps for you,
speedixir can get you around the rooftops in a hurry, use decoy inside bell and run touch boucassier (which should now be fully grown), run down and catch feather before it falls into the sewer.
Ride cannon ball up to get sole, use growixir on bud and plant so that Fulbert can climb, place letter in front of mirror twice.
LAB

THERE ARE SOME PAPERS AND A RECIPE BOOK THAT BLOUNT SHOULD REFER TO.
Right hand picks up, left hand pushes buttons, turns knobs etc. Growixir goes in first bottle, speedixir in second bottle, flyixir in third bottle (1, 2, 3 - left to right).
Distilling done in the still, burning in ashtray, cook in kettle, pestling in mortar. Memorium yields tears of joy (not till you are ready for flyixir).
Soap bubble made by soap in basin of water and key dipped in soapy water, held in front of fan started with coin.
STORE

Give coin and letter to grocer
Take egg and key
Open moon lamp
Throw cupboard and jump on it from cornice.
Get decoy from storage cabinet, jump on sofa spring, get horn, hit grocer with hammer.
Take everything you can.
Fulbert gets soap when Wolfy lifts crate. Fulbert pushes button, Wolfy uses hammer on trap door. After Blount gets wings, he ends up where some balloons and a balloon pump are.
GEYSERS AND BALLOONS

Balloons move Ooya around. Move basket over goat by weighting it and cutting ballast to knock out goat. Colossus and machines are at the exit to the left. You need the spy glass which can be taken with the fishing pole. Put Ooya by the giant, pull cloud with fishing pole, Ooya on balloon, pierce cloud with knife.

Ooya on silent geyser, Blount covers an active one, Ooya gets in basket when it is straight up. Cut off ballasts until Ooya jumps off at glacier. Use spy glass on speck, use Ooya on speck, take Bizoo. You can catch a sawfish but you need the bate which is in front of colossus and his machine.

COLOSSUS

Ooya on catapult, Blount looks in telescope, Ooya causes worm to appear from cheese. Blount on catapult, Ooya touches ships, Blount gets worm. Knock off Colossus's helmet with rock from catapult. Use sawfish on column holding hammock. Detach Blount's shadow using Ooya, put Bizoo on Colossus's face.

Get tooth pick inside loose tooth, use on closed eye, look in that eye to see grain of sand. Enter right ear, pull nose hair, kick sand at tear, use tooth pick to knock out fleas (junior, brother, two sisters - the right one first, woman, and man flea). Make another tear and ride it. Kick sand off. Shadow picks up sand and puts it in the machine gears.

Ooya launches another ship, shadow puts gear in robot that has been opened with a sharp instrument. Shadow puts pollen on face of Colossus, Bizoo puts tooth pick in right nostril, jumps on nose. When hand appears, Bizoo jumps on nose again. Put pollen in left ear and jump on collar to force pollen into the ear.

AN AUDIENCE WITH THE QUEEN

Talk to queen, use hammer on guard, kiss queen, bet wand. Fulbert makes candle fall, Fulbert on dish, Wolfy hits veggies, Wolfy jumps on stationary chandelier, get fennel by the pot, Wolfy stands at left bookcase and under the glasses, Fulbert climbs colonnade then runs to flagstone to catch glasses.

Wolfy uses glasses to get onion, light the candle in the three holders (middle, back, front) with the wand. This opens the fountain.

KING

Give Tibo the gun, give the King a hand, use fennel on Rock Steady, Fulbert climbs spear and moves chandelier, Blount on other one. Talk to Wynnona, onion to Iron Head, take axe, dish from table, give wand to Buffoon. Fulbert makes roach appear from hole, when King tries to hit it, use dish on Buffoon and take the slipper. Open the fountain by using wand on candles (M B F).

Use coin to decide to go back through.

BACK AT THE QUEEN

Give slipper to Queen, put axe in pot on mantle, hide in fireplace, Fulbert causes skull to fall, cook hits string with axe, return skull to the King.

CHESS BOARD:

You will arrive at the chess board. Do not do anything here yet. Go immediately to the Big Book Room.

BIG BOOK ROOM

In a couple of locations, a spider scares Wolfy. If Fulbert is near, Wolfy has no trouble with the spider. Wolfy should talk to the face on the book.

Use Fulbert on web to get Wolfy past spider. Use axe on wooden ruler to get a block.

There is a book on sculpting and one on drawing that Wolfy should read.

On the left is a book with some arrows. If Wolfy jumps on them 2 or 3 times, they will fall on the floor. Take the arrows.

Wolfy stands facing a sheet with numbers and under a dust pile. Fulbert hits the dust and Wolfy should sneeze. If Wolfy has trouble sneezing, stand away from the numbers and walk into the dust cloud. Ignore the zero. Take all the other numbers and put them in the ink well. The six is on a hook at the upper left of the screen.

The spider has one of the numbers! How does Wolfy get it?

If Wolfy stands near the spider, Fulbert can do something to enable Wolfy to scare the spider away. Actually, Wolfy changes back into Blount just for a second or two.
Have Fulbert cover the moon while Wolfy stands close to the spider.

The number eight seems to be missing! Where is it?

Wolfy will have to draw the eight on a sheet of paper.
You need a block of marble from the wagon in the picture. It needs something for a wheel and no it is not the zero! It's an ox cart so I guess you'll have to draw an ox since it's an ox drawn cart! In the story book, give the arrows to the bowman. There's a tiny horse in this room. Give the horse to the knight. Draw notes on the house twice to get a small mandolin. A brush dipped in ink is good for drawing and painting.

CHESS BOARD

Draw outlines on a block of wood and a block of marble using chalk and a compass. A hammer and steel chisel sculpts marble. A hammer and wood chisel sculpts blocks of wood. Dip the sculpted pieces in paint and use the brush to finish them.

To start the game, put the pieces on the board and click a square that says Chess Board.

The rules of the game are on a sheet of paper on the back wall.

Lover and Killer move one square at a time in any direction.
Bowman one square diagonally on green.
Knight moves as in regular chess but avoids snakes.
Killer attacks King diagonally.
Killer must eliminate the King.
Lover must enter the tower.
Use the Bowman on the Lancers and the key. Put the lover on the square with the key. Put Killer on the square with the lever. He pushes it, getting rid of the guy with the axe. On either side of the King is a hidden soldier. Only the Knight can get rid of these. The King must be trapped and Wolfy kills him with the axe.

Juggle the balls with both hands and click the bank to break it. Put a coin in the bank and play the big mandolin wrong handed to hypnotize Othello. Put him on the blue square in front of the Chaperon to get him out of the Lover's way. When the Lover is properly positioned, he can play the tiny mandolin to call the princess. He will then use the key to enter the tower once he is invited.

MIRROR ROOM

Blount, Fulbert and Wolfy must call the dragon and make it big. This way, Blount can get through obstacles and carry the chicken to unreachable heights.

Put the egg in the time mirror, pass the chick to the reflection, put chick in thinning mirror, thin chick in small hole, thin chick in fattening mirror twice, fat chick in big hole, fat chick in thinning mirror once, chick in time mirror, chicken in fattening mirror.

BRAIN ROOM

Wolfy is strong and can move levers and get things unstuck. Get speck of sand from Colossus in the memory window (Wolfy hates Colossus). Wolfy and Blount rides the wagon to reach the lake. Wolfy jumps in the lake. Put grain of sand in lake (the sand is reusable). Jump on bubble, ride fish to get the decoy.

Make the plant grow so that Fulbert can climb it, use the decoy on the open window. Make the dragon big, use decoy on fence. Check the box (chest). Use the decoy on the puddle of dreams.

How can the fat chicken get to the grain?

Blount could catch a ride.
Pick up the grain of folly.

MIRROR ROOM

Reset the clock by reversing the chicken routine. This awakens the Demon. Use the grain of folly on him.

Why can't the reflection pick up the ugly ointment? He must pass the chick back to Blount.

At the mirror on the far left of the room, use beauty ointment on mirror of beauty, when Blount is pretty, use ugly ointment on the mirror of ugliness.

THE GODS

Wolfy needs a way to reconcile the two poles of divinity.
Angel and Demon must play a duet creating music for the note of harmony.
Talk to the Positive pole. Pick up the piece of thread.
Use hammer on wall and axe on fence.
Ring left door bell then the right one.
Jump on the chain that is stretched.
Put music score into the spring.
Ring door bells (left then right) and jump into empty spring (basin).
Talk to Demon.
Put red sheet on Demon music stand.
Talk to Angel.
Put yellow sheet on Angel music stand.
Use coin on Angel halo and hammer on Demon cloud.
Put thread on the two notes.
Ring the door bells (left then right).
The notes should become one
 