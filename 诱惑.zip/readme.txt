Lure of The Temptress
---------------------

Complete solution:

The jail:

Pull the torch on to your bedding and stand in the bottom left-hand corner
of the screen. When skorl comes in leave the room shut the door and lock
it. Speak to Wulf who is prisoner chained against the wall and then go
through to the guard room. Pick up the green bottle. Look at the barrel at
the left of the room and use the bottle on the tap. Pick upp the knife from
on top of the barrel. Look at the sack on the right and use the knife on
the sack. Look at the sack and Dermont picks up a coin. Go back to Wulf.
Give him the bottle and he tells you af an escape route.

Go through the guard room to the torture chamber and use the knife to cut
the cord that's tying Ratpouch to the rack. Tell Ratpouch to go to the
outer cell and push the bricks in the wall. When he goes off follow him
through the hole in the wall and down the sewers into the village.

Turnvale - rescuing Goewin:

Walk through the two exits and you find yourself at the castle gates. Walk
left to the apothecary then left to the castle walls. Then down to the
monks house. Left to Ewan's shop. Left to the Severed Arms and then down.
The opening on the left is the blacksmith's. Go inside and talk to Luthern.
Tell him you've escaped from the skorl. Pick up the tinderbox from the
floor at the front of the screen. Go to the Magpie Tavern which is below
the monk's house. Talk to Morkus. Bribe him and he tells you Goewin was
taken prisoner.

Leave the inn and find Mallin who is the guy in the green jacket - this
might take some wandering around. Talk to him and ask him to tell you what
you have to do. Take the bar to the shop and give it to Ewan. Go back to
the Magpie. Talk to the barmaid and give her the gem. Go to the
blacksmith's. Talk to Luthern and then give Luthern the flask. Speak to
Grub - the beggar on the pavement outside the Magpie Tavern. Go back to the
Severed Arms and speak to Edwina who is sitting knitting at the table. Ask
her is she's seen Taidgh. Now examine the diary.

Go to the market place outside Ewan's shop. Give Ratpouch the lock-pick and
look at the door on the right. Wait for the skorl to walk past and notice
that there is a long gap and a short gap between his appearances. At the
start of a long gap tell Ratpouch to use the lock-pick on the lock on
Taidgh's frontdoor. Open the door go inside and examine the apparatus. Use
the tinderbox on the oil burner and after some steam is let off use the
flask on the tap.

Drink the flask and then go off the top of the screen to the skorl who is
guarding the gate. Talk to him. Open the door and walk through. Talk to the
left-hand skorl and then leave with Goewin. Follow her to the apothecary.
Talk to her. Stooge around until the potion wears off and then talk to her
again.

Turnvale - the dragon:

Go to the monk's house and read the notice on the wall. Find Malin. Talk to
him and say: 'Yes certainly.' Take the book back to the monk's house. Give
it to the fat monk and talk to him about the smell - he gives you some
herbs. Talk to the thin monk about defeating Selena and remember the three
herbs - houndstooth cowbane and elecampane.

Go to the blacksmith's. Talk to the old dear in the rocking chair and give
her the sprig of herbs. Go out of the blacksmith's and in the garden to the
left there are some flowers. To the right of the two red flowers there is
some cowbane. Pick it up. Go to the apothecary and talk to Goewin. Ask her
to make an infusion of cowbane houndstooth and elecampane. Then find Gwyn
and talk to her - she's the lady in the red hat. Go to the shop and talk to
Ewan then go back to the apothecary. Talk to Goewin and ask for the potion.

Go to the Severed Arms and talk to Ultar then go to the Weregate and talk
to the Gargoyle. Go back to the apothecary. Talk to Goewin and then go back
to the Weregate and talk to Goewin once again. Now go through the gates.

Exploring the caves:

Pull the right-hand skull. Go through into the green cave and then into the
entrance cave. Talk to Goewin. Tell her to go back to the green cave and
follow her there. Tell Goewin to back to the entrance cave and pull the
left-hand skull. When the door opens go into the blue cave. Pull the
right-hand skull and then the left-hand skull. Wait until Goewin walks in
and tell her to go into the green cave and pull the right-hand skull. Go to
the left when the door opens. Go up and kill the guard. Go left and use the
potion on the dragon straightaway. Talk to the dragon and order it to help
you. Go into the blue cave. Pull the left skull and go to the green cave.
Pull the left skull then go back to the entrance and leave the caves.

The castle:

When you've left the caves talk to Goewin and then find Mallin and have a
chat with him. Go to the market place outside Ewan's shop and wait until a
skorl goes in. Look through the window and watch Ewan and the skorl's
conversation. Wait for the skorl to leave and then go in and talk to Ewan.

When you arrive in the cellar look at the top cask in the stack of three in
the bottom left-hand corner of the screen. Go into the kitchen and look at
the carcass. Take the fat and the tongs and go back to the cellar. Use the
tongs on the bung on the cask. Go into the passage and wait for Minnow to
walk past. Talk to him and tell him to tell the skorl that there is a leaky
cask in the cellar. Leave the kitchen on the right. Walk up the steps to
the balcony. Wait for the skorl to go through the door and after a short
while go back down the stairs. Walk through the room of drunken skorls and
into the gate room on the right. Use the fat on the lever. Go back into the
room of the drunks and tell Minnow to go to the gate room and pull the
lever. While he's pulling the lever operate the winch. Go back through the
room of drunks up the stairs along the balcony and up the steps on to the
drawbridge. Kill the guard. Walk to the left and get ready to watch the
finale.