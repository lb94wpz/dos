MYSTERIOUS SONG (TurboGrafx-16 version)
COMPLETE WALKTHROUGH
v1.0 by Rainy_Eyes

MYSTERIOUS SONG is (C) 1999 Darkness Ethereal, (C) 2012 Frozen Utopia

00. INTRODUCTION

Mysterious Song is an old-school Dragon Warrior-like console-style RPG for the
TurboGrafx-16 CD SUper System. It is a SuperCD game so you'll need a TurboDuo or
a System 3 Card to play it. It also runs on the Japanese equivalents.

01. GAME MODES

When you first start the game, you have the option to play in Original or
Balanced mode. Original uses all of the formulas and algorithms of the original
MS-DOS version of the game. Balanced is a somewhat more "fair" version of the
game; leveling doesn't take as long and battles are not quite as hard.

02. HOW TO PLAY

The game controls like any ordinary RPG. Use the D-pad to move around and to
navigate menus, the II button to talk to people and confirm menu selections, I
to cancel menu choices, and Run to bring up the game menu. Holding I while on
the map also allows you to run around, even on the world map.

03. CHARACTERS

-MAJOR CHARACTERS-

*SPEAR*
Spear is the main protagonist of Mysterious Song. He is a young man who has just
finished his training to be a Toren Knight. He is haunted by a voice in his head
in the opening scene; the voice of Grimm. Spear seems to have a minor case of
retrograde amnesia, which is made apparent when he returns home.

Spear is able to use magic spells, but his main form of offense is swordplay. He
is a capable fighter but makes a decent backup healer. He is also the only one
able to summon spirits. Aside from his summoning, it's best to leave the
offensive magics to Ryanna and rely on Spear's physical strength to get the job
done.

*TIGER*
Tiger is several years older than Spear and is an experienced, battle-hardened
Toren Knight of unrivaled strength and loyalty. He immediately follows the
direct order of the king and joins Spear.

Tiger is your standard battle tank; high HP and attack strength, low magic
defense and absolutely no magic spells whatsoever. This also means he'll be the
first one to be Poisoned or Diseased, and will always take the most damage from
magic spells, but he will dish out the most punishment to the enemies and can
withstand the largest amount of physical damage.

*RYANNA*
Ryanna is a strong magician from the town of mages, Illus. The knowledge and
wisdom of Illus is prized by the king. Thus, Ryanna will help the mission. She
has a secret of her own that is alluded to in the storyline but never really
explored; maybe it was to set up a sequel?

Although she can use a sword, Ryanna's main strength lies in her ability to cast
spells. Her X-magic becomes very powerful as she grows in level. For a magician,
she actually has rather good HP, although her physical strength and defense are
lower than the two knights. She reaches 99MP way before Spear does.

*GRIMM*
Grimm makes his presence known from the very beginning. He is a god-like being
who becomes obsessed with Spear. He hates all other humans and sees them as
nothing more than a plague on the world. He uses his power to create monsters to
attempt to wipe humans off the face of the planet.

One interesting thing about the relationship between Spear and Grimm is that of
chaos and order. Normally in these kinds of games, the "heroes" are portrayed as
"order" and the "villians" are portrayed as "chaos". Here, that relationship is
reversed; Grimm is "order", and Spear is "chaos". That's why Grimm can't figure
him out; Spear's mind is one of constant turmoil, and this both infuriates and
fascinates Grimm. Grimm portrays all humans according to songs, but can't quite
figure out what kind of song Spear is. By the end of the game, Spear figures it
out for himself.

-MINOR CHARACTERS-

*KING ALGAMETH IX*
King Algameth IX is the monarch of the Toren Kingdom. He entrusts Spear with
this important mission.

*ELLIA*
Ellia is Spear's mother. Up until Spear finds her, he never mentions her at all.
She is the one who leads him to the Tower Of The Gods.

*DYONN*
Dyonn is the Toren Kingdom's master-at-arms. He trained Spear to be a knight.

*ARK*
The carpenter of Nemar. Ark can build anything... as long as he has his tools.
He opens the way to the Tower Of The Gods.

*OGIEN*
An ancient fire spirit who aligns himself with Spear. At first, it's not really
known *why* he does this, but it's revealed at the start of EX Game that he does
this so Spear can take him to "The Gathering", a place where the spirits are
supposed to come together as one.

*VYPER*
He is an assassin under Grimm's command. It's assumed that he was responsible
for the destruction of Nemar, as he's the one who holds Ark's tools.

04. BEGIN YOUR ADVENTURE

You started out in Toren Castle with a conversation with Dyonn. Once he has said
his bits, go upstairs. Just walk around the second floor to meet King Algameth
IX and collect 200GP to start your journey with. King Algameth IX instructs you
to go to the East, to a town called Fawna, to enlist the aid of a knight named
Tiger. Go back downstairs.

It may be wise to purchase a better weapon at this point, but it's up to you.
You can get the Long Sword for 100GP, but you can't afford the Chain Mail right
now. Purchase the sword if you'd like, and pick up a few Herbs as well. Even
with the better sword, enemies can be tough for a couple of levels. When you're
all set, visit the Inn and save your game (you don't need to stay to save), then
exit Toren Castle.

05. ENTERING COMBAT

Once you leave the castle and start traveling on the world map, you will be
occasionally attacked by creatures. Battles are randomly constructed from a
pool of specific enemies. Once the screen wipes out black from the right, you're
about to fight.

Just starting out, Spear has a few options against his enemies. The most obvious
one is Attack, and is the one you will be using the most this early. This is a
normal melee attack with your equipped weapon. Magic allows you to use the
character's magic spells. Spear has Heal to start with, which is a basic spell
for restoring HP. Item allows you to use items, such as the Herbs you should
have bought earlier. An interesting thing here is that you can also use Item to
equip weapons and armor. Finally, Flee lets you attempt to flee from battle.
This is based on the agility factors of the enemy party versus your own. One
detail here is that for each time you attempt to Flee but fail, you get a boost
in your chances. So you will be able to Flee eventually, if not right away.

Around the Toren Castle area, you will only run into the Slime and Birdmask
enemies. Both are rather weak, but they can all be tough in a group of three
until you get Spear's level up a bit.

06. UNDERSTANDING CHARACTER STATUS

-Healthy: The character is just fine. The battle text is "OK".
-Poisoned: The character will lose HP for each turn of battle (10HP per turn)
 and for each step on the map (1HP per step). The battle text is "Psn". And yes,
 you can die on the world map from the Poisoned state, so Cure it as soon as you
 can, either with the spell or with a Remedy. If someone on the map is Poisoned,
 Spear will appear to have a purple face.
-Diseased: This odd condition doesn't do any damage, but it does have two
 effects on the character: their attack power is cut in half, and they cannot be
 Healed. Cure and Remedy will take care of this condition. The battle text is
 "Sick". If someone on the map is Diseased, Spear will appear to have a green
 face.
-Dead: The character is dead and cannot act. Their battle portrait goes black.
 If everyone is Dead, it's Game Over. Dead can be reversed with a Revive item,
 or with a Revive spell. Spear and Ryanna both get Revive, but only Ryanna gets
 X-Revive, which is resurrection + full health.

07. MAKING IT TO FAWNA

Once you approach the area where Fawna is, the enemies get tougher. You'll run
into Birdmask's tougher, yellower cousin, Birdman, as well as the Thief. As long
as you can handle these somewhat stronger enemies, you'll make it just fine.

There are just a few things to do in Fawna. Obviously, your main goal here is to
recruit the aid of Tiger, who is in the house to the lower right of the town.
You can also do some shopping at the tool shop to the lower left. It might be
wise to pick up a Chain Mail now, and it's 20GP cheaper than in Toren Castle.
You will also get a small discount on Ether here, although Herbs are slightly
more expensive. This is the first time you'll be able to purchase Remedy as
well. Unless you can really afford it, skip buying the Iron Suit for now.

When Tiger joins, he will be at the same level as Spear, with the minimum amount
of experience to have that level. So, if you reach Tiger at level 8, Tiger will
also be level 8. Stay at the Inn and save if you need to. Your next mission is
to head North, to the Illus Pass.

08. INTO ILLUS PASS

As you travel North, you will run into more powerful enemies. The Knight and
Watcher appear here, and both are considerably tougher than what you've been
dealing with up until now.

Once you reach the cave, Tiger will move the rocks away with his bare hands. You
are now free to enter the cave.

Inside Illus Pass, you will meet two new enemies, Cutthroat and Wyrm. Watcher
can also be found here. The way through this area is rather straightforward. If
you see what appears to be a man in flames, avoid him for now; this is Ogien, a
powerful fire spirit. You are unlikely to be strong enough to deal with him now;
we'll see to him later. Follow the trail upwards until you reach the end of the
cave. There are no treasures or secret events to find here; it's just a cave of
evil things.

09. MEGA WYRM

Mega Wyrm is your first real challenge. It has 360HP and can use Poison. Tiger
is the stronger fighter, so let him use his physical attacks to beat down the
creature, and use Spear to use Cure or Remedy for when someone is Poisoned, plus
healing items or magic when someone is low on HP. Mega Wyrm is not too much of a
threat as long as you come prepared. Once it is defeated, you can leave Illus
Pass.

10. TO ILLUS

The town of Illus is just slightly North of the top exit of Illus Pass. You will
find some new enemies in the area around Illus, namely the Cursword and the Evil
Mage. Wyrm can also be found here.

Once in Illus, your main mission is to locate Ryanna, who will join your party.
She is in the northeastern part of the town. You can also do some shopping here.
Illus has the best purchasable equipment in the game, and the Iron Suit has
dropped in price considerably. If you can't afford a full set of Magic Mails for
everyone, at least get some Iron Suits, and as many Magic Swords as you can
afford for them. You can always come back to this town later to finish getting
all of the equipment you need. For now, however, stay at the Inn and save, then
head towards Nemar. To do that, you will need to backtrack through Illus Pass
and head to the rock near where Tiger cleared the rubble. Ryanna can clear this
one.

If you passed up Ogien on the way to Illus, this is a good time to fight him.
Ogien has only 240HP, but he has powerful Fire magic that would have toasted
you earlier. With Ryanna along now as well, this battle will go very easily.
Once Ogien is defeated, Spear will now be able to cast Summon Ogien, a very
powerful, but MP-expensive, Fire-based spell that hits all enemies on-screen.
The most interesting part of Summon Ogien is that it is a Piercing-type spell;
it ignores the defenses of its targets and always delivers the same damage.

11. WJATR'S LAMENT

This oddly empty maze is filled with enemies you have already faced before. It
is also the first time you will find Mega Wyrm as a regular enemy. It still has
all the same stats as it did when it was a boss, and can now come in multiples.
That also means that it is also worth as much XP and GP as it was worth back
then, and by now, you should be able to mop the floor with it, making it an
excellent farming monster. Once you see Woda, a blueish spirit just standing
around, you are almost to the exit. Nemar is next.

12. NEMAR AND ELLIA

Nemar is slightly south of the other side of Wjatr's Lament. Once you enter the
town, there is a short cutscene, and things to explore. There are two main parts
to Nemar: Spear's mother, and Ark's mission. Spear's mother can be found in the
northeastern corner of the map, and Ark can be found just south of there. Find
Spear's mother first, then go talk to Ark to be sent on a mission to reclaim his
stolen tools.

There is a shop here, but it does not sell anything new, being in a ruined town
and all. Not much else to do here except stay at the Inn and save.

*IMPORTANT NOTE* Once you enter Nemar, random encounters in the Illus Pass stop
happening. This means that you can walk through it unopposed; very helpful if
you want to go back and finish purchasing equipment.

The new enemies outside of Nemar are Armless and Jellyeye. Neither should be all
that tough anymore. There are two things you can do at this point: walk to the
path to the South to go after Ark's tools, or head North to view the Tower Of
The Gods. In a rather Final Fantasy type of arrangement, the top few spots of
the region up there will yield some monsters more powerful than you've faced
before, namely the Frost, Sprite, and Venomous enemies.

13. NEMAR CAVE

Nemar Cave has two floors. Walk downward to the bottom, then the path goes to
the right, then back up. Hit the stairs to reach the second floor. Once on the
second floor, taking the south path will lead to more treasures, while the left
path will lead to Vyper and the Dark Knights.

New enemies on the first floor include the Cave Demon and the Clay Man. The
Jellyeye can be found here too. The second floor introduces Skullman and Toxic
Liz.

Vyper and the Dark Knights can be difficult if you're not prepared. Summon Ogien
will work very well in this battle, if you can keep Spear's MP up with Ethers.
Vyper can use Thunder magic, and has a strong physical attack as well. Focus
Tiger's attacks on the Dark Knights, and use Ryanna's X-spells on them as well.
Once they're out of the way, Vyper is easier to deal with. Just pound him with
Spear and Tiger, and use Ryanna to heal. Once he goes down, you'll win Ark's
tools. Don't forget to claim the extra treasure.

Once Vyper is beaten, random encounters in Nemar Cave stop, and you can leave
this area unopposed. Now, return to Nemar, and give Ark his tools back. Now, you
can challenge the final area of the game, the Tower Of The Gods.

14. THE TOWER OF THE GODS

The tower is divided into five floors. The first floor is home to a new enemy,
Night Devil, as well as Armorskill and Venomous. This floor is easily passed.

The second floor is where things start to get a little longer. You can find a
Magic Sword and Magic Mail on opposite sides of this floor. This floor brings
out new enemies Divine and God Beast. Divine can use Thunder magic, so be aware.

The third floor is where things get really interesting. You can go three
different ways here. To the right will win you another Magic Sword and Magic
Mail combo, plus a Revive. Going to the left will take you to a long passage
that eventually leads to a treasure trove on the fourth floor, where you can
find the unique Suit Of Ages, the most powerful armor in the normal game. There
are three of them up here, one for each of your characters. You will also find
the *only* Chaos Sword in the game here that can be gotten from treasure. Once
you have all the goodies here, go back down to the third floor and take the
northern path to fight Gregor, God Of The Undead.

Gregor has 900HP and can use Fire, but is otherwise not going to be much of a
threat. If you've made it this far, you are strong enough to handle him. Once
Gregor is defeated, the "proper" fourth floor is available.

*IMPORTANT NOTE* Once Gregor is defeated, random encounters in Wjatr's Lament
stop, and the appearance of Nemar changes somewhat.

New enemies on the third floor include the Evil Witch and Gruesome, a poisonous
creature. The fourth floor adds Valkyrie and Marauder. Marauder is worth a solid
amount of XP and does not use magic, so it's a good enemy to fight for last-
minute farming. Once you reach the fifth and final floor, the only enemy to
fight is Marauders, so farm away. Once you're ready, walk to the top of the
fifth floor to meet Grimm.

15. THE FINAL BATTLE

Grimm has 2700HP and is both physically and magically powerful. You can pull out
all the stops on this one in regards to items, because this is the final battle.
Spear can Summon Ogien for consistent damage, and Ryanna can use her X-spells
as long as her level is high enough. If Tiger is strong enough, his attacks can
help, but you may just want to use him as an item-user and rely on Spear's
summon and Ryanna's magic. Grimm can use Thunder, and his magical attack power
is very high, so watch your HP. Once Grimm goes down, the game is over. Enjoy
the ending. :)

16. BUT WAIT... THERE'S MORE!

If you play the game in Original mode and acquire Ogien, the special EX Game
will become available to you in the Extras menu. You'll know that the mode has
been unlocked, as the game will give you a screen mentioning it right after the
credits have scrolled. The storyline changes somewhat, and Spear has his Summon
Ogien spell from the very beginning. EX Game plays with the Original algorithms,
but you'll already be used to that since you have to play in Original mode to
open it to begin with.

You cannot unlock EX Game in Balanced mode, even if you acquire Ogien. You have
to do it in Original mode.

17. THE EX DUNGEON

Play through the game as you normally would. When you go through Wjatr's Lament,
you will notice that Woda is no longer standing there. Tempted to go in? Don't;
at least not yet. Keep playing as you normally would. Play until you have
beaten Gregor in the tower before attempting the EX Dungeon.

Once you are sure you are ready to conquer this massive and difficult challenge,
re-enter Wjatr's Lament and attempt to get to the stairs that Woda was standing
in front of when you played through before. You will be stopped by Wjatr, one of
the four elemental spirits, who will attempt to kill you.

Wjatr has 2500HP and will attack with Thunder magic. Wjatr is not weak to any of
your spells, since you have nothing Earth-based. If you can take him down, the
first level of the EX Dungeon becomes available, and you win yourself a hefty
1000XP.

18. WODA'S ENVOI

The first challenge in the EX Dungeon is this freezing ice cave. Be careful of
the ice spikes along the floor; they will damage your whole party. There are
times when they are unavoidable, however.

There are two exits to the first floor of this top level. Find either of them to
enter the nightmare of the random dungeon. You will go through six randomly-
selected floors, fighting a host of enemies you've already conquered before.
Frost, Watcher, Armless, Wyrm, Evil Mage, Cursword, Cuttroat, and Mega Wyrm can
all be found here. Once you pass six floors, you'll reach the final floor of
Woda's Envoi. Depending on which way you entered from the first floor, you'll
come out on opposite sides of this map. Either way, head to the middle and find
your way up to meet Woda.

Woda is a water spirit and is basically just the water version of Wjatr. She can
use Ice magic, but is vulnerable to Fire, especially Ryanna's X-Fire. You should
be quite strong at this point, so Woda won't pose much of a threat. 1000XP is
after this battle. Once you have cleared this point, random encounters in Woda's
Envoi stop altogether.

19. ZIEMJA'S CANTICLE

Once you enter Ziemja's Canticle, you can talk to the spirit to immediately
escape the region, back to the start of Woda's Envoi to leave. It might be a
good idea to do this, so you can return to Nemar so visit the Inn, save, and
stock up on items if needed. The spirit in Woda's Envoi can also send you right
back to Ziemja's Canticle, so you don't have to do all that walking again.

There is only one path through the first floor here, so find it and enter the
depths. This time, you will face eight randomly-chosen maps. The enemies in this
area are the Valkyrie, Cave Demon, Gruesome, Divine, God Beast, and Night Devil.
During your travels, you may come across a treasure chest. This is actually a
relatively complex puzzle; you can attempt to solve it now, or wait until later.
Either way, it's completely optional and you can finish EX Game without doing
it.

Once you have passed eight floors of hell, you'll be on the final floor of
Ziemja's Canticle. Work your way to Ziemja's room and face the leader of the
elemental spirits.

Ziemja has 3500HP and attacks with Disease. He is weak to Thunder magic, so have
Ryanna pound him with X-Thunder while Spear and Tiger attack and keep her MP
high. You'll earn 2000XP for taking down Ziemja, and as before, the region will
stop having random encounters.

20. OGIEN'S PERORATION

Be prepared for one of the most obnoxious areas in the game. Be SURE to use the
spirits to exit, save, and restock.

There is one treasure chest in this area that is closed. It is easy to reach,
and its contents are splendid: it contains Impervious, an extremely powerful
piece of armor. It gives you an incredible 250 defense AND magic defense. This
may be best placed on Tiger, but it doesn't matter who you put it on since it
will turn anyone into a nearly invincible wrecking machine.

Ogien's Peroration is only three areas, but the middle one is especially tough.
By itself, it is a mind-numbing maze, but it also contains Dragons, the game's
most powerful regular enemy. Fortunately, they will only come one at a time,
but virtually always with other enemies to make things harder. Having Impervious
makes your chances of surviving these encounters much higher.

Once you make it through the dangerous maze, you'll be in the final area of this
region. Find your way to the rightmost side of the area to face all three of the
elemental spirits at once.

The fight against the trio of elements may or may not be tough, depending on
your levels. They still have the same stats as when you faced them individually.
Interestingly enough, Summon Ogien works just as well here as it ever has. When
the battle is won, you'll get 4000XP but the spirits will take Ogien with them.

LEAVE! Trust me... use the spirits NOW. Escape, heal and stock up, and save. If
you want to do the optional puzzle for Ziemja's Canticle, this is a good time to
do it. Otherwise, go on... because once you enter the next area, you can never
leave it.

21. CACOPHONY'S REFRAIN

This is... Nemar?!

This place looks like Nemar did before it was destroyed by Vyper and his goons.
It's as if you'd taken a step back in time. You can't save at the Inn, and the
store does not sell you any items. The goal here is to find Spear's past self;
you can find him at his mother's house, of course. Talk to him to engage an
event. All the townspeople disappear. Leave to the south and follow a newly-
opened path to the right. There will be some conversation as you follow this
path. Once you reach the end, you will find all four spirits. The ground will
change, and then the spirits will all merge together to form the true final boss
of Mysterious Song, Cacophony.

22. THE TRUE FINAL BATTLE

Cacophony is the combination of all four elemental spirits into one big, insane
death-dealer. It has 9999HP and incredible physical and magical strength. Its
main problem is in the fact that it can change forms at will; the background
will tell you what form it's in:

-Purple: Air form. Cacophony has no weaknesses in this form. He can use
 Lightning Bolt, which is pretty much the same as X-Thunder.
-Green: Earth form. Cacophony is weak to Thunder in this form. He can use
 Plague, a Disease-based spell that will hit everyone.
-Blue: Water form. Cacophony is weak to Fire in this form. He can use Ice
 Smash, which is essentially X-Ice.
-Red: Fire form. This is arguably Cacophony's strongest form. He can use Fire
 Storm, which is essentially Summon Ogien. He is weak to Ice in this form.

Another problem with fighting Cacophony is that if you use healing magic, he
will siphon it as healing for himself. So, everyone will be healed. Siphoning
healing magic may also change his form. Finally, his physical attacks can
inflict Poison status in addition to normal damage.

If you can manage to waste his 9999HP, you're rewarded with an alternate ending,
as well as access to the hidden bonus game from the Extras menu.

23. WHAT ELSE IS THERE TO DO?

There's a few optional things you can do in the game, either for completion's
sake or to become even more powerful.

24. THE ISLE OF DRAGONS

To the east of Illus is a small island that is crawling with Dragons, the most
powerful non-boss enemy in the game. They have 999HP and extremely high magic
attack strength, as well as physical defense. One use of Fire can take anyone
out much of the time as they shrug off your sword hits. Only dumb luck and
extreme preparedness will get you through this. Have Spear use Summon Ogien, and
Ryanna use X-Thunder. Use your Revives on ANYONE who has fallen; don't bother
Healing them. It can be done! Your prize is a hefty 999XP and 999GP as well as
the Chaos Sword. This is the only way you can find additional Chaos Swords in
the normal game. The Dragons in the Crystal Maze in Ogien's Peroration also drop
them, of course.

25. THE RIDDLE OF ZIEMJA'S CANTICLE

This is basically a word puzzle, spread across the eight randomly-selected parts
of this portion of the EX Dungeon. You need to open all eight chests and form a
phrase. When you open one, it'll show you what you have so far. If you don't
have enough open, it'll say "Need more pieces". Each floor has two letters of
the puzzle, and it will change depending on whether the chest is open or closed.
When you have hit all eight, it will (probably) tell you "Puzzle is incomplete".
If you get this, you will need to open or close the right chest to complete the
puzzle. This is why this is best left for after you've beaten Ziemja; you won't
have to deal with random encounters as you solve this puzzle. When you do manage
to get the right order, it will tell you "Puzzle is complete!". A secret boss
will then fight you.

Called Herr Peace, this secret boss is second only to Cacophony in terms of
overall statistics. However, it has no magic and can only attack. It is weak to
Fire, so X-Fire away. It has 5000HP and gives 5000XP, but its real value is in
its item drop, the one-of-a-kind Oblivion, an extremely powerful weapon. Make
sure you have an item slot free for when you beat Herr Peace or else you will
not get the weapon. It has an attack strength of 250, ten times that of the
Chaos Sword.

Here are all of the possible phrases for the riddle:

HERRPEACEISRULER
GATHERINGTHESUNS
TEMPTATIONBRINGS
ZIEMJALEADSUSFAR
WJATRRULESBYWIND
WODAWILLFREEZEUS
FEARTHESAPPHIRES
BETRAYERSWILLDIE

26. THE BONUS GAME

Once you beat the EX Game, the bonus game becomes available. This is basically a
two-to-five player Bomberman clone, based on characters from Mysterious Song as
well as characters from Frozen Utopia's then-planned Neutopia III (which was
canceled, by the way). It has some bugs in it but it's the only place to hear
three additional music tracks that are not in the game proper, not even in the
Audition option. This is pretty much just a deathmatch Bomberman game. There's
only one "level" and you blow each other up until there's only one person left.

27. TRIVIA

The music in Fawna and Illus, called "Tears", is heavily inspired by the song
"As Tears Go By" by The Rolling Stones.

"Herr Peace" is an inside joke from the early development of the game. At
certain times, the tops of NPCs heads could be seen in places they were not
supposed to be; being like "hair pieces" just floating around the map.

The original MS-DOS version of the game only allowed one save slot, as opposed
to two.

The Venomous enemy design is based on the Midgar Zolom from Final Fantasy 7.

The Bestiary description for the Valkyrie is a hint to the game "Valkyrie
Midnight", a game that was in the works by Frozen Utopia at the time of the
release of Mysterious Song.

The names of the elemental spirits are derived from Polish words. The original
designer, Matt Zuckowski, is of Polish descent, so he used words from the
language of his ancestry to name the spirits. Each name corresponds to the
element that they represent.

"Tiffy" and "Aeri" in Fawna are references to the two female protagonists in
Final Fantasy 7.

"Lament", "Envoi", "Canticle", "Peroration", "Refrain", and "Cacophony" are all
technical terms in music theory.

The game was originally meant to have sequels, which is why "Chapter I" can be
seen in the end credits. However, no further games were ever made by Darkness
Ethereal, which is why the Frozen Utopia version was given a "Chapter X".

The four elemental spirits were all meant to be usable in the original MS-DOS
version of the game. For some reason, they were cut from the design, but the
code to summon them was left intact. They are not usable in the Frozen Utopia
version.

Using Ogien against the elemental spirits makes them speak in-battle. This was
meant to be used to set up special counterattacks for when you fight the three
all at once, but due to memory constraints, this was removed from the final
version.

The original title screen music was from the Amiga demo "Agony". While on
display at a show, many people recognized the piece. A new title piece was then
written for the game in response, and is only the only completely original piece
of music in the game (the rest are enhanced versions of tracks from the original
MS-DOS game).

Due to how the game was programmed, the Slime enemy has twice the chance of
appearing than the Birdmask in the area around Toren Castle. Every other enemy
has an equal chance of appearing on the world map in their respective zones.

Princess Julia is named after one of the original designers of the game, Julia
Hart. She was one of the founding members of Darkness Ethereal in the 1990s.

Wjatr's Lament did not exist in the original MS-DOS version of the game. It is
exclusive to the Frozen Utopia version.

The original MS-DOS version did not have the option to play "Balanced". This,
too, is exclusive to the Frozen Utopia version.

In the original MS-DOS version of the game, Tiger has black hair and darker
skin. Out of all of the characters in the game, he was modified the most.

28. CHARTS N GRAPHS N SUCH

-ENEMY LIST-
Here's a complete list of all the enemies in the game, with stats and such.

LEGEND:
HP: Hit Points
MP: Magic Points
AT: Attack strength
DF: Defense strength
AG: Agility rating
MS: Magic strength
MD: Magic defense
SA: Special Attack
XP: Experience points
GP: GP (gee...)
WK: Weakness (None = no real weaknesses, Nothing = also immune to Death spells)
    (Note that all bosses are immune to Death spells)
Drops: What this enemy will drop when killed
    (Items are always dropped unless the item bag is full)

*SLIME*
Description: A slimy, wiggly creature of evil. It never fights alone.
HP: 4
MP: 0
AT: 3
DF: 2
AG: 1
MS: 1
MD: 1
SA: None
XP: 1
GP: 2
WK: None
Drops: None
Found: Around Toren Castle

*BIRDMASK*
Description: An evil mutant who hides behind a mask.
HP: 7
MP: 0
AT: 5
DF: 3
AG: 2
MS: 1
MD: 2
SA: None
XP: 3
GP: 4
WK: Thunder
Drops: None
Found: Around Toren Castle and Fawna

*BIRDMAN*
Description: Half man, half bird, all evil.
HP: 14
MP: 0
AT: 7
DF: 6
AG: 4
MS: 1
MD: 2
SA: None
XP: 4
GP: 6
WK: Thunder
Drops: None
Found: Around Fawna

*THIEF*
Description: Hides in the shadows and attacks anyone who walks by.
HP: 12
MP: 0
AT: 10
DF: 8
AG: 3
MS: 1
MD: 2
SA: None
XP: 6
GP: 6
WK: None
Drops: Herb
Found: Around Fawna, near Illus Pass, Wjatr's Lament

*WATCHER*
Description: A faithful servant of evil who burns anyone it sees.
HP: 18
MP: 8
AT: 10
DF: 10
AG: 10
MS: 2
MD: 2
SA: Fire
XP: 9
GP: 10
WK: None
Drops: None
Found: Near and in Illus Pass, Wjatr's Lament, Woda's Envoi

*KNIGHT*
Description: A former Toren Knight, driven to madness and murder.
HP: 24
MP: 0
AT: 16
DF: 12
AG: 4
MS: 1
MD: 1
SA: None
XP: 12
GP: 12
WK: Fire
Drops: Remedy
Found: Near Illus Pass, Wjatr's Lament

*WYRM*
Description: A bloodthirsty, poisonous crawler.
HP: 22
MP: 4
AT: 20
DF: 16
AG: 9
MS: 4
MD: 10
SA: Poison
XP: 10
GP: 11
WK: Fire
Drops: None
Found: Illus Pass, around Illus, Wjatr's Lament, Woda's Envoi

*EVIL MAGE*
Decription: A slightly insane, totally evil spellcaster.
HP: 32
MP: 16
AT: 8
DF: 12
AG: 17
MS: 7
MD: 20
SA: Thunder
XP: 14
GP: 16
WK: None
Drops: None
Found: Around Illus, Wjatr's Lament, Woda's Envoi

*CURSWORD*
Description: An evil spirit, enslaved in sword form.
HP: 22
MP: 0
AT: 19
DF: 19
AG: 15
MS: 1
MD: 16
SA: None
XP: 12
GP: 18
WK: Thunder
Drops: None
Found: Around Illus, Wjatr's Lament, around Nemar, Woda's Envoi

*DRAGON*
Description: An ancient, fire-breathing lizard. Extremely powerful.
HP: 999
MP: 99
AT: 175
DF: 200
AG: 100
MS: 100
MD: 300
SA: Fire
XP: 999
GP: 999
WK: Nothing
Drops: Chaos Sword
Found: The Isle Of Dragons, The Crystal Maze

*JELLYEYE*
Description: A poisonous, flying jelly beast with many eyes.
HP: 40
MP: 12
AT: 32
DF: 30
AG: 25
MS: 30
MD: 40
SA: Poison
XP: 22
GP: 27
WK: None
Drops: None
Found: Around Nemar, Nemar Cave F1

*ARMLESS*
Description: Despite its name, it is armed to the teeth.
HP: 34
MP: 12
AT: 23
DF: 24
AG: 32
MS: 11
MD: 35
SA: Ice
XP: 18
GP: 22
WK: None
Drops: Herb
Found: Around Nemar, Woda's Envoi

*VENOMOUS*
Description: A terrifying toxic snake.
HP: 65
MP: 8
AT: 32
DF: 36
AG: 53
MS: 55
MD: 57
SA: Poison
XP: 52
GP: 60
WK: None
Drops: None
Found: Around the Tower Of The Gods, Tower Of The Gods F1

*FROST*
Description: Likes its milk frozen.
HP: 72
MP: 12
AT: 36
DF: 35
AG: 62
MS: 17
MD: 51
SA: Ice
XP: 56
GP: 70
WK: Fire
Drops: None
Found: Around the Tower Of The Gods, Woda's Envoi

*SPRITE*
Description: An obnoxious, magical flying pest.
HP: 67
MP: 16
AT: 20
DF: 28
AG: 70
MS: 18
MD: 70
SA: Thunder
XP: 50
GP: 60
WK: None
Drops: Ether
Found: Around the Tower Of The Gods

*ARMORSKULL*
Description: A heavily armored undead warrior.
HP: 95
MP: 0
AT: 45
DF: 51
AG: 53
MS: 1
MD: 71
SA: None
XP: 75
GP: 82
WK: None
Drops: Herb
Found: Tower Of The Gods F1 & F2

*CAVE DEMON*
Description: A lesser demon who enjoys the darkness of caverns.
HP: 76
MP: 0
AT: 29
DF: 33
AG: 29
MS: 1
MD: 32
SA: None
XP: 43
GP: 56
WK: None
Drops: None
Found: Nemar Cave, Ziemja's Canticle

*CLAY MAN*
Description: An evil spirit trapped in a body made of clay.
HP: 65
MP: 0
AT: 24
DF: 30
AG: 9
MS: 1
MD: 22
SA: None
XP: 20
GP: 26
WK: Ice
Drops: None
Found: Nemar Cave F1

*CUTTHROAT*
Description: A vicious assassin.
HP: 24
MP: 0
AT: 12
DF: 9
AG: 14
MS: 1
MD: 6
SA: None
XP: 12
GP: 12
WK: None
Drops: None
Found: Illus Pass, Wjatr's Lament

*DIVINE*
Description: The Grim Reaper's children.
HP: 69
MP: 24
AT: 44
DF: 59
AG: 42
MS: 18
MD: 76
SA: Thunder
XP: 59
GP: 66
WK: None
Drops: Ether
Found: Tower Of The Gods F2 & F3, Ziemja's Canticle, Ogien's Peroration

*EVIL WITCH*
Description: An insane spellcaster.
HP: 65
MP: 34
AT: 41
DF: 39
AG: 72
MS: 24
MD: 55
SA: Fire
XP: 60
GP: 62
WK: None
Drops: None
Found: Tower Of The Gods F3

*GOD BEAST*
Description: Grimm's pet.
HP: 88
MP: 0
AT: 52
DF: 45
AG: 58
MS: 1
MD: 55
SA: None
XP: 69
GP: 80
WK: None
Drops: None
Found: Tower Of The Gods F2, Ziemja's Canticle, Ogien's Peroration

*GRUESOME*
Description: Sickening.
HP: 87
MP: 16
AT: 50
DF: 52
AG: 50
MS: 66
MD: 69
SA: Disease
XP: 72
GP: 80
WK: None
Drops: Remedy
Found: Tower Of The Gods F3 & F4, Ziemja's Canticle

*MARAUDER*
Description: Grimm's elite footsoldiers.
HP: 132
MP: 0
AT: 72
DF: 47
AG: 51
MS: 1
MD: 62
SA:None
XP: 110
GP: 125
WK: None
Drops: None
Found: Tower Of The Gods F4 & F5, Ogien's Peroration

*NIGHT DEVIL*
Description: Does not like daylight.
HP: 104
MP: 16
AT: 41
DF: 44
AG: 51
MS: 24
MD: 56
SA: Fire
XP: 82
GP: 91
WK: None
Drops: Ether
Found: Tower Of The Gods F1, Ziemja's Canticle, Ogien's Peroration

*SKULLMAN*
Description: A powerful animated corpse.
HP: 52
MP: 0
AT: 24
DF: 46
AG: 52
MS: 1
MD: 88
SA: None
XP: 42
GP: 50
WK: None
Drops: None
Found: Nemar Cave F2

*TOXIC LIZ*
Description: A deadly lizard who makes its home in damp places.
HP: 46
MP: 12
AT: 21
DF: 24
AG: 42
MS: 38
MD: 40
SA: Disease
XP: 30
GP: 33
WK: None
Drops: None
Found: Nemar Cave F2

*VALKYRIE*
Description: Comes out after midnight.
HP: 102
MP: 8
AT: 61
DF: 51
AG: 72
MS: 22
MD: 77
SA: Fire
XP: 98
GP: 100
WK: None
Drops: None
Found: Tower Of The Gods F4, Ziemja's Canticle

*DARK KNIGHT*
Description: Vyper's personal guards.
HP: 392
MP: 0
AT: 55
DF: 34
AG: 28
MS: 1
MD: 200
SA: None
XP: 350
GP: 500
WK: None
Drops: None
Found: Nemar Cave F2

*OGIEN*
Description: An ancient fire spirit.
HP: 240
MP: 20
AT: 31
DF: 23
AG: 25
MS: 11
MD: 25
SA: Fire
XP: 150
GP: 250
WK: None
Drops: None
Found: Illus Pass

*MEGA WYRM*
Description: A massive three-headed Wyrm. Highly territorial and toxic. 
HP: 360
MP: 24
AT: 35
DF: 18
AG: 24
MS: 20
MD: 30
SA: Poison
XP: 140
GP: 200
WK: None
Drops: None
Found: Illus Pass, Wjatr's Lament, Woda's Envoi, Ogien's Peroration

*VYPER*
Description: An evil assassin who serves Grimm.
HP: 560
MP: 44
AT: 82
DF: 54
AG: 51
MS: 22
MD: 270
SA: Thunder
XP: 400
GP: 750
WK: None
Drops: Dark Sword
Found: Nemar Cave F2

*GREGOR*
Description: The evil God of the Undead.
HP: 900
MP: 50
AT: 122
DF: 72
AG: 98
MS: 32
MD: 550
SA: Fire
XP: 900
GP: 1000
WK: None
Drops: Dark Sword
Found: Tower Of The Gods F3

*WODA*
Description: An ancient water spirit.
HP: 2500
MP: 99
AT: 150
DF: 25
AG: 75
MS: 30
MD: 250
SA: Ice
XP: 1000
GP: 0
WK: Fire
Drops: None
Found: Woda's Envoi, Ogien's Peroration

*ZIEMJA*
Description: An ancient earth spirit.
HP: 3500
MP: 99
AT: 150
DF: 25
AG: 75
MS: 30
MD: 250
SA: Disease
XP: 2000
GP: 0
WK: Thunder
Drops: None
Found: Zimeja's Canticle, Ogien's Peroration

*WJATR*
Description: An ancient air spirit.
HP: 2500
MP: 99
AT: 150
DF: 25
AG: 75
MS: 30
MD: 250
SA: Thunder
XP: 1000
GP: 0
WK: None
Drops: None
Found: Wjatr's Lament, Ogien's Peroration

*HERR PEACE*
Description: Hairy.
HP: 5000
MP: 99
AT: 220
DF: 90
AG: 100
MS: 35
MD: 250
SA: None
XP: 5000
GP: 0
WK: Fire
Drops: Oblivion
Found: Ziemja's Canticle

*GRIMM*
Description: An ancient gothic god who renounced humanity.
HP: 2700
MP: 90
AT: 220
DF: 90
AG: 100
MS: 35
MD: 650
SA: Thunder
XP: 0
GP: 0
WK: Nothing
Drops: None
Found: Tower Of The Gods F5

*CACOPHONY*
Description: The four elements driven to insanity all at once.
HP: 9999
MP: 255
AT: 255
DF: 16
AG: 255
MS: 100
MD: 500
SA: Varies
XP: 0
GP: 0
WK: Varies
Drops: None
Found: Cacophony's Refrain

-WEAPONS-
All the weapons in the game and how you get them.

*SHORT SWORD*
Description: The standard weapon of the Toren Knight. This sword is designed for
close combat only.
Attack+2
Sell Price: 25
Obtained: Spear's initial weapon.

*LONG SWORD*
Description: A standard warrior's weapon, suitable for any melee combat.
Attack+5
Sell Price: 50
Obtained: Shops in Toren Castle (100) and Fawna ()

*MAGIC SWORD*
Description: A long sword that has been magically enhanced by the magicians of
Illus.
Attack+10,Magic+5
Sell Price: 500
Obtained: Shop in Illus (1000), Nemar Cave F2, Tower Of The Gods F2 & F3

*DARK SWORD*
Description: A Magic Sword that has been corrupted by dark priests.
Attack+15
Sell Price: 2500
Obtained: Nemar Cave F2, Tower Of The Gods F4, dropped by Vyper and Gregor

*CHAOS SWORD*
Description: An evil blade, cooled in the blood of a dragon and cursed by the
god of Chaos.
Attack+25
Sell Price: 1
Obtained: Tower Of The Gods F4, dropped by Dragons

*OBLIVION*
Description: The ultimate sword of doom, this weapon is said to have brought the
world to the brink of destruction.
Attack+250
Sell Price: 1
Obtained: Dropped by Herr Peace

-ARMORS-
All the armors in the game and how you get them.

*LEATHER VEST*
Description: The standard armor for Toren Knights, decorated with the crest of
Toren.
Defense+2
Sell Price: 50
Obtained: Spear's initial armor.

*CHAIN MAIL*
Description: Tough armor made from linked steel rings.
Defense+5
Sell Price: 125
Obtained: Shop in Toren Castle (250) and Fawna (230)

*IRON SUIT*
Description: Plate mail made from sheets of heavy iron.
Defense+10
Sell Price: 375
Obtained: Shop in Fawna (900) and Illus (750)

*MAGIC MAIL*
Description: Magical chain mail that offers additional magic protection.
Defense+15,M.Defense+10
Sell Price: 1750
Obtained: Shop in Illus (2500), Nemar Cave F1, Tower Of The Gods F2 & F3

*SUIT OF AGES*
Description: A powerful set of ancient armor that magically conforms to the
wearer's body.
Defense+25
Sell Price: 1
Obtained: Tower Of The Gods F4

*IMPERVIOUS*
Description: Exceptionally powerful magic platemail that absorbs all kinds of
magical attacks. Only one is known to exist.
Defense+250,M.Defense+250
Sell Price: 1
Obtained: Ogien's Peroration

-ITEMS-
All the items in the game and how you get them.

*HERB*
Description: A restorative herb grown in the fields of Toren Kingdom.
Restores up to 100 HP.
Sell Price: 5
Obtained: Shops in Toren Castle (10), Fawna (12), Illus (10), Nemar (10); Nemar
Cave F1 & F2, Tower Of The Gods F2; dropped by Thief, Armless, and Armorskull.

*ETHER*
Description: A very strong-smelling potion, brewed to help magic-users perfect
their craft.
Restores up to 25 MP.
Sell Price: 25
Obtained: Shops in Toren Castle (50), Fawna (47), Illus (40), Nemar (50); Nemar
Cave F1 & F2, Tower Of The Gods F2 & F4; dropped by Sprite, Divine, and Night
Devil.

*REMEDY*
Description: A salty medicine that purges the body of any sickness.
Sell Price: 5
Obtained: Shops in Fawna (15), Illus (10), Nemar (50); dropped by Knight and
Gruesome.

*REVIVE*
Description: A holy artifact that brings one back from the dead.
Sell Price: 25
Obtained: Shops in Toren Castle (50), Fawna (50), Illus (48), Nemar (50); Nemar
Cave F2, Tower Of The Gods F3 & F4.

-SPELLS-
Spear can cast a few spells but is more of a warrior than anything else. Ryanna
is a better magician and her spells are much more effective. Tiger can't learn
magic and never gets MP.

*HEAL*
Basic healing spell. Costs 2MP to cast; heals 4x Magic Strength in HP.
Spear and Ryanna both start the game knowing this spell.

*CURE*
The spell version of Remedy. Costs 2MP to cast.
Spear and Ryanna both learn this spell at level 5.

*FIRE*
A basic fire spell. Costs 4MP to cast; damage is 3x Magic Strength + the enemy
Magic Defense subtracted from the caster's Magic Strength.
Spear learns this spell at level 12, Ryanna learns this spell at level 10.

*ICE*
A basic cold spell. Stats are the same as for Fire.
Spear learns this spell at level 27, Ryanna learns this spell at level 11.

*THUNDER*
A basic shock spell. Stats are the same as for Fire.
Spear learns this spell at level 39, Ryanna learns this spell at level 12.

*REVIVE*
Same as the item Revive. Costs 20MP to cast; gives the target 25% of their HP.
Spear learns this spell at level 55, Ryanna learns this spell at level 25.

*DEATH*
Eliminates the enemy. Costs 15MP to cast; 30% success rate.
Ryanna learns this spell at level 41.
Honestly... this spell is a waste of MP.

*X-FIRE*
A powerful fire spell. Costs 10MP to cast; damage is 6x Magic Strength + the
enemy Magic Defense subtracted from the caster's Magic Strength.
Ryanna learns this spell at level 18.

*X-ICE*
A powerful ice spell. Stats are the same as for X-Fire.
Ryanna learns this spell at level 19.

*X-THUNDER*
A powerful shock spell. Stats are the same as for X-Fire.
Ryanna learns this spell at level 20.

*X-HEAL*
A more powerful healing spell. Costs 8MP to cast; heals 8x Magic Strength in HP.
Ryanna learns this spell at level 34.

*X-REVIVE*
Revive plus full healing. Costs 40MP to cast.
Ryanna learns this spell at level 49.

*X-DEATH*
Eliminates the enemy. Costs 30MP to cast; 60% success rate.
Ryanna learns this spell at level 57.
This spell, too, is a waste of MP.

*SUMMON OGIEN*
Summons Ogien to incinerate all enemies. Costs 15MP to cast; damage is 150 + a
random amount of damage based on Spear's Magic Strength. This is a piercing
spell that ignores all defenses of the enemy, but also all weaknesses of the
enemy; the damage is consistent. Although this is an expensive spell for Spear
to cast, it can easily reverse a situation where you are physically outmatched.
Spear learns this spell when the party defeats Ogien.

29. PONDERANCES

-What is Ryanna's "secret", her "true grace"? 'But underneath these well-
 composed notes lie her true grace... always on the edge of self-destruction.'
-Where is King Algameth's queen? Princess Julia is with him, but there is never
 any mention of a queen.
-Why does Tiger fear Spear? Is it because Tiger is so rigid and Spear is so
 chaotic?

30. CREDITS, REVISIONS, ETC.

This guide is (C)2013 Rainy_Eyes
The game is (C)1999 Darkness Ethereal, (C)2012 Frozen Utopia

Version 1.0, Aug 17 2013
-Initial version