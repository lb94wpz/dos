Spirit of Adventure:

Something you should know.........

A lesser known bug, and more evil, is that if it tries to load a game, and fails, it will delete the saved game. Not a major issue, usually. But every so often it will hiccup, and trash the saved game. Have had it happen only twice in 3 months of playing. The first time it took a month of adventuring and trashed it, good and proper. The second time, I had wised up and backed the game file up, and only lost about 4 hours. It may have been my system at the time (an ancient, even then, 386) because it had a history of doing weird things, However I recommend copying the game save file to a safe spot when done adventuring for the day, just to be on the safe side.