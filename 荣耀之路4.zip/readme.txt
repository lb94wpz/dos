Words:         Symbols:
                 1        2        3       4       5
ALKAZOTZ       Pizza    Pizza    Fire    Water   Water
BETAZENE       Water    Fire     Water   Earth   Fire
CRANOMEAL      Earth    Water    Fire    Pizza   Earth
DESERTIX       Earth    Fire     Earth   Fire    Water
ELKORN         Pizza    Earth    Pizza   Wind    Wind
FLIEGNITZ      Wind     Pizza    Fire    Wind    Pizza
GARGOIL        Pizza    Water    Water   Earth   Earth
HINTLINE       Earth    Wind     Pizza   Wind    Earth
ICKYUCKGOOP    Water    Earth    Earth   Water   Pizza
JOLLENE        Pizza    Pizza    Wind    Pizza   Pizza
KICKAPTUI      Water    Wind     Water   Pizza   Earth
LAXABIFF       Earth    Earth    Water   Earth   Water
MEXICALISH     Fire     Earth    Pizza   Fire    Pizza
NOXIPYU        Wind     Fire     Earth   Wind    Earth
OSSIPYE        Earth    Fire     Pizza   Earth   Fire
PENTICKLE      Wind     Pizza    Pizza   Wind    Water
QUIXOAT        Water    Wind     Fire    Pizza   Wind
ROMBURN        Fire     Earth    Fire    Wind    Earth
SUMTHIN        Water    Pizza    Earth   Wind    Wind
TAMLIN         Pizza    Water    Wind    Earth   Water
ULTIMO         Fire     Wind     Pizza   Pizza   Pizza
VOLTOFFEN      Wind     Fire     Earth   Fire    Wind
WHAMMBO        Earth    Fire     Earth   Wind    Fire
XASPARIL       Wind     Wind     Water   Wind    Water
YAMMER         Wind     Pizza    Wind    Water   Pizza
ZOTZBRUE       Water    Fire     Fire    Wind    Water