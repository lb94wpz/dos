                                 WHALE'S VOYAGE

                                   THE MANUAL


WHALE'S VOYAGE: INSTRUCTIONS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Important note:

Before you start playing, remember to make back-up copies from the original
diskettes, and only work with these back-ups.


Hardware Requirements:
~~~~~~~~~~~~~~~~~~~~~~
PC  version:  all 100% compatible machines from 386 upwards with at least 1
megabyte of memory and a 100% compatible graphics card.


CONTROLLING THE GAME
~~~~~~~~~~~~~~~~~~~~

The  game  is controlled in exactly the same way throughout, using either a
joystick in port 2 or the cursor keys and Return.

Menu  options  are  selected in the same way:  menus are selected by either
left/right  or up/down movement via the joystick (or the cursor keys).  The
currently  selected  menu option will always be indicated by a flashing red
symbol  (usually  a box or a small arrow).  The action shown can be carried
out be pressing the Fire button (or the Return key).

To  return to the previous menu, the joystick (or cursor keys) must be used
to  move  in a direction other that those for moving around the menu.  This
sounds  complicated  at  first,  but  you  will find yo get used to it very
quickly, after which it provides very fast input.

For example - when on a menu in which actions are selected by moving to the
left  or  right,  if you now try to move up or down, you will exit from the
menu and return to the previous one.

If  you  are  in  the  Trading Menu, pressing the Escape key takes you to a
sub-menu with the following options:


       S ... Save game

       L ... Load game

       Q ... Quit game

       C ... Continue


If  you press the "S" key the current state of the game will be saved.  "L"
will  load  the  previous  game  at the point where it was saved.  "Q" will
return  you  to DOS.  If none of these is required and you key "C" you will
be able to continue the game.


PLAYING THE GAME
~~~~~~~~~~~~~~~~

I   New game or old game?
~   ~~~~~~~~~~~~~~~~~~~~~

First,  a  short  program will be loaded, which will ask you if you wish to
load  a  saved  game or start a new game.  If you are playing for the first
time, you should select "NEW GAME".  As only one game position can be saved
at a time, the "OLD GAME" option will always load the last position.


II  The Crew Generator
~~  ~~~~~~~~~~~~~~~~~~

Before  you  can  move  on to the action of the game, you must first create
your crew - that is, your players.  This is done in the Crew Generator:

Select  "CREATE  CREW MEMBER", which will be the only option in the menu at
this  stage.   A row of five men will appear at the top of the screen, from
which you must select one to be the father of the crew member.  After this,
you  select  its  mother in the same way.  A baby will then be shown in the
window  underneath,  and this should be given a name (as an exception, this
is entered via the keyboard).

The  screen  will  now  show the child's most important character features.
You  can  select  these  by moving up and down and introduce mutations into
them by moving left and right.

The gene for each character feature in the DNA will be shifted as you cause
it  to  mutate:   the  greater  the  mutation, the more it will shift.  The
number  of mutations you can perform is shown in the top text field against
the  MUTATION  RATE.   The  advantage  of mutations is that the crew member
becomes  stronger in one or more sides of his character.  However, there is
a  drawback  which should not be taken lightly:  the greater the mutations,
the  weaker the genes become, which makes the character more susceptible to
diseases which crop up in the course of the game.

After  this you can choose an education for your character.  You can select
one  of  six schools and one of six colleges.  However, not every character
is  automatically  admitted  to  every  school or college:  this depends on
certain  qualifying  values,  which  can  be  seen  as  a sort of "entrance
examination".

The available Schools are


1)  UNIVERSAL ELEMENTARY SCHOOL

    In this school the character is given a general all-round
    education and taught a broad range of subjects.


2)  SPACE EDUCATION CAMP

    This camp gives the child and education oriented
    towards space travel.


3)  ARMY SCHOOL

    In this school, military training comes first: the child will
    be taught to be a soldier and warrior.


4)  SCHOOL OF LIFE

    The School of Life is not really a school at all: the child simply
    spends its youth roaming the city streets, gets to know life in the
    gutter, and becomes "streetwise".


5)  CYBERTECH MENTAL SCHOOL

    This offers the child the chance to develop his mind and
    advance his mental powers.


6)  NAGIKAMURA GAKKO

    This Japanese school provides a basic education centred on
    chemistry.



The Colleges are


1)  MILITARY ACADEMY

    On Completing his course at this college, the character will be a
    fully trained soldier and will have developed
    special combat abilities.


2)  HOODSON MEDICAL SCHOOL

    This college trains its students to become doctors and
    also teaches them to handle mental energy.


3)  ARANIAN MONASTIC SCHOOL

    Graduates from this establishment are warrior monks,
    not only capable of using weapons to excellent effect,
    especially in hand-to-hand fighting, but also the ability to
    use special mental powers.


4)  PSI SCIENCE INSTITUTE

    This college gives its students complete control over the
    mind. Students learn how to use their mental energy and
    graduate as psionic initiates.


5)  CHEMICAL UNIVERSITY

    Here, students are trained as biochemists, with a wide
    knowledge of the elements and composition of different
    planets and systems.


6)  BOUNTY HUNTERS' GUILD

    The last college is run by the Bounty Hunters' Guild, and
    only accepts the best-qualified candidates, as the
    students are trained as rugged fighters.


Every  character  must  graduate from one of these six schools and colleges
before his education is finished so that he can join the game.

Once you have given a crew member a complete education, you have the choice
of either designing a new character or erasing the first one.

Before starting the game you must have designed four characters.  Once this
has been done, a second option will appear in the menu automatically.


Here is a summary of all the symbols we have met:


      CREATE CREW MEMBER

      ^ icon of a bottle with some liquid in it


      REMOVE CREW MEMBER

      ^ something i can't see what it is but it says REMOVE on it so no prob.


      START GAME

      ^ this icon looks like a ship beaming down something on a planet.


III The Trading Screen
~~~~~~~~~~~~~~~~~~~~~~

The  main  part  of  the  game  is divided into two distinct sections:  the
Trading Screen and the 3-D Screen (which we will look at shortly).

The  Trading  Screen  relates  to  the part of the game when the crew is on
board  the  Whale,  where  they are safe from pursuers they might meet, for
example,  in  the  cities (more on this a little later).  However, the ship
may still be attacked by other vessels (see below).


The main commands available to you are as follows


(from left to right)

  .-------+-------+-------+-------+-------+-------.
  |       |       |       |       |       |       |
  |   1   |   2   |   3   |   4   |   5   |   6   |
  |       |       |       |       |       |       |
  `-------+-------+-------+-------+-------+-------'

      1)   BUY GOODS

      2)   SELL GOODS

      3)   SHIP'S SUPPLIES

      4)   SELECT NEW TARGET PLANET

      5)   LAND SCOUTCRAFT OR BEAM DOWN

      6)   PHONE



Buy Goods
~~~~~~~~~

If you select this sub-menu, contact is made with a trader on the currently
selected planet, shown at top left.

There  is  an  extensive  range of goods to trade during the game.  In this
selection  from  the menu, the trader you have contacted will offer some of
these  goods  for sale to your crew.  The prices for the various goods vary
from planet to planet and may change in the course of thegame.

The  name  and price of the product currently selected will be shown on the
display  monitor  at  top  right  in  exactly  the  same way as the Whale's
remaining free capacity.

Pressing  the  Fire  button  (or the Return key) will cause the goods to be
bought.


Sell Goods
~~~~~~~~~~

This allows goods that have been bought previously to be sold to the planet
you  are  currently  in  contact  with.  Needless to say, there is not much
profit  when  buying goods then selling them back to the same planet in the
same move.


Ship's Supplies
~~~~~~~~~~~~~~~

Once  you  have  sufficient  money, you can equip the Whale with additional
"extras",  which  could be very useful in the event of a confrontation with
other ships (see SPACE BATTLE below).

Fuel  for  the ship can also be bought from this menu, to enable you to fly
on to another planet:

If  the  red box is positioned over the "Refuel" icon, the text window will
display the price for one unit of fuel.  The number of units you need for a
particular voyage will depend not only on the distance to your destination,
but  also,  of  course,  on  the weight of the goods you are carrying.  The
number  of  units  of fuel required for the voyage can be found on the Star
Map (see below).

Clicking  on  the "Refuel" icon produces a display containing the following
information:



- MAXIMUM:    20000  tells you the capacity of the fuel tank.

- YOU HAVE:   00000  tells you how much fuel you have in the tank at present.

- PURCHASE:   9483   tells you the maximum amount of fuel you can
                     buy before you fill the tank or run out of money.
                     (In this case it is limited by the money available.)


If  you  now  press  the  Fire button (or the Return key) a maximum of 5000
units will be bought.  If this is done for the above example, the following
figures will now appear:


   MAXIMUM:    20000
   YOU HAVE:   5000
   PURCHASE:   4483


If you press the Fire button again, you will not be able to buy 5000 units,
as you only have 4483 credits left.

Additionally, this menu allows you to buy a small scoutcraft with which you
can  fly  over  the  surface of a number of planets to prospect for mineral
resources.

There  are 5 different extras per planet.  If you want to buy a scoutcraft,
for  example,  you must first find a planet offering them.  You should also
go carefully with your fuel reserves, because it may well happen that there
is no fuel on the planet you are making for.

Extras can be bought, sold or repaired.

This  is  arranged  by selecting one of the two icons at the far left.  The
text  window  will  now  indicate whether you are intending to buy or sell.
You can now select one of the extras.  An extra can only be rapaired if you
already  have  it and the planet you are in contact with sells the item and
thus is able to repair.

If  you  select the "Buy" symbol, an indication will appear against each of
the  extras  you  already  have,  telling  you  whether it needs repairing.
Clicking on the symbol will result in the extra being repaired.


SELECT NEW TARGET PLANET AND TAKE OFF
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

If this icon is selected a window will appear giving a short description of
the  planet  you  have  currently  selected.   At  the  right there are two
symbols.  Ths top one takes you to the Star Map, where you can select a new
destination  from  the planets in the system.  This shows you how far it is
to  the new planet and how much fuel you will need.  Once you have chosen a
new  destination  and confirmed it by pressing the Fire button, you will be
returned  to  the  previous menu.  The lower icon will now allow you to fly
the Whale to your new destination.

During  your  flight  through space to the planet you have selected as your
destination,  you  are  very  likely to meet trouble.  For example, pirates
maybe  lying in wait for the Whale, with their eyes on the contents of your
hold.   In  such  an event, a SPACE BATTLE will be displayed on a screen of
its own.

---------------------------------------------------------------------------.
<|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|~~~|>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
<|   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
<|   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
<|   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
<|   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
<|   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
<|   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |>|
<|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|>|
---------------------------------------------------------------------------|
                                                     | Hits: 00 | Move: 00 |
---------------------------------------------------------------------------'

The  upper  section shows the actual playing area.  The Whale always starts
in  the  centre  of  the  screen.   There are three ways to survive a space
battle:

1) Destroy all the enemy ships.

2) Click on the "Give in" symbol. This means that your entire cargo will be
   looted by the pirates, but you will survive.

3) If small green arrows light up at left and right, it is possible to
   escape. Once the Whale reaches the left or right-hand edge of the screen
   it can get away, so the battle is over.


If  the  ship  is knocked out by the enemy's weapons, the game is over.  In
view  of  this, it is a good idea to equip the Whale with some "extras" and
save the game frequently.

The  lower section of the screen contains the playing icons.  The number of
icons shown depends on what extras you have equipped the Whale with.

+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+
|  _  |  __ | __  |  /  | / \ |  a  |some |     | a   |     |
| / \ | |   |   | | `--.|( o )|globe|kinda|  ?  |flag | >>> |
| ~~~ | `   |   ' |   / | \ / |     |globe|     |     |     |
+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+

The following icons are shown at all times:


-   AHEAD         Activating this icon moves the Whale one
                  square in the direction it is facing.


-   PORT TURN     The Whale will turn 90 degrees to the left.


-   STARBOARD TURN The Whale will turn 90 degrees to the right.


-   GIVE UP       When this icon is activated the battle is over


-   END MOVE      This terminates your move; it is now the computer's turn.


-   SHIELDS UP    The shields will operate for one move (i.e.until you start
                  your next move).


-   HOLOGRAM      This activates the Hologram projector for one move
    PROJECTOR ON  (i.e. until you start your next moove), and a second
                  image of the Whale will appear on the screen.
                  This means that the enemy cannot be sure which
                  Whale is the real ship and which is the decoy. In
                  the confusion, attacks may be directed at the wrong image.


-   CLOAKING      The Cloaking Device will be activated for one move
    DEVICE ON     (that is, until you start your next move). This makes
                  the Whale invisible to the enemy, so that it cannot be
                  attacked.


-   IDENTIFY      This extra allows you to identify enemy spaceships and
    ENEMY SHIP    the weapons that they are carrying.



Every  time  you  activate an icon it will cost you "movement points".  The
number of points lost for each action depends on the equipment on board the
Whale.   For example:  one move ahead will normally cost 3 movement points.
However,  if  the  Whale has been equipped with the Booster Drive this will
only  cost  2  points.  In addition, your remaining movement points (out of
the  fixed  count set at the start) will be increased each time an extra is
bought.

This means that the better equipped the Whale is, the more flexible it will
be in battle.

Between  the  battle screen and the menu bar for the icons there is a small
strip  giving the number of hits you have taken and your remaining movement
points.


Land Scoutcraft or Beam Down
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This  gadget has a double function:  If you have bought a scoutcraft in the
"SHIP'S  SUPPLIES" menu, this option takes you into a new menu which allows
you to fly across the planet's surface.

If  you  have  not yet bought a scoutcraft, activating this menu operates a
Teleporter which beams the crew down to the selected planet.


Phone
~~~~~

This icon allows you to phone people you have got to know during the game.


IV  The 3-D Screen
~~  ~~~~~~~~~~~~~~

The main action of the game takes place on the 3-D screen, where the player
can  move  his  characters  around - for example through cities - and solve
tasks and puzzles.

To  illustrate this, let's take a look at the layout of the top half of the
screen:


+--------------+-------------------+--------------+---------------+--------+
|  __________  |                   |  __________  |               |  _  _  |
| |          | |                   | |          | |               | | || | |
| |          | |                   | |          | |               | | || | |
| |          | |                   | |          | |               | | || | |
| |          | |                   | |          | |               | | || | |
| |    1     | |                   | |    1     | |               | |4||5| |
| |          | |                   | |          | |               | | || | |
| |          | |         3         | |          | |               | | || | |
| |          | |                   | |          | |               | |_||_| |
| |__________| |                   | |__________| |               |  T  O  |
| _EXT__._EXT__|                   | _EXT__._EXT__|               |        |
||      |      |                   ||      |      |               |  ______|
||  2   |  2   |                   ||  2   |  2   |               | |      |
||      |      |                   ||      |      |               | |  6   |
||______|______|                   ||______|______|               | |      |
|Whale's Voyage|                   |Whale's Voyage|               | |      |
+--------------+-------------------+--------------+---------------+-+------+
                         ~
                         7



1)   Automapping

2)   Space for "extras" purchased during the game.

3)   View screen, showing the current field of view as seen by the crew.

4)   Temperature indicator. Shows the temperature of the surroundings.

5)   Oxygen indicator. Shows the oxygen content of the air.

6)   This window shows the planet on which the crew is presently located.

7)   Indicates that "WALK" mode is currently selected.


If you are in "WALK" mode (shown by the small flashing light) you can guide
your crew through the planetary locations:

-    Joystick forward            Crew moves forwards.
-    Joystick back               Crew moves backwards.
-    Joystick left               90-degree turn to left.
-    Joystick right              90-degree turn to right.
-    Fire button+joystick left   One step to the left.
-    Fire button+joystick right  One step to the right.
-    Fire button+joystick back   Takes you into the lower section of the
                                 screen, where you can operate the
                                 crew's icons.

The  lower  part of the screen gives you the control icons you need to play
the  game.   These  can be selected using either the joystick or the cursor
keys.

.-------+---+-------------------------+---+---+H----------------+----------.
|       |   |                         |   |   |M----------------|          |
+-------+---+-------------------------+---+---|H----------------+----------+
|       | 2 |          3              | 4 | 5 |M------ 6 -------|          |
|   1   +---+-------------------------+---+---|H----------------|    7     |
|       |   |                         |   |   |M----------------|          |
+-------+---+-------------------------+---+---|H----------------+----------+
|       |   |                         |   |   |M----------------|          |
`-------+---+-------------------------+---+---+-----------------+----------'


1)   Special icons

This  area  will display various icons during the game which are related to
the  immediate situation.  At the start, only the Teleporter icon is shown:
this beams you back to the Whale (Trading Section).

2)   Duty icons

Each  of  the  four  characters  has  a Duty Icon, which identifies the job
allocated to him within the crew.  The following duties can be assigned:

L    ... Leader           The Leader of the group always goes ahead.
                          This means that he is the first to be caught in
                          any traps that have not been spotted beforehand.

S    ... Scout            If this duty has been selected for a character,
                          he will keep a look-out for traps and warn the
                          group when he finds one.

C    ... Closer           If this duty is assigned to a member of the
                          crew, he will close every door after the crew
                          has gone through. The advantage of this is that
                          it makes things difficult for pursuers and while
                          they are busy re-opening the door, valuable
                          time is gained.

T    ... Targeter         A character for whom this duty has been
                          selected takes aim at the person standing in
                          front of him, which means that "Select" does
                          not have to be selected for this character in
                          the event of an attack. However, the automatic
                          targeting is not obvious - that is, the enemy
                          will not be aware of it.

J    ... Joker            A character charged with this duty will
                          try to keep up the morale of the crew by
                          telling jokes. If the crew's morale is
                          high, they will not be intimidated so
                          easily in battle.

M    ... Merchant         A crew member with this duty is
                          responsible for the crew's budget. This
                          results in the number of credits available
                          being shown on screen.

W    ... Weigher          The Weigher shows the weight each
                          character is currently carrying in the
                          text window next to the character's
                          name.

U    ... User             If this duty has been selected, the
                          present temperature and the current
                          oxygen content of the air will be shown
                          in the top right-hand corner of the
                          screen.


There is one further symbol, which cannot be selected but will be displayed
during the course of the game:


D    ... Dead              This character is dead. He can only be
                           brought back into the game if he is
                           brought back to life - either by a
                           magician or a doctor or by using one of
                           the "Healing Devices" which can be found
                           in a number of cities.


Special  demands  are  made  of each character according to the duty he has
been assigned.  For example, the Leader should have a strong personality to
enable  him to keep the crew under control and improve morale.  A Scout, on
the  other  hand,  has  to look out for traps and should therefore have had
training in this particular area.


3)    Name Icon

If  this  square  is  selected,  you  will  see  the icons available to the
character  in question to carry out actions.  For example, an object can be
picked  up, put down or used.  These symbols will appear automatically when
the  situation  requires.   If  an  object  is  on  the field where you are
standing, for example, the "pick up object" icon will appear.

The  colours  used  for  these icons are significant:  weapons are shown in
red,  general objects (for example, a compass) in blue and guiding icons in
yellow and/or green.


4)    Profession Icons

This  will show you the variour abilities each character has.  These depend
on  the  profession that has been chosen:  a doctor, for example, will have
skills to heal wounds, whereas a magician will have a range of spells etc.


5)    Level Icon

This  indicator  shows you how many points you already have, what level you
are  on  so far, and how many Experience Points are still needed to move up
to the next level.


6)    Readings Icon

The  Readings  square displays the two most important readings:  health and
mental energy.

If  the square is activated (press Fire button or Return key) a list of all
readings will appear, in figures.


7)    Health Status Icon

The  character  currently  selected  will always be shown in this square by
means  of  a small picture.  If you click on this field, the character will
tell you how he is.


V   Hints and Tricks
~   ~~~~~~~~~~~~~~~~

This  section  passes  on  a few hints and tricks which may help you to get
over  any early difficulties, or to find answers to problems.  For the time
being,  however, you can skip this chapter if you like and see how well you
make out by yourself.


Assembling a crew
~~~~~~~~~~~~~~~~~

The  crew  should  be put together very carefully so that you have a strong
team  later  in  the game.  As you only have four characters, but there are
six different professions, the right selection can be very important.

Each  of  the  professions has its own strong points, so it is important to
build  up  four  different  characters  with  four  different  professions.
Furthermore  it  is not a bad idea, as a rule, to include one character who
is physically strong and one who is superior to the others in mental terms.


Putting weapons down
~~~~~~~~~~~~~~~~~~~~

In  the  3-D section, if weapons are put down by the crew the magazine will
automatically  be  removed.   When this weapon is picked up again, you will
not be able to shoot with it as it will be empty.


Reloading weapons
~~~~~~~~~~~~~~~~~

If  you buy a weapon, it will not be loaded, of course.  You will therefore
need  a  magazine,  which  can  also  be  bought from weapons traders.  Any
magazine  will  fit  any  weapon, as it comes with a special weapon-sensing
unit  and a calibre adaptor.  It will therefore adjust automatically to the
weapon used.


Goods
~~~~~

If  you  want  to  trade  in  sensitive  goods offered on the planet, it is
advisable  to  equip the Wahel with an appropriate refrigeration unit (only
available  on  certain  planets),  to  stop such goods spoiling during long
flights.

Goods  which  must  be  refrigerated are:  Food, infusions, brain implants,
drugs, medical items, bottled blood.


Fuel consumption
~~~~~~~~~~~~~~~~

If you want to fly the Whale from one planet to another, you will of course
need  a  certain  supply  of fuel, which will depend on the distance to the
destination  planet.   If  also depends on how much cargo you have taken on
board.  If the hold is full, you will naturally need considerably more fuel
to cover the same distance.


Saving more than one position in a game
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In  the  Trading Menu you have the option of saving the current game to the
Save  Disk  supplied.  It is only possible to save ONE position in the game
on  this  disk.   If  you  want  to be able to save the game at a number of
different points, use a copy program to copy the Save Disk before you start
playing.   You will now be able to save different game positions to each of
your Save disks.


Creating new characters
~~~~~~~~~~~~~~~~~~~~~~~

If  you  want to start the game with a new crew, the first thing you should
do is store the game (press the "ESC" key in the Trading Menu), so that the
new  characters  are secure.  This allows you to continue with the old crew
when you start again (the OLD GAME option).


Dead characters
~~~~~~~~~~~~~~~

If  a  character dies in the course of the game, you will not be able to do
anything  with  the  character  for  the  time being; but there are ways of
bringing  him  back  to  life.  If you have a powerful magician or a doctor
among  the  crew,  who  is capable of bringing people back to life, you can
breathe  fresh  life  into your character.  However, if you cannot do this,
you  will  find  a "Healing Device" in some cities, which will allow you to
heal  wounds  or  bring people back to life.  The price for this depends on
the seriousness of the injury.


Political Background
~~~~~~~~~~~~~~~~~~~~

After  the  Great  Revolution  on  Irada  in  the  year  2291 by the Terran
calendar,  the  war  between  humans  and  Iradians  came to an abrupt end.
Freedom had a beneficial effect on all the races involved.  After more than
a  century,  the  enslaved  Sanxons  were able to form their own government
again.   The Iradian military class and the dictatorship which existed with
their  support  were  completely  eliminated.   Within 3 years, the Iradian
Empire  evolved  into  a  democracy  on the model of the United Continents.
With  Earth  supplying  economic  assistance  and  waiving  claims  to  war
reparation,  it  took  less  than  a  decade to establish a free market and
working democracy.

In  2035  the newly-established Union of Democratic Economies (UDE) decided
to unify interstellar trade and form a new organistaion which would combine
all  known  races  into  a  single  huge market.  This Cosmic League, as it
became  known,  set out to help the poorer populations such as the Iradians
and  Rexantas,  by  means  of a single currency and universal manufacturing
standards.

Each  planetary  system  was  assigned  a  Central  Government  responsible
directly  to  the League.  These centres were combined in a federal fashion
so  that  each  could pass laws which would be binding on all members while
within  the  respective  planetary  system.   These laws and the results of
their  application  were  reviewed  annually by General Inspectors from the
League and corrected where necessary.

As  time went by, the Cosmic League gradually acquired more and more power,
with   the  result  that  on  1/1/2371  the  League  amalgamated  with  the
governments  of  the  separate  Empires  with the aim of forming an overall
union.

In  the  framework  of  this organisation, the terrestrial solar system had
lost  its  central  position,  as Sol was located at the edge of one of the
spiral  arms  of  the galaxy.  The government and the League's headquarters
moved  to a planet which had hitherto been uninhabited and was known simply
as Z-1.

Some  years  later  an  experiment was started on Earth to re-establish the
natural  cycles  of  atmospheric regeneration.  Since 2087 work had been in
progress  to  cleanse  the  air and correct the oxygen deficiency resulting
from  the  imbalance  of  the biomass.  By the application of a new process
given the name Genesis II, it was envisaged that the natural proportions of
oxygen and C02 breathers would be restored over a 50 years period.


Background Story
~~~~~~~~~~~~~~~~

"Hey, Mike!  Look at this!" John shouted to his friend.  "There's some sort
of liquid running out of the wall!"

"This ship really is a pile of rust!" replied his chum in horror.

"Looks  like machine oil, kids," announced Frank, dipping his finger in the
viscous, dark-brown liquid and testing it against his tongue.

"Ugh!  It's oil from the hyperdrives," he confirmed, spitting out the trial
drop disgustedly.

"Keep  out  of  the hold unless you want another nasty shock," came a voice
from the aft end of the ship.  It was Sven, the fourth in the party.

To  understand  why  these  four  are so agitated, we need to look a little
further  into  the past - when they scraped together what little money they
had,  to  buy  themselves  an  impressive  but remarkably cheap second-hand
spaceship,  a  freighter  to be precise.  But as they later realised, their
purchase was not quite the bargain they thought.

And now the helpless crew are marooned in a ship which is falling apart, at
the  end of the galaxy in a distant star system far beyond Earth.  They are
drifting  in orbit around the planet Castra, as they can't afford the price
of fuel ...


THE PLANETS
~~~~~~~~~~~


LAPIS
~~~~~

This  planet is extremely inhospitable, as it is closest to the sun and the
climate  is  very  hot  and dry.  The settlers are few and far between, and
live  in  villages of container-like structures which can easily be rebuilt
in a different place.  This is necessary, as volcano eruptions are frequent
and  put  the  settlers  in  danger.   There  are  violent  sandstorms  and
"rockstorms",  which  have  left  the  containers  looking dusty, dirty and
dented.

The settlers' main source of income is mining, as Lapis is rich in ores and
minerals.   These  are  extracted  in extensive mining operations scattered
across the entire surface of the planet.

As  this rocky planet is a relatively long way from the system's centre, it
is  hardly surprising that a good many criminals and other shady characters
have  found  refuge  here.   This  makes  it  comparatively  dangerous  for
adventurers to move about on their own outside the protection of the city.

According  to  rumour,  more and more adventurers and treasure hunters have
amde for the planet recently:  it is said that out on one of the boundless,
unprotected plains where the rockstorms rage, a prospector came upon a huge
vein  of  platinum.   He  radioed the find through to his base station, but
before he could give its position he fell victim to the storm!  Ever since,
one  courageous  "scanner"  after  another  has  set  out  into the endless
wilderness in search of the mine, but very few return.


ARBORIS
~~~~~~~

As  Arboris  is  favourably  placed with respect to the sun, its climate is
ideal  for a thriving vegetation.  The entire surface is covered by a thick
jungle.

Obviously,  wood  is  available  in abundance, so the buildings are made of
this.   Most  of the other planets, however, do not have large resources of
this  material,  and  as  a  result the government has issued a firm ban on
exports  of  wood.  No one is permitted to trade in it on Arboris, as it is
clear  that  it is and important material, and that its importance can only
grow in the future.

Like  Lapis, Arboris is rich in mineral resources of all kinds.  This makes
these raw materials the main export.

Although  the  planet  is  only  at  an average technical level, a trade in
technically sophisticated articles is also flourishing.

As  the  climate  is  relatively pleasant and criminal activities have been
kept within limits, the planet is a popular holiday destination.


CASTRA
~~~~~~

Castra  was once the most technically advanced planet in this solar system.
Over  the  years,  however, more and more traders settlet here.  The result
was  that the pressure of competition increased to such an extent that many
traders could only keep their heads above water by adopting illegal methods
for  at  least  part of the time.  After a short time the economy on Castra
totally collapsed.

This  period  of great confusion was exploited by the criminal world.  More
and  more  shady  types  settled  on  Castra, and soon the once flourishing
metropolis had been transformed into a den of crime and corruption.

Only  after  decades  was  it  possible  to  restore  some order and regain
Castra's  reputation  as  a  technological trading planet.  But it is still
plagued by a very high crime rate.


SKY BOULEVARD
~~~~~~~~~~~~~

This  planet  was  formerly  known  as Decadence IV and was, like Castra, a
flourishing centre of trade and the seat of government.  The crime rate had
always  been  extremely  low  as  its  politicians  had set up an extensive
policing  system  for  their  own protection.  This enabled them to control
trade  and  prevent  a  collapse  of  the  system similar to that which had
overtaken Castra.

In  a  very  short  time,  Decadence  IV  had surpassed Castra in technical
advance  and  trade, and accordingly became the leader in the market.  With
its  rapid  rise to prosperity, the population could afford themselves more
luxuries.   There was also a large influx of immigrants which increased the
population several times over.

Only  a few years after its great trading rise, Decadence IV had achieved a
high  level  of  luxury.   This,  however, went together with an increasing
demand  for  energy.   The planet's reserves became consumed at a dangerous
rate  and  the  politicians only came to their senses once it was too late.
There  was no way of saving the devastated planet, whose atmosphere was now
poisoned to saturation.

A  great flood of migrating refugees began, as almost everyone sought a new
home  on another planet.  Those with power on Decadence IV, however, had no
intention  of  giving  up  the  planet on which they had so much influence.
Without  further ado, they decided to build a giant space station in orbit;
and Sky Boulevard was born.

The project was completed with feverish haste, and the remaining population
escaped from the planet at the last moment, before the biosphere collapsed.
In  their  new  life  in  space,  however,  they were confronted with a new
problem:   their  energy  reserves were in danger of running out.  As there
was  little  time  left,  a  snap  decision  was taken and a nuclear fusion
reaction  was initiated on the surface of the planet beneath Sky Boulevard,
to  supply  the station with light and energy.  As a result of this drastic
intervention  in  the  natural  order,  all  remaining  life  on the former
Decadence IV was destroyed.  From this time on, the surface was wreathed in
clouds of thick smoke and soot.  This brought temperatures down to freezing
point and made the planet an inhospitable place.  The new Sky Boulevard, on
the  other  hand,  was  provided with ample energy, and the once prosperous
centre  of  trade  and government woke from its sleep and once again became
the heart of the system.


NEDAX
~~~~~

Nedax  is  the  only  planet  in  the  entire  system with a surface almost
completely  covered  in water.  Life is impossible on the few small islands
as these are repeatedly submerged and swept clean by the strong tides.

The  only  way  of  colonising  this  planet was to build cities on the sea
floor.   For technical reasons, this was not possible on a large scale.  As
a  result, great numbers of people live together in a small space.  Despite
this, the crime rate is low.

Trade is also carried on in raw materials extracted from the sea floor.


INOID
~~~~~

Inoid,  at  2810  million  miles is the furthest planet from the sun and is
almost totally covered in a thick ice sheet.  The population live in cities
insulated from the bitter cold.

Trade is carried out in most available goods.



APPENDIX A
~~~~~~~~~~


JIM NIPPLE greets you:
~~~~~~~~~~~~~~~~~~~~~~

Welcome  to  my  little  hideaway!   I'm  glad  you  found your way here so
quickly.   I  chose this hiding place for a very good reason.  My work here
is  rather  dangerous.   You see this box of tricks?  It's a bugging system
which  lets  me listen to nearly every call made anywhere on Lapis.  It's a
real marvel of science!

As  it's a very mobile unit, I can dismantle is quickly and take it with me
to  a new hide-out.  This flexibility protects me against unexpected visits
by  secret  agents.   You're not safe for very long if you stay in the same
place.

Thank  you  for bringing me the implant so quickly.  It is for an important
man who has been very active in support of our organisation.  Unfortunately
the  Secret Service has been on our trail for quite some time, and they are
trying to prevent us from getting this man fitted with it.

As you've probably noticed, the situation in this star system is relatively
relaxed  on  the surface.  We live in a democracy, but in reality it's more
like  a  dictatorship.   After  all,  where  else would you find a complete
abscence  of  political  parties?   Opinions which differ from those of our
government  are  simply  not allowed.  They are not suppressed by using the
army, but - however paradoxical it sounds - by a massive bureaucracy.  This
mountain of officials blocks any and every plan by senseless activity.  The
worst  of  it  is that even they themselves don't know who they are working
for  -  or  against.   And we can only get through to the odd one or two of
them.

Our organisation is keen to have more people, so that we can overthrow this
system.  You have given us excellent support, and we would like to show our
gratitude.  We would be delighted if you would continue to work with us.