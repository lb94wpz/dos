 =============================================================================
                 "AMBUSH AT SORINOR" Manual Additions/Changes
                  --------------------------------------------

               To print this file, copy "README.TXT" to printer!
------------------------------------------------------------------------------
                              Machine Requirements

    IBM and 100% Compatibles

    Required:   IBM-PC/AT 12 Mhz '286 or faster
                640K Memory
                Hard Drive
                256 Color VGA graphics
                Mouse, 100% Microsoft (or Logitech) Compatible
 
    Supported:  XMS Memory
                Music & Digitized Sound Effects with 2 MB XMS memory on 
                 PC Speaker, Adlib, Sound Blaster and Compatibles

    Recommended: 16 Mhz '386SX or faster
                 DOS 5.0
                 2 MB XMS memory
----------------------------------------------------------------------------
     CLARIFICATIONS/ADDITIONS/CHANGES TO "AMBUSH AT SORINOR" GAME MANUAL:

    CREDITS
    -------
    "Ambush at Sorinor" Logo designed by Mike Armijo

    IBM INSTALLATION AND STARTUP (Page 2)
    ----------------------------
    Added information:
    The SHARE program has been reported to cause conflicts with our
    installation program.  If problems with installation occur and you
    are using SHARE, you may try commenting out the SHARE command in your
    system configuration or use the Mindcraft HELP program to create a DOS 5.0 
    boot disk. 

    GETTING STARTED (Page 3)
    ---------------
    Equipment Changes section:
    Reconfigure option on menu displays message about running the SETD.EXE
    program and does not do any configuration on its own. 

    If the sound equipment changes run the SETD.EXE program from the 
    DOS prompt in the "Ambush at Sorinor" subdirectory.

    THE MAIN MENU (Page 19)
    -------------
    New Campaign:
    When a new campaign is started, the Payment/Attitude rating bar will
    appear.  The manual description is incorrect and the number now 
    appearing is a number from 0 to 100 (50 is the default) which sets
    the initial attitude of the clans toward you.  The higher the attitude
    the more the clans like you and the more money they are willing to pay
    you for missions initially.  Selection of missions and success or failure
    will change the various clan's attitudes towards you as the game 
    progresses. 

    THE MAIN MENU (Page 20)
    -------------
    Other Menu:
    Reconfigure no longer runs the sound menu program. Instead, to allow 
    settings beyond default values the SETD.EXE program was implimented and 
    must be run from the DOS prompt.

    COMMAND ICONS (Page 22)
    -------------
    Group Report:
    For the escort player group reports also include the VIPs.
    Highlighting a group selects the new active group to issue orders to. 
    The screen will then become centered on the new active group.

    CHARACTER TABLES (Pages 51-53)
    ----------------
        Clan's Prices in the tables represent how much that unit charges
    to work for that particular clan.  For example: A barbarian hero would 
    charge the Rokan (barbarian) clan only 13 coins to work for them but 
    will charge the Ylatrius (Zorlim) 18 coins and other clans 16 coins. 

    TROUBLESHOOTING (Page 55)
    ---------------
    If sound problems occur within the game and you want to test for
    a sound board conflict, run the SETD program from the DOS prompt and
    choose one of the PC Speaker choices.

    Equipment Changes:
    If the sound equipment in your computer changes, run the SETD program
    from DOS instead of choosing Reconfigure from menu.

    GAME HOT KEYS (Back Cover of Manual)
    -------------
    F1 performs the same function as the END PLACEMENT/SYSTEM ICON.
    While placing and buying troops this will end the placement phase
    and start gameplay (the game will begin paused).  The End Placement
    Icon will be replaced by the System Icon.
     
    CLAN TABLE (Back Cover of Manual) 
    ----------
        The Clans are listed in an incorrect order on the back cover of 
    the manual.  The correct order is:

      1. ROKAN     (Barbarian Warriors)
      2. YLATRIUS  (The Zorlim Mages)
      3. GRLZX     (Orc Wanderers)
      4. DROKAL    (Dwarven Miners)
      5. TWILLIN   (The Spritely Elves)
      6. SERNEVAN  (Human Merchants)

        The Clan numbers used on the character tables in the manual are 
     correct.
---------------------------------------------------------------------------
IMPORTANT NOTES:

    Traps -
  
          When the computer is playing the ambusher, it will not 
    accidentally trigger its own traps.  As the the human attacker, 
    however, your troops may accidentally stumble across your own traps so 
    be careful when placing traps and/or troops.  Also keep a close watch 
    on your troops approaching traps.

    Choosing Missions -

        Clans will give you available missions depending on their attitude
    towards you.  Although the attitude sets which category (or price 
    range) the missions will be chosen from, individual missions will not 
    always increase in price each time.  A clan may, after you have 
    successfully completed a mission for them, offer you less money in the 
    next mission.  Working for their enemies, even though they are offering 
    more money, will of course lower your rating when dealing with the 
    first clan. 

    Dead bodies -

         When looking at a dead body, only the background tile will be
    listed.  In other words, looking at a dead orc warrior on the ground
    will say "Ground" and no mention of the orc as it is no longer an
    available troop.  Pressing F3 to activate the histogram will also
    not display dead troops, they have become part of the landscape.

---------------------------------------------------------------------------
                                 Sound Boards

         Use the SETD.EXE program to select sound boards and to configure 
     the sound driver for that board if not using default values.  The
     SETD.EXE program is automatically loaded the first time that you start
     the Ambush at Sorinor game.  If your sound board changes then run the
     SETD.EXE program from the DOS prompt inside the Ambush at Sorinor 
     subdirectory. 

          If you do not see your sound board listed and it is Sound Blaster
     compatible then choose the option for "Sound Blaster and compatibles".
---------------------------------------------------------------------------
                             -- Troubleshooting  --

    Error messages during the game are displayed to be self explanatory,
    for example "Mouse driver not detected" would tell you that you forgot
    to the load the 100% Microsoft or Logitech compatible mouse driver
    before running Ambush at Sorinor.

    Error messages related to memory problems will display what type of
    memory is insufficient such as "insufficient XMS memory" and what
    the results are, such as "Sound effects not available".  You will
    need to read the "Troubleshooting" section of the manual or run the
    HELP program to get help in clearing memory.

    Please see the "Troubleshooting" section of the manual and/or the
    options on HELP program for Sound Board, memory, and boot disk help.
---------------------------------------------------------------------------
                   INFORMATION ON OTHER MINDCRAFT PRODUCTS:       

 - Type PREVIEW to access Mindcraft online text information catalog.
   View descriptions of games currently available, upcoming game descriptions, 
   information on Mindcraft's BBS, and The Mind's Eye - Mindcraft's very own
   Newsletter. 
 =============================================================================
                               - END OF FILE -                  
