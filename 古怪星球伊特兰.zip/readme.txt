This review will be a bit different from the rest, since the introduction to the game is actually written on the back of the box and not given in the game itself. But before I write down the introduction there are a few things you'll need to know:

First of all, the game is completely controlled by your keyboard, so you will need to know which button does what.

Cursor Keys: Movement

T: Take
U: Use
S: Speak
L: Look
I: Inventory
D: Options
Spacebar: Shoot (in 3D travelling).

The game uses both a 3D first-person view mode (when travelling) and a typical adventure third-person view mode (when inside buildings and towns). Eternam was, as far as I know, the first game to use this approach, and it is a good one. The 3D engine they used is actually pretty good when it comes to creating a living world, but what really stands out in this game is the actual gameplay. Its humour rivals that of Terry Pratchett and Douglas Adams with animations and surprises that simply leave you speechless for a couple of seconds afterwards.

If you like a good laugh and enjoy twisted humour, this game is one that I would recommend.

Now the introduction:

Congratulations Don Jonz! You have just won a Virtual Adventure Vacation on Eternam, the biggest and best planetary Funpark in the galaxy.

Hard-working intergalactic Space Marshals like yourself deserve to experience the ultimate getaway. Travel through 3D landscapes to more than a half-dozen past human eras, populated with life-like bio-tech creatures offering tongue-in-cheek remarks. From the age of the pharaohs and the realm of medieval knights to the French Revolution and beyond, you��ll have the adventure of a lifetime�� or several.

But, Mister Jonz, there is a slight problem�� Dragoons still inhabit Eternam wanting to reclaim the park and have joined forces with your arch-rival Mikhal Nuke. They plan to ruin your vacation in a big way!

At least you can count on help from the beautiful Tracy, a technician on the Eternam coordination team. Unfortunately, to escape Nuke��s evil clutches, she has dematerialised into the Funpark��s computer network, so Tracy will communicate only via a computer screen.

You��ll need intuition, courage, wit, diplomacy, charm and a surreal sense of humour. Only you can save Eternam - - and yourself. But who wouldn��t face all challenges to win Tracy��s smile? So�� Enjoy your vacation, Mister Jonz!