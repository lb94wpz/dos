______           _        _________
|_   _ \         / \      |  _   _  |
  | |_) |       / _ \     |_/ | | \_|
  |  __'.      / ___ \        | |
 _| |__) |_  _/ /   \ \_  _  _| |_  _
|_______/(_)|____| |____|(_)|_____|(_)



- COMPLETE WALKTHROUGH FOR THE PC VERSION -


- Written by ManiacMansionFan -
- Contact: maniacmansionfan@hotmail.com -




*********** IMPORTANT INFO ***********

B.A.T. is a game developed by Computer��s Dream and published by Ubisoft in 1990.

This guide refers to the PC version. I have not played the game on other
supports and am thus unaware of potential differences between versions. If you
are playing on another support, this guide may be inaccurate.

Please do not distribute or reproduce the guide anywhere without my
explicit permission. The ONLY websites allowed to host it are:

* http://www.gamefaqs.com
* http://www.neoseeker.com
* http://www.supercheats.com

Please contact me if you see it reproduced anywhere else.




*********** CONTENTS OF THIS GUIDE ***********

BACKGROUND
CREATING YOUR AGENT
CONTROLS
B.O.B.
FIGHTING
GENERAL TIPS
WALKTHROUGH




*********** BACKGROUND ***********

Refer to the manual for the full background story. In a nutshell, you are a
22nd century secret agent and your goal is to locate and kill Vrangor, a
dangerous criminal. In order to find him you will also need to find and kill
Merigo, another criminal. Both are hiding on planet Selenia. You will win the
game when you have found and killed Vrangor.




*********** CREATING YOUR AGENT ***********

On the game��s title screen, right click with your mouse to edit the agent you
will be playing when you start a new game.

On this new screen, you can choose the weapon you start with, your agent��s name
and his aptitudes.

In order to change your weapon, browse through the different weapons available
and click ��TAKE�� or ��LEAVE�� accordingly (if the ��LEAVE�� option appears, it
means you are currently carrying that weapon, and if the ��TAKE�� option appears
it means you are not). Each weapon has a different weight, and you cannot carry
more than a certain limit. You can check out the weapon��s weight, its value and
the ammo it uses by clicking ��Information��. I recommend that you take the MOZ
(the one before last when going from left to right), it will be all you need.

The developers wanted to give this game an RPG edge and you can thus edit your
aptitudes by clicking the + and �C besides them, as you can often do when you
begin playing an RPG. Sadly, it seems they were overly ambitious when they
designed this feature and didn��t end up using it much within the game, so none
of this seems to really matter. You will be fine with the default profile.

Change your agent��s name if you want, and, when you are ready, save your agent
and go back to the main menu. This time, left click with your mouse to start
playing.




*********** CONTROLS ***********

The controls may feel awkward for someone used to playing modern games, but
don��t let it stop you from playing this fun adventure.

Clicking LEFT with the mouse will produce different results depending on what
your cursor currently looks like:

- Something that looks like an eye: This is the default cursor, it means there
is nothing special happening. Clicking will bring up your B.O.B. computer (see
the next section for more information on that).
- A 3D directional arrow: This appears when you hover on a pathway that will
take you to a different screen if you click on it.
- A 2D arrow pointing upwards: This appears when you hover on a machine that
you can use.
- A speech bubble: This appears when you hover on a character present in the
background image whom you can chat with. Clicking will bring up a menu where
you can say hello (this is always useless), ask them about Vrangor / Merigo /
the city, or ask them the time. This will be your number one way for finding
out what time it is (you��d think a guy with a computer implanted into his arm
would also have a watch, but no).
- A face with ��talking�� lines: It means a character is trying to talk to you.
Click if you want to talk, otherwise just ignore it. Most of the times the
people approaching you will have nothing interesting to say, save for a few
specific occasions.
- A triangle with a small arrow pointing upwards: You get this cursor in shops
where you can buy items. Click to browse what the person is selling.
- A bottle: This means you can either buy a drink (if you are at a bar) or
freely drink water (if you are at the fountain in the park).
- A heart: You will only see this in the night club. Click to ask a partner to
dance with you.
- A question mark: This indicates there is something there, but you cannot
access it because you are missing an item. You will not be told what it is you
are missing.

Clicking RIGHT with the mouse will bring up the game menu, where you can choose
between the following:

- Inventory: check out the inventory of what you are carrying.
- Look: don��t bother using this
- Search: use this to check a screen for hidden or dropped items
- Drop: drop unwanted items from your inventory
- Health: eat, drink or sleep. You must have food or beverages in your
inventory if you want to eat or drink. You can sleep anywhere, which is a good
way to make time go faster if you are waiting for a certain time.
- Help: use this to pause the game, turn on/off the music, save/load your game,
or quit




*********** B.O.B. ***********

B.O.B. is the computer implanted into your arm. It has four different programs:

--- PROG 1 ---

Check out your level, your experience, and your aptitudes. As mentioned before,
the RPG aspect of this game was not developed much, so none of this seems to
really matter.

--- PROG 2 ---

Check out your current health status. This screen will tell you if you are
hungry, thirsty, or wounded. Again, being hungry or thirsty unfortunately
doesn��t really matter as this feature was not developed properly (it supposedly
decreases your fighting abilities, but the difference is hard to notice).
However, it is good to know whether you are wounded. Your life potential
indicates the amount of energy you will have whenever you get into a fight.
Ideally, it should be at 99%. Anything less means you are wounded, and you will
die when it reaches 0%.

--- PROG 3 ---

This lets you switch your language decoder to ��Robot�� or ��Alien�� (a feature
that can be made obsolete with program 4, see below) as well as change your
heart rate. Again, the heart rate feature was not properly implemented and you
won��t need to bother with it.

--- PROG 4 ---

This ambitious feature lets you freely create programs that B.O.B. can use,
choosing from a bunch of pre-written command lines. You are probably starting
to know the drill by now: unfortunately, this is a good idea that doesn��t have
any real use, save for one exception. I strongly recommend creating a program
that automatically translates the language of whoever you are talking to, so
that you don��t need to constantly switch between ��Robot�� and ��Alien�� in program
3.

Click ��Edit�� to start a new program, then write the following code:
IF ROBOT
TRANSLATE ROBOT
END IF
IF ALIEN
TRANSLATE ALIEN
END IF
END

When you are done, click ��Quit��, then ��Save�� your program so that you don��t
need to retype it every time you start a new game. In the list that appears,
highlight your program��s name and click ��Run��.

In order to load your program when you start another game next time, click
��Dir�� to see the list of programs you have created, then highlight your
program, click ��Load�� and then ��Run��.




*********** FIGHTING ***********

Whether you choose to engage in a fight or are randomly attacked by somebody,
you need to know how the fighting screen works if you want to survive.

Let me start by saying that you only really need to fight twice in this game:
against Merigo and against Vrangor. All the other fights will serve no purpose
to you and will only work towards depleting your ammo, force field protection,
and/or life meter. Therefore, I recommend that you simply ESCAPE all fights
that are not against Merigo or Vrangor.

You will get into a fight if:
- You are talking to someone and choose the ��Attack�� option. You never need to
use this option, so stay clear of it.
- You get caught stealing from someone (they may first ask you to give the item
back, but not always).
- A killer robot sent by Vrangor finds you. This can randomly happen at any
time, on pretty much any screen, so be quick to react when the fighting screen
pops up out of nowhere.
- You have made enemies among the population. They may then randomly get into a
fight with you if they find you. If you stay out of trouble this shouldn��t
happen to you. However this will happen steadily more often if you keep killing
people.
- You find Merigo or Vrangor.

Now, let��s examine the fighting screen. At the top of the screen, from left to
right, you will see the ��Escape�� button, your weapons (if any) and your force
field protections (if any). At the bottom, you will see the state of your ammo,
your life meter, the state of your force field, and your enemy��s life meter.

Quite obviously, you need a weapon and some ammo if you want to kill anybody.
If you are missing one or the other, your only option is to escape. You will
start the game with a weapon of your choice (see the ��Creating your agent��
section above) but no ammo, so you will need to purchase that during the game.
You do not begin with any force field either, but using one is heavily
recommended so that it takes the damage instead of you. You should definitely
avoid any fighting until you have a weapon, some ammo, and a force field.

If you are ready to fight (which, I remind you, you only really need to do
against Merigo or Vrangor), you first need to click on your weapon and on your
force field to activate them. This must be done at the beginning of every
fight, even if you only have one weapon and one force field to choose from.
After this is done, place your cursor on your enemy (the cursor should change
into a target) and click as quickly as possible until you kill him.




*********** GENERAL TIPS ***********

- As noted above, escape all fights unless you are fighting Merigo or Vrangor.
There are no benefits to fighting other people.

- Try and keep your life potential at 99%, and always have some force field
protection and some ammo with you. If this isn��t the case, this should become
your priority before you resume your adventure.

- Watch your money and don��t run out of it. Especially make sure you always
have at least 5 credits remaining on your card. You can regain credits at the
arcade game, but only if you have at least the 5 credits required to start the
game.

- If you are in need of credits, play the arcade game. If you write down the
sequences on a piece of paper, it should be easy to win and regain credits.
Doing this, however, is slow and boring, and you shouldn��t need to resort to it
if you spend your money wisely.

- You have a limited amount of time to succeed in your mission, so keep that in
mind and avoid wasting too much time. You should be able to complete your
mission without particular hurry, as long as you don��t get arrested and have to
spend days in jail.

- Don��t ever steal from the shops. You will lose the ability to buy from them,
and will also probably get arrested, which will make you waste days that you
will spend in jail.

- If you wish to resist hunger, you will have to buy food from the food shops
(you can also sometimes steal some from the random passersby, but that is
riskier; it is also sometimes possible to buy the food from them). However, in
order to resist thirst, instead of spending money to buy drinks you can just go
to the fountain at the park and drink for free. Keep clicking on it until your
hydration level is back at 99%, even if the game tells you are not thirsty
anymore. In any case, avoid spending much money on food and do not ever spend
money on drinks since you can drink freely.

- If you visit the doctor after getting wounded, make sure your life potential
is back at 99% before you leave him. If you ask for a general check-up, he will
make you pay a fee and may give the impression that you are fully healed, but
that is not necessarily the case. Keep paying for surgery until you are back at
99%. Do not bother buying pills from him, his surgeon skills are all you will
need.

- Last but not least, as usual for these kinds of game�� save often! Use the
different slots you can save on so you can backtrack at certain points of the
game if needed.




*********** WALKTHROUGH ***********

The first sections of this document were largely spoiler-free, but the
walkthrough obviously contains SPOILERS, so stop reading here if you want to
beat the game on your own.

This walkthrough assumes you have read and understood what I wrote in the
previous sections, so you should read them if you haven��t already. B.A.T. is
not a linear game. Some parts are random and some details change from game to
game, therefore it is impossible to give you a perfect walkthrough that will
direct you from start to finish. I will however try to be as helpful and
complete as possible.


- First steps �C

Start by heading right to access the toilets. Inside, you will meet a contact
who will brief you on your mission and give you your equipment: the weapon you
chose (if you followed my advice, you chose the MOZ), a hologram of Merigo that
you will be able to show people (which would seem useful but is actually
useless) and a flyer (which is equally useless). Exit the toilets.


- Getting acquainted with the city �C

If you are new to the game, what you should do next is wander around the city
to find out where each important area is located, so you can access them again
quickly in the future. If you like pre-chewed work, I recommend that you check
out the JPG map I am uploading at the same time I am uploading this guide. It
indicates all the important areas and how to reach them.


- Acquiring krells, ammo and force fields �C

From the area you started in, go north twice to reach the astroport (on the
second screen, make sure you go north in the upper area of the screen,
otherwise you will enter a pub instead). There, enter the second building from
the left to be able to exchange your credits with krells. Use the machine and
exchange around 900 credits, which should provide you with enough krells for
now, while keeping some credits in your account. Make sure that at all times
you have at least 5 credits remaining on your card, as explained in the
��General tips�� section.

Back at the astroport, go north twice again. There, on the right side, is the
weapons shop. Enter it. You already have a weapon and don��t need another, so
what you want to buy is ammo. If you followed my advice and chose a MOZ, you
will want to buy E-300 ammo. It is not very expensive so buy two of them, and
you will easily be set for the whole game. If you chose another weapon, then
buy whatever ammo it uses (this is mentioned in the weapon��s ��Information��
option when you create your agent).

Now, exit the shop and go west. You will be in front of the doctor��s office,
you should not need him now but remember where it is located in case you need
it later.

Go south three times. You will be in a new area and the music will change. Go
north, then east, and you will find yourself in an alley. Enter the door on the
right to access the force field shop. Buy two Force 8 fields. If you don��t get
into unnecessary fights, this will be all you need to protect you during the
rest of the game. If you ever find yourself needing more, just remember where
the shop is.


- Finding the technician access card �C

Exit the shop and go north. Enter the big building, which turns out to be a
hotel. Here you will find an important item that someone forgot in a room. Talk
to the clerk and rent a room for one day. You can now go to the elevator on the
right to access your room. Go there and search it (by doing a right click and
choosing ��Search��) and you will find a technician access card. You will not
need this item until much later in the game, but since we were in the area it
was the perfect time to get it. Exit the room, talk to the clerk again to give
him back your key, and leave the hotel.


- Starting the search for Merigo �C

Backtrack to the place where you found the weapon shop. From there, go north
twice and you will be in front of a bar. Enter it and talk to the woman in the
zipper suit. Talk to her and ask her about Merigo. Pay her and she will tell
you that she heard a specific type of alien talking about him. This changes
from game to game so I cannot tell you what type of alien it will be, you need
to see it for yourself. You now have something to go on.


- Asking people about Merigo �C

Now that you know what type of alien could provide you with information, answer
every time a stranger is trying to talk to you (when you see a face with
��talking�� lines). If the person is not the right type of alien, just leave the
conversation. If it is the right type of alien, talk to him, and question him
about Merigo. Repeat this process until you find someone who says they can help
you and gives you an appointment at the museum in the park. Remember the time
he gives you so you can be there on time. (Note that this person will not react
if you show him the hologram of Merigo! Only questioning him about Merigo will
work. I told you the hologram was useless!)

It may (or may not) take a while until you are approached by the correct
person, so I recommend that you keep following the rest of the walkthrough in
the meantime, and check back here once you found him and set up the
appointment. Until then, you can jump forward to ��Getting Lydia and Sloane to
join you��.


- Appointment at the museum �C

Make sure to check the time regularly so that you don��t miss the appointment.
Also make sure that, when you come, you have at least 400 krells (if you don��t
want to have to steal) or 100 krells (if you don��t mind stealing).

From the doctor��s office, go north twice and you will be at the park entrance.
Enter the park by going west. Choose the right pathway and go north to be in
front of the museum. Enter it. When it is time for the appointment, answer when
a stranger is trying to talk to you: it should be the alien you have an
appointment with (if not, just leave the conversation and wait to be approached
by the right person). Question him about Merigo again, accept to pay him the
100 krells, and he will tell you Merigo is hiding at the Xifo Club. He will
also tell you at what time he saw him there: remember that time.

Don��t leave the conversation just yet, because the Xifo Club is a ��members
only�� club and you don��t have a member card, but this alien does. You can
either buy it from him for 300 krells (just choose ��Buy�� in the conversation
options) or attempt to steal it. In that case, steal from him repeatedly
(giving him the item back if you get caught) until he has had enough and starts
attacking you. Escape the fight immediately. If you were sufficiently lucky you
should have managed to steal the member card from him; check your inventory to
make sure.


- Confrontation with Merigo �C

Now, you will need to be at the Xifo Club at the time the alien said he saw
Merigo. Check the time regularly to make sure you get there on time. To find
the club, from the park entrance go north, then east twice, then north twice,
and the club will be on your right. If you don��t have a member card your cursor
will only become a question mark there, but if you do have the member card you
can enter.

Once you are at the Xifo Club, go north to the table around the center of the
screen and wait there until it is the time the alien told you. At this
particular time, Merigo will show up and immediately attack you, so be ready.
Activate your force field and your weapon, then fire at him until he dies.

On his death screen, search him (right click and ��Search��) to find an
electronic key you will need later on.

If you got hurt during the fight, you should now visit the doctor to get
healed. If you were fast enough to activate your force field, it should have
taken most, if not all of the damage. It is probably in a bad state by now, but
this is why we bought a second one.


- Getting Lydia and Sloane to join you -

Lydia and Sloane are two characters who can join you. You will need help from
both of them at certain points. If you come from the screen with the Xifo Club,
just go south twice. If you come from, let��s say the doctor��s office, go north
twice and you will be at the park entrance. From there go north, then east
twice.

Now, on your left is the video arcade where you can find Sloane between 1 and
3pm, and on your right is the night club where you can find Lydia between 2 and
4am.

Lydia:
Go right to enter the night club. Entering costs 50 krells, so only go if it is
the right time to meet Lydia. She will approach you as soon as you enter. Agree
to dance with her. If you want to convince her to join you you will have to be
a good dancer. Click alternately on your left and right mouse buttons, trying
more or less to follow the rhythm of the music. Do not click as fast as
possible as that does not work, just find the right rhythm that will make your
��love meter�� on the right go up. Make it go to the top and then keep the same
rhythm until the dance is over. Lydia will offer to join you, say yes.

Sloane:
Go left to enter the video arcade and make sure you have at least 1000 krells
on you (you will not spend them, but you need to have them to accept a bet). If
you have been following my walkthrough you will have more than that in your
pocket. If it is the right time, Sloane will approach you when you attempt to
use the video game. Agree to his 1000 krells bet and wait until he is done
playing (you don��t need to pay attention to what he does). When he loses, he
will tell you the level you need to reach in order to beat him. Play the game
and, unless you want to rely on your memory, write down the sequences on a
piece of paper so you can easily win. Numbering the symbols from 1 to 8 and
writing down the numbers might be easier than drawing the symbols. Once you
have reached the level Sloane told you to reach, you must lose in order to
finish playing (he will not accept it if you just try to stop playing). He will
then ask what you want. Say you want him to join you. He will also give you the
1000 krells anyway.


- Getting the Epsilon code and trying to rent a drag �C

Go south twice to arrive at the northern airlock entrance. Go north to enter
the airlock. The guard here normally would not let you pass, but Sloane has
connections and will talk to him to make him change his mind.

First of all, go west to access the technicians�� computer. Talk to the
technician on the left and he will let you use the computer, providing you have
the access card we picked up at the hotel earlier. Browse the stations list
until you find the ��Epsilon�� station, and write down the code, which will be a
combination of L (for left) and R (for right). The code varies from game to
game. We will not need to use this right now, but since we were in this area it
was a good time to get it out of the way.

Now, go back to the airlock and go north. Go north again (somewhere on the
right of the screen) and you can talk to someone who can rent you a drag. He
will ask for the exorbitant price of 5900 krells, which you most likely do not
have. However, Lydia will then intervene and give you the phone number of her
friend Crisa Kortakis, one of the big shots in town.


- Visit to Kortakis �C

The only phone in the game is located at the very first screen you were on when
you started playing, so backtrack all the way there. The phone is located on
the left. Dial the number Lydia gave you and arrange a meeting with Kortakis.

Now, go back all the way to the Xifo Club area (from the area where you could
enter the arcade and the night club, go north twice) and head north to access
Kortakis��s building. Go north and you will be allowed to enter, since you have
arranged a meeting. Ask Kortakis for credits. Kortakis accepts, and also gives
Lydia a jewel.


- Going underground �C

TO DO THIS PART OF THE GAME, YOU MUST HAVE DEFEATED MERIGO. IF YOU HAVEN��T DONE
SO YET, GET TO IT NOW.

Backtrack to the astroport. You are not going to be renting a drag just yet
after all. Kortakis added a lot of credits to your card, but the person who
rents drags only accepts krells, so keep in mind you will have to make some
change. Now is as good a time as any, since we are in the area. Exchange
credits until you have at least 5900 krells saved for later.

Now, head east (between the northern pathway and the hotel) to access a
derelict area. Go north and then north again to access the building. Merigo��s
electronic key allows you to access it; if you don��t have it, you will only see
a question mark there.

Go east and use the machine to enter a maze.


- Maze �C

Whoever designed this maze was one sick puppy. It is huge and all the corridors
look exactly the same, making it extremely easy to get disoriented and get
lost. On top of that, some of the gates you go through do not open again when
you try to go back, and at times you may find yourself in a dead end where your
only way out is to restart the game!

If you want to tackle the maze on your own, you MUST make a map of your
progress as you go along, otherwise I can guarantee that you WILL get lost,
unless you are incredibly lucky. If you want help, look up the JPG map with the
solution that I am uploading along with this guide.

I am also writing the solution here in case you cannot view the map:
First door on the left
Second door on the right
First door on the left
First door on the right
First door on the left
First door on the right
Second door on the right
Go forward until you go through a gate
*Make sure the opening you just went through is now located on your left (this
ensures you are facing the correct direction)*
First door on the right
Second door on the right
First door on the right
Go forward until you go through a gate

You have now arrived at the underground city. Go north, south, north, north,
west (it is the only way you can go apart from backtracking, so this is not
hard to figure out). You will arrive in a strange room and Lydia will notice a
hole shaped just like the jewel Kortakis gave her. Ask her to insert it, and
something will drop on the floor. Search the room (right click and ��search��) to
find yet another access card. This one will later on help us find the Epsilon
station where Vrangor is hiding.

Your job at the underground city is now done but if you think you can just
backtrack your way through the maze, think again: some of the gates you went
through will not open again, so you must find another way out. Go back to the
screen where you first arrived here and use the machine again.

Go forward until you go through a gate
*Make sure the opening you just went through is now located on your left*
Go forward until you go through a gate
*Make sure the opening you just went through is now located on your right*
First door on the left
*Make sure the opening you just went through is now located on your right*
Go forward until you go through a gate
Go forward until you go through another gate
*Make sure the opening you just went through is now located on your left*
Go forward until you go through a gate
*Make sure the opening you just went through is now located on your right*
First door on the right
First door on the right
First door on the right
First door on the left
First door on the left
Go forward until you go through a gate
*Make sure the opening you just went through is now located on your left*
First door on the right
First door on the right
Go forward until you go through a gate
*Make sure the opening you just went through is now located on your left*
Go forward until you go through a gate

And finally, you are out!


- Finding Vrangor �C

You are now ready to rent that drag and find Vrangor��s hiding place.

If you have not yet exchanged your credits to have at least 5900 krells, as
suggested above, do so right now. Also, make you sure are fully healed, have
some ammo, and at least one intact Force 8 field.

Head back to the northern airlock and you can now afford to rent the drag. You
are going to need the Epsilon station code soon (the one I told you to obtain
through the technicians�� computer earlier), if for some reason you have lost
it, get it again before you enter the drag.

Your drag is located around the left side of the screen. Use it.

You are represented by the little white dot on the radar. Moving your mouse
left or right will make you change directions accordingly. Clicking with the
left mouse button makes you increase your speed, while clicking with the right
button decreases it. Your default speed is pretty slow, so go into full speed.
Drive around until you see an orange dot: that is the Epsilon station where
Vrangor is hiding. The only way to locate it is to have the access card from
the underground city in your inventory: this is why we went through all that
trouble earlier. Go to that orange dot to enter the station.

Go south and use the panel to enter the Epsilon code. From top to bottom, push
the left or right buttons accordingly so that the lit buttons match the code.
When you are done, exit the panel and the door on the right can now be accessed
(otherwise you will see a question mark).

Go through the door. In a matter of seconds, Vrangor will appear and attack
you. Fight him the same way you fought Merigo and kill him.

Congratulations, you have completed B.A.T.! For all your efforts, all you get
is a static screen that reads: ��THE END / TO BE CONTINUED���� and the game then
resumes, although there is no longer any point to keep playing. Pretty
anticlimactic!









Written by ManiacMansionFan
Contact: maniacmansionfan@hotmail.com


Please do not distribute or reproduce this walkthrough anywhere without my
explicit permission. The ONLY websites allowed to host this walkthrough are:

* http://www.gamefaqs.com
* http://www.neoseeker.com
* http://www.supercheats.com

Please contact me if you see it reproduced anywhere else.