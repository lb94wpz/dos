                   
                            A R C A D E   P O O L 

                 The sensationally playable Pool Simulator!

                  (C) Copyright 1994 Team17 Software Ltd.
                     
                     Conversion by East Point Software.

              






                          
                          Arcade Pool Disk Options:


INSTALL         - Installs Arcade Pool to the path of your choice

SOUND           - Configures Arcade Pool Sound Driver (see later)

README          - These documents

INSTPX          - Installs a demo of Project-X to C:\PX

PXDEMO          - Runs a demo of Project-X from this disk

PREVIEW         - Short preview of some forthcoming titles from Team17



                               
                               

                               
                               
                               


                               ARCADE POOL:


Fancy a game of 8 Ball ? Wanna play US or UK rules ? What about 9 Ball, 
or even laying up some trick-shots ? Try your luck at 9 Ball challenge - or
see how fast you can clear up in Speed Pool!


Whether it`s you against any of 32 CPU opponents or against up to 7 friends, 
Pool allows you to set up your own tournament in the comfort of your own 
home... Betting and beers are optional!


Arcade Pool shows how Pool should be played, the display is clear and the
control exceptionally easy... No other Pool game has allowed you to cue'up
and go quite like Arcade Pool, within minutes of playing you`ll be slamming
the 8 ball down with ease!

                  
                        
                        CONFIGURING SOUND DRIVER:

       Arcade Pool currently supports 5 different modes of sound;

       SILENCE          -       No sound at all...
       BEEPER           -       Uses PC loudspeaker (ugh!)
       ADLIB            -       True Adlib card Support
       SOUNDBLASTER     -       Support for Creative Labs Soundcards
       ULTRASOUND       -       Support for Gravis Ultrasound (Reccomended)

       During the game, +/- act as sound volume over-rides.


                          
                          
                          
                          
                          
                          SYSTEM CONFIGURATION:

The performance will vary according the hardware inside your PC, but
if you have a 386DX+ machine and a good (fast) graphics card then there 
will be no problems. Memory shouldn`t be a problem as long as you have at
least a megabyte expanded memory, especially if running sound effects.



                                PROBLEMS ?

If you have any problems running Arcade Pool, do not hesitate to contact
Team17 software at the following...


SnailMail:
----------

Team17 Software Ltd, Customer Support, 
6 St Johns Square, Wakefield, West Yorkshire,
England WF1 2QX.



Voice/Digital Mail:
-------------------

Tel. UK [+44] (0)924 201846 10am-4pm GMT.
Fax. UK [+44] (0)924 385903 24hrs.



Email:
------
For those of you with access into Cyberspace...

Internet;                       CiX;
POOL@TEAM17.DEMON.CO.UK         TEAM17@CIX.COMPULINK.CO.UK        
