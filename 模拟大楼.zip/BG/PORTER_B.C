//*********************************************
//     BLOOD GROUP for HR2 THE SIMULATOR
//
//  NAME     :  PORTER type B
//  PURPOSE  :  seek R_FLAG->get ERG->
//              seek G_FLAG->put ERG
//              FAIL->go G_PYLON
//  CHARACTER:  Nebaru
//
//  WRITER   :  ARTDINK 1994/12/16
//*********************************************

main()
{
	int	ans ;
	int	echk ;
	int	try ;

	try = 0 ;
	do{
		echk = buggage() ;
		if( echk == FAIL ){
			ans = lets_go( R_FLAG ) ;
			if( ans == SUCCESS ){
				ans = get_erg() ;
			}
		}
		else{
			ans = put_erg( G_FLAG ) ;
		}
		if( ans == FAIL ){
			if( try < 2 ){
				ans = lets_go( G_PYLON ) ;
				if( ans == FAIL )	put() ;
				try++ ;
			}
			else{
				if( echk == FAIL ){
					error_act( LEFT,LEFT ) ;
				}
				else{
					error_act( RIGHT,RIGHT ) ;
				}
				break ;
			}
		}
		else{
			try = 0 ;
		}
	}while( ans == SUCCESS ) ;
	return( ans ) ;
}

lets_go( int target )
{
	int	ans ;
	int	p ;
	int	h ;

	if( target != G_PYLON ){
		ans = find( target ) ;
	}
	else{
		ans = find2( target ) ;
	}
	if( ans != FAIL ){
		p = place() ;
		h = high() ;
		do{
			ans = go( p,h ) ;
		}while( ans == CONT ) ;
	}
	return( ans ) ;
}

get_erg()
{
	int	ans ;

	ans = lets_go( ERG ) ;
	if( ans == SUCCESS ){
		ans = get() ;
	}
	return( ans ) ;
}

put_erg( int target )
{
	int	ans ;

	ans = lets_go( target ) ;
	if( ans == SUCCESS ){
		ans = put() ;
	}
	return( ans ) ;
}

error_act( int dir1,int dir2 )
{
	int	i ;
	int	chk ;
	int	dir ;
	for( i=0 ; i<4 ; i++ ){
		chk = i%2 ;
		dir = dir1 ;
		if( chk != 0 )	dir = dir2 ;
		round( dir ) ;
	}
}


