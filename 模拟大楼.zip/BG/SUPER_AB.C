//*********************************************
//     BLOOD GROUP for HR2 THE SIMULATOR
//
//  NAME     :  SUPER BUILD MAN type AB
//  PURPOSE  :  get ALL ERG->build ALL ORDER
//              FAIL->go G_PYLON
//  CHARACTER:  konjou?!
//
//  WRITER   :  ARTDINK 1994/12/16
//*********************************************

main()
{
	int	i ;
	int	ans ;
	int	echk ;
	int	job ;

	mem_reset() ;

	echk = buggage() ;
	if( echk == FAIL ){
		for( i=10 ; i<16 ; i++ ){
			job = recall( i ) ;
			ans = action_chk( job ) ;
			if( ans == SUCCESS ){
				ans = get_erg() ;
			}
			if( ans == SUCCESS ){
				break ;
			}
		}
	}
	else{
		job = recall( echk ) ;
		ans = put_erg( job ) ;
		if( ans == FAIL && job == WINDOW ){
			ans = put_erg( GATE ) ;
		}
	}
	if( ans == FAIL ){
		if( echk == FAIL ){
			error_act( LEFT,LEFT ) ;
		}
		else{
			error_act( RIGHT,RIGHT ) ;
		}
		ans = lets_go( G_PYLON ) ;
		if( ans == FAIL ){
			put() ;
		}
	}
	return( ans ) ;
}

mem_reset()
{
	memory( WHITE,WALL ) ;
	memory( L_GRAY,WINDOW ) ;
	memory( D_GRAY,PILAR ) ;
	memory( YELLOW,STAIR ) ;
	memory( BLUE,FLOOR ) ;

	memory( 10,STAIR ) ;
	memory( 11,PILAR ) ;
	memory( 12,WALL ) ;
	memory( 13,WINDOW ) ;
	memory( 14,GATE ) ;
	memory( 15,FLOOR ) ;

	memory( STAIR,YELLOW ) ;
	memory( FLOOR,BLUE ) ;
	memory( PILAR,D_GRAY ) ;
	memory( WALL,WHITE ) ;
	memory( WINDOW,L_GRAY ) ;
	memory( GATE,L_GRAY ) ;
}

action_chk( int o )
{
	int	col ;
	int	ans ;

	col = recall( o ) ;
	ans = find( o ) ;
	change( col ) ;

	return( ans ) ;
}


lets_go( int target )
{
	int	ans ;
	int	p ;
	int	h ;

	if( target != G_PYLON ){
		ans = find( target ) ;
	}
	else{
		ans = find2( target ) ;
	}
	if( ans != FAIL ){
		p = place() ;
		h = high() ;
		do{
			ans = go( p,h ) ;
		}while( ans == CONT ) ;
	}
	return( ans ) ;
}

get_erg()
{
	int	ans ;

	ans = lets_go( ERG ) ;
	if( ans == SUCCESS ){
		ans = get() ;
	}
	return( ans ) ;
}

put_erg( int order_type )
{
	int	ans ;

	ans = lets_go( order_type ) ;
	if( ans == SUCCESS ){
		ans = put() ;
	}
	return( ans ) ;
}

error_act( int dir1,int dir2 )
{
	int	i ;
	int	chk ;
	int	dir ;
	for( i=0 ; i<4 ; i++ ){
		chk = i%2 ;
		dir = dir1 ;
		if( chk != 0 )	dir = dir2 ;
		round( dir ) ;
	}
}

