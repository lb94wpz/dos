COMMANDER KEEN!!!
Commander Keen 4 Walkthrough Guide Version 0.15 - 9-01-2001
Under Construction.
Created by ?ther SPOON!, aetherspoon@hotmail.com
______________________________________________________________________________
|                               Table of Contents                            |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Section 1..(Not in final form)...............................Table of Contents
Section 2..(Complete)..........................................Version History
Section 3..(Not complete)..........Introduction to Myself and Commander Keen 4
Section 4..(Not in final form)........................................Bestiary
Section 5..(Complete)....................................................Candy
Section 6..(Complete)..............................................Other Items
Section 7..(Not complete).................................Complete Walkthrough
Section 8..(Complete)...................................................Cheats
Section 9..(Not started)...............................General Tips and Tricks
Section 10.(Not complete)................................................Other
______________________________________________________________________________
|                                   Bestiary                                 |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

BOUNDER
 According to Commander Keen 4, Bounders are red, friendly, bouncing guys that
 are annoying, but can be helpful too.  It is a non-combatant enemy (you can
 shoot it, but it will not kill you), although it CAN kill you (of course, you
 would need to be immensely stupid to be killed by it) by being on the bounder
 as it falls into a pit.  It is mainly there to help you.  Since you do not
 get points for shootings things in this game, it is useless to kill it unless
 you are in a rather sadistic mood :)  There are a couple of exceptions though
 ...  you can be pushed by them into a pit.
  Locations:  Mainly outdoors levels.
POISON SLUG
 According to Commander Keen 4, Poison Slugs are the most common creature in
 the Shadowlands, and can kill you two ways, either by its "remains", or by
 it's touch.  Poison slugs are probably the slowest creatures that you will
 ever find, and they are pushovers.  They tend to...  um..  excete some form
 of green poison...  excrement that goes away after around 5 seconds.  They
 are also deadly to the touch, so be careful.  Since they are so slow (and
 stop when they fart to...  um...  excrete), it is easy to jump over them.
 If you are an experienced CK player, there is no need most times to even
 shoot them.
  Locations:  Damn close to every level in the game.
LICK
 According to Commander Keen 4, Licks are blue beanbag-like monsters that
 breathe fire, and that is just what they are.  Not too hard to kill, but
 they are fast.  Touching them will NOT kill you, but their fire will.
  Locations:  Hardly anywhere in easy, everywhere in hard.
SKYPEST
 YE GODS these things are annoying...  According to our intrepid hero, these
 are virtually immune to all attacks...  the secret is when they are on the
 ground- your pogo stick can kill them believe it or not...  They kill by
 touch, unless they are on the ground and you pogo them.
  Locations:  Mainly outdoors levels.
MAD MUSHROOM
 The second type of non-combatant creature, these things kill you with there 
 touch, but you can't kill them....  your only chance is timing.  They will 
 bounce three times, then do a high bounce (sometimes landing on a different
 platform in some cases!), then repeat.  Just time it right.
  Locations:  Almost everywhere, with the first level being one of the few
   exceptions.
WORMOUTH
 Only a tad annoying, you should be able to dodge these green thingies.  In
 their "seeker" state, they look like a green pellet.  When they come after 
 you, they look like a green hungry hand puppet (well, that's what it looks
 like....  don't ask how I came up with that).  You can only shoot them in
 their "hungry" state, and they only come up for that when you are on top
 of them.  Occasionally they do come up.  My suggestion is (most times)
 just to jump over them.
  Locations:  Unknown.
INCHWORM
 These are non-combatants.  They do absolutly NOTHING other then follow you.
 They are only found in the Pyramid levels.  Well, they DO do something, but...
  Locations:  Temple of the Moon and Hillsville.
PRINCESS LINDSEY
 Yet another non-combatant friend, she will give you a little help on how to 
 do things....  I'm much better help in this FAQ though :)
  Locations:  Hillsville and Chasm of Chills.
FALSE ROCK
 For some odd reason, the Commander Keen 4 help files never mention this 
 fiend, but he exists all right...  killable, but also easily avoided.
 He can only hit you while launching himself in the air (his method of attack)
 and you can shoot him there.  I just walk past them most times.  He reacts to 
 you like the ghosts in Mario do- if you look at him, he won't move.
  Locations:  You hardly ever see him in easy (Hillsville being the first), but
  he is almost EVERYWHERE in hard other then the first two levels.  Pretty
  much, he can be in every level with a rock in it.

ARACHNUT
 "Insane, green, crab-walking creatures with two dangerous mouths."  Okay,
 these monsters are hard to deal with.  They CANNOT DIE.  They can, however, 
 be stunned.  When you shoot them twice (yes, twice), they fall to the
 ground. After about 4 seconds, they will start to get back up, then come
 back up to fight again.  Kills by the touch only, so you can pogo above it
 (sorta- it's tall).

BERKELOID
 Immortal creature, throws fireballs, kills with touch.  'nuf said.  Avoid.
  Locations:  Isle of Fire.
COUNCIL MEMBER
 Non-combatant friend (yes, friend).  These guys are immortal, and are
 almost literally walking exit points.  You need to rescue all 8 of these 
 members to beat Commander Keen 4.
  Locations:  Perilous Pit, Cave of the Descendents, Isle of Fire, Crystalus,
   Well of Wishes, Lifewater Oasis, Pyramid of the Shadows, and Pyramid of the
   Gnosticene Ancients.
COUNCIL JANITOR
 Tee hee hee :)
  Location:  Pyramid of the Forbidden
DOPEFISH (May the Dopefish be with you!)
 These creatures are legends in their own right.  Although they only appear
 in Commander Keen 4 (and one level at that), these are the only creatures
 that are actually worshipped outside the keen universe.  These are the
 second-dumbest creatures in the universe, and the thought patterns are
 "swim swim hungry, swim swim hungry" (kinda like me :)).  They are
 immortal since they are fish....  and you can't shoot anything in that
 level that they are on.
 They also have the COOLEST theme song in Commander Keen- "Eat your veggies."
 The only way around them is to make "sacrifices".  They are also rather funny.
 They can only kill you by eating you.  On easy, you will only ever find TWO
 Dopefish.  On hard, there are 7 Dopefish.
  Location:  Well of Wishes, and the fan pages of hundreds of thousands of
   people everywhere :)
EAGLE EGG
 A simple egg...  until you step on it.  See EAGLE SPAWN for more details.
  Locations:  Crystalus, Chasm of Chills.
EAGLE SPAWN
 Yipes!  One shot takes down these FLYING AND WALKING creatures, but they come
 back up in 4 seconds.  They most times come from eggs, but some levels on hard
 have the eagles pre-hatched.
  Locations:  Crystalus, any level with Eagle Eggs that have been hatched.
MAGES
 I have no idea what to call these things, but they steal items!
  Location:  Pyramid of the Gnosticene Ancients
MONTY PYTHON FOOT
 What, you didn't think Apogee had a sence of humor? 
  Locations:  Pyramid of the Moon and Pyramid of the Forbidden.
SCHOOLFISH
 Non-combatant, but useful "Follow the leader"s.  These are the things you use
 as sacrifices to the Dopefish.
  Location:  Well of Wishes.
SPRITE
 No, this is not the drink made by Coca-Cola :)  These are devils underwater.
 They can actually shoot you (unfair...  a monster can shoot but you can't:( )
 ....  Death by shooting or touch.
  Location:  Well of Wishes.
THUNDERSTORMS
 Yet another creature they left out of the help...  they shoot lightning bolts
 and follow you.  Unkillable, can only kill you with a lightning bolt.
  Locations:  Anywhere where there are clouds.

______________________________________________________________________________
|                               Version History                              |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
9-02-2001
Version 0.15- Outlined my route for beating the game and ALL enemy statistics!
  Everyone should cheer now or something :)  Also worked on Beastiary.
9-01-2001
Version 0.11- Finished Level 3 Easy.  Yeah, I'm working on easy for now, I'll
  get back to Normal soon enough, then hard.  Submitted to GameFAQs, but may
  not be posted because 0.15 was so close to it.
7-07-2001
Version 0.10- Found an error inside the FAQ (why doesn't anyone tell me these
  things?!), and finished Level 2...  easy.
6-16-2001
Version 0.09- Corrected two cheats, fixed one spelling error and one VERY
  large formatting error (seems I was doing 80 characters per line instead of
  79...  odd.), added Version History and intro.  Posting on GameFAQs and 
  RPGInsider.com.  Plugged my HTML version of this FAQ (finally remembered...)

  FAQ Denials-
   Cheating.de has been denied access to my FAQ.  I don't like spammers.
4-20-2001
Version 0.08- Started second level walkthrough, posted on GameFAQs
(unknown dates)
Version 0.07- Finished most other sections.
Version 0.06- Added other sections
Version 0.05- Finished first level walkthrough, posted on GameFAQs
Version 0.04- Started first walkthrough
Version 0.03- Continued organization
Version 0.02- Organization of FAQ
Version 0.01- Start of FAQ
______________________________________________________________________________
|                 Introduction to Myself and Commander Keen 4                |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Hello.  I'm the almighty ?ther SPOON!, sometimes known as aetherspoon (on the 
GameFAQs boards), ?ther SPOON! (on the RPGInsider.com boards), and on the rare
occasion, Spoon (on the RPGInsider.com website).  I'm a rather well known...
-being I guess you could say- on the GameFAQs boards, former IRCop there back
when the chat existed.  I'm also Co-Webmaster for RPGInsider.com (that's why 
I allowed my FAQ to go there :P), so I'm kinda well known/notorious there too.
I have a web version of this FAQ stored on my personal website
(www.aetherspoon.cjb.net it SHOULD be assuming cjb ever works...), and that is
also incomplete, but has some nice introductory work including things that
this FAQ will never cover, and has screenshots too!
I use two computers for this game- my 80386 PS/2 machine and my P3-850 machine
...  running the preview version of Connectix Virtual PC (no, that's not a
plug, I just like the program...) so I can actually take screenshots!
More on the game itself later, but my HTML FAQ has the basics of the game down
pat...  and it looks soooo pretty! :)

This game has the time honored tradition of being the game that peaked my 
interest in Commander Keens, and the cause of me purchasing Commander Keen 6
(my favorite Keen).
______________________________________________________________________________
|                             Candy (aka Points)                             |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Shikadi Soda (100 Points)
   Three-Tooth Gum (200 Points)
   Shikkers Candy Bar (500 Points)
   Jawbreaker (1000 Points)
   Doughnut (2000 Points)
   Ice Cream Cone (5000 Points)
______________________________________________________________________________
|                                 Other Items                                |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   Raindrops:  (NOTE:  I refuse to call them raindrops, they are tear drops
      darn it!)  "Floating in the sky are raindrops.  Since the water of
      Gnosticus IV has a life-sustaining energy, if Keen collects a hundred
      raindrops, he gets an extra life!" - Okay, get 100 and it does the same
      thing as having a lifewater flask.
   Neural Stunner:  This is ammo for your weapon.  'nuf said.
   Gems:  These things open doors....  at least this isn't Keen 6 where you
      have to kill Blooglets to get them...
   Lifewater flask:  1-up.
______________________________________________________________________________
|                            Complete Walkthrough                            |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                _______________________________________________
                |                 Shadowlands                 |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
If you really want to, you can visit the Bean-with-Bacon MegaRocket, but where
you need to go is Border Village, which is above the MegaRocket.
                _______________________________________________
                |         Bean-with-Bacon MegaRocket          |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  -1/10?  :)
******
*Easy* 
******
     No enemies, no way of dying, no items.
********
*Normal*
********
     Nadda.
******
*Hard*
******
     You get the idea.
                _______________________________________________
                |                 Shadowlands                 |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Now goto Border Village (above the Bean-with-Bacon Megarocket
                _______________________________________________
                |               Border Village                |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ************
  *Statistics*
  ************
Okay, here is your first real level.  The whole object of this level (as well
as many levels in CK4) is to reach for the exit, which is placed on the left
side of the level (unlike almost every other platform game in existence, you
can start off on the right side of the level).
Walkthroughs:  1 combined one (not much difference between the levels).
Number of Exits:  2
Difficulty of level:  1/10
  ************
  ****Easy****
  ************
Combatant Creatures: 
  2 Poison Slugs
Non-combatant enemies:
  2 Bounders
24 Ammo Found Total
Lives- 7 Bonus Lives can be found.
  ************
  ***Normal***
  ************
Combatant Creatures: 
  3 Poison Slugs
Non-combatant enemies:
  2 Bounders
15 Ammo Found Total
Lives- 7 Bonus Lives can be found.
  ************
  ****Hard****
  ************
Combatant Creatures: 
  3 Poison Slugs
  2 Licks
Non-combatant enemies:
  2 Bounders
15 Ammo Found Total
Lives- 7 Bonus Lives can be found.
 ************************
 **Combined Walkthrough**
 ************************
 When you enter, above you are 2 arcs (small formations of items that can be
 grabbed with one stroke) of teardrop crystals.  These can be obtained with or
 without the help of the bounder, but if you do not use the bounder, make sure
 you at least use the pogo stick...  This is also a great location to get used
 to grabbing these arcs since there are no enemies in the intro area other
 then the bounder.
 The first enemy you run across is a bounder.  
***BOUNDER BIO***
  According to Commander Keen 4, Bounders are red, friendly, bouncing guys
  that are annoying, but can be helpful too.  It is a non-combatant enemy (you
  can shoot it, but it will not kill you), although it CAN kill you (of course
  , you would need to be immensely stupid to be killed by it) by being on the
  bounder as it falls into a pit.  It is mainly there to help you.  Since you
  do not get points for shootings things in this game, it is useless to kill
  it unless you are in a rather sadistic mood :)  There are a couple of
  exceptions though...
---END BOUNDER BIO---
 Anyways, immediately after the hill (around the starting location of the
 bounder) is a small arc of Three-Tooth Gum (200 points each, 800 points 
 total).  If you continue down the path, you will see a little hut (well, it's
 just past the candy arc...  hard to miss).  If you press up, you will enter
 the hut.  The first hut has 4 Shikadi Sodas in it (100 points each, 400
 points total), and NOTHING else...  very small room if you ask me.  Be
 careful though...  when you leave the hut, you may have a poison slug right
 next to you.
 Speaking of the slug, this is the first thing that can kill you here.
***POISON SLUG BIO***
  According to Commander Keen 4, Poison Slugs are the most common creature in
  the Shadowlands, and can kill you two ways, either by its "remains", or by
  it's touch.  Poison slugs are probably the slowest creatures that you will
  ever find, and they are pushovers.  They tend to...  um..  excete some form
  of green poison...  excrement that goes away after around 5 seconds.  They
  are also deadly to the touch, so be careful.  Since they are so slow (and
  stop when they fart to...  um...  excrete), it is easy to jump over them.
  If you are an experienced CK player, there is no need most times to even
  shoot them.
---END POISON SLUG BIO---
 Anyways, since you are playing this game on easy, I would suggest you shoot
 the poor little thing.  When you reach the next house, this is where the path
 splits.  You can either 1) go into the house, or 2) stay on top.  I suggest
 doing both for the points, although it doesn't really matter too much if you
 are on easy anyways....
*****PATH DIVERSION 1: inside the house.****
  On Easy, this is the harder of the two routes, on Normal they are about the
  same difficulty, but on Hard, it is the easier of the two.  When you enter
  the house, you'll see two blasters to your left (bringing your blaster count
  to 20 on Easy), and two sticks of gum (200 points each, 400 points total) to
  your right.  Below the sticks of gum is the fire poll down to the level
  below.  The easiest way to go down polls most times is to go down partially,
  then quickly jump and fall the rest of the way down, but in this case, that
  is not necessary.  On your right are two Shikkers Candy Bars (400 points
  each, 800 points total).  Continue to the left until you reach a green pool
  of acid (deadly).  You'll see a rather odd looking arc of points:  two rows
  of soda, and one row of jawbreakers (100 points each for the two rows of
  soda, 1000 points each for the row of jawbreakers, 2400 points total).  This
  arc is possible on one pogo-assisted jump (and if you are good, one normal
  jump), but I would advise against it unless you are very good at this game
  since you CAN do two jumps....
  Right after the statue of the slug is the exact opposite pattern (100 points
  each for the two rows of soda, 1000 points each for the row of jawbreakers,
  2400 points total).  At this point, you can continue on to the left until
  you reach another fire poll, and go back up to the end of the diversion,
  which has 4 sodas in the room (100 points each, 400 points total).
*POINT SUMMARY FOR THE END OF DIVERSION 1*
     Points:  7800
     Teardrops:  8
     Blasters:  15 for Easy, 9 for Normal and Hard
     Keens:  0
*****PATH DIVERSION 2: outside the house.*****
  You should notice that there are some pits here with spikes on the bottom:
  remember what I said about bounders falling into these things?  Well, many
  times they will fall in this first one, other times they will go over it.
  The spikes are just long enough to hit you with a bounder in there....  and
  spikes will kill you of course.  Anyways, there is another small teardrop
  arc here, and you can get the entire arc by jumping over the spikes.  The
  next 2 sets of spikes have 3 tear drops in a row above them- if you aim for
  the middle one, you will get all three.  On hard, you get to meet your next
  enemy:  Lick
***LICK BIO***
  According to Commander Keen 4, Licks are blue beanbag-like monsters that
  breathe fire, and that is just what they are.  Not too hard to kill, but
  they are fast.  Touching them will NOT kill you, but their fire will.
---END LICK BIO---
  To be honest, I never even shoot the lick.  I get out of its way, and it
  ends up falling into the spikes.  Immediately after the spikes is another
  poison slug.  This one I do suggest killing, as it is in a rather 
  inconvenient spot.  There is a house here with a blaster inside.  If you
  have used two shots (one for each slug), you should have 8 or 11 after
  getting the blaster (each blaster gives 8 shots on easy, 5 on normal and
  hard).  Now, notice another bounder here....  when you are on the hill,
  look up.  You'll see an arc of gum high up (200 points each, 800 points
  total), and 2 teardrop arcs (bringing your total teardrops to  26).  The
  teardrop arcs do not need the bounder, nor does the gum arc, just use
  your pogo stick.  On hard, you will find another lick here, and I always
  use the bounder to go past him- I never touch him.  Sometimes the slug is
  here in Normal and Hard (see below after the diversion), which I do
  shoot.  You should reach the house and exit sign now.
*POINT SUMMARY FOR THE END OF DIVERSION 2*
     Points:  2000
     Teardrops:  26
     Blasters:  6 for Easy, 3 for Normal and Hard
     Keens:  0
--END DIVERSION--
 Right at the last house there is a slug in Normal- kill it.  Grab the
 teardrop arc now.  After you grab the arc, you should decide on going back
 to do the other path (I will assume you do).
 At this point, after you go back and do the other path, you should have:
     Points:  8600
     Teardrops:  30
     Blasters:  22 for Easy, 12 for Normal and Hard
     Keens:  0
 If you want, you can go to the exit now, however, there is a secret (and
 somewhat hard to reach) exit as well.
*****PATH DIVERSION 1: Normal Exit.*****
Left of the "above world" section.  Just keep going left and you'll reach it.
*****PATH DIVERSION 2: Secret Exit.*****
 Go underground (I suggest going through the exit from the underworld since it
 is most likely closer to where you are), and go to the slug statue area.  If
 you stand right at the left-most torch (the big one) and look up, you will
 see a section of the ceiling longer then the rest...  Pogo to it, and release
 the pogo when you reach it.  There is a itty-bitty ledge there for you to
 climb on.  NOTE:  For Normal and Hard (since the pogo doesn't go as high),
 you will have to pogo off of the lip of the green acid lake to this.  
 It's just a tad harder :)
 Now, you will see a elevated platform (that falls when you touch it).  I
 suggest starting up your pogo stick on the ledge, and make sure it reaches
 the maximum height (about 3 pogos) before you move and pogo onto the elevator.
 Keep the pogo stick on and go up and left, and you will see SEVEN life flasks,
 bringing your keens up to 10.  When you get all 7 flasks, go to the door up
 towards the top on the right (directly above the slug statue) to exit.
EXIT-
****SUMMARY: This level's stats****
     Points:  8600
     Teardrops:  30
     Blasters:  +22 for Easy, +12 for Normal and Hard (15 if you wanted to
       shoot the licks, but that is not necessary in my opinion)
     Keens:  7
                _______________________________________________
                |                 Shadowlands                 |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Current Status:
   Points:  8600
   Teardrops:  30
   Blasters:  27 for Easy, 17 for Normal and Hard
   Keens:  10
Now, you will have a choice.  You can either:
1) Goto The Perilous Pit (and rescue a council member)
2) Goto Slug Village
3) Goto the Water.
If you go to the water, young Billy Blaze will say he can't swim- we'll get to
that later.
I'm not going to The Perilous Pit because I'm going to do all the council
members LAST.
Guess what that leaves?  Slug Village....
Slug Village looks identical to Border Village, and is just a tad north of Slug
Village (if you miss it, you are blind :)).
                _______________________________________________
                |                 Slug Village                |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ************
  *Statistics*
  ************
Now we are getting somewhere, your first somewhat-difficult level...  Only two
major paths, and no secret exits....  Kinda straight forward, don'ts think? :)
Number of Exits:  1
Difficulty of level:  1/10 for easy, 2/10 for hard.
  ************
  ****Easy****
  ************
Combatant Creatures:  
  4 Poison Slugs
  1 Skypest
Non-Combatant Creatures:
  4 Bounders
  1 Mad Mushroom
 **********************
 **Walkthrough - Easy**
 **********************
 Start off with grabbing the 5-tear arc at the beginning.  If you mess this up
 , go back to playing Mario Brothers :P  Anyways, it's time for another
 patented CK4 path diversion!  
*****PATH DIVERSION 1:  Top of the world*****
  Note:  I do not suggest taking this path at all, I NEVER do.  EVER.  My 
  suggestion is go diversion 2, 3, 4, then 1 backwards.
  Jump over the first pit- that's the path of diversion two....   anyways, the
  tiny arc of 3 tears does require a pogo boost.  The next set is 4 teardrops
  in a row, which also requires a pogo boost:  watch out for the bounder and
  slug (which should be shot) though...  You should see the path start to go
  down hill and a small teardrop arc, but be careful- there is another slug
  there.  I suggest luring it to the top of the hill, then shooting it.  After
  it's "stunned", take a normal leap to get the drops.  You'll see a path
  above.  Go there, but watch out for this new and unique creature- the
  Skypest.  Although this is the end of the diversion, sometimes the Skypest
  interferes with this path.
***Skypest Bio***
  YE GODS these things are annoying...  According to our intrepid hero, these
  are virtually immune to all attacks...  the secret is when they are on the
  ground- your pogo stick can kill them believe it or not...  They kill by
  touch, unless they are on the ground and you pogo them.
---End Skypest Bio---
*POINT SUMMARY FOR THE END OF DIVERSION 1*
     Points:  0
     Teardrops:  11
     Blasters:  0
     Keens:  0
*****PATH DIVERSION 2:  Underground*****

  You now are going to get a glance at what most of CK looks like- underground
  .  When you reach the first pit, go down and immediately to the RIGHT.
  You'll enter a secret passage (there are two of them on this side, one
  further up then the other).  Inside the top secret passage is two candy bars
  (500 points each, 1000 points total), then go down to the left to get the
  Jawbeaker (1000 points each, 1000 points total), then right again to the
  other secret passage.  Keep going right, and you'll fall down a firepoll.
  Down below is an icecream cone (5000 points each, 5000 points total) and and
  a blaster.  Go all the way up the poll for six teardrops and two Jawbreakers
  (1000 points each, 2000 points total).  Anyways, go back down the poll part
  way and do a short jump, holding down left at the same time (trust me, it's
  easier then that).  For now on, I'll refer to that move as a polejump.
  Anyways, go left (out of the secret path) until you reach a pit and go down.
  Down here is your first encounter with the ever-so-famous "Mad Mushroom."
***Mad Muchroom Bio***
  The second type of non-combatant creature, these things kill you with there 
  touch, but you can't kill them....  your only chance is timing.  They will 
  bounce three times, then do a high bounce (sometimes landing on a different
  platform in some cases!), then repeat.  Just time it right.
---End Mad Mushroom Bio---
  To get everything (you may want to save here...  kinda tricky), you need to
  go under the mushroom, get all the stuff, then jump OVER the mushroom and
  get the rest.  Do NOT use a pogo stick here, just a normal jump.  All in all
  , there are eight teardrops and 3 Jawbreakers (1000 points each, 3000 points
  total).  Go back left again (using the pogo stick to get back up to the main
  level area again) and go up to get the two sticks of gum (200 points each,
  400 points total).  Fall down the next pit and get the two candybars (500
  points each, 1000 points total).  Jump towards the right to go into yet
  another secret passage.  Go right until you fall down.  Then go left....
  WAAAAY left.  You'll go to a small room with three blasters, two
  Jawbreakers (1000 points each, 2000 points total) and an Ice Cream cone
  (5000 points each, 5000 points total).  Go back right until you reach that
  hidden pit again, then pogo back up to the other pit (too many pits :) ),
  then pogo back up to the path again.  Grab the small arc of gum (200 points
  each, 600 points total), then go down to get the other two sticks of gum
  (200 points each, 400 points total).  Continue left, being grateful along
  the way for the fact that you chose easy instead of hard, and you'll see a
  firepole.  Go up it.  Now, you have ANOTHER diversion.  Path three will
  bring you to the rest of the points, path four brings you to the end of
  the diversion.  If you go to path three, you have to come back and do path
  four to finish the level.
*-*-*PATH DIVERSION 3: Lower Slug Village part two*-*-*
   Grab the arc of teardrops (4), and kill the slug.  Then grab the huge
   amount (9) of teardrops above the bounder, and enter the little area.  
   Here is your first look at a switch.  Hit up to switch it, which activates
   the extended area of the platform.  See what's below the platform?  Fire.
   Guess what happens when you fall in it?  :)  Anyways, there are three
   sticks of gum (200 points each, 600 points total) above the platform, but
   make sure you are confident in your jumping and pogoing, since the last
   piece needs a pogo boost.  My hint on that is to wait until the platform is
   moving RIGHT, then pogo, hit the candy, and move a bit right.  The platform
   will be right below you when you land (most times).  Keep following the
   path, picking up three more sticks of gum (200 points each, 600 points
   total).  At the end of the path is your reward:  2 Doughnuts (2000 points
   each, 4000 points total) and a blaster.  Return to the location of the pole
   again and start diversion 4.  Curiously enough, if you have gotten every-
   thing at this point, you will have 35000 points even....  odd :)
-POINT SUMMARY FOR END OF DIVERSION 3-
     Points:  5200
     Teardrops:  11
     Blasters:  8
     Keens:  0
*-*-*PATH DIVERSION 4:  Returning to the Skies*-*-*
   Oh gee, this is real hard.  If you can't figure out where to go when you go
   right, you need more then this FAQ :P  Grab the arc of teardrops (3) to the
   right, and you've finished the diversion.  Yep, that's it.  Although this
   is the end of the diversion, sometimes the Skypest interferes with this 
   path.
-POINT SUMMARY FOR END OF DIVERSION 3-
     Points:  0
     Teardrops:  3
     Blasters:  0
     Keens:  0
*POINT SUMMARY FOR END OF DIVERSION 2*
     Points:  26400
     Teardrops:  30
     Blasters:  40
     Keens:  0 (I am not counting keens from points and teardrops)
*****DIVERSION REUNION*****
 This Skypest, however, tends to fly off into the air and leaves the level
 (oddly enough).  Anyways, right after the pest is yet another slug.  See the
 bounder?  DO NOT SHOOT IT!  Right above the bounder (you can't see it unless
 you look up) is a rather large area of tear drops and an ice cream cone (5000
 points each, 5000 points total).  Get the last 5-tear arc, and you are done!
 Well...  assuming you went backwards along the first diversion. :)
****SUMMARY: This level's stats - Easy****
     Points:  31400
     Teardrops:  70
     Blasters:  +41
     Keens:  0
  ************
  ***Normal***
  ************
Combatant Creatures:  
  6 Poison Slugs
  1 Skypest
  2 Licks
Non-Combatant Creatures:
  4 Bounders
  1 Mad Mushroom
 ************************
 **Walkthrough - Normal**
 ************************
 For now on, the Walkthroughs for Normal will be slightly condense compared
 to the walkthrough for Easy.  If you need more details, just read both. :)

 Anyways, jump over the first slug.  Not hard.
*****PATH DIVERSION 1:  Top of the world*****
  Right across the gap is another slug.  I would shoot this one mainly 
  because he (she?  it?!?) tends to be in the way.  Further down the path, 
  you'll see TWO more slugs (got the reason why it is called slug village
  yet?).  You should be able to avoid both of them.  That's it.  Short, eh? :P
*****DIVERSION REUNION*****
  Your standard Skypest (just one), then another slug and a lick.  I HATE
  LICKS!!!  This one I killed since the lick is right by the bounder for the 
  hard-to-reach drops/candy.
  ************
  ****Hard****
  ************
Combatant Creatures:  
  10 Poison Slugs
  2 Skypests
  6 Licks
  5 Wormouths
Non-Combatant Creatures:
  3 Bounders
  1 Mad Mushroom
 **********************
 **Walkthrough - Hard**
 **********************
To be completed....
                _______________________________________________
                |                 Shadowlands                 |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Current Status:
   Points:  40000 (HERE 1ups are counted in tallys from score bonuses)
   Teardrops:  0 (1 keen gained from drops included in tally)
   Blasters:  63 for Easy, ?? for Normal and Hard.
   Keens:  13
All right....  you can go almost anywhere now...  anywhere but the water.
So, I'll bring you to the next easiest (and not required whatsoever) level- 
  Hillsville
                _______________________________________________
                |                 Hillsville                  |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  ************
  *Statistics*
  ************
Now, this is most likely the first somewhat hard area of the game (using the 
term "hard" loosely).  This isn't exactly a Crystalus or a Well of Souls, but 
it is STILL hard compared with the two "sluggy" towns.  Or is it?  Heck, you 
shouldn't even need to use your BLASTER the entire level...
Number of Exits:  1
Difficulty of level:  0/10 if just trying to beat it, 3/10 to get items, 4/10
 for hard.
  ************
  ****Easy****
  ************
Combatant Creatures:  
  3 Rocks (yep.  That's it.)
Non-Combatant Creatures:
  1 Bounder
  2 Mad Mushrooms
  2 Inchworms
  1 Princess Lindsey
 **********************
 **Walkthrough - Easy**
 **********************

  First thing you see is your new favorite friend, the Inchworm.
***INCHWORM BIO***
  These are non-combatants.  They do absolutly NOTHING other then follow you.
  They are only found in the Pyramid levels.  Well, they DO do something, but..
---END INCHWORM BIO---
  Grab first teardrop arc (4 drops), then proceed to the right.
  There is a Shikkers Candybar arc above the first pit area (500 points each,
  2000 points total) and hidden platform to the left of the first pit.
  You'll see a shiny reflection if you look long enough.  To reach it, jump to
  the highest hill, pogo to it and stop.  WAY up and to the left is another
  platform (this is the short way to reach it, you are actually skipping one).
  Now you'll see floating platforms above you- DO NOT HIT THE FIRE!.  Heck, 
  you can't even walk off the platform as the fire has a radius around it that
  you can't hit...  Immediately to the right of you is another hidden platform,
  Do a short jump to that, then pogo up to the jet platform.  Going left on the
  jet platforms are a jawbreaker (1000 points each, 1000 points total) and
  an arc of blasters (4).  At the end of the left side is a drop down to the
  beginning of the level with two doughnuts (2000 points each, 4000 points
  total).  Go back to the jet platforms. Going right from that last hidden 
  platform is another jawbreaker (1000 points each, 1000 points total), 2 
  doughnuts (2000 points each, 4000 points total), and you'll reach the end of
  the platform...  Or did you?  In reality, there is YET ANOTHER hidden
  platform to your right, and a lifewater flask above and to the right of it.
  Fall straight down from that flask, landing by ANOTHER inchworm (they are
  VERY helpful if you couldn't tell..  one where the secret started at, the
  other where it ended at).  Now, backtrack to the left until you reach the
  point at which you were before (the point where you jumped on the first 
  hidden platform.  On your way, you'll see one hill with a teardrop arc (4
  drops), and a 'shroom right after.  Platform to the left of the shroom has
  2 Shikkers Candybars (500 points each, 1000 points total) and another
  teardrop arc (4 drops).  Now you have returned from where you started from,
  so go back to the right (getting tired of backtracking yet?  :P) until you 
  reach a very steep hill.  Look up at the top of the hill and go meet her
  (while getting the 5 teardrops) royal highness, Princess Lindsey.
***PRINCESS LINDSEY BIO***
   Yet another non-combatant friend, she will give you a little help on how to 
   do things....  I'm much better help in this FAQ though :)
---END PRINCESS LINDSEY BIO---
  Guess what?  You get your first in-game conversation now!  Yay or something!
*****CONVERSATION: Lindsey vs. Keen*****
    Princess Lindsey:  There's gear to help you swim in Three-Tooth Lake.
       It is hidden in Miragia.
    Commander Keen: Thanks, your Highness!
-----END CONVERSATION-----
  Go down and flip the switch, grabing both Shikadi Sodas (100 points each,
  200 points total) and return to the hill.  I'm taking the bottom route first. 
*****PATH DIVERSION 1:  Fury hath no Doughnut*****
    Ignore the platform and grab the two sticks of gum (200 points each, 400
    points total)  Now, this is the tricky part- playing with fire.  Jump right
    BEFORE you reach the fire- it is kinda tricky to do.  Now, I suggest you
    save. :)  You should see 2 doughnuts there.   DO NOT TRY TO GET BOTH AT
    ONCE!!!  You are going to do something else- one at a time.  Pogo over the
    fire while facing the OPPOSITE direction, and try to pogo over the fire
    completely.  Now you should have grabbed one doughnut (2000 points each, 
    2000 points total) and be facing right.  Pogo over the fire AGAIN to grab
    the other doughnut (2000 points each, 2000 points total) and return to the
    moving platform and diversion 2.  Chances of success of getting it the 
    first time without dying is around 1%.  Yes, it is actually possible, I've
    done it before.  This is the only hard part about this level.
*POINT SUMMARY FOR THE END OF DIVERSION 1*
     Points:  4400
     Teardrops:  0
     Blasters:  0
     Keens:  0
*****PATH DIVERSION 2:  Elevator Wars*****
    Jump on to the moving platform.  At the apex of the moving platform, you'll
    see 4 jawbreakers (1000 points each, 4000 points total) and a blaster.  Get
    them (duh), it isn't hard to do.  Now, move along the horizontal moving 
    platforms.  You'll notice some jets above you- ignore them for now.  Get
    the teardrop arc (4 drops) and move on down.  Grab the 2 Shikkers Candybars
    (500 points each, 1000 points total), going underneath the 'shroom.  Now, 
    I kinda lied....  there are THREE diversions.
*POINT SUMMARY FOR THE END OF DIVERSION 2*
     Points:  5000
     Teardrops:  4
     Blasters:  8
     Keens:  0
*****PATH DIVERSION REUNION/DIVERSION 3:  Jet Set Platforms Mark II*****
    Keep going until you reach three rocks and a teardrop- DON'T GET THE ARC
    YET.  First, we'll deal with these "false" rocks.
***FALSE ROCK BIO***
 For some odd reason, the Commander Keen 4 help files never mention this 
 fiend, but he exists all right...  killable, but also easily avoided.
 He can only hit you while launching himself in the air (his method of attack)
 and you can shoot him there.  I just walk past them most times.  He reacts to 
 you like the ghosts in Mario do- if you look at him, he won't move.
---END FALSE ROCK BIO---
    Anyways, I lure them in to that spike pit.  If they go in there, they can't
    jump out, and you won't need to shoot. :)  Anyways, to the left of the tear
    drop arc and WAAAAY up, you'll see a glimmer.  Yep, yet ANOTHER hidden
    platform.  How to reach it that high up?  Easy- the bounder there.  Aren't
    you glad you didn't shoot this level?  :)  After you get up there, another
    hidden platform is above and to the right of it, but we are going to ignore
    that one to get the next one- WAAAY up and slightly to the left.  Two more 
    hidden platforms exist to the left until you reach the jet platforms
    (again).  Go left first and grab the arc of jawbreakers (1000 points each,
    4000 points total) and the blaster on the end.  Now go to the right and
    grab that icecream cone (5000 points each, 5000 points total)!  Fall back
    down from the cone.
*POINT SUMMARY FOR THE END OF DIVERSION 3*
     Points:  9000
     Teardrops:  0
     Blasters:  8
     Keens:  0
*****PATH REUNION*****
  Grab the teardrop arc (4 drops) and Shikkers candybars (500 points each, 1000
  points total) and leave the level.  That's it!
****SUMMARY: This level's stats - Easy****
     Points:  33100
     Teardrops:  25
     Blasters:  +38
     Keens:  1
  ************
  ***Normal***
  ************
Combatant Creatures:  
  3 Rocks 
  2 Poison Slugs
Non-Combatant Creatures:
  1 Bounder
  2 Mad Mushrooms
  2 Inchworms
  1 Princess Lindsey
 ************************
 **Walkthrough - Normal**
 ************************
Not complete!
  ************
  ****Hard****
  ************
Combatant Creatures:  
  3 Rocks
  10(!) Poison Slugs
  6 Skypests (still counting though, could be more since they fly off...)
Non-Combatant Creatures:
  1 Bounder
  2 Mad Mushrooms
  2 Inchworms
  1 Princess Lindsey
 **********************
 **Walkthrough - Hard**
 **********************
Not complete!
                _______________________________________________
                |                 Shadowlands                 |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Current Status:
   Points:  73100 
   Teardrops:  25 
   Blasters:  111 for Easy, ?? for Normal and Hard. (Your scorebox will only
       say 99, but if you hit enter you see the true total)
   Keens:  14

Now, I haven't finished this part of the walkthrough yet, but I'm going to list
the enemy statistics for EVERY level (Easy only), and in order too!  :)

                _______________________________________________
                |                   Miragia                   |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  0/10, 2/10 to get everything, 3/10 for hard.

  ************
  ****Easy****
  ************
Combatant Creatures:  
  7 Poison Slugs
Non-Combatant Creatures:
  4 Mad Mushrooms

                _______________________________________________
                |                  Sand Yego                  |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  2/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  7 False Rocks
  4 Poison Slugs
  2 Aracnuts
Non-Combatant Creatures:
  1 Mad Mushroom

                _______________________________________________
                |               Chasm of Chills               |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  5/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  3 False Rocks
  2 Licks
  2 Poison Slugs
Non-Combatant Creatures:
  6 Thunderclouds
  2 Mad Mushrooms
  2 Eagle Eggs
  1 Princess Lindsey
  
                _______________________________________________
                |             Pyramid of the Moon             |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  4/10, 8/10 to get everything and the foot.
  ************
  ****Easy****
  ************
Combatant Creatures:  
  1 Poison Slugs
  1 Lick
  1 Aracnut
Non-Combatant Creatures:
  12 Inchworms
  1 Monty Python Foot

                _______________________________________________
                |           Pyramid of the Forbidden          |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  7/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  7 Poison Slugs
  5 Licks
Non-Combatant Creatures:
  1 Mad Mushroom
  1 Council Janitor
  1 Monty Python Foot

                _______________________________________________
                |                 Isle of Tar                 |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  6/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  7 Poison Slugs
  5 Wormouths
  1 Skypest
Non-Combatant Creatures:
  1 Mad Mushroom

                _______________________________________________
                |              The Perilous Pit               |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  0/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  None!
Non-Combatant Creatures:
  3 Mad Mushrooms
  1 Bounder
  1 Council Member

                _______________________________________________
                |               Lifewater Oasis               |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  2/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  2 Poison Slugs
  1 False Rock
Non-Combatant Creatures:
  1 Thundercloud
  1 Council Member

                _______________________________________________
                |           Cave of the Descendents           |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  3/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  3 False Rocks
  1 Poison Slugs
  1 Skypest
Non-Combatant Creatures:
  7 Mad Mushrooms
  1 Council Member

                _______________________________________________
                |            Pyramid of the Shadows           |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  6/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  7 Poison Slugs
Non-Combatant Creatures:
  1 Council Member

                _______________________________________________
                |      Pyramid of the Gnosticene Ancients     |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  10/10 to get everything, 6/10 normally.
  ************
  ****Easy****
  ************
Combatant Creatures:  
  7 Poison Slugs
  2 Mages
Non-Combatant Creatures:
  1 Council Member

                _______________________________________________
                |                 Isle of Fire                |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  4/10
  ************
  ****Easy****
  ************
Combatant Creatures:  
  6 Poison Slugs
  5 False Rocks
Non-Combatant Creatures:
  1 Berkloid
  1 Council Member

                _______________________________________________
                |                Well of Souls                |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  9/10 for easy, 10/10 for hard.
No pogo, no blaster.  Oh crap. :)
  ************
  ****Easy****
  ************
Combatant Creatures:
  You can't even shoot, how are you going to combat these things?  :P
Non-Combatant Creatures:
  24 Schoolfish
  1 Sprite (not a six-pack)
  2 Dopefish (Dopefish Lives!  Worship the Dopefish!)
  1 Council Member

                _______________________________________________
                |                  Crystalus                  |
                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Difficulty of level:  10/10 for easy, 9/10 for hard.
NOTE:  IMPOSSIBLE POGO TRICK REQUIRED FOR GETTING EVERYTHING
  ************
  ****Easy****
  ************
Combatant Creatures:  
  3 Poison Slugs
Non-Combatant Creatures:
  5 Mad Mushrooms
  1 Eagle Egg
  1 Council Member

______________________________________________________________________________
|                                   Cheats                                   |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Come ON People!  You don't need to cheat for THIS....

In case you do though.....  
(Cheats originally located in the program "Cheat v.26.0" and also at 
Gamesages)
These are not from me, but I do know them by heart, so I could say that they
are mine, but I'm honest :)  Also, you can get the cheats at 
http://www.3drealms.com/cheat/keen4.html, that's the official page for them.

To enter Debug Mode, hit A+2+Enter.  This will activate the Debug Keys. Once 
you do this, do any of the following codes:
NOTE:  Cheat keys are not officially supported by Apogee. If you use the debug
 keys, Apogee cannot provide any support, since this alters game performance
 to a state where our standard support comments and issues might not apply.
 In short, using cheat keys can cause the game to malfunction or crash. Use
 at your own risk!  (Excerpt, Apogee/3DRealm's official website)

F10 + B = Border color (anywhere from 1-15).
  Border Colors (only works in the EGA/VGA version, CGA colors vary):
    0 = Black (Valid color in CGA version)
    1 = Blue
    2 = Green
    3 = Cyan (default color in the VGA version, valid color in CGA version)
    4 = Red
    5 = Magenta/Purple (Valid color in CGA version)
    6 = Brown
    7 = Greyish White (Valid color in CGA version)
   After 7, they repeat again.  These are colors for BASIC if you didn't know.
F10 + C = Object count.  You get to see the # of Active/Inactive objects in
  the map.
F10 + D = Record a demo.  WARNING:  This tends to crash.
F10 + E = Beat current level.  If used in the world map, you beat the game.
F10 + G = God Mode.  You can't be hit, but you can still die by reaching the
  bottom of a level...  sometimes covered in water or oil.
F10 + I = Free Items (3000 points and 99 blasters)
F10 + J = Jump Mode.  This is a rather useful cheat- you can jump as high as 
  you wish.  No pogo needed (CK 1-3 used to need the pogo to do this). There
  is one side effect though- you need to turn the jump mode off if you wish
  to jump down from any ledge.
F10 + M = Current Memory usage.  After you hit enter from the screen, the 
  screen will look messed up- hit enter again to return to the game.
F10 + N = No clipping.
    On the World Map:  You can walk ANYWHERE.  Well...  almost.  You cannot 
      walk on any beach (sandy area) w/o the diver suit, and you cannot walk 
      off the edge of the map- it is the only way to actually die on the world 
      map :)  If you turn it back on, either you will stay in that terrain, 
      or you will be bumped to a movable path.
    In a level:  You better use Jump Cheat with this....  otherwise you WILL
      die.  If you fall off the bottom of a level, you will die.  If you turn
      this on in a wall, unexpected things may happen.  Note that even with
      God Mode on, you will still die.
F10 + S = Slow Motion.  Eeep.  Slow motion is annoying and useless.
F10 + T = Sprite Test.  No, this isn't a soda tasting contest :)  Hit ESC
   to leave the test.
F10 + V = Add VBLs.  I have absolutely no freaking clue what this is. (0-8)
   Note:  According to the 3DRealms/Apogee website, VBL stands for Vertical
   Blinking Signal, and said that it will do nothign for most users.
F10 + W = Level Warp.  Here is the list of levels:
     Level Warp levels. (Possibly the order in which you are to beat them?)
         Level 01- Border Run
         Level 02- Slug Village
         Level 03- Perilous Pit
         Level 04- Cave of the Descendents
         Level 05- Chasm of Chills
         Level 06- Crystalus
         Level 07- Hillville
         Level 08- Sand Yego
         Level 09- Miragia
         Level 10- Lifewater Oasis
         Level 11- Pyramid of the Moons
         Level 12- Pyramid of the Shadows
         Level 13- Pyramid of the Gnosticene Ancients
         Level 14- Pyramid of the Forbidden
         Level 15- Isle of Tar
         Level 16- Isle of Fire
         Level 17- Well of Wishes
         Level 18- Bean with Bacon Megarocket (also the easiest spot to leave)
F10 + Y = View Clipping.  You get to see where you can walk....  it makes it 
  easier for you to view where secret areas are.  Note that this is turned off
  after you leave the game- you can't turn it off.  (Thanks to Global Enemy
  for the reminder about that!)
Non-Debug Mode Cheat:
T+A+B (does not require debug mode) = 99 blasters, 4 shells, and a
  keen.  It is also the only way to get shells in the Shadowlands :)
F9 = Boss Mode.  It will drop you down to what looks like a DOS Prompt
  Oddly enough, this cheat is NOT mentioned on the Apogee website....  well, I 
  can sort of understand since it isn't really a cheat...
Those are the cheats for Commander Keen 4.
______________________________________________________________________________
|                                    Other                                   |
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
http://www.3drealms.com/downloads.html is the URL where you can download 
Commander Keen 1 and/or 4 (Shareware)
http://personal.mia.bellsouth.net/~spoon42/ <- that is my website, which
currently has a version of this FAQ, as well as one in HTML with additional 
features.

FAQ in Progress.  Version 0.15
No website other then GameFAQs (www.gamefaqs.com), RPGInsider 
(www.rpginsider.com) and my personal website may use this FAQ under any
circumstances.  If you want to use my FAQ, ask, and I MIGHT give you
permission.  
All trademarks/copyrights are owned by their respective
companies, this is not a official walkthrough from Apogee/Id Software.
2001? ?ther SPOON! - aetherspoon@hotmail.com