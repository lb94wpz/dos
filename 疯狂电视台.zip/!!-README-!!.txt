T�to hru m�te z web str�nky ->>> WWW.BESTOLDGAMES.NET <<<- �akujem za n�v�tevu;)
This game was downloaded from website ->>> WWW.BESTOLDGAMES.NET <<<- Thank you for your visit;)


  /7    /7 /7    /7 /7    /7
 /7    /7 /7    /7 /7    /7
/7 /7 /7 /7 /7 /7 /7 /7 /7
 /7 /7    /7 /7    /7 /7   /7

    /7/7			       /77777		     /77777
   /7  /7   /7/7/7  /7/7/7/7 /7/7/7/7 /7  /7 /7     /7/7    /7       /7/7/7 /7  /7 /7/7/7 /7/7/7
  /7/7/7   /7      /7/7        /7    /7  /7 /7     /7  /7  /7  /777 /7  /7 /7/7/7 /7     /7/7
 /7    /7 /7/7        /7/7    /7    /7  /7 /7     /7   /7 /7    /7 /7/7/7 /7  /7 /7/7      /7/7
/7/7/7/7 /7      /7/7/7/7    /7    /7/7/7 /7/7/7 /7/7/7  /7/7/7/7 /7  /7 /7  /7 /7      /7/7/7  /7
        /7/7/7/7                                                               /7/7/7/7

                                                                                 /7/7/7
                                                                       /7    /7 /7      /7/7/7/7
                                                                      /7/7  /7 /7/7       /7
                                                                     /7  /7/7 /7         /7
                                                                    /7    /7 /7/7/7/7   /7

!!!!  INFO:   !!!!

 -> V�etky hry stiahnut� z BestOldGames.net s� plne funk�n�, hrate�n� a neobsahuj� �iadne v�rusy, �i in� nevy�iadan� s�bory...
 -> Pokia� m�te probl�my so sp���an�m niektorej hry, nav�t�vte sekciu DOSBox na adrese: http://www.bestoldgames.net/dosbox/
 -> Ak sa V�m nepodar� niektor� hru stiahnut� z BestOldGames.net ani v�aka DOSBoxu rozbehn��, nap�te do Diskusn�ho f�ra na adrese: http://forum.bestoldgames.net/ a ur�ite V�m porad�me...


##     ## ##     ## ##     ##
##     ## ##     ## ##     ##
 ## # ##   ## # ##   ## # ##
  #####     #####     #####
   # #       # #       # #  #

####   #####  ####  ########  ######  ##     ####      #####     ##    ##   ##  #####   ####
##  #  ##    ##        ##     ##  ##  ##     ##  ##   ##        ####   ### ###  ##     ##
####   ###     ##      ##     ##  ##  ##     ##   ##  ##  ##   ##  ##  ## # ##  ###      ##
##  #  ##        ##    ##     ##  ##  ##     ##  ##   ##   ##  ######  ##   ##  ##         ##
#####  #####  ####     ##     ######  ###### #####     #####   ##  ##  ##   ##  #####   ####  #

                                                                       ##   ##  #####  ########
                                                                       ###  ##  ##        ##
                                                                       ## # ##  ###       ##
                                                                       ##  ###  ##        ##
                                                                       ##   ##  #####     ##

                                                                                <-mylan->

                                                                        EMAIL:  mylan@bestoldgames.net
									ICQ:    277570859