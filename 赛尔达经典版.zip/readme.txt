********************
The Legend Of Zelda FAQ
********************
Table Of Contents:

I. Legal Mumbo Jumbo
II. Contact
III. Review
IV. Story
V. Miscellaneous (Controls and such)
VI. Items
VII. Bestiary
VIII. Map
IX. Heart Containers
X. Music Review
XI. First Quest Walkthru
XII. Second Quest Walkthru
XIII. Conclusion
*****
Version 1.00: Pretty much the entire Walkthru was made.
*****
Version 1.25: No new text but I fixed the formatting and other junk. It 
was fugged up before.
*****
Version 1.50: I found a lot of errors in the FAQ that I had to edit out 
after I reread the entire FAQ.
********************
I. 

This FAQ was created by AceC-DC. It is copyrighted under my name and is 
my property. I am not usually so anal about these things and even if 
you did copy it is not the end of the world but I am saying this mainly 
because if somebody is going to try and make a profit of what is mine, 
then this is to stop it. That is basically why I want it. If you want 
to post this on your site, I suppose you can, I don't care really, just 
as long as you are not making a profit from it. Try to give the credit 
to me though, that'd be nice. On that note, the copyright is below.

Copyright 2003-2004 AceC-DC

On that note, let's get started shall we?
********************
II.

On a side note: If you need help and this walkthru did not help, e-mail 
me. I cannot guarantee that I will know but I most likely will and I 
can still try my very best although this walkthru probably has your 
answer in it. Send your questions to: acec_dc@yahoo.com

On another note, I made or am making walkthrus for every Zelda game so 
keep your eye open!
********************
III.

THE LEGEND OF ZELDA

Info: Get ready to start one of the greatest adventures of your life. 
This is "The Legend Of Zelda 1" for the original NES. This game broke 
barriers in the world of gaming. Not only was it the very first home 
console game to feature a save feature but also the style of gameplay 
itself was revolutionary at that time. Up to the release of this game, 
all games were 2-D sidescrollers for the most part, but when this game 
came out, it had the whole game laid out in an overhead view so it 
looked like you were looking at all the gameplay action from above in a 
bird's eye view. There are three save slots to pick from. This is also 
the very first game in the Zelda series and set many precedents that 
would stick to the series until the present date. This game also was 
one of the first games that had RPG elements in it. The game itself is 
not an RPG but it could be considered a founding father of many genres 
due to the fact that it's style was revolutionary and is what makes it 
a timeless classic. The game's graphics may look like cheap '80s 
graphics by today's standards but back in the day when it was released 
the graphics were jawdropping. Shiguru Myamoto who made the ever so 
popular Mario series also made this game. One cool feature in this game 
is the Second Quest. The Second Quest is a totally different quest to 
play once you beat the game the first time through. Basically in the 
second quest, all the dungeons have different layouts and are harder. 
This game came out in the mid 1980's. I would say that the official 
American release date would be in 1987 although I believe the game came 
out in Japan in 1986 although I could be wrong. Good Luck on your 
quest!

WARNING! Due to the fact that this game uses a very primitive version 
of saving, the saved information can be lost very easily. To avoid 
losing saved information ALWAYS hold down the reset button on the 
Nintendo when turning off the power. Failure to do so may erase game 
files. Believe it, it has happened to me! Do the same for Adventure Of 
Link. 
********************
IV.

THE LEGEND OF ZELDA STORY

In the vast land of Hyrule, there was a princess named Zelda. The land 
of Hyrule was a very peaceful and prosperous land until one day an evil 
being named Ganon came to Hyrule in search of the Triforce. The 
Triforce was a legendary golden triangle that granted mystical powers 
to the beholder. This Triforce laid in Hyrule. Ganon managed to seek 
out and find a piece of the Triforce called the Triforce of Power. Once 
he managed to obtain this mystical essence he became ever so powerful. 
His next goal was to obtain the other known piece of the Triforce 
called the Triforce of Wisdom. He knew that Princess Zelda held this 
Triforce and went after her. To protect her land of Hyrule, Zelda had 
to split up the Triforce of Wisdom into 8 shards and hide these shards 
in elaborate underground dungeons scattered all throughout Hyrule. 
Ganon did manage to capture Princess Zelda, but Zelda sent out her 
bodyguard Impa to seek for help. Ganon found out about Impa and went to 
go find her. Unfortunately Ganon and his troops did manage to corner 
Impa in the middle of the wilderness. Very fortunately, a young hunter 
named Link who was about 15 years old, and who appeared at the right 
place at the right time, showed up. He was very courageous and agile 
and managed to fend off Ganon and his minions. With the enemies gone, 
Link talked to Impa and Impa told Link the whole story of what was 
going on. When Link heard this, he vowed to be the hero and save 
Princess Zelda and Hyrule. Link's quest was now to find all of the 8 
shards of the Triforce of Wisdom, hidden throughout dungeons in the 
land of Hyrule. Once he obtained these, he would finally be powerful 
enough to enter Ganon's lair. There he would have to slay Ganon, rescue 
the Princess Zelda and save Hyrule from impending doom...
 
Goal: You play as Link. Work your way through all 8 dungeons, slaying 
the beasts inside and obtaining the Triforce shards on your way out. 
Once you have all 8, find Ganon's lair. Here, you must seek out Ganon 
and slay him. That is your goal, so good luck...
********************
V.

THE LEGEND OF ZELDA MISCELLANEOUS

This is a section with miscellaneous things that are not in any other 
sections. Most of the things in here are basic things that are good to 
know before playing the game.

Basic stuff:
 
Starting a new game: After you turn on your game you should see the 
Title Screen. Press Start here and you will see a screen where you can 
pick between saved game files to choose from. If you need to erase an 
already exiting file press the select button until the elimination mode 
is highlighted. Press Start then, and then press select until you 
highlight which game file you want to erase. Then press start to erase 
the file and press select to get back to the select file screen. To 
register your name, press select to get to the registration mode. Press 
start here and highlight which game file slot you want by pressing 
select. Then you can maneuver the cursor over the letters with the 
control pad and press the A button to pick the letters for what your 
desired name is. Once you are done then press select until you 
highlight the registration end option then press start here. If you 
change your mind about erasing or making a file, you can always just 
select the end option without doing anything else. To select the 
desired game file to play on, highlight it with select then press start 
to begin your game. Each game file will have your basic statistics you 
have in your game like health, number of deaths, and name displayed 
next to it on the select game file screen.
*****
Game Over Options: When you get hit by a monster you will lose a heart 
or a piece of a heart. When you get down to very low health like one 
heart, the game will let off an obnoxious unnecessary nonstop beeping 
sound until either you die or until you refill your health past the 
"danger zone". If you do manage to die, you will get a screen with 
three options: Continue, Save, and Retry. Here you can pick between 
your options using the Select button. The Game Over options do the 
following:
*****
Continue: Basically go on as if you never died. You will start back at 
a starting point and you can try again. If you select this option when 
you died outside in the overworld then you will always start off in the 
same screen. If you select this option when you died in a dungeon then 
you will start off at the beginning of that dungeon.
 
Save: This will save any progress that you have obtained in the game 
and will take you back to the select game file screen. If you select 
this when you died in a dungeon you will start off back in the 
overworld so I strongly suggest you only use this option in the 
overworld, preferably when you complete a dungeon. Also don't be 
impatient and turn off the power or reset the Nintendo from the time 
between when you select save and when the select game file screen comes 
up. The specific time that you should NOT turn off your game is when 
the save option is flashing red and white after you select save but I 
would just wait until you see the game file select screen to turn off 
your game anyways as it would be safe then. If you do turn the game off 
improperly, your game progress is in danger of being messed up. Your 
game file could be deleted but most likely, it will just not save the 
info that you wanted to save.
 
Retry: This doesn't save or continue. It takes you back to the select 
game file screen without saving you progress. Only use this option if 
you want to quit and you do not want to save your game.
*****
Saving your game: There are really only two ways to save your game and 
both of them are a bit inconvenient. Due to the fact that this is a 
very primitive version of saving and this game used one of the first 
save systems available in home console games, the options of saving are 
a little more inconvenient by today's standards. The two ways to save 
your game are as follows: 
*****
"The Second Controller" Save: At any time in the game you can go to 
your subscreen by pressing start. Here if you have a second controller 
plugged into your Nintendo then you can save an easiest way. Just hold 
down the A button and the up button on the second controller at the 
same time and the Game Over Options will appear enabling you to save. 
When you save with this method you will still be taken to the select 
game file screen and end up in the overworld, but it is still an easier 
method of saving then "The Death" save. Unfortunately, you cannot save 
your game inside a dungeon like you can in more recent Zelda games.
 
"The Death" Save: Once you die, a game over screen will appear and ask 
you to do one of three options. Saving is one of these options. You 
will save and then appear back at the select game file screen and if 
you start your game again you will be in the overworld. If you don't 
have a second controller this may be the only way to save 
unfortunately. Just run into an enemy enough times to get rid of all of 
your health and then die. Then you will have the option of saving. I do 
not recommend this method of saving as much because every time you die, 
the number of times you die is displayed next to your name so if you 
want to have the least possible deaths go with the other method of 
saving.
 
What I recommend is doing "The Second Controller" save every time you 
beat a dungeon or accomplish something very hard or important in the 
game. If you do not have a second controller then just kill yourself 
and use "The Death" save, although this way there will be a higher 
number of deaths on your game file but you gotta do what ya gotta do. 
If you don't want to save that much then you can just save right before 
you turn off the game or you can save a fewer amount of times. It is 
all up to you.
 
WARNING!

Again, since this is a very primitive save system, games will not be as 
safe as they would be today. Certain things will delete certain games 
if you do something wrong, but if you follow all of my instructions 
then you will be fine. Sometimes, over time, the games may erase just 
because of an old game battery although this does not happen that 
often. 
*****
Controls: Here are what the controls in the game do:
 
Directional Pad: Since this is a game with an overhead view, pretty 
much whatever direction you push makes Link move in that direction. If 
you are in any of the rare sidescrolling sections of the game then 
right and left move right and left and up and down only let you climb 
up and down any ladders or stairs nearby. The Directional Pad also 
let's you move a cursor if you want to select something sometimes.
 
Select: It can switch between options. In gameplay it will pause the 
game.
 
Start: It can select a certain option sometimes. In gameplay it will 
bring up the subscreen, which is, in a way, another method of pausing 
in the game, only the music still plays.
 
B: All items you aquire in the game can be used with the B button. Via 
the subscreen, you can pick which item you want to use and select it to 
B. Then in gameplay, pushing B will use that item.
 
A: Basically this is just your sword. In gameplay, you will always 
swing your sword whenever you push A. The only other function that A 
does is confirm an option sometimes. 
*****
Screens: There are two screens in this game during gameplay. Here is 
what they are and what they do:
 
Main Screen: This is basically the screen where the game takes place. 
It is where all the gameplay occurs. Up in the top of the screen you 
will see some statistics that are good to know during gameplay. These 
include a small map so that you can see what region of Hyrule you are 
in although it is not a very good map. You can see how many rupees you 
have. You can see how many keys you have. You can see how many bombs 
you have. You can see what you have selected to the B button as well as 
your sword in the A button slot. Lastly, you can see how much health 
you have altogether and how much health you are missing. The amount of 
hearts is the amount of health that you have altogether. The red hearts 
is your current health and the white hearts is the amount of health 
that you could have only you are missing it.
 
Subscreen: This is basically another pause. This has all of the 
statistics on it that are not as important to see during gameplay. It 
will feature all of the statistics already shown in gameplay yet a few 
more statistics. It will have how many Triforce pieces you have 
collected so far. It will have all of the items that you have aquired 
throughout the game in your inventory. You can select between all of 
the items in the blue box to use for your B button with the directional 
pad. All items that you aquire throughout the game that you cannot 
select to a B button but use them automatically will appear above the 
blue box in your inventory. Lastly, the subscreen will display which 
item is selected for use of the B button. 
*****
Worlds: There are two worlds, the overworld and the underworld. Here is 
what they are:
 
Overworld: This is land above ground. It is basically the wilderness of 
Hyrule. Any place in the game that is not in a dungeon is considered 
the overworld. There is nothing else that is that special or unique 
about the overworld.
 
Underworld: Any of the 9 dungeons is considered the underworld because 
they are underground. These would be considered the levels of the game. 
The subscreen changes in the underworld a bit. There will not really be 
a map at the top of the screen until you get the map that is in that 
dungeon. Once you get the map then the dungeon's layout will be 
displayed at the top of the screen in place of where the normal 
overworld map would normally be. On the subscreen there will be a large 
map covering the screen. This is a larger map however it only displays 
the rooms that you have been to so far in that dungeon. Other than 
that, the subscreen will just tell you whether you have aquired the map 
and/or the compass in that dungeon. The Map and the Compass are items 
that are very useful in dungeons which I will talk about in the Items 
section. You may also need to find keys in dungeons to get through 
locked doors. The enemies that appear in the underworld are different 
than the ones that appear in the overworld. Lastly, every dungeon in 
the first quest has a general shape to it which may help, but not that 
much. 
*****
Other stuff: You will meet people all throughout the game. Some will 
give good information and hints in the game. Some will give you 
important items. The ones in dungeons will give you hints usually for 
that dungeon or on where to go next. Some people will deduct rupees 
from you if you destroy their "door". That happens if you find them by 
burning down a tree sometimes. There are several more types of people 
out there as well which you will meet. Lastly, there are merchants all 
throughout the overworld in Hyrule that live in caves. Some sell more 
valuable and rare items than others. Seek out the merchants for they 
are very helpful. 
********************
VI.

THE LEGEND OF ZELDA ITEMS

Here is a list of all of the items in the game and what they do:
 
Sword: This is your main attacking weapon of course. The game would not 
be Zelda without it. The sword is so important that you always have to 
have it equipped at all times in the game. It is always assigned to the 
A button. All enemies in the game are vulnerable to your sword. One 
cool feature about the sword is when you have full health you can shoot 
swords at enemies which is a very powerful skill. There are three main 
kinds of swords you get throughout the game. You will have to seek out 
the men who give you these swords but there will be hints directing you 
to them. Here is what the three swords do: 

Sword: The least powerful of all the swords. This is the very first 
sword Link gets at the very beginning of the game. When attacking 
enemies with this sword, it takes the longest to kill them with many 
more hits. 

White Sword: The second most powerful sword in the game. It takes less 
to kill enemies with this sword however it is not the most powerful 
sword. You need at least 5 hearts to get this sword.
 
Magical Sword: The most powerful sword in the game. With this, killing 
enemies is a lot easier and it takes usually one or two hits to kill 
them. You need at least 12 hearts to get this sword.
 
Shield: This is another item that is equipped all throughout the game. 
You start the game off automatically with a smaller shield that is not 
as powerful. Link always has his shield out in front of him, so how you 
use it is if an enemy shoots something at you and if you aim right and 
it hits your shield then it will bounce off of the shield and you will 
not get hurt. There is also a magic shield that you can buy from many 
of the merchants scattered throughout the land. I have seen them sold 
from a price range of 160, 130, or 90 rupees, depending on where you 
buy it at. Despite it's name, there is nothing really magic about this 
shield, it is just that it is a lot bigger shield than your original 
one. With this shield you have a lot more defense, so when an enemy 
shoots something at you, you have a lesser chance of it hitting you. 
Lastly, there is an enemy in the game that can eat your magic shield so 
try not to let that happen for they are very expensive.
 
Rupees: These are the currency of Hyrule. They are basically jewels. 
You can get them easily for a lot of the times enemies drop them 
whenever you kill them. It may however take a while to accumulate a lot 
of them sometimes. You can carry a maximum of 255 rupees at one time. 
Of course all shops in the game require a certain amount of rupees to 
buy their products. There are several other places in the game where 
you will need rupees when interacting with people as well. Flashing 
rupees that flash blue and yellow are worth 1 rupee and solid blue 
rupees are worth 5 rupees. 

Hearts: Whenever you get hurt by an enemy you lose either a heart, more 
than one heart or half of a heart. Whenever you kill enemies in the 
game they leave hearts a lot of the time. Pick up these hearts they 
drop to replenish one of your hearts lost. 

Heart Container: A Heart Container adds one more heart on to your 
maximum health. You start the game off with three heart containers and 
when you get one more heart container you have a maximum of 4 hearts 
and the pattern works like that. Whenever you beat a boss of a level, 
it will leave a heart container. There are 5 other heart containers 
hidden throughout Hyrule. 

Fairy: Sometimes if you are lucky, an enemy will drop a fairy if you 
kill it. Fairies are harder to catch however if enemies do drop them 
for they fly around the screen and are sometimes hard to catch. Like 
most items left by enemies, they will disappear if you don't collect 
them in time. Fairies restore 3 hearts. There is another greater fairy 
in the game. In some locations in Hyrule there will be a pond and when 
you go to that pond a fairy will appear and restore all of your health. 
You can go to these fairies as much as you want although there are only 
a few of them in the game. 

Key: In dungeons these open locked doors. In many rooms in the dungeon, 
keys are hidden and in order to get these keys you have to do something 
in that room like kill all of the enemies in it. You can also buy keys 
in some of the shops although that is a waste of time because the keys 
are usually not all that hard to get. Of course, once you use a key it 
will disappear. 

Magic Key: With this item you will never need an ordinary key ever 
again. This is the master skeleton key and it can open any and every 
locked door in the game without ever running out. You get this as an 
item in a dungeon later in the game. 

Ladder: No this does not help you climb hard to reach areas. This could 
actually be viewed as a bridge. What it does is it lets you cross small 
streams of water. The streams of water have to be very small as the 
ladder cannot fit over large streams. The streams have to be one square 
wide to be exact. Once you have the ladder, all you have to do is walk 
over to the stream and walk across it like it is land and the ladder 
will appear and you can walk across it like a bridge. You get the 
ladder as a dungeon item in the game. 

Raft: There are a few docks throughout the game and these docks are 
useless without the raft. Once you have the raft, go to these docks and 
walk out towards the water. Once you do this, you will ride the raft 
across the water and get to another location. The docks must be 
connected to the land however. You get the raft as a dungeon item in 
the game. 

Map: This is an item that can only be used in dungeons. Every dungeon 
has it's own map. To get the map, you have to find the room it is in 
and sometimes you have to kill all the enemies in that room to get it. 
Once you have the map, you can see the layout of the whole dungeon 
which is very useful. Before you have the map in the dungeon that you 
are in, it is very hard to navigate through it.
 
Compass: This is another useful dungeon item. You get this like you get 
the map as in you must seek out the room with the compass in it which 
may mean killing all of the enemies in that room in order to get it. 
Once you have the compass, you will be able to see which room the 
Triforce piece is in.
 
Letter: In one place in Hyrule you will find this letter. With the 
letter you can now buy potions. There are some ladies in Hyrule which 
will not even speak to you at all but once you have the letter and show 
them it then they will always be willing to sell you the potions from 
then on which is very useful.
 
Rings: Wearing these rings builds your defense. If you wear the blue 
ring, it will cut your damage taken in half which makes it harder for 
you to get hurt. If you wear the red ring then it will cut your damage 
taken to a fourth which is very helpful. Your clothes also change color 
to whatever ring you wear. The blue ring is the most expensive item in 
the whole game and you can only purchase it in one place. The red ring 
you get as an item in Ganon's Lair in the first quest.
 
Power Bracelet: With this item you will be much stronger. Wearing this, 
you can push some rocks and other sturdy items. Throughout the game 
there are a few items like this that you can push. Once you have the 
Power Bracelet then just walk over to the item you wish to push and 
walk towards it. The Power Bracelet is hidden in the overworld 
somewhere but it is not that hard to find if you look carefully enough.
 
Clock: This is another item that enemies leave behind occasionally when 
you kill them. This item is very convenient especially when you are 
dealing with tough enemies. When you get this, it freezes all of the 
enemies on the screen. The enemies will never come unfrozen so you 
should be able to kill them all. This effect only lasts one screen 
however. 

Boomerang: I grew accustomed to this item for it is pretty useful. You 
throw it and it comes back to you of course just like a boomerang. It 
can kill many of the weak enemies and stun most of the other enemies. 
The magic boomerang is a more powerful blue boomerang in that it has a 
farther throwing range and you can throw it all the way across the 
screen. You can also fetch items that enemies leave behind with the 
boomerang as well. You get both boomerangs as dungeon items.
 
Bombs: You place them down and a few seconds later they go off. They 
can inflict damage to enemies and one enemy is only vulnerable to 
bombs. Other than that, bombs are used to open up hidden caves in the 
overworld and they also blow up some walls in dungeons letting you 
access other rooms in that dungeon. You can buy bombs from many shops 
throughout Hyrule and many enemies leave behind bombs when you kill 
them. Sometimes in dungeons, when you kill all of the enemies in that 
room, you will get some bombs as a prize. You start off with a maximum 
of 8 bombs but as the game progresses, you can get up to 16 bombs if 
you can find the men that sell you the bomb upgrades. 

Bow: It lets you shoot arrows. This item is useless if you don't have 
any arrows. You get the bow as a dungeon item.
 
Arrow: Once you have the bow, you can shoot arrows which is a useful 
weapon to have. One enemy is only vulnerable to arrows while other 
enemies are weak to them as well. The only problem with arrows is that 
when you shoot them you lose rupees. So if you are broke then you also 
have no arrows. Think of it as when you get rupees, you also get 
arrows. You do not use the arrows that much in the game however. You 
can buy arrows at some of the shops throughout Hyrule.
 
Silver Arrow: The only thing these are good for is slaying Ganon. This 
is the legendary item that you must have in order to kill Ganon. Other 
then that they are the same as regular arrows I believe. You will get 
these as the dungeon item in Ganon's Lair in the First Quest.
 
Candles: Once you have the candles you can let out a flame. These 
flames can light the dark rooms in dungeons and they can also burn down 
some trees in the overworld. The flames can also hurt enemies and can 
hurt yourself if you are not careful. The blue candle can only let out 
one flame per screen but the red candle can let out an unlimited number 
of flames per screen. You can buy the blue candle in a shop in the 
overworld and you get the red candle as a dungeon item.
 
Recorder: When you play this item in the overworld a tune will sound 
and a whirl wind will come, blow you away and warp you to the outside 
on a previously beaten dungeon. One enemy is particularly vulnerable to 
the sound of the recorder. The recorder has some other mysterious 
effects as it can sometimes open doors and pathways that would 
otherwise be kept secret. 

Food: This can be used for enemy bait but it is not very useful for 
that. You put it down and some enemies will swarm to it so it can 
distract them however at the price that is not a wise choice of use for 
this item as well as the non-intended use of it either. The main use 
for the food is to give to a monster that says "Grumble Grumble" that 
blocks your path later in the game. Giving him the food lets you pass. 
You can buy the meat at some more hidden shops in Hyrule although it is 
a bit expensive. 

Potions: Once you have the letter then the lady that does not speak 
will now be willing to sell you the potions. The potions are very 
useful in the game. Once you drink a potion it will replenish all of 
your hearts no matter how low you are. When you find yourself in a 
tight situation with one heart and you are trying to fight a lot of 
tough enemies, that is the time to drink the potion. A blue potion 
works like a regular potion and a red potion is like having two blue 
potions in that it can be used twice. You can always buy more potions 
if you run out but of course you have to have the money first.
 
Magic Wand: The magic wand is a very powerful item in the game. It is 
the same weapon that the Wizzrobe enemies use. You swing it like a 
sword and it lets out a wave of energy that can kill some enemies. 
Although it is powerful, I still like to have the boomerang equipped 
but that is just me. It is really all up to what you want to do. You 
get this item in a dungeon. 

Book Of Magic: This lets you do another spell with the magic wand. With 
this, instead of just a magic wave being cast out of your wand, it will 
be a flame. The flame of course can light dark rooms, burn down some 
trees and kill some enemies. Once you have this item, the candles are 
useless. You get this item in a dungeon.
 
Triforce: The main item in the game you are seeking. You get one at the 
end of the first 8 levels. You want to collect all 8 pieces of the 
Triforce before you can enter Ganon's Lair. 
********************
VII.

THE LEGEND OF ZELDA BESTIARY

Here is the list of enemies in the game and descriptions about them: 
*****
Overworld enemies: These enemies only appear in the overworld:
***** 
Tektite: These four-legged spider like creatures will hop around all 
over the screen until you kill them. Don't worry they are not all that 
fast. The red ones are easier to kill and the blue ones are a bit 
harder but not by much. Sometimes the blue ones leave a bit more 
rupees. You will find them scattered all throughout the overworld but 
they are not that much of a problem. Just simply try to get near enough 
to them to kill them and avoid their jumping. 

Octorok: These are land octopuses that spit rocks at you out of their 
snout. The red ones are easier to kill and the blue ones will take more 
hits to kill with the weaker swords. Either avoid their rocks or use 
your shield to protect yourself. Octoroks are a very common site in the 
overworld, usually near the beginning of where you start off at. They 
are very easy enemies and should not be that much of a problem. 

Leever: A kind of sand creature that will come out of the ground and 
move around a bit then go back under for a few seconds. The red ones 
are easier and tend to leave more rupees while the blue ones are a bit 
harder and take more hits to kill. You can tell whether they will come 
out of the sand or not because you can see the dirt move where they 
come out, so watch for that dirt movement and run away from it. Leevers 
are found mostly in the desert, the beach, or near water. Just avoid 
them from hitting you while attacking them with your sword. 

Peahat: A flying flower like monster. In many places in the overworld 
you will see a pack of these. Peahats fly around for several seconds 
then they lay down to rest for a few seconds. While they fly around, 
they are invincible so you can only attack them when they land. I 
usually just ignore Peahats because they take too long to kill and are 
not that hard to avoid but it is up to you. You will find them all over 
the overworld. 

Molblin: These are like a cross between a bulldog and a goblin. They 
are Ganon's main minions. Molblins only appear in the forests and they 
all shoot arrows. Arrows are just like rocks only a bit more powerful 
and harder to avoid. The red Molblins are easier to kill while the blue 
ones take more hits to kill. 

Armos: It is very easy to avoid these. They are statues that do not 
move at all unless you touch them. If you touch and awaken them, they 
can be a little pesky. In many places in Hyrule you will see rows of 
these. Some Armos guard underground caves and one Armos is covering the 
Power Bracelet later in the game. Don't even touch an Armos from the 
front or it will automatically hurt you. If you manage to awaken an 
Armos try to stun it with your boomerang at all costs and make sure it 
is frozen! If not you may have a problem for sometimes when they awaken 
they run around super fast and are hard to kill, plus when they run 
that fast, they chase you sometimes and will usually take a few hearts 
off. Awaken an Armos with caution. 

Ghini: These are ghosts that haunt the graveyard in Hyrule. In all of 
the plots of cemetery in the overworld, there will always be one Ghini 
roaming around. They take several hits to kill but are not all that 
challenging. If you touch any Gravestone, another Ghini will appear. 
You can touch the same gravestone a dozen times and a dozen Ghini will 
appear! Don't touch a gravestone from the front though or you will get 
hurt by the Ghini. Once you release a Ghini from it's tombstone, it 
will be invincible and you cannot kill it unless you kill the original 
Ghini that was on that screen when you came to it. If you already 
killed that original Ghini then you are out of luck. However, if you 
lure many Ghinis out from their graves and the original Ghini is still 
on the screen and you kill it, all the other Ghini will die and leave 
lots of good items so you can do that to stock up on goods if you need 
to but it is not all that helpful. In that case, pretty much just avoid 
the Ghini altogether unless you really need or want some items for 
there is only one gravestone in the first quest with some importance to 
it. 

Lynel: Like something straight out of Greek mythology. It has a horse's 
body and a Lion's head, with a man's torso. It carries both a sword and 
shield in it's arms. The toughest thing about the Lynal is that they 
can shoot swords just like Link can when he has full health. The sword 
is more powerful and does more damage then a rock or arrow. The red 
Lynal are the weaker version while the blue Lynal may take several hits 
to kill sometimes. The Lynal is the toughest overworld enemy and they 
are usually in the mountains more towards the last level. 

Zola: These are fish that pop out of the water to shoot balls of energy 
at you. They can be very annoying and hard to kill sometimes. You 
cannot really kill them with the first sword you have due to the fact 
that they take two hits to kill with it. Once you have the white sword, 
you will only have to hit them once. The reason they are so hard to 
kill is that they will appear in the middle of a body of water where 
your sword cannot reach so you can only kill them if they come up near 
the shore or if you have full health and shoot swords at them. They 
will also only be above the surface for only a second so you have not 
much time to attack them. I suggest just ignoring them for they are not 
that much of a bother anyways. Zolas appear pretty much in any place 
where there is water in the overworld. 

Boulder: This is not really an enemy seeing as it is not living but it 
can still hurt you. The boulders are also invincible so all you can do 
is run to protect yourself. In some places in the overworld, usually in 
the mountains near the last level, boulders will fall from the top of 
the screen non-stop and you will have to avoid them. Usually three 
boulders fall at a time. 
*****
Underworld enemies: These enemies only appear in the dungeons in the 
game: 
*****
Zol: Large blobs that move around the room slowly. If you attack a blob 
with the weaker swords then they will split into two gels. If you have 
a more powerful sword or weapon, one hit will kill the Zol. Zols are 
one of the most easiest enemies in the game.
 
Gel: If you attack a Zol with the first sword then they will split into 
two of these. Other than that, sometimes a room will be filled with 
many of these. They just slowly move any which way throughout the room 
and are so easy that the boomerang can take out them.
 
Rope: They are basically snakes. They will move slowly around the room 
but if you cross their line of vision which is anything horizontally or 
vertically next to them, then they will charge at you so beware. Other 
than that, they are pretty easy to kill. 

Vire: Blue demon things that slowly hop around the room. They are very 
easy creatures. If you hit them with a weaker weapon then they will 
split into two red Keese although even though they are red, they are no 
different from the black ones. If you hit the Vire with a strong enough 
weapon, you can kill them with one hit. 

Keese: These are basically bats. Sometimes rooms will be filled with 
them. They are very easy to kill as they will die if hit with a 
boomerang. They will fly around the room and may be a little hard to 
aim at. They are also in the rare sidescrolling rooms in the game. Two 
red Keese will emerge from a Vire if you hit it. 

Stalfos: Sword wielding skeleton warriors. They will just walk around 
the room and are not that hard to kill at all. 

Wallmaster: They can potentially be one of the most annoyest enemies in 
the game. They are giant hands that appear out of the walls sometimes. 
If you get hit by one, it will take you all the way back to the very 
beginning of the level. Many of them will come out of the wall at once 
and then emerge back into it a few seconds later. To avoid getting 
captured, attack from a distance if you can. If you get the clock in a 
room with Wallmasters, they will not appear which can be bad because 
usually you need to kill all of them in a room to advance into the next 
room. The Wallmasters usually guard the room next to the boss.
 
Goriya: Looks like some kind of rodent wearing a cloak. These creatures 
chuck boomerangs at you. The red ones are weaker while the blue ones 
are tougher of course. All Goriyas will chuck the weaker version of the 
boomerang at you until you get the magical boomerang. Once you get the 
magical boomerang then they all chuck a magical boomerang at you too. 
They are usually not that much of a problem though. 

Wizzrobe: One of the most annoyest enemies in the game. They are 
wizards that shoot waves of energy at you from wands. There are two 
kinds red and blue. Red are a bit easier to kill and they appear in an 
area, shoot their magic then disappear and reappear in a different 
area. The blue Wizzrobes take a few more hits to kill and will float 
around the room shooting waves of energy at you. They can move through 
objects and their energy waves seem more powerful and take off more 
hearts. The blue Wizzrobes are harder to kill and are more of a 
nuisance.
 
Darknut: Another obnoxious enemy. These are knights, simple as that. 
They wield a sword and a shield. What is so tough about them is that 
you cannot attack them from the front because of all of their armor. 
You have to hit them from either their sides or their back. Also what 
makes them so hard is that they never stop walking and if you creep up 
on them then they could do an about face and walk right into you taking 
off a heart. You have to use strategy and kind of approach them a 
little far away from them and strike with your sword. Be prepared to 
run if they come near you. It is all in the strategy how to kill them 
but always try to keep your distance. The red Darknuts are a bit weaker 
than the blues ones. The blue Darknuts are hard because it takes a lot 
of hits to kill them. 

Pols Voice: An odd shaped lump monster with big rabbit-like ears. They 
will hop around in a vertical line usually and take a lot of hits to 
kill. Arrows will kill them instantly so it is a good choice of weapon 
when battling the Pols Voice.
 
Lanmola: A giant centipede that scurries across the dungeon floor. It 
has body segments so when you attack it, it will gradually lose it's 
segments until it is nothing more than a head. Then just kill the head. 
Lanmolas move any which way. Red Lanmolas are a lot easier to kill. 
Blue Lanmolas are a lot harder because they move around the screen 
really fast. Just try to keep your distance and strike.
 
Like Like: Probably the most annoyingest enemy in the game if you let 
it hit you. Other than that they are not that hard at all. They are 
just large slimy blobs that slowly creep across the room. They look a 
little like cylinder tubes with a hole on top as it's mouth. What makes 
the Like Like so annoying is the fact that if you let it hit you, it 
will hold you there inside of it and eat your magic shield! Whatever 
you do, keep your distance from the Like Like. Fortunatly, the Like 
Like does not eat your shield 100% of the time but I would rather be 
safe than sorry. Try to stun it and avoid going near them as much as 
possible especially when other enemies are on the screen. What I do is 
I stun them with my boomerang and try to kill the other enemies first, 
then I try to stun them several times before and between hitting them 
with my sword. If it eats your shield, you have to go all the way back 
to the overworld and scavenger around to find enough rupees to buy the 
expensive shield that costs a minimum of 90 rupees and that is if you 
know where the shop is where you can find the shields that cheap! Oh 
what a pain! 

Gibdo: Basically they are mummies that wander around the screen 
aimlessly. They do have a lot of armor though so it will take many hits 
to kill them. Also, when you hit them they have a lot of resistance and 
will not fall backwards like most other enemies do. Then again, I think 
most enemies have a lot of resistance but still, the Gibdos have a lot 
of defensive power nonetheless. Just try to keep your distance when 
attacking the Gibdo. 

Moldorm: A red worm that crawls around in the sand. They are very easy. 
Just attack them many times and they will gradually lose body segments. 
Unlike the Lanmola they move very slow. 

Patra: Giant flying eyeballs with a forcefield of several smaller 
flying eyeballs. The main eyeball will just flutter there while it's 
mini-versions circle around it. Sometimes it will send the smaller 
Patra outwards into a big circle making it hard to avoid them 
sometimes. Sometime the smaller Patra will also circle the larger Patra 
by going every which way around it also making it difficult to attack 
the Patra. What you want to do is keep your distance and try to attack 
the smaller Patra first. Once you get rid of all of the smaller Patra 
then the larger Patra is vulnerable. Once the larger Patra's forcefield 
is gone, it is very easy to kill. The Patra are only in Ganon's Lair in 
the first quest. They are in a way mini-bosses. 

Bubble: Very annoying creatures. Not only are they invincible, but they 
are a pain in the ass. They are flying skulls surrounded by a evil 
white forcefield. If you get hit by a bubble you will not get hurt but 
you will not be able to use your sword for a few seconds which can be a 
very dire situation. The Bubbles also push you backwards a lot if you 
get hit by them so be very careful when Bubbles and Like Likes are in 
the same room together. The Bubbles move every which way throughout the 
room. In the second quest there are red bubbles which is one of the 
most annoyest enemies in the game. If you get hit by a red bubble, you 
will not be able to swing your sword at all unless you do one of three 
things. One, if you touch a blue bubble after being hit then you will 
be fine again. Two, go to a fairy's springs in the overworld. Or three, 
drink the potion. I would not want to waste a potion and it would be 
too much of a hassle to go to the overworld, so I would just try and 
seek out a blue bubble. 

Traps: These are little traps with spikes covering their sides that 
hide in the corners of rooms. When you cross their path, they will come 
towards you very fast. They are invincible so if you see a room with 
them in it, quickly hurry out of the way. 

Stone Statues: All throughout the dungeons, there will be statues that 
decorate the place. The statues face looks like a monster or a dragon. 
They are always in the very first room of every dungeon as well as in 
many other rooms. In some rooms in dungeons there will be these statues 
and they will shoot balls of energy at you nonstop. The stone statues 
are invincible so just avoid their energy balls. 
*****
Bosses: At the end of every level there is a boss guarding the Triforce 
piece in the other room. Sometimes these bosses will be in later levels 
in other rooms sometimes. These are the bosses: 
*****
Aquamentus: A large dragon that blocks your way with a large single 
horn on it's head. It will shoot three energy balls at you in waves. 
Just try to avoid the energy balls and head for Aquamentus's head, 
particularly it's horn. You can strike it's head once or twice then 
back away again before he shoots his energy balls at you again. Or you 
can just go up to his head and repeatedly attack his head until he is 
dead and not care if you get hit a little. The strategy is all up to 
you. 

Dodongo: A very large dinosaur like monster that creeps around the 
room. It looks a lot like a Tricerotops. Sometimes later in the game 
there will be three of these in a room together. Bombs are the only 
thing that Dodongos are vulnerable to. Just place the bombs right in 
front of their paths where they are going to walk and they will eat 
them. You must have good timing and judgment because they will move 
away from where you place the bombs sometimes, but it is not that hard. 
Two bombs will kill the beast. Another good strategy is to place 
another bomb on a Dodongo while it is eating the first bomb. While the 
second bomb explodes, it will stun the Dodongo and you can just kill it 
with your sword then in one strike. Doing this will also score you more 
bombs when the Dodongo is dead. If you have no bombs then you are out 
of luck so always make sure you have a lot of bombs before battling the 
Dodongo. 

Manhandla: A large plant like monster. It has it's body and four heads, 
one of each side of it's body. Each head will shoot energy balls at 
you. Attack the heads. A few hits will get rid of a head. Once you get 
rid of all of it's heads then it is dead. The less heads it has, the 
faster it moves. It normally moves in every which way. You can use your 
sword to kill it but that is very hard when it moves very fast. What I 
think the best strategy is, is to just strategically place a bomb down 
where it is walking towards. If the bomb is in the center of it, it 
will sometimes kill it. If it doesn't kill it, it will usually only 
have one head and another bomb on it now will kill it. 

Gleeok: A multi-headed dragon that shoots energy balls at you. They can 
have anywhere from 2-4 heads. Just attack a head and with a few hits, 
the head will be cut off. Once the head is cut off then it will fly 
around the room. If the head flies around the room just ignore it and 
concentrate on the other heads. If you just swing your sword like mad 
then you should usually kill it, but also try not to get hit by the 
energy balls of course. 

Digdogger: It is supposed to be a kind of land version of a sea urchin. 
This enemy is very easy. It usually just creeps around the room doing 
nothing. There will be statues that shoot energy balls at you in the 
room to attack you. Digdogger is pretty much invincible at first. Play 
the recorder and he will shrink and sometimes split into three smaller 
Digdoggers. These small Digdoggers are not that hard and they will just 
move fastly across the room, moving every which way. You can stun the 
small Digdoggers with the boomerang and a few hits whit the sword will 
kill a small Digdogger. 

Gohma: This is a large crab like monster that walks in a horizontal 
path and who is in a room with statues that shoot energy balls at you 
usually. Gohma has one large eye and it shoots energy balls at you. 
It's eye is it's weak point. Shoot an arrow into it's eye to kill it. 
Sometimes it will partially close it's eye, hindering you from shooting 
arrows at it. Wait for it's eye to open and then aim and shoot. One 
arrow usually kills the red Gohma while it takes a few arrows to kill 
the blue Gohma. 

Ganon: The final and ultimate boss in the game. You only will find him 
at the end of Ganon's Lair at the very end of the game. You walk into 
his room and he will appear. Then he will turn invisible. When he is 
invisible he will move around the room shooting energy balls at you. He 
usually appears in the same areas. Just try to station yourself in the 
center of the room or next to where he normally appears and keep 
striking your sword. Eventually you will hit him and he will appear for 
a few seconds. Keep doing this until he appears and turns a brownish 
red color. When he turns this color he is stunned and you only have one 
more thing to do. That last thing to do is to shoot a silver arrow at 
him. If you don't have the silver arrows you cannot beat him. Once you 
have the silver arrows just shoot one at him and he should die. Do it 
quickly though, for he will turn back to normal again if you do not 
shoot him fast. Once you kill him he will turn into a pile of ashes 
with the Triforce on top and you have just beaten the game! 
********************
VIII.

THE LEGEND OF ZELDA MAP

Here I will give information on all of the screens in the overworld of 
Hyrule. Note that this applies only to the first quest. I may give 
information for the second quest later but you can always look in my 
walkthru for that. To decipher the map, I will describe each screen. 
Going along horizontally are the letters A-P. Going along vertically 
are the numbers 1-8. Note that I may of missed a few things that are 
non-important but I think I got most of the good stuff. I am sure it is 
not that hard to figure out. Also, when I say that I am not sure what 
is in a cave, the contents of the cave are not important as I have 
listed all the places that are important in the game.
*****
A-1: Just a very small path through the mountains. Nothing of real 
importance here, other than it is just a connection between two areas. 
There are not even any enemies in this screen.
 
A-2: Several rocks and hollow trees. There are blue Lynal here so 
beware. This whole general area is quite pointless actually so there is 
no real need to venture around here other than for exploration. 

A-3: A plot of cemetery. Just like all the other plots of cemetery in 
this area. 

A-4: Another plot of cemetery. They really put too much cemetery in 
this game. Pretty much a pointless screen but watch out for the Ghinis 
as usual here. 

A-5: More cemetery. This has a stairway connecting to another region of 
Hyrule. 

A-6: Could be considered part of the cemetery but there are no 
tombstones here. It is a dull gray color like the rest of the cemetery 
but it is really just an entrance to the cemetery. Watch out for the 
red Lynal here. 

A-7: Connecting the dead woods to the cemetery. Watch out for Lynals 
and Peahats. 

A-8: A dead end with hollow trees and a cave. In the cave, you can 
gamble with a woman so that she will tell you the directions through 
the forest maze but I will tell you the directions anyways so don't 
even bother with her. 

B-1: A mountain pass. It has red Lynals in it so beware. It basically 
connects screens to the left, right and down.
 
B-2: More hollow trees, rocks and Lynals. Virtually pointless as what I 
can see. 

B-3: More cemetery however this plot of cemetery actually has a 
purpose. You can push one of the tombstones here to reveal a hidden 
cave. In that cave, if you have 12 heart containers then you can get 
the Magic Sword from an old man. 

B-4: More cemetery that connects with another region of Hyrule. 

B-5: Another pointless plot of cemetery. Another pointless screen.
 
B-6: Part of the dead woods. Watch out for blue Molblins here. This is 
next to the forest maze. 

B-7: The forest maze in the dead woods. If you go the wrong way the 
screen will repeat over and over again. Going the right way through it 
or going right will exit the maze. In order to proceed west as desired 
go the directions: North, West, South, West. Doing this will get you to 
advance west into another region of Hyrule. Watch out for blue Molblins 
here. 

B-8: The outskirts of the dead woods. Nothing special here other than 
it connects some screens together. Watch out for blue Molblins here. 

C-1: A strip of mountain pass that connects some screens together. 
Watch out for red Lynals here. 

C-2: A mountain pass with hollow trees and blue Lynal in it. 

C-3: Level 6. It is the outskirts of the cemetery and it has Armos in 
it. Level 6 is hard and it has a lot of Wizzrobes in it so be extra 
careful. 

C-4: Small plot of a mountain pass that connects the cemetery together. 
Watch out for Lynals and Peahats here. 

C-5: Level 7. It may look like just an ordinary pond but in reality, if 
you play the recorder then the pond will dry up and the passage to 
Level 7 is underneath. 

C-6: A winding path through the dead woods with a lot of Molblins 
scurrying through the many trees. 

C-7: More dead woods infested with Molblins. A line of trees will 
divide the screen preventing you to travel to both sides of it. This 
screen leads to the forest maze to the west. 

C-8: More Molblin infested dead woods. There is another thick line of 
trees here preventing you from going to both sides. This exits the dead 
woods although the exit is a dead end. 

D-1: A strip of mountain pass that either leads west or down through 
some stairs. Boulders fall here so beware.
 
D-2: A mountain pass with Lynals. This screen also connects a few 
areas.
 
D-3: The screen is divided by a thick layer of mountain rock. There are 
two sides to it. Both sides are infested with red Lynals. The left side 
has one of the four shortcuts in it if you have the power bracelet and 
you push one of the rocks. The right side just connects to another 
region of Hyrule. 

D-4: The most farthest east screen that could be considered part of the 
cemetery due to it's dull gray color. This is simply just a plot of 
Armos which are not worth waking up. 

D-5: One of the few fairy fountains in Hyrule. The fountain is 
connected to the dead woods. Use this fountain if you are anywhere near 
western Hyrule or near the beginning of where you normally start off in 
the overworld. 

D-6: A plot of the dead woods that leads to the dead woods fairy 
fountain and east out of the dead woods. Watch out for Molblins here. 

D-7: More dead woods that have Molblins and Octoroks in them. This 
screen also leads out of the dead woods to the east. 

D-8: The most southeastern strip of dead woods. It has blue Molblins in 
it. This screen leads to the screen with Level 3 on it.
 
E-1: A mountain pass dead end in Death Mountain. This has a cave in it 
that holds the potion lady if you need her. Beware the hoard of blue 
Lynal here. This is right next to Ganon's Lair. 

E-2: A mountain pass with a plot of Armos here that do not need to be 
woken up. There are also red Lynal here. This just connects mountain 
passes to more mountain passes. 

E-3: A mountain pass with a plot of Armos. The most northeastern Armos 
is standing over the power bracelet so he is the only Armos that I 
recommend waking up here. 

E-4: A corner of the easier region of Hyrule, it is a mountain side 
plot of Armos near the lake. The upper-middle Armos is covering a 
secret cave that holds the expensive blue ring and meat. There are a 
lot of blue Leevers here. 

E-5: A small plot of land wedged in between the mountains and a lake. 
It does have a cave here on the mountain although I honestly do not 
remember for sure what is inside which I apologize for. I believe there 
may be a hint giver inside although I cannot be sure of it so just 
check it out yourself. There are also red Octoroks roaming here. 

E-6: A small strip of living woods connected to the dead woods along 
side the corner of the lake. There are red Octoroks and a Zola here.
 
E-7: A valley with Octoroks in it. There is a cave here which has the 
potion lady in it. 

E-8: Level 3. It is a small dead end valley and holds no importance 
other than being where Level 3 is. 

F-1: The infamous landmark called Spectacle Rock due to the two large 
rocks that look like eyes. This is at the very top of Death Mountain. 
Bomb a whole in the left "eye" to find Ganon's Lair. This is probably 
the most guarded screen in the overworld with monsters. It has hoards 
of Lynals, Leevers and I believe Peahats as well. Approach with 
caution.
 
F-2: Mountain pass that connects more mountain pass. It has Peahats in 
it. 

F-3: A mountain pass that connects a few areas together. It also has a 
plot of Armos that do not need to be woken up and a cave. I think that 
the cave is a shop. Watch out for Peahats here as well.
 
F-4: A narrow path alongside the foot of Death Mountain and the lake. 
Watch out for the Zola in the water. 

F-5: Level 4. This is an island in the middle of the lake. You can only 
get to it if you get to it via the dock below in which you need the 
raft to do so. 

F-6: This screen is divided by a small stream coming from the lake. The 
left side of the stream has no real importance and the right side holds 
the dock that leads to Level 4 if you have the raft. Watch out for a 
red Octorok and a Zola. 

F-7: A bridge crossing the creek that divides east and west Hyrule. 
There are red Octoroks and a Zola here. 

F-8: A creek divides this small plot of valley. To get to the left side 
of the creek, go to the screen above it and cross the bridge. The cave 
on the left side holds a cave with a hint giver inside. There are 
Leevers, Peahats and a Zola here so beware. 

G-1: A mountain pass that leads to Spectacle Rock to the west. Watch 
out for Peahats here. 

G-2: A jagged mountain pass. Watch out for the falling rocks here. 

G-3: A Peahat infested strip of land between the foot of a mountain and 
the bank of a lake. There is a hidden cave here with a low discount 
price of 90 rupees for a magic shield inside in which you need to bomb 
to open it. There is also a Zola here as there is in most water areas.
 
G-4: The bank of the lake at the foot of Death Mountain. Watch out for 
the Zola here for it has a lot of room to swim. 

G-5: The bank of the lake with a Zola. This Zola also has a lot of room 
to swim so beware that if you are concerned with killing it then it 
will be a lot more difficult to do so. 

G-6: The bank of the lake next to the large field. It has both red 
Octoroks and a Zola. 

G-7: A valley infested with red Octoroks. There is a shop in a cave 
here at average prices selling average things. 

G-8: A small rocky valley with a lot of red Tektites in it.
 
H-1: The entrance to the peaks of Death Mountain. It is a narrow 
mountain path guarded by a red Lynal. 

H-2: The creek divides the screen. To the left is the stairs up Death 
Mountain and you have to go the long way to get to it if you do not 
have the ladder. To the right is just a small mountain pass along side 
a creek. In order to cross the creek you must have the ladder. Watch 
out for the Zola in the creek. 

H-3: A creek that leads out into the lake thus blocking your path 
without the ladder. There are Peahats and a Zola here. 

H-4: Level 1. This is an island connected to a bridge and it has a lot 
of hollow trees on it. This is your first destination at the beginning 
of the game. 

H-5: A narrow path between the lake and the forest. One of the trees 
here can be burned down to find a heart container. Watch out for the 
Zola here. 

H-6: A field that connects to areas. Watch out for the red Octoroks 
here. 

H-7: A small rocky valley with Red Octoroks in it. 

H-8: A valley with a cave along side it. In the cave is where you will 
find your very first sword. This is the screen where you start your 
game off at and where you start off every time you start in the 
overworld.
 
I-1: A mountain pass. Watch out for the falling rocks here. 

I-2: A small creek along side a mountain pass. There is a Zola and 
falling rocks here so beware. 

I-3: The northeastern part of the lake. There are Peahats and a Zola 
here. 

I-4: The bridge that takes you to Level 1 on the lake. There are many 
Octoroks here and a Zola so be careful.
 
I-5: The Southeastern part of the lake at the edge of the forest. It 
has red Leevers here as well as a Zola. 

I-6: A large field connecting many areas together. Watch out for the 
red Octoroks here. 

I-7: A field that leads into the forest to the east. Look out for red 
Octoroks here. 

I-8: A field between some valleys. There are red Octoroks here. 

J-1: A dead end at the east of Death Mountain. There is virtually 
nothing here at all. 

J-2: A narrow path between a small creek and a mountain pass. Beware 
the Zola and the falling rocks. 

J-3: The western part of the desert. There are red Leevers here. 

J-4: One of the few fairy fountains in Hyrule. This one is connected to 
the forest. Go here if you are in the eastern part of Hyrule.
 
J-5: A path at the edge of the forest. This leads to a fairy fountain. 
This also has one of the four shortcuts in it if you have the power 
bracelet. Just push the rock if you do have the power bracelet to open 
up the shortcut. 

J-6: An intersection between the forest and a large pond. Watch out for 
Peahats and a Zola here. 

J-7: The southwestern part of the forest. Part of the large pond is 
also here. Watch out for the red Octoroks and Zola here. 

J-8: The western part of a valley in the south of Hyrule. There are a 
lot of blue Tektites here. If you have the power bracelet then you can 
push one of the rocks to get to one of the four shortcuts in Hyrule. 

K-1: A springs at the peak of the mountains. The water here leads out 
to all of the other bodies of water in Hyrule. There is a Zola in the 
springs. There is a cave here that has the White Sword inside of it. 
There is also a blue Lynal guarding this cave so watch out. 

K-2: A mountain pass. There is a waterfall here coming from the springs 
above. If you walk into the waterfall then there will be a lady that 
will let you gamble for the information she wants to tell you. I know 
that information so no need gambling with her. The mountain pass creek 
starts here and there is a Zola in the creek's water. There are also 
red Tektites here. Going up the stairs will get you to the springs 
while going east will just take you to a dead end. 

K-3: The very middle of the desert in Hyrule. There are hoards of blue 
Leevers in here so watch out. 

K-4: The southwestern part of the desert. This leads into the forest to 
the south. Watch out for Leevers and Peahats here. 

K-5: A small grove amongst the forest. The grove leads to the desert or 
more forest. There are a lot of blue Tektites here as well as a cave. 
The cave has a shop inside with a decent range on prices. 

K-6: A open area within the forest at the side of a large pond. Just 
one of the many pathways through the forest. Watch out for the Zola and 
the red Octoroks. 

K-7: More open forest area along side the large pond. There are red 
Octoroks and a Zola here. 

K-8: A southern valley pass infested with blue Tektites. 

L-1: Level 5. This is at the peak of a mountain top. In order to get to 
this screen you have to cross through the lost hills first as this is 
the destination of the lost hills. 

L-2: This is the lost hills. This is like the forest maze as in if you 
don't go the right way then you will just end up in the same area. If 
you want to exit this screen just go west. Once you enter into the lost 
hills you cannot go back if you enter from the south or the east. In 
order to get to Level 5 in the lost hills just keep on going up until 
you find the screen with Level 5 on it. 

L-3: The northeastern part of the desert. There are a lot of Leevers 
and Peahats here so watch out. 

L-4: The southeastern part of the desert. There are a lot of blue 
Leevers here so be on the lookout. 

L-5: A small corner in the forest. There is a line of trees dividing 
this screen. On the left half of the trees is more forest and to the 
right is a path from the desert to the forest. There are a lot of red 
Molblins here so watch out. 

L-6: A field among the forest. There are a lot of Molblins here.
 
L-7: A field at the edge of the forest. There are Molblins and blue 
Octoroks here so be careful. 

L-8: A narrow path through the valley that leads to the beach. The path 
up leads to the forest. If you bomb a certain part of the rocky wall on 
the left here then a cave will open up with a heart container inside. 
There are a lot of red Leevers here as well as a Zola. 

M-1: A mountain peak. There is a cave here and some stairs that lead 
down to a lower elevation. I think that the cave is a shop with decent 
prices but I cannot be sure on that. Also beware of the red Tektites 
here. 

M-2: A plot of Armos on the mountains. I think there may be something 
good under one of the Armos but I am not exactly sure.
 
M-3: A large boulder at the foot of a mountain. If you bomb a certain 
part of the boulder then a cave will open up and a heart container is 
inside. Watch out for the many red Tektites bouncing around here 
though.
 
M-4: Level 2. This sits on the top of a big hill in the forest. 

M-5: The foot of a hill in the middle of the forest that leads to Level 
2 if you climb up the stairs. There are hoards of Octoroks here as well 
so be careful. 

M-6: Many winding paths through the forest. Each path leads to more 
forest. A really thick line of trees divides the paths. There are a lot 
of blue Molblins prowling these paths. 

M-7: The middle of the forest with many paths leading through it. There 
is a thin line of trees dividing the screen. If you are on the left 
side of the screen and want to get to the right side you will have to 
take a long path around the trees through several other screens. There 
are also a lot of red Molblins here so watch out. 

M-8: The beach. To the south is an ocean which leads to more vast lands 
that are not in this game. Along side the beach are many red Leevers so 
be careful. 

N-1: The peak of a mountain. Going down the stairs takes you to the 
rest of southern Hyrule. This place has a few red Tektites in it so be 
on the lookout. 

N-2: Two mountain paths with a layer of mountain dividing the screen. 
On the left side of the screen you can push the rock to open one of the 
four shortcuts if you have the Power Bracelet. To the right is just the 
corner of a small gulf with a Zola in it. The stairs go up the mountain 
peak which leads to more paths that take you elsewhere. There are also 
a few Peahats flying above the mountain peaks here too. 

N-3: Strip of land between the foot of a mountain and the gulf of the 
ocean. To the south of this screen lies the forest. This screen is 
inhabited by a hoard of Octoroks and a Zola. 

N-4: The northern most strip of forest. It has many blue Molblins 
roaming it. There are two Armos and one is covering a cave with a 
Molblin that gives money inside of it. 

N-5: A field in the middle of the forest. There are a lot of blue 
Molblins wandering through here. To the west of here is the path to 
Level 2. 

N-6: The heart of the forest. This is a bit of an intersection that 
leads to more forest in all directions. There are a lot of blue 
Molblins here so be careful. 

N-7: A few paths in the southern forest. The lone tree blocking the 
intersection is Level 8. Just burn down that tree with a candle and you 
will find it. There are also many red Molblins around here so be 
careful. 

N-8: A strip of beach. There are a lot of blue Octoroks here as well as 
a Zola in the ocean. 

O-1: A narrow path that leads to the peak of a mountain. The cave at 
the peak here has an old man that will give you the letter to give to 
the potion lady. 

O-2: An intersection at the foot of a mountain. Going west will lead 
back to the mainland, going north up the stairs will lead to the 
mountain peaks and going east goes to a sort of dead end. There are a 
lot of red Tektites maneuvering between the sides of the mountain as 
well as a Zola in the gulf. 

O-3: A corner of land that edges the ocean. There are many Octoroks 
here as well as a Zola in the water. 

O-4: More land along side the ocean. There are a lot of Octoroks here 
and also a Zola. 

O-5: The northeast corner of the forest. This is a dead end with two 
Armos in it. One of the Armos is covering a secret cave. That cave is I 
think a gambling game but it might be a Molblin that gives you money, 
but I really don't remember. I would go with saying that it is a 
Molblin but I could be wrong. There are a lot of Blue Molblins on this 
screen. 

O-6: A dead end in the forest inhabited by blue Molblins. There is a 
cave here which I think is a shop but it might be a Molblin giving you 
rupees too. I think it is a shop though. 

O-7: The field in the forest that leads out of the forest. This has 
many Molblins and blue Octoroks in it. 

O-8: The coast of the ocean and the beach. There are a few Octoroks 
here as well as a Zola in the ocean so be careful. 

P-1: This is a hidden mountain peak. There is a shrine here that has a 
rupee giving Molblin in it. To get to this screen you must walk through 
the wall of the screen below here. 

P-2: A dead end. There are a lot of hollow trees here with a hoard of 
Peahats flying around them. The tree with a hole in it just has a 
gambling old man in there which I do not recommend seeing him but you 
can if you want and are willing to take a risk. If you climb the 
mountain here by walking into the northern wall then you can get to the 
screen above here. You will just walk through the wall if you push at 
the correct spot.

P-3: A small gloomy island off the coast of the ocean. To get here you 
will need the raft. Once you are here, enter the shrine to find a heart 
container. 

P-4: The coast of the ocean. It has a dock here and if you have the 
raft then you can go on that dock and sail to the island adjacent to 
it. Look out for the Blue Octorok and the Zola here. 

P-5: A series of docks along side the coast of Hyrule. There is a ton 
of Octoroks here and a Zola. The docks here are pointless though. 

P-6: Pretty much identical to the screen above it, this is more coast 
with docks in it. There is a hoard of Octoroks here and a Zola in the 
ocean. There is a heart container on one of the docks if you can get 
over there with the ladder. 

P-7: The beach which also leads into the forest. There is a cave here 
which has a shop with decent prices inside. There are also a lot of 
Octoroks and a Zola here as well so watch out.
 
P-8: The most southeastern part of Hyrule. This is the coast and it has 
a blue Octorok and a Zola in it so watch out. 
********************
IX.

THE LEGEND OF ZELDA HEART CONTAINERS

Heart Containers: Every time you beat a dungeon boss in the game you 
get a heart container which adds one more heart on to your maximum 
health. There are five other heart containers to get that are all 
hidden in the overworld. I will list the ones in the first quest for 
now:
*****
H-4: You can burn down one of the trees more to the right of the screen 
to find a heart container.
 
L-8: Bomb around the left flat wall and a cave will be opened up with 
the heart container inside. 

M-3: The large rock in the middle of the screen has a hidden cave 
inside of it if you bomb a certain part of it. 

P-3: You need the raft to get this one. In P-4 there is a dock. Use the 
raft at that dock and it will take you to an island with the heart 
container in the cave.
 
P-6: This is the only heart container that is actually out in the open. 
To get it you simply need the ladder. Once you have the ladder, you can 
easily walk across to the docks in the water and retrieve your prize! 

********************
X.

THE LEGEND OF ZELDA MUSIC REVIEW

The music for this game is excellent because it set a theme song for 
the entire series. Even though the music is composed of primitive LED 
electronic music, it can still be enchanting almost. The tunes 
themselves are excellent when listened to with a more advanced Midi 
instrument. Some tunes like the dungeon music are a bit repetitive but 
still enjoyable if you listen to it once. Still though, other Zelda 
games have way better music than Zelda 1. The music is great 
nonetheless.
********************
XI.

LEGEND OF ZELDA WALKTHRU~THE FIRST QUEST

Here you will find a step by step walkthru for the first quest for The 
Legend Of Zelda. Keep in mind that this is my very first walkthru and I 
am new to this so I will admit that it will be hard for me to make this 
walkthru. In dungeons, I will try my best, but if the walkthru through 
the dungeons is a little longer than it should be then that is my fault 
and I apologize. I don't think that it should be too big of a problem 
though. Infact, after looking over it, it looks pretty fine to me. It 
is a bit long though, but that is because I went into more details.

*****

To Level 1:

The game will start off on screen H-8. You are in an open valley in 
southern Hyrule. First things first before you do anything, you need a 
sword. Just go into the cave you see on this screen. Inside the cave 
there will be an old man that will give you your first sword so just 
walk up and take it. Now once you have your sword your very first 
destination is Level 1 which is on screen H-4. For those of you who 
don't want to read through all of my details on to get to Level 1, the 
basic directions are: Up, Right, Up, Up, Up, Left. But if you are 
interested in details, read on. Exit the cave and go to the screen 
above you. Here is where you will encounter your very first enemy the 
Octorok. Like all enemies you can check the bestiary I have made to get 
more information on the enemies. If for some reason you would mess up 
and die before you get to Level 1, just start over, it is not hard at 
all and would just take patience and persistence if you die a lot but 
getting to Level 1 should not be a problem because it is easy. Simply 
attack the Octoroks with your sword. If you don't get hit and have full 
health then you can shoot swords and hit them even easier. Sometimes 
their rocks that they shoot will not hit you if you hide behind the 
rocks on the ground on this screen but if you see no way out of the 
path of a moving rock try to use your shield to deflect it. Or if you 
really don't care, you could just ignore the enemies and run away all 
together. Killing enemies will get you a lot of good items so I 
recommend at least trying to kill a lot of the enemies you see in the 
game. So just kill these four red Octoroks and go right. Now there are 
a few more Octoroks creeping in between many trees in a field. Just 
kill them as well and go up. The next screen is a lot like the screen 
to the bottom, so just kill the Octoroks and go up a screen. Here there 
are red Leevers which are harder than Octoroks. They will take two hits 
to kill. Just try to keep your distance and when you see one come out 
of the dirt try to strike it with your sword. Many times Red Leevers 
will all come out of the ground in a row and you can just kill them all 
in a line very easily. Just ignore the Zola in the water for now as you 
cannot kill it until you have the white sword later in the game. Go up 
a screen here. Here you may have trouble if you don't use good skills. 
Not only is there a Zola that you cannot kill in the water but there is 
also a blue Octorok here which takes two hits to kill with your current 
sword. If you don't even care about killing everything you can just try 
to ignore the monsters and go to the next screen. Cross the bridge to 
the left. Now you are on an island with many hollowed out, dead trees. 
There is a red Octorok here so be careful. Just go into the middle tree 
with a hole in it and you are now in Level 1.

Level 1:

This level's design is supposed to resemble an Eagle, but it doesn't 
look that much like it. Use this design to help you if you really need 
it but you probably won't especially since I will provide the walkthru. 
This Level is a tealish-blue color and it is your first taste of the 
repetitive NES dungeon music that might make you scream if you don't 
have the patience. Luckily I have the patience and if you don't then 
just turn down the volume. You will start off in just a regular room 
with no enemies and just many statues. This is how every first room in 
this game's dungeons look. First, go left into the next room. Here you 
will find three Keese which won't be a problem. Just make sure that 
they don't fly into you and just kill them with your sword. They will 
leave a key behind. Now exit the room and in the room where you started 
off go right again. There will be a hoard of Stalfos running around the 
room. They are not hard at all and only take two hits with your current 
sword. As you may see, one of the Stalfos has a key lodged into itself. 
Kill that Stalfos and get it's key. Now leave this room and go back to 
the room where you started off. Now that you have a key go through the 
locked door and one of your keys will disappear. In the next room are 
three Stalfos. Simply kill the Stalfos and proceed into the next room. 
In this next room is another hoard of Stalfos. After you kill all of 
them then a key will appear in the room. Go into the room to the right. 
In this room is a flock of Keese. Just keep your distance and kill them 
as usual. There is a compass in the corner of the room so pick that up. 
Now you can see where the Triforce piece in this dungeon lies. Leave 
the room and go left again once you leave the room. In this room there 
are more Keese. Once you enter the room the doors behind you will shut. 
After you kill all of the Keese then the doors will open again. You 
will see these doors that shut in all the dungeons and you will see 
them often. Now that you killed all of the Keese then just go forward 
through the locked door. In this room you will see three Gels moving 
throughout the room. They are very easy, so just hit them with you 
sword. Once they are all dead you can push the block in the middle of 
the room. When you push that block then the shut doors to your left 
will open. Inside the next room is an old man that will tell you a 
hint. The hint is "Eastmost peninsula is the secret". Basically all 
that means is that the Triforce piece is at the eastmost peninsula on 
the map in this level unless of course he is referring to the overworld 
in which he may be speaking of a hidden rupee cave. Leave the old man's 
room and go right. In this room are more Gels and the map. Just kill 
the Gels and take the map. Now you can see the dungeon's layout and see 
if it really looks like an eagle. Now go into the room above you. In 
this room are three Stalfos walking along narrow paths extended over 
water. Since you don't have as much room to walk it may be a little 
harder. Just try to keep your distance and if a Stalfos is following 
you then run away and quickly turn around and hit it with your sword 
and repeat until it is dead. One of the Stalfos is holding a key. After 
the Stalfos are all dead then go through the locked door up. Here you 
will find three red Goriyas. Try not to stand in front of them as they 
throw boomerangs. Try to attack them from their sides or back. It takes 
three hits to kill them. You can strike them over the water if you are 
facing up and they are right above you. After you kill them all, they 
leave a key. Get the key and open the locked door to your left. As soon 
as you enter the room keep on walking left. There are traps in this 
room and one is set at the entrance. If you stand at the entrance to 
this room long enough you will get hurt. In this room, you want to get 
around to the other side of the cluster of blocks. The only path over 
there is in alignment with the path of the traps. What you have to do 
is walk into the traps path and that will set the traps off but back up 
to get out of their way when they close in. When they are slowly moving 
back into their idle position, take the opportunity to run over to the 
other side of the blocks. Now push the block farthest to the left and 
enter the stairway. Now you are in a 2-D basement. Watch out for the 
four Keese in here. Just try to avoid them and if you can hit them you 
can try. They are just there to make it more difficult for you. Climb 
down the stairs and go all the way to the right to the other stairs. Up 
those stairs sits the bow which you cannot use until you buy some 
arrows at a shop. After you get the bow then leave this basement. To 
leave this room perform the same method of setting off the traps and 
also it would be wise to do the same method to the traps at the exit of 
the room as well. In the next room go down two rooms and open the 
locked door to your right. In the next room are three red Goriyas. Kill 
them all and they will leave the boomerang. The boomerang will 
automatically equip itself, being the only item accessible at this 
time. The boomerang is a very useful item. From now on, when battling 
most enemies, try to shoot them with the boomerang and then strike them 
with your sword. If that enemy takes many hits to kill then keep on 
stunning it with your boomerang between sword blows. This technique 
will make the game a lot more easier. Now go into the room to the 
right. This is the room right before the dungeon boss as you can hear 
it's frequent roars. In this room it may look empty at first but it is 
not. First go over and pick up the key. Now watch out for all of the 
Wallmasters. Wallmasters are the hands that come out of the walls. If 
you let one get you then it will take you all the way back to the 
beginning of the level which is a real pain in the ass so just keep 
away from them whatever you do. None of the Wallmasters will ever go 
very far away from the wall so if you are in the middle of the room you 
are pretty much safe. There are many Wallmasters to kill in this room 
however you do not need to kill them to get into the next room. Beware 
that if you get a clock which Wallmaster often leave behind after you 
kill them, then no more Wallmasters will appear if you want to kill 
them all. If you are ever in a situation where you need to kill all of 
the Wallmasters in the room but you got the clock then just leave the 
room and come back. Go up through the locked door. In here you will 
have to battle the dungeon's boss named Aquamentus. No, he does not 
have anything to do with water or fresh breath despite his name. He is 
a huge dragon that blocks the way into the Triforce room and he will 
shoot three energy balls at you at a time. His head is his weak point. 
If you have full health and the ability to shoot swords he will be 
really easy to kill. Just keep your sword in alignment with his head in 
the opposite side of the room of him and keep on shooting until he is 
dead, avoiding the occasionally energy balls he shoots at you. If you 
don't have full health then just walk over to his head and hit it once 
or twice then run away again to avoid his energy balls and keep on 
doing that until he is dead. If you are brave and have enough health 
you can also just run up to his head and whack him like crazy with your 
sword until he is dead but it is all up to you. After a few hits he 
will be dead and he will leave a heart container where he stood. Pick 
up the heart container and you will now have 4 hearts maximum! Now go 
into the next room and you will see the flashing Triforce piece sitting 
in the middle of the room. Pick it up and it will restore your health 
and you will be 1/9th of the way through the first quest. You will come 
out of the entrance to Level 1. If you want to save the game now you 
can but you will start at the beginning on screen H-8 if you do but at 
least you will be safe from you losing your information if the Nintendo 
freezes which it easily does sometimes. If you really want to be safe, 
I would save after every level but I actually usually save after every 
two levels or if I die. Next stop is to Level 2.

To Level 2:

Level 2 is on screen M-4. From Level 1 you go: Right, Down, Down, 
Right, Up, Right, Right, Down, Right(At the top of the screen), Right, 
Up, Left, Up. From the beginning of the game you go: Right, Right, 
Right, Right, Up, Up, Right(At the top of the screen), Right, Up, Left, 
Up. What I recommend is you do a little shopping before you go to Level 
2. I would buy a magic shield. You should either have enough or almost 
enough rupees at this point. If you need more rupees then I know a 
great path to follow in order to get more rupees. The "Rupee Path" is 
as follows: At the beginning where you normally start off at go: Right, 
Right, Right, Right, Right, Right, Right, Right, Up, Up, Up, Up, Left, 
Up, Left, Left, Left, Left, Left, Left, Down, Down, Down, Down, Left, 
Down. Keep on repeating this until you have enough rupees and kill all 
of the enemies along the way although you can ignore the Zolas and 
Peahats if you want. A lot of these enemies carry a lot of Rupees. Blue 
Tektites and red Leevers are rich and will get you a lot of money. Once 
you have the shortcut activated then you can go to the shortcut on 
screen N-2 and warp to screen J-8 and continue that pattern over and 
over again until you have enough rupees. To get to the warp at N-2 from 
the Rupee Path when you arrive on screen N-3 just go up and go through 
the shortcut. If you have not opened the shortcut yet then you can also 
go the following path when you arrive at screen J-3: Kill all the red 
Leevers here for a lot of money then go: Right, Down, Down, Left, 
Down(Or up first if you need a fairy fountain health restoration), 
Left, Down, Left, Down. Going this way will take you through a blue 
Tektite screen which leave a lot of money behind when you kill them. If 
some enemies like blue Tektites leave rupees on walls and mountains 
that you cannot reach, just use the boomerang to retrieve the rupees 
and other items you may want. Now that you have enough money go get a 
magic shield. The cheapest price I have seen in the game for a magic 
shield is 90 rupees in a hidden cave revealed by a bomb in screen G-3 
but you cannot access that screen yet. Instead just save up a few more 
rupees and get the magic shield that costs 130 rupees. That shop is in 
screen P-7 which you will pass if you take the Rupee path. If you 
really want to buy a lot of stuff now then you should also buy the blue 
candle in the shop on screen G-7 for 60 rupees, some arrows from the 
shop on screen P-7 for 80 rupees, and some bombs from the shop on 
screen P-7 for 20 rupees. You don't have to buy those things now but if 
you want to you can. It will take a long time to accumulate enough 
rupees to get those items however. You will need the arrows and the 
blue candle eventually however I am pretty sure you will find bombs in 
Level 2 as well as when many enemies, especially blue Octoroks and blue 
Molblins, leave behind after you kill them but bombs are not really 
that necessary to get now. Also, on screens N-4 and O-5, there are 
sleeping Armos. If you wake them up then there will be a hidden 
staircase under them when they start moving. In those staircases is a 
cave with a nice Molblin inside that gives you rupees and then leaves. 
The one in N-4 gives you 30 rupees while the one in O-5 gives you a 
measly 10 rupees although every rupee is important, right? Since you 
could be anywhere right now in the walkthru, I won't give as much 
detail as to how to get to Level 2. I will say however, watch out for 
the Molblins in the forest near Level 2, especially the blue ones for 
they take a few hits to kill. Just try to dodge their arrows or deflect 
them if you can. Also, there is a fairy fountain on screen J-4 if you 
are near there and need to have full health. Level 2 is on screen M-4. 
There is a blue Octorok guarding Level 2 so watch out. Just ignore the 
Armos for they are non-important and do not need to be woken up. Just 
enter the shrine and you are in Level 2.

Level 2: 

The design of Level 2 is supposed to resemble a crescent moon although 
it doesn't really help that much. This level is really blue, so much 
that it might hurt your eyes. With all that aside let's begin the level 
shall we? First things first, go to the room to the right. Here, there 
will be many snakes called Ropes inside. If you cross their line of 
vision then they will charge towards you. Just try not to cross their 
line of vision and you can also stun them with the boomerang which will 
also help. After you kill all of the Ropes then they will leave a key 
behind for you to take. Next go up into the next room. Here there will 
be three more Ropes. Just hide and maneuver through the blocks in the 
room and it will not be as hard. You can also strike your sword at the 
Ropes through the blocks. Next go left. In this room will be a few 
Ropes, just kill them and a pair of shut doors will open revealing 
another room to go in. Go left into this now open room. In here there 
are several Ropes, just kill them and get the key in the room 
afterwards. Now go right two rooms and open the locked door to the 
right. Go in the now unlocked door. In here there will be many Gels 
moving about. Now that you have a boomerang you can just chuck it at 
them and it will kill them instantly. The same technique works on Keese 
also. Now collect the Compass in the room so that you can see where the 
Triforce piece is in the level. Now go left to exit this room and now 
go up. In this room is a lot of red Goriya. Kill all of the red Goriya, 
and try to use the boomerang in the process for it really does help. 
Now go right and you will be in a room with a bunch of Gels. Kill the 
Gels with the boomerang and get the map. Leave this room and then go 
up. Kill all of the Ropes in this room to get a key. Now go to the room 
to the right. Now this room is very tough and if you want you can do it 
later in the game when you have more health and experience because this 
room is not mandatory. But I recommend doing this room anyways for it 
is a good idea. It may take some patience and a few tries but you can 
do it eventually. Try to have as much health as possible when entering 
this room. In this room are three blue Goriyas which you have to hit 
many times with your current sword to kill. To make it even harder, the 
statues in the corners of the room are continuously shooting energy 
balls at you. So not only do you have to avoid three boomerangs but 
also a barrage of non-stop energy balls! Just whatever you do, try to 
stun the Goriyas with your boomerang, avoiding any other weapons 
projectiled towards you and once a Goriya is stunned, focus on it. Just 
strike it with your sword, then stun, then strike, then stun again 
until it is dead. Do the same technique for the last two Goriyas. Once 
all three blue Goriyas are dead, then a blue magical boomerang will 
appear on the floor. Pick it up quickly before you get shot at by the 
statues. Now you can throw your boomerang all the way across the screen 
which is very helpful. Leave this room to the left. Now go up a room. 
You will enter a room full of sand and two worm like creatures called 
Moldorm will be scurrying across the sand. They may look tough but in 
reality they are very easy to beat. Just keep your distance and keep on 
hitting their bodies. The more they get hit, the more body segments 
they lose and eventually they will both die. Once you kill both of them 
then a key will appear on the sand. Go to the room to the right. 
Quickly keep on walking as you enter the room because there are traps 
set at the entrance. The only enemies in this room are a few Keese 
which you can easily fend off with your new and improved boomerang. 
There are bombs sitting in the middle of the room in case you don't 
have any already because you need them to finish the level off. As you 
leave you can try to set off the traps then exit as they are resetting 
themselves or you can just run like hell which works also. Now you are 
in the room with sand in it again so go up into the next room. In this 
room is a lot of Ropes so be careful. Just kill all of the Ropes and go 
through the locked door on the right. In this room is simply a few Gels 
and when you kill them all you will get a mere five Rupees. Go up after 
you get more cash. In this room you will see a hint giving old man and 
he will say "Dodongo dislikes smoke". That means that you have to use 
bombs to kill the dungeon boss named Dodongo. Now exit this man's room 
and go left then up. In this room is a hoard of red Goriyas but this 
time they wield a blue magical boomerang too now that you got the new 
boomerang. You can stun and kill them between the blocks and maneuver 
around the blocks strategically to kill the Goriyas. After you slay all 
of your foes in this room then some bombs will appear. Notice the roar? 
That is because you are right next to the boss's chamber. Go up into 
the boss's chamber. In here you will find Dodongo, a dinosaur like foe 
that pretty much does nothing except walk around the room. Like the old 
man said he is pretty much invulnerable to everything except bombs. 
There are two ways to kill him. The first way is to strategically place 
a bomb right where he will walk. Sometimes you may miss or he may do a 
sudden turnaround and you will waste a precious bomb. Most of the time 
he will eat it however and it will hurt him. Another bomb like that 
will finish him off. It is good to put a bomb right in front of him 
while the other one is exploding in his stomach, that way he will eat 
it when he gets unstunned. Another good way to kill Dodongo is to 
quickly place a second bomb on him while he is eating the first bomb. 
If the second bomb explodes while he is stunned from the first bomb 
exploding inside his stomach then he will be stunned. While he is 
stunned then he will even be vulnerable to your sword and one sword 
strike will kill him. Doing this also gets you more bombs. Later in the 
game in several areas you will have to beat three Dodongos in a room. 
If for some reason you run out of bombs then you either have to 
scavenger up enough rupees and buy bombs in the shops in the overworld 
or find enough bombs that enemies drop to kill Dodongo. After Dodongo 
is dead then he will leave a heart container and you now have 5 hearts! 
Go into the next room and collect the Triforce piece. You are 2/9ths 
done with the first quest. You will now exit Level 2 and now would be a 
good time to save despite the fact that you will start off on screen H-
8 again.

To Level 3: 

Now that you have 5 hearts you will have enough hearts to get the white 
sword. I strongly urge you to get the next sword as if you don't, the 
game will be really tough. The White Sword is on screen K-1. To get 
there from Level 2 go: Down, Right, Up, Up, Up(The staircase), Left, 
Left, Left, Up. If you are back at the beginning on screen H-8 then 
just go to Level 2 and follow my directions I gave from there. On this 
screen is a cave and an old man inside the cave will give you the more 
powerful white sword if you have 5 or more hearts. Beware the blue 
Lynal guarding the cave though for he is the toughest overworld enemy 
in the game. Just stun him with your boomerang between sword blows and 
you should be fine. Now that you have the white sword enemies will be a 
lot easier to kill and the game will be a lot easier to beat. Those 
annoying Zolas in the water can now be defeated because it will now 
only take one sword hit to kill them. Other enemies will take less hits 
to kill them as well. Now that you have your new sword exit the cave. 
You can only go one way now as the path that you came is a dead end due 
to your passing through the lost hills screen. So from this screen just 
go: Down, Left, Left, Left, Down, Right, Down, Down, Down, Down, Left, 
Down to get back to the beginning on screen H-8. Now I recommend 
getting the two or three heart containers that are now accessible in 
the game. For container number one you should go from the beginning at 
H-8: Right, Right, Right, Right. Here just bomb the flat wall to the 
left in the right area and a cave will be revealed. In the cave will be 
a choice between a red potion and a heart container. Obviously you want 
to pick the heart container as not only can you can easily get a red 
potion later in the game but also you get another heart added on to 
your maximum health! Now from the beginning at H-8 go: Up, Right, Up, 
Up, Up, Up, Right, Right, Right, Right. Bomb the right spot in the 
large boulder to reveal a cave with a heart container in it. From the 
beginning at H-8 go: Up, Right, Up, Up, Left. Burn on of the trees 
towards the right of the screen with the blue candle. If you don't have 
the candle I urge you go get it now. You don't have to get these heart 
containers now but the game would be a lot more easier if you did. If 
you run out of bombs then buy or find more. If you don't burn down the 
right tree then leave the screen, come back and try again. Don't worry, 
eventually you will find it. Now with all of this aside, you are ready 
to go to Level 3. Level 3 is on screen E-8. To get there from the 
beginning at H-8 go: Up, Left, Left, Left, Left, Down, Right. If you 
need to, instead of going down where I said down, go up two screens to 
find a fairy fountain. Then after you get your health restored, go down 
three screens and then go right.  On this screen there will be more 
Armos and a red Tektite. You can kill the Tektite if you want but just 
ignore the Armos and enter the shrine to get to Level 3.

Level 3:

This time the level is a green color. The shape of the level is 
supposed to be a "Manji" whatever that is. Probably some Bhuddist 
symbol of peace and harmony or something but to me it looks like a 
Swastika so go figure. You can only go left here so do just that. This 
next room is filled with Zols which are large versions of the Gels. If 
you have the first sword then when you strike the Zol it will split 
into two Gels. Luckily, if you followed my directions and got the white 
sword, then you can kill the Zols with one hit. There is a key in this 
room as well so just take it and then go up into the next room. In this 
room are a few more Zols. After you slay all of them then a key will 
appear. Take the key and go up into the next room. In this room you 
will have your first encounter with the Darknut. Darknuts can be very 
hard and frustrating sometimes but if you know what you are doing then 
it should be no real problem. The Darknuts in here are red, there are 
only three of them, plus you have a lot of space to move around so they 
should not be as tough to defeat. Darknuts are armored in the front of 
their bodies so you have to attack them from either of their sides or 
their backs. I would always try to hit them at their sides as they will 
do a 180 degree turn-around when you attack them from their back and 
they will often times run into you. I would keep my distance also when 
fighting them. If you have full health and you can shoot swords then it 
is always a lot easier as you have no threat of having them turn 
around, suddenly running into you. After you kill all three red 
Darknuts then some bombs will appear. Go left into the next room. Keep 
on walking as there are traps set at the entrance. Kill all of the 
Keese in this room and then collect the compass. Now go left into the 
next room but be careful with the traps. In here is a hoard of red 
Darknuts and you also have less space so it is easier for them to 
corner you in if you are not careful. Try not to be around too many of 
them at once. After you kill them all then the doors below will open 
and you can go in them. In this room is a ton of red Darknuts. There 
are so many Darknuts here that no doubt your NES will slow down rapidly 
as well as the music so it is like a dramatic action scene from a 
movie. After you kill the first Darknut things will speed up a bit 
though. Be careful as to not get hit and kill all of the Darknuts to 
get some bombs. Go down the stairs to the right. In here is another 2-D 
basement with Keese in it. Your prize in this room is the raft which 
you don't use much in the game but oh well. After you get the raft then 
leave this basement and go up two rooms. In here there will be Keese, 
Zols, and Bubbles. Bubbles are the only thing new and not only will 
they curse you from using your sword for a few seconds but they will 
also push you really far backwards which can be a hazard sometimes. If 
you happen to get cursed it is no big deal as not only can your 
boomerang kill the Keese but also the curse only lasts a second. The 
bubbles are invincible however. After you kill the Zols and Keese go 
right into the next room. This next room will have blocks that form a 
small corridor to walk through not allowing much space to move around 
in. Kill all of the Keese with your boomerang and then collect the 
bombs that appear in the room afterwards. Now continue right into the 
locked door to get into the next room. In here are three Zols and they 
will leave a key after you kill them all. After you complete this room 
then go up through the locked door. Watch out for the traps at the 
entrance and kill the two Zols in this room. After you kill the Zols 
you might wonder why the shut doors did not open and that is because 
you have to push the left block to open them. After you open the doors 
with the block then go up into the next room being careful with the 
traps. In this room is an old man that gives hints. He says: "Did you 
get the sword from the old man on top of the waterfall?" If you could, 
you would answer "Yes." and you should already have the sword if you 
followed this walkthru correctly. Just go left into the next room. Kill 
all of the Keese in this room and after you do so the doors that shut 
when you entered the room will open, allowing you to leave. Take the 
key and go right, then down, then down again being careful of the 
traps. Now from here, open up the locked door to your right. Keep on 
walking because of the traps and kill the two Zols. Take the map. Now 
you may think that the boss's room is next because of the roaring but 
that is wrong. You always hear the roar if you are right next to the 
boss's room which you are, but the next room does not lead to the 
boss's room. Go down, avoiding the traps. In here are three red 
Darknuts however you can strategically hide behind the blocks and 
attack them there. You can either come out quickly, strike, then run 
away, or you can also strike them from over the blocks sometimes as 
well. After you kill the Darknuts then the shut doors to your right 
will open so enter them. Now this is the room right before the boss. In 
here is a few Keese, Gels and Bubbles. As usual, try to avoid the 
Bubbles and kill the Zols and Keese. After you kill all of the enemies 
in this room then you will get a blue rupee but I doubt you really 
care. Just go up into the boss's chamber. In here you will see the boss 
Manhandla moving around in the sand. Manhandla? It sounds like manhands 
from Seinfeld. Well anywho, Manhandla is a large multi-headed plant 
that shoots energy balls at you and moves quickly across the room. It's 
body is invincible so you have to hit it's heads. Try to keep your 
distance yet come in close enough to strike. Of course, try not to get 
hit with the energy balls. A few hits will eliminate a head. What 
really works good though is if you strategically place a bomb where he 
is going to move to. The bomb will always get rid of a few heads and 
sometimes kill him instantly. It is all up to you what you want to do. 
After you slay this beast then just pick up your heart container and 
collect the Triforce piece in the next room. Well what do you know, you 
are already a third complete with the first quest! You will then leave 
Level 3 of course and now you can work your way to Level 4. You can 
save if you want now which is always a good idea to do.

To Level 4: 

Before going to Level 4, I recommend getting these few things first. 
Get another piece of heart, get the blue ring, get the blue candle, get 
the letter, get the red potion, and get the meat if you want. The two 
most important things is the heart container and the blue ring though. 
In fact, getting the rest of the stuff is really probably not all that 
important to get right now anyways, but you can if you want to. First 
you should get another heart container. It is on screen P-3. Follow the 
Rupee Path to screen P-4 and then from here, use the raft at the dock 
to float to the island on screen P-3. Just enter the shrine and you can 
get a heart container inside. Next, go get the blue ring. The blue ring 
is on screen E-4. Wake up the top-middle Armos and then go into the 
staircase he reveals. Down the staircase is a cave with an expensive 
shop inside. You can buy the blue ring here for a whopping 250 rupees 
but it is worth it, for the blue ring really takes a lot of damage 
away. I really do recommend getting the blue ring now, so just follow 
the Rupee Path for a while until you get enough money. By now in the 
game, you will probably be close to having 250 rupees anyways. Notice 
the meat in the shop as well? Remember that meat for you will need it 
later in the game as well. Get the blue candle for 60 rupees at the 
shop on screen G-7 as you will need it for the next level. Now if you 
really want to upgrade then you can get the letter, the red potion and 
the meat now. Just look later in the walkthru for directions on how to 
get them. As of now, I would just go to Level 4 though. Level 4 is on 
screen F-5. To get there from the beginning on screen H-8 go: Up, Left, 
Left, Up(On the right side). Now from here, use the raft at the dock to 
float to Level 4. There is a Peahat here. You can kill it if you want 
but it doesn't matter either way. Enter the shrine to get to Level 4.

Level 4: 

Level 4 is a yellow color. For some reason no dungeons in this game are 
the color red. Anywho, the supposed shape of this level is a snake 
whether you see it or not. First go left into the next room. There is 
an easy flock of Keese here and after you kill all of them then you get 
a key. After you get the key then go right and then up. In this room 
you will find three Vire. With your current sword, when you hit them, 
they will split into two red Keese which are really no different than 
the regular Keese. The Vire are not hard to kill at all. For some 
reason, if you leave the room and then come back, then the Vire are 
back too. Just go into the locked door on the right. Oh no, who turned 
off the lights? This is no problem, just let out a flame with the blue 
candle. Be careful not to run into the flame though as it can hurt you. 
Technically, you could maneuver through this room in the dark but it 
would be very hard. After the room is lit, kill the Vire and the Keese 
and collect the compass. Leave the room and the Vire will probably be 
in the room again. You can kill them if you want but whatever you do, 
just go up eventually. In this room is a flock of Keese guarding the 
key. After you finish this room then go left. You will be in another 
dark room so light it up with your candle. After the room is lit, slay 
the many Vire in this room. Then after that, just go up. Yet another 
dark room! Light it up as usual and you will reveal three Zols in the 
room. Kill the Zols, collect the key, and go up. This room is another 
dark room. Light it up and then you can kill the Vire. As you can see, 
a pool of water is blocking the upper door, so you have to go there 
later once you get the ladder. If there are any enemies behind the 
pool, beyond reach, then you can just ignore them. For now, just go 
right through the locked door. In this room is a narrow path surrounded 
by water and several Vire hopping around the place. It helps to use the 
boomerang here and to try to reach the Vire across the water sometimes 
but it doesn't always work. Either way, this room is not hard. Kill the 
Vire to open the doors to the right. Then go right into the next room. 
In here you have to be extra careful. There are Bubbles, Zols, and Like 
Likes. The Zols should not be a problem but the Bubbles and Like Likes 
will be. As you may know, if you touch a Like Like, then it will eat 
you magic shield a lot of the times! The cheapest price I have seen for 
a magic shield is 90 rupees and I am sure you don't want to spend 
forever saving up enough rupees to buy another shield every time you 
run into a Like Like. To make matters worse, the Bubbles will push you 
a great distance if they hit you and many times if you are not careful, 
they will push you right into a Like Like. What I would do is 
concentrate on the Zols first to get them out of the way. While doing 
this, avoid the other enemies as much as possible. Now focus on the 
Like Likes. Try to corner a Like Like and stun it with your boomerang. 
Once it is stunned try to make sure that no Bubbles are in the way and 
if there is a Bubble near by or if one is coming then get out of the 
way and still try to keep the Like Like stunned by chucking your 
boomerang at it every few seconds. Once the coast is clear, focus on 
the Like Like. Stun, then strike, then stun, then strike. Repeat that 
technique until it is dead. Unfortunately, you have to hit the Like 
Like many times to kill it. Finally after this battle, you can push the 
left block in this room to reveal a hidden staircase. Go down the 
staircase. Down here is the usual 2-D basement with four Keese and a 
treasure. The treasure this time is the ladder which you will need. 
Take the ladder then leave the basement. Go left into the other room. 
The Vire will probably reappear. This time you can walk across the 
narrow pools of water with the ladder and a good strategy to use is to 
station yourself over the pool and strike the enemies as they come by 
from there. If you want to, you can go through the locked door up but 
there would be nothing important up there. If you do go up, then after 
you light up the room, you will see yourself on a peninsula and there 
will be a map across some water which you cannot get from this entrance 
so it is pretty much pointless to enter this room, not to mention that 
you would waste a key. I would just go left instead. After you light up 
this room, kill the Vire and be careful for the Bubbles. Now you can 
cross the water so do so and enter through the locked door up above. 
Simply kill all of the Vire in this room and proceed to the right. 
Light up this room and kill the Gels here. Follow the narrow path to 
the map in the corner of the room. Once you do this then leave the 
room. You will probably have to fight the Vires again but since they 
are not hard then it should not be a problem. After you kill the Vires 
then go up into the next room. This is your first taste of a boss 
rematch in the game. Often, you will have to fight one of the previous 
bosses in the game again. You have to fight a Manhandla in this room 
and this time there are also statues in the corner of the room shooting 
energy balls at you. Remember that each Manhandla's head has two hits 
to kill, that Manhandla will increase in speed as you eliminate it's 
heads and that you can just use bombs to try to finish Manhandla off 
quickly. Once you slay Manhandla then go up a room. In here you will 
see a hint giving old man. He will say: "Walk into the waterfall". What 
he means is that you can walk into the only waterfall in Hyrule and go 
into a hidden cave. That hidden cave has a lady that you can gamble 
with so that she will give you good hints. Just don't even bother with 
the waterfall lady because I know what she says and I will just tell 
you later what she says. Just go right into the next room through the 
locked door. Light up the room with the candle and kill all of the 
Keese. Pick up the key on the little island in the middle of the room. 
Proceed to the right. This next room is a little tricky. There are 
traps set at the entrance and right in front of where you would 
normally escape the trap's path is a block. To make matters worse, the 
room is dark so you cannot see your way. Luckily, you can stand in the 
doorway and look at the scenario before you make your run for it. What 
you have to do is run quickly either up or down then go right really 
fast to escape the trap's path. I will admit that I even often get hit 
here. I would try to go down as if you go up, you will have to cross 
the path of more traps. Even if you do get hit, it will only take off a 
small piece of health away that is not to worry about. After you get 
out of the trap's path then light up the room with the candle. Now go 
down, and try to avoid the trap's path once more. In this room is more 
Vire and the roars you hear tell you that you are right next to the 
boss's chamber. Kill all of the Vire and push the left block to open 
the doors to the boss's chamber. The boss this time is named Gleeok and 
he is one of the hardest bosses in the game. He blocks the door to the 
Triforce room and he is a large dragon with multiple heads. Later in 
the game he will have 4 heads! For now he only has 2 heads so he won't 
be so hard. Just try to avoid the energy balls that he shoots at you 
and hit his many heads. After a few hits per head, the head will get 
decapitated and float around the room shooting energy balls at you. 
When the heads begin to float, it gets much trickier because there are 
energy balls being shot at you from different directions. Just try to 
focus on the heads and avoid all of the energy balls.  It helps if you 
have full health here. If you do have full health then you can just 
stand in the back of the room and shoot swords at him, avoiding the 
energy balls he spits at you. If you have enough health, you could also 
just whack him like crazy with your sword until he dies but you will 
lose a lot of health and sometimes die that way. It is all in the 
strategy and timing. Once he finally is dead, pick up your heart 
container and go into the Triforce room above you. Pick up the Triforce 
shard and you are 4/9ths complete with the first quest! I would 
definitely save now once you exit Level 4.

To Level 5: 

There are more things which I recommend getting before you go to Level 
5. You should get the last overworld heart container, the letter, the 
red potion, and I would get both some arrows and 100 rupees as well. 
First let's get the last heart container. It is on screen P-6 and it is 
along the Rupee Path. I am sure that you have probably noticed it 
before and tried to get it. Well now is your lucky day because you can 
get it! Just walk over to the water's edge and you can now reach the 
dock because of the ladder. Now walk across the water to get to the 
second dock with the heart container on it! Now you should get the 
letter. The letter is on screen O-1. From where you currently are, just 
go: Up, Up, Left, Up, Left, Up(On the right side), Right, Up. Up the 
stairs you will find a cave with an old man in it. He will give you the 
letter in which you need to get the red potion from the potion lady. 
While you are here there is another point of interest nearby. From this 
screen, go: Down, Right. On this screen you can play a gambling game if 
you want however I don't like to risk it and I suggest to just ignore 
the game. Instead try to walk along the upper wall here. At one point 
in the wall, you can actually walk through the wall and get to the 
hidden screen above it. Enter the shrine on this screen. Inside the 
shrine is a nice Molblin that will give you a whopping 100 rupees! 
After you do these things then I would get the red potion and the 
arrows. With 100 more rupees on you, it should be no problem. Despite 
the fact that you are very close to Level 5, I would just leave 
anyways. Just go back to screen N-3 and continue on the Rupee Path 
until you get back to the beginning on screen H-8. Now from the 
beginning go: Up, Left, Left, Left. Go in the cave here. At first, 
there will be a lady that will not speak at all. Equip the letter and 
show it to her. From that point on, every time you enter the potion 
lady's cave then she will offer to sell you potions. You can buy a blue 
potion I suppose if you want to but I would go with the red potion for 
it is only a mere 28 rupees more. From this point on, I would try to 
always have a red potion on me. You actually don't really need the 
potion as much at this point because Level 5 is not all that hard, but 
you will need it eventually. A good strategy to use with the red potion 
is whenever you are very low in health, to the point where you either 
hear that obnoxious beeping, or around one or less heart, sometimes two 
hearts even, then equip the potion, use it and all if your hearts will 
be restored. Then the red potion will turn to blue and you can use it 
again later. Use it again later when you need it. Then after you use a 
blue potion, you will run out and you should buy another red potion for 
68 rupees. There is also another potion lady right next to Ganon's 
Lair, but I would not worry about that until you actually get that far 
in the game. Now I would get some arrows as they will make Level 5 
easier. Arrows are not mandatory but I still recommend getting them as 
Level 5 will be slightly easier with them so you might as well just get 
them now anyways. Take the Rupee Path and go to screen P-7. Go into the 
cave to see a shop. You can buy arrows here for 80 rupees. Once you buy 
the arrows you will never have to buy them again. When you shoot an 
arrow you lose a rupee, so basically think of it as when you get a 
rupee, you also get an arrow. But don't fret, as you rarely use the 
arrows in this game. Lastly, it would help to accumulate at least 100 
rupees for there is a bomb upgrade that costs 100 rupees in Level 5. 
Just follow the Rupee Path and you will eventually get enough rupees. 
Now you are finally ready to go to Level 5. Level 5 is on screen L-1. 
To get there, you will first have to go to the "Lost Hills". From the 
beginning on screen H-8, take the Rupee path until you get to screen N-
3. From here go: Up(Up the stairs), Left, Left. Now you are in the Lost 
Hills. If you try to go anywhere here besides left you will just end up 
on the same screen so once you enter the Lost Hills from the south or 
the east then there is no way to get back without taking a treacherous 
path all around Hyrule which you don't want to do. Once you are in the 
Lost Hills just continue to go up the screens until you reach a 
different screen. You may have to climb up about four screens but don't 
worry, you will get there eventually. That is the hint that the 
gambling lady behind the waterfall would of told you. Now ignore the 
Armos, kill the Red Leever if you want, but eventually just enter the 
shrine and you will now be in Level 5.

Level 5: 

This is another green colored level and it is supposed to be in the 
shape of a lizard, whether you see it or not, it doesn't really matter. 
Just go right into the next room. In here there will be a hoard of 
monsters called Pols Voice. They look like rabbits kind of with their 
big ears and they hop around, usually in a vertical line. They take 
several hits to kill however if you bought the arrows like I 
recommended in this walkthru then one arrow will take out a Pols Voice. 
Sometimes all or most of the Pols Voices will be lined up in a row and 
all you need to do is just shoot one arrow and they will all die. I 
heard that the recorder which you will get in this level does something 
to them too, but I have never witnessed anything so just stick with the 
arrows. After all of the Pols Voices are dead then you will get a key. 
Take the key, leave to the left and go up a room. You will get your 
first taste of Gibdos in this room after you light it up with the 
candle. Gibdos are basically just mummies. They have a lot of armor due 
to their bandages so they will take several hits even with the best 
sword however pretty much all they do is walk around aimlessly so it 
won't be too tough as long as you use your boomerang to stun them in 
between sword blows. Sometimes the Gibdo doesn't have much resistance 
and is hard to knock back, if at all so beware, however that is not 
always the case. One of the Gibdos in this room is holding a key as you 
can see. Just slay the Gibdos and after you do so the doors to the top 
will open. Ignore those doors for now and proceed to the right but be 
sure to pick up your key that the Gibdo dropped of course. In this room 
is a hint giving old man that says: "Digdogger hates certain kinds of 
sound". Oh, so this Digdogger creature hates it when people drive by 
his dungeon with a bass turned to full blast too! No, not quite the 
case. The hint basically just means that the level boss Digdogger is 
vulnerable to the recorder which you will get in this level. Just leave 
this room and go up. It is not really necessary to light up the room 
again as all you have to do is go up but you can if you want to 
anyways, it doesn't matter either way. You have to cross over a pool of 
lava but I am sure you don't care. In this room are three of the Level 
2's boss Dodongo. If you use the right strategy then it won't be hard 
at all. What I would do is try to have a Dodongo eat a bomb, then when 
he is eating it, immediately place another one down and he will get 
stunned, allowing you to kill him instantly with one sword blow, plus 
he will leave more bombs behind after he dies to boot. Try this method 
for all three Dodongos. Just be careful with your bombs as if you 
happen to run out then it is a real hassle to go get more. After you 
kill the three Dodongos then the doors to the left will open. Go into 
the now open doors to the left. The doors will shut behind you and you 
will have to battle a hoard of Zols. After you kill the Zols then a key 
will appear and all the doors in the room will open. Take the key and 
go down. In here, the doors will shut and you will have to kill a large 
group on Gibdos, one of which is holding some bombs. After you kill all 
of the Gibdos you are probably wondering why the shut doors have not 
opened. No worry, as you have to bomb a hole in the wall to get further 
in the dungeon. When you bomb a hole in a wall, you have to put it 
directly in the middle of the wall in order to make the hole. Bomb a 
hole in both the left and right walls but go left. In this room is a 
hoard of blue Darknuts. If you thought the red Darknuts were hard then 
these will be very frustrating. They are no different than the red 
Darknuts except that you have to hit them several times each to kill 
them which can be hard, especially considering the amount of them in 
this room. Not to mention the fact that they take away a good chunk of 
health when you get hit by them. Just try to keep your distance, and 
try not to be around too many Darknuts at once as then it can be tricky 
to escape when they close in on you. If you run low on health feel free 
to use your potion now. Hopefully, the Darknuts will drop a lot of 
hearts and fairies when you kill them. Use the same strategies I gave 
before with the red Darknuts and you should be fine. After you kill all 
of the Darknuts then push the leftmost block and you can now have 
access to the staircase. Once you go down the staircase you will notice 
that there is no item down there but that this is simply just a 
passageway to another part of the dungeon. Still remember to be careful 
around the usual four Keese here though. Once you arrive out of the 
basement then you will be in a similar looking room as the one that you 
left with two locked doors in it. If you need to go back then you can 
push the leftmost block and when you get to the room where you fought 
all of the Gibdos, remember that you can bomb the right wall here. 
Anywho, in this room with two locked doors, open the door to the left 
first. In here is another hoard of blue Darknuts but fortunately, you 
have a lot more room to maneuver through this time. Use the same 
strategies that I gave before. Once you have finished all of the 
Darknuts off then push the block in the center of the room. This will 
reveal a hidden staircase in the corner of the room. Down that 
staircase is the usual basement with an item in it. This time the item 
is the recorder which has multiple uses, all of which I will explain 
when it comes time to. For now, just watch out for the four Keese as 
usual and when you leave this basement, leave to the right and then go 
down through the locked door. In this room you will find a flock of 
Keese in a room with only a small pool of lava. Kill all of the Keese 
then pick up the key on the floor. Now bomb the right wall and go 
through the hole that the bomb reveals. In this room is an old man will 
sell you a bigger bomb carrying capacity. Even though it is a bit 
pricey at 100 rupees, I would accept the offer for it will come in use. 
Once you buy the bomb upgrade then you will now be able to carry a 
maximum of 12 bombs. Leave this room after you make your purchase and 
then go up. Push the block to gain access to the staircase and enter 
the stairs. Cross through the basement, avoiding the Keese, and when 
you appear on the other side go right. You can ignore the blue Darknuts 
if you want to which I am sure you do. Now go right through the bombed 
hole in the wall ignoring the Gibdos if you want. You will now be in a 
dark room. You don't have to light the room if you want, but you won't 
be able to go up where you want to go until you kill all of the Gibdos 
in the room due to the shut doors. Whatever you do, after all of the 
Gibdos are slain, then go up a room. Now from here go up through the 
locked door, ignoring the Dodongos. In here, lighting up the room will 
not even be necessary as you cant really go anywhere far from the door 
except right in front of you. The map appears in the darkness so pick 
it up and go back down again to leave this room. Now go right and 
ignore the Dodongos again. Light up this room with the candle and once 
you do, kill the Zols scooting around the walkways surrounding the 
pools of lava. After you do all of this, then go up a room. Kill all of 
the Gibdos here to reveal a key. Standing over the pools of lava with 
the ladder and striking the Gibdos from there is a good strategy to do. 
Going left is unnecessary as you got the map in it already which was 
the only thing in it. Instead, just go forward a room. In here, you 
will have to kill three red Darknuts. The room is a system of walkways 
surrounded by many pools of lava. Use this to your advantage and 
station yourself with the ladder over a pool of lava. Whenever a 
Darknut walks nearby, strike it with your sword and two hits will kill 
a Darknut. This will be a hell of a lot easier then any other method so 
I suggest you do it. After you kill the Darknuts then a compass will 
appear which you should take. Now go up a room. In this room is two 
Gibdos, Pols Voices, and Keese. First light up the room with the 
candle, then use the arrows against the Pols Voices, the boomerang 
against the Keese, and stun the Gibdo with the boomerang and then 
strike with your sword as usual. You can use the pools of lava to your 
advantage against the Gibdo which would help a lot. After all the 
enemies are dead then pick up the key they were guarding in the middle 
of the room. Now open the locked door to your left. In here is a room 
full of Gibdos. Use the boomerang and pools of lava to your advantage, 
especially against the ones in the middle of the room behind the pool. 
Now go left a room. In this room you will have to kill a hoard of Pols 
Voice. They are not hard to kill when you have the arrows, so just try 
to line up yourself with them and only a mere few arrows will take out 
all of them. After this, open the locked door to your left to enter the 
boss's chamber. If you want, you can go down in the boss's chamber 
because the door is open and you will be shut inside a Gibdo room. Kill 
all of the Gibdo to open up the doors but you get no prize. This is 
just a trap and is unnecessary to go to. Whatever you do when you enter 
the boss's chamber you will encounter Digdogger which is supposed to be 
a giant land sea urchin if that makes any sense. He pretty much does 
nothing except creep around all over the place so the only way he could 
hurt you is if you touched him. There are statues that shoot energy 
balls at you in the corners of the room however. If you play the 
recorder you got in this level, he will shrink and now he is vulnerable 
to sword blows as when he was big he wasn't. The longer you let him get 
away unharmed, the faster he will run all over the place so I would try 
to attack him quickly and stun him with the boomerang as well. Only a 
few hits will kill him and make a heart container appear. After you 
defeat Digdogger then just go up a room and collect your Triforce piece 
to exit the level. You are now 5/9ths done with the first quest which 
is over half of it! Like after every level, I would save now before 
going to Level 6.

To Level 6:

There are really only two things you need before Level 6, both of which 
you will get when you are around the entrance to Level 6. Your first 
priority is to get past the Forest Maze to west Hyrule. Before you do 
that, if you need another red potion, now is the time to get it as 
there are no potion ladies nearby after you pass the convenient one. 
There is no need to go on the Rupee Path other than to buy a red potion 
as the two things you will get does not require money of any sort. The 
Forest Maze is on screen B-7. To get to the Forest Maze from the 
beginning on screen H-8 go: Up, Left, Left, Left, Left, Up, Left, Left, 
Down. This screen is just like the Lost Hills as when you go anywhere 
but the right path and the direction right then you will run into the 
same screen. There are many blue Molblins on this screen and in this 
general area of the dead woods which are all the woods with red trees 
in it so watch out. Once you do get to the Forest Maze then go these 
directions: Up, Left, Down, Left. Once you go those directions you will 
be in a new screen. Another gambling information lady in a cave nearby 
would of told you the directions as well but that would just be a waste 
of rupees. Once you leave the Forest Maze then go up 4 screens and then 
right one screen. Here you will encounter several new overworld enemies 
all of which are a bit tougher than the ones you are used to. The main 
one to worry about is the Lynal that shoot swords but just kill them 
like you would kill an Octorok or a Molblin and you should be fine. 
Just don't get hit with their swords that they shoot of course for that 
can do some damage. As for the Ghinis, which are the ghosts in the 
cemetery, I would just ignore them for they are just a waste of time. 
Now at the screen where you should be as of now, one of the middle 
graves in the second row can be pushed. You will know which one it is 
as no Ghini will appear when you touch it. If it is the correct grave 
then push the tombstone from the top pushing downwards and enter the 
staircase it reveals. Kids don't try this at home, graves should  not 
be messed with but to be respected, as you don't want to run into a 
goulish zombie visitor, but visiting underground graves happens in 
every Zelda game so just get used to it. In the cave under the grave is 
an old man that will give you your final sword if you have enough 
hearts. You need a maximum of 12 hearts to be exact, which you should 
have by now if you followed this walkthru step by step. This sword 
kicks ass as it can kill many enemies instantly, including some tough 
ones. There will be the occasional toughie enemy out there though that 
will still take a few hits to kill so don't get your hopes up. After 
you get your new sword then I would now go get the power bracelet. The 
power bracelet is not very far away at all on screen E-3. To get there 
from here after you exit the grave go: Down, Right, Right, Up(Take the 
right stairs), Right, being careful around the enemies along the way. 
Now on this screen, wake up the Armos in the top right corner and under 
him is the power bracelet. When waking the Armos be careful though as 
sometimes he runs around very fast and is hard to defeat then. I would 
awaken him from the back then quickly stun him with the boomerang and 
kill him then. The power bracelet infact doesn't do all that much but 
it will still come in handy. The only real thing it can do is open the 
shortcut. The shortcut can be opened in any of the four locations of 
the shortcut and after it is activated it will be activated until the 
very end of the quest. Luckily, one end of the shortcut is simply left 
of this screen, but of course you will need to go down a screen to get 
around the rock wall. On this screen now push one of the four rocks and 
be careful around the Lynal. You have now successfully activated the 
Hyrule shortcut! The four ends to the Hyrule shortcut are on screens: 
D-3, J-5, J-8, and N-2. Just go to any one of those screens and if you 
want to travel quickly across the land then use these shortcuts. Once 
you enter the staircase that the shortcut revealed then you will have a 
choice of three roads to pick from by entering staircases. Certain 
paths lead to certain areas so I will so generously lay out the correct 
paths for you.

Shortcut Paths: 

D-3: Road #1 leads to J-5; Road #2 leads to J-8; Road #3 leads to N-2.

J-5: Road #1 leads to J-8; Road #2 leads to N-2; Road #3 leads to D-3.

J-8: Road #1 leads to N-2; Road #2 leads to D-3; Road #3 leads to J-5.

N-2: Road #1 leads to D-3; Road #2 leads to J-5; Road #3 leads to J-8.

If you are too lazy to read and decipher all of that then just do trial 
and error and you will eventually find the correct path. This shortcut 
system is very useful though as you don't have to trek all the way 
around Hyrule which can take forever sometimes. Before you enter Level 
6, you could use your new shortcut to go near the fairy fountain on 
screen J-4 if you lost a lot of health of this journey. After you do 
this then take the shortcut to D-3 and go: Down, Left, Up to reach 
Level 6. Watch out for the red Lynal here and don't disturb the 
sleeping Armos for they will most likely cause trouble and are 
pointless to wake up anyways. Just enter the shrine and you will now be 
inside Level 6.

Level 6:

You will be in another yellow colored level and the shape of it is 
supposed to be a dragon. Wasn't the last one a lizard? What's the 
difference? Level 6 is one of the hardest first quest dungeons so be 
careful. The red potion will come in very handy in this level. What 
makes this level so hard is the frequent Wizzrobes and the first 
several rooms will be the most difficult so be prepared for trouble. 
First enter the right room. It is a dark room so it would be wise to 
quickly light the room before the Wizzrobes shoot. Once the room is 
lit, you will see the easier version of the Wizzrobe which is the color 
red. Red Wizzrobes will appear in a random location, shoot their wave 
of energy, disappear, then reappear in a different location. Just watch 
where the Wizzrobes appear and get out of the way of their line of 
fire. If you are close enough to one of them then quickly strike it 
with your sword as one sword blow with the best sword will kill them. 
Sometimes if you are lucky, your magic shield will block their waves of 
energy but it can be hard to do so sometimes. Once you kill all of the 
red Wizzrobes then collect the key that appears on the floor and then 
go up a room through the locked door. There will be a hint giving old 
man and he will say: "Aim for the eyes of Gohma". What he means to say 
is that this dungeon's boss named Gohma is vulnerable to arrows as it 
has a big eye that can easily be shot at. Leave the room to the south 
then go left two rooms. This is another red Wizzrobe room, so just use 
the usual strategy to kill them all. If you are lucky then you can kill 
them all with one shot. How you ask? Sometimes in this game in 
dungeons, hitting one enemy will kill all of the other of the same 
enemies in the room. It is not that often that this happens but it has 
happened to me in this room before so it can happen to you too. After 
you defeat the red Wizzrobes then go up a room. This room is a very 
simple room filled with Zols. Kill the Zols and collect the compass 
that appears after you kill them all. Then go up a room. In here is a 
room filled with Keese and statues in the corner of the room that shoot 
energy balls at you. Be careful to avoid the energy balls, kill the 
Keese and the doors above you will open. Collect the key and proceed up 
a room. The next room has three paths of traps to pass through. If you 
run straight forward without halt then you should get to the next room 
safely. Do just that and be prepared for a huge fight in the next room. 
This is one of the toughest rooms in the game. The doors behind you 
will shut and you will not only find Like Likes, Bubbles and red 
Wizzrobes but a new enemy the blue Wizzrobe. The blue Wizzrobe is a lot 
harder then the red Wizzrobes. I would concentrate on the red Wizzrobes 
first as it will make things a lot simpler. Just whatever you do, stay 
far away from the Like Likes and the Bubbles. If you have a good 
opportunity to strike a blue Wizzrobe and/or a Like Like then do so. 
Next, concentrate on the blue Wizzrobes. These Wizzrobes will float all 
over the place and are constantly moving. They shoot at you a lot and 
their magic waves of energy will take away a lot of health. They also 
take about 3 hits to kill. Just try to avoid their line of fire along 
with the other enemies in the room. Lastly you can concentrate on the 
Like Likes which take 3 hits to kill even with the best sword! Try to 
stun the Like Likes in between sword blows with your boomerang. Stay 
away from the Bubble as not only will it take away your ability to 
swing your sword for a few seconds which will render you harmless but 
it can also knock you into a Like Like's path getting rid of your magic 
shield. So just remember that the most important thing to do is to stay 
as far away as possible from the Like Likes and you should be fine. You 
may need to use a red potion in this room if you are not careful. After 
the huge battle then push the left block to open the shut doors and 
advance into the next room. In this room is another Wizzrobe infested 
room, both with red and blue Wizzrobes. You may be able to maneuver 
around the blocks during the fight. Also a good key to remember is that 
the blue Wizzrobes are harmless when they travel through objects which 
you may take to your advantage. After this fight which can be another 
hectic battle you will get a measly five rupees which are totally not 
worth it considering the amount of effort involved. In fact, I believe 
that you could just skip this fight and room if you really desired to 
do so. Whatever you do, go up into the next room eventually. Now the 
last stage in this tough part of the level. You must now fight a three-
headed Gleeok! Luckily you current sword will cut off a head with only 
two hits but that is still 6 hits to kill him altogether. Just watch 
out for the energy balls he shoots and you should probably be fine. 
Also be cautious with your health level as you may need to replenish 
your hearts with a red potion right about now. A good comforting 
thought is that after you kill any boss in this game, most of them 
never reappear again, including this Gleeok here, so if you die, you 
will not have to fight this Gleeok again. After you slay Gleeok then 
advance into the next room that just opened up to the right. In this 
room are two Zols, 2 Like Likes, and two Bubbles. Hopefully if you are 
lucky, then the bubbles and the undesired enemies will be trapped 
behind the pool of lava and will not be able to get you. Plus, if that 
is the situation, you can use it to your advantage and stand over the 
pool of lava with your ladder and attack while still staying out of 
harm's way. After you kill the Zols and the Like Likes, the map will 
appear. Yes, I know the design of the level looks nothing like a dragon 
but what can ya do? Now proceed through the locked door up above. You 
will have to have another blue and red Wizzrobe battle. Thankfully they 
are the only obstacles in this room to deal with. After you kill all of 
the enemies then push the left block to reveal a hidden staircase. Down 
that staircase is the usual treasure in the basement with Keese in it. 
The treasure this time is the magic wand which can be useful if you 
like it. I would use the wand if my sword was cursed by a red bubble 
but you will not encounter those monsters until the second quest. As of 
now, I like the sword better but unlike the sword, the magic wand will 
always shoot energy waves, even if you don't have full health. I 
personally like to stick with my good old boomerang but it is really 
all up to you. With the boomerang, you can stun the toughest enemies 
like the Like Likes. I really recommend to continue to use the 
boomerang. Whatever you do, after you exit the basement, go down a 
room, then right a room. This room is simply a red Wizzrobe battle 
after you light up the room. I would not advise you to go up as the 
doors will shut, leaving you trapped in a room with two Zols, two 
Bubbles and worst of all, two Like Likes. You don't even get a prize 
for defeating the monsters other then an escape so it is simply a trap. 
Instead, go right into the next room. When you go right, you will have 
to fight both blue and red Wizzrobes, Like Likes and there will be a 
Bubble in there too so watch out because it may be tough. After that 
battle, go up through the now open doors. There will be a hint giving 
old man inside which will tell you: "There are secrets where fairies 
don't live". That just explains the entrance to Level 7 which we won't 
worry about until later. For now, exit this room and go left two rooms 
then down another. After lighting up this room with the candle then 
kill the red and blue Wizzrobes in this room. After doing this, proceed 
down a room. This room will be dark so light it up. Then fight the 
Vires in the room. The Vires will be a lot easier this time because you 
can kill them with one hit with your current sword rather then 
splitting them into two red Keese. After killing all of the Vire, the 
doors on your right open so go in them. This next room will be one of 
the last toughie Wizzrobe battles thankfully. There are red and blue 
Wizzrobes, Like Likes, and a Bubble inside. Be very cautious in here 
and do the normal strategy and procedure. After you kill all of the 
enemies then push the block in the middle of the room to open up a 
hidden staircase. The staircase leads to an underground tunnel to 
another part of the dungeon, but watch out for the four Keese here as 
usual. When you emerge from the tunnel you will be in a room with two 
Like Likes, two Zols, and two Bubbles. Kill the Zols first, then the 
Like Likes but stay away from the Bubbles, as they can knock you into 
the Like Likes. After you kill all of the enemies, go down a room. 
Light up the room and kill the three Vire here. If you kill a Vire and 
no Keese appear then the Vire will not reappear when you leave and come 
back. There are also two Bubbles here as well. If you are lucky then 
some of the enemies will be trapped behind the pool of lava in this 
room. After you are done in this room then proceed to your left. Kill 
the red and blue Wizzrobes here but be careful for the traps set at the 
entrance. Go down a room from here. First light the room up and then 
kill the red and blue Wizzrobes. Luckily, there are a lot of pools of 
lava here that prevent the blue Wizzrobes from being able to shoot very 
much as whenever they maneuver over an object they cannot shoot you. 
After you kill all of the Wizzrobes in the room then some bombs will 
appear which may be useful I guess. After this room then proceed up two 
rooms into the bosses chamber through the locked door. This is the last 
boss that you have not seen in the game. It's name is Ghoma and it is 
supposed to be a sort of giant crab like monster with a giant, singular 
eye. It will pretty much move on a horizontal path and shoot energy 
balls at you and that's about it. Simply shoot one arrow at it and it 
will die. If you are not fast enough, then it will shut it's eye 
partially and you will have to wait until it opens it again for it to 
be vulnerable. Aiming is pretty much the key here. If you have a lot of 
rupees then you also have a lot of arrows, but if you are broke or near 
broke then you might have some problems. All it takes is one arrow 
which converts to one rupee to kill Gohma if you are good. When you 
eventually kill Gohma then it will of course leave the usual heart 
container to take and you can proceed into the Triforce room. Take the 
Triforce piece and you are now 2/3rds complete with the first quest! I 
would definitely save after you beat and exit Level 6. Now you must 
travel to Level 7.

To Level 7:

Level 7 is not far away and not hard to get to. To top it off, you 
don't need anything before entering Level 7 which will make is a lot 
easier although it would be wise to get at least 100 rupees and have 
the meat too but I am sure you already have those things by now. Level 
7 is on screen C-5. To get there from the beginning on screen H-8 go: 
Up, Left, Left, Left, Left, Up, Left, and Up. You are probably 
wondering why there is no shrine or anything. Well dungeons don't 
always have to have a shrine built for them as they can be anywhere. 
This is what the old man in Level 6 meant when he said: "There are 
secrets where fairies don't live". The only thing to really worry about 
on this screen is a red Molblin but that is nothing. Here you will 
manifest one of the many powers of the recorder. Normally if you play 
the recorder then a whirlwind will come and warp you to the entrance of 
one of the dungeon's that you have already visited at random. If you 
equip and play the recorder on this screen then the lake will dry up 
and the entrance to Level 7 will be revealed underneath! Now enter 
Level 7.

Level 7: 

Level 7 is yet another green level and the shape of it is supposed to 
be a demon. A lizard, then a dragon, then a demon?! Why are there so 
many freaking reptiles. And I say this because in the instruction 
booklet, the drawing of the demon looks like a dragon. Oh well, go 
figure. Go right a room. In here you will fight two Moldorms which will 
not be hard at all. After you defeat the Moldorms then some bombs will 
appear. Get the bombs and go up a room. Now go up a room to find a 
flock of Keese. After lighting up the room, kill the Keese and 
hopefully you will kill them all with one hit if you kill their 
ringleader first. Unfortunately, you will get nothing but oh well. Now 
go left a room and you will find a hoard of blue Goriyas which should 
not be all that challenging. After you kill them all then you will get 
some bombs but also be careful about the statues that shoot energy 
balls at you as they will continue to shoot even after you slay all of 
the monsters in the room. Now go right two rooms. Kill all of the blue 
Goriyas in this room to open the doors above. Go up a room to find a 
hint giving old man that says: "There's a secret in the tip of the 
nose". That basically means that there is something of interest in the 
room that forms the "nose" of this level's shape which is supposed to 
be a demon. After you receive this hint then go down a room then right 
another room. You will have to fight Level 5's boss Digdogger again 
which won't be hard at all as he was the easiest boss to begin with. 
Watch out for the statues that shoot energy balls in this room. After 
you kill Digdogger then go right a room. Kill the hoard of Stalfos in 
this room. If you are lucky, many Stalfos will be trapped behind the 
pool of water, plus you can stand over the pool of water with the 
ladder and strike the Stalfos as they come near you. One hit with your 
current sword will kill a Stalfos. As you may notice, one Stalfos has a 
key inside of him so after you kill him, pick up the key he drops. As 
you may of noticed, the enemies in this dungeon are not so hard, 
especially considering the very difficult last level. That is because 
this level is counteracted with puzzles involving the fact that you 
need to bomb holes in walls to advance further. So with this in mind, 
go left three rooms and bomb the top wall, lighting the room if you 
need to. Light this room up and then kill the hoard of Stalfos, using 
the pools of water to your advantage if you need to. Pick up the 
compass that the Stalfos dropped and advance left. Kill both the red 
and blue Goriyas in this room and the doors that shut when you entered 
will open if you need to go back. Go left a room. Kill the three 
Dodongos using the good strategy I said for them earlier and all you 
will get is 5 rupees. Go down a room. Watch out for the traps at the 
entrance and kill the Keese in this room to make some bombs appear. Now 
go down a room, being careful around the traps when exiting. Kill the 
ropes in this room and then collect the key on the floor but be careful 
for the statues that shoot energy balls at you. Now go up two rooms and 
go up another room opening the locked door. In here is another bomb 
upgrade for 100 rupees. When you pay you will have a maximum of 16 
bombs to hold which is the ultimate maximum capacity of bombs in this 
game. Go down a room then right, then up. There will be Keese, blue 
Goriyas and some Bubbles in this room and hopefully they will be 
trapped behind the pool of water. After you kill all of the enemies 
then the doors to go up will open, thus you must now go up a room. You 
will now have to fight Digdogger again but this time when you play the 
recorder, he will not only shrink but also split into three but he 
still won't be hard. As usual, the statues in the corners of the room 
will shoot energy balls at you so be careful. From here, bomb the right 
wall. In this room, is two Moldorms in a pit of green sand. Once you 
kill them, you will get a key but that is all. Now from here, go left 
two rooms. Kill the both red and blue Goriyas in this room and maneuver 
around the blocks as a good strategy. Once you kill them all then a 
blue rupee will appear. Open the locked door above. In this room will 
be a red Goriya that will say: "Grumble Grumble" and block you for 
going any further. As it turns out, he is just hungry so if you give 
him the meat then he will disappear forever allowing you to go up a 
room. If you didn't get the meat for some reason, it is in the same 
shop where you bought the blue ring on screen E-4. Once you go up a 
room then you will be in a dark room with two blue Goriyas, Bubbles and 
Keese in it. Kill the enemies to open the shut doors that closed behind 
you and collect the map on the little island in the middle of the room. 
Open the locked door to the right. Kill all of the blue Goriyas in this 
room to open the doors up above. Once you go up a room, kill all of the 
red and blue Goriyas to open the right door and then go right. In this 
room is a hoard of blue Goriyas guarding a key. Watch out for the 
statues that shoot energy balls in here though. After you slay all of 
the Goriyas then go left then down a room. Bomb a hole in the right 
wall here. Even though this room does not appear on the map it is still 
here for some reason and it is the "eye" of the demon. Kill all of the 
red and blue Goriyas in this room then push the left-most block to gain 
access to the staircase. Down the staircase is a basement with the red 
candle in it being guarded by four Keese. The red candle is worthless 
as it just let's you let out more than one flame per screen which you 
never need to do but oh well. After you get the red candle then bomb a 
hole in the right wall and go right. Kill all of the blue Goriyas here 
to make some bombs appear and then go up through the locked door. In 
here is a large room full of sand and two Moldorm. After you kill the 
Moldorm then some bombs will appear which I am sure you have more than 
enough of by now. Just go down and right through the locked door. Now 
you will have to fight yet another Digdogger. This Digdogger splits 
into three and there are those statues that shoot energy balls at you 
in this room as well. After you slay Digdogger then go up a room. In 
here are three Dodongo in a room with the statues that shoot energy 
balls at you. After you kill all three Dodongos then you get some 
bombs. Now bomb the right wall here and go right. You have to kill all 
of the Wallmasters in this room to advance. Just be careful not to let 
the Bubbles hit you as they may push you into the Wallmaster's grasp 
and then you would have to make the treacherous trek all the way to 
this room again. Plus, if they don't push you into the Wallmasters then 
you can't kill the Wallmasters until you can use you sword again which 
is still a hassle. Lure the Wallmasters out of the walls by going near 
the walls, avoiding the Bubbles. You may need to stun them with your 
boomerang which would help a lot. After you slay all the Wallmasters in 
the room, push the middle block on the right row of blocks to make a 
hidden staircase reveal. Go down the staircase and through the Keese 
infested tunnel. When you emerge from the underground then kill all of 
the red and blue Goriyas. If you want to go back then you can just push 
the left-most block here and go back down the staircase. Bomb the right 
wall here and go right into the boss's chamber. Here you will have to 
fight Aquamentus again and he will not be any more difficult than the 
first time you fought him. In fact, he will only take two hits to kill 
rendering him easier than some basic enemies. After he dies, take the 
heart container and go into the next room to obtain the Triforce piece. 
You are now 7/9ths through the first quest and only have one more 
Triforce piece to go! After you emerge from Level 7 you can save if you 
want before trekking to Level 8.

To Level 8: 

You will not need anything to get to Level 8 other than if you need to 
refill your potion or something like that. Level 8 is on screen N-7. To 
get there from the beginning on screen H-8, go: Up, Right, Right, 
Right, Right, Up, Right(At the top), Right, Down. Now burn down the 
lone tree blocking the intersection of paths here to reveal Level 8!

Level 8: 

Finally a normal colored dungeon! This is just a pale stony gray color 
and the level's design is supposedly that of a lion's head. Go right 
first and kill the Zols and Keese in this room but watch out for the 
three Bubbles after you light the room up with the candle. Most enemies 
are only limited to the space on the little islands that they are on 
though. This room is pretty much pointless except for the key so just 
leave it after getting the key and go left a room. You will now be in a 
room where you will fight a Manhandla. Use the same technique you 
usually use but watch out for the two energy ball shooting statues in 
the room as well. Once you slay Manhandla, a blue rupee will appear and 
the doors to your left will open up. Go left into the next room. This 
is a heavily guarded room with two red and blue Darknuts, Bubbles and 
Gibdos. Just keep your distance and use the good strategies that I have 
provided before. After you kill all of the Darknuts and Gibdos then 
push the left-most block to reveal access to the staircase. The 
staircase takes you to the usual four Keese basement with a treasure in 
it. The treasure this time is the magic book which is really not all 
that helpful. All it does is it converts the magic waves that you cast 
with your magic wand into flames so you will now not need to use the 
candle anymore. You can light up rooms, burn down trees, and kill 
enemies a lot quicker and easier now. I still prefer to use the 
boomerang however. I would think with such a thick book that you could 
learn more than one measly spell but oh well. After you get the magic 
book then leave the basement and go right two rooms, then up a room. In 
here you will fight another Manhandla in a pit of gray sand and when he 
dies you will get another blue rupee. Bomb the upper wall and go up a 
room. Fight the mass of blue Darknuts and avoid the energy balls from 
the statues. Now that the battle is done, two doors will open above and 
to the left and a key will appear. Take the key and go right. There is 
a hoard of Pols Voices in here which you will fight after you light up 
the room. A few arrows will get the job done so then you can take the 
compass in the middle of the room. Leave this room, then go left a 
room. After lighting the room up, kill the two Keese, Gibdos and Pols 
Voices and collect the key that appears afterwards. Then go left a 
room. Simply kill the three red Darknuts while avoiding the statue's 
energy balls to get another key then leave and go up a room. Here you 
will have to fight Gohma again in a pit of sand. The only problem is 
that it is blue this time therefore it takes three arrows to kill which 
shouldn't be a problem, especially if you have a lot of rupees which 
you should by now. Now after Gohma is dead, go up a room into the hint 
giving old man's room. He will say: "Spectacle Rock is an entrance to 
death". That means that the landmark known as "Spectacle Rock" on 
screen F-1 is the entrance to Ganon's Lair. You won't need to worry 
about that until after Level 8 though. Just leave this room and go 
right through the locked door. Kill the red and blue Darknuts and 
Gibdos while avoiding the Bubbles, then go up through the locked door. 
Kill all of the blue Darknuts in here to open the right door but watch 
out for the statues as usual. Go up instead and fight the Manhandla for 
the map. After this then go up a room through the locked door. You will 
have to fight another blue Gohma. After you defeat him go through the 
upper door. In here the doors will shut behind you and you will be 
trapped to fight a few red Darknuts. After you defeat them, you will 
get some bombs then leave this room. Now go right a room. In here you 
will first have to fight a few red and blue Darknuts as well as a Pols 
Voice or two. After this battle, push the block farthest to the left 
and go down the staircase. In here is another treasure basement. The 
treasure this time is the magic key which let's you go into any locked 
door in the entire game! You won't be needing keys at all anymore and 
the number next to your keys will simply turn into the letter "A". 
Pretty cool deal, now leave the basement and leave the room to the 
left. Now bomb the left wall and go into the hole. Kill all of the Pols 
Voice in this room to get some bombs then go down a room. Now for a 
bonus room. It has a stockpile of rupees in it which will make up for 
the arrows you wasted on the Pols Voice in the room before this. After 
you collect the rupees then go up, then right, then down two rooms. You 
will probably have to kill the blue Darknuts in this room again so do 
so and advance to the right a room. Kill the Gibdos and blue and red 
Darknuts here while avoiding the Bubbles, then go down the staircase to 
the far right. When you emerge from the Keese tunnel then kill the Pols 
Voices. You can get the key at the corner of the block spiral if you 
want but it won't matter either way now that you have the magic key. 
Whatever you do, just go left eventually. Kill all of the red Darknuts 
here while avoiding the statue's ammo then go up. There will be a hint 
giving old man here that will say: "10th enemy has the bomb." I 
actually honestly do not know what he means here but if you wanna 
figure it out then knock yourself out. It must not be very important 
however, because I can still beat the game easily. Oh well, just bomb 
the right wall to enter the boss's chamber. You will now have to fight 
the hardest boss, a four-headed Gleeok! By now with your current 
health, power, and defense, he should not be too hard fortunately. 
After you beat him, you will get your last heart container and then you 
will have full health! Now go up a room and pick up the last piece of 
the Triforce! That's it, now all you need is to defeat Ganon and save 
Princess Zelda and Hyrule! Once you leave Level 8 then I would 
definitely save before the treacherous journey to Death Mountain.

To Ganon's Lair:

You won't need anything really for Ganon's lair although it would help 
immensely if you had full health and a red potion. Fortunately, there 
is another potion lady right next to Ganon's Lair so you can get that 
there if you need it. To get to Ganon's Lair from the beginning on 
screen H-8 go right two times to the Hyrule shortcut and then take the 
path that leads to screen D-3. From D-3 go: Down, Up(The right 
staircase obviously), Right, Right, Up, Right, Right, Up, Left, Left. 
Now if you need the red potion then go left again and into the cave, 
being very careful for the many blue Lynal. Once you are ready to go to 
Ganon's Lair bomb the left "eye" in the correct spot. The "eye" is the 
large boulder. Watch out for all of the enemies on this screen however. 
Now enter the dungeon of death...

Ganon's Lair: 

The music is not the normal dungeon music. Instead, it is a more "doom-
filled" repetitive tune, which will still probably get on your nerves. 
This dungeon is also a gray color and the design of it is that of a 
skull. One point of interest is that this is the biggest dungeon in the 
entire game so it may take a while. Proceed with caution. First go the 
only way: up. If you have not collected all of the Triforce pieces then 
an old man will prevent you from passing forward. Since you followed 
this walkthru, then the old man should not appear. Go left a room. 
After lighting up the room you will have to fight a hoard of both red 
and blue Wizzrobes that are guarded by a bunch of Bubbles. The Bubbles 
will probably be annoying and get in the way and I suppose you could 
station yourself over the pool of lava but that might be hard to do 
with the blue Wizzrobes so I really don't know what you want to do. 
After you kill all of the enemies then go left a room. Be extra careful 
in this room for there are red and blue Wizzrobes but more importantly 
Like Likes and Bubbles. You don't want to lose your shield at this 
point and it is very easy to get knocked into a Like Like so just be 
extra cautious in here. After you slay all of the monsters then go up a 
room. There will be many more red and blue Wizzrobes in here but 
fortunately the blue Wizzrobes might not have as much room to maneuver 
as there are many blocks in this room. Go up a room after this fight. 
There are simply just a few red Wizzrobes in here and after you kill 
them you get a dinky 5 rupees. Go right a room after the battle. In 
here are more red and blue Wizzrobes, Like Likes, and Bubbles which are 
probably driving you insane by now. Be extra careful in this room as 
well and after you are done with the enemies, go right a room. You will 
now have to slay a hoard of blue Wizzrobes in a room full of sand. 
After this battle, go down a room. There will be two Like Likes, Zols 
and Bubbles in this room. Fortunately there are also two pools of lava 
that divide the room providing you safety from the hazards of the 
enemies. A key will appear in the room after you defeat the enemies if 
you need it but you shouldn't if you followed this walkthru correctly. 
Bomb a hole in the left wall here then go left. In here you will 
actually encounter a new enemy. The red centipedes in this room are 
called Lanmolas. They are the weaker of the Lanmola species. There are 
always two and they zip around the room at high speeds. You have to 
keep your distance here and strike both of them. As the battle goes on, 
they will lose body segments until they are just a head. Once they are 
only a head, then just defeat the head and now you can push the left-
most block to go into the staircase. This tunnel will take you to the 
other side of the dungeon. You will emerge in a room will a large 
spiral built out of blocks. Be very careful for the Like Likes here. 
You will not have much room to move so you must use your boomerang in 
this room. Chuck the boomerang to stun the Like Likes as they advance 
towards you. Strike, then stun again, then strike and continue that 
pattern for all the Like Likes in this room. Once you are done then go 
down a room. Simply kill all of the Vire here, maybe using the pools of 
lava to your advantage and go down a room. Kill all of the Keese here 
for a blue rupee. Bomb the left wall here. After lighting this room, 
kill all of the Gels here. Go up a room. Now you will be on a peninsula 
and witness the most pointless wasted cluster of video game space ever. 
Just go down then right a room. This whole area is like a dead end so 
just go up two rooms then right a room. Kill the blue Wizzrobes after 
lighting up the room. You will need to come here later as well but for 
now just go right. Now time for another new enemy. This time it is a 
floating eyeball called a Patra. You cannot attack the large eyeball 
until you take out the smaller ones. Try to keep your distance but 
repeatedly keep on trying to kill the small Patras. Apparently, the NES 
was not ready for "these advanced kind of things" in video games as the 
small Patra will appear on the other side of the screen if they are too 
far to one side of the screen but I doubt you really care. One good 
thing about the Patra is that typically, whenever you see a Patra, it 
is a sign of the path to Ganon. After you slay the Patra then you will 
get some bombs. Go down from here. Now here is a surprise, you will see 
a room full of Gels, an enemy you have not seen since the beginning of 
the game. Simply chuck your boomerang at them to kill them all. Go left 
from here. You actually can't do anything in this room but there are 
two Zols, Like Likes, and Bubbles in here. Just kill the enemies you 
can reach as most are behind inaccessible walls. You will go to the 
little path in the middle of the room soon. For now, just go right then 
down a room. Kill the Zols and Keese in this room and then bomb the 
right wall and advance into the hole. Kill the Vires in this room while 
avoiding the statue's fire. You will get some bombs and you will have 
to come back here soon as well. For now just go down a room. Kill the 
red and blue Wizzrobes here while watching out for the many Bubbles 
moving about the room. There is a key in the corner of the room if that 
interests you at all but I doubt it does. Just go down a room from 
here. Kill the red and blue Wizzrobes in here but be careful as always 
because by now you probably don't have as much health and blue 
Wizzrobes take out a lot of health when they hit you. A key will appear 
in the room if you care. For now just go up two rooms. Yeah I know you 
have been here before but just bomb the upper wall and continue to go 
up. You will have to fight another Patra in here. Like last time, focus 
on the small Patra then after all of them are gone then kill the large 
Patra. Once the Patra is dead then you will get the map and now you can 
see for yourself just how big this level really is. You are only about 
half done! Just bomb the upper wall and continue up through the hole. 
Be very careful in this room as there are Like Likes, Bubbles, and red 
and blue Wizzrobes. Just think about how much it would suck if you lost 
your shield when you are this far. Hopefully you will get a clock or 
something then you won't have a worry in the world. Even though there 
is no room listed on the map above you, bomb a hole in the upper wall 
anyways then go up. Kill the red and blue Wizzrobes in this room while 
avoiding the Bubbles. After you do this then push the left-most block 
like always and go down the staircase. In this basement you will get 
probably the most valuable item in the game which is the red ring. With 
this ring, the damage you take from enemies will be reduced to a fourth 
meaning it will be really hard for you to die now! Sometimes this thing 
is so effective that an enemy will hit you and you will simply not get 
hurt at all. Talk about effective! That and Link will turn red for the 
rest of the game if that matters to you. After leaving the basement, go 
down two rooms, then left a room watching out for the Gels, then up, 
then left a room. After lighting up the room, you will have to fight 
the blue Wizzrobes again. After the battle, bomb the wall below you. If 
you are lucky then all the enemies will be behind walls and not in your 
path. Whatever the case is, eventually bomb the bottom wall here and go 
down. You are now in the dark room that is the "right eye" of Ganon's 
Lair. Kill all of the red and blue Wizzrobes here to get the compass. 
Now go up two rooms, then right a room. Go up through the locked door 
to get to another section of the dungeon. In here will be a hint giving 
old man that says: "Go to the next room". Simply bomb the left wall to 
go to the next room like the old man said. Kill all of the red and blue 
Wizzrobes in this room then push the left block to reveal a hidden 
staircase. Go through the tunnel at the bottom of the staircase. At the 
other end of the tunnel is a room filled with Zols. After you kill the 
Zols there are three doors to go to. Let's go to the room below. Kill 
all of the red and blue Wizzrobes in this room while avoiding the 
Bubbles then go right a room.(Note, after rereading and editing this 
FAQ later, I am not sure if I meant to say go left at this point. In 
fact, I am pretty sure you do go left but I am not positive. Just go 
into the door that you see for it is the correct path. I am so sorry 
about that.) In here you will have to fight the blue Lanmola which is 
lightning-fast version of the red Lanmola. You will most likely get hit 
a few times but still try to keep your distance and strike the monsters 
continuously until they are dead. After this battle then push the 
farthest left block and go down the staircase. You will emerge into an 
empty room after the tunnel. Go up a room to fight a Patra. This 
Patra's forcefield will not jet outward but move around in an NES 
attempt at 3-D graphics. Just attack this Patra like the other Patras 
and get the key in the corner of the room if you want. Now go right a 
room. Kill all of the Keese in this room to get a blue rupee, yippee. 
Go right a room, then up a room to door #3. Kill the red and blue 
Wizzrobes and the Like Likes here being ever so careful for the Like 
Likes, the Bubbles, and the firing statues. Bomb a hole in the upper 
wall here then go up. The old man in this room will say: "Patra has the 
map". You already know this and already have the map so just leave this 
room and then go down a room again. Now go left two rooms. Push the 
block farthest to the left here as usual and then go down the stairs. 
Go through the tunnel and when you emerge you will be in a Wizzrobe 
room. Kill both the red and blue Wizzrobes and then bomb a hole in the 
upper wall. After going in the wall you will have to fight a few blue 
Wizzrobes and there will be bubbles in the room as well. After the 
fight then push the middle block to the right which will reveal a 
hidden staircase. This staircase leads nowhere but to treasure. The 
treasure this time is the silver arrows and it is the last item you get 
in the game. The silver arrows is the only item that can kill Ganon so 
other than for that use they are just like regular arrows and would be 
pointless. Leave the basement, go down a room, then push the left-most 
block and go through the tunnel. When you emerge from the tunnel, go up 
a room. You will be in a Like Like room so be extremely careful. Maybe 
you can maneuver around the block in this room a way that the Like 
Likes cannot get you as much. When you are done with this room, go up. 
When you go up then the doors will shut and you will not be able to go 
back into this room for a while but that is where you should go for now 
anyways. Now go up a room and the doors will shut behind you. Keep on 
walking to avoid the traps set at the entrance and kill all of the Like 
Likes to advance further. You will now have to fight red and blue 
Wizzrobes, Like Likes and a Bubble(even though you can't kill it, it is 
still in the room like usual). Now you really don't want to lose your 
shield at this point however hopefully if a Like Like captures you, 
then it will not eat your shield as what sometimes happens. Try to 
avoid the Like Likes at all costs anyways. Now go up a room. Kill the 
Patra in this room and go up another room. This next room looks like a 
carbon copy of all the past few rooms when it comes to how it looks but 
this particular room has more blue Lanmolas in it. After you kill them, 
then you will get some bombs. Advance up a room. After lighting up this 
room, kill the Zols and Keese and avoid the Bubbles. Now go right a 
room through the locked door(Why they even bother to have locked doors 
at this point with the magic key and all, I have no idea. Probably in 
case you didn't have the magic key. Oh well, it doesn't matter 
anyways.). This is the last hint giving old man. He will say: "Eyes of 
skull has a secret". He is of course referring to the map's design. One 
eye has a compass in it which you should of got a long time ago and the 
other eye has Princess Zelda in it, which the compass should of 
revealed so this is yet another useless fact. Go down a room from here. 
Kill the red Lanmolas here to get a blue rupee which I am sure you are 
jumping for joy because of it. Now go down a room through the 
pointlessly locked door. Kill the Zols and Like Likes here and be 
careful for the Bubbles. If you want, you can bomb the left wall for a 
shortcut back to a few rooms ago but I would just go right. Kill the 
Gels in this room and get the bombs in the corner of the room. You are 
probably noticing the peninsula at the bottom of the screen. Well you 
been there already, you cannot reach it from here, and it is pointless 
anyways, so just go up a room. Kill the Zols and Like Likes in this 
room but be careful around the Bubbles. Go left a room. Now you will be 
in a room in which you already been in before. If you remember way back 
at the beginning of this walkthru how I said that I am sorry if I seem 
like I am taking you on a wild goose chase then this is what I mean. I 
express my deepest apologies but I just had you take a pointless trek 
around the dungeon while getting nowhere. It would be way to 
complicated to fix it and make this walkthru perfect but I doubt that 
you really care all that much. Since I got you into this mess, I will 
get you out. Follow my directions out now. Go down, then right a room. 
Now bomb a hole in the right wall and go through the hole. Kill or 
ignore the Vire, pick or choose, then go up a room. You will probably 
remember this room. From this point on, you will have to trek through a 
series of rooms you have already been to. Do the same exact thing that 
I said to do before, especially when it comes to enemies but I am sure 
I didn't need to tell you that. You can even just look back in the 
walkthrough if you want but I will just provide directions on how to 
get to where you want to go from here. Go right, up, left. Now push the 
left block after killing the Wizzrobes and go through the tunnel. When 
you emerge from the tunnel, go left, left, up. Now you are back at 
where you want to be. Go right a room. After lighting the room up, kill 
all of the Zols in this room and go up. Kill both the red and blue 
Wizzrobes in here and luckily the blue Wizzrobes can't move around as 
much due to the many pools of lava in this room. Go up a room from 
here. In this room there are red and blue Wizzrobes but watch out for 
the traps set at the doorway. After defeating the Wizzrobes, push the 
left block to reveal a hidden staircase. Unfortunately, a trap is 
covering the staircase so you go to use a strategy here. Walk into the 
trap's path to set it off then quickly run into the staircase while the 
trap is slowly resetting itself. Go through the tunnel and you will 
emerge in a room with red and blue Wizzrobes and traps so be careful. 
After killing the Wizzrobes you want to go to the left side of the room 
which will require the same technique that you used in the very first 
level. You have to set off the traps by walking into it's path then 
when they are resetting themselves, make a run for it to the other side 
of the room. Now bomb the left wall, and use that same technique to 
avoid the traps set over here. Go through the hole and there will be 
two Like Likes, two Zols, and two Bubbles. Be the most careful you have 
ever been around here because these are the very last Like Likes and 
the end of the game is only a few rooms away so you really don't want 
to get your shield taken away cause that would qualify for the most 
frustrating thing to ever occur in a video game ever. After the battle 
then do the usual routine of pushing the left-most block and go down 
the staircase. This is your last underground tunnel. Feel proud as you 
walk through it. When you emerge you will fight your last enemy which 
is a mini-boss Patra. You have battled it several times before so just 
use the same strategy that I told you to use before. Now the upper 
doors will open and you can enter into the final battle! The room will 
appear dark at first but the shine of the Triforce will light up the 
room as Link will hold it over his head when he enters. Then a little 
medley will play and Ganon will appear. There are statues in the 
corners of the room but don't worry for they don't shoot any energy 
balls at you. The image of a skull is on the floor's tile design. Now 
the battle begins! This battle may appear to be difficult being the 
last battle and stuff but in reality it can be very easy if you know 
the right strategy to use. Ganon will be invisible as he moves around 
the room which may make it tough at first. He will always appear in the 
same several places so just pick a spot where you know he will appear 
and swing your sword like crazy. I like to pick the spot right in front 
of the door that leads up. He will be shooting continuous energy balls 
at you which I guess you could avoid if you really cared. With a red 
potion, a red ring and full health, getting hit would not be much of a 
problem now! If you don't care much about getting hit and have those 
three things then by the time the battle is over then you should of not 
lost that many hearts. Anywho, back to the battle. Eventually, if you 
swing your sword many times where Ganon will appear, you will hit Ganon 
and you will know you hit him because he will materialize. Do this 
approximately three times. The fourth time Ganon is hit, he will appear 
and be a reddish brown color. This means that he is vulnerable to die. 
If he goes away after he was the reddish brown color then you can get 
him to appear again, just use the same strategy as before although I 
never let him get away when he is that reddish brown color! Anywho, 
when he is that color, just shoot the infamous silver arrows at Ganon 
and he will explode. That same medley will play as it did when Ganon 
appeared and you will see nothing more of Ganon than a pile of ashes 
with the Triforce sitting on top of them. There will be a brief moment 
of silence until you pick up the Triforce. Now you probably know what 
to do but pick of the Triforce and the door in front of you will open 
while the music starts up again. Go into the last room of the game to 
end this quest! Now the only obstacle between you and Princess Zelda is 
a wall of flames. Simply swing your sword at a flame and it will get 
extinguished. For some reason, the game designers must of thought that 
the flames would be challenging but it seems pointless to me. Anywho, 
just walk forward and thus ends your quest. Enjoy the ending! 

Ending:

A little medley will play and Princess Zelda will say her thank yous to 
Link even though she only says a basic sentence of something along the 
lines of "Thank you Link for saving Hyrule". I think he deserves more 
thanks than that but I guess the NES was not capable of good endings. 
Link and Zelda will then hold up the pieces of the Triforce as the 
game's screen flashes. After this then some happy ending music will 
start to play and a message appears something like: "Peace returns to 
Hyrule thus ends the story." Then a short colorful credits will scroll 
with of course all Japanese names. There are only a few names for some 
reason, only like 5. I would think that there was more people working 
on the game then that but oh well, what can ya do? Now you will see the 
following message: "Another quest will start from here. Press the start 
button. (Picture of Triforce over Ganon's ashes) Copyright Nintendo" So 
you know what to do now. And if you don't know, you should push start. 
You can listen to your victory music for a while if you want now too. 
Now the game will save I think and if you don't think it will then just 
save your game in the second quest but I am pretty sure it will save 
but I would rather be safe than sorry. Now, you will start back at the 
beginning of the game with only three hearts and no weapons. A sword 
will appear next to your name. You have just accessed the second quest. 
If your game got erased or if you don't want to beat the first quest 
then just name your character Zelda and you will be in the second 
quest. The main difference in the second quest is that the dungeons are 
different. I will provide a walkthru for the second quest now. You 
technically just now beat the game but if you really want to beat it 
100% then play the second quest now. Whatever the case is, I 
congratulate you on your successful completion of the first quest of 
The Legend Of Zelda. The End. Game Over.
********************
XII.

THE LEGEND OF ZELDA WALKTHRU~THE SECOND QUEST

Now that you battled your way through the first quest, in order to 
fully beat the game, you should play the second quest which is a bit 
harder. This game is very repetitive compared to the other Zelda games 
so the second quest may seem a bit tedious and boring but it is also a 
lot different so I would at least try it. The overworld is almost 
exactly the same as it was in the first quest. The four main 
differences are this:

#1) Some of the shops are in different caves. I will tell you where to 
go if you need this.

#2) A few of the heart containers are in different areas. For now, I 
will just tell you where to get them when you are ready to get them in 
the walkthru. If I feel it necessary to add them into the first quest's 
heart container list then I shall.

#3) Many of the dungeons are in new areas or different caves. Of course 
I will tell you about this when you are ready for it.

#4) Lastly, just a few of the screens are different. There are actually 
probably two or three screens and they are the ones that were entrances 
to dungeons in the first quest.

With that in mind we shall begin the quest. Seeing as you are more 
experienced by now, the second quest will not take quite as much 
details to get you through it. I will warn you however that I am 
looking at maps from an old issue of Nintendo Power to get through the 
first 6 levels so if I make a few mistakes that is why. Well now, let's 
start, shall we?

*****

To Level 1:

Getting to Level 1 is simple. It is basically the same as it was in the 
first quest. Level 1 is also in the same place. You don't really need 
anything before entering Level 1 although it would help if you have 
bombs and maybe even a shield although those things are not even 
necessary. Just try to get to Level 1 for now then later if you need 
bombs or a shield then I have explained how to get them later in this 
walkthru. After getting your sword in the cave at the beginning on 
screen H-8 go: Up, Right, Up, Up, Up, Left. Go in the hollow tree to 
get to Level 1.

Level 1:

Unlike, the levels in the first quest, these level's layouts are not 
supposed to resemble a specific picture of something although they all 
do anyways. Level 1 is in the shape of a capitol "E". This level is 
very blue if that matters to you at all. In this first room, first go 
right. Kill the red Goriyas in this room then collect the wooden 
boomerang afterwards. Go out of this room and then go up a room. Kill 
the red Goriyas in here while avoiding the statues and go up a room. Be 
very careful in this room as the Stalfos in the second quest will shoot 
swords at you like the Lynals do. They are still not too tough to 
handle but it is always good to be careful around the second quest 
Stalfos. You will get the compass in this room also. Go up a room and 
beware the blue Goriyas as they take several hits with your current 
sword to kill. Ignore going right for now and go up after killing the 
blue Goriyas. Kill the Gels in this room and with a key you have gotten 
earlier in this dungeon, open the door to the right. In here, you will 
have to kill a Dodongo. You will have bombs by now by defeating some 
earlier enemies but if you run out for some reason, you can always 
leave and try to buy or find them in the overworld as they are not too 
hard to get. If you do want to leave the dungeon and buy them in the 
overworld then a few good shops to go to for now would be the ones on 
screens E-5, K-5, and/or P-7, depending on which one seems more 
convenient to you. Some enemies such as blue Molblins and Leevers also 
leave them behind when you kill them in the overworld. Anywho, back to 
the dungeon. After you defeat the Dodongo then go down a room. Watch 
out for the traps and Keese and then get the Map. The room earlier that 
I told you to ignore for now led to this room and going to it back then 
would of been pointless as you couldn't of crossed the pool of water 
without the ladder thus the map would of been unreachable. After you 
have the map then go up then left a room. Go up a room from here too. 
Kill the Moldorm here and it looks like you are in a dead end. Not to 
worry, there is a way further in this dungeon, just not in this room. 
Go down 4 rooms then bomb the right wall from there. Now push the 
farthest left block after killing the Keese and go through he tunnel to 
another part of the dungeon. You will emerge in a room with Bubbles and 
Wallmasters. Be careful for the Wallmasters, just kill them and avoid 
their grip. After going left a room, you will face a room of blue 
Goriyas and statues! This room can be hard with your current lack of 
health and such so if you really have trouble in here, I am pretty sure 
that there is no important item in here so just bomb the upper wall and 
advance through it if you don't care to fight the Goriyas. You will 
simply have to fight an Aquamentus here which will not be hard so do so 
and then go right a room. Collect the Triforce piece and that is Level 
1 for you!

To Level 2: 

Before going to Level 2 it would be wise to buy a magic shield. You can 
buy one at the shop on screen P-7 for 130 rupees among a few other 
places probably too but the one on P-7 would be the most convenient as 
it is on the Rupee Path. You should use the Rupee Path that I provided 
in the first quest to gain many rupees as I am sure you don't have that 
much cash yet. I suppose that is all you shall need for Level 2. Unlike 
Level 1, Level 2 is in a different area than in the first quest. Level 
2 is on screen E-4. It is where the shop with the blue ring was in the 
first quest. Just wake up the sleeping Armos in the middle of the top 
row to reveal the entrance to Level 2 and enter.

Level 2:

This dungeon is in the shape of the capitol letter "A" and it is a 
blue-turquoise color. The level is slightly difficult so it may take a 
few tries. Go up a room as it is the only place you can go. This room 
is full of Gibdos which won't be a problem if you use a good strategy 
such as with the boomerang. Just remember to keep your distance as it 
really helps. After the Gibdo battle, go up a room. Kill the Zols in 
this room then go up a room. Kill the Keese while avoiding the statues, 
then get the key. Go up a room to face a hoard of Gibdos. After this 
battle, go up a room to fight a room full of Keese with statues. When 
you are done here, the doors above will open but first bomb the right 
wall. You can kill the Keese if you want, it doesn't really matter but 
pick up the key whatever you do. After getting the key then go out of 
this room then up into the next room. This is not the Level boss but a 
mini-boss, which is something common in every Zelda game. It is 
Manhandla this time so use the similar strategies you used in the past 
especially with the bombs. Go right a room to face a room of red 
Darknuts. After this fight then go up a room. Fight the Zols then get 
the map when it appears after the Zols are dead. Now go down two rooms. 
You will recognize this room from a few rooms ago and you will probably 
assume you will need bombs. If you have made that assumption then you 
are wrong as this room introduces a new feature: Illusionary walls. 
Just walk up and push against the bottom wall and you will just walk 
right through it! Now go down the staircase at the end of the block 
spiral for the treasure basement with the recorder in it. After getting 
the recorder then leave the basement then go left through another 
illusionary wall. Go down two rooms and forget all about the locked 
door you see in the first room as you will get to that room another way 
in a few seconds. Once you have gone down two rooms then go right 
through the locked door and defeat the red Darknuts in this room. Bomb 
the upper wall and go through the hole. In here is a couple Keese, 
Gibdos and Pols Voices. Since you don't yet have the credentials, i.e. 
the bow and arrow, then you can still kill the Pols Voices with your 
sword but it just takes many hits to kill them. Don't go left as it 
leads back to the room with the locked door I told you to ignore. 
Instead, go right a room. Battle the red Darknuts in this room then go 
down a room. Watch out for the traps and statues, then kill the Keese. 
Go down a room from here. Kill the many Zols sliding around the room 
here then go down a room. Kill the pack of Gibdos then go down the 
staircase to your right. You will emerge in a room with a few red 
Darknuts. After killing all of them, go up a room through the locked 
door into the boss's chamber. You will have to fight a Gleeok in this 
room. He can be very tough so be very careful when battling him. I died 
what seemed like a billion times the first time I fought him as your 
health and stuff is very weak at this stage in the game but you can and 
will kill Gleeok eventually. For one, it helps if you don't get hit at 
all on your trip to Gleeok's room so be very careful and serious on the 
trek to him. Try to stay on one side of the room as far away from his 
heads as possible yet as far up as you can go and shoot swords at him 
while avoiding his energy balls. If you get hit then be very careful 
and go up to him to strike him then run away again and continue that 
strategy. Getting hit here will take away a lot of health which will 
prove to be dire so be very careful. You may also need the red potion 
which is how I beat him. Getting the red potion would require a hell of 
a lot of overworld sidequests so if you don't want to mess with all of 
that right now then just keep trying to kill Gleeok. Don't worry, you 
will eventually kill Gleeok as long as you keep on trying. If you 
really need the red potion then here is how you get it: From the 
beginning on screen H-8 go: Up, Left, Left, Left, Left, Up, Left, Left, 
Down, Up, Left, Down, Left, Up, Up, Right, Up, Right, Right, Up(On the 
right), Right. Awaken the farthest right Armos on the top row to get 
the power bracelet then from here go: Up, Left, Up, Left, Left, Down. 
Push one of the boulders here to open a cave with the letter inside. 
Now the potion is in the same place as it was in the first quest. Be 
very careful for the many tough monsters on this trek as many of them 
are too tough for you with your current status. If you really have 
trouble then just ignore the monsters as nobody is forcing you to kill 
them. Anywho, once you finally defeat Gleeok then go up a room to get 
the piece of the Triforce. I would definitely save the game now 
whatever you do, before attempting to get to Level 3.

To Level 3: 

The time between Level 2 and 3 is a wise time to stock up on goods. You 
should get several things at this point in the game. First off, you are 
weak in power and should get your sword upgrade as you can get it now 
with 5 hearts. The White Sword is in the same cave that it was in 
during the first quest on screen K-1. Next, you need to buy some meat 
as there is the monster that blocks your path in Level 3. You can buy 
the meat on screen P-1. It is the most northeastern part of Hyrule and 
in the first quest it was a secret cave where a Molblin that gave you 
100 rupees lived. You have to walk into the upper wall on the screen 
below it. If you are short of cash then just use the Rupee Path to gain 
the desired amount of money. You can buy the blue ring in this same 
shop later as it is not so vital to have at this point in the game. 
Another good thing to get at this point is a hidden heart container. 
From the beginning on screen H-8 go: Up, Right, Up, Right, Up, Right, 
Up. You should be in the desert. Play the recorder here to open a 
hidden staircase buried beneath the sands. Down that staircase is a 
heart container! Now that you have a little bit more power, I would 
also go get two more things before attempting Level 3. You should get 
the letter and the red potion at this point. I talked about how to get 
them earlier in Level 2. If you have trouble with the monsters on the 
way then simply ignore them for now. On your trek through you can score 
another heart container! When you get to the Forest Maze exit the 
forest maze the correct way and when you exit it go: Up, Up, Up, Up. 
Push down while above the tombstone second closest to the left in the 
middle row to reveal a staircase with a heart container in it! That is 
still not it as you can get yet another heart container now believe it 
or not! Once you pick up the power bracelet then go: Right, Up, Right, 
Right, Up, Left. Play the recorder here to make a staircase appear in 
the ground. The heart container is down the staircase. Now you have a 
whopping 8 hearts! Only four more to get the last sword already! If you 
want, you can access the Hyrule shortcut now as well, as you now have 
the power bracelet. Now once you get all of that out of the way you can 
finally go to Level 3. Level 3 is in the exact same area that level 2 
was in during the first quest on screen M-4. You will need to play the 
recorder here to dry up the pond in order to enter Level 3.

Level 3:

This level is small and simple so it can give you a break from that 
toughie Level 2. This level is a dark blue color and it is in the shape 
of the capitol letter "L" with 2 rooms off separately from the "L". 
With all these letter shaped levels you would think that the game 
designers are trying to spell a message but in fact it is just a 
meaningless jumbled word. To be exact, all the level's designs spell 
out: "EALDZ". What the hell is "EALDZ"??! It is the name Zelda 
scrambled up but I don't know why they didn't just have the level's in 
order of "Z", "E", "L", "D", "A". Then at least it would spell 
something, but who knows, Shiguru is a crackpot anyways. Anywho, with 
that out, go up a room. Kill the hoard of red Goriyas here and then go 
up a room. Kill the herd of Ropes then continue up. You will have to 
fight some tricky blue Goriyas along with avoiding some statues but 
with your current health status it shouldn't be all that hard as it 
could of been. Once this battle is over then get the map and go up. In 
here you will fight a bunch of Stalfos that shoot swords so be careful. 
After this battle then go up a room. In here is that red Goriya that 
says: "Grumble Grumble" from the first quest. Just give him the meat 
like you did in the first quest in order to pass. Once he is gone then 
you can go up into the next room. In the next room is a hoard of red 
Goriyas that will give you the blue boomerang once you defeat them all. 
After this, go all the way down to the room right above the room that 
you started in. From here, go right through the locked door. You will 
be in a room with three Dodongos. This could actually be considered the 
Level boss as it is the toughest enemy in this level but it is not 
guarding the Triforce piece directly so go figure. If you run out of 
bombs then just get more, most likely in the overworld. If you use good 
strategies that I have told you in the past though then you would not 
run out of bombs. Anywho, after the battle, go down a room. Get the 
compass and kill the Wallmasters but don't get grabbed by them or else 
you will have to go back to the beginning of the level. Once you kill 
all of the Wallmasters then push the middle block on the right wall to 
open up the tunnel entrance. Once you emerge from the tunnel you will 
be in a room full of red Goriyas which is actually the level boss. Kill 
the Goriyas, go up a room, collect the Triforce, and save your game for 
now!

To Level 4:

I would get the blue ring before Level 4 as not only is Level 4 pretty 
hard but it is also late enough in the game that getting the blue ring 
now would be a good idea. It will cost 250 rupees, so use the Rupee 
Path if you need it. You may have enough rupees by now anyways if you 
have not bought anything for a while. You should also buy the blue 
candle from the shop on screen G-7 as well. Even after you have bought 
the blue ring and candle, you should still gather up 150 more rupees as 
you will need them for the next level. So with all that in mind, you 
may have to travel the Rupee Path several times. Once you are finally 
ready to go to Level 4 then go to the Lost Hills area on screen L-2. 
You have to push down on the boulder to the far right. I am pretty sure 
you need the Power Bracelet in order to do so but you should have it by 
now anyways if you followed the walkthru. If you need full health then 
keep on going up on the screen L-2 to eventually get to a fairy 
fountain. It also helps to have a red potion for Level 4.

Level 4:

Level 4 is one of the longest and tedious levels of the game. It even 
introduces a new enemy not seen in the first quest! It is a green 
colored level in the shape of the capitol letter "D". Start off by 
going left a room. There are Keese, Zols and Bubbles here and I 
actually don't think there is anything worth while in this room other 
than a key but it is good to explore every room anyways. After this 
room, go right two rooms. You will encounter the last new enemy of the 
game: the red bubble. If you read the bestiary then you may know the 
annoyance of these creatures. They work like regular bubbles, only when 
you get hit, you cannot swing your sword again unless you either go to 
an overworld fairy fountain, drink the red potion, or touch a blue 
bubble. You don't wanna trek all the way out of the dungeon and you 
don't wanna waste a precious red potion so I would go for the blue 
bubbles as there are usually some hanging around. Even if you don't see 
a blue bubble right away, just keep on trying to advance in the level 
and usually sooner or later there will be a blue bubble. These 
particular red bubbles in the room you are in are just there to give 
you a small taste of them and what they do. Even if you do get hit, 
don't worry as the room above this room is filled with blue bubbles. 
Either way go up a room. Touch the blue bubbles if you need to but 
eventually go left. Defeat the Digdogger while avoiding the statue's 
fire then go left. Kill the red and blue Darknuts and the Pols Voices 
here for the compass then go up a room. This next room may be 
challenging as there are red bubbles and red and blue Darknuts in it 
although there is a blue bubble to uncurse yourself if you need it. 
Just try to avoid the red bubbles at all costs and try to maneuver 
around the blocks in order to kill the Darknuts. If you do get hit by a 
red bubble then immediately touch a blue bubble before trying to do 
anything else. After this battle, go right through the locked door. 
Slay the Aquamentus in here then go right a room. Kill the Keese, Pols 
Voices and Gibdos here then push the middle block in the leftmost 
column to reveal a staircase. Down the staircase is a treasure basement 
with the magic book in it. No, you don't get the magic wand for quite a 
while so I have no clue as to why you get the magic book now. Leave 
this basement then go up a room by walking through an illusionary wall. 
Pay the old man 100 rupees for a bomb upgrade then go through the 
illusionary wall to the left. Kill the red Darknuts here then go left 
through the locked door. Kill the hoard of blue Darknuts here then go 
up a room. Kill the Zols while avoiding the traps when you walk in. To 
get to the right door, trigger the traps then run around them when they 
are resetting. In the next room, defeat the Gibdos, Pols Voices, and 
Keese in this room then bomb the right wall. You will be in a secret 
treasure bonus room! Take all of the rupees in this room then go left. 
Go up a room then push the block in the intersection and go right a 
room by bombing the wall. Kill the Dodongos while avoiding the statues 
then walk up through an illusionary wall. Kill all of the blue Darknuts 
here while avoiding the statues to get the map. Go down a room, left a 
room, then push the block and go down. Go left a room then up a room. 
Kill the Zols here then go up a room by bombing the upper wall. Watch 
out for the red bubbles and kill the red and blue Darknuts. Walk 
through the illusionary wall to the right. This room is also pretty 
pointless as you can't get the key that appears until you have the 
ladder later in the game and even then you will probably have more than 
enough keys. But like I said earlier, it is good to explore every room 
just because. Just kill the Keese in this room then go back out to the 
left again. Go up a room through the illusionary wall. A hint giving 
old man will say: "If you go in the direction of the arrow". I honestly 
have no idea what he means by that but anywho just walk right through 
an illusionary wall. Now you will face an extremely annoying part of 
the game. An old man will not let you pass until you give him want he 
wants. Either give him 50 rupees or a heart container. You would have 
to be a damned fool to give away your precious heart container so give 
him the measly 50 rupees to pass. I think you may be able to leave the 
room from how you came if you do not have enough rupees but I am not 
100% sure. Either way, just have 50 rupees on yourself before you enter 
this dungeon. After giving the old man your toll then go right a room. 
If for some reason you are cursed then there are blue bubbles in here. 
Push one of the blocks in this room to open a hidden passageway. I 
believe the block you push is the farthest upper-right one. You will 
emerge in a room full of red bubbles. If you get hit by one of them, 
simply trek back through the tunnel to the blue bubble room but try 
your best not to get hit. Go up a room to fight the level boss 
Digdogger and his armada of shooting statues. After you defeat him, go 
up a room but whatever you do, don't collect the Triforce piece just 
yet! Skip over the Triforce piece and go up a room through an 
illusionary wall. Kill the red Darknuts here while avoiding the statues 
and go up a room again. You will have to fight three Dodongos here. 
After you defeat them all then go up a room.  Kill the red and blue 
Darknuts here as well as the Pols Voices. You can easily maneuver 
around the blocks to your advantage as sometimes the monsters in this 
room will trap themselves in a little corner of blocks. Whatever you 
do, don't go left as it leads out into some other rooms previously 
visited and once you go out then there is no way to get back in and you 
would have to trek all the way around the dungeon to get to that room 
again. Believe me, it happened to me once and I was pissed. Instead, 
push one of the blocks towards the left half of the room to reveal a 
staircase. Down these stairs lies the raft which you will need to get 
to Level 5. Once you get the raft, leave the basement and go down until 
you get to the Triforce room. Collect the Triforce then save the game 
before going to Level 5.

To Level 5:

Before you go to Level 5, buy some arrows at the shop on screen P-7. 
Then after that go up to screen P-4 where the dock is and sail off the 
dock with the raft. Just like the first quest, there is a heart 
container inside the shrine. Now you have 10 heart containers! Finally, 
get a red potion if you need it for Level 5. Level 5 is where Level 4 
was in the first quest on screen F-5 in which you need to sail to below 
from screen F-6 via the raft.

Level 5:

This is the last level in the shape of a letter. It is a yellow colored 
level in the shape of a capitol "Z" or maybe a 2 but most likely a "Z" 
as all the other levels so far have been shaped like letters but who 
really cares anyways. Start off by going up a room and avoid the traps 
set at the entrance. Kill the Zols and go left. Be very careful not to 
get caught by a Like Like and avoid the traps. Go down a room and kill 
the annoying red and blue Wizzrobes. Go left through an illusionary 
wall and kill all the Keese in here. You probably get a key or 
something, I don't know for sure as like I said in the beginning of 
this walkthru, I am looking off of a Nintendo Power map. Anywho, after 
you are done with whatever in this room, go right then down the 
staircase. You will emerge in a block spiral room with blue Wizzrobes 
in it. Hopefully the Wizzrobes will spend too much time mindlessly 
floating through blocks and not hitting you but that is up to the game. 
Push the middle block on your far left and go right. Remember to push 
the block from the left or else your path will be blocked. Just ignore 
the blue Gohma as you don't have your bow yet. Go down a room and then 
into the staircase, avoiding the red bubbles. Get the bow in the 
basement and then up a room. Now you can kill the blue Gohma. After 
Gohma is dead, go left and down the staircase. After emerging from the 
tunnel, go up a room, then left a room, avoiding the traps and Like 
Likes(Or killing the Like Likes preferably). Kill the Vire in this room 
and get the map. Go up a room and defeat the red and blue Wizzrobes 
while watching out for the red bubbles. Go up a room again to fight 
more red and blue Wizzrobes. Go right into a pitch black room. You will 
see the eyes of dark monsters. The monsters are easy Zols so just kill 
them where you see their eyes. Go up a room to fight Like Likes and red 
and blue Wizzrobes. Don't even worry about the key behind the pool of 
water as you don't need it. Go right a room to fight a Manhandla in a 
room of sand. Go up a room and kill the many Keese. Go down the 
staircase at the end of the block spiral. After emerging from the 
tunnel you will have to kill several Vire. Go left through the locked 
door and defeat the three-headed Gleeok. Since Gleeok is pretty tough, 
you should have a red potion handy. Go up a room and get your Triforce 
piece! Now save the game.

To Level 6: 

You should get two things before attempting Level 6. First you must get 
the magic sword which will prove to be very helpful which is on screen 
J-1. To get this from the beginning of the game on screen H-8 go into 
the Hyrule Shortcut. Go to screen D-3 then from here go: Down, Up(On 
the right side, where else?), Right, Right, Up, Right, Right, Up, 
Right, Right. This will look like a dead end but it is really where you 
find the magic sword. Push around many of the boulders, pushing one of 
them will reveal a staircase with the magic sword inside, that is if 
you have 12 hearts which you should right now if you followed the 
walkthru. Secondly, you should get the Red Potion if you need it for 
Level 6. Now that you are prepared, Level 6 is in the cemetery. 
Wherever you are right now just warp to screen D-3 via the Hyrule 
shortcut as it is near the cemetery. Now from screen D-3 go: Down, 
Left, Left, Left. Play the recorder to make one of the tombstones 
disappear. Underneath it will be the staircase that leads to Level 6!

Level 6:

This is the last level that I have the luxury of looking at a map 
provided by an old issue of Nintendo Power. I have no clue as to why 
they didn't have the maps to Level 7, 8, and 9 in it only that they are 
idiots. Maybe they ran out of room, however for some reason, they have 
plenty of room to babble about how there was a Nintendo cameo in an 
episode of Full House and Growing Pains later in the issue, which I am 
sure nobody gave a damn about, so go figure. Anyways back to the 
walkthru. This level is a yellow level and it's shape is not a letter 
or anything like the last 5. The shape could be viewed as a 
psychologists ink blot test or a cloud as it is no real pattern. To me 
it kind of looks like Link's hat sideways but who knows. Oh well, it is 
no big deal anyways. Go up a room first. Kill the many red and blue 
Wizzrobes floating through blocks and proceed up. Kill the Like Likes 
and red and blue Wizzrobes then go left. Kill the Vire and go left. 
Kill the red and blue Wizzrobes and Like Likes in this room and go up. 
The old man in this room says: "South of arrow mark is secret". I 
honestly don't know what he is talking about but oh well. Leave this 
room below then go left. Watch out for the traps then push one of the 
blocks on the far left. Strategically maneuver into the staircase and 
get the ladder in the basement. Now leave the basement and go right 2 
rooms. Go down a room and get the key on the island in the pool of lava 
with the ladder but watch out for the bubbles and the red and blue 
Wizzrobes. Go up a room, then right a room. Bomb a hole in the upper 
wall and go through the hole. Watch out for the bubbles and kill the 
red and blue Wizzrobes and then go left. At first, keep on walking to 
avoid the traps but stop when you are over the pool of lava as there 
will probably be a Like Like on the little island. If you are brave 
then you can cross the pool to the island and battle the Like Like or 
you can just wait until it wanders in front of you and strike if you 
are patient enough. Once both Like Likes are dead then walk up through 
the illusionary wall. Watch out for the red bubbles and kill the red 
and blue Wizzrobes. If you are lucky, all or most of the monsters will 
be trapped behind the pool of lava but if they are not then you can 
position yourself over the pool of lava and strike the enemies from 
there. Either way, when you are done with this room, cross the pool of 
lava and bomb the right wall. When you go into the next room, pick up 
the compass and kill the Keese if you want to. The path you see in the 
middle of the room can be accessed but it is pointless to go through 
and will not be taken on this walkthru. Instead, leave to the left and 
then go up a room. Kill the Vire and cross the pools of lava and go up 
to the next room. Kill the red and blue Wizzrobes while avoiding the 
statue's fire. Go right and kill all of the red and blue Wizzrobes. 
Cross the narrow part of the pool of lava and go down. Just ignore the 
key on the little peninsula as even I don't know how to get it and it 
is worthless as you will have more than enough keys anyways. I don't 
remember exactly which one but push one of the blocks in this room. I 
think it may be the block in the middle row on the far left. Go down 
the staircase that the block reveals and then through the tunnel. You 
will emerge in a block spiral room filled with Keese. Kill the Keese 
and travel around the block spiral to the door on the right. When you 
go into the next room you will experience a very difficult task. You 
will now have to fight three bosses back to back! If you have full 
health and a red potion not to mention the amount of skill it took to 
get this far already, it won't be too tough. The first boss is a 2 
headed Gleeok which should not be too hard with your current skill. 
After killing him and going into the next room be super careful as it 
has red bubbles in it! Even if you do get hit, you will notice that 
there was a room with blue bubbles in it before the tunnel that took 
you to this section of the dungeon but it is a hassle to go back and 
forth so just be on your best alert. Push one of the blocks, I think it 
may be the left block on the bottom but I am not sure. If it is not 
that block then try another block as there are 4 blocks altogether so 
it should not be too hard if I am wrong. When the staircase appears, go 
down it and through the tunnel. When you emerge you will fight the 
second boss, a Manhandla. He should not be all that hard so just use 
the previous strategy to kill him and go up a room. Now you are at the 
third and final boss, a blue Gohma. Simply shoot your arrows to kill it 
and then advance into the next room to get your Triforce piece! Now 
save your game of course and you are now ready for Level 7!

To Level 7:

There are two things you should get before going to Level 7. First you 
should go to screen P-6 via the Rupee Path. You can get that same heart 
container on the dock with the ladder that you got in the first quest. 
That is all the overworld hearts in the entire game, you now have them 
all! You should also have a hell of a lot of money before going into 
Level 7 as there are a few rooms in it that you must have a lot of cash 
for. Infact, I would even go as far as saying to get a maximum of 255 
rupees as you may need every last rupee you can get. If you have extra 
rupees left over after Level 7 than you will still have money at least 
not to mention, 255 rupees is a bit exaggerated but I would rather be 
safe than sorry. Lastly, it would be wise to buy a red potion if you 
need it before attempting Level 7. Level 7 is on screen M-7. It is 
hidden under the thicket of the forest. To access it, you need to be on 
the right part of the screen. You will notice that there is a row of 
trees that divides the screen and prohibits you from going to the left 
part of the screen. At the top part of the row of trees that block your 
path is one tree that sticks out on the right and then above that tree 
is just the thick forest. Go to the right of that tree and face left. 
Now from here, use the candle and the tree that the flame lands on will 
burn up revealing Level 7. It is a process that is difficult to explain 
but just use trial and error and follow the walkthru the best you can 
and you will have no problem finding Level 7. To get to the staircase 
that was revealed you have to go all the way around a few screens back 
to the left side of this screen of M-7.

Level 7:

Now I know I have said this multiple times before but I am going to say 
it again: From Levels 7-9, there are no maps for me that I usually look 
off of so writing this walkthru for those levels is kind of like trial 
and error and so if you go on any sort of wild goose chase, then I 
apologize and I will try my best to have the most simple walkthru for 
the rest of the game. With that out, welcome to Level 7. It is a gray 
colored level and it's shape is that of a sort of spiral. Start off by 
going to the room to your left. Watch out for the traps set at the 
entrance and kill the two Zols. Take the compass sitting in the trap's 
path but don't let the traps get you. There is a hidden staircase in 
this room but don't even go through it as it takes you to a dead end 
filled with red bubbles. It is there only for you to escape the red 
bubble room if you entered it later in the dungeon. Instead, leave this 
room and go right a room. Kill the red and blue Darknuts here and the 
Pols Voices while avoiding the statues then go right. Light up this 
room, then kill the red and blue Darknuts. To avoid the red bubbles, it 
would be wise to situate yourself over the pool of water and strike the 
Darknuts from there. Hopefully all of the red bubbles will be on one 
side of the pool of water. If you get hit, simply touch the blue bubble 
and try again. After this battle, go right a room. Kill the red and 
blue Darknuts and Gibdos in this room while avoiding the bubbles. Push 
the third block from the top on the left wall that jets out diagonally 
to reveal a hidden staircase. After you go through the tunnel, kill all 
of the Keese and go down a room. Kill the red and blue Darknuts and 
Pols Voices, then push the middle-left block to reveal a staircase. 
Down these stairs is a treasure basement with the red candle in it. As 
you know, the red candle is not very useful but oh well. Now leave this 
basement, go up a room and then push the block farthest to the left. Go 
through the tunnel and then go right. Kill the Manhandla in this room 
and then push the farthest left block to open the doors to the next 
room then go into the next room. Light up this room then kill all of 
the red and blue Darknuts while avoiding the red bubbles. Use the pools 
of water to your advantage and stand over them to strike the Darknuts. 
Now after this, go up a room. Light up this room then use the pool of 
water to your advantage and kill the red and blue Darknuts while 
avoiding the red bubbles. After this battle, the map will appear. Take 
it and go up a room. Kill all of the blue Darknuts in this room while 
avoiding the statue's fire and you will get a blue rupee and the doors 
above you will open. Just be glad you have your powerful magic sword to 
kill the several blue Darknuts with only two hits! Now go up a room. 
You will be in another room full of blue Darknuts to defeat and statues 
that shoot at you. Kill all of the Darknuts and go up a room. Finally a 
room with no Darknuts only instead it is a blue Gohma. Kill the Gohma 
while avoiding the statue's fire and then go up a room. Kill the Keese, 
get the key and push the block to the far left to reveal a staircase. 
Go through the tunnel, avoiding the traps and when you emerge on the 
other side, kill all of the blue Darknuts. If you want, you can push 
one of the blocks in this room to go back through the tunnel. The next 
several rooms are there solely to piss you off but just go where I go 
anyways. Go up a room first. This is one of those annoying block 
intersection rooms. Push the block up and go left. You will have to 
kill a huge amount of Gibdos in this room, talk about night of the 
living dead! Go down through the locked door. This room is a trap 
apparently as all you get is a fight with a hoard of blue Darknuts. 
After they are dead then go up a room. Whatever you do, don't go up a 
room, as it will only take you into a room of red bubbles and a dead 
end that leads back to the beginning of the level. Instead, push the 
left block to reveal a staircase. After emerging from the tunnel you 
will see yourself in a familiar room. I guess that was not the right 
way to go. Oh well, no sweat. Just go back to the room with the block 
intersection and go right this time. You may have to fight some of the 
enemies again along the way, sorry. You will be in that mean old 
scrooge's room that makes you pay a toll, you know, the same guy that 
was in Level 4. This is why you were supposed to bring rupees along 
with you to Level 7. Obviously, you will pay in cash, not life! After 
you pay this man, go up a room. You will have to fight a Manhandla and 
only get a blue rupee as your victory prize, looks like another dead 
end. Just go back a room and then go down a room. Whatever you do, 
don't go left then up because you will have to pay another toll and the 
toll booth leads to a dead end with red bubbles so don't go left unless 
you like to waste time and money for some reason. Kill all of the blue 
Darknuts then push that third block towards the top on the left 
diagonal wall to reveal a staircase. After going through the tunnel 
that the staircase revealed you will be in a bit of a tough room. You 
will have to kill red and blue Darknuts and avoid red bubbles at the 
same time. Maybe you will strike lucky and get a clock or something. 
When you are done in here then go left through the locked door. With 
this room, you will have probably had all you can take with Darknuts 
but thankfully this is the last Darknut room of the level as it is the 
pre-boss room. Kill the blue Darknuts then go left to face the boss 
which is a giant blue Darknut! Haha, just kidding, it is actually 
worse, as it is a Gleeok, which besides, I don't think the game would 
have enough memory to have a giant Darknut. This Gleeok has four heads 
so it is a bit tougher. Use the usual strategy and it helps if you have 
a potion, but if you don't, maybe you are skilled enough by now to take 
it on with only a few hearts like I did. After the fight, get the 
Triforce piece, and now only one more Triforce piece stopping you from 
Ganon! Save the game now of course.

To Level 8:

The only three things you should get before going to Level 8 is some 
meat, 100 rupees, and a red potion if you need it. Other than that, you 
need nothing else. Level 8 is in a very unusual spot and if you had no 
walkthru then it would be virtually impossible to find. Level 8 is on 
screen J-2. To get there from the beginning on screen H-8, go: Up, 
Right, Up, Up, Up, Up, Left, Up, Right, Right. Level 8 is in a cave 
behind a bombable wall. You see the wall of mountain above you? If you 
look carefully, you can notice that it is divided by little squares as 
that is how they programmed it back in the days of the early video 
game. Well if you notice these squares then try bombing the fourth or 
fifth square from the left to find Level 8. If you have no clue as to 
what I am talking about, try to use good judgment and bomb more towards 
the left part of the screen. Yes, I know it is awkward standing over 
water to do this, but you have to do it. Anyways, once you find the 
correct plot of wall, then bomb the wall then go in the hole into Level 
8!

Level 8:

Back to a green colored dungeon, this level is shaped also like a 
spiral only it is a different shaped spiral. Go up a room. This room is 
filled with red bubbles. You don't want to get hit as I don't know 
where any nearby blue bubbles are right now. If for some reason you did 
get hit, there is a fairy fountain nearby the entrance to Level 8. From 
the entrance, just keep on going right until you get to the Lost Hills 
then keep on going up until you get to the fairy fountain, you can't 
miss it. Anywho, avoid the red bubbles and push the block. After 
emerging from the tunnel, kill the red Goriyas and go down through the 
illusionary wall. Ignore the Dodongos for now and go right. Kill the 
blue Goriyas and Keese in here, then bomb the bottom wall and go down. 
Kill the blue Goriyas in here and then get the map. Go up a room and 
push the middle block in the left-most row of blocks to reveal a 
staircase. After emerging from the tunnel you will be back in a 
previously visited room. I would have you go down a room but I would 
eventually take you to a room where you need a key and you have no more 
keys at this point if you followed the walkthru. The irony is enough to 
kill that the one time you actually need a key, you have none. Oh well, 
we will get one later in the level. For now, just go up two rooms then 
push the farthest left block and go through the tunnel. I will be 
honest at this point. Due to my lack of organization and experience at 
walkthrus, I wrote this walkthru, jumping back and forth through parts 
of it when writing it, especially in this level so that is why if I 
make dumb mistakes. If things get too confusing then try your best to 
get past it. If you are really stuck then e-mail me although I honestly 
don't think it should be too much of a problem, I wanted to warn you 
anyways and I apologize for the inconveniences caused by me. Anywho, if 
you are in a part of the dungeon that you have not been to before and I 
don't explain it then look later in the walkthru for the guide through 
it. From where you currently are, go up through the illusionary wall 
and push the block in the intersection up. Now go right a room. Kill 
the Ropes here, push the block, then go through the tunnel. Kill the 
Moldorm and bomb the right wall and go through the hole. Kill the three 
Dodongos for a key. Good, now you can finally access the desired area 
earlier! Go left then down two rooms. Kill the three Dodongos in this 
room then go down through the locked door finally! Watch out for the 
Wallmasters and red bubbles in here. After killing the Wallmasters, 
push the middle block on the right row of blocks and go down the 
staircase that appears. Get the magic wand in the basement and then 
when you leave, go up two rooms and then push the block to reveal the 
staircase. Go through the tunnel and up a room, while avoiding the red 
bubbles. In this room is a hoard of flashing Ropes. I honestly have no 
idea as to why they are flashing. They are probably the "new and 
improved" more powerful Rope of the second quest yet they seem the same 
to me other than that they are flashing. Oh well, just kill them all 
and go up a room. Kill all of the blue Goriyas, cross the pool of 
water, and go up a room. Kill the Digdogger and go up a room. Give the 
Goriya the meat to make him go away then go up a room. Light the room 
up, but keep on walking as to avoid the traps. Kill the Keese to get 
the compass then cross the water and go to the next room. Kill the blue 
Goriyas while avoiding the statues and then get the key and go left. 
Kill all of the blue Goriyas, then go into the next room on the left. 
Kill the Digdogger then bomb the left wall and go through the hole into 
the next room. Cross the pools of water as to avoid the red bubbles and 
go through the locked door on the left. If you need bombs, some 
Wallmasters will come out if you are close enough to the walls and when 
you defeat them all, bombs will appear. You can hang over the water to 
attack the Wallmasters if they come after you. Kill the three Dodongos 
in this room and go left. Unfortunately, the Dodongos will reappear 
sometimes if you come back to this room later for any reason. In here 
is a hoard of red bubbles and a key. Take the key and push the middle 
left block to reveal a staircase. Don't worry if you get hit by a red 
bubble as there is a blue bubble at the other end of the tunnel so the 
only enemies you would have to face is the usual 4 tunnel Keese and you 
can just ignore them or kill them with your boomerang. There are 
Wallmasters in here but killing them is only important if you want to 
go back through the tunnel. If you want to kill them then just get near 
a wall but be careful for the red bubbles. After the Wallmasters are 
dead then push the middle block on the right wall of blocks to reveal 
the staircase. Other than this, go left a room. Kill the Stalfos in 
here then push the third block from the top on the left diagonal wall 
of blocks to make a staircase appear. Down the stairs is a basement 
with the magic key in it. After getting the magic key, leave the 
basement, go right, then down. The doors shut behind you as you are in 
a block intersection room. Push the block and go left as it is the only 
place you can go. Kill all of the Ropes here and then walk down through 
the illusionary wall. Kill all of the blue Goriyas and Keese here while 
avoiding the bubbles then go right a room. Kill the Keese and then walk 
through the narrow path across the room and into the locked door on the 
right. Kill the blue Goriyas for some bombs. If you don't have full 
health and cannot shoot swords then the Goriyas stuck behind the blocks 
are a pain in the ass to kill. Just try to use to candle or magic wand 
or something, or strike them through the blocks if you can. Once the 
Goriyas are finished, push the block farthest to the left and proceed 
down the staircase. Kill the Moldorms in here and bomb the bottom wall 
and walk through the hole. Kill the red and blue Goriyas and then go 
down a room. Kill the Aquamentus and then go left a room. Warning: 
Watch out for the Wallmasters in this room as you are too close to the 
end of the level to get caught and go back to the beginning of the 
level now. Trust me, it happened to me and it almost blew up my piss-
me-off meter. This may be a hard feat to do, but if you can, try to get 
into the open space in the middle of the room and then attack the 
Wallmasters. After all of the Wallmasters are dead push the middle 
block in the right row of blocks to open the door, then go left. In 
here is an old man that will sell you a higher bomb carrying capacity 
for 100 rupees. Obviously you want to accept the offer. After you buy 
more bombs, go right two rooms, then up three rooms. In here you will 
simply fight three Dodongos. After this battle, get you last heart 
piece and go up a room to get the last Triforce piece! Now only one 
more level until you have fully beaten the entire game! Save of course 
before you do anything.

To Ganon's Lair:

You won't need much for the last level but keep in mind this is the 
absolute last time you will be in the overworld so stock up and make it 
worthwhile. Get a red potion if you don't have one as you will 
definitely need it. Other than that, you are pretty much prepared to go 
to Ganon's Lair! Ganon's Lair is in the farthest northwest corner of 
Hyrule on screen A-1. To get there from the beginning on screen H-8, 
warp to screen D-3 via the Hyrule shortcut then go: Down, Up(Right 
side, Sherlock), Right, Up, Left, Up, Left, Left, Left. Again, like the 
entrance to Level 8, if you can see the squares that divide the 
mountain wall, then the bombable wall to Ganon's Lair is about four 
squares from the left. If you don't know about the squares then just 
try bombing around the middle-left part of the upper wall. Now enter 
the very last level of the game with caution and beware the doom it 
beholds...

Ganon's Lair:

The level will start off like Ganon's Lair in this first quest, all 
with the music and the gray color and everything. The shape of this 
last level is a huge 46 room Ganon head making it one of, if not the 
largest levels in the entire game. Go up into the next room first. The 
old man that would normally prohibit you from advancing is not there 
because you have the Triforce now. From here on, it is like trial and 
error for me to write this last challenging level so bear with me. It 
should not be too much of a problem as I did pretty good at all the 
other levels. First go left a room. Light up the room then kill the 
superfast blue Lanmolas for some bombs. Go left a room. Holy shield 
eater Batman, a room full of Like Likes, statues and traps! Just kill 
them all and go left. Simply kill the Vire while avoiding the statues 
for 5 rupees and then go up through the locked door. Kill all of the 
Keese then go left. You will have to fight a pair of red Lanmolas in a 
statue room and you will get bombs as your prize. Now go up a room. You 
will be in a room full of red bubbles. Just don't get hit like I did 
while making this walkthru because if you do, I have no idea as to 
where blue bubbles are at this time. Bomb the right wall and go through 
the hole. It is one of those block intersection rooms, and this is not 
the only one in this level unfortunately. Push the block ahead and go 
up as going down would uselessly take you to a previously visited room. 
Kill the red and blue Wizzrobes here while avoiding the traps set and 
then go right a room. You will have to kill more red and blue Wizzrobes 
while avoiding statues and red bubbles. Thankfully there is a blue 
bubble in here to rejuvenate you if you need it. You will get a useless 
key but who cares. Just go right a room. In this block intersection 
room, push the block ahead and go down through the locked door as it is 
the only way to go. Kill the red Wizzrobes to open the door to the 
right then go right. Ah, a Patra, which usually signals you are going 
the right way. Even if you are going the right way, I am going to make 
you explore the whole dungeon regardless as it is a wise decision. Oh 
well, just kill the Patra and go down a room. Avoid the traps, light up 
the room, kill the Zols and go down a room. You are back where you 
started so we are going to fill in the gaps of the rooms you missed 
that you will notice if you look at the map. Go left again. Who cares 
about light, just go up(and light the room if you do care). You just 
get a battle with some red and blue Wizzrobes, so I guess you should 
not of gone up. Just go down again, then left, then up again. Looks 
like another pointless red and blue Wizzrobe room. So I guess the room 
above is also inaccessible from this room as well and we will have to 
find another way. Ok, just go down, then left, then up, then left to 
gain access to the other part of the block intersection. Now go back in 
the block intersection room, and go up, then right, then bomb the wall 
down. There will be a hoard of Zols that are camaflouged due to the 
dark background and when you kill them you get the compass. From here 
go right, right, down, down, to get to the main entrance again. Now go 
right a room. Light up the room then kill the red and blue Wizzrobes. 
Now go right a room. This room is a dead end with Statues, red and blue 
Wizzrobes and even worse, Like Likes in it so don't even bother with 
it. Assuming that you do complete this pointless room, go left again. 
You can go up but it is a pointless room with Keese so don't even 
bother. Instead, go left, up, up, bomb the upper wall and go up once 
more. Yet another block intersection room! Push the block up and go 
right. Now there is no turning back from as far as I can see. Watch out 
for the red bubbles in here. There is a hidden passageway in here but 
ignore it for now as I don't want to go there at the moment. Instead, 
go up a room. By now you must despise the block intersection rooms as 
there is another one. Push the block up and go left. Yep, definitely 
time for a mass murder at Nintendo Headquarters as there is another 
block intersection room and this one is all red for some reason. Push 
the block and go up a room. Be extremely careful for the dozen red 
bubbles in here and go right a room. Oops, another pointless room of 
red and blue Wizzrobes, sorry. Now go left, down, right(to gain access 
to the other part of the block intersection), left, down, then right. 
Now push the left block to gain access to the tunnel. When you emerge, 
kill the red and blue Wizzrobes then go right. Now you are back in the 
room you came in. Go up, up, then right through the illusionary wall. 
Light up the room and kill the Keese. A blue rupee will appear in an 
inaccessible area but I doubt you care anyways. Just walk through the 
only available path set out and walk through the illusionary wall on 
the right. Kill the red and blue Wizzrobes then bomb the upper wall and 
go up. You must be on the right track as you will have to fight a 
Patra. After killing the Patra you will get the map. Go left through 
the illusionary wall. Kill the red and blue Wizzrobes in here then push 
the block to reveal a staircase. In this basement is the silver arrow 
needed to slay Ganon with. Leave the basement then go right through the 
illusionary wall. Don't go up as it will put you in a room with Vire 
and the doors behind you will close and not open so you will have to 
trek all the way back to this room through the dungeon. Instead bomb 
the right wall and go into the next room via the hole. Kill the Zols 
and Like Likes while avoiding the bubbles and statues and go down 
through the illusionary wall. Kill the red and blue Wizzrobes here then 
push the left block of the blocks in the middle of the room to reveal a 
staircase. Go through the tunnel down the staircase to emerge in a room 
full of blue bubbles and the thick stone wall to your right has Zelda 
behind it but unfortunately this is not the entrance to the room that 
holds her. This room seems to be pointless as there is no way out other 
than the way you came in. So just push the block to go back through the 
tunnel. For a little bit, you may do some mindless wandering while I 
try to find the next room to go to in this walkthru. But I am pretty 
sure where it is so don't fret. Well with that out, go left. Kill the 
red and blue Wizzrobes in here and go down. Go left twice to get back 
to the main entrance hall. From this point, until we get to a new area, 
just kill any enemies you see if you want or have to. I don't know 
which ones will appear as I took a break when in the middle of this 
walkthru by turning off the game so all the enemies will reappear for 
me but maybe not you. Ok well, just go left three rooms. Now go up two 
rooms. Push the block, go left, then back in the room, then push the 
block and go up then right. Bomb the wall here and go up. Kill the 
hoard of blue Wizzrobes then go right through the door. This room is 
highly annoying as it has red and blue Wizzrobes, Like Likes and a 
bubble running around on little islands over lava. Hopefully no enemies 
will be on the island you are standing on when you come in this room. 
If a Like Like is on your island, either try to kill it right away or 
leave the little island to one with no Like Like on it. This battle is 
annoying so do your best and then go up a room. Do what the old man 
says and go into the next room on the left through an illusionary wall. 
Hopefully the Like Likes will be trapped behind pools of lava but just 
kill them all anyways and go into the next room on the left. This room 
is kind of a pain in the ass. Kill the hoards of red and blue Wizzrobes 
and go up. If you went left it would just take you to a pointless Vire 
room so don't even bother. Kill the Patra and then go left through an 
illusionary wall. Kill the blue Lanmolas and push the left block to 
make a staircase appear. Get the red ring down the staircase and then 
leave the basement. Go right through the illusionary wall and then push 
then left block to reveal a staircase. Go through the tunnel to emerge 
in the last few rooms of the dungeon! Kill the hoard of red and blue 
Wizzrobes then bomb the right wall and go through the hole. Kill the 
Patra in this room while avoiding the statue's fire. Hopefully you will 
not get too much health taken away as Ganon is in the next room. If you 
happen to die here or at Ganon you can try again, but it helps if you 
have at least a blue potion. Go into the next room to face Ganon. 
Fortunately, Ganon is not at all harder or different than he was in the 
first quest so just defeat him the same way as before with the three 
strikes until he is reddish-brown then dish out the ol' silver arrow 
through his blackened soul. Pick up the Triforce on Ganon's pile of 
ashes then proceed into the last room. Rid the flames guarding Zelda 
with your sword then walk up to Zelda and enjoy the little ending!

Ending: 

A happy little ditty will play then Zelda will say: "Thanks Link, your 
the hero of Hyrule" over a black screen. Zelda and Link will hold up 
their pieces of Triforce while the screen flashes and the victory 
ending music plays. Most of this stuff is the same as the first quest's 
ending but some of it is a little bit different. The message: "Finally, 
peace returns to Hyrule. This ends the story." appears then the screen 
starts to scroll. The unusually small credits will roll for a few 
seconds. This next part is mainly what is different. The following will 
appear on the screen and stay on the screen until you press start:

"You are great.

*Your Name in red~Mine being Ace* Followed by: 

*number of lives lost throughout the entire first and second quest~mine 
being 15* 

You have an amazing wisdom and power.

*picture of the Triforce on Ganon's ashes*

End of "The Legend Of Zelda 1"

Copyright 1986 Nintendo"

Now press start to get back to the game select screen.  I am 99% sure 
that the game already saved itself but I would save just to be safe 
anyways. Whether you save the game or not, it doesn't matter because 
you are 100% done with the game now anyways. Either way, your game file 
goes back to the beginning of the game again, I believe on the second 
quest. You have now fully completed "The Legend of Zelda 1" for the NES 
so be proud. I congratulate you. Next stop in Zeldaland is "The Legend 
Of Zelda 2: Adventure Of Link" for the NES. The game is harder and a 
lot different so see you there in my next walkthru. Until next time, 
thus ends the quest. The end. Game over.
********************
XIII.

And that is a rap. If you still have any questions about the game, feel 
free to e-mail me. I hope my FAQ was very useful and that you enjoyed 
it. Keep an eye out for my FAQs for all of the other Zelda games. Good 
luck.

Copyright 2003-2004 AceC-DC
********************
