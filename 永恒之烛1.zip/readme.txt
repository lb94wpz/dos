courtesy of diachun@autarch.acsu.buffalo.edu

Article: 12077 of rec.games.misc
From: Wyvern@cup.portal.com (Jeanne Wyvern Harlan-Marriott)
--

    Since we've seen some recent interest in this game and I have received
a few email requests for hints, I thought I would upload my note/walkthru
file! <and just remind you <again, I know I'm getting to sound like a
record> that if you were a member of Portal, this file and MANY MORE would
have been at your finger tips!!! <sorry about that!!!>
                                                            Wyv

Wyvern@cup.portal.com  |   "It can't be tomorrow until I've slept"
                     Notes for THE MAGIC CANDLE
                     Compiled by Wyvern
KING'S CASTLE:
     King
           See Belazar before you leave
     Gustron, knight
           they say Thorin's hammer is stolen
           rates vary town to town
     Banas, King's Uncle
     Usher
           Find olf Lufer in PORT AVUR, gathers mushrooms
           they say Belazar is dying
     Servant
           Ask Trikerviz about PEARLS
     Brontos
           Go to SHENDY on way to Bondell
           They say Banas is up to something
           BONDELL is home of the haflings
     Grolf, Com. Royal Guards
           Learn Locate & Confuse to avoid enemies
     Bhardagast, counsellor to king
           Seek help of the gods
           8 gods
           One sleeps in DERMAGUD
           DERMAGUD is deserted mine in UBERION that Bordal knows
           Bordal probably in inn at PORT AVUR
     Dinge, mayor of BONDELL
           Haflings high in charisma
           Don't believe all rumors
     Luan, courtier
           Guards are knowledgable about schedules
           Queen is depressed and speaks to nobody
     Ferdo
           Buy cheap, sell dear
           They say Trolls hold the bridges
           Buy CUBES, SPHERES, PYRAMIDS from wandering colleagues
                 who travel the roads
     Veridia
           Kids love Rimfiztrik the wizard
     Dehos
           Read about HOYAM essense in library
     Boseham
           Has friend in SOLDAIN
           Yodan the dwarf
           Knock on his door
           Knock if doors are closed
     Chilek
           You may buy SABANO from Azidamus
           Azidamus in SOLDAIN
           Knock on his door
     Vanedar
           buy ropes
           Wizard in SOLDAIN sells spell book, ask Chilek
     Dincher
           Nuri the cook give free food
           They say Lady Naran is in love again
     Forkos, servant
           Seek Capt. Garlin in PORT AVUR
     Sol
           Beratt hides a secret
           Beratt cleans the council room early in the morning
     Rana
           eat my master's food
     Nuri, cook
           Don't eat orc-food, poisonous
           Queen will diet
     Rimfiztrik
           You must find CUBES< SPHERES< PYRAMIDS
           Talk to Ferdo, near fountain
     Gelhad
           Ask monks about TEMPLES
3rdlevel
     Naran
           Bhardagast is wisw
           They say he will propose soon
     Queen's chambermaids
           MIREMIRA was a great sorceress
           She can alter the effects of Black Magic
     Nethien, elven Prince
           Kindred in TRILLIAD
     Panok
     Yolam, servant to Belazar
           Some servants are spies
     Belazar, counsellor to late King Ognar
           Learn about
                 gods              grant power
                 temples
                 eleven maids      songs
                 hafling teachers
                 gate prayers      raise dungeon gates
                 gem traders       buy gems at reasonable prices 
                                   from wandering dwarves
     Mikemira, sorceress
           If down to 10 DAYS TIME, I can attempt the NEUTAR
                 SPELL which will gain you 60 days time

           Find ZIRVANAD
           Find Father Orbonn in PORT AVUR
                 ask him about ZIRVANAD
     Banas
           Read about MEARDOM in library in PORT AVUR
           Seek Bestul at KEOF
     Beratt
           35 charisma needed
           Interesting items hidden below
           LEADS YOU TO THE ENTRANCE TO MEARDOM, Castle Dungeon
           Meet him at 8:00 near Servant's Quarters
ON ROAD TO PORT AVUR
     Sir Levnkor
           Pick NIFTS at NORTH PHALENG
     Merchants
           cubes       24 ea
           pyramids    19 ea
           spheres     22 ea
           COmbination to teleport to Isles of Ice
PORT AVUR
|--------------EE-----------------------------|
|  combat                 |      |            |
|docks             a      |guest |   jail     |
|        cpt       r      |house |            |
|       guard      m      |      |            |
| met              o _____|__    |      ______|
| smith            r                          |
|                           weapon            |
|_______             ___________________ _____|
|       |           |      tailor       | wiz |
|     __|           |________     ______| sch |
|     |             |                   |     |
| inn |                                 |     |
|_____|      _______|      garden             |
|           |                           |     |
|    _______|_______      ______________|     |
|   |               |    |              |     |
|   |               |    |   library    |     |
|   |archer   gen st|    |_____     ____|     |
|                                             |
|             food        gem cutter          |
|---------------------EE----------------------|

     Guard
           They say Scorpia can solve it!
     Innkeeper
           Hire a captain to sail
           Word from the south worries the dwarves
     Feyz
           they say DOLOMAR hides in KEOF
     Bordal
           Seek RABBANKAR the scholar
           DERMAGUD, chant achunne reshiptar ebitonagzi to enter
           Seek DRAKKA council
           Drakka means dwarf in old dwarvish
     Voer
           Offer bard a drink
           Garlin sails to FUBERNEL
     Meno
           They say black dragons are awake
     Fetrik
           Buy ropes & blankets if you are heading to UBERION
           Old man studies mushrooms
     Ermal, bard <offer drink>
           Dwarves are in town selling HOYAM
           Ellidrin of SELDARAD
           Far yonder in Seldarad
           lives a fair elven maid
           eyes of bright emerald
           and hair of shiny gold
           Man and elf come from afar
           yearning a glance of her
           and her songs to hear
           said to be like no others
           Her name is Ellidrin
           she is known to favor the hearty
           deep in Seldarad green
           she sings, she waits for thee.
     Levos
           Guard at castle knows TELEPORT combination
     Jail Officer
           Ask comm. about pass
           Orc Buzbazgut, tell brother in VOCHA to send for help
                 it was chief chambur's last wish to be buried with
                 hammer<candle>
           Orc Hubantatur
                 was member of squad that stole hammer
           Orc Dagbunbagtur, help escape now and group spared later
                 we buried the HAMMER next to CHAMBUR's TOMB
                 buried in VOCHA below ISLES OF ICE
     Sephair
           Don't camp without blankets
           Tailor of KNESSOSIS is the best
     Lunyan
           Carpenter may find work in KEOF
           Food is expensive in MERG
     Lufer
           Seek MAKASO the wizard in SOLDAIN
           SOme say the words at temples are ancient prayers to gods
           Find GONSHI mushrooms by River in PHERON FOREST
     Father Orbann
           ZIRVANAD was placed in stone vault by Zarva's apprentices
           Vault had a star shaped KEY, fate of key unknown
           Dwarf ballads say a White WOlf carries the Star KEY 
                 around her neck
           Vault hidden in underground chamber
           Father Hosan claims vault is in caverns of SUDOGUR below
                 LYMERIC
           HOSAN in KEOF
     Father Ulubal
           Have a LENS when  you visit a TEMPLE
           If you want to know about VALON ask Hokando in SOLDAIN
           THere is a DUNGEON under LAKE BRELLEHT
     Librarian
           HOYAM essense is dwarvian specialty found underground
                 turns to ash in sunlight. Exact use a Dwarf secret
                 may have luring effect on some creatures
           MEARDOM is name of DUNEGON below the King's Castle. King
                 Ongar ordered wizard DEBARAMOS to seal gate with 
                 magic, Aslan, son, found slain
     Everos
           Visit Belazar again after reading ZIRVANAD
           Teach swordplay in 1 day in SUMRUNA
     Runnof <monk>
           18char needed
     Hupson
           Sail to BONDELL via SHENDY
           GODS may grant strength
     Captain Garlic
           SHENDY      100
           FUBERNEL    150
           POINT HENA  200
ON ROAD
     Rokka
           Captain Kunder sails to the ISLES OF ICE
     Father Gostac
           inspect ALTAR in TEMPLES <use lens>
           Rabbonkar teaches old Dwarvish in SOLDAIN
           There is a TEMPLE between the 2 lakes
     Father Bullon
           6 of the 8 gods sleep in underground chambers
           2 gods sleep above ground
                 KALB - TEMPLE in LAKLAND
                 PAX  - far far away
           There is a TEMPLE nearby through DERMAGUD

DERMAGUD
**BUG> while trying to locate emeralds, standing on water, when
       use shovel, picture shows wall BELOW the chest
       3 CUBES TOWARDS YBERTON 2 steps south, 4 steps west, 6 steps
             south, DIG <diamonds> 
       Chant to awaken GOD: shaerad ude shaerad faey 
SOLDAIN
MAP:                                 
|--------------------------------------|
|     yodan       ?           Makaso   |
|==                                    |
|         Azidamus    Council Hall     |
|                        18:00         |
|     Hokando       Rabbonkar          |
|                                   == |
|--------------------------------------|
     Yodan
           Ask council for HOYAM
           Find WHITE WOLF and WOLF ROCK in PHALENG
           New Diamond mine in PHALENG
     Varak
           If you please the council, they might declare you a dwarf 
                 friend
           A captain in KEOF dares to sail to the ISLES OF ICE
     Hodin
           Seek 'TEMPLE of the sun' at KUSKUNN
     Makaso
           teaches LEARNING
     Hokando
           awaken GODS by chanting their PRAYER
           VALON <god>, reach his TEMPLE through DERMAGUD
Council of Elders
     Yondilar
           Dwarves can be generous
           Talk to Okdark
     Frigger
           HAMMER must be retored to its place
     Fodkin
           We cannot help while the HAMMER is missing
           WHITE WOLF in PHALENG
     Okdark
           Must prove worth
           return HAMMER
     Nokbin
           Hammer is symbol of Dwarf power
           Visit KUSKUNN before VOCHA
           Treasures in VOCHA
     Rabbonkar            Teaches old Dwarvish
DRAKKA     -     dwarf             TARG        -     step
OT         -     home              ZERBOD      -     trap
TRAR       -     belong to         ORU         -     towards
GRU        -     snakes            LEKION      -     fountain
DAHAR      -     ahead             AGRU        -     examine
ZALFAR     -     elden             HRUKK       -     pride
UMEN       -     magic             TOKRA       -     portal
ZATAGI     -     attention         ORU         -     to
HATMA      -     spider            APTAR       -     level
DENGA      -     rope              HUKTE       -     time
RASPAGOD   -     necessary         BERI        -     near
GAPI       -     entrance          AHKT        -     pyramid
HAN        -     1                 YUVAR       -     sphere
GODA       -     2                 KUP         -     cube
VOD        -     3                 KARB        -     dig
GOTRA      -     4                 PARTAL      -     hall
ROTTA      -     5                 DRUK        -     down
DEN        -     6                 VO          -     up
OBUR       -     7                 KAR         -     go
YOZU       -     8                 GARVATH     -     hello
DERO       -     9
NOK        -     0
RAGON      -     west
DEVAR      -     north
NOGAR      -     east
KRAV       -     south
--------------------------------------------------------------------
AGRU        -     examine          LEKION      -     fountain
AHKT        -     pyramid          NOGAR      -     east
APTAR       -     level            NOK        -     0
BERI        -     near             OT         -     home   
DAHAR      -     ahead             OBUR       -     7    
DEN        -     6                 ORU         -     towards
DENGA      -     rope              ORU         -     to
DERO       -     9                 PARTAL      -     hall
DEVAR      -     north             RAGON      -     west
DRAKKA     -     dwarf             RASPAGOD   -     necessary 
DRUK        -    down              ROTTA      -     5       
GAPI       -     entrance          TARG        -     step
GARVATH     -     hello            TOKRA       -     portal
GODA       -     2                 TRAR       -     belong to 
GOTRA      -     4                 UMEN       -     magic     
GRU        -     snakes            VO          -     up
HAN        -     1                 VOD        -     3      
HATMA      -     spider            YOZU       -     8       
HUKTE       -     time             YUVAR       -     sphere
HRUKK       -     pride            ZALFAR     -     elden   
KAR         -     go               ZATAGI     -     attention 
KARB        -     dig              ZERBOD      -     trap
KRAV       -     south
KUP         -     cube

SHENDY
KEOF
Map:
|--------------------------------------|
| rest           sw.train      docks   |
| house                                |
|          armor      gem        archer|
==guards                               |
|                           gamble     |
|        food   weapons                |
|                       gen goods      |
| inn    KEOF COURT                    |
|                                      |
|        library        carpenter      |
|--------------------------------------|
     guards
           Vixeskre    00:00
           Dolomar     01:00
           Ferrin      in inn early morning
           Tasfaras    13:00
           Bestul      16:00
           Cpt. Kunder 19:00 in inn
     Nulden
           Talk to mysterious guest at guest house
     Zentyne
           you need to raise your charisma
           the say TONTON's services are expensive
     Kebo
           Seek TONTON in BONDELL
     Hosan
           after obtain the STAR KEY seek the 'Gate Keeper'
                 in LYMERIC
           poison pillows in guest houses
           Vault in SUDOGUR below LYMERIC
           Ask Gate Keeper about SUDOGUR
     kid
           the say you can teleport from VOCHA
     Umurik
           You can teleport to YBERTON from DERMAGUD
           Combination hidden in DERMAGUD
           CRYSTAL CASTLE - more volunteers
     Tasfaras
           Learning skill, AKSIMENTO can help in LYMERIC
     Father Gostand
           Ask Yodan <SOLDAIN> about WHITE WOLF
           Giant eagles have stolen the prince
     Meldon
           After you have read ZIRVANAD visit Belazar
           there is a strange guest in the guest house
     Numbar (mysterious guest>
           Go to DUNGEON to find what you seek
           Name the DUNGEON you seek
           to enter VOCHA chant HOKDE  KAFLTH  POKANDAJO
     Usmet
           Ask BESTUL about Ongar's wizard
           Ask Guards about Bestul
     Vixesre
           REMULDA of LYMERIC sells the book ISHBAN
           PYRAMID SPHERE SPHERE to teleport from 
                 VOCHA to ICE PLAINS
     Dolomar
           You need the help of the MAD WIZARD
                 be patient with him
           THey say the King is ill
           MAD WIZARD sit atop his TOWER
                 TOWER OF THAKASS
                 Has the BLUE RING
     Krundo
           Captains won't sail to HEAVENLY
                 Isles of Faery Magic
           They say a cure for the curse exists
     Ferrin
           Avoid bad advice
           Kunder dares to sail to the ISLES OF ICE
           Many TELE COMBOs learned in SHIRAN wizards' village
     Bestul
           40 charisma needed
     Wein
           Read Sherro's legend in library
           CPt. may sail to Port Hena
     Librarian
           Sherro's legend is old elf tale. Sherro elf girl born
           when unicorns still dwelled in TRILLIAD. She could
           attack unicorns by chanting words known as 
           SHERRO'S HIGH CALL
           elves may still know the words
     Baston
           Kunder can take back to Port Avur
     Danto
           Vist friend ZEKE in LYMERIC <good advice>
     Mentino
           Kunder can take you to KUSKUNN <take lens>
           Blk. Dragons burnt THELDAIR
     Kunder
           ISLES OF ICE      200
           PORT AVUR         120
           KUSKUNN            50
           FUBERNEL          100
           POINT HENA        210
     Atlan
           Visit the CANDLE in BERBEZZA in HIDDEN VALE
     Isham
           ask WIZARDS about TELEPORTERS
ON ROAD ON SHENDY
     Mola, monk
           visit temple on FUBERNEL
           Teleportal on SHENDY
     Dundar, farmer
           seek TUTEN in BONDELL
           TUTEN knows the words to enter SHADRUM
     Nuronn, wizard
           seek KUREK in KHARIN
           KUREK has been to BEDANGIDAR
           There is a SERMIN patch nearby
           SPHERE PYRAMID CUBE     SHADRUM     MARMARIS
     AELLIN, elf maiden
           seek my 2 sisters 
           <each has a song>
FUBERNEL
DELKONA

|----------------------------------|
|       gamble     armor        docks
|     |          |__________
|     |                guest|
| lib |               house |    inn            WATER
|-----|-      ----|_________|
 |guards|
 |      |         -----------    tower
|-------|        |  gen.st.  |__
|car      _______|
|pen     |                   ---
|ter     |                  | wiz    
|        |  weapons         |school     archer  
|food    |                  |           school
|________|___________       | blk
|                           | smith
------------------------------
       STRANGERS NOT ALLOWED into CITY
           OFFER 100
     Guard
           Leksra knows teleportals out at 01:00
           Kraken in awake
     Guard's Headquarters
           Rumour is enemy inflitrated, strikes withing
           OFFER $100- to get in
GENERAL STORE
           Topaz       90
           Rubies      115
           Emeralds    250
           Diamonds    575
     Lippa
           elf may help but has a temper
           GENEVAR <elf> gained insight from OBELISKS
           Genevar visits Delkona Inn
     Bundi
           Read Sherro's Legend in KEOF library
     Uzim, wizard in inn
           only way into SARGOZ is teleport
           there is a teleportal on SHENDY
           SPHERE PYRAMID PYRAMID BEDANGIDAR to UDAR
     Domlin, monk
           seek HERU, GOD OF WAR
           Temple on FUBERNEL
     Tumis, hafling
           GONSHI in N. FUBERNEL
           DRELIN in S. FUBERNEL
     Genevar, elf
           reasearch in libraries
           words on OBELISK = 3 WORDS OF WILL
     Pupin, hafling
           I survived
           Heard of man who can raise dungeon gates with gaze
     Gonnar
           LUFFIN on W. FUBERNEL beaches
     Shanek
           MIRGETS on ISLE OF GIANTS
     Drunk
           search for stairways to HEAVEN<LY>
           Necromans are about town
     InnKeep
           Capt. Murdar has a lady in SUMRUNA
           Capt. Murdar in before noon
     kid
           I'm not afraid of gbolins
           you must go to SARGOZ
     Leksra, wizard
           There are 4 TELEPORTALS on the surface of DERUVIAS
           PHERON      KHIRISS     KHERBEL     SHENDY
     Llochhean
           ARGELB knows the tele combo to escape SARGOZ
           ARGELB is in CRYSTAL CASTLE
     Kahir, old man
           Don't lose the RING, they would end in the
                 furnace of Hades <SARGOZ>
     Aartinix, wizard
           FARUK sells TELEPORTAL KEYS
           2 stairways leading down from level 2 of KHAZAN
           KHAZAN is dungeon under SEA
           SPHERE SPHERE SPHERE  KHAZAN to PORT AVUR
     Pavik, wizard
           there is an OBELISK on VO
           SPHERE SPHERE CUBE KHAZAN to YBERTON
     Bobo, hafling
           FOZIMAR the wiard can increase LEARNING
           FOZIMAR lives in BONDELL
     Stavko
           1 of the 3 LEVERS is in DARVALE
                 must pull all 3 at one time
           there are 2 destinations to teleport to from SARGOZ
     Murdar, captain
           visit SHENDY
           Faery tules HEAVENLY
           ISLES OF GIANTS         200
           SHENDY                  150
           BLUE CRAB BEACH         250
           SUMRUNA                 150
     Tiko, hafling
           LUFFINS on KUSKUNN
           Its all because of the dreadful Hodli Ducks
     Librarian
           OBELISKS = powerful Spell
           SUNKEN ISLE Elden Magic Powerful books were placed in
           a tower named RUHAN island and tower submerged
     Emmo, hafling in the inn
           LEVER in PIYAN
           There is no more DREAM DUST <elven magic> in THELDAIR
     Tombul
           Lost AMULET gambling, sold it to FARUK, merchant
                 on FUBERNEL
TOWER:
     SHENDY            6 squads    difficulty 1
     KUSKUNN           3 squads    difficulty 5
     HEAVENLY          4 squads    difficulty 5
     FUBERNEL          8 squads    difficulty 2
     ISLE of GIANTS    9 squads    difficulty 7
     ISLE of ICE       4 squads    difficulty 2

On Road to Bondell
     Minky, hafling
           Conquer Shadrum, TOWER built by ogres
           Ogres corrupted isle, nothing but swamps now
     Merchant, pyramids 24
           There is a nift field near by
     Faruk, merchant
           gave AMULET to FARHAD in SUMRUNA
BONDELL
Map:
|------------------------------|
| Meliso    Tonton      Tuten  |
|         (charisma)           |
|                              ==
|                              |
|                      Nimmet  | 
| Fozimar                      |
| (learning)            Hubbo  |
|------------------------------|

     Shumme, hafling
         You can buy the book ISHBAN in LYMERIC
         I hear the King's hero is on quest for CIRCLET
         THe King of Ogres wears the CIRCLET
     Pinosh, hafling
         Learning only cost 120 in SHIRAN
         They say enemy partols area west of here
         the TOWER of SHADRAN is on the ISLE OF GIANTS
    Jepne, hafling
         You can buy the BOOK ZOXINN in SHIRAN
         Ask FIZKRETO about ZOXINN 
         They say Dinera has lost her powers
              She entered the TOWER SHADRUM with aid of
              TUTEN. alas she was defeated and wanders the
              roads of FUBERNEL
    Tuten, hafling
         Seek DINERA, she is not crazy
         They say the ash of *shir-aka* was used by Eldens to
              trap DREAX
         Wizards of SHIRAN look after SHIR-AKA now
         chant DAMLAZ  FIRTARAFA  YAKLAMATOFAR to open SHADRUM
     Hubbo, halfing
           seek TEMPLE of HERU before KHAZAN
           One entrance to KHAZAN is on this isle
     Nimmet, hafling
           pay attention to all you hear about SARGOZ
           Furnace of Hades burns in SARGOZ
           You must find the portal on LAKE KUMALIS to reach 
                 the furnace
           4 levels in SARGOZ, Lake on lv 4
     Shinshu, hafling
           learning cost only 140 in LYMERIC
           Demonic powers are at work
     Meliso, hafling
           Raise the SUNKEN ISLE by pulling all 3 LEVERS at once
           Delkonia Guards are crooks
ON ROAD BONDELL DELKONA
    Merchant, cubes 24
        THe AMULET is lost. Was given to
        Knight FARHAD from SUMRUNA

    Dinera
        You must defeat the Ogre King in the TOWER of SHADRUM
        There are 3 halls in the top level one is the
            Hall of No Return, to cross it you must reach the
            EAST wall and move SOUTH

ON ROAD PORT AVUR  LYMERIC
     Emin
           PINDALF in the CRYSTAL CASTLE studies Magical Rituals
           Ogre Kin wears stolen circlet
     Gallen, dwarf
           sells rubies for 60 each
     Sefir, farmer
           SERMIN in UBERION
     Trikerviz, wizard
           DENKAR knows that pearls can be used for more than trade
           CUBE PYRAMID CUBE DERMAGUD    SELDERAD
     Gretta, old woman
           go back home
           they say its out
     Fixnix, wizard
           you may sail or teleport to ISLES OF ICE
           PYRAMID CUBE SPHERE     DERMAGUD    ISLES OF ICE
LYMERIC
map:
|-------------------------------|
|                 GATE KEEPER   |    SUDOGUR lies below
|                               |
|                               |
|                               |
| )\)\)\)\)\)\###)\)\)\)\)\)\)\ |    )\ = water  ### = bridge
|                               |
| AKSIMENTO               ?     |
| learning                      |
|                               |
|  REMULDA             ZEKE     | 
|sells Ishban                   | 
|-------------EEE---------------| 

     Remulda
           sells ISHBAN for 1750

TRILLIAD
NIFT   x116 y66
SERMIN x114 y60
ON ROAD:
     Aaso, farmer
           5 rations for 6 coins
     Rufus, hermit
           Magic is not the answer to all
     Gaylon, elf
           Find PAX in PIYAN <eye>
           TEMPLE in ROSUS
     Fahael, elf
           Seek REMON the Kinght in the CRYSTAL CASTLE
           Treasure in Enemy Towers
     Nehemas
           Seek PALADIN in BEDANGIDAR (GOD of MOON)
     Kellian
           Seek HEXTARIS in THELDAIR
           The HERMIT was not always a HERMIT (wanders Trilliad)
     Ovar, monk
           HISSEN is in CREZIMAS
           TEMPLE to HISSEN in SW KHERBEL by the sea
     Aydor, elf
           Ask Wizards about TELEPORTALS
           KUREK entered BEDANGIDAR
           KUREK in KHARIN
     Leam-fr, elf
           ASHES may be needed, ask conclave in SHIRAN
THELDAIR
map:
|---------------------------------|
|                     Jagamer     |
|                                 |
|         Council Hall            |
|           18:00                 |
|                    Gilondo      |
|                                 EE
|                                 EE
|                                 |
|                                 |
|                     Hextaris    |
| Baelin              DEMARO 1500 |
|(knows elfen maiden)             |
|---------------------------------|

     Kehvean, elf
           TRUK the wizard know the TELEPORTALS like no other
           TRUK is in the CRYSTAL CASTLE
           there is a curfew in Delkona
     Sevidor, elf
           NIFTS east of THELDAIR
           Elven maid on an isle
COUNCIL HALL
     Neldor, elf
           SOMONA the Sorceress could help
           THey say AZRAELS are coming
     Keldain, elf
           Knock on GILONDO's door
     Nef, elf
           Help so you can be h elped
           ONly AZRAELS could overpower SOMONA
           Somona is maker of DREAM DUST
     Queen Fay, elf
           Elves will help you
     Feadeil
           Only SOMONA can give you the DUST you seek
           Somona is out Sorceress and advisor to the Queen
     Galhail, elf
           Ask about the ELVISH CLOAK in MERG MUSEUM
           There are prisoners in the mines of BEDANGIDAR
     Tassen,elf
           Stay away from BEDANGIDAR <dwarf mine>
     Gilondo
           Maybe we can get help from LAND OF FAERY
           SHERRO was friends to UNICORNS
           ONly one UNICORN left
           SHERRO'S HIGH CALL: SHERRO  HOY  DUMANFIR
     Hextaris, wizard
           sells the DEMARO BOOK for 1500
     Baelin, elf
           Seek SUERFIN in TRILLIAD <elven maiden>
           SUERFIN knows the SPARROW SONG
           AYDOR will visit soon, wanders in the woods
     Somona, sorceress
           Knows how to make DREAM DUST <gives you some>
MERG
map:
|--------------------------------------------|
|                docks                museum |
| guest    |     |                      ^    |
|  house   |     | inn      gambling         |
|          |     |                           |
|----------|     |---|                       |
|                    |             g  -------|
|                    |             es  metal |
| ----    -----|                   nt   smth |
| carpen       |     |             eo        |
|  ter         |     |             rr        |
|              |     | tailor      ae        |
|      ________|     |________     l         |
|     |                                      |
|     |    -----|    |---                    |
|     | wiz sch |    | weapons          food |
|     |  350    |    |                       |
|----------------EEE-------------------------|

     Guard
           buy Methreal ARmor
     GENERAL STORE
           Topaz              75
           Rubies            110
           Emeralds          210
           Diamonds          390
Behind Guest House 2 elves
     Rondel, elf
           We're searching for SOMONA, you should too
           The Queen awaits thee
     Leminor, elf
           Seek the 3 ELVEN SISTERS
           BAELIN in THELDAIR knows one of the sisters
     Gelsham
           GONSHIS in SELDERAS
           RUKNET, in the inn, is not well
     Korhan, knight
           Find a DWARF that can tell you the secrets of
                 BEDANGIDAR
           BRENNIX is lost there <would love to own it>
     Clero
           Ask REMULDA about the BOOK ISHBAN <in LYMERIC>
           Queen Fay needs help
INN:
     RUKNET, monk
           You need the STAR KEY to get into SUDOGUR
           there is a TOwer in SUMRUNA
     Tomola, captain
           UDAR              350
           BAY OF MERIC      200
           KRAKEN BAY        225
     Meneby, hafling
           The more you HUNT the better you get
           Good hunting in TRILLIAD
     Durmush
           Did you dig in CHAMBUR's TOMB yet?
           Treasures in TOWERS
after 19:00 in INN
     Runbear, wizard
           my master may be able to help
           he was the late king's wizard
           CUBE CUBE CUBE    KHERBEL   MERG
     Haendel, elf
           Seek the ELVEN MAIDS, BAELIN loves one
     Lokhan, elf
           ELVEN MAIDS give gift in SONG
     Aposh, drunk
           Seek PUGAR in KHARIN, hunts CYCLOPS
           Breweries in FUBERNEL are closed
     Kimm, man
           Carry LOKA
           Gnolls put traps in chests

     Museum Master
           enjoy the ELDEN artifacts on display
           CROWN OF KUMAKDGAN King of Gnolls
           ELVEN CLOAK protects from FIRE
     Punok, farmer
           ask farmers about FOOD
     Thoran, man
           Tomola sails to KRAKEN BAY
     Bornozar, monk
           Perhaps the BIRD GOD will help you
           BIRD GOD in SUDOGUR
           DRELINS in E. FISESTAR
           TEMPLE in SOuthEast KHERBEL at end of road
     Envil, man
           Temples are for the GODS
     SORGULARA, wizard
           You must ask for SPELL BOOKS by name
           SPHERE SPHERE PYRAMID   SUDOGUR     MARMARIS
     Lupsikin, wizard
           Best value for learning MAGIC in DELKONA
           GONSHI by sea South of CRYSTAL CASTLE
           PYRAMID SPHERE CUBE     MEARDOM     S. KENDAR
     Lunikor, monk
           MIRGETS in KHIRISS
           TEMPLE of SUR <bird> is in SHERTUZ
ON ROAD:
     Efenor, elf
           seek UNICORN, SHERRO loved them
LUFFIN     x 92  y 82
KHARIN x 130  y 110
map:
|--------------------------------------|
|                           Armory     |
|  Shagar                              |
|                                      |
|                ----------------------|
|                                      |
|---------------------------------     |
|              Pugar                   |
|  Viadras                             |
| (learning)                       ?   |<-Kurek?
|              Koldan                  |
|                                      |
|                                      |
|     ----------|   -------------------|
|     Valoda    |          Kabuck      |
|               |   |                  |
|----------------EE--------------------|

     Delek, dwarf
           SHAGAR may provide a lead
           Bard's mighty magic was of no avail
     Shagar, dwarf
           Seek DINERA in bFUBERNEL
           PUGAR knows the location of the stolen CLOAK
           must teleport to SARGOZ
           Need 'KEY COMBINATION' and location of the 'CHAMBER'
                 from which to teleport
           KEY COMBINATION is on 4 SIGNS in KHAZAN
           KULAK knows about KHAZAN <out afternoon>
     Volgas, dwarf
           VIADRAS = learning, lives in the square garden
           Red Octopus is at large
     Kurek, dwarf
           Dreax is visible
           to enter BEDANGIDAR chant SAMANDAX  TIFGARAMO  KEMT
     Pugar, dwarf
           Cyclops stole the CLOAK from MERG
           Buried the SouthWest corner of HALL OF ANCIENT DREAMS in
                 CREZIMAS
METHREAL ARMOR         900
     Turben, dwarf
           PAX sleeps in PIYAN
           TEMPLE in ROSUS
     Kulak, dwarf
           ask about KHAZAN, 2 entrances, 1 is on FUBERNEL
           Valoda lost his plume
     Valoda, dwarf
           teaches OLD DWARVISH
     Kabuck, dwarf
           need to raise 'SUNKEN ISLE'
           locate the 3 LEVERS pull all at the same time to
                 raise the sunken isle <SARGOZ>
     Gard, dwarf
           LOKA south of KHARIN
           Moss covered PORTAL in KHAZAN 3rd level ports to
                 area with no other entrance
     Koldan, dwarf
           SCROLL hidden in SHADRUM
           ask KEMKEZAR about scroll <in SHIRAN>

SUMRUNA
map:
|-----------------------------------------------|
|blk.  tailor|                     docks        |
|smth                                           |
|                   ______                      |
|      |------|    |gamble|     |---------|     |
|combat|      |    |      |     | inn     |     |
|sch.  |      |    |      |     |         |     |
|_______gen st_    |______|     |__    ___|     |
E                                               |
E_______     ___________    ______    __________|
|      |                          |   | guest   | 7 coins/night
|weapon          tower            |   | house   |
|      |                          |   |   ______|
|______|     ________________     |__________   |
|                                               |
|armor         __                           food|
|          wizard|       seaside                |
|          school|                              |
|-----------------------------------------------|

GENERAL STORE
     Rubies      135
     Diamonds    500
     Guard
           Seek Monks BASKO & MURKAZA 
     Murkaza, monk
           need PIERCE & REPEL in SHADRUM
     Basko, monk
           LUFFIN in KHERBEL desert
           TEMPLE of the MOON is in SouthEast KHERBEL
                 near Yberton
     Fagharn, wizard
           Read about THE SUNKEN ISLE in DELKONIA
           GONSHI drying up
           SPHERE PYRAMID CUBE     DERMAGUD    PHERON
TOWER
     S. TRILLIAD       9 SQUADS    3 DIFFICULTY
     S. BIHUN          5 SQUADS    3 DIFFICULTY
     FISESTAR          5 SQUADS    5 DIFFICULTY
     KHERBEL          12 SQUADS    6 DIFFICULTY
     YBERTON           3 SQUADS    4 DIFFICULTY
     UDAR              7 SQUADS    6 DIFFICULTY
     PIYAN             7 SQUADS    7 DIFFICULTY
     ISLE OF VO        4 SQUADS    7 DIFFICULTY

INN:
     Demren, monk
           2 TEMPLES in KHERBEL
           HISSEN = Snake GOd
           TEMPLE of HISSEN in SouthWest KHERBEL
     Zukumya, wizard
           SERMIN in FISESTAR
           CUBE PYRAMID SPHERE     CREZIMAS    FUBERNEL
     Drunk
           ALI = creator
     Leshar
           visit NIMMET in BONDELL
     Hakim
           MIRGETS in PIYAN
           PUPIN knows how to enter KHAZAN
           PUPIN left town
     Valero
           knock on KOLDAN's door in KHARIN
     Dumear, second mate
           TELEPORTAL in KHERBEL
     Patras, captain
           Sirens caused Garlin to go down
           FUBERNEL          150
           ISLE OF VO        100
           SHENDY            250
           BLUE CRAB BEACH   250
     Gourney, monk
           DEMREN and I pray at different TEMPLES
     Derhal
           seek guidance from Haflings about SHADRUM
           deadly halls in SHADRUM
     Rumba, old man
           MAD WIZARD has the BLUE ONE
           UNICORN has the GREEN ONE          <rings>
     Kelock
           seek KABUCK the dwarf in KHARIN

     Mizekske, wizard
           JAGAMER teaches LEARNING in THELDAIR
           PYRAMID CUBE PYRAMID    KHAZAN      SHENDY
     Enick, farmer
           seek MIKEMIRA in KING'S CASTLE
           PUPIN survived KHAZAN
           PUPIN in DELKONIA
     Mishu, farmer
           seek HUBBO in BONDELL
     Farhad, knight
           you may have to enter the 'FURNACE'
           All ELDEN ARTIFACTS found by the enemy are thrown into
                 the FURNACE OF HADES
           Lost WHITE AMULET in a fight. It will probably show up
                 in the FURNACE OF HADES
     Aishen, woman
           KOLDAN in KHARIN
           DESSEN, in CRYSTAL CASTLE, is friendly with a WITCH
     Shibel, woman
           seek EFENOR, wood elf, ask about UNICORN
           MIKEMIRA, in the KING'S CASTLE can BUY TIME
     Numan, merchant
           Brew in Tavern is cursed

CRYSTAL CASTLE
     Tamahir
           seek HUBBO's advice in BONDELL
           MURUMAS is cursed with NO SLEEP spell
     Veren
           SHAGAR, in KHARIN knows about the LOST DUNGEON
     Edromir, knight
           seek TREBOR One Eye's TREASURE in CREZIMAS
           TREBOR, thief king
           TREASURE buried 11 steps west of TOMB
           UMARO claims he went down once. <queen's hero>
     Guard
           QUEEN can sense the monster down below
     Queen
           I can tell the number of enemies in CREZIMAS
           Level 5     4 ambush    5 parties
           Level 4     2 ambush    3 paries
           Level 3     4 ambush    2 parties
           Level 2     3 ambush    3 parties
           Level 1     3 ambush    3 parties
           after cleaning out CREZIMAS COMPLETELY the QUEEN
           will give you CRYSTAL DUST
     Umaru
           Search  CREZIMAS thoroughly for hidden item
     Ochann, knight
     Semal, lady
           Buy METHREAL ARMOR in  KHARIN
           The Elven CLOAK is stolen, protects from FIRE
     Tepekos, knight
           Portal on level 2 of CREZIMAS
     Argelb, wizard
           talk to SHAGAR before visting KHAZAN
           SHAGAR live in KHARIN
           PYRAMID PYRAMID CUBE    SARGOZ      FUBERNEL
     Dessen, lady
           DINERA, the witch, knows the peril of SHADRUM
           Hodli ducks will our doom, they are huge and fat
     Marumas, wizard
           Lava in CRESIMAS
           FURNACE OF HADES in the bottom of SARGOZ
           Do SARGOZ only when you are the best you can be
           SPHERE PYRAMID PYRAMID  CRESIMAS    SELDERAD
     Truk, wizard
           TELEPORTAL in THAKASS is gate to SARGOZ
           PYRAMID PYRAMID PYRAMID SUDOGUR     SUMRUNA
     Remon
           Seek evil Dragon RAHKAN's TREASURE under cursed sign
           THey say RAHKAN will return
           Wizards tricked RAHKAN into a trap
     Pindalf, wizard
           Hope my 'studies' can help you
           I study 'magic rituals'
           RITUAL OF AWARENESS written in a book called the
                 ZILMAERON it is locked in a glass sphere in
                 the TOWER OF RUHAN on the SUNKEN ISLE
           MELISO in BONDELL claims knowledge
SHIRAN map: 
|-------------------------------------| 
|             Kemkezar                | 
|  Seksanta?               Petkenpif  | 
|                                     | 
|                                     | 
| Council                             | 
|  Hall       SHIR-AKA                | 
|               TREE                   E 
|                                      E 
|                                     | 
|                                     | 
|                                     | 
|  Fizkreto               Yetmishi    | 
| (sells ZOXINN 2000)                 | 
|-------------------------------------| 

     Petkenpif
           there are 10 DUNGEONS
           KOLDAIN, in KHARIN, knows the location of ZUKKAMEAR
           WHITE AMULET, TOMBUL bought it from an elf in DELKONIA
     Yetmishi
           Raising Dungeon Gates requires knowledge
           mad coleague has gone senile
           SPHERE PYRAMID PYRAMID  CRYSTAL CASTLE    SELDERAD
           THAKASS chant KURAMDAFUR  TEVALATO  REKMETREK
     Kemkezar
           There are fountains in THAKASS if you awake KALB
           THAKASS is teleportal gate to SARGOZ
           SCROLL OF ZUKKAMEAR = 3 words to make the
                 BUBBLE OF CAPTIVITY
     Freyapkin, leader
           Magical items of the same color light up the 'STONES'
           LIGHTING STONES in BERBEZZA in Hidden Vale
           SPHERE CUBE CUBE        KHIRISS     FUBERNEL
           Only the person wearing the CIRCLETTE OF AKA can pick
                 the twigs of the SHIR-AKA TREE
     Shekyza, archmage of the red order
           You can buy the BOOK ZOXINN here in Shiran
           SPHERE CUBE SPHERE      SHENDY      DAKLAND
     Gromus, archmage blue order
           Walk in SHIRAN after MIDNIGHT
           PYRAMID CUBE PYRAMID    SHADRUM     SHIRAN
     Jaxinfozt, archmage green order
           PYRAMID SPHERE PYRAMID  MEARDOM     KNESSOS
     Matrakas
           Take lessons from SEKANTA
           A GOD sleeps nearby, to the WEST
           CUBE CUBE PYRAMID       SHADRUM     FISESTAR
     Atvalan
           SERMIN in TRILLIAD NorthEast of THELDAIR
           DEBARAMOS no longer practices magic
           His aprrentice is RUHBEAR in MERG
           PYRAMID SPHERE CUBE     CREZIMAS    TRILLIAD

     Gnetra 
           search for BRENNIX in BEDANGIDAR 
           CREZIMAS is infexted with spawn of darkness
           SPHERE CUBE PYRAMID     KHIRISS     TRILLIAD
     Carvis
           DRELIN west of SHIRAN
           OBELISK in MEARDOM
           PYRAMID CUBE PYRAMID    KHIRISS     SHERTUZ

KNESSOS
map:
|---------------- d  o c k s-------------------|
|gamble   inn                         sword    |
|                                     school   |
|      ----------------                        |
|       w        armor|    |                   |
|       e  <    >|    |    |                   |
|       a        |    |    |                   |
|       p        |    |    |           tower   |
|       o             |    |------       ^     |
|       n        arch-|    f      |            |
|                 er  |    o      |            |
|                sch. |    o      |            |
|blk smith            |    d      |            |
|                 car |    |      |            |
|                 pen |    |      |            |
|      tailor     ter |    |-------------------|
|     ________________|          Guest House   |
|          general    |           3coins/day   |
|       >  store      |    |                   |
|-----------------------EE---------------------|

     Zekros, wizard
           TELEPORTAL on Level 5 of THAKASS on Wizards' Isle
           Writing on HOYAM in PORT AVUR
           PYRAMID CUBE PYRAMIDE   THAKASS     KHIRISS
           Cpt. Barbos can take you to Wiz Isle
     Tenkit, haflin
           When facing tough monsters, use NIFT
           NIFT North of KNESSOS
           Hodli ducks are a curse
     Flaygor
           BARBOS sails to BIHUN
           OBELISK below KING' CASTLE
     Innkeeper
           The MAD WIZARD is really not so crazy <WIZARD's ISLE>
           Cpt. Barbos in around 19:00
     Barbos, captain
           there are rats in Garlin's boat
           BIHUN             200
           WIZARDS ISLE      150
           PHERON            400
           KUZU BAY          350
     Merif, farmer
           Seek FAGHARN'S advice in SUMRUNA
           TEMPLES are prayers to GODS
     Kiprit, hafling
           GHERIG's friend knows how to enter THAKASS
           ask guards about GHERIG
     Kemosh, hafling
           seek knowledge about the BUBBLE in SHIRAN
           heard Mad WIzard moved to upper BEDANGIDAR
     Vilad
           must know the SYMBOL for each GOD
           ZUMAGINS rule THAKASS, Wizards Isle
     Jemosh, hafling
           need PIERCE spells to conquer THAKASS
           OBELISK nearby, North of KNESSOS
     Mimosh
           Keep asking about the BLUE RING to MAD WIZARD
           Quonnies drove him mad
     Rhumba, old man
           Barbos can take you back to PHERON
           SPHERE SPHERE SPHERE    BEDANGIDAR  SHENDY
     Gurgay
           Barbos sails to KUZU BAY
           TREASURE on Level 1 of THAKASS
     Gherig
           ask YETMISHI in SHIRAN about entering THAKASS
     Ugdobar, wizard
           visit PETKENPIF in SHIRAN, knows of the WHITE AMULET
           SERMIN in South DARVALE
           CUBE PYRAMID PYRAMID    THAKASS     BIHUN
     Tonos, knight
           Don't mess with GAEMS
           Army of Kobolds arrived from Grud
     Fendick, monk
           seek TEMPLE of KALB in DAKLAND
     Sarik, farmer
           feel rain coming
     kid
           I'm really a goblin
           read the rule book
           Hodli ducks are losing their feathers
     kid2
           look at my new shoes
           you must kill monsters
           PIERCE spells in THAKASS
     Feyyuz
           buy BOOTS to walk on LAVA
TOWER
     DAKLAND           5 SQUADS    3 DIFFICULTY
     FIZTRAZ           7 SQUADS    4 DIFFICULTY
     DARVALE           6 SQUADS    4 DIFFICULTY
     ROSUS             8 SQUADS    3 DIFFICULTY
     SELDERAD          5 SQUADS    3 DIFFICULTY
     KHIRISS           8 SQUADS    4 DIFFICULTY
     N. TRILLIAD       4 SQUADS    3 DIFFICULTY
     N. BIHUN          2 SQUADS    3 DIFFICULTY

TELEPORTALS
KHIRISS    x136  y 33
SHENDY     x 19  y 78
KHERBEL    x108  y 86
     SPHERE SPHERE SPHERE    BEDANGIDAR  SHENDY

     SPHERE PYRAMID PYRAMID  BEDANGIDAR  UDAR

     CUBE PYRAMID SPHERE     CREZIMAS    FUBERNEL

     SPHERE PYRAMID PYRAMID  CREZIMAS    SELDERAD

     PYRAMID SPHERE CUBE     CREZIMAS    TRILLIAD

     PYRAMID CUBE SPHERE     DERMAGUD    ISLES OF ICE

     SPHERE PYRAMID CUBE     DERMAGUD    PHERON

     CUBE PYRAMID CUBE       DERMAGUD    SELDERAD

     CUBE CUBE CUBE          DERMAGUD    YBERTON 

     SPHERE SPHERE SPHERE    KHAZAN      PORT AVUR

     SPHERE SPHERE CUBE      KHAZAN      YBERTON

     PYRAMID CUBE PYRAMID    KHAZAN      SHENDY

     CUBE CUBE CUBE          KERBEL      MERG

     PYRAMID SPHERE PYRAMID  KERBEL      FUBERNEL

     SPHERE CUBE CUBE        KHIRISS     FUBERNEL

     SPHERE CUBE PYRAMID     KHIRISS     TRILLIAD/BIHUN
                                          (border)
     PYRAMID CUBE PYRAMID    KHIRISS     SHERTUZ

     PYRAMID SPHERE PYRAMID  MEARDOM     KNESSOS

     PYRAMID SHPERE CUBE     MEARDOM     S. KENDAR

     CUBE CUBE SPHERE        MEARDOM     UDAR

     CUBE SPHERE CUBE        PHERON      BAY OF MERIC

     PYRAMID PYRAMID CUBE    SARGOZ      FUBERNEL

     CUBE PYRAMID PYRAMID    SARGOZ      PHERON

     SPHERE CUBE SPHERE      SHENDY      DAKLAND

     PYRAMID PYRAMID CUBE    SHENDY      UBERION

     CUBE CUBE PYRAMID       SHADRUM     FISESTAR

     SPHERE SPHERE SPHERE    SHADRUM     ISLE OF GIANTS

     SPHERE PYRAMID CUBE     SHADRUM     MARMARIS

     PYRAMID CUBE PYRAMID    SHADRUM     SHIRAN

     SPHERE SPHERE PYRAMID   SUDOGUR     MARMARIS

     CUBE SPHERE CUBE        SUDOGUR     PHERON

     PYRAMID PYRAMID PYRAMID SUDOGUR     SUMRUNA

     CUBE PYRAMID PYRAMID    THAKASS     BIHUN

     PYRAMID SPHERE PYRAMID  THAKASS     KHIRISS

     SPHERE PYRAMID CUBE     THAKASS     SARGOZ

     PYRAMID SPHERE SPHERE   VOCHA      ICE PLAINS

     CUBE CUBE CUBE          VOCHA       MERAM

     SPHERE SPHERE SPHERE    VOCHA       SHENDY

CHANTS:

DERMAGUD 
chant achunne reshiptar ebitonagzi to enter
Chant to awaken GOD: shaerad ude shaerad faey        1

SHADRUM
chant  DAMLAZ  FIRTARAFA  YAKLAMATOFAR 

VOCHA 
chant HOKDE  KAFLTH  POKANDAJO
TEMPLE on KUSKUNN symbol SUN <vocha>               2
chant  EFTAH  EFTAH  YOLIMDAR  PEHRIZ

SUDOGUR
NEED STAR KEY
TEMPLE of SUR <god> x47 y35 <sudogur>
chant YENNA  BENIVO  HEB  BENNA                      3

CREZIMAS
WALK IN
TEMPLE OF HISSEN <SNAKE> <crezimas>                    4
chant TUEM  OBOTEM  KEFLUEM  MAESLEM

KHAZAN
chant EKSAM  RATTABL  GANGAMURT
TEMPLE OF HERU <on fubernel>                           5
chant  VREAMEN EFTAH YOLIMDAR TIZ

BEDANGIDAR
chant SAMANDAX  TIFGARAMO  KEMT
TEMPLE OF PALADIN <MOON> <bedangidar>                  6
chant EFTAH  YENNA  OLIM  TIZ 

TEMPLE TO PAX <EYE> <in rosus>                         7
CHANT ISHTHYAM  SERMIAN  IDELIOZ  OBOTEM
PAX SLEEPS IN PIYAN

TEMPLE TO KALB <MASK> in DAKLAND x101 y 12            8
chant: IDELIOZ  FYDELIA  HEB  THARIMO
KALB SLEEPS IN DAKLAND x 85  y 9

THAKASS 
chant KURAMDAFUR  TEVALATO  REKMETREK
  
SHERRO'S HIGH CALL: SHERRO  HOY  DUMANFIR

ELFEN MAIDENS:
Ellidrin   x132  y 34
Suerfin    x 99  y 66  "Sparrow Song" Increases SPEED
3rd on on Shendy

LEVERS:
X91  Y 26 
X93  Y113

|------------------------------------------|
|                                          |
|     RITUAL OF AWARNESS                   |
|     chant:                               |
|     REHTEM VEREK                         |
|     EKLEM KENEK                          |
|     ELATIR GNASSAR                       |
|                                          |
|     TO MAKE BUBBLE                       |
|     chant:                               |
|     TEFK   AKAMUR   DARDA-IYM            |
|                                          |
|     OBELISKS:  WORDS OF WILL             |
|     1)   SASTAMOUNU                      |
|     2)   EZBEREKENE                      |
|     3)   VRAKKALAMHIR  <X 79     Y117>   |
|                                          |
|------------------------------------------|