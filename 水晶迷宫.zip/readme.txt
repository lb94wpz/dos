I mean no offense to my neighbors across the pond, but I am slowly coming to the conclusion that British game shows are an organized form of public sadism. The Weakest Link, Who Wants to Be a Millionaire, Big Brother, and more are all designed to psychologically tear down contestants. They get the most artfully vicious hosts they can find and design tasks that are either near impossible or pit teammates against each other in subtly immoral ways. Not that it��s better here in America with our Fear Factors and emotionally abusive Simon Cowells (although, we imported him from the UK too). But for the most part his is a new phenomenon in America where as in the UK this has been going on for years. Case in point, back in 1990 a game was conceived that proved incredibly popular during its 6 season run. It was called The Crystal Maze, and now you can have all the torment of the TV game show on your home computer.

I don��t want to give the impression that I didn��t enjoy playing the home game. The worst part was I really enjoyed its eclectic series of challenges. Despite feeling abused by the computer I was determined to make inroads to defeating winning the game. Since I couldn��t find an FAQ for this game anywhere I feel compelled to write a more extensive review than normally appears here. My goal, naturally, is to help others who follow. If you play the game, please use the forums and share what you learn and together we will crack The Crystal Maze!

The point of the game is to collect time crystals. Each time crystal buys you 5 seconds in the Crystal dome at the end of the game for each of your remaining team mates to try to catch as many gold tickets as they can, and avoiding silver ones. If you score a total of over 100 (gold minus silver) you win!

There are 4 zones you will need to visit to collect time crystals before going to the crystal dome; Aztec, Futuristic, Medieval, and Ocean. Each is a theme that will change the games you play. Also, there are 4 game types; Physical, Skill, Mental, and Mystery. Choosing the right player to do the right type of game will make the game easier or harder. Each player has at least one strength and I think I��ve found the strengths of all the characters. Each player also, apparently, has a weakness, although I��ve made no attempt to document those. Choose at least one of each kind before starting to improve your chances. Since the players don��t have proper names, just fill refer to them by where they are on the grid:

Mental	Physical	Skill	Mental
Mystery	Skill	Physical	Skill
Physical	Skill	Mystery	Mental
Not knowing how the game distributes strengths, it��s possible I miss categorized someone. But the Skill category is the most important. Use someone who listed as Skill above on some of the games left and right will be swapped, making it much more frustrating that normal.

Then, when have chosen your team, click on the second button in on the lower right to start playing. This button is usually what you use to advance the game. From here on in I��ll just call this the ��Ok�� button, even though it never really says that. Choose a zone to start. Then click on that ��Ok�� button and choose which player and which game you want to play. Press the ��Ok�� button to advance again and play the game. If you see the dice in the lower right-most button the computer will randomly make a choice for you if you press it but you will still be given a chance to change the computers choices before clicking ��Ok��.

When playing games keep your eye and ear on the clock. When you see and hear that time is nearly out be ready to escape the game by pressing the control and escape key at the same time. (I found in DOSBox under XP pressing control then escape causes XP to catch it and open the start button, but if you pressed escape then control the game catches it and you escape.)

Here is the complete list of games in each zone:

AZTEC
Physical
Raft Jumping Game �C Some variation of a platform jumper exists in every world. In Aztec you��re jumping across moving rafts. I��ve won this platform jumper the most of all the platform jumpers. If you land on the first raft just hold down the jump button until you��re on the other side. Touch the water and instantly be kicked out, no lock in.
Skill
Gag the Gods �C You have a limited number of balls. Aim the chute at the statues mouths and release the balls at the right time so their mouth closes on the ball and they stop moving. Only 3 statues to stop, but timing is difficult. If you run out of balls before the timer runs out you��ll automatically lose, no lock in. Choose someone with aptitude in skill games or left and right will be reversed!
Build a pyramid �C Catch balls in the chute as they pachinko down from the top. If you miss you also lose a ball that you caught. For this reason this one is very frustrating and if you haven��t caught enough before time starts running out escape to avoid lock in. Again, you want someone who��s good at skill games.
Mental
Shape Sodoku �C Organize the board so that no column or row has two of the same shape or color. To add to the difficulty there is an empty spot that shifts as you try to solve it. Be fast or you��ll have to rethink what you��ve done. If you don��t finish in time you will be locked in. The trick is to work in diagonals. Put all the shapes on their diagonal, then rearrange them by color in the other diagonal. Put the last piece in place and you win. But as usual, keep your eye on the clock. It��s easy to get lost and locked in.
Pebble Solitaire �C A triangle of divots in the sand with stones in all but one of them. Jump stones to eliminate them, you win when there��s only one left. You can practice this one out of the game easily enough. If you get to a point where you have no more moves you will lose but not be locked in.
Mystery
Picture Search �C Most zones have one of these. You are given clues and have to find what they point to. A clue like ��this hides on the wall�� means you need to click on the animal hide on the wall. Guess wrong and you lose time. Run out of time and you��re locked in. Here are a few more clues to help you out: ��You found a small key�� means click on the small chest on the table. ��Look underfoot�� means the rug on the floor.
FUTURISTIC
Physical
Platform Jumper �C This one has some very fast spheres that if you touch you die. Timing is difficult but if you do touch them you simply lose and are not locked in.
Skill
Recycle the Electrons �C A high resolution (relatively) version of the snake game that you��ve probably played a hundred times. If you hit a wall or your own tail you��ll lose, but won��t be locked in. However, if you don��t collect all the electrons before time runs escape to avoid lock in.
Mental
Lights out �C Buttons will turn off or on the lights. Figuring out what combination will turn them all out is the trick. It��s very difficult and you usually end up just randomly hitting buttons hoping to see a pattern. I have won this one a few times, but it��s looking hopeless just escape so you don��t get locked in.
Platonic Sequences - A game of Simon with the computer. A sequence of colored shapes will blink and you must click on them in order. If you miss you��ll lose but won��t get locked in.
Mystery
Blackened Maze �C Navigate your token through the maze, but beware because enemy tokens are navigating the maze too and will throw up a smoke screen to confuse you. But you can pass into the darkness without problem and will light the way as you go. But if you don��t get out in time you��re locked in unless you escape.
Picture Hunt �C You should be familiar with this one by now. This time it has a spacey theme.
MEDIVAL
Physical
Snakes on Planes �C (I couldn��t resist.) A platform jumper with snakes. It takes some practice but if you die before time runs out (likely) you won��t be locked in.
Skill
Mind the Wind - Crossbow shoot out 4 targets with a limited number of arrows. You will definitely want someone will skill game aptitude or the controls may be odd. If you run out of arrows before you run out of time you will not be locked in. Use someone who��s listed above under skill or left and right will be reversed.
Mental
Magic Square �C Order the number to form the same sum across, down and diagonal. It��s made more difficult by the pieces being dots not actual numbers like one is used to. If you fail to do this you will be locked in. Below is a grid that will help. No matter the goal, find the lowest numbered piece. Then put that one in the spot labeled A on the grid below. Next, find the piece one higher than it and put it in B, and so on. You��ll win every time:
F	A	H
G	E	C
B	I	D
7 down to 7 across �C Re-shuffle the tokens to spell the word ��CRYSTAL.�� The trick is to learn to slide the ones you have all over (which can be done in one shot by sliding the last in line) so that you can prop others against them.
Mystery
Picture Hunt �C Same as in the Aztec zone but with a medieval theme.
Quiz �C A fortune teller asks you word problems. But be quick, because the time tends to be short. It��s better to guess wrong than let time run out. That way you avoid being trapped.
OCEAN
Physical
Box Jumping �C The boxes you have to jump on don��t go left and right, just up and down. Time your jumps to land while the boxes are above water. But if you aren��t careful you��ll over jump. If you land in the water before time runs out you will not be locked in.
Skill
Walk the Plank �C You have a limited number of tries to guide your dot through the zig-zaging plank. The dot will continue to move in the direction you press until you press in the opposite direction. If you run out of chances before you run out of time you will not be locked in.
Mental
Signal Flags �C Just like the old game you played as a kid, pick two cards and if they match remove them, if they don��t turn them back over and keep going. I��ve never lost this one, but I assume if you can��t do it in time you��re locked in.
Sliding Puzzle �C you are given a picture that you must unscramble before time runs out. So far I haven��t ever seen this one too scrambled up and have always been able to do it in time no matter who I choose.
Mystery
The Crystal is Hot �C A grid of boxes are laid out before you. As you click on a box you will be told if you��re getting closer to the crystal by the usual ��Warmer��/��Colder�� clues. Each guess costs some time. If you don��t find the crystal before time runs out your player is locked in.
Picture Hunt �C Just like in Aztec and Medieval.
THE CRYSTAL DOME
This is the last area you will visit, the point of the whole game. Each time crystal you��ve collected give each free player 5 seconds to catch as many gold tickets as possible, but remember that every silver ticked you catch counts against you. FPS twitch gaming skills are a plus here.
Since every character not locked in gets a chance to get you gold tickets, every locked in character is 5 seconds times the number of crystals you have less time to hunt gold tickets. With that in mind you can buy people out of lock out. Any time before you get to the crystal dome, while looking at the crystals you��ve won or by clicking the information button (a crystal with a red ��i�� on it), pressing the down arrow, and clicking the padlock next to your locked in character. As a rule, you have more crystals than people a buy out will gain you time.

With the information provided above, and some practice, you should have a fair chance at beating the game.

The last thing I want to mention is the settings menu. You get to it by clicking on the button in the lower right with the TV on it. You will then be given a submenu with options that will affect, from top to bottom, audio, input, game play, and a button to save your settings. I highly suggest setting your input options so that you know what your keys are defined as. The default (/,ZA and Space) is a bit odd.

Go back to the options menu and click on the game play button (the one that looks like a time crystal) and you will presented three buttons and a slider. Click the first button on the left if want to play in practice mode. You can replay games without fear of getting trapped which is a fantastic way to get good at them. Unfortunately practice games don��t really count because you can��t enter the crystal maze in the center. The second and third buttons affect the order that you automatically visit the four zones, clockwise or counter-clockwise. The slider affects difficulty. The more to the left it is the easier the game will be. The more the slider is to the right the more it plays like the real thing. 32 is the default.

Some of the things said here are echoed in the manual.txt file included in the game. But this review should provide you with more information that will give the starting player the edge