Gobliins 2 Walkthrough

The Village - Part I
Speak to the Notable. He's the one sitting on the porch. Talk to the two old men with both Fingus and Winkle. You need to get their bottle. Have Winkle try to steal the sausage while he is standing on the ground. While the two old men laugh, Fingus can take the bottle. Go to the Fountain.

The Fountain - Part I
Use Fingus to turn on the fountain. Use Winkle to place the bottle under the jet of water. Use the full bottle of water on the Toad with Winkle. Pick up the stone that was under the frog. Knock on the Wizard's door and talk to him. Have Fingus use the stone on the mechanism. Make Fingus pull down the ladder rung and have Winkle climb the ladder to the roof. Have Winkle enter the chimney and enter the Wizard's house.

The Wizard's House
Talk to the Wizard with Winkle and Fingus. Have Winkle step on the tiger's tail. Take the matches in the tiger's mouth with Fingus. Use the matches to light the fire under the kettle. Pour water in the kettle. The poster will be partly steamed off the wall. Blow the fire out by touching the kettle. Take the spring key. Have Fingus use the key on the cuckoo-clock. When the cuckoo comes out with the big key, use Winkle to throw a stone and knock the key down. Take the big key and leave.

The Fountain - Part II
Open the door of the cellar with the key. Take the wine and go to the village.

The Village - Part II
Use the bottle of water to water the flowers. Make Fingus give a flower to the Notable. Place Winkle on the platform and have Fingus press the switch. When Winkle is thrown onto the roof have him steal the sausage. You can now visit the giant!

The Giant
Use the sausage on the pot hole with Fingus. Take advantage of the moment to let Winkle pass by the dog. Open up the burrow with Winkle and go through the hole in the tree. Have Winkle tickle the chicken and use Fingus to hit him with the sausage. Take the chicken's egg with Fingus and light the wood with Fingus or Winkle. Place the egg on the fire with Fingus. As you are talking to the awakened giant, give him the wine and sausage. Winkle and Fingus can now exit at the top.

The Trench
Enter the small tower with Fingus. After picking up the bomb with Fingus and lighting the fuse with Winkle, the guard will explode. Enter the small tower with Winkle. Pick up the bomb with Fingus and light the fuse with Winkle, the carpet will drop and a hand will catch the carpet. Enter the small tower with Fingus, pick up the bomb with Winkle and transfer it to Fingus so he can light the fuse. The hand will drop the carpet. Walk on the carpet. Go talk to Soka. He will advise you to look for "the sand of time" to cross the trench.

Kael
Have Winkle use the bottle on the nymph to wake her up. Give the tree a drink with Winkle and climb onto the tree's hand. Place Fingus on the rock under the branch. Use Winkle to knock down a flower by shaking the branch and have Fingus ready to catch it. Use the flower on the stone under which the bees live. Use Fingus on the stone. When a bee flies out, Fingus will get honey. Put Fingus on the big rock to the left of the stone and use Winkle on the stone to make the bee come out. Put Fingus on the bee's back. When the bee takes Fingus near the nymph, have him give the honey to the nymph. The nymph will point out the correct mushroom. Pick the mushroom and use Winkle to knock on Vivalzart's door. Show him the mushroom with Winkle and enter his house.

Vivalzart's House
Put the mushroom into the machine with Winkle and activate it with Fingus. When the machine starts, the liquid is blocked by the clothes pin. Take a worm from the jar with Winkle. Place Fingus on the left trap door under the vulture. Activate the shelf button with Winkle. This tosses Fingus to the vulture. While Fingus is hanging, throw the worm to the vulture with Winkle. Fingus will drop with a piece of meat. Give the meat to the piranha who spits out the bone. Place a goblin on the trash can. Take the bone and give it to Vivalzart. When he throws it into the trash can, a goblin will bounce onto the shelf. Get the Kind Elixir and the clothes pin blocking the pipe. The liquid will go into the container. Use the bottle and give each goblin a few drops to drink. Watch the gobliins disappear into a dream.

The Musicians
Put a hand on the headlight with Winkle to recover the drumstick. Make Winkle put the drumstick on the stocking cap to create a net. When you activate the spring with Fingus, a bicycle pump appears for a short time near the drummer. During this brief period, put Winkle's hand on the headlight and put the bicycle pump in inventory. Place a gobliin on the spring. Activate the spring with the other goblin. The gobliins will jump in turn and a door on the left will open. Go through the door.

Water Hose
In the musician room, at the top, the way is blocked by a water hose. Use the clothes pin on the base of the hose with one of the gobliins. Go through the bottom right hole and speak to the guitarist. He plays and a note dies out at the top right. Capture the note with the net. Have Winkle use the bicycle pump to pump up the saxophone player. Use Fingus to catch the mosquito coming out of the sax with the net. With Fingus, use the bicycle pump to pump up the sax player. Use Winkle to catch the note coming out of the sax with the net. Use the mosquito on the headlight with Winkle to make the drummer play. When Fingus catches the last note with the net, you'll have the melody. Use the melody on the bottom left door. It will enter the clock. Go see Tom and he will give you the hourglass.

What do I do with the Hourglass once I have it?
Use the hourglass on the trench in the trench room. Go through the opening.

Gromelon
Get the mayonnaise and put it near Gromelon. Put Fingus on the shelf and make him jump on the mayonnaise. While Gromelon is drenched, pick up the sword with Winkle and activate him on Rustik. When Stalopicus' mouth is open, take the gum with Fingus. Use the gum on the cupboard lock to take an imprint. Take the mayonnaise before leaving.

What do I do with the imprint?
Give the dwarf blacksmith the imprint, then the sword. He will ask for help with the bellows. Use the stool with Winkle on Otto to make him grimace. When he shakes his lance, hang Fingus on it. Fingus can then jump on the bellows and the dwarf blacksmith can forge the key. Take the key from the blacksmith and use the mayonnaise on Focus with Winkle. While the meat is lowered, use the stool with Fingus to take a piece. Take the anvil before leaving.

Amidal
Make Fingus use the meat on Amidal to get his false teeth. Use the key on the cupboard. Each gobliin will take a diving suit.

The Well
Enter the well with Winkle. He will press a button which reveals a door into the monster. Lift the hatchet with Winkle to reveal a switch. Press the switch with Fingus before the hatchet drops back. The monster's door will open. Enter the well with Fingus. When the monster starts to speak, go through the monster's door with Winkle. The combination of the monster's jaw moving and Winkle's voice will stun Schwarzy.

Schwarzy
While Schwarzy is stunned, use the stool on the hoist with Fingus to hitch him to the hoist. Use the false teeth with Winkle to scare Schwarzy, who'll hang for a moment. Throw the anvil at Schwarzy before he comes up. He will go down farther to lift the cover off the well. Each goblin will use a diving suit to go down into the well.

The Ship Wreck
Go on the lower deck and through the door with Winkle to move the skull. Light the lamp with Fingus and a lamp fish will arrive. Catch the lamp fish with Winkle placed on top of the mast. Use the lamp fish on the three question mark zone and a chest will appear.

The Sea Horse
Use the stool on the sea horse. From now on, use the sea horse directly to go up. Send Fingus through the hole on the right. Activate the shell with Winkle, who throws it up, and catch it with Fingus. Send Winkle through the hole on the right. Activate the cavity with Fingus and a gloved hand will emerge. While the hand is stopped, drop the shell on it with Winkle. Pick up the shell with Winkle. He can now take the glove with the starfish inside.

The Big Shell
Place Fingus on the big shell. Light the lamp with Winkle. When the moray eel appears, activate the rudder. This will throw Fingus by the big shell near the statue. Use the starfish on the chest with Winkle. While the chest is open, activate the statue with Fingus to get the sword. Use the sword on the skull. Pick up the diamond.

The Glove, The Blob
Use the glove on the blob to neutralize it. Grasp the bottle with Fingus. The bottle contains a parchment with an SOS message from the Prince Buffoon. Grasp the bottle with Winkle. It contains a pearl. Give the pearl to the mermaid and give her the diamond. The Mermaid will open part of the passage. Use the parchment on the octopus with Fingus. the octopus will open another part of the passage. Recover the glove on the blob and the stool. Exit through the passage.

The Storeroom
Activate the swordfish with Fingus and take the salt. Lift the large pot cover with Fingus. While he's holding it, pour the salt on the little guy with Winkle. Take the file in the small pot with Winkle. While Fingus is holding the rope on the right, activate Winkle on the left rope to pull Fingus up onto the shelf. Free Colibrius from the chain by having Fingus use the file. Colibrius will fly off with his cage. Take one of the thumbtacks on the wall.

Meatballs
Salt the dish of meatballs with Winkle. When Oumkapok's hand grabs the cook, place the thumb tack on the case with Fingus. The cook, in pain, will throw the meatball up in the air. Use the Kind Elixir on the meatball with Winkle. Oumkapok is now neutralized and you can go to the Throne.

The Throne Room
To get to the cornice, use the stool with Winkle and climb using his hands with Fingus. Press the switch with Fingus and make Winkle go through the door that opens in the bottom right eye. Winkle will join Fingus at the top. To take the crown, walk Winkle into the ear and activate the tongue immediately with Fingus. Make a cockroach come out, by sending Fingus into the ear. Activate the tongue immediately with Winkle.

The Cockroach
To catch the cockroach, use Winkle on the left orifice. Immediately use Fingus on the right hole with the glove. Put the cockroach in front of the right hole and pour Kind Elixir on it. Glotziok will eat it and become neutralized. Make another cockroach come out by using Winkle again on the left orifice. Use Fingus on the right hole with the glove to get it. Pick up the pepper and return to the left side of the room. Exit out the door on the left.

The Armor Room
The cockroach must be disguised as a ladybug and coated with the Kind Elixir in order for Amoniak to eat it. Take the helmet feather and dip it in the paint pot. Put the cockroach in front of the hole through which the painter feeds the king. Paint the cockroach red and pour pepper on it. Pour the Kind Elixir on the bug. Speak to the king in the armor. To do this, click on the stone to go up, then click on the helmet. Give the king back his crown by putting it on the helmet to return him to normal size.

When can I rescue the Buffoon?
When Amoniak has disappeared and Glotziok and Oumkapok have silly smiles. You can rescue the Buffoon.

The Armor Room - Part II
Take the Buffoon to the shrinking machine. Put the gobliins under it one at a time. The Buffoon will start the machine and shrink them both. The gobliins will then jump out of the scientist's window.

The Knife
Click Fingus on the handle. Just before lifting it, click Winkle on the point. They will move the knife. Repeat this operation to move the knife again. Click Fingus on the bookmark. Use it on the candle with Fingus. Pick up the match and use it with Winkle on the eye. Click the Buffoon on the eye. He will kick it and break the glasses. Pick up the shard of glass and use it on the ray of light with Fingus. Pick up the lump of wax and use it on the seal. Use the imprint on the keyhole. Pick up the seed and use it on the map village. A plant will grow. Put the Buffoon and the two gobliins on the plant.

How do I get the Buffoon out of the Tree
The Buffoon is hungry and won't come down until he is fed. You can obtain apples for the Buffoon from Kael, the tree. You need to obtain a container first though. Go through the hole with Winkle to get to the Buffoon. He reacts violently and a bean drops. Click on the stone and a mole appears. Use the bean on the mole with Winkle. While they struggle, take the mole's cap with Fingus. Use the match on the apples with Winkle. While the apple is bouncing, use the cap on it with Fingus. Use the apple on the hole with Winkle to give it to the Buffoon. He comes down and rushes to the mushrooms. In turn, the two goblins eat the mushrooms.

The Toy Room
Use Fingus on the bowling pins. As the bowling ball arrives, put Winkle on the right star so he can jump on the ball and intercept it. Put the bowling ball on the lid with Winkle and place him on the lid too. Activate the bottom flagstone with Fingus. The safety pin drops and lands on the umbrella. Catch another bowling ball. Put it on the lid. This time, place Winkle on the catapult at the bottom left. Activate the bottom flagstone with Fingus. Use Winkle on the feeler and make him jump on the bubble. The bubble will float down with him onto the lid. Activate the bottom flagstone with Fingus. When the bubble is blown towards the umbrella Winkle can take the safety pin.

What do I do with the safety pin?
Catch another bowling ball. Put the bowling ball on the lid and put Winkle on the catapult. Activate the bottom flagstone with Fingus. Make Winkle go up and activate the top flagstone after placing Fingus on the flagstone at the rainbow's end. If necessary, Fingus can be returned to the bowling pin side of the room by using the catapult. Put him on the catapult and have Winkle jump from the star on the left onto the catapult. Activate the switch with Winkle to make the Buffoon fall. In the short time he's in the bubble makers circle, quickly use Fingus on the feeler to enclose him in a bubble. Make Winkle burst the bubble with the pin to free the Buffoon.

The Buffoon in the Tree - Part II
Place the Buffoon on the catapult. Press the button with a goblin. Once the key comes out of the statue's eye, activate the catapult with the other goblin. As the Buffoon is catapulted up, he will grab the key and be taken away by a bird. Exit at the rear of the scene.

The Mountain
Have one goblin lift the stone. Situate the other goblin on the upper platform. The goblin should take the stone and put it on the 2nd level. Repeat the operation to put the stone on the 3rd level. Place a goblin on the lion. Throw the stone from level 3 with the other goblin. When the first goblin is on the giant's right shoulder make him act on the red head, which falls off. Come down and take the stone to level 2. Place Winkle on the lion and throw the stone from level 2 with Fingus. Winkle will be placed on the giant's left shoulder. Go through the shoulder hole and bring him near the fallen red head. Place Fingus on the lion and activate the head with Winkle. Fingus will land on the levitating rock.

The Levitating Rock
As Fingus lands on the levitating rock, move him to the rock's !!! zone. When he starts jumping, the rock will descend. When the rock gets to Winkle's level, make him jump on it. The rock will rise. Use Winkle on the small rock near the bird cage. Quickly make Fingus walk on him. Use the file on the cage with Fingus and get back the key.

How do I open the gate in the Tree scene?
Use a key on the door.

The Lab
Use water on the Buffoon. An evil creature will take him to the Kingdom of Gloom and Doom. Have Winkle take the pencil and use it 3 times on the blackboard. Take the sponge which the furious magician throws at him. Have Fingus use the pencil on the magician's portrait. While he's being hit by the boomerang, jump on the armchair with Winkle to catch it in flight. Make Winkle use the mug on the magician who will bang on the table. He'll knock a toothpick to the other side of the room. While the toothpick is still bouncing, make Fingus throw the boomerang.

What do I do with the Toothpick?
Have Winkle use the toothpick on the skeleton to open the rib cage. A bottle will smash on the ground leaving a puddle. Use the sponge on the puddle. While Winkle acts on the pipe, use the wet sponge on the smoke with Fingus. The way to the Kingdom of Gloom and Doom opens. Send the gobliins through.

The Kingdom of Doom and Gloom
Place Fingus on the bottom right eye, and Winkle on the left edge (with the !!! marks) of the top right platform. Winkle will jump and Fingus will be thrown. Pick up the mouse and use it on the mud. Jump on the crocodile. As Amoniak reaches to catch the goblin, use the boomerang with the other goblin on the teeth. This will cause the Buffoon to fall. Before the little demon can send the Buffoon back to Amoniak, make a goblin jump from the left edge (with the !!! marks) of the top right platform. The eye will pop out and hit the little demon.

The Buffoon and the Sponge
Put the sponge on the rock. Place the Buffoon on the eye and make Winkle jump from the left edge (with the !!! marks) of the top right platform. This throws the Buffoon onto the sponge which wets the rock. As the water flows, use the pencil with Fingus on the rock. He draws a magic door which lasts a short time. Make Winkle turn the handle. The heroes go out the door and you have won the game!