      |     (    (   | |   | |   |  __/\__ \ |
                  _____|\___|\___/ \__\_\\__,_|\___|____/\__|


                      ~ EcoQuest: The Search for Cetus ~ 
                 An Educational Adventure Game for DOS/Windows
                         FAQ/Walkthrough by Bananagirl
                              bananasquid@msn.com
                                v1.0 - 08/07/02



                                  Disclaimer!
                                  ```````````
                This guide is ?2002 bananagirl. All information
                contained within is protected by copyright law.



===============================================================================
                    .:*~*:.  < Table of Contents >  .:*~*:.
===============================================================================

1. Introduction
2. Game Basics
     o Controls
     o Menus
     o Saving/Loading
     o Story
     o Characters
         > Adam
         > Delphineus
         > Cetus
         > Flesh-Eater
3. Walkthrough
     o Adam's House
     o Dolphin Lab
     o Ocean
     o Eluria
4. FAQ
5. Revision History
6. Copyright & Contact Information
7. Credits/Thanks



===============================================================================
                     .:*~*:.  < 1. Introduction >  .:*~*:.
===============================================================================

Howdy, and welcome to my EcoQuest: The Search for Cetus guide. My name's 
Bananagirl, but you probably already knew that. I'll be helping you through 
the game with this here guide, taking you step-by-step through each area of the
game. 

I first played EcoQuest about 8 years ago. A friend of my mother's was quite
fond of computer gaming, and lent me her disks. I played through the game, 
then foolishly left the disks out, and they were ruined. This was, of course,
not a good thing. Fortunately, the person I had borrowed the game from had
completed it before, so it was not a total loss. I'm sure she was mad at me,
though.

For 8 years, I have searched far and wide for the game. I've checked every 
store that sells similar games that I've been to since then. I've posted a 
request for the game on numerous abandonware forums. I've searched the internet 
for both abandonware sites and software dealers. And finally I found it. No, I 
won't tell you where. Even though this game is no longer being published and is 
therefore no longer a source of income for Sierra, it's still illegal to 
download copyrighted work and all that. So no, I won't tell you where I got it.

And with that in mind, I'm off to get started. If I say anything insulting in
here, I'm kidding. I don't seriously insult people I don't know. Most of the
time [insert evil laugh here].

     - Bananagirl



===============================================================================
                     .:*~*:.  < 2.  Game Basics >  .:*~*:.
===============================================================================
                                    Controls
-------------------------------------------------------------------------------

EcoQuest uses Sierra's point-and-click interface of the early 90s. Your cursor
has six different options, which you can switch between by pressing your right 
mouse button. Clicking on an object or area with the left button will trigger
the action you've selected.

The actions (and their corresponding icons) are as follows:
   > Walk/Swim..............Body
   > Look....................Eye
   > Touch/Take.............Hand
   > Talk..........Speech bubble
   > Item...................Item
   > Recycle......Recycling sign

Most of the controls are pretty much self-explanatory, so I won't insult your 
intelligence by going into too much detail.

- Walking (or swimming) is used to go from place to place. It is sometimes 
  used to trigger events. 

- Looking is used to examine objects, or to trigger puzzles, view diagrams,
  and other such things.

- Touching things can trigger puzzles, switches, and other things. Taking 
  something will add it to your inventory and will automatically be selected.

- Talking to things or people triggers events, as well as providing hints, 
  clues, and other such things.

- Items can be used for countless things. The item displayed in your cursor is
  the one you have selected from your inventory. Any item you pick up is 
  automatically selected, but can be changed by choosing a new item in the 
  inventory.

- Adam will pick up a recycling bag early in the game, and by using the 
  Recycle cursor, Adam can pick up trash and help make the world a better 
  place. And get points, too.

- Sometimes a simple arrow cursor will be displayed. This acts just like any 
  other pointer cursor you've ever used.

- A dolphin is displayed when loading or cutscenes occur. This is the wait 
  cursor, so when that's displayed, sit back and watch. There's nothing you 
  can do.

- When you click on a question mark in any of the menus, a question mark icon
  will be displayed. Click on anything with that icon to see a quick 
  description of its function.



-------------------------------------------------------------------------------
                                     Menus
-------------------------------------------------------------------------------

EcoQuest's menu system is accessed by moving your cursor to the top of the 
screen. Doing so will display the menu bar, which has 9 different options. 
The first 5 change your cursor: Walk, look, touch, talk, item. The next one, 
however, takes you to your inventory.

The inventory is set up much the same way as any other adventure game you 
might have played. A graphic of each item is displayed. Underneath them, you
can see 5 options. The first 3 are cursors: Look, touch, and select. Clicking
on the select cursor, then an item, will select that item. Go figure. The next
one, a question mark, is the help icon, which is also available in the main 
inventory system. Clicking on this, then another option, will tell you what
each one does. Finally, we have the OK button. After choosing your item, click
here to go back to the game. 

After the inventory option, you'll see another cursor changing button. This 
one changes it to recycle. Nifty, eh? Yep. 

The next option on the menu bar is the system controls menu. From here, you 
can change the volume, speed, and detail of the game. You can also save, load,
restart, and quit from here. There are two more buttons displayed. One is a
question mark (which acts the same way all the other question mark icons do),
and the other is the Sierra logo. Clicking this will show you the other games
by Sierra, as well as the credits for EcoQuest.

The final option is the question mark. Click on it, then on anything else on 
the menu bar, and you'll see what it does. 

Moving your cursor down, the menu bar will go away, and you'll be able to see 
the full title of the game and the amount of points you have. Points aren't 
really necessary. They're just there to add a neat little challenge to the
game. 



-------------------------------------------------------------------------------
                                 Saving/Loading
-------------------------------------------------------------------------------

To save your game, access the system controls menu and click the save button.
Choose your directory (the game defaults to the folder in which you installed
the game), name your game something descriptive, and press save. Boom. Game
saved. 

To load your game, go to the system controls menu and choose load. Go to the
directory in which you saved your game and choose the file you want to use. 
Press load. 



-------------------------------------------------------------------------------
                                     Story
-------------------------------------------------------------------------------

A young dolphin named Delphineus set out on a search for the missing king of 
his land, Cetus. In his rush, he ran head-on into an abandoned fishing net and
became entangled in it. Unable to reach the surface for air, the dolphin would
have surely died, had he not been rescued by Dr. Noah Greene.

Dr. Greene kept the dolphin in an area designed for the recovery of such 
creatures. He, along with his assistants and his son, nursed the animal back
to health. It is here that the game picks up...



-------------------------------------------------------------------------------
                                   Characters
-------------------------------------------------------------------------------

Adam:
`````
 Adam is the 12 year old son of Dr. Greene. He's pretty big on science and the 
 ecosystem, and highly concerned about the state of the planet. Along with his 
 father, Adam does everything in his power to keep the enviroment clean and 
 safe and stuff. Cheers.


Delphineus:
```````````
 Delphineus was found in a fishing net by Adam's father and was nursed back to 
 health in his holding tank. Delphineus accidentally reveals his ability to
 speak while playing with Adam, and after being released, returns to ask for
 Adam's assistance.


Cetus:
``````
 The leader of Delphineus' kingdom has been missing for weeks. It is while 
 searching for him that Delphineus is caught. That leaves it up to the dolphin 
 and his human friend to locate Cetus and save him from whatever is preventing 
 him from returning to his kingdom.


Flesh-Eater:
````````````
 While most manta rays are relatively gentle, Flesh-Eater has made a habit out
 of feasting on Elurians. With Cetus gone, there's nothing to protect them from
 this threat.



===============================================================================
                     .:*~*:.  < 3.  Walkthrough >  .:*~*:.
===============================================================================
                                  Adam's House
-------------------------------------------------------------------------------

After Adam's father has finished speaking, he will prompt you to help him with 
the seagull he rescued from an oil spill. Walk over to the box, and you'll 
trigger another conversation. Examining the seagull will reveal that it is 
shivering and coated with oil. You get to help clean it off. Pick up the 
detergent and the clean rag from beside the box. You'll have to combine these 
two items to make another one. Just go into your inventory and click on the 
detergent, then use that item on the clean rag to create a soapy rag.

Using the soapy rag, click on the gull. Adam's father will start washing it, 
then hand it over and give you a few pointers on oil removal. Within a few 
moments, the seagull will be shiny and clean and white. Like my teeth. 
Conversations like the one Adam and his father have after the bird is clean
help to make this game the educational adventure it happens to be.

Dr. Greene will hand over a solution for getting rid of oil, telling you to use 
it on the coral, then leave for a meeting. You're all alone now. Before you 
move on with the game, there are a few things in the house that can be done to 
get some points, as well as netting you some nifty cool things.

The first order of business is to do what your father said. Right behind Adam 
is a fishtank with a bit of coral in it. Use the fertilizer solution on the 
coral, and the water will become crystal clear. If you examine the gerbil cage 
beside the tank, you'll see the poor li'l guy begging for water. So pick up the 
water bottle beside the cage and use it on the gerbil. He'll dance for you. 

After you've watered the rodent, turn around and have a look at that rug. It's 
shaped like the Earth. Occasionally, a fish or a periscope will pop out of it. 
Talk to the rug. If you click on different regions, you'll be greeted in 
various languages. I particularly liked the American's.

If you look over at the computer, you'll notice a bookshelf above it. Look
at the books 5 times, and you'll get a few points. And some interesting 
titles. Vegetarian Macrobiotic Cooking? No comment. Once you're done there, 
look at the computer. It tells you to check the chalkboard. So check out the 
chalkboard behind the gerbil's cage. Take notes. You'll be needing the 
information in that diagram later in the game. Might I recommend a quick 
sketch, or perhaps a screenshot?

Examining the computer again will launch into King's Quest V, another game 
released around that time by Sierra. Adam can't play it, though. Too bad. It 
really is quite a good game. You should buy it if you haven't already. I have
three copies of it. None of them work.

Check out the computer chair. There's a letter to Adam on it. Pick it up to 
open it, and Adam will receive his membership card and certificate. He can play 
with the dolphin without breaking any laws now. Make sure you pick up the 
envelope again to throw it out. Grab the empty can from the desk and toss it 
into the recycling bin, then grab the garbage bag lying on the floor nearby.

You've done all you can in here for now (your total should be 72 points), so
it's time to leave. Walk over to the door in the back of the room and use your 
hand cursor on the security pad. Doing so will bring in a close-up of it. Enter 
your four digit security code, then hit the E at the bottom to input it. This 
is Sierra's anti-piracy thing, so I can't tell you the code. Check your manual 
or something. You'll know you got it right if the light turns green and the 
door opens. And don't bother emailing me if you didn't buy the game or you 
"lost your manual" or something ate it or whatever. I'm still not telling.



-------------------------------------------------------------------------------
                                   Dolphin Lab
-------------------------------------------------------------------------------
Before you do anything else, you'll want to check that blackboard over in the
corner for instructions. It's generally not a good idea to try to nurse an
animal back to health if you have no clue what you're doing, so you should  
actually read it, rather than just clicking on it for the points. If you don't 
do the instructions in the correct order, you'll have to start over from the 
beginning.

Start off by talking to the dolphin. Adam will decide what to say; you just 
need to click the talk icon on it until you've earned its trust, which should 
only take about 3 sentences or so on Adam's part.

Once you've gotten the trust message, you'll have to feed him. Pick up a fish
from the bucket in the corner. When the dolphin swims around, it will 
occasionally stop and face Adam. This lasts about two or three seconds. When he 
is in this position, click the mackerel on him to throw it. Do it again. You 
can keep doing it after this, but he'll just throw it back in the bucket.

When the dolphin's full, it's time to get in and play with him. Click the hand 
icon on the ladder to make Adam get in. From there, the dolphin will swim 
around a bit, then offer his fin to Adam. Take it with the hand icon. 

After the ride, climb back out and pick up the frisbee from the counter. Throw 
it at the dolphin, who will jump up and catch it, then throw it back. Click on 
the frisbee while it's flying back to you to catch it. It has to be fairly 
close to Adam, or he'll miss it and say, "Rats! I almost caught it!" The fourth 
time Adam throws it, he'll run over to the other side of the pool (assuming you 
were throwing from the side with the blackboard), and the dolphin will respond 
a bit... differently. Zounds.

It's safe to throw the frisbee a few more times before Delphineus leaves, so go 
ahead and get the points for it. Of course, you can only play with a frisbee 
for so long before you start imagining things. You probably won't want to get 
that back.

Gotta get him outta there now, so climb out of the water using the ladder and 
run over to the right side of the pool where Delphineus is waiting. There are 
switches on both the inside and outside of the water here. The inside switch 
can be used by the dolphin to close the inner gate if it wants to be alone, but 
the outer switch will free him. Have Adam flip that, and Delphineus is on his 
way home.



-------------------------------------------------------------------------------
                                     Ocean
-------------------------------------------------------------------------------

A few days have passed since you last saw your li'l dolphin buddy, and Adam is 
sitting on the dock looking bored. Of course, there's no way the game can be 
over already, so logic denotes that something's gonna be happening here pretty 
soon. Watch the horizon. Hey, wait a minute... if it's been a few days, why is 
Adam still wearing the same shorts? 

You've got to go rescue Cetus, but you can't very well do that as you are now. 
Go back to the dolphin lab and open the cupboard under the chalkboard, then 
take the diving equipment inside. You might notice that a tracking device is 
also included in the lot. You'll need this later.

Go back outside and use the diving equipment on Adam. He'll empty his pockets
(including the mackerel he picked up a few days ago, if you got an extra one)
and put on his gear, then jump into the water. Out on the open sea, swim north 
once. You should see a barge. Swim up to it. As you can see, it's leaking oil 
and trash. Not pleasant. Ignore the kid with the balloons for now and have a 
look at the trash. 

You really only need to pick up enough to clear a path, but you might as well
do your part to save the enviroment. Recycle everything you possibly can. Adam 
will keep the jar, but the rest of it is trash. Once you've cleared the area of 
everything disposable, swim west, put on your oxygen tanks, and prepare to 
navigate the seaweed maze. Delphineus isn't feeling so hot, so it's up to you 
to get through it. To do so, swim south, then east, then southwest. Once you 
get through, you will reach Eluria.



-------------------------------------------------------------------------------
                                     Eluria
-------------------------------------------------------------------------------

Delphineus will tell you to see the Oracle, so you should probably do that 
before anything else. First, however, clear out the trash littering the area. 
The steel basket can be salvaged, but everything else that looks trashy is 
worthless, so you might as well toss it all into your bottomless garbage bag.

When the area is cleaned up, go into the large building on the right side of 
the screen. This is where the oracle lives, but you'll have to solve a few
puzzles to get to her. The first one is the sliding mural, which is found on 
the wall. Click on it to look closer.

Random clicking can get you relatively far in adventure games, but if that 
isn't working for you, let's assume it's all on a grid, with 1 in the upper-
left corner, 4 in the upper-right, 9 in the lower-left, and 12 in the lower-
right. A working order could go something like this... 9 5 6 2 3 4 8 7 3 2 6 7 
11 12 8 4 3 2 1 5 6 10 9 5 6 2 3 4 8 12 11 10 6 7 11 12 8 7 3 2 6 7 3 4 8 7 3 2 
1 5 6 7 8 12. If you've got something shorter, by all means, send it in!

With the puzzle in place, take the shell sitting on the pedestal in the middle 
of the room, then leave the building for the time being. Outside, click on the 
statue of Poseidon (the guy with the trident) to examine it. That guy kneeling 
in front of Poseidon seems to be cupping his hands as if he's missing something. 
Hm... Bronze statue. Bronze conch shell. Make the connection. Give the servant 
the shell you picked up in the Oracle's temple.

After the servant blows the shell, Poseidon will let go of his trident. Take it
and go into the temple. On the back wall is another mural with three eyes. Adam
can only poke 1 in at once, but with the pronged trident he can get all three.
Once all three eyes have been depressed, a panel will slide up, revealing the
Oracle. Talk to her.

In order to prove your lack of stupidity, the Oracle will ask you three 
riddles. These are answered by pointing at parts of the mural you descrambled
earlier. Don't read past this point if you want to solve the riddles by 
yourself. I'm going to give the answers away. Stop reading now. It's not my
fault if I ruin it for you. You just did it to yourself. 

Man, Fish, Love. Between answers, the Oracle will tell you about Cetus, the
evil stingray that's been terrorizing Eluria, and the events that caused Cetus'
disappearance. When that's all over, she'll tell you to bring her some sign of
the citizens' trust. And that's that. Head out of her temple and go to the 
building beyond it. 

Inside, speak, and the Great Senator will challenge you to solve the puzzle of 
the columns. This is actually pretty easy, since you just need to click on all 
of them a few times until something snaps into place and then do it again and 
again until everything has snapped. Even so, the correct order is as follows...

    A   B   C
1  --- --- ---  
2  | | | | | |   [B2, C3, A3, A2, B3, B1, C1, A1, C2]
3  --- --- ---

When your done, the room will shake, and the golden mask on the wall will fall,
revealing... Superfluous, the hermit crab mayor. He doesn't have much to say, 
so you'll have to go off and do something else for awhile. Don't worry. We'll
be back.

Leave the mayor and go outside. Head east from the courtyard to reach the 
Gardens. Before you do anything else, use your trash bag to clean up all the
garbage littering the area. When the area looks clean, pour the remainder of 
the fertilizer solution your dad gave you on the oil-soaked coral that 
dominates the area. Doing so will bring out the Keeper of the Gardens, which is
good, 'cause Delphineus told you to speak to her. 

After hearing your story, she'll give you a healing potion. As she leaves, an 
oil-coated shell will drift down. Pick it up, then use your recycling bag to 
clean up the area, effectively doing your part to save the underwater 
ecosystem. Great! Head north to the Fish Apartments.

You'll run into Delphineus here, and he'll drop some not-so-subtle clues as to
how to earn the mayor's trust. Ignore him and grab the white cloth in front of
the apartments, then clean up. Delphineus will leave for the surface. You're
alone again. Use the cloth you just picked up to clean off the oil-coated shell
you found in the Gardens (now you've got an oil-coated cloth instead), then go 
east and visit Superfluous again.

Give the mayor the clean shell to earn a deputy badge. Leave the building. As
you do so... Luckily, Delphineus has mad tail-swatting skillz. Adam will live
to tell his tale. Go back to the Fish Apartments.

Try to go into one of the apartments. The watchman will pop out and refuse to
let you in. Show him your badge to get access to the residences. As you finish
up, a blowfish will dart into a plastic bag and inflate. Push on it to get it
out of the window, then pull it off. In return for saving his life, the 
blowfish will give you some urchins. Adam will pocket them (yowch!). Recycle
the plastic bag and leave Narcissus' apartment. Go visit the one in the lower
left corner.

Inside, talk to the tropical fish. Epidermis will tell you that he's leaving, 
since the only plants he can eat are being attacked by algae. Use your urchins 
on the plants to clear up that little problem, and he'll give you a sharp shell
from his collection. Go outside and head for the rightmost apartment in the
middle row. 

This apartment is occupied by a sturgeon who's gotten his nose stuck in the 
rings of a six-pack. Use the sharp shell from Epidermis to free him. He'll 
give you a pair of tweezers, then leave for the meeting. Pick up the rings and
use the shell to cut them up. Adam will recycle the pieces. Exit this apartment 
and go to the one above it. 

Recycle the balloon on the floor, then try to pull the string on the one 
dangling from the turtle's mouth. When it breaks, whip out your tweezers for 
some mad throat unclogging action. Erroneous will give you four screws to 
dispose of, then swim off to the meeting. Recycle the second balloon and go 
visit Gregarious. 

Talk to the manatee to see why he's so blue, and he and Adam will go up to the
surface together to see about those propellers. When you reach the boat, talk
to the fisherman. Go into your inventory and mix the screws Erroneous gave you
with the metal cage you picked up from Eluria's courtyard, then use the cage on
the boat's engine.

Just two more people to get out, and you've already helped one of them. Recycle
the new trash and pick up the pump lying on the ground, then go into the last
lit apartment aside from Gregarious'. 

Recycle the bleach bottle propping up the table and use your pump on the window
to clean out the room. When Olympia wakes up, Adam will talk her into going to
the meeting. She'll give him one of her baby spines as a gift, then swim off.
Follow her. 

When the meeting ends, it's time for you to visit the oracle again. You now 
have a sign of the citizens' trust in the form of the mask Superfluous gave 
you, so use Poseidon's trident to open up her panel and show her the mask.

She will give you the following prophecy:

 "In the place where shadows creep,
  Rests the poison of the deep. 
  What came from man must now return,
  Lest the Kingdoms die, the oceans burn. 
  Held hostage is the King of Peace, 
  None shall be safe 'til he's released.
  Only Love can face The One Most Vile.
  To save us all - a human child."

To fulfill this, you'll need the following:

 "Armor for a modern knight,
  From the depths a glowing light. 
  A net of bones, a wall of stones, 
  A floating orb, a silver wire,
  Will help you in a place most dire."

Leave the temple and go south then east.



-------------------------------------------------------------------------------
                                  Coral Reef
-------------------------------------------------------------------------------

Before doing anything else, pick up all the trash in the area and snag the 
mirror lying on the ground. When you're done, go right and climb up into the
hole near the edge of the screen. Woohoo, pirate treasure! Open the chest. Bit
of a let-down, eh?

Pull the pike out of the pirate's chest, then pull again. When the key falls
into the water, follow it. As you try to pick it up, a fish will dart out and
swallow it. Chase it! Just when it seems like you've got it cornered, it will
dart off again. Follow it, but grab the lure hanging from the steel support 
column as you go past. 

When you lose the fish, the anenome will be burping. Use your lure on it, and 
it will spit out the key. Hey, that's the way the foodchain goes. Pick up the
key and go right. Use your jar on the dark hole and hide in the sponges in
front of it. The octopus will open it up, then go back into his lair. Grab the
jar and use your mirror on the octopus to send it off in an inky terror. Steal
the cable it was guarding and go left two screens. 

Use your jar on the glowing ear of the statue head. Now you've got a fish-in-a-
jar. Go back to the reef and head to the screen in which you found the lure.
Have Adam use the trident on the toilet to pop open the lid and take the toilet
float inside, then open the storage compartment behind the seats of the sunken
maintenance vehicle. The hammer will crumble, but you can take the steel saw if
you're up to it. Head to the cave in the east and go inside.

Use your fish-in-a-jar to get some light in the place, then check out the 
stalagtites or stalagmites for a Space Quest plug. Check out the wall of stones
on the right side of the cave, and start pulling them out. When you've made an
opening big enough for Adam to fit through, the light will strike something 
hidden in the rocks. Take a gander.

The box is locked, but we've got the key from the pirate in our grubby little
pockets. Open it up and... well, dang. The lock's rusted. Lube it up with the
grease-coated cloth, then try again. Now, does anyone find it a bit odd that
the key to this box containing modern protective gear is stuck on a pike used
to impale a pirate hundreds of years ago?

Anyone, pick up the gear and put it on. Go into the cave. Open your inventory
and start making some sort of signal for a clean-up crew. Attach your float to
the radio transmitter, then the cable to that, and tie the whole mess to one 
of the barrels. When the barrels are gone, exit the cave via the northern hole.



-------------------------------------------------------------------------------
                              Flesh-Eater's Domain
-------------------------------------------------------------------------------

Let's not get into the logic of harpooning through the cabin of a boat. Take a
look around instead. As Adam admires the whaling vessel, Delphineus will point
out the glowing eyes watching them from the dark cave in the distance. OK, 
don't panic, just swim... D'oh. Use the sharp shell to cut Adam out of the 
driftnet. You'll have to free Delphineus later. 

Make your way back to the whaling boat and use the trident to pry open the 
door. Swim through the boat and follow the rope. When you get to the end of it,
talk to Cetus. Go into his mouth when it opens and use your hacksaw on the end
of the harpoon. Get out of the mouth and pull out the harpoon, then apply the
healing potion from Demeter. Now it's time to save Delphineus and end this 
whole adventure.

Head to Flesh-Eater's cave and go in. Use your sharp shell to cut away the 
drift net, freeing Delphineus. Go back outside. When the manta gets close to 
you, use the lionfish spine on it. Congratulations, you've saved the underwater
kingdom of Eluria. A hero is you!!!



===============================================================================
                         .:*~*:.  < 4.  FAQ >  .:*~*:.
===============================================================================

Q. What's the code for the security door?
`````````````````````````````````````````
   Check your manual.


Q. Can I ask you something?
```````````````````````````
   Please do. This section could stand to be majorly beefed out, y'know. 



===============================================================================
                   .:*~*:.  < 5. Revision History >  .:*~*:.
===============================================================================

v1.0 (08/07/02)
```````````````
The walkthrough's all done. The game is too buggy to make it worth my time to
make a point list, so look elsewhere. Sorry. I'm a slacker.



===============================================================================
               .:*~*:.  < 6. Copyright & Contact Info >  .:*~*:.
===============================================================================

This document is copyright ?2002 Bananagirl (bananasquid@msn.com).

This document was written exclusively for use on the internet. It is not
intended to be used in any way that is profitable for anyone, including the
author. It is not to be reproduced in any way without express written permission
from the author.

The information found within this document is, to the best of the abilities and
knowledge of the author, 100% accurate. However, the possibility exists that
inaccurate information may be found within. Any errors (human, computer, or
otherwise) should be reported to the author as soon as possible.

EcoQuest and all characters, locations, etc., are trademarks of Sierra On-Line 
The author makes no claim to the creation of these. This document can only 
legally be found at http://www.gamefaqs.com.

Don't email me if you don't have anything constructive to say. I don't want to
have to hate you, but I might just do it if you give me a reason.



===============================================================================
                    .:*~*:.  < 7. Credits/Thanks >  .:*~*:.
===============================================================================

Author
``````
Bananagirl (bananasquid@msn.com)


Thanks to
`````````
- The only site on the 'net that actually has it.

- My pants.

- My mother for making said pants.



-------------------------------------------------------------------------------

                                        iLfj:
                                        K   jf
                                  ;LLfjjW    LLGLLf:
                                 GDi;;;t#     W;;;;E;
                                .ELLLL;tK     KLDfjLt
                                     tGEi    f#t
                                     D#f     E,
                                    jWK  jLfLEf;
                                   tWiWEKGj;;;;jD:
                                 .GD;,,,,,;DEt;;iK
                               .fKi,,,,tKttE.Dt;;Dt
                             .fEt,,,,tDL,fG. .W;;Ki
                          :tGGi,,,;LDf,iEt    K;tK
                        tDLi,,;tLDGi,;DL.     jLE:
                        iDfjfLft;,;fLj.
                            #:,,,:##
