Waxworks walkthrough by Sebatianos
sebatianos@yahoo.co.uk

General:
It doesn�t matter in what order you enter the waxworks. All the items are used only in that
particular exhibit. When you complete the first one, you�re uncle�s manservant will start
pushing you around, so you need to move quickly to the next exhibit. Before entering the
exhibit you can read the plaque and find out more about the world you�re about to encounter.


   Pyramids:


There are quite a few enemies scattered throughout the maze. Once you get the dagger you
should use it as your selected weapon (you do that by clicking on the hammer icon). As soon
as you kill an enemy with a better weapon (a sword or a spear), you should collect that
weapon and use it (you really need to fight a lot, but you can get through without restoring
your health). For attacks try clicking on either the head or the stomach of the enemy. It�s
advisable to save often (just don�t forget where in the maze you were before saving). If you
talk to uncle Boris he will tell you what you need to do in order for him to heal you (but
that�s not really necessary if you�re good enough with the fighting). There are also two kinds
of traps. There are wires running across the corridor and stone blocks that trigger a giant
bolder. You should click on the wire and select avoid then you can safely continue. When you
activate a bolder (and there�s no way to avoid this), you need to get out of its way (so save
first and figure out a safe place to hide).

1st floor
Enter the first room on the right and pull the knife out of architect�s back. Search the room
(click on everything and if the option look in appears, look in). You still need to find a
scarab and a weight. You'll also need to grab the jar of oil, and the lit lamp and all the
jugs. Next you'll need to collect the two piles of sand. Now get the 440Hz tuning fork, which
is hidden in a pot. Use the 440Hz tuning fork to destroy the glass wall.  Go to the room with
riches and collect the tile and find yet another weight. Now go to the stairway that leads to
the 2nd floor. The algebraic puzzle begins a countdown when you touch a tumbler, here�s how
the numbers should be:

               8
          8         4
             7   2


2nd floor
First you need to collect the hammer and yet another weights. Now go down to the 1st floor and
knock down the support beam. Now go back up and collect the 261.63Hz fork. You should also find
a pot with entrails inside. Now find the next tile. Return to 1st floor and go to the room
filled with water. Drop the entrails and step back. Attack the crocodile with the spear. After
he�s dead fill the jugs with water. Be careful, you don�t have the spear anymore, so you�re
unarmed at this point (collect a spear and select it as your weapon again). No go to the 2nd
floor and knock down the wooden beam and continue to the hot coals. Empty the jugs on the coals
and cross them. The second puzzle (leading to the 3rd floor) is much simpler. You need to switch
the taps and make sure the jar with the ankh fills faster than the one with the snake.

3rd floor
Use the 261.63Hz tuning fork to break the glass wall.  Knock out the support beam, but make sure
you're on the EAST side of it (otherwise you�ll trap yourself). Get the third tile. Continue to
the pot hanging from the ceiling. Put the sand in the jar to open the secret passage. Collect
the next fork (415.3Hz) and get the rock. Before entering the bow and arrow room you need to
throw the rock to activate the trap. Leave the rock and get the bow and arrow.

4th floor
Collect the 369.99Hz fork and go down to 3rd floor and destroy the glass wall you couldn�t
before and use the same fork on the very next glass wall. Find the 329.63Hz fork and go back
to the needle room. Fire your arrow (with bow) and the stone needle should bridge the gap. Use
the 329.63Hz fork on the glass wall. Knock down the next support beam and go to the Life room.
I�m not quite sure what you need to do to cross the stones, so here�s how I did it. When you�re
close enough you look down and see the stones. SAVE!!! Select a stone and if you can move on it
it�s the correct one. If it kills you, it�s the wrong one (load the saved game). When you find
the correct stone ? SAVE!!! Basically you need to save after each correct step. If you start
from the beginning of the room, the arrangement of the stones will change. So this will require
a lot of saving and loading, but I�m not sure how else you can cross. Proceed to 5th floor.

5th floor
Trigger the gas and face the mirror (on the wall). Destroy it with one of the forks (I think
it�s the 329.63Hz). Find the body and collect the amulet. Notice the symbol order on the first
mural that reflects the symbols on the tiles (note this down). Proceed to the mural room.
Attack the mural to punch a whole in it (so you can pass). In the room with the tile, first
drop the jar of oil on the ground, then light it. Grab the final tile, and return to the
body. Attack this mural as well and get upstairs.

6th floor
You need to place the tiles correctly (should be placed as you�ve seen on the mural). Both
rooms to the west contain a weight (collect both) and go on to the sarcophagus room. Place
the scarab into the slot, and look inside (you just saved the princess) and don�t? forget to
collect the final weight. Place the weights on the scale until both sides are equally balanced
(you need to put the heavy and very heavy on one side and extremely heavy on the other ? then
just use the light ones to equal it out). A corridor will open and when you enter it a priest
will attack you (kill him). Walk to the statue and insert the amulet. Then step back a little
and push the statue to exit the pyramid.


   Cemetery:


On this level you�ll get to fight zombies. Remember, they�re already dead, so you can�t kill
them. What you need to do is to make them harmless. You need to chop off their arms and head
(go for the arms first). You do this by clicking on the wounds on the shoulders (you need about
3 hits to chop off the arm).

So in order to fight the zombies you first need the sickle (go and get it). Next go to the
railing and pick up the loose iron rail. Now go to the tomb and open it (you need to be on the
northern side of it and you�ll see a crack in it). Once inside open the coffins and talk to the
guy in the left one (don�t look inside the coffin on the right, or else you die). Because there
are many zombies you�ll need to fight (sometimes they�ll just start popping up one after the
other) you might need to restore your health. In order to do that, you�ll need the heart of the
girl (yup, you can steal her heart away) and off course you need to talk to your uncle and ask
him to heal you.  Next you need to collect the wooden stick and sharpen it. Now you�re ready to
enter the church and use the stick on the Vampire. Pick up the plate with bread and go back to
the tomb. Here you should talk to uncle Boris (through the crystal ball). Once the spell is
complete (the bread you picked up will be just the thing needed), you must return to the church.
Now look at the statue and turn its head to deactivate the force field. !Change your weapon! You
need to touch Vladimir, so you must put away the sickle and use your fist. And there you are back
in the hallways facing your uncle�s manservant.


   Mines:


The plant mutants are quite tough, so don�t fight them with the regular weapons (but if you must I
suggest the shovel (3 well placed hits to the head). There are also vines and pods that can�t be
destroyed by usual methods. You need the canister with weed killer and when you run out you need to
refill it. When the message will read it�s almost empty, you have just one shot left, when it�s
completely empty go to the generator (then you�ll be burning the baddies). To refill you should face
the generator and take the lower cap off. Quickly drag your canister on to the flowing gasoline, but
don�t forget to put the cap back on to stop the gasoline from being wasted. There is enough gasoline
there for two refills, but you may only use it once! You will need one refill for the drill!

You can find the screw-driver and a lighter in the miner�s coat (you don't really need them) and talk
to the injured guy. At the turning point face the lift to see the chemical canister (take it it�s
your best weapon for this exhibit). Next you need the gas bottle and the welding mask (you can pick
up the shovel and the pickaxe on the way too). Now go and look at the support beam and scrape two
pieces of coal off it. Return to the main corridor (with the tracks in the middle (go back where you
came from) and go get the support beam next. When you pick it up, return to the tracks and take just
one step east (to the drop spot). Drop the beam and go get the drill (as soon as you go south a cart
should run down the tracks and it will stop at the drop spot). When nearing the drill it gets very
dark and it�s almost impossible to the plant pod. When you reach the drill (a guy on the wall has it),
turn south and feel the holes for a drill bit. Now go and get the welding torch and toolkit from the
dead mechanic (search him and get a handkerchief). Upon return to the tracks you should find a cart
where you dropped the beam (if the cart has blocked the elevator you�re screwed). Find the cart and
take the iron piece from inside. Now go and collect the medical kit (and search the guy to get the
second handkerchief and the key). Now go to the prison and talk to everybody except the one on the
left. Go to the generator and fill the drill with gasoline. In the storage rooms you�ll find a detonator,
dynamite (12 sticks, just to be sure), 2 protective suits, 3 gas masks (you only need 2), 2 bottles
filled with gasoline, and 2 empty bottles (don't need them). Drag the charcoal over the handkerchiefs
and place them in two gas masks (those are the filters). Wear the gas mask (with the filter) and the
protective suit and give all the stuff to the explosive expert. You�ll need to burn one more vine,
but you�re out of fuel (empty the bottle into the spray canister). Go to the plant but save befor
reaching it! Use the piece of iron as a weapon and poke out the eyes of the monster and place explosives
into all 8 wall pieces in this small room (just face the wall). Give the med kit to the doctor and
have her join you. Leave your spray canister for the doctor. Wait a few moments (if you have to fight
use a shovel). Return to the elevator and talk to the professor (injured man). In the end tell him the
mine is set to explode. Pick up the canister and go heal the third guy in the prison. Head back to the
elevator (with the electrician). Stand at the turning point so you can see the elevator and unlock the
safety gate. Step into the elevator and close the gate. Now face the controls and look at them. Use the
detonator and then operate the controls.


   London:

Get the bag and hurry down to the pier. Once there look inside the bag and drag the money (and the diary)
over the upper left icon (a hand with a triangle), it should appear in the inventory. Now get the plank
(go to the door in the east alley - it�s unlocked - and through the warehouse), you�ll see it on your
right. Go to the tailor's back yard and climb the ladder. Place the plank so it connects to the other
house and go through the window (now you�re at the locksmith�s). Go all the way downstairs and take the
keys and the pencil. Read the diary (it�s in the girl�s bag) and shade in the missing part. Go back up and
out the window. Next go behind the drugstore and open the backdoor with the key and get the sleeping pills
(they�re on the middle shelf next to the fart pills poster). Now go to the butcher�s back yard and get the
animal guts from the barrel (put the sleeping pills inside). Climb on the barrel (in the street) and throw
the guts to the dog. Open the bolt, climb down from the barrel, open the door and get inside. Unlock the
door to the pawn shop and enter (then go through the open door on the inside, don�t bother unlocking the
other door). Move the clothes and find the safe. Take the watch (from the safe), the police whistle (it�s
in the vase) and the cane. In the back yard of the hardware store is a rope (in a barrel). Now climb up the
ladder again and go to the chimney. Tie the rope over it. Climb down the rope and enter through the window.
There is a layer�s office in the house; take the map from the desk (it�s in the filing tray) and a letter
with a warehouse key in the cabinet in the back (take it). Take the jacket (from the middle model), blue
vest (next to the jacket) and a bowler hat. Go to the Bull's bar. First talk to the costumer next to the
piano player. Then talk to the landlord and get some of the fines ale. Tell him you�re looking for
entertainment. In the end he�ll tell you the guy next to you is a pickpocket. Talk to the pickpocket and
offer him the watch if he steals the booklet from the pimp. You'll get the key to Molly's, go and unlock
the door. You'll find a letter there. Go and talk to the landlord of the Ship�s Inn. Ask about
entertainment (ask for Molly). When he denies knowing her confront him as a liar and then show him the
letter. He�ll give you a crowbar and after you bring him tea, you�ll get the information about the meeting.
Go out on the street and blow the whistle (then quickly go to the dead end). After the bobby got rid of
the people in the street go to the warehouse (unlock the door and carefully go through the crates until
you find the one you�re looking for; open it). Bring the tea to the landlord and get Molly�s location.
Tell her you want to kill Jack and that he�s your brother and SAVE. Now go out the door and fight. He
blocks well, but you need to stay on him (keep clicking for his stomach, then from the left side and then
for the face).


   Lifting the course:

Look at the manservant and receive the four relics. Wear the amulet before entering the last exhibit.
Upon entering throw the poison, then grab the crossbow (on the left side). When the witch is bleeding
from her arm, use the crossbow. As she falls down use the knife and kill her, Now you�ll exit the exhibit.
Look at your brother sitting in the corner and use the ring.

The course is lifted and you can leave the WAXWORKS!