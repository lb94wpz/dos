123456789012345678901234567890123456789012345678901234567890123456789012345
---------------------------------------------------------------------------
Dusk of the Gods
---------------------------------------------------------------------------

Version 1.3

10 July 2007

For PC DOS/Windows

by Lee Beng Hai

My lastest email address can be found at

http://www.gamefaqs.com/features/recognition/684.html

-------------------------------------------------------------------------
Disclaimer
-------------------------------------------------------------------------

This FAQ is meant for personal use only. You should not host this 
document on your web site without my permission.

You can find the latest copy of this FAQ at

http://www.gamefaqs.com/

The following sites had been granted permission to host this FAQ

http://www.cheathappens.com
http://computerunderground.com
http://DLH.Net
http://gamenemesis.com
http://www.gamesover.com
http://www.neoseeker.com
http://www.cheats.de
http://www.cheatcc.com
http://cheatplanet.com
http://faqs.ign.com
http://www.honestgamers.com
http://www.supercheats.com
http://gamerevolution.com

If you want your site to be added to the list, please email me. 

However, your site will be added only if and only if I had something to add 
to my FAQ.

(c) Copyright 1991-2007 by Lee Beng Hai. 

-------------------------------------------------------------------------
Contents
-------------------------------------------------------------------------

01. Introduction
02. Character Creation
03. Temples of the Gods
04. Armor Class
05. General Hints
06. Geography
07. The Kings Quests and Magical Items
08. The Main Quest
09. Revision History

---------------------------------------------------------------------------
01. Introduction
---------------------------------------------------------------------------

When the game started, Odin had seen from the pool of vision that a 
climactic battle would soon be fought known as Ragnarok or the "Dusk of 
the Gods". The outcome of Ragnarok depends on whether these gods survived: 
Thor, Frey, Hodur, Odin and Heimdal.
 
You are one of the Einherjor, Champion of Odin, entrusted with the 
responsibilities to ensure the survival of the Gods when Ragnarok happens.

---------------------------------------------------------------------------
02. Character Creation
---------------------------------------------------------------------------

In the character creation screen, you can select what you do in your life 
as a human. You can choose to raid (increases warrior ability), study 
(increases sage ability), or pray to one of the gods.

The bar at the bottom indicates your life and will slowly decreases. When 
it reaches zero, you are dead. The game begins only after your character 
is slain in battle and taken to Valholl. Odin made you into one of his 
Einherjor.
 
During the game, your warrior and sage ability will increases when you use 
them. However, your attitude towards the Gods does not change.

At the beginning, your character is given on default visit to Odin. If you 
need to pray to the Gods, select Freya (the purple building).

Create a character with very high warrior ability. Sage ability is not as 
crucial. 

---------------------------------------------------------------------------
03. Temples of the Gods
---------------------------------------------------------------------------

In the game, you'll find many temples of the gods. They appear to look 
like a small house with a single bed. There is usually a certain picture 
in the house that indicates whose temple it belongs to. To pray to the 
god, select an item and click on your character on the main screen. 
Sacrifice the following items to gain the God's favor: perfume, Freya's 
tear, craft wheel, craft idol and ship tokens. You can also sacrifice 
magical items to the Gods but it is not worth it. Once the God accept your 
sacrifice, a certain icon appear in the yellow box, click on it to cast 
the spell. If you sacrifice more items, another more powerful spell will 
be given. The previous spell can only be selected after you had cast the 
spell you have just received. The God gives a maximum of 5 spells so don't 
waste extra items after that. The spells will fade away after some time, 
one at a time.

The following is a list of the magical powers that you will encounter in 
the game. Your Sage Ability will determine 3 things when it comes to spell 
casting: the amount of damage for offensive spells, the duration of the 
spell and the effectiveness of non-offensive spells.

Odin

1. Mannaz, Increase "Sage" Ability - Temporarily increase Sage Ability.

2. Flaming Javelin - throw a javelin of magical fire and flame.

3. Hagalaz, Death - instantly slays most creatures.

4. Berserker Rage - temporarily increases Warrior ability, hit points, and 
increases the character agility rating but lower armor class. I.e. 
increases all attack skills but decreases defense.

5. Shape Change - take the form of a wolf with certain special abilities.

6. Othila, Speak with the Dead - grant the ability to speak with the dead 
on Midgard. Required to complete the game. Looked like an 'x' with a '^'    
on top.

7. The Unknown - creates a random object. Look like an 'F'.

Tyr

1. Teiwaz, Increase "Warrior" Ability - Temporarily increase Warrior 
Ability. Look like an 'up arrow'.

2. Spellfire - project fire at an opponent.

3. Enchant Weapon - Permanently increases a weapon's effectiveness, both 
in damage and ability to hit.

4. Tyr's Fist - throw a ball lightning. Less powerful than Spellfire or 
Lightning bolt but there are no counter spells to reduce the damage.    
Look like an 'N'.

5. Flame arrow - creates a flame arrow, do more damage than a normal 
arrow.
 
Freya

1. Obscurity - Grant your character the power of invisibility. If is most 
effective against less powerful creatures.

2. Algit, Protection - temporarily increases your character armor. Look 
like a trident.

3. Firebrand - create a light source that is strong than a normal branch 
 (Torch).

4. Restoration - heals damage. Look like a 'z' flipped vertically.

5. Thurisaz, Teleport - teleport to the nearest temple of Freya. Look like 
'|>'.

6. Kanu, Opening - open doors that don't require a special key. Look like 
a '<'

7. Ehwaz, Fire Shield - decreases the amount of damage caused by fire 
based spells.

Thor

1. Lightning Bolt - cast lightning.

2. Isa, Binding - freezes an opponent in place so that he cannot move or 
attack. Look like an "I".

3. Fear - causes an opponent to panic and run away.

4. Swiftness - increases movement speed and the rate of speed needed to 
complete tasks.

5. Lightning Shield - decreases the amount of damage caused by lightning 
based spells.

---------------------------------------------------------------------------
04. Armor Class
---------------------------------------------------------------------------

A descriptive armor rating system is being used in the game. The ratings 
from least effective to the most effective are:

 1. unarmored
 2. well-clad
 3. safe guarded
 4. well-protected
 5. stoutly clad
 6. rugged
 7. mighty
 8. shielded
 9. reinforced
10. fortified
11. iron-clad
12. steel plated
13. unyielding
14. impervious
15. invincible

---------------------------------------------------------------------------
05. General Hints
---------------------------------------------------------------------------

Warrior ability determines the encumbrance of your character. There is 
lots of stuff that need to be carried around, so keep the warrior ability 
high.

Warrior and sage abilities increases as you use them.

Most of the magical items in the game had limited usage. After a while, 
they will lose their ability, so keep them in your inventory, and use them 
when necessary.

When you are carrying some crucial items and get killed. You will be 
brought back to Valholl WITHOUT those items. They will remains on the 
ground at the position you were killed. So, you'll need to go back and get 
them but there is an exception to this: if you get killed in the sea, you 
will be able to keep the item since you can't drop anything in the water. 
This provides a quick and dirty way to get back to Asgard.

You need to find the Fehu rune to gain the ability to speak with the dead. 
There is only one such rune in the game. There is however an easier way to 
gain it. Pray at Odin temple, sacrifice many items until the Fehu rune 
appears. The rune look like an "x" with a "^" above it.

Ask Frey about SKIDBLADNIR. He will gives you a magical ship that lets you 
travel at sea.

---------------------------------------------------------------------------
06. Geography
---------------------------------------------------------------------------

You will need to travel a lot in this game. So, 1'11 roughly give you a 
guide on the various parts you might come across. You start of from 
Valholl, in Asgard. Follow the path in the NW and you will reach the 
rainbow bridge. There is cave beyond the bridge with 2 exits. The SW exit 
led to King Nitheri Land, while the NE exit leads to King Nithod land. 
From Nithod land, go east to reach the Elven Land and north to reach Aegir 
Land. The Giant Land is east of the Elven land. North of Aegir Land is the 
Ice Plain. West of Nitheri Land is King Magnus Land. East of Magnus land 
is the land of King Hrothgar.

---------------------------------------------------------------------------
07. The Kings Quests and Magical Items
---------------------------------------------------------------------------

King Nitheri's Quest
--------------------

Kill Treesmiter and he'll give you the Lifegiver Shield. When equipped, 
the Shield regenerates your hit points. The shield will vanish after much 
use, so equip it only when necessary. In the process, you will find a 
Sword that can cast Spellfire and a Cloak of Obscurity. Effects will 
expires after much use.

Lifegiver Shield   - regenerates hit points.
Fire Sword         - cast Spellfire.
Cloak of Obscurity - prevent people from seeing you.

King Nithod's Quest
-------------------

Look for Weland in the Elven Land. Buy the dragon brooch for 15 iron 
dirhems. Give the brooch to the King. Get Naglering. This sword is very 
powerful, for it can do up to 255 damage. It will lose its power after 
much use.

Naglering Sword - can do up to 255 damage.

King Hrothgar's Quest
---------------------

Kill the green beast Grendel. Fight the Green Beast with bare hand if you 
want to kill it. Make sure you have some Baldur's brow to cure poison 
before fighting Grendel. You'll find lots of good stuff in the King's 
Treasure Room after you kill the Green Beast.

King Beowulf's Quest
--------------------

Kill the Dragon and bring the Head to him. Get the Sword Hrunting. It can 
cast lightning.

Hrunting - sword that cast lightning.

Other Magical items
-------------------

Ask Ragnar about 'FATHER'. You'll get the Torc of Odin.

Go to the Elven land. Explore the caves in the Elven Land. There are 
around 5 caves. You'll find the Elven Helmet in one of the caves. Go back 
to King Nithod land. Wear the Elven Helmet and then look for the Hill 
Lady. Kill her and get the Key to her Room. Lots of goodies are inside the 
Hill Lady's treasure room.

In King Nitheri's land, one of the wolves is not really a wolf, but 
someone wearing a Wolf Cloak. Kill that Wolf and get the Cloak. Wearing it 
transforms you into a wolf and you can walk pass wolves safely. Limited 
usage.

Wolf Cloak - transform you into a wolf to walk pass wolves safely.

You might come across an old man, Hrunding selling the Valknut key at 
Midgard South. Buy it with 10 iron dirhems and use it to open the door of 
a certain building on the eastern part of Midgard North in the land of 
King Nithod. Once released, Brynhild will give you the Boot of Swiftness 
and the sword Hrolte. The shoes' effect wears off after much usage. The 
sword will increase warrior ability when equipped.

Boot of Swiftness - increase speed.
The Sword, Hrolte - increase warrior ability when equipped.

There is a man that sells a set of plate and leggings for 30 iron dirhems. 
Buy it if you can for it is the best and lightest in this game.

In Jotunheim, look for a cave on the western part of the island. Kill the 
two giants within to get the helmet, Heldegrim. When worn, it instills 
fear into your opponent. Its effect seems to last forever.

Heldegrim - helmet that instills fear into your opponent.

---------------------------------------------------------------------------
08 The Main Quest
---------------------------------------------------------------------------

The outcome of Ragnarok depends on whether these gods survived: Thor, 
Frey, Hodur, Odin and Heimdal. I will describe what is necessary to ensure 
their survival.

Thor

Thor needs his hammer. Go to the Land of King Nithod. Look for the 
battlefield, the place where you find lots of dead bodies. Look at the 
rocks there carefully. You can talk to one of them, a land voettir. Ask 
him to give you Thor's Hammerhead. Go back to Valholl and give the 
Hammerhead to Sindre the Smith who will reforge Mjollnir.

There is another thing that need to be done. Thor will go fishing with 
Hymir and will catch the world serpent. Thor will get killed in the 
process if the fishing line breaks. So, you'll need to and something to 
strengthen the fishing line.

Go to King Magnus land. There are 3 ships along the coast; the one with 
lots of Vikings is the one you are looking for. Walk into the ship and 
take the stairs. Go down and kill the Vikings. Get Dromi and Ledling.

Go the Aegir land. Look for a small island somewhere near Aegir's Island. 
Look for the goddess Ran. Give her Ledling and Dromi. She will get your a 
Strand of her net.

Now go to the Giant Land. Look for Hyrrokin. Get the power gloves and 
belt. When worn, they increase you warrior ability. NE of Hyrrokin is an 
empty house where you will find Hymir's fishing line. Drop the fishing 
line and the strand of Ran's net on the ground. This ensures that the 
fishing rod is strengthened. (Don't ask me how I figure this out, I make a 
wild guess and hit the jackpot!)


Frey

Frey needs the Sword of Victory and the aid of Thor to survive Ragnarok.

You need to steal the Rod of Subduing from Hela. To reach Hela's plain, 
you'll need Hel's shoes and Skidbladnir. In Magnus land, there is a 
certain cave that is surrounded by trees. Cast lightning to burn down the 
trees. Enter the cave and get Hel's shoes. Ask Frey about Skidbladnir and 
he will give it to you.

Go to the Elven Land. Somewhere on the western side of the island is a 
cave blocked by trees. Cast lightning to burn down the trees. Enter the 
cave. Explore the cave to get Gridarvoid and Mimer's gauntlet.

Hela's Plain is in a cave on the Giant Land, on the eastern side. Enter 
the Otherworld. Wear Hel's shoes to walk across the thorn and use 
Skidbladnir to cross the river of blades. You'll find a building to the 
south and a cave that leads to somewhere else. Enter the building and talk 
to the woman there. She'll ask you to get the Golden Glow. Leave the 
building and enter the cave. There are 2 caves and a few building here. 
Enter the cave to the NE and talk to the dead. The answer to the riddle is 
HONOR. Get Gjallor Horn. When you give it to Heimdal, Ragnarok will 
happen, so don't do it unless you want to end the game. Go to the building 
where you find some golden stuff on the floor. Wear Mimer's gauntlet and 
take the Golden Robe. If you forget to wear the gauntlet, then good luck 
to you. Show the Golden Robe to the woman to get the Gjoll key. Open the 
door and search for Hela in her cave. Walk near the Rod of Subduing, grab 
it and run away from Hela. Hela cannot be killed so there is no point 
fighting her.

Go back to Asgard. Give the Rod of Subduing to Frey's man, Skirnor, who 
lives to the south of Frey. He'l1 will use it to charm Gerd, the Giantess.

Hodur

You must make Hour regain his sight and make the giant lost their rage.

Go to King Hrothgar's Land. Go to the small isle to the east of the King's 
land. Enter the cave and fight Grendel's mother. It can only be harmed by 
a Great Sword that is hidden beneath one of the items inside her room. My 
advice here is to save the game before entering the cave. Then enter the 
cave and start searching the items, ignoring the monster's attack. A spell 
of obscurity is useful when you want to do the searching. When you know 
where to get the Great Sword, restore the game and then head straight for 
the Great Sword. Use it to kill the monster. Get Grendel��s Mother Key. Use 
the Kano Rune to dispel the magic on the door. Open the door with 
Grendel��s Mother Key. Get the Torc of Sight inside the treasure room.

Go back to Asgard. Look for Hodur in the SW comer in the forest. Give the 
Torc of Sight to him.

Go to Jotunheim. Look for the cave where you find 4 different guardians. 
Kill all the guardians and look for the statue inside. Attack the statue 
to destroy the Giant's Battle Rage.


Heimdal

Heimdal need some protection in order to survive Ragnarok.
The help of the Vanir is also needed.

Go to the Elven Land. Search the caves to get the Star of Muspell.

Go back to Asgard. Look for the smith, Volund. He'11 forges a breastplate 
for Heimdal.

Go to the Otherworld. Enter the cave of Surt. Get the Key from his brother 
when you enter the cave. Go down thee levels and unlock the treasure room 
with the Key. Get the Mead of Consequence. If you find Surt on the way, 
just ignore him since he cannot be killed.

Go back to Valholl and give the Mead of Consequence to Hoenir. This will 
ensure that Vanir will aid the Aesir at Ragnarok.

Odin

To ensure Odin survival, Hodur must survive and Fenrir must be forever 
bind. You'll need to find 7 items to forge the chain Gleipner:

1. Bear's Sinew

Easy, just go to the forest of Asgard or any other places. Kill a bear and 
you have what you need.

2. Mountain's root

Go to the Giant Land. SE of Jotunheim is a small island. Kill the black 
fylgja and get the mountain's root in the middle of the island. It looks 
like a piece of white rock, so don't miss it.

3. The Breathe of Fish

Go to Jotunheim. Enter Froste fortress. Kill the giants inside and get the 
key to the measure room. Get the Magical Cauldron.

Go to Aegir's island. Enter the cave and look for Aegir in his great hall. 
Give him the Magical cauldron in exchange for the Fish Breath.

4. A Cat's Footfall

Go to Elven Land. Explore the northern most cave to find the Sapphire.

Go to a certain cave in Midgard. I have forgotten where it is located, but 
it is not difficult to find. Look for the dwarven smith. Give him the 
Sapphire. Get Brisingamen.

Go back to Asgard. Give Brisingamen to Freya. Get Cat's Footfall.

5. A Woman's Beard

Go to the Ice Plain. Enter the cave to the SE. Talk to the dead man. Get 
the key to the private chamber. Go to the Gori's place. Kill the black 
fylgja to get the Entrance Key. Use the keys to enter the building. Kill 
the Gori to get the woman's beard.

6. The Spittle of Bird

Go to King Nitheri's Land. Look for King Beowulf. Then search the mountain 
to the SE to and the dragon. The dragon is almost impossible to kill when 
confronted directly. Instead, I suggest this method. Walk to the place 
directly south of the dragon that is safe from the dragon's attack. Then 
observe the way the dragon breath fire. Once the fire is blown, move up 
and attack the dragon once. Turn back and hide to the south. Attack and 
take cover until the dragon is killed. Remember to save your game before 
this attempt. Once the dragon is killed. Get his head and talk to it. 
Enter the cave and get the Dragon Heart.

Go to the Ice Plain. Search for the Eagle on the western side of the 
island. Eat the Dragon Heart and talk to the Eagle. Get the Bird's 
Spittle.

7. The Arrow of Pain

Go the Otherworld. There is a small island to the west of the Hall of 
Thorns. You'll find Loke and his wife there. Go to the cave to south of 
him. There are many arrows inside. The Arrow of Pain is hidden inside one 
of the pile of arrows.

Go back to Asgard. Talk to the smith, Volund. He'1l use the items to forge 
Gleipner.


Ragnarok

Talk to Heimdal and give him the Horn.

If you had done everything that is needed, victory will be yours.

Good Luck!!!

---------------------------------------------------------------------------
09. Revision History
---------------------------------------------------------------------------

1.30 - 10 Jul 2007
Minor updates.

1.20 - 09 Jul 2004
Update info on Brynhild and Grendel��s Mother. Added Rune stones ability.

1.11 - 29 Jul 2002
Updated email address. Added a list of sites whom requested permission
from me to post this document.

1.10 - 11 May 2002
OCR from copy printed long ago. Reformat the document slightly.

1.00 - 1991
First version.

(c) Copyright 1991-2007 by Lee Beng Hai. 

123456789012345678901234567890123456789012345678901234567890123456789012345