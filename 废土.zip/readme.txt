              Wasteland: The Unofficial Game Reset Utility 1.0

                                 or

                      How I spend my free time
----------------------------------------------------------------------------

Recently, a popular (if lousy of late) computer magazine put Interplay/EA's
classic game, Wasteland, on their accompanying CD-Rom (or CG-Rom, as they
call it, cutesy idiots).

Anyway, the game on the cd-rom wasn't the complete game. Well, it was and it
wasn't. While you could play the game to finish, the cd-rom version missed
a cool utility that would reset the maps to let you play the game again with
the same characters. (This was a feature popular in a lot of old CRPGs, either
because they were meant for floppies, and errors were likely, or because games
back then were a lot more fun.)

So, there was a lot of pleading/whining on the net, for the reset/program files
to be released. But, interplay wouldn't let them be posted, for whatever
reason (When I emailed them about it, their reply said "Nope, Sorry" and then
had 50 lines of ads of their upcoming products)

Anyway, after some work, here's a program that accomplishes the same thing
This is the finished release! No more beta. I implemented a functionaly,
and fairly snazzy looking menu system, and it does everything. One small
flaw, the input is kinda ugly, but it works, it works.

-------------------------------------------------------------------------
The files:

r.exe - executable file
reset.bat - batch file 
readme.txt - the file you are reading

To run, just type reset (or click on it in windows). You can run just the
r.exe if you really want to, doesn't really matter

You are greeeted with a menu, with 5 options

1) Setup Master Files
2) Save Characters
3) Reset Wasteland Maps
4) Import Characters
5) Exit

To choose, type the number and hit return (working on removing the return)

1) You should run this, when you first copy wasteland onto your hard drive.
It copies game1 and game2 , which are the maps, into files master1 and master2
Note: This is very very slow - I couldn't remember how to use dos commands 
inside a program, so I wrote my own version of copy, which happens to be very
slow. If you want, just copy game1 and game2 as master1 and master2 to save
time.

2) This command takes the characters out of the game, and saves them to a
file called change.dat (Why change.dat? Why not?)

3) This option restores the Wasteland maps back to the originals

4) This command takes the characters you saved into change.dat, and 
inserts them into the game.

5) This exits. If you are just running r.exe, it's ugly, but if you used
the batch file, it exits okay.

------------------------------------------------------------------------
Notes on Use
------------------------------------------------------------------------
Options 1) and 3) are very slow. Don't be alarmed if it takes a while. Maybe
I'll optimize it in future releases. It's 1 minute 11s or so as it is on my
P90, haven't tried it on anything else, yet. If that's a program,
use copy game1 master1 and copy game2 master2 for option 1, and
copy master1 game1 and copy master2 game2 for option 3

IMPORTANT: In order for it to work correctly, try to be on the main map
when you save the characters

Unlike the original reset program, the characters still have all their 
possessions. So, for maximum fun, drop everything.

So, lets run though a common scenario or two
-----------------------------------------------------------------------
Have a finished game of wasteland on your hard drive
-----------------------------------------------------------------------
In this case, you'd want to run the reset program, and save the characters. 
Then reinstall the game (from the cd-rom), being sure you don't touch the
change.dat file.  Run the reset program again, then choose 1) to save the
original maps as the masters. Then choose 4) to import your characters back
into wasteland

------------------------------------------------------------------------
Have a freshly, untouched Wasteland on your hard drive
------------------------------------------------------------------------
In this case, you'd want to run the program, and choose 1). Then exit,
and run wasteland. When you finish Wasteland, and want to play again,
Just run the reset program again, and choose 2), 3), and 4) in order, and
boom, you're back to the start of the game.

-----------------------------------------------------------------------
Misc Stuff

Copyrights: the programs enclosed are copyright by me, Jeremy Reaban, except
where noted, and Wasteland is either a trademark/copyright of Interplay or EA
 or both. My programs do not contain any code, files, what have you from the
original wasteland, so I'm not violating any copyright laws

Other disclaimers: I'm not responsible for any damage these programs may
cause. They shouldn't do anything bad, they didn't for me, but I'm reminded
of a company that just released a demo that uninstalled your entire hard 
drive instead of just itself. It could happen. 

This version may be freely distributed on all BBSs, web pages, Ftp sites, etc.
It may not be put on any cd-roms without my permission, and it may not appear
on the Microsoft Network period. (That's what they get for not hiring me!<g>)


Anyway, to get in touch with me, my email address is jer@inlink.com

                              Jeremy Reaban


Thanks:

The Chemical Brothers, for making the music I listened to while writing this
program

The guy I mentioned in the program, for uploading his menu example to AOL

Interplay/EA for making Wasteland in the first place
