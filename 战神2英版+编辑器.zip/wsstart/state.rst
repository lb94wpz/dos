[edit-]
screen=80 25
toggles=1 1 0 1 1 0
srch=
src=
rpl=
file=d:\scf\warscen\wsstart\text06.txt 1 1 1 1
[brief]
file=d:\scf\warscen\wsstart\text06.txt 1 1 1 1 1 22 78 1 c=0
file=d:\scf\warscen\wsstart\text00.txt 1 1 1 1
file=d:\scf\warscen\wsstart\text01.txt 1 1 1 1
file=d:\scf\warscen\wsstart\text02.txt 1 1 1 1
file=d:\scf\warscen\wsstart\text03.txt 1 1 1 1
file=d:\scf\warscen\wsstart\text04.txt 1 1 1 1
file=d:\scf\warscen\wsstart\text05.txt 1 1 1 1
[shared-]
pmark=d:\scf\warscen\wsstart\text06.txt 1 1
