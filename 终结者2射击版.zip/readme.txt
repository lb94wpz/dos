***************************************************************************
*                   T2: The Arcade Game - Technical Guide                 *
*                   =====================================                 *
*                     Published by Hi Tech Entertainment            v1.1  *
***************************************************************************
                                                                           
I.      INTRODUCTION
II.     CREATING A BOOT DISK WITH AN EDITOR
III.    CREATING A BOOT DISK WITHOUT AN EDITOR
IV.     DOS 6.x MULTI-CONFIG
V.      TECHNICAL SUPPORT

***************************************************************************

I.INTRODUCTION
==============

If you experience memory problems with T2, this README.TXT file outlines the 
necessary steps in getting T2 to work correctly on your system.  It may be 
necessary for you to create a boot disk.  DOS 6.x users, however, can take 
advantage of a new feature called Multi-Config.

If you are getting a ! NOT ENOUGH MEMORY ! message when you start T2, it
doesn't necessarily mean you are out of available memory (RAM).  In its 
native mode, DOS uses too much conventional memory to run T2.  To successfully
run T2, special drivers, like HIMEM and EMM386, must be loaded to free up the
conventional memory (approximately 596K) required to run T2.  To find out how 
much conventional memory you have, type MEM at the C:\> prompt.


***************************************************************************

II.CREATING A BOOT DISK WITH AN EDITOR
======================================

1) First format a blank floppy disk by inserting a disk into drive A
   and typing:

     FORMAT A: /S


2) Using an editor of your choice create 2(two) files on this disk, one
   called CONFIG.SYS and the other AUTOEXEC.BAT.

   The CONFIG.SYS file should look something like this -- the
   first three lines are the most important:

     DEVICE=A:\DOS\HIMEM.SYS
     DEVICE=A:\DOS\EMM386.EXE NOEMS
     DOS=HIGH
     STACKS=9,256
     FILES=10
   
   Your AUTOEXEC.BAT file only needs to contain the command to load your
   mouse driver.  It should look something like this:

     C:\DRIVERS\MOUSE.COM

   
   If your mouse driver is stored in a different location on your
   hard drive, you will need to alter the path and/or filename
   to suit your particular system.


   Go to the A: prompt type MD DOS [ENTER]
                            CD DOS [ENTER]
                            COPY C:\DOS\HIMEM.SYS [ENTER]
                            COPY C:\DOS\EMM386.EXE [ENTER]

   Then restart your computer by pressing [CTRL+ALT+DEL] at the
   same time and leave the boot disk in drive A.


***************************************************************************

III.CREATING A BOOT DISK WITHOUT AN EDITOR
==========================================

   If you don't have an editor, you can create CONFIG.SYS and
   AUTOEXEC.BAT by typing the following from the dos prompt (C:>):

   CREATING A CONFIG.SYS:
   ======================
     1) Insert a formatted blank disk into drive A:
     2) Type A: [ENTER]
     3) Type COPY CON CONFIG.SYS [Enter]
     4) Type DEVICE=A:\DOS\HIMEM.SYS [Enter]
     5) Type DEVICE=A:\DOS\EMM386.EXE NOEMS [Enter]
     6) Type DOS=HIGH [Enter]
     7) Type STACKS=9,256 [Enter]
     8) Type FILES=10 [Enter]  
     9) Hold the control key down and press Z [CTRL+Z].  A "^Z" should appear 
        and you should see the message: "1 File(s) copied" 

   CREATING AN AUTOEXEC.BAT:
   =========================
     1) After completing the instructions listed above: 
     2) Type COPY CON AUTOEXEC.BAT [Enter]
     3) Type C:\DRIVERS\MOUSE.COM [Enter]
     4) Hold the control key down and press Z [CTRL+Z].  A "^Z" should appear 
        and you should see the message: "1 File(s) copied" 

  Go to the A: prompt and type MD DOS [ENTER]
                               CD DOS [ENTER] 
                               COPY C:\DOS\HIMEM.SYS
                               COPY C:\DOS\EMM386.EXE

  Then restart your computer by pressing [CTRL+ALT+DEL] at the 
  same time and leave the boot disk in drive A.

***************************************************************************

IV.DOS 6 MULTI-CONFIG
=====================

Multi-Config is a a new feature in DOS 6.x that allows you to define a
multiple start-up menu.  Each time you start up your computer, DOS
will display the menu on the screen.  When you make a selection, DOS will
execute only those commands corresponding to your selection.

To create a T2 menu selection, first edit your CONFIG.SYS to look like this:

        [MENU]
        MENUITEM=DOS
        MENUITEM=T2

        [DOS]
        {PLACE YOUR NORMAL CONFIG.SYS COMMANDS HERE}

        [T2]
        DEVICE=C:\DOS\HIMEM.SYS
        DEVICE=C:\DOS\EMM386.EXE NOEMS
        DOS=HIGH
        STACKS=9,256
        FILES=10

Then, edit your AUTOEXEC.BAT to look like this:

        GOTO %CONFIG%

        :DOS
        {PLACE YOUR NORMAL AUTOEXEC.BAT COMMANDS HERE}
        GOTO END

        :T2
        C:\DRIVERS\MOUSE.COM 
        GOTO END

        :END

***************************************************************************

V.TECHNICAL SUPPORT
===================

If you still experience difficulties please contact the Hi Tech Entertainment
Technical Support department at (800) 216-1750.  Our Technical Support 
department is in operation from 9:00 a.m. to 5:00 p.m. Eastern Time, Monday 
through Friday. Please leave a number where you can be reached between
the hours of 10:00 a.m. to 5:30 p.m..

***************************************************************************
*                               HITECH STAFF                              *
***************************************************************************

VP PRODUCT DEVELOPMENT
  Col Stone

PRODUCER
  Mark Thienvanich

ASSOCIATE PRODUCER
  Jason A. Schreiber
  Seth W. Rosenfeld

MARKETING MANAGER
  Martha K. Brandt

MARKETING ASSISTANT
  Karen Ser


