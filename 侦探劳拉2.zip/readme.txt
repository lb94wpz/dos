
ACT I- A Nose for News Lift up bottom right corner of blotter on your desk, get key.
 Open desk drawer with key, get press pass.
 Finger through the trash can, get baseball.
 Talk to Rube about flower shop, burglary.
 Read bulletin board.
 Exit room.
 Look both ways and cross street.
 Use finger icon on bum.
 Cross street and cross back.
 Get paper three times.
 Cross street.
 Use coupon to get sandwich.
 Cross street, enter police station.
 Talk to the desk sergeant.
 Give him sandwich.
 Talk to cop, ask about speakeasy.
 Knock on back door in station.
 Read pole.
 Exit station and get a cab (use finger icon on cab sign).
 Use press pass on cabbie.
 Go to the docks (make selection from notebook).
  Talk to man (Steve) about Carter, Carrington, Museum.
 Get taxi, go to Lo Fat's.
 Talk to boys until they mention ants.
 Give them baseball.
 Cross street.
 Knock on door, password is Charleston.
 Talk to Ziggy (in front).
 Tell him Crodfeller sent you.
 Ask about Egyptology.
 Exit, get taxi, move trash in the dirty taxi until you see dry cleaning ticket and take it.
 Go to Lo Fat's.
 Give Lo Fat the laundry ticket, ask him about museum.
 Cross street, knock on door, give password, enter bathroom in the back.
 Put on dress, exit building.
  ACT II- Suspects on Parade Show press pass to guard.
 Take water glass.
 Eavesdrop on 14 conversations, talk with everyone.
 (Eavesdrop by walking behind a group of characters).
 Look at Tut Smith's medallion when you talk with him.
 Go right to giftshop, look at daggers with magnifying glass until you find real dagger, it's towards back.
 Talk with Steve.
 Go to Egyptian Exhibit.
 Look at medallion with magnifying glass, take medallion, look at initials, look at footprint in blood.
 Look at Rosetta Stone on wall.
 Open sarcophagus on the right, search body, get notepad.
  ACT III- On the Cutting Edge Go to T Rex Room, get bone and press button.
 Go to Medieval Room, see Pippin in center armor.
 Listen at Yvette's door with water glass.
 Go to Olympia's office, look at snake oil, stone and writing on wall.
 Enter Yvette's office.
 Take carbon from trash can and hold it up to lamp.
 Turn off lamp.
 Enter Carrington's office.
 Listen at door.
 Look at bookshelf, middle, right for Crime and Punishment.
 Open book, take file, look at file.
 Look at notepad.
 Look at phone book (purple), open and read.
 Get number for B.
 Sayff (KL 0527).
 Look at fireplace, get charcoal.
 Rub Carter's notepad with charcoal.
 Look at notepad.
 Open safe using KL 0527.
 Read diary with magnifying glass.
 Close safe.
 Use intercom, listen to conversations.
 Exit room.
 Look at paper cutter.
 Look at lamp with magnifying glass, take light bulb from lamp.
 Exit room.
 Look at statue with magnifying glass, flip switch, go north and put bulb in stairway, go downstairs.
  Listen at Ernie's door (on right).
 Enter back door.
 Enter Ernie's door.
 Exit to corridor, break glass mirror with bone, take lamp.
 Go upstairs.
 Enter Yvette's office.
 Go to Egyptian Room, look at body.
 Go to mask room, look at gray head near top, middle.
 Go to Carrington's office.
 Look at initials, clock.
 Enter Yvette's office and back to Carrington's.
 Listen at door.
 Go downstairs.
 Enter Heimlich's office.
 Get garter from inside a book on shelf.
 Use bone on trap, get cheese.
 Go to Ernie's office ask about carbon paper.
 Go to medieval room and use finger icon on wall hanging.
 After the countess enters, walk near her, talk to her.
 Ask her about diary.
 Go to Ernie's office, get lasso and wire cutters from the toolbox.
 Exit office.
 Use lasso to get dagger from vat 13.
 Go upstairs.
  Go to Old Master's Gallery, look at painting that sparkles (by Anonymous Bosch).
 Use magnifying glass on sparkle part twice.
 Use wire cutters or dagger on key.
 Go downstairs to the back room.
 Get meat from fridge.
 Look at trunk.
 Use key on trunk.
 Put meat in trunk quickly.
 Look in trunk with magnifying glass, look at watch with magnifying glass.
 Take watch and show it to the Countess when you see her.
 Get bottle of snake oil.
 Enter Ernie's office.
 Go upstairs and listen at Yvette's door.
 Go to Pterodactyl room and look at Ziggy.
 Use wire cutters on wire.
 Go to Medieval Room, hide behind wall hanging, listen to conversation.
 Go to Mastodon Room, get hairs from body (use magnifying glass).
 Go to Old Master's Gallery.
  ACT IV- Museum of the Dead Go to Yvette's office, talk to her.
 Leave office.
 Talk to Steve.
 Listen at Yvette's door, enter.
 Go to lab.
 Return to Yvette's office, look at red hair, get shoe, look at scarf, fingernails.
 Go to Old Master's Gallery, use bone on statue.
 Take glasses, hair.
 Go to Medieval Room, get boot, look at red markings.
 Go to Olympia's office, use snake oil on snake three times.
 Use lasso on snake.
 Put snake in cage.
 Go to lab, fill snake oil bottle (use bottle on tub).
 Go to Olympia's office.
 Inspect body, take grapes, take smelling salts, look at cobra fang on ankle.
  ACT V- Rex Takes a Bite Out of Crime NOTE - Save often this act as the murderer is only a few steps behind you!  Go to Pterodactyl Room, close door.
 Use wire on door.
 Go to Medieval Room, go north to storage room.
 Push chair, open window above chair.
 Go to Egyptian Room, hide in left mummy case.
 Go to storage room, push crate.
 Use wire cutters on rope near pole.
 Push rightmost crate.
 Open door, enter elevator and press lever.
 Exit elevator, remove mummy from the case on the floor and prop it again the elevator door.
 Use lasso on snake hook on top of left hand mummy case.
 Enter mummy.
  Answer the riddles - first is Womb, second is Tomb.
 Answer by using the hieroglyphics in notebook.
 Move coal from Steve's face, use smelling salts.
 Give him boot quickly.
 Slide Egyptian panel, enter passage.
 Turn on lamp.
 Walk/crawl through tunnel.
 Use snake repellant on snakes.
 Use cheese on right rectangle and rats will chase cheese.
 Go through opening, SAVE.
 When murderer is in Rex's mouth, press button.
  ACT VI- The Coroner's Inquest Answers to his questions:  Who murdered Pippin Carter? O'Riley.
 Motive? Financial Gain.
 Who murdered Ziggy? O'Riley.
 Motive? Cover another crime.
 Who murdered Ernie Leach? O'Riley.
 Motive? Cover another crime.
 Who murdered Yvette? O'Riley.
 Motive? Jealousy.
 Who murdered Countess Waldorf-Carlton? O'RIley.
 Motive? Cover another crime.
 Who was the skeleton? Carrington.
 Who murdered Carrington? Watney Little.
 Who impersonated Carrington? Watney Little.
 Who murdered Watney Little? O'Riley.
 Motive? Cover another crime.
 Who stole the dagger? Watney Little.
 Who manipulated Little? O'Riley.
 Who was the woman responsible for stealing paintings? Countess Waldorf-Carlton.
 Who was the man responsible for stealing paintings? Watney Little.
 Who was the art theft middle man? Ziggy.
 Who is the High Priest of the Sun Worshippers? Rameses Najeer.
 Who was in the fencing business? Ernie Leach.

