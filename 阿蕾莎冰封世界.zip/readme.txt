Back to Aleshar: The World of Ice
  __       __  __        __   __
 /  \ |   /`  /_ \ |  | /``\ / `\
 |--| |   |--   \  |--| |--| |__/
`|  | \__ \__ \__/ |  | |  | | \_ 
@@@@@@@@{THE WORLD OF ICE}@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

   Aleshar: The World of Ice
   Walkthrough rl 27.07.2003

   By: Haba
   Originally for: Haba's Pages (1997-2006)


   Notes:

   Nearly lost this one in a hard drive crash after my 
   website went down. Web archive recovered it, so I've 
   put it back online. Feel free to redistribute,
   but do leave the credits intact, aye?

   -Haba, 13.7.2009


You'll be outside the elementalist's hut.
Enter Cyan Bay.

-----   Cyan Bay   --------------------------  X X - X X

Go to the inn, talk to the people inside. Common keywords are 'name', 
'job' and of course - 'cult'. One of the people inside is Erik Greymire. 
Say 'trainer' to him and follow the conversation.

Enter the room on right, go behind and pick the lock. (Keep trying 'till 
it opens). Go down the ladders and pick up the goods. Now you're ready 
to leave for Snowhold.

There is a sapphire in a house, you can buy bandages and herbs from the 
healer and sell the items you don't need at blacksmith's.

Now would be a good time to learn how to use that sextant. And hone your 
hunting, skiing and survival skills.



-----  Snowhold  ----------------------------  I N - D V

Snowhold is a bigger town. Which means that there is a lot more to plunder. 
So go ahead brave one, nick them off everything valuable. There is a man who 
buys and sells gems, so you can turn your 'discoveries' into cash.

Once you've had your fun, enter the inn. Talk to Fras Hilltop - the keyword, 
which you of course wrote down, is 'Greymire sent me'. Do as he says and go 
to the healer's during night. (O)pen the secret door and attend to the meeting. 
It _has_ to be night, otherwise no-one will be down there.

So now you know what you need to do. If you're a wimp, go train before 
attempting it. And remember, even a tiger can fall prey to a rabbit in it's sleep. 
Once you've done what they asked, go back and ask for 'help' once more.

So now you're sent out to meet a seer.



-----   Seer   ------------------------------  K H - D A

The journey was worth of the trouble, eh? So next, do as the seer requested. Go see 
Mixor Silvernote and ask him about the 'tome of ancients'.

After meeting him in Snowhold, you'll be told the location of the tome. So out to 
explore, we go.



-----  Tome of Ancients  --------------------  I H - E A

Have a weapon ready, because this isn't going to be a cakewalk. The dungeon is 
populated by nasty bunch of people, whom you need to slap into order. You may use 
magic, but be cautious - a heart attack will surely come  if you fight several 
enemies at once. Run away if you are losing. Go up, heal yourself with your magic, 
then go back down. Rememebr to loot the corpses for valuables. The tome is somewhere 
in the middle of the second floor. You'll regonise the room once you enter it.

This dungeon is fairy good place to train your fighting skills. Try to raise your 
power control skill to novice level at least, a good control on your elemental 
powers becomes essential very soon.

After collecting the tome I met up with a shade in this very dungeon (while 
playing on legend setting). It made me poop my pants. But then a goblin chief 
killed it. Apparently shades dont like goblins and vice versa.

Once you've slaughtered enough poor beasties, go back to  seer with the tome.



-----  Water Shrine  ------------------------  X X - X X  

The seer wasn't too helpful. But at least you know the location of one shrine now. 
Water shrine is just behind the seer's hut. If you have been using water element 
lately, give it a visit. There is a stone slab on the third floor of the shrine. 
Once you step on it, your screen should fade into white. If not, try casting water 
spells on yourself a few times.

Like the seer said, visiting those shrines is essential - it is the only way to 
improve your channeling abilities in general - only power controll skill improves 
through use, elemental powers need to be trained on the shrines. And trust me, 
you'll need the skills further on the game. [They _do_ improve without visiting 
shrines too, but REALLY slow]

Once you're done, head back to Snowhold and talk to Fras Hilltop once more.



-----  Dwarlow  -----------------------------  J T - F W

Now we're getting somewhere! Do as told and head towards Dwarlow. Find Brinn 
Ravenlock inside the inn and ask her about 'citadel of wisdom'. She states her 
job quite nicely though :P Anyway, now would be a really good time to harness 
all your primary skills, pick up a nice weapon and armour. Why? Well... Listen 
to the rumors about the cult of wisdom... You'll see soon enough.

Once you feel ready, enter the Citadel of Wisdom either using the secret door 
or fighting your way through to the backyard, then opening the secret door there 
and entering the dungeons.

Fight your way to the third level of Citadel of Wisdom dungeon. Once you come 
across a door that is not locked, gather all the infiltrators still alive with 
you. They'll buy you extra seconds. Do not kill the priests inside, try to 
reach the stairs on your right instead.

If you survive, find your way out of the ruins. With Type O Negative's words: 
Don't be afraid of the creepy green light. 

(This is the end of the Shareware version, but since the game is now PD, it's 
rather pointless to play the SW version ;-))



-----  Underworld  --------------------------  X X - X X

So, here we are. Try to fight your natural urge to kill everything that's 
diffirent from you for a moment and hear out what your friends have to say. 
They have a simple story to tell. Once you've figured out the background, 
go down to next level of the dungeon (because it is the the _only_ direction 
you can take from now on.

The next level has beasties. Nasty ones. Not good one's to spar with. Do as 
your newfound friends tell you and use magic against them. Bigger weapons 
might work as well but I personally found myself getting chopped into pieces, 
even though I wore a plate mail.

Keep going down, fighting your way through. The molemen aren't much of help, 
makes one wonder how they've managed to survive that long. This is a good 
place to train your magic abilities. Use wide variety of elements, but be 
careful to not kill yourself with overexhaustion.

On fourth level of the underworld, there is a secret door right next to the
stairs. Even if you decide to not use it now, keep it in mind. Eventually 
you'll see a thin rock bridge leading into nowhere. Heal and rest before you 
enter it. If nothing happens, go back to the first level and do what I told 
you to do in the beginning!

The fight is _hard_. That buffoon doesn't seem to be harmed at all by fire 
magic, and lightnings only scratch him. You have two options as far as I 
can see: either keep on stunning him or use balefire. Balefire (spirit+fire) 
is the most dangerous spell in your possession. Using it will most likely 
lead into death if you're even a bit spent - a risk that I had to take because 
nothing else seemed to work on that troll.

Once you have disposed the evil, make your way back to the molemen. They'll 
let you out of the hellhole, so don't leave anything valuable behind.

Now... if nothing seems to help, you keep on dying when casting balefire or 
getting hacked into pieces... There is only one solution and you're not going 
to like it - load an earlier save, go visit spirit shrine and train yourself.



-----  Seer revisited  ----------------------  I N - D V

You'll come outside in middle of nowhere. If you want, you can head for Dwarlow 
again, but there seems to be nothing to do there. Brinn just says "Yes, I heard 
the mission went awry." And that's all. Bah. So instead, lets head back to snowhold.

Fras Hilltop doesn't have anything to say either! 'Help yourself' - screw him! 
But since we're here, now would be a good time to visit the seer.

Write up the locations to shrines that he gives. And as he suggests, now could 
be a good time to get one of the legendary weapons. They dont do miracles, but 
even the process of aqquiring once should boost your fighting skills to a brand 
new level. Visit all the shrines to raise your magic skill, then lets head for 
Sanctuary. (I presume you talked about the legendary weapons in Dwarlow on your 
last visit.)



-----  Sanctuary  ---------------------------  X X - X X

There is only one good reason why visit Sanctuary. And he's sitting on the local 
in. Go talk to Shelan Starbeam, you wont regret it. His information will prove 
rather useful.

Depending on your primary skill, pick one out of the three. Heronblade is cutting 
weapon, Stormaxe two-handed and Dragonhammer is a crushing weapon. I would suggest 
the dragonhammer, since you'll be able to get a heronblade from there as well.



-----  Heronblade  --------------------------  I S - E N

The 'rumor' was quite accurate. You'll encounter shades and wraiths, who are not 
so nice opponents. They aren't harmed by magic, with the exception of balefire. 
You _can_ kill them in combat, but beware - they will easily swarm you in open spaces.

On the third level of the dungeon you will meet up with Sorrow. He is wielding 
heronblade - and is backed up by horde of wraith and shades. A tough battle.



-----  Dragonhammer  ------------------------  X X - X X


This is the easiest of the three different magic weapons. The dungeons here are 
populated by goblins, cave trolls, rock trolls, rock troll chiefs (DEADLY!), 
shades and wraiths. And by some sorrow's as well.

The few first levels are ideal for training: goblins for melee, trolls for magic 
and shades for more melee. Shades and other ghostly fellows are very resistant 
to magic - only the most powerful of spells harm them. You can kill them with 
'basic' spells if you use maxium power.

The final level of this dungeon is _hard_ when compared to the previous levels. 
You better have trained yourself properly before entering it. The dragonhammer 
is located somewhere in the middle, but beware - shades, wraiths and sorrows 
will quickly overwhelm you if you encounter them in open space. Use area effect 
spells if you get stuck, run, cast invisibility and so forth. If you encounter 
a rock troll chief - DO NOT FIGHT IT! They are by far one of the hardest foes 
I've met in the game. If you lure some ghosts to them, they'll 'exorcise' them 
for you. Just stun the trolls and run for it.

I think that the shades in this dungeon are easier than in the other two, at 
least I managed to kill them in melee, while I found myself getting killed when 
I tried the other two. The final level is very good for raising your melee skill - 
if you can survive the hordes. Additionally, I got myself a heronblade from one of 
the sorrows in this dungeon.



-----  Stormaxe  ----------------------------  X X - X X


Once again, the 'legend' was quite accurate. The first few levels are populated 
by cave and rock trolls, the last with wraiths, shades and some sorrows. Once 
you come across a large room with pilars, the axe is in the end of the room.

Not too hard dungeon, especially since one of the stairs leading down is right 
next to the one that brought you down in the first place! Now that's what I 
call customer service.



-----  Snowhold revisited  ------------------  X X - X X

[If you want, you can visit Snowhold right after you have seen the seer for 
the last time]

Fras Hilltop seems to be the only one you can talk about what has happened, so 
lets go see him once more.

Oh well.. Hopefully you fixed up your error and nothing went permanently wrong. 
If so, do your next task and head for the co-ordinates he gave to you.



-----  Dungeon  -----------------------------  H R - F W

Visit, go back to Fras Hilltop, then return once more. Talk to Hilltop once more, 
and off we go again.



-----  Hearthstone  -------------------------  F Q - F O

Find Garn Ravenwings in the local inn (of course), bring up resistance in 
conversation. He'll give you a task. Perform it, and the talk to him once more. 
And then back to the dungeon.



-----  Dungeon revisited  -------------------  H R - F W

Go to the second floor like the last time. After that, head stairs down till 
you reach the final level of the dungeon. There will be goblins and trolls, 
but dont mind them. You should find what you're looking for by heading down, 
left and down again, and then right. Even if you are too late (t)alking will 
reveal the truth.

I guess you know what we'll do next. Off to see mr. Raven it is.



-----  Hearthstone revisited  ---------------  F Q - F O

Raven isn't at the inn, I wonder why? Now, you probably don't know where he 
lives, do you? His house is on the right side of the town. You'll regonise it 
from the red carpet with runes and a locked door. Go pick the lock and enter 
the stairs.

Typical. Two options: either pick the lock or search the cell for a hidden door. 
If you chose the first one, well - balefire has worked on the magic users before. 
Either way, head up the stairs and pick up your gear from the floor. Now just 
leave the town.



-----  Final showdown  ----------------------  X X - X X

Once you leave, you'll be constantly harassed by priest scouting parties. You 
have a new option once one comes by and you detect it. Use it. You'll end up at 
a familiar place. Nothing too difficult, just walk out. Again, leave the town.

Now your direction and mission should be clear to you. Take caution though, this 
is no cakewalk. Once you feel ready for it, enter the shrine and walk to the altar
on third floor.

I don't have too much good advice for you - he is deadly. Remember what the seer 
told you.

If you are a cheater, you can teleport out of the shrine by casting chasm on yourself 
(S+E+A). Then enter the shrine again and the game is over.



That's all folks. Aleshar is safe once again, though there'll be few songs written 
about you. Opression and other hardships never vanished from the land and many good 
men died for no good reason but at least you could escape your own torment.

-THE END-
