Robinson's Requiem
 
Welcome to your new home. Your parachute has set you down in the
heart of a jungle,  so  get  your wits about you right now. You need
to keep your eyes open  all  the  time  for anything that could
prove useful. You're going to need to stock up on food, and kit
yourself out with the tools necessary for your  survival.  Remember
to constantly check your health using your Sesame computer, always
anticipate threats to your health rather than wait for the symptoms.
Everything  you  need to stay alive on this planet is here, it's
just  a matter of using your ingenuity and intuition. But remember,
staying alive  is  just  the  first  stage  in  your  bid  to
escape. Follow these guidelines and you may stand a fighting
chance......
 
Begin  by  heading  eastwards  through  the passage on the left
between the mountains. Tread carefully and look for changes in the
terrain as there are steep  drops  and  banks which can lead to
broken bones. Soon you will come across the wreckage of your
spaceship, so take what is yours - collect five wires  from the
debris and collect the medicines from behind the ruin. This is
essential, your medical kit will keep you alive.
 
Now return to the south, then go to the east until you come to a
lake. Here you  will  encounter  another  Robinson  Agent. You may
be tempted to shake hands  and  enquire  as  to  his  health,  but
remember, it's every man for himself  on this planet and staying
alive means dispensing with some of the niceties.  He has
possessions that you need, so you must kill him. Take the matches,
a  gourd,  the computer and the battery from him, and pick up his
knife which has fallen to the ground.
 
Now  that  you have a knife you can cut loose. Find yourself some
food, but be  careful, as the pears on the tree by the lake are not
edible. Using the knife,  collect branches and leaves from the
trees. These are your building materials.  You  can make a hat using
the leaves and the needle in your kit bag.  Now  get  yourself a
supply of water. You can fill the gourd you took from  your  fellow
prisoner  -  just click on 'USE', then get sufficiently close  to
the lake. Click on the gourd and drag it near to the water and it
will  fill.  Unfortunately  the lake is not full of French mountain
mineral water,  so you would be well advised to disinfect it before
drinking. Use a sterilisation tablet or light a fire to boil it
("USE" icon).
 
In  the  vicinity  of  the  lake  there are three cauliflowers
concealed in hidden  recesses.  They  are  rather heavy, so you
would be wise not to lug them around with you. Remember, the weight
of the bag that you are carrying directly  affects your level of
fatigue. It is best to eat them as and when you find them. Now
return to the west as far as the end of the montain.
 
Recover the following along the way in the recesses of the mountain:
to the south, earthworms in a heap of earth, and to the north, a
cauliflower. Take the road to the south, follow it and go up the
mountain. On the left of the slope  is  a cauliflower. Eat it. Now
you must go into combat. The birds on this  planet  are not the
twittering sparrow type. You must fight the eagle and kill it. Now
use the knife to collect meat and feathers from the eagle. Recover
the  eggs  and  a large bunch of feathers from the nest - you will
need these later.
 
Now  go  back  down  the  mountain  and  continue towards the north.
At the entrance to the road, prepare to meet a friend who is not all
he appears to be.  When  you  have  killed him, look in the grass
close by for his Sesame computer.  If you find it, take it. Follow
the narrow pass to the west, but watch out, there is a tiger at the
entrance to the road, and tigers on this planet  are  particularly
menacing  creatures.  They  will  attack without provocation  and
few weapons are effective against their lethal lunge. Your best  bet
is  to  pass  it by crawling on your hands and knees (click both
right  and  left  mouse buttons), by-passing it via the road which
leads to the  north.  Having successfully avoided imminent death,
continue along the road  right  to  the  end  towards the south, and
collect some resin from a tree.  By  using the resin and a branch,
you can make a torch. Now continue along  the  road  towards  the
north and turn left at the crossing. Swallow your fear and
trepidation, light the torch and enter the cave.
 
The  caves  are  dark and dank, as all proper caves should be, and
they are full  of numerous mutant Ali Babas. A word of warning -
there may be hidden precipices  in  the ground, so tread carefully.
In the main cave, recover a computer  on  the  floor. A very long
corridor to the north leads to a dead end.  If  you get this far,
use your knife to scrape of saltpetre - it will come  in  handy
later.  At  this  stage  you  would  be  wise to take some
antibiotics.  Remember,  climate  and  environment  affect  your
health and there's  nothing like a damp, cold cave to bring on a
dose of flu. Now take the west exit and head towards the marshes.
 
The  marshes  are  one of the more unpleasant parts of the planet,
and will begin  to  test your survival skills for real. Until now
you have just been getting  yourself acclimatised. Beware! Do not go
into the marshes at night as a tyrannosaurus roams around and kills
anything that moves.
 
Numerous  monsters  may attack in the main clearing. Four roads lead
to the west.  The  one  furthest  to the north leads to a tree with
edible grapes. Check  your  energy  levels  - it may be wise to eat
and get some rest. The second road leads to a small clearing where
there are five melons hidden in tall  grass.  The third road leads
to a Robinson. Be sociable - talk to him and take the necklace that
he offers you.
 
You may want to collect the fruit from the Yks'Ykd'Yk, in this
clearing. It is  a  type  of drug. Now take the fourth road which is
the furthest to the south. It leads to a village. Watch out! Along
this road carnivorous plants must  be  killed  or avoided. If you
are bitten by a carnivorous planet you must  act  fast  as  it's
bite is poisonous. The necklace that your fellow Robinson  gave  you
has  an important use. Put it around your neck and you won't be
attacked by the horsewoman from the village.
 
You  may want to go and listen to the Headwoman of the village,
right up in the north. Not far from her, you can find a stegosaurus,
whose milk you can take  simply  by  validating  the  gourd  on  the
udders. After collecting creepers  with  the  knife  (by  clicking
on  them), you can make a bow by combining a branch and a creeper:
 
`          Branch + Creeper = Bow
`          Branch + Feather = Arrow
`          Branch + Creeper + Safety Pin + Earthworm = Fishing Rod
 
Now you should be getting used to the idea of using the environment
to your advantage.  Try experimenting - combining different elements
by clicking on the  'BUILD'  icon. You can fish at any of the
watering places by selecting the 'HOOK' icon in the 'USE' action.
Return to the mutant Ali Baba cave and pass through it in order to
reach the jungle.
 
You  have  still got to deal with the tiger, but at least now you
have bows and  arrows. Crawl past it and once on the other side,
position yourself at a  safe  distance  and shoot two arrows. Watch
out! At the first arrow, the tiger  will  start to attack so you
must get the second shot in quickly and accurately  or  you  will be
cat-o-meat for sure. Recover the skin and meat from  the  carcass of
the tiger. Always remember, animal furs and skins can be used to
make clothes.
 
Flushed  with  your victory over the tiger you should now be getting
a feel for  how  you're  going  to  make it off this planet. Head
back towards the wreck  of  the  vessel. Directly north, take a road
towards the left. Climb the  mountain and cross the bridge. Here you
may choose to pick some leaves from a 'majuarina' plant right on the
edge of a cliff.
 
A  little further on, there is another tiger which must also be
killed with two  arrows,  but  you should have got the hang of this
by now. Recover the skin and meat and use the skins, thread and
needle to make some clothes:
 
      Skin + Wire + Needle = Clothes
 
 
Enter  the cave to the north and put on the maximum amount of
clothes, with the  skins  taking  priority.  This is the coldest
place in the game. Cross this  cave from the south to the north, in
the main cave you will encounter some  pteranodons.  From  this
main cave, go towards the east and you will meet  another  Robinson.
Kill  him and recover the computer, a razor and a video  game  (this
cannot be used on this planet). Return to the main cave then go to
the north in order to leave the cave and enter a canyon.
 
Out  of  the  frying  pan  and into the fire! Apache Canyon is hot.
Fine if you're  on  a  beach  holiday,  but a threat to your
well-being when you're trying  to stay alive against the odds. Take
off the clothes and put on the leaf  hat  as  soon  as possible
because that sun is blistering. Check your water  levels  - you
don't want to end up dead from dehydration. The desert area  is
inhabited by Mygale spiders, which have a poisonous bite. You can
give  yourself  an  injection  of serum before crossing this region.
Try to kill  them  or  avoid them. If you are bitten, immediately
apply the aspiro venom  to  the  wound, or an injection of serum
(the aspiro venom will pump out the poison).
 
Your aim is to cross the desert towards the west and enter the plain
at the south-west  where  large  rabbit  bisons  live.  This is a
bit of a game of target  practice  since  they  tend  to  bounce
around all over the place. However,  if you can kill a few of them
they are a ready supply of meat and skin.
 
Watch  out!  At  the  end of this plain there is a large, aggressive
rabbit bison  with  its  calf. A butt from a rabbit bison causes
fractures and can sometimes lead to temporary deafness. There is a
body of a dead Robinson in this  end.  Recover  its  computer.  To
the south there is a passage in the mountains;  on  the  other side
you meet a Robinson. Listen to him. You can collect  three  pumpkins
at  the very bottom of this canyon. Return to the desert  either  by
continuing towards the east or by passing via the plain with  the
rabbit bisons. By passing via the east, in a dead end towards the
south, you can treat yourself to some Schamalho meatballs.
 
Once  in  the  desert  area,  take  the  road which rises up to the
plateau towards  the east. On this plateau, in a village, there are
natives who you must  fight.  It  is worth the effort because the
natives have spears which will  prove  to  be highly lethal
projectiles and which can be used several times.  To the north of
the village there is a potato field. Take the large gourd  hanging
in  one  of  the huts and fill it up at one of the watering places.
 
Now  continue  directly  south  west  from  the village, along a
precarious ledge.  You will encounter a pteranodon right at the end.
Watch out! he can easily  pluck  out  one  of  your  eyes!  Here,
recover the computer on the sacrificed  Robinson.  Return  to  the
desert area. To the east there is a passage which leads to a cave.
Enter this cave.
 
Do not take the first crossroads. Instead continue straight along
the road. Cross  through  two caves inhabited by small
tyrannosauruses. At the end of these  two caves, take the road to
the south. Here you arrive at a maze. In the  maze of galleries
there are various dead ends. In one of them, you can recover  a
computer close to a body. In the other dead end there is an area
with a small pond. Take the tortoise and, after eating it, use its
shell to make  a helmet. A useful tip:- Collect salt from the walls.
It is extremely useful  in  time  of  intense  heat. Return to the
main cave. Take the road which leads to the south-west and to the
desert.
 
The desert is hot and it is absolutely essential to have lots of
water (two full  gourds),  to  wear the hat and to absorb some salt.
If you don't take these  precautions, you're not going to make it
across. Follow the road and at the intersection, continue towards
the west. At the second intersection, go  west.  This will lead in
the end to a desert area which is watched over in  the  north  by  a
large  triceratops.  Do not approach it for the time being.
 
Towards the south, kill the mad Robinson and recover his objects.
Return to the  second  intersection  and turn towards the south. The
road splits into two,  and  down one of the forks is a body with a
computer which you should take and return to the cave.
 
Now  return  to the canyon and take the other cave to return to the
jungle. Go  down  the  mountain  and  take  the  Ali  Baba cave to
reach the marsh. Remember  the warning about the tyrannosaurus in
the marsh? Now is the time to  outsmart  it.  Wait  until  nightfall
then send up the flares when the tyrannosaurus  appears.  The
bright  light  will  blind  it  and  once the tyrannosaurus is
blinded it can no longer move, so hit it until it dies. Be careful
though, because it takes a while to kill it so one flare might not
be enough. As soon as it starts to get dark the tyrannosaurus will
start to attack again so get out of the way.
 
Once you have done that, go straight to the village of the
Horsewomen. They will  be  grateful  so go to see the Headwoman at
the end of the village as she may have some tokens of her gratitude
to give you.
 
Cross  the  jungle.  Go  to  the  east, to the cascade. Fill the
gourds, go towards  the  east. A road starts off towards the south,
leading to a cave. This  is  the  Sponz  Grub  Cave.  Enter  this
cave  and crawl through the corridor.  The  fat  Sponz  Grub  is
waiting  in the large cave. Take care because it is very fierce.
Kill the grub with the distress gun - it's quick and  efficient.
Take the corridor leading to the west at the bottom of the cave.
There  you  will  come  across  other small grubs which must also be
killed. Recover a computer from the ground. Return towards the east
and, in the  large  cave,  take  the  passage to the south-east.
Crawl through this underground passage. The cave comes out in the
forest.
 
Be careful! On leaving the forest there is a Robinson wandering
around with a  laser, and he shoots at anything that moves! Don't
waste time here, just get  out the distress gun and blow him away!
Recover his laser in the grass and,  from  his  person,  refills
for  the laser, a computer and a pair of kevlar  gloves.  Recover
the  computer on the body which is moaning at the northwest  of  the
clearing. At the east of the clearing there is a rather sparse  area
in  which "lapins-cerfs" (stag-rabbits) are gambolling about. You
may want to lay snares here:
 
      Wire + Branch = Snare
 
These will have to be removed later, You can try to hunt the
"lapins-cerfs" with  a projectile or even with the sword, if you are
quick enough. Recover the skins and meat from the bodies.
 
Slightly further to the south-east, follow a road which goes up a
mountain. If  you  fancy  a culinary distraction at this point you
can leave the road and  headtowards the east where you will come
across a small plateau in the middle  of  which stands a lovely
apple tree. Collect some fruit and return to  the  road.  Be
careful! It is surrounded by Centaurs who shoot arrows. Kill them
with a laser and recover the bows.
 
Continue  along  the road and after crossing a bridge, you will end
up on a plateau  where  numerous  Centaurs attack with their axes.
They must all be killed,  so  that you can recover a computer from
the Head Centaur, as well as  an axe, which is a highly effective
waepon. Return to the clearing from where you started. Go towards
the north.
 
Prepare  your  laser  and  be very careful as there are four tigers
roaming around  in the area. Kill them one at a time! Recover their
skins. With all of these skins you will be able to make quite a few
warm clothes and you're going to need them.
 
Now  continue to the east until you reach the edge of a small lake.
Go into the  water  and  swim some distance northwards. Soon you
will come across a raft which you should take and descend the
waterway. Pass under the bridge. At  the  fork  you can go to the
left and collect artichokes from the bank. Return  to  the
intersection and continue as far as the lake. At the end of this
lake  the entrance to a cave will appear. Before you go in, make
sure that you put on some warm clothes as it is extremely cold in
this cave.
 
Follow  the  river  and at the first intersection, take a left. Go
right to the  end and, from the walls, collect some sulphur. Return
to the preceding intersection  -  still  by  raft  -  and continue
towards the east. Here, a waterfall  will  appear.  Change  into the
reptile skin clothes, jacket and trousers, then jump into the
waterfall. Swim to the other side, slightly to the north. Put on the
warm clothes again and start off on foot past quite a few  giants.
These  guys  are violent and are liable to break your arms as soon
as  look  at you. This is where the helmet you made from the
tortoise shell comes in handy. Put it on and go into combat.
 
Your  next  step is to follow a maze of galleries in which there is
coal to be collected from the walls of a small cave, and a computer
to be recovered in  a  cave  guarded  by three giants. The maze ends
up in a passage at the southeast. A horrible pterodactyl appears -
kill it. Now put on the reptile skin  and  dive  into the water.
Swim towards the north until you reach the edge.  You  may  be
chased by two pterodactyls. Kill them (it's easier with the  laser).
Continue along the road until you end up in a large cave. Take the
north  exit  towards  the  canyon.  Once in the canyon, take the
other entrance  to  the  cave - the one where the tyrannosaurus used
to stalk. At the  first  intersection, turn right and you will come
across a computer in the middle of the skeletons. Take it and go
back to the canyon.
 
At  this  point  in the game, you should have 17 Sesame computers,
together with  the  one you are carrying yourself. These are the key
to your escape. Go  and  see  the Robinson close to his cabin. Watch
out! You have to shoot him before he shoots you. If you doubt your
skills with a gun, you can kill him from a distance before he gets a
chance to aim at you. Recover from him a  gas  mask,  refills and
his computer. Then go to the desert. To reach it you  have  to cross
the canyon with the tyrannosaurus where you can fill up the gourds
and take some salt.
 
Once  in the desert, go towards the west where the mad Robinson was.
To the north  there  is  a  large area inhabited by a triceratops
which is at this point  taking a siesta. You may be able to skirt
around him but be careful, one  step  too far and it will charge
you! It's probably therefore wiser to kill  it.  To do this you need
to make a Molotov Cocktail. The recipe for a Molotov  Cocktail  is
as follows: take one empty whisky bottle, place some coal,  sulphur
and saltpetre into the bottle and make a wick with a plaster or
creeper. The best way to kill the triceratops is to keep a good
distance and  shoot  at  it  with  the  laser in order to wake it
up, then throw the Molotov Cocktail at it.
 
Now  go  back  to  the wreck which is at the end, in a hidden recess
in the north, and take the battery by clicking on the wreck. Go
directly east. The road  is  long  and  full  of  traps and
quicksand so tread very carefully. Suddenly  you  will come across
some Walkers. These are robot prison guards and  they  have to be
destroyed with the laser. If you are in need of water or  energy
you can eat the single stalk of the Macreloptia Rhacodes, which is
the only edible mushroom in the desert. It is situated right at the
end of a dead-end in the northeast and guarded by a Walker.
 
You  will  emerge  far  over in the southeast, along an enormous
esplanade, guarded  by  a  giant  robot. Now is the time to make a
booby trap. Use the battery  and  the  wire, but be careful. To make
this trap it is imperative that  you  wear  the  kevlar  insulation
gloves recovered previously from a Robinson.  Add  Battery  +  Wire
to  obtain  a booby-trapped battery. Move forward to attract the
giant robot, then put down the battery just in front of  yourself,
retreat a little and leave the robot to electrocute itself on the
battery.  Continue  towards  the north. Watch out for the lava, do
not step  in  it. The entrance to the cave is right up in the north.
Put on the gas mask before entering it.
 
At  the  first  intersection,  turn  left  and kill the robot. From
behind, recover  a  computer from a body and a heavy laser on the
ground. The heavy laser has an infinite number of shots so you can
finish the game using this weapon  alone.  Return  to the previous
intersection and continue along the road.  Be  careful.  You  will
arrive  at  an  enormous cave frequented by numerous  Walkers.
Destroy them individually with the laser. Watch out for the  lava
disks  on  the  ground  and  on the walls. Continue in a maze of
galleries  to  the north and, beneath an aperture, recover Nina's
computer. If you fall asleep in the cave she will sign to you
telepathically that she has managed to throw her computer into a
volcano.
 
Go to the computer cave. Watch out for the numerous Clambots which
are more easily destroyed from a greater distance. Insert all the
computers, as well as your own, into the aperture of the main
computer (the one with the small red  light).  Once  all  the
computers  are  incorporated, the base of the androids will switch
to self destruction. Now your escape is essential. You have  come
too  far to turn back and it's time to concentrate your efforts into
getting  off  the planet. As from this moment there is only a
limited time  left  to escape. Unfortunately, you are now at a
serious disadvantage since  you  no  longer  have your computer, so
you cannot access either the map, the control panel of the computer
or the scanner for the skeleton. The best way is to remember the
route out. The double doors out are situated in the  maze in the
middle of the map. You will meet numerous robot dogs along the way,
which you will probably prefer to blow up with your giant laser.
 
Providing all the disks have been inserted into the computer, the
door will open.  You  can  then join your dear Nina and leave the
planet to return to Earth where you will surely be greeted as a
hero!!
 
THE END.