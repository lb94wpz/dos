===============================================================================

                              FAQ/Walkthrough for
                         POLICE QUEST III: THE KINDRED

===============================================================================


GUIDE INFORMATION
-----------------

Author:   Tom Hayes
E-mail:   thayesguides(at)gmail(dot)com
System:   PC
Updated:  19th June, 2008
Version:  1.1


CONTENTS
--------

1. Introduction
2. Walkthrough
     2.1. Day 1
     2.2. Day 2
     2.3. Day 3
     2.4. Day 4
     2.5. Day 5
     2.6. Day 6
3. Item List
     3.1. Day 1
     3.2. Day 2
     3.3. Day 4
     3.4. Day 5
     3.5. Day 6
4. Point List
5. Copyright Information


VERSION HISTORY
---------------

1.1:  19th June, 2008  (Format update)
1.0:  22nd July, 2005  (First version)


===============================================================================

1.                                Introduction

===============================================================================


Promoted to sergeant detective in the Lytton Police Department, things seem to
be going well for Sonny Bonds. At the end of a normal day on patrol, Bonds
receives news that his wife has been stabbed by a gang at the mall where she
works. Rushing to the scene of the crime, Bonds finds only two clues: a bronze
star and a chain. While his wife lies in a coma in the hospital, Bonds will
need to use these two items to track down the members of the gang responsible.


===============================================================================

2.                                Walkthrough

===============================================================================


-------------------------------------------------------------------------------
2.1.                                 Day 1
-------------------------------------------------------------------------------


STATION
-------

The game starts in the Lytton Police Station. Press the button to use the
elevator and select floor 1. Open the storage closet and get the batteries and
the flares. Enter the locker room. Use the middle locker in the middle set of
lockers and enter the password 776 to open the locker. Get the flashlight, the
nightstick and the notebook. Close the locker and exit the locker room. Press
the button to use the elevator and select floor 2. Open the left door to enter
the sergeant's office. Get the complaint form from the in/out basket and then
exit the office. East. Enter the briefing room. Talk to Morales. Use the
clipboard at the side of the podium to give the briefing. Exit the briefing
room. West. Open the door to enter the sergeant's room.

After Bonds has finished talking to Morales, select sustained to conclude that
discplinary action against Morales is necessary. Get the computer ID request
form from the in/out basket to fill out a form for a computer access card. Exit
the office. Press the button to use the elevator and select floor 3. Give the
computer ID request form to Mike and he will make a card. Get the card from the
desk. Press the botton to use the elevator and select floor 2. Enter the
sergeant's office and wait for a message to appear that tells Bonds to call
dispatch. Use the phone on the desk and press the dispatch button. Exit the
office. Press the button to use the elevator and select the ground floor. Use
the patrol car to exit the station. Drive to 11th/River on the map and stop
when the Aspen Falls sign appears. Use the walk icon to exit the car.


ASPEN FALLS
-----------

East. Walk toward the man and he will throw Bonds' badge into the river. Use
the clothes to find keys and a driver's license. Throw the keys into the river
and the man will exit the river to attack Bonds. Quickly use the nightstick on
the man. Use the handcuffs on him to take him to the patrol car. Search the man
to find a knife. Open the door to let the man in. Open the other door to enter
the patrol car. Use the keys to start the car and then drive back to the
station at 6th/Rose.


STATION
-------

Use the lockers. Open the top-left storage locker and put the gun inside. Walk
into the booking room. Put the driving license and the knife in the drop
drawer. Use the door and book the man for being not in full control of
faculities (05150). Get the handcuffs from the drop drawer. Exit the booking
room. Use the lockers. Use the key in the top-left locker and get the gun. Use
the patrol car. Drive to 1st/River and turn onto the highway. Drive up the
highway to automatically stop at a scene with Morales.


MORALES
-------

Talk to Morales. Talk to the woman in the car. Talk to Morales and select
Signature to witness her failure to sign. Use the patrol car. Use the keys to
start the car.


HIGHWAY
-------

Continue to drive up and down the highway until you see a car. The order of the
cars that appear in this next section is random, but the method of stopping
them is all the same. To do this, press the red button to turn on the siren and
then start driving behind the car. After a while, the car will pull over.
Remember the time that is displayed after leaving the car, as this will be
needed on the ticket.


MERCEDES CONVERTIBLE
--------------------

Walk to the right side of the car and talk to the driver to get his license.
Enter the patrol car and use Orpheus' driving license on the computer. Select
Form 900 and enter the time and vehicle code (22349). Get the ticket and exit
the patrol car. Give the ticket to Orpheus. Use the patrol car. Use the keys to
start the car.


FORD 58
-------

Walk to the right side of the car and talk to the driver to get his license.
Enter the patrol car and use Ruiz's driving license on the computer. Select
Form 900 and enter the time and vehicle code (21654). Get the ticket and exit
the patrol car. Give the ticket to Ruiz. Use the patrol car. Use the keys to
start the car.


DODGE
-----

Use the computer and enter the plate ID 12896 to discover that the owner is a
sherrif. Quit the computer and slow down to let the sherrif overtake.


FORD ESCORT
-----------

Walk to the right side of the car and talk to the driver twice to administer
the field sobriety test. Move the finger from side to side to complete the
test. Search the driver and then use the handcuffs on him. Use the hand icon on
the driver to put him in the patrol car. Use the patrol car. Use the keys to
start the car and then drive to the station at 6th/Rose.


STATION
-------

Use the lockers. Open the top-left storage locker and put the gun inside. Walk
into the booking room. Use the hand icon on the man to remove the handcuffs.
Use the gas chromatograph on the table. Press the red switch to turn on the
machine. Get the tube to test the man. Get the piece of paper from the machine.
Use the drop drawer. Use the door and book the man for driving under the
influence of intoxicants (23152). A cutscene is shown where Marie is attacked
at the Oak Tree Mall. Exit the booking room. Use the lockers. Use the key in
the top-left locker and get the gun. Press the button to use the elevator and
select floor 2. Enter the sergeant's office. Use the phone on the desk and
press the dispatch button. Exit the sergeant's office. Press the button to use
the elevator and select the ground floor. Use the patrol car. Drive to 9th/Rose
and stop at Oak Tree Mall.


OAK TREE MALL
-------------

Get the chain from Marie's hand to travel to the hospital. Exit the hospital to
return to the mall. Talk to the reporter to get his card. COmbine the batteries
with the flashlight in the inventory and then use the flashlight on the floor.
Walk to the side of the red car to see a yellow object. Get the bronze star.
Use the patrol car to complete the first day.


-------------------------------------------------------------------------------
2.2.                                 Day 2
-------------------------------------------------------------------------------


BONDS' HOUSE
------------

Get the music box from the closet. Exit the house to drive to the station.


STATION
-------

Press the button to use the elevator and select floor 2. Enter the homicide
office to talk to the captain, who says that Morales will be helping Bonds with
the case. Use the computer on the desk and put the computer access card in the
slot. Select Homicide, Serial, and enter the number 09987 to reveal information
on the star. Review cases, 199124, 199144 and 199137. Quit the computer. Use
the phone at the left side of the desk and dial 555-0707 to call the reporter.
Exit the office. Press the button to use the elevator and select the ground
floor. Open the trunk of the car and put the flares in the flare box. Open the
door to enter the evidence lockup. Use the chain on the slot and enter 199144
as the case number. Use the bronze star on the slot and enter 199124 as the
case number. Bonds will drive to the hospital.


HOSPITAL
--------

Enter the flower shop and talk to the woman. Give the wallet to the woman to
buy a rose. Talk to the receptionist twice to discover that Marie was moved to
room 307. Press the button to use the elevator. Give the rose to Marie. Give
the music box to Marie. Use the hand icon on Marie to kiss her. Exit the
hospital to complete the second day.


-------------------------------------------------------------------------------
2.3.                                 Day 3
-------------------------------------------------------------------------------


STATION
-------

Press the button to use the elevator and select floor 2. Enter the homicide
office and get the note from the in/out basket. Exit the office. Press the
button to use the elevator and select the ground floor. Drive to the bottom of
2nd and stop. Unlike other areas in the game, no sign will appear to tell you
that you have arrived. Walk out of the car.


325 SOUTH SECOND
----------------

Use the newspapers at the right side of the trolley to talk to Carla. Show her
the wallet. Use the handcuffs on the cart and Carla will come to the station.


STATION
-------

Get the lunch from the table to give it to Carla. Use the computer on the desk
and put the computer access card in the slot. Select Tools, Drawing Composite.
Select and adjust each item on the face until Carla says OK to all of the
selections. Select Search Compisite Master to identify the face as Steve
Rocklin. Quit the computer. Talk to Carla to take her back to 325 South Second.


325 SOUTH SECOND
----------------

Use the cart to get the handcuffs. Use the car to drive to the mall.


OAK TREE MALL
-------------

Walk out of the car and wait for Morales to return from the phone call. Use the
car to complete the third day.


-------------------------------------------------------------------------------
2.4.                                 Day 4
-------------------------------------------------------------------------------


STATION
-------

Press the button to use the elevator and select floor 2. Enter the homicide
office and get the subpoena from the in/out basket. Exit the office. Press the
button to use the elevator and select the ground floor. Use the patrol car.
Open the glove compartment and get the speedometer calibration chart. Exit the
patrol car and use the unmarked car. Drive to 8th/Rose and stop at the court.
Exit the car.


COURT
-----

Enter the court. Talk to the lawyer twice and then give him the speedometer
calibration chart. After exiting the court, use the car to drive to the mall.


OAK TREE MALL
-------------

After Morales has left the car, use her purse to get the key. Exit the car and
open the door to the keymaker's shop. Give Morales' key to Zak and then show
him the wallet to pay him. Enter the car and use the key on Morales' bag to
replace it. After Morales returns, a message is received from dispatch
regarding a crime at an alley. Drive to Rose/2nd and stop at the alley. As with
325 South Second, this is another location that is not identified on the map.


ALLEY
-----

Open the trunk of the unmarked car and open the briefcase. Get all of the tools
and then close the trunk. Look at the body in the dumpster. Move the shirt to
reveal a pentagram on the chest. Use the notebook on the pentagram. Search the
trousers to find identification, which reveals the man as Dent. Use the
toothpicks on the hand to collect evidence from the fingernails. Walk away from
the dumpster. Look at the man's car and use the scraper on it. Open the trunk
of the unmarked car and put the tools back in the briefcase. Close the trunk.
Use the unmarked car. Use the keys to start the car and then drive to the
station at Rose/6th.


STATION
-------

Press the button to use the elevator and select floor 2. Enter the homicide
office and get the note from the in/out basket. Use the computer on the desk
and put the computer access card in the slot. Select Homicide, New File to
start a file on Dent. Quit the computer. Exit the office. Press the button to
use the elevator and select the ground floor. Open the door to the evidence
lockup. Use the paint sample and the skin and hair sample on the slot and enter
199145 as the case number. Exit the evidence lockup and use the unmarked car.
Drive to the hospital at 4th/Peach.


HOSPITAL
--------

Press the button to use the elevator. Get the chart at the bottom of the bed.
Look at Marie and then look at the digital readout. Use the red button to call
the nurse. Use the hand icon on Marie to kiss her. Talk to the nurse and then
exit the hospital to complete the fourth day.


-------------------------------------------------------------------------------
2.5.                                 Day 5
-------------------------------------------------------------------------------


STATION
-------

Press the button to use the elevator and select floor 2. Enter the homicide
office and use the computer on the desk. Put the computer access card in the
slot. Select Tools, City Map. Plot Crimes, and place points between 3rd/4th on
Palm, 2nd/3rd on Rose, 9th/10th on Rose and 6th/River. Select Check Pattern and
draw lines from the bottom point to the top point, from the top point to the
right point, and from the right point to the left point. The direction of the
points seem to indicate that another point is needed at the top-right corner,
so add another point at 8th/9th on Palm and connect a point from the left point
to the top-right point, and the top-right point to the bottom point to reveal
the pattern of a pentagram.

Quit the tools menu and select homicide. Review case number 199145. Quit the
computer. Use the phone on the desk and press the dispatch button. Read the
note on the board. Exit the office. East. Open the right door to enter the
psychologist's office. Read the file on the desk. Exit the office. West. Press
the button to use the elevator and select floor 3. Open the desk drawer and get
the tracking device. Press the button to use the elevator and select the ground
floor. Use the unmarked car and drive to Palm/8th. Exit the car.


OLD NUGGET
----------

Look at the gold car. Open the trunk of the unmarked car and get the tools from
the briefcase. Use the scraper on the door of the gold car. Use the tracking
device on the gold car. Enter the Old Nugget. Wait for Rocklin to arrive.
Select the gun from the inventory, and Bonds will fire at him as Rocklin draws
his gun. Rocklin will drive away in his car. Use the unmarked car. Use the keys
to start the car and turn on the tracking screen and the siren. After a while,
Rocklin's car will stop on the freeway. Drive to the location.


CAR COLLISION
-------------

Open the trunk of the unmarked car and get the flares. Close the trunk. Use the
flares on the freeway. Look in the yellow car and get the keys from the
ignition. Use the keys on the trunk of the car and cocaine will fall out. Open
the trunk of the unmarked car and put the tools back in the briefcase. Use the
hand icon on the cocaine. use the keys to start the car and drive to the
station at 6th/Rose.


STATION
-------

Press the button to use the elevator and select floor 2. Enter the homicide
office and use the copy of Morales' key on her desk. Look at the piece of paper
inside the drawer. Close the drawer. Get the note from the in/out basket. Exit
the office. Press the button to use the elevator and select the ground floor.
Open the door to the evidence lockup. Use the paint sample on the slot and
enter 199145 as the case number. Exit the evidence lockup and use the unmarked
car. Drive to the hospital at 4th/Peach.


HOSPITAL
--------

Exit the hospital to complete the fifth day.


-------------------------------------------------------------------------------
2.6.                                 Day 6
-------------------------------------------------------------------------------


STATION
-------

Press the button to use the elevator and select floor 1. Enter the men's locker
room and get the toilet paper. Use the toilet paper on the toilet to block it.
Exit the locker room and talk to the janitor to tell him about the toilet.
Enter the women's locker room. Use the right locker in the left set of lockers
and enter the password 386 to open Morales' locker. The locker contains a bag
of cocaine. Exit the locker room. Press the button to use the elevator and
select floor 2. Enter the homicide office and talk to the captain to tell him
about Morales. Talk to the captain again and he will tell Bonds to go to the
coroner. Exit the office. Press the button to use the elevator and select the
ground floor. Use the unmarked car and drive to the coroner at 8th/Peach.


CORONER
-------

Enter the coroner's office and get the envelope on the counter. Look at the
envelope in the inventory to find a ring, clipping and Marie's locket. Wait for
the coroner to return. Exit the coroner's office and use the car to drive to
the hospital.


HOSPITAL
--------

Press the button to use the elevator. Give the locket to Marie. Use the hand
icon on Marie to kiss her and then exit the hospital. A message is received
from dispatch regarding a fire at 500 West Peach Ave. Use the keys to start the
car and drive to Peach/1st. Exit the car.


500 WEST PEACH AVE
------------------

Open the trunk of the unmarked car and get the tools from the briefcase. Talk
to the fire chief and then enter the house. Get the photograph on the floor.
North. Use the scraper on the pentagram. Exit the house. Open the trunk of the
car and put the tools back in the briefcase. Close the trunk and use the car to
drive to the mall.


OAK TREE MALL
-------------

Exit the car. Enter the army office. Show the wallet to the man. Show the
photograph to the man. Get the record and then exit the office. Use the car to
drive to the station.


STATION
-------

Press the button to use the elevator and select floor 2. East. Open the right
door to enter the psychologist's office and show him Bains' record. Exit the
office. West. Press the button to use the elevator and select the ground floor.
Open the door to the evidence lockup. Use the blood sample on the slot and
enter 199145 as the case number. Exit the evidence lockup and use the unmarked
car. Drive to 522 Palm at Palm/1st and exit the car.


522 PALM
--------

Knock on the door of the house. Use the unmarked car. Use the keys to start the
car and drive to the court at 8th/Rose. Exit the car.


COURT
-----

Enter the court. Show the news clipping and the photograph to the judge. Get
the search warrant from the desk and then exit the court. Use the unmarked car.
Use the keys to start the car and then drive back to Palm/1st. Exit the car.


522 PALM
--------

Knock on the door of the house. Use the unmarked car. Use the keys to start the
car and drive to the court at 8th/Rose. Exit the car.


COURT
-----

Enter the court to talk to the judge. Get the judicial order from the desk and
then exit the court. Use the unmarked car. Use the keys to start the car and
then drive back to Palm/1st. Exit the car.


522 PALM
--------

Use the gun on Bonds and he will move to the side of the door so that the ram
can open it. Shoot the man that rolls toward the couch at the left side of the
room. Bains will appear. Use the handcuffs on Bains and an officer will take
him outside. Use the left cushion of the couch to find a remote control. Use
the remote control on the TV and select channel 8 to open a secret entrance in
the fireplace. Walk through the entrance to enter the basement. Walk to the
barrels at the left side of the basement and use the gun on Bonds. Click right
and then quickly scroll through the icons to the gun target icon. Shoot the man
that appears from the left side of the room to complete the game.


===============================================================================

3.                                 Item List

===============================================================================


-------------------------------------------------------------------------------
3.1.                            Day 1 Item List
-------------------------------------------------------------------------------


BATTERIES
  Found in the storage closet on the first floor of the station. They are
  combined with the flashlight in the inventory.


BRIAN FORBES' KEYS
  Found by searching the clothes at Aspen Falls. They are used on the river.


BRIAN FORBES' LICENSE
  Found by searching the clothes at Aspen Falls. It is used on the drop drawer
  in the booking room at the station.


BRONZE STAR
  Found by using the flashlight on the car at the Oak Tree Mall. It is used on
  the drop drawer in the booking room at the station.


CHAIN
  Found on Marie's hand at the Oak Tree Mall. It is used on the drop drawer in
  the booking room at the station.


COMPLAINT FORM
  Found in the in/out basket in the sergeant's office at the station. It is
  used to select an action against Morales.


COMPUTER ACCESS CARD
  Found by giving the computer ID request form to Mike on the third floor of
  the station. It is used on the slot of the computer in the homicide office at
  the station.


COMPUTER ID REQUEST FORM
  After the briefing, the form is found in the in/out basket in the sergeant's
  office at the station. It is given to Mike on the third floor of the station
  to get the computer access card.


FLARES
  Found in the storage closet on the first floor of the station. They are used
  on the flare box in the trunk of the patrol car. They are used on the freeway
  on day 5.


FLASHLIGHT
  Found in the locker at the station. It is combined with the batteries in the
  inventory. It is used on the floor under the car at the Oak Tree Mall to find
  the bronze star.


GUN
  Available at the start of the game. It is used on the locker outside the
  booking room at the station. It is selected from the inventory before meeting
  Rocklin in the Old Nugget on day 5. It is used on Bonds before entering the
  house at 522 Palm on day 6. It is used on Bonds in the basement of the house.


HANDCUFFS
  Available at the start of the game. They are used on Brian Forbes at Aspen
  Falls and on the driver of the Ford Escort in day 1. They are used on the
  cart at 325 South Second on day 2. They are used on Bains in the house at 522
  Palm on day 6.


JUAN RUIZ'S LICENSE
  Found by talking to the driver of the Ford 58 on the highway. It is used on
  the computer in the patrol car to make the ticket.


KNIFE
  After using the handcuffs on Brian Forbes at Aspen Falls, the knife is found
  by searching him. It is used on the drop drawer in the booking room at the
  station.


LOCKER KEY
  Found after putting the gun in the top-left locker outside the station. After
  visiting the booking room, the locker key is used on the top-left locker to
  get the gun.


NIGHTSTICK
  Found in the locker at the station. It is used on Brian Forbes at Aspen Falls
  after he exits the river.


NOTEBOOK
  Found in the locker at the station. It is used on the pentagram in the house
  on day 4.


ORPHEUS' LICENSE
  Found by talking to the driver of the Mercedes Convertible on the highway. It
  is used on the computer in the patrol car to make the ticket.


REPORTER'S CARD
  Found by talking to the reporter at Oak Tree Mall. It is not used.


TICKETS
  Found by using Juan Ruiz's and Orpheus' licenses on the computer in the
  patrol car. The tickets are given to Juan Ruiz and Orpheus.


WALLET
  Available at the start of the game. It is used to buy a rose from the woman
  at the flower stall in the hospital on day 2. It is shown to Carla at 325
  South Second on day 3. It is used to buy the copy of Morales' key from Zak at
  the Oak Tree Mall on day 4. It is shown to the man in the army office at the
  Oak Tree Mall on day 6.


-------------------------------------------------------------------------------
3.2.                            Day 2 Item List
-------------------------------------------------------------------------------


MUSIC BOX
  Found in the closet in Bonds' house. It is given to Marie in the hospital.


ROSE
  Bought from the woman at the flower stall in the hospital. It is given to
  Marie in the hospital.


-------------------------------------------------------------------------------
3.3.                            Day 4 Item List
-------------------------------------------------------------------------------


ANDREW DENT'S LICENSE
  Found by searching the trousers of the body in the dumpster in the alley. It
  is not used.


COPY OF MORALES' KEY
  Found by giving the key to Zak at the keymaker's shop at Oak Tree Mall. It is
  used on Morales' desk in the homicide office at the station.


MORALES' KEY
  Found by using Morales' purse after she leaves the car at Oak Tree Mall. It
  is given to Zak in the keymaker's shop at Oak Tree Mall.


SAMPLE ENVELOPES
  Found in the briefcase in the trunk of the patrol car. They are used to hold
  various samples.


SAMPLE ENVELOPE WITH GOLD PAINT SAMPLE
  Found by using the scraper on the car at the alley. It is used on the drop
  drawer in the booking room at the station.


SAMPLE ENVELOPE WITH SKIN AND HAIR SAMPLES
  Found by using the toothpick on the body's hand in the dumpster at the alley.
  It is used on the drop drawer in the booking room at the station.


SCRAPER
  Found in the briefcase in the trunk of the patrol car. It is used on the car
  at the alley.


SPEEDOMETER CALIBRATION CHART
  Found in the glove compartment of the patrol car at the station. It is given
  to the lawyer in the court.


TOOTHPICKS
  Found in the briefcase. They are used on the body's hand in the dumpster at
  the alley.


-------------------------------------------------------------------------------
3.4.                            Day 5 Item List
-------------------------------------------------------------------------------


ROCKLIN'S KEYS
  After Rocklin crashes on the freeway, the keys are found in the ignition.
  They are used on the trunk of the car.


SAMPLE ENVELOPE WITH WHITE PAINT SAMPLE
  Found by using the scraper on the door of the gold car at the Old Nugget. It
  is used on the drop drawer in the booking room at the station.


SCRAPER
  Found in the briefcase in the trunk of the patrol car. It is used on the door
  of the gold car outside the Old Nugget.


TRACKING DEVICE
  Found in the desk drawer on the third floor of the station. It is used on the
  gold car outside the Old Nugget.


-------------------------------------------------------------------------------
3.5.                            Day 6 Item List
-------------------------------------------------------------------------------


ENVELOPE
  Found on the counter in the coroner's office. It is looked at in the
  inventory to find the ring, clipping and Marie's locket.


MARIE'S LOCKET
  Found in the envelope. It is given to Marie in the hospital.


MICHAEL BAINS' MILITARY RECORD
  Found by showing the wallet and photograph to the man in the army office at
  the Oak Tree Mall. It is shown to the psychologist in the office on the
  second floor of the station.


NEWS CLIPPING
  Found in the envelope. It is shown to the judge in the court.


PHOTOGRAPH
  Found on the floor in the house. It is shown to the man in the army office at
  the Oak Tree Mall. It is shown to the judge in the court.


REMOTE CONTROL
  Found under the left cushion in the house at 522 Palm. It is used on the
  television in the house to open a secret entrance.


SAMPLE ENVELOPE WITH BLOOD AND HAIR SAMPLES
  Found by using the scraper on the pentagram in the house at 500 West Peach
  Ave. It is used on the drop drawer in the booking room at the station.


SCRAPER
  Found in the briefcase in the trunk of the patrol car. It is used on the
  pentagram in the house at 500 West Peach Ave on day 6.


SEARCH WARRANT
  Found by showing the news clipping and the photograph to the judge in the
  court. Bonds will automatically use it when he knocks on the door of the
  house at 522 Palm.


TOILET PAPER
  Found in the men's locker room on the first floor of the station. It is used
  on the toilet.


===============================================================================

4.                                 Point List

===============================================================================


             DAY 1
             -----
5      5     Get the batteries.
8      3     Get the flares.
9      1     Open the locker.
10     1     Get the flashlight.
11     1     Get the nightstick.
12     1     Get the notebook.
13     1     Get the complaint form.
14     1     Talk to Morales.
15     1     Use the clipboard.
20     5     Select sustained.
21     1     Get the computer ID request form.
25     4     Give the computer ID request form to Mike.
26     1     Get the computer access card.
28     2     Use the clothes.
31     3     Throw the keys into the river.
36     5     Use the nightstick on Forbes.
41     5     Use the handcuffs on Forbes.
46     5     Search Forbes.
48     2     Put the gun in the locker.
50     2     Put the driving license in the drop drawer.
52     2     Put the knife in the drop drawer.
53     1     Book Forbes for being not in full control of faculties.
54     1     Get the gun.
56     2     Talk to the woman in the car.
61     5     Select Signature.
66     5     Write the ticket for Orpheus.
71     5     Write the ticket for Ruiz.
76     5     Let the sherrif overtake.
78     2     Administer the field sobriety test.
83     5     Search the driver.
88     5     Use the handcuffs on the driver.
93     5     Get the piece of paper from the gas chromatograph.
95     2     Use the drop drawer.
100    2     Book the man for driving under the influence of intoxicants.
105    5     Get the chain.
108    3     Talk to the reporter.
110    2     Combine the batteries with the flashlight.
115    5     Get the bronze star.


             DAY 2
             -----
120    5     Get the music box.
125    5     Read information on the star.
130    5     Call the reporter.
135    5     Put the bronze star in the evidence lockup.
140    5     Buy a flower.
141    1     Talk to the receptionist twice.
146    5     Give the rose to Marie.
151    5     Give the music box to Marie.
161    10    Kiss Marie.


             DAY 3
             -----
162    1     Get the note.
165    3     Show the wallet to Carla.
170    5     Use the handcuffs on the cart.
175    5     Give the lunch to Carla.
195    20    Identify Steve Rocklin.
197    2     Use the cart.


             DAY 4
             -----
198    1     Get the subpoena.
203    5     Get the speedometer calibration chart.
206    3     Give the speedometer calibration chart to the lawyer.
211    5     Get Morales' key.
216    5     Buy the copy of Morales' key.
217    1     Use Morales' key on the bag.
222    5     Use the notebook on the pentagram.
227    5     Search Dent's trousers.
232    5     Use the toothpicks on Dent's hand.
237    5     Use the scraper on Dent's car.
238    1     Get the note.
239    1     Start a file on Dent.
244    5     Put the paint sample in the evidence lockup.
249    5     Put the skin and hair sample in the evidence lockup.
264    15    Talk to the nurse.


             DAY 5
             -----
274    10    Reveal the pentagram pattern.
279    5     Press the dispatch button.
282    3     Read the note on the board.
287    5     Read the file.
292    5     Get the tracking file.
297    5     Use the scraper on the door of the gold car.
307    10    Use the tracking device on the gold car.
312    5     Fire at Rocklin in the Old Nugget.
317    5     Drive to the location on the freeway.
322    5     Use the flares on the freeway.
327    5     Use the hand icon on the cocaine.
337    10    Look at the piece of paper.
338    1     Get the note.


             DAY 6
             -----
343    5     Use the toilet paper on the toilet.
346    3     Talk to the janitor.
356    10    Open Morales' locker.
361    5     Talk to the captain.
363    2     Get the envelope.
368    5     Get the photograph.
373    5     Use the scraper on the pentagram.
376    3     Show the wallet to the man.
379    3     Show the photograph to the  man.
382    3     Get the record.
387    5     Show Bains' record to the psychologist.
392    5     Arrive at 522 Palm.
397    5     Knock on the door.
400    3     Show the news clipping and photograph to the judge.
405    5     Get the search warrant.
410    5     Knock on the door.
415    5     Get the judicial order.
425    10    Shoot the man.
430    5     Use the handcuffs on Bains.
435    5     Get the remote control.
440    5     Select channel 8 on the TV.
450    10    Shoot the man.


===============================================================================

5.                           Copyright Information

===============================================================================


This file is Copyright 2005-2008 Tom Hayes. As it can be difficult to keep
track of websites that haven't posted the latest version of this file, please
do not distribute it without my permission. Send an e-mail to me if you would
like to post this file on your website and you will likely receive a positive
response. If you do post the file, please keep it in its original form with all
of the sections intact and credit the author (Tom Hayes) as the writer of the
file. The latest version of this file can be found at www.gamefaqs.com.