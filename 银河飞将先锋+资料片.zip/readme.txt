����rf.exeִ������Ƭ

-------------------
PRIVATEER HELP FILE
-------------------

This HELP file contains basic help with PRIVATEER. You
can read the CONTENTS and select a TOPIC that pertains
to you, and <PAGE DOWN> to that area. But, it would be 
very helpful to read this file completely. If you 
still have problems, please feel free to give us a call
at ORIGIN PRODUCT SUPPORT. When you call, if at all 
possible, be near your computer. If that is not 
possible, be sure that you have the following 
information:

* The error message you are receiving.
* The DOS name and version you are running. 
* Mouse type and driver you are using.
* Listing of machine type and hardware contents.
* Contents of your Autoexec.bat and Config.sys files.
* Contents of your CHKDSK and MEM /c statement.


CONTENTS:
--------
1.  Making a BOOT DISK (Configurations included)
2.  ERROR CODES:
    - D002-FFFF (sound card problem)
    - #1910 or #1941
    - CRC errors, Bad Files on Disk, PKUNZIP file errors,
      General Failures reading the game disks. 
    - ERROR #2 or Installation Error #2
    - #1209   
    - Crashes when going through JUMP GATES
    - JEMM.OVL file not found
3.  The install keeps hanging on a disk between 
    reading and writing. (Manual PKUNZIP)
4.  Joystick Problems.
    - Speed adjustable GameCards.
    - Program asks for a JOYSTICK B. 
5.  FILE ACCESS DENIED when trying to delete the PRIVATEER game.     

TOPICS:
------

------------------------------------------------------
1. Almost all software and memory conflicts can be 
   bypassed by using a BOOT DISK. Making one WILL NOT
   change you HARD DRIVE, you will only be changing your
   configuration on the disk. YOU WILL NOT WANT TO EDIT  
   YOUR HARD DRIVE configuration, doing so might cause 
   other applications to run incorrectly or not at all. 

   MAKING A BOOT DISK
   ------------------
   A. First put a Blank disk in the A: (it must be the
      A:, most BIOS will only boot from A: or C:)
   
   B. At your C:\> prompt you will want to type:
      
	format a: /s        
   
      **This format is for a High Density-Double Sided 
	diskette only. If your disk does not have HD 
	on it or is not labled with the High Density 
	Double-sided, then you will need to get one.
	
   C. Hit enter when it asks for a label, and then 'N' 
      when it asks about formatting another diskette.

   D. At the C:\> prompt. You will want to type:
   
	edit a:config.sys
   
   E. Now should now be at a blank screen. Look at the 
      HEADINGS listed below and find the memory 
      management system you wish to use and TYPE every-
      thing UNDER that heading. 


	NO EXPANDED MEMORY MANAGER
	--------------------------
	device=c:\dos\himem.sys
	dos=high
	files=25
	buffers=25
	shell=c:\dos\command.com c:\dos /p


	EMS386 MEM. MANAGER (DOS 6.0 WITHOUT DBLSPACE)
	---------------------
	device=c:\dos\himem.sys
	device=c:\dos\emm386.exe 2592 /i=b000-b7ff ram
	dos=umb       
	dos=high
	files=25
	buffers=25
	shell=c:\dos\command.com c:\dos /p

	
	EMS386 MEM. MANAGER (DOS 6.0 WITH DoubleSPACE)
	---------------------
	device=c:\dos\himem.sys
	device=c:\dos\emm386.exe 2592 /i=b000-b7ff ram
	dos=umb       
	dos=high
	files=25
	buffers=25
	shell=c:\dos\command.com c:\dos /p
	devicehigh=c:\dos\dblspace.sys /move

	EMS386 MEMORY MANAGER (DOS 5.0)
	--------------------
	device=c:\dos\himem.sys
	device=c:\dos\emm386.exe 2592 /i=b000-b7ff ram
	dos=high,umb
	files=25
	buffers=25
	shell=c:\dos\command.com c:\dos /p


	QEMM MEMORY MANAGER                     
	-------------------
	device=c:\qemm\qemm386.sys
	dos=high
	files=25
	buffers=25
	shell=c:\dos\command.com /p
	
	
   F. After typing these lines, you want to exit and
      save your file. Do so by typing:

      {ALT} and the 'F' key,
      'X' key,
      and then 'Y' to save.
       
   G. Next you NEED an AUTOEXEC.BAT file on your BOOT
      DISK. Type the following at the C:\> prompt:

	edit a:autoexec.bat                             
   
      After pressing <ENTER>, you will want to type 
      the following at the blank screen:

	path c:\dos
	prompt $p$g
	set comspec=c:\dos\command.com
	c:
	lh C:\MOUSE\MOUSE
	
			 
DO NOT** C:\MOUSE\MOUSE is usually the line that 
       * activates your mouse. You must have a driver
       * to run it. The one above is the most common, 
ENTER ** if the mouse does not work or you receive an
       * error with this line, then you will want to 
       * look on your HARD DRIVE autoexec.bat or 
       * config.sys files. Find the line that looks 
THESE ** similar, go back into your AUTOEXEC.BAT on 
       * the BOOT DISK, and replace the line with the
       * one on listed on your HARD DRIVE. Other common
LINES ** examples are: C:\WINDOWS\MOUSE, C:\DOS\MOUSE. 

   H. After typing these lines, you want to exit and 
      save your file. Do so by typing:

      {ALT} and the 'F' key,
      'X' key,
      and then 'Y' to save.

   I. You will now want to keep this disk in the A: and
      REBOOT the computer. Make sure there are no error 
      messages. If there are, make sure you have the 
      correct the correct spelling, etc. Now you will 
      want to go to the game directory (where you 
      installed it), and type PRIV to play the game.

-------------------------------------------------------         
2.  Most of the ERROR CODES mean that you have a BAD set
    of Disks. But there are some that mean there might 
    be a software conflict or hardware conflict. Listed 
    are the most common error codes and what you need to
    do to get around them.


    ERROR CODE: D002-DFFF
    ---------------------
    This error means that the sound card selection you 
    made was either invalid or that you are sharing an
    IRQ, DMA, or IO Address with current sound card 
    selection. First, you will want to type INSTALL in
    the PRIVATEER sub-directory. This will allow you to
    change the MUSIC and SPEECH card options to NONE,
    then make sure you choose the top menu choice, 
    INSTALL WITH THESE OPTIONS. Now try to go into the
    game, if it works then you have either chosen the 
    incorrect IRQ, DMA, or IO Address or you are 
    sharing one of those selection with another 
    peripheral.  
    You will want to make sure that you have the correct
    settings on your sound card, most have a test program
    that can tell you what your selections are and you 
    will be able to enter those when prompted by the 
    INSTALL program. You DO NOT want to use the DEFAULT
    settings as most will have a different default then
    the original cards. 
    The other main problem is that some people have 
    there IRQ set to 7. On almost every computer there
    is a printer that is set to IRQ 7, also. You CAN NOT
    share IRQ's, especially for the sound cards. If you
    are using IRQ 7, then your best bet would be to move
    the sound card to IRQ 5, which is open on most 
    computers depending on what peripherals you have 
    installed. Some sound cards are run by software and
    others by hardware jumpers. Two examples are the 
    ProAudio Spectrum 16's which are primarily run 
    through software and the Creative Labs Soundblaster
    which is run by jumper selections on the card itself  
    as well as some software settings. Consult your 
    sound card manual for the specific adjustment you
    will have to make. 
    
    
    ERROR #1910 or #1941
    --------------------
    These errors will usually mean that you have either
    a bad disk or bad set of disks. You will want to 
    make sure that you have made the BOOT DISK as 
    recommended in TOPIC #1 and then boot with the disk 
    then try to install the game. That has worked with 
    many of the people. If you still receive the error,
    you probably have a bad set of disks and will want
    to exchange them for a new set if within 30 day of
    purchase. If it happens twice, you would probably 
    want to give us a call. Please check warranty 
    information on INSTALLATION CARD for charges that
    may apply.


    CRC ERRORS, BAD FILES ON DISK, GENERAL FAILURE 
    READING THE GAME DISKS, and PKUNZIP FILE ERRORS
    ---------------------------------------------------
    These errors mean you almost definately have a bad
    set of disks. First, make sure that you have a 
    boot disk and try to re-install. If that does not
    work get a new set and try them. If it happens 
    again give us a call.

    
    ERROR #2 or Installation ERROR #2
    ---------------------------------
    You will want to make a boot disk and then 
    re-install the game. You need to make sure that you
    have the SHELL line in the config.sys and the SET 
    COMSPEC line in the autoexec.bat file.
    
    
    ERROR #1209
    -----------
    Memory problems that have normally been caused by
    NON-INTEL processors. Somewhere the memory has 
    been corrupted. Make sure you have a boot disk
    and add these parameters to your CONFIG.SYS 
    EMM386.exe line (for a QEMM users try excluding
    the same regions):

    device=c:\dos\emm386.exe /x=e000-efff /i=b000-b7ff
     
    **Try doing the Manual PKunzip listed below in 
     section 3.


    CRASHES going through Jump Gates
    --------------------------------    
    The only thing that we found to cause this (happened
    in testing) was additional joystick ports with
    no joysticks installed or installing a joystick 
    then removing it and playing the game with keyboard
    and mouse. (See 4 and 4A section)

    
    JEMM.OVL File not found
    -----------------------
    This error has occured when installing to a drive 
    that is low on space or when you are installing 
    to a compressed drive with ACTUAL SPACE of 25 meg
    or less. You will want to make a clean boot disk
    and free up 25 megs of actual space. Also, try the 
    manual installation listed below.

-------------------------------------------------------        
3.  MANUAL Installation of PRIVATEER using PKUNZIP
   
    If you are getting a lot of with PRIVATEER crashing
    & rebooting during the PKUNZIP phase. The new 
    PKUNZIP does several new things to speed up the 
    unzipping process those include:

    1) swapping to DPMI (protected mode)
    2) using extended mem.
    3) using expanded mem.
    4) some other things.

    Anyway, some computers are having a problem 
    dealing with these above processes. The PKUNZIP 
    program will automatically use the available XMS,
    DPMI, EMM, etc. So, if it locks-up during the 
    install use this line:

    pkunzip -3+ -++ --+ -)+ [path to PRIVATEER disk #1]
			    [path to PRIVATEER dir]

    EXAMPLE:
    
    pkunzip -3+ -++ --+ -)+ b:\privater.zip c:\privater         

    Since this is a manual install, you will then need
    to copy the INSTALL.EXE file off Privateer Disk #1, 
    then go into the PRIVATEER hard drive directory. 
    (c:\privateer, etc) Type INSTALL, choose the sound 
    options, and hopefully you will be able to get the
    game up and running.   

-------------------------------------------------------
4.  The joystick problems can be cleared up by trying
    several different suggestions. Most of the problems
    come from having two or more joystick cards active
    at the same time and there is address conflict. 
    But, we have been able to get most of them up and 
    going in no time at all. Just try the suggestions 
    below. 
   
    A.  Make sure that you have only one game card 
	active. If you have a Gamecard and a port on 
	your sound card then you will want to disable
	the joystick port on your sound card, because 
	it might cause a conflict. Also, another 
	common problem is that there is usually a 
	gameport on your PARALLEL/SERIEL IO card that
	is on your computer as well as the above 
	joystick ports. All, except for one should 
	be disabled. 
      
    Speed Adjustable GameCards  
    --------------------------
    If you have a speed adjustable game card. The ones
    we tested were: CHGAMECARD III Automatic, GRAVIS 
    Eliminator, THRUSTMASTER ACM, and both KRAFT-
    High Speed and software controlled. The speed you 
    might have to change them to will vary between the
    game and your computer but we have included the 
    settings which seem to work most often. REMEMBER,
    yours might be a little different, so do not get
    discouraged, just try change the number +/- 1 at 
    a time and see what happens.  

    CHGAMECARD III Auto is software controlled. The 
    disk that came with the card has a small program
    that is named CHJOY3.exe which has to be run 
    sometimes. Make sure that you have that file 
    installed to a path in your boot up (put it in 
    your DOS directory) or in the directory you will
    run it from like the C: or game directory. The type
    following command: 

    CHJOY ##
 
    ## can be any number between 1 and 31. 150 can also
       be used but check your README.TXT on the disk
       that came with gamecard. The number 28 has
       been the setting with the most success.
       EXAMPLE:

	CHJOY 28

    
    GRAVIS ELIMINATOR has a dial connection which you 
    can vary the speed. Just make sure it is connected
    to the back and that you try the dial at the lower
    end. 1, 2, 3 have worked for most computers.

    THRUSTMASTER ACM uses a dial setting also. It has
    worked best on the lower end of the dial. Try using
    0, 1, 2.

    KRAFT HIGH SPEED GAME CARD uses adjustments through 
    dip switches on the back and the most common 
    setting was switch #2 down and the rest in up 
    position. Consult your manuals for the switch 
    settings. 

    KRAFT SOFTWARE CONTROLLED GAME CARD uses the 
    command KCARD.EXE, make sure that you have that  
    file installed to a path in your boot up (put it
    in your DOS directory) or in the directory you 
    will run it from like the C: or game directory.  
    The type following command:
    
    Kcard ##

    ## can be any number between 1 and 99. The setting
       most common was 5 to 7. Example:
 
	Kcard 6
	 
    
    PROGRAM ASKS FOR JOYSTICK B    
    ---------------------------  
    There are either two joystick ports active and you
    are sharing the gamecard address or you have an
    advanced joystick with throttle or panning control
    which is being detected as the second joystick.
    You will want to make sure that you eliminate  
    any second port, (Read 4A above) and see if you 
    are prompted for a second joystick. If you are 
    positive that no other port is active on the 
    computer and you are still being prompted for a 
    second joystick then you will want move PRIVATEER
    game directory and type the following:
  
    copy joya.dat joyb.dat

    This will make a second joystick file which will 
    get you past the 'CALIBRATE JOYSTICK B' prompt
    for one.   

_______________________________________________________       
5.  FILE ACCESS DENIED when trying to delete the 
    PRIVATEER game from the hard drive.     
    
    A. Due to certain configurations, etc. the PKUNZIP 
       Install will attrib certain files in the 
       PRIVATEER sub-directory to READ-ONLY. Just go
       into the PRIVATER directory on your computer 
       ( Example: C:\privater> ) and then type this 
       command:

       ATTRIB -s -h -r *.*

       Now, you should be able to delete all the files
       in the PRIVATEER sub-directory.




       

 


      
	   
 
  
     
    
