/***********************************************************
* Rocks'n'Diamonds -- McDuffin Strikes Back!               *
*----------------------------------------------------------*
* (c) 1995-2002 Artsoft Entertainment                      *
*               Holger Schemel                             *
*               Detmolder Strasse 189                      *
*               33604 Bielefeld                            *
*               Germany                                    *
*               e-mail: info@artsoft.org                   *
*----------------------------------------------------------*
* conf_grp.h                                               *
***********************************************************/

/* ----- this file was automatically generated -- do not edit by hand ----- */

#ifndef CONF_GRP_H
#define CONF_GRP_H

/* values for elements configuration (group elements) */

#define EL_GROUP_1			(EL_GROUP_START + 0)
#define EL_GROUP_2			(EL_GROUP_START + 1)
#define EL_GROUP_3			(EL_GROUP_START + 2)
#define EL_GROUP_4			(EL_GROUP_START + 3)
#define EL_GROUP_5			(EL_GROUP_START + 4)
#define EL_GROUP_6			(EL_GROUP_START + 5)
#define EL_GROUP_7			(EL_GROUP_START + 6)
#define EL_GROUP_8			(EL_GROUP_START + 7)
#define EL_GROUP_9			(EL_GROUP_START + 8)
#define EL_GROUP_10			(EL_GROUP_START + 9)
#define EL_GROUP_11			(EL_GROUP_START + 10)
#define EL_GROUP_12			(EL_GROUP_START + 11)
#define EL_GROUP_13			(EL_GROUP_START + 12)
#define EL_GROUP_14			(EL_GROUP_START + 13)
#define EL_GROUP_15			(EL_GROUP_START + 14)
#define EL_GROUP_16			(EL_GROUP_START + 15)
#define EL_GROUP_17			(EL_GROUP_START + 16)
#define EL_GROUP_18			(EL_GROUP_START + 17)
#define EL_GROUP_19			(EL_GROUP_START + 18)
#define EL_GROUP_20			(EL_GROUP_START + 19)
#define EL_GROUP_21			(EL_GROUP_START + 20)
#define EL_GROUP_22			(EL_GROUP_START + 21)
#define EL_GROUP_23			(EL_GROUP_START + 22)
#define EL_GROUP_24			(EL_GROUP_START + 23)
#define EL_GROUP_25			(EL_GROUP_START + 24)
#define EL_GROUP_26			(EL_GROUP_START + 25)
#define EL_GROUP_27			(EL_GROUP_START + 26)
#define EL_GROUP_28			(EL_GROUP_START + 27)
#define EL_GROUP_29			(EL_GROUP_START + 28)
#define EL_GROUP_30			(EL_GROUP_START + 29)
#define EL_GROUP_31			(EL_GROUP_START + 30)
#define EL_GROUP_32			(EL_GROUP_START + 31)

#endif	/* CONF_GRP_C */
