-------------------------------
Commander Keen
The Really Big
"Unofficial" Commander Keen FAQ
by Dave "Flaose" Allen
flaose@hotmail.com
Version 2.01
17/01/11
-------------------------------

------------
Introduction
------------
Hello, and welcome to my Commander Keen FAQ.  I hope that by the time you
finish reading this, you will have a vast knowledge of Commander Keen, his
universe, and a few cold hard facts, without starting to foam at the mouth and
babble senseless phrases (except, perhaps, Shikadi).  If you are prepared, read
on brave soldier.

Table of Contents
 [1] General Information
	 [1.1] General Disclaimer and Legal Stuff
	 [1.2] Who am I?
	 [1.3] Why am I writing this?
	 [1.4] What are the Official Commander Keen games?
		 [1.4.1] Marooned on Mars
		 [1.4.2] The Earth Explodes
		 [1.4.3] Keen Must Die!
		 [1.4.4] Keen Dreams
		 [1.4.5] Secret of the Oracle
		 [1.4.6] The Armageddon Machine
		 [1.4.7] Aliens Ate My Baby Sitter!
		 [1.4.8] Commander Keen
	 [1.5] Who made the Commander Keen games?
	 [1.6] Will there be more Commander Keen games?
	 [1.7] Why play Commander Keen?
	 [1.8] Where can I get Commander Keen?
	 [1.9] What is Shareware?
	 [1.10] What's up with id and 3D Realms?
	 [1.11] A note on Pirating
	 	 [1.11.1] What is Pirating?
		 [1.11.2] What I've accidentally pirated a game?
	 [1.12] Who can distribute this FAQ?
	 [1.13] Revision History
 [2] Commander Keen's Universe (Also Known as The Meat)
	 [2.1] Who or what is Commander Keen?
	 [2.2] What other games has Commander Keen appeared in?
	 [2.3] How do I control Commander Keen?
		 [2.3.1] Invasion of the Vorticons
		 [2.3.2] Keen Dreams
		 [2.3.3] Goodbye, Galaxy!
		 [2.3.4] Aliens Ate My Baby Sitter!
	 	 [2.3.5] Commander Keen
	 [2.4] What is the difference between difficulty levels?
		 [2.4.1] Keen Dreams
		 [2.4.2] Goodbye, Galaxy!
		 [2.4.3] Aliens Ate My Baby Sitter!
		 [2.4.4] Commander Keen
	 [2.5] Who are Commander Keen's friends?
		 [2.5.1] Marooned on Mars
		 [2.5.2] The Earth Explodes
		 [2.5.3] Keen Must Die!
		 [2.5.4] Keen Dreams
		 [2.5.5] Secret of the Oracle
		 [2.5.6] The Armageddon Machine
		 [2.5.7] Aliens Ate My Baby Sitter!
		 [2.5.8] Commander Keen
	 [2.6] Who are Commander Keen's enemies?
		 [2.6.1] Marooned on Mars
		 [2.6.2] The Earth Explodes
		 [2.6.3] Keen Must Die!
		 [2.6.4] Keen Dreams
		 [2.6.5] Secret of the Oracle
		 [2.6.6] The Armageddon Machine
		 [2.6.7] Aliens Ate My Baby Sitter!
		 [2.6.8] Commander Keen
	 [2.7] What are the worlds Commander Keen visits?
	 [2.8] How does Commander Keen get around?
	 [2.9] What goodies can I pick up on my journeys?
		 [2.9.1] Marooned on Mars
		 [2.9.2] The Earth Explodes
		 [2.9.3] Keen Must Die!
		 [2.9.4] Keen Dreams
		 [2.9.5] Secret of the Oracle
		 [2.9.6] The Armageddon Machine
		 [2.9.7] Aliens Ate My Baby Sitter!
		 [2.9.8] Commander Keen
	 [2.10] What's the name of Keen's pet Yorp?
	 [2.11] What's this I hear about Billy Blaze's extended family?
	 [2.12] What is this 'Dopefish'?
 [3] The Official Commander Keen Games and Stories
	 [3.1] What's the Story Behind Invasion of the Vorticons?
		 [3.1.1] Marooned on Mars
		 [3.1.2] The Earth Explodes
		 [3.1.3] Keen Must Die!
	 [3.2] What's the Story Behind Keen Dreams?
	 [3.3] What's the Story Behind Secret of the Oracle?
	 [3.4] What's the Story Behind The Armageddon Machine?
	 [3.5] What's the Story Behind Aliens Ate My Baby Sitter!?
	 [3.6] What's the Story Behind Commander Keen?
 [4] The Lyrics
	 [4.1] What are the Lyrics to Eat Your Veggies?
	 [4.2] What are the Lyrics to Aliens Ate My Baby Sitter!?
 [5] The Standard Galactic Alphabet
	 [5.1] What is the Standard Galactic Alphabet?
	 [5.2] What do all the Signs Say?
		 [5.2.1] Marooned on Mars
		 [5.2.2] The Earth Explodes
		 [5.2.3] Keen Must Die!
		 [5.2.4] Secret of the Oracle
		 [5.2.5] The Armageddon Machine
		 [5.2.6] Aliens Ate My Baby Sitter!
		 [5.2.7] Commander Keen
 [6] The Hints, Tips, and Other Funny Things
	 [6.1] What are some Hints for Invasion of the Vorticons?
		 [6.1.1] Marooned on Mars
		 [6.1.2] The Earth Explodes
		 [6.1.3] Keen Must Die!
	 [6.2] What are some Hints for Keen Dreams?
	 [6.3] What are some Hints for Goodbye, Galaxy!?
		 [6.3.1] Secret of the Oracle
		 [6.3.2] The Armageddon Machine
	 [6.4] What are some Hints for Aliens Ate My Baby Sitter!?
	 [6.5] What are some Hints for Commander Keen?
 [7] The Cheat Codes
	 [7.1] What are the Cheat Codes for Invasion of the Vorticons?
	 [7.2] What are the Cheat Codes for Keen Dreams?
	 [7.3] What are the Cheat Codes for Goodbye, Galaxy!?
	 [7.4] What are the Cheat Codes for Aliens Ate My Baby Sitter!?
	 [7.5] What are the Cheat Codes for Commander Keen?
 [8] The Maps
 	 [8.1] What's the Layout of Marooned on Mars?
	 [8.2] What's the Layout of The Earth Explodes?
	 [8.3] What's the Layout of Keen Must Die!?
	 [8.4] What's the Layout of Keen Dreams?
	 [8.5] What's the Layout of Secret of the Oracle?
	 [8.6] What's the Layout of The Armageddon Machine?
	 [8.7] What's the Layout of Aliens Ate My Baby Sitter!?
	 [8.8] What's the Layout of Commander Keen?
 [9] The Walkthroughs
	 [9.1] How do I get through Marooned on Mars?
	 [9.2] How do I get through The Earth Explodes?
	 [9.3] How do I get through Keen Must Die!?
	 [9.4] How do I get through Keen Dreams?
	 [9.5] How do I get through Secret of the Oracle?
	 [9.6] How do I get through The Armageddon Machine?
	 [9.7] How do I get through Aliens Ate My Baby Sitter!?
	 [9.8] How do I get through Commander Keen?
 [10] The Endings
	 [10.1] What's the Ending to Marooned on Mars?
	 [10.2] What's the Ending to The Earth Explodes?
	 [10.3] What's the Ending to Keen Must Die!?
	 [10.4] What's the Ending to Keen Dreams?
	 [10.5] What's the Ending to Secret of the Oracle?
	 [10.6] What's the Ending to The Armageddon Machine?
	 [10.7] What's the Ending to Aliens Ate My Baby Sitter!?
	 [10.8] What's the Ending to Commander Keen?
 [11] Now What?
 [12] The End of it All
 [13] Acknowledgments



-----------------------
[1] General Information
-----------------------
And in the beginning, God created Heaven and Earth, and Lawyers.  Therefore,
thou shalt have legal stuff in order. Dig in, while it's warm.


[1.1] General Disclaimer and Legal Stuff
	I AM NOT AN EMPLOYEE OF APOGEE SOFTWARE, LTD OR ID SOFTWARE LLC.  THIS
FAQ WAS DONE IN MY RECREATIONAL TIME, OBEYING ALL LAWS THAT PERTAIN TO MY PLACE
OF RESIDENCE.  I AM IN NO WAY RESPONSIBLE FOR ANY ERRORS I OR ANYONE ELSE HAVE
MADE.  COMMANDER KEEN IS A TRADE MARK AND COPYRIGHT OF ID SOFTWARE.  ALL OTHER
COPYRIGHTS AND TRADEMARKS ARE PROPERTIES OF THEIR RESPECTIVE OWNERS.  ALL ARE
USED WITHOUT PERMISSION.  I AM IN NO WAY LIABLE FOR ANY HEALTH EFFECTS CAUSED BY
THE READING OF THIS DOCUMENT, INCLUDING, BUT NOT LIMITED TO: CONGESTIVE HEART
FAILURE, BLINDNESS, VOMITING, NAUSEA, DIARRHEA, INDIGESTION, HEARTBURN,
BLOATING, CONSTIPATION, STARVATION, AND MALNUTRITION.  THIS FAQ MAY BE
DISTRIBUTED IN ANY FORM AS LONG AS: A) IT IS IN ORIGINAL AND UNEDITED GLORY, B)
CREDIT IS GIVEN TO ME, THE AUTHOR, C) IT IS THE MOST CURRENT VERSION PERTAINING
TO THE DISTRIBUTOR'S KNOWLEDGE, D) NOTHING IS CHARGED FOR IT (BUT I'M PRETTY
SURE NO ONE WOULD PAY MONEY FOR THIS).  FOLLOW THE SHAVED BLUE GONADS. BY THE
WAY, IF YOU'RE ACTUALLY STILL READING, YOU'VE GOT WAY TOO MUCH TIME ON YOUR
HANDS, AND THERE'S WAY MORE INTERESTING STUFF TO READ.  GET GOING!


[1.2] Who am I?
	My name is Dave Allen, known to most of the Internet community as Flaose
(flay-oase).  I'm Canadian, and far too old to still be playing Commander Keen.
But enough about me, how are you?


[1.3] Why am I writing this?
	I wrote this FAQ for two reasons: 1) At the time I began, there was only
one Commander Keen FAQ, and it wasn't all that comprehensive.  I wanted to write
a FAQ that would cover every facet of the Commander Keen games.  2) I felt that
I hadn't made a great enough contribution to the Commander Keen society, but
this is it, The Big One.


[1.4] What are the Official Commander Keen games?
	There are eight official Commander Keen games.  Seven made for the PC in
the early 90s, and one made more recently for the Game Boy Color.  In this
section, basic game information will be given: each game's complete title,
original release date, and a list of available versions (with the notable
differences between each).

[1.4.1] Marooned on Mars

	Complete Title: 
	Commander Keen in "Invasion of the Vorticons"
	Episode One: Marooned on Mars

	Original Release Date:
	December 14, 1990 (DOS)

	Known Versions:
	November 1990
	Beta		-	Very different from final release
				Tank Robot shoots lower
				Completion of Red Maze City is mandatory
				Yorp statue in First Red Rock Shrine gives a
				completely different message
				Story screen shows cutscene of Vorticon stealing
				Bean-with-Bacon Megarocket parts
				Game not winnable, ending not implemented
				No God mode cheat
				Various other differences in level design

	December 1990
	Beta		- 	Possibly version 1.0
				Earlier preview screenshots of Keens 2 and 3
				God mode doesn't allow walking through solid
				tiles on world map

	v1.1		-	Initial public release

	v1.3		-	Removed /LEVEL command-line parameter

	v1.31		-	Added note at startup about graphics being
				decompressed

	v1.32		-	Release by Advanced Gravis Computer Technology
				Added large opening splash screen offering
				an ordering discount for Gravis customers

	v1.34		-	Release by Precision Software Applications
				Removed info about "Fight for Justice" and
				replaced it with info about Goodbye, Galaxy!
				Changed ordering information 

[1.4.2] The Earth Explodes

	Complete Title: 
	Commander Keen in "Invasion of the Vorticons"
	Episode Two: The Earth Explodes

	Original Release Date:
	December 18, 1990 (DOS)

	Known Versions:
	v1.0		-	Initial release

	v1.1		-	Fixed text scrolling speed on faster computers
				Removed broken F8 screenshot function

	v1.31		-	Added command-line parameter /K fixing beeping
				keyboard problem

	v1.32		-	Release by Precision Software Applications
				Removed info about "Fight for Justice" and
				replaced it with info about Goodbye, Galaxy!

[1.4.3] Keen Must Die!

	Complete Title: 
	Commander Keen in "Invasion of the Vorticons"
	Episode Three: Keen Must Die!

	Original Release Date:
	December 18, 1990 (DOS)

	Known Versions:
	v1.0		-	Initial release

	v1.1		-	Yellow keycard can now be obtained in Fort
				Cavort
				Schoolhouse in Secret City can now be reached
				without cheats
				Fixed text scrolling speed on faster computers
				Removed broken F8 screenshot function

	v1.31		-	Added command-line parameter /K fixing beeping
				keyboard problem

	v1.32		-	Release by Precision Software Applications
				Removed info about "Fight for Justice" and
				replaced it with info about Goodbye, Galaxy!

[1.4.4] Keen Dreams

	Complete Title: 
	Commander Keen in "Keen Dreams"

	Original Release Date:
	Second Half of 1991 (DOS)

	Known Versions:
	v1.0 - Initial commercial release

	v1.01		-	Initial shareware release
				Changed initialization screen
				Removed 'Cast of Characters' from help screen
				Removed mention of both undeveloped game
				'Commander Keen Meets the Meats' and 'Goodbye,
				Galaxy!'
				Updated title screen
				Added debug level
				Removed joystick support (for some reason)

	v1.13		-	Second shareware release
				Joystick support once again included

	v1.92 REV 0	-	Second commercial release
				Trademarks and copyright date added to title
				screen
				Nearly identical to v1.13

	v1.93 REV 1	-	Third commercial release
				Added start-up shell with notices, hints, and
				tips
				Copyright date on title screen changed to
				1991-93

[1.4.5] Secret of the Oracle

	Complete Title: 
	Commander Keen in "Goodbye, Galaxy!"
	Episode Four: Secret of the Oracle

	Original Release Date:
	December 15, 1991 (DOS)

	Known Versions:
	Demo Version	-	Pre-release demo promoting Aliens Ate My Baby
				Sitter!
				Only EGA version known to exist
				Contains only six levels from the full game
				The only music is on the world map, and it is an
				earlier	version of the song contained in the
				final release
				A+2+ENTER is not required to activate cheats
				Cheat codes B+A+T, E+N+D, and F10+Y not
				implemented
				Minor level differences 

	v1.0		-	Initial public release
				Both CGA and EGA versions available

	v1.1		-	Both CGA and EGA versions available
				Fixed game-ruining bug in which collected gems
				would not be saved

	v1.2		-	Both CGA and EGA versions available
				Updated help menu content and color
				Introduced some erroneous information in help
				text

	v1.4		-	Both CGA and EGA versions available
				Fixed erroneous information in help text
				Added "Fix Jerky Motion" option
				Added support for four-button joysticks
				Updated copyright date to 1992

	v1.4 (FormGen)	-	Distributed by FormGen Corporation
				Both CGA and EGA versions available
				Changed ordering information listing FormGen as
				the game's only distributor

	v1.4 (GT
	Interactive)	-	Distributed by GT Interactive Software
				EGA version only
				Removed ordering information
				Updated id Software section of help menu

[1.4.6] The Armageddon Machine

	Complete Title: 
	Commander Keen in "Goodbye, Galaxy!"
	Episode Five: The Armageddon Machine

	Original Release Date:
	December 18, 1991 (DOS)

	Known Versions:
	v1.0		-	Initial public release
				Both CGA and EGA versions available

	v1.4		-	Both CGA and EGA versions available
				Added "Fix Jerky Motion" option
				Added support for four-button joysticks
				Playing Korath III Base on Easy no longer
				crashes the game
				Shelleys now push Keen instead of turning around
				on contact
				Changed graphical result of F10+Y cheat
				Updated copyright date to 1992

	v1.4 (GT
	Interactive)	-	Distributed by GT Interactive Software
				EGA version only
				Removed swastika in Energy Flow Systems
				Fixed typo on fuse structure warning signs
				Removed ordering information
				Updated id Software section of help menu

[1.4.7] Aliens Ate My Baby Sitter!

	Complete Title: 
	Commander Keen in "Aliens Ate My Baby Sitter!"

	Original Release Date:
	November 1991 (DOS)

	Known Versions:
	v1.0		-	Initial public release
				Both CGA and EGA versions available

	Special Demo
	Version		-	EGA version only
				Only four levels playable
				Other levels blocked off and have Yorps
				sitting on 'DEMO' signs
				Keen starts with grappling hook
				E+N+D cheat restarts current level
				Added ordering info

	Promotional
	Release	Version	-	Release by Precision Software Applications
				EGA version only
				Only four levels playable
				Other levels blocked off and have Yorps
				sitting on '????' signs
				Keen starts with grappling hook
				Removed E+N+D cheat
				High Score table changed
				Ordering info changed

	v1.4 		-	Second commercial version, changes compared to
				v1.0
				Both CGA and EGA versions available
				Fixed game-ruining bug in which collected gems
				would not be saved
	       			Added bug wherein Molly doesn't stay in her
				cage properly, making the final level easier
				Added "Fix Jerky Motion" option
				Added support for four-button joysticks
				Added B+A+T cheat
				Most cheats now have to be enabled with
				A+2+ENTER
				Changed background color of end sequence
				F10+P cheat no longer freezes game
				Updated copyright date to 1992

	v1.5		-	Third commercial version
				Both CGA and EGA versions available
				Fixed bug where Molly doesn't stay in her cage
				Fixed typo in Bloogfoods, Inc. entrance text
				Fixed flashing arrow in ending sequence (its
				background remained grey in v1.4)
				F10+P cheat once again freezes game

[1.4.8] Commander Keen

	Complete Title: 
	Commander Keen

	Original Release Date:
	May 30, 2001 (GBC)

	Known Versions:
	Initial	Release	-	The only version of the game known to exist
				Believed to be v1.0


[1.5] Who made the Commander Keen games?
	Those who are credited with working on the first seven Commander Keen
games are the Programmers, John Carmack, John Romero, and Jason Blochowiak;
Artist Adrian Carmack (he's not related to John, really!); Creative Director Tom
Hall, whom all other Creative Directors fear because of all his great ideas; CEO
Jay Wilbur; and Musician Bobby Prince, the who composed the music for Commander
Keens 4 - 6.

	Being more modern, Commander Keen, the Game Boy Color game, has a much
longer credit list.  Though the game was probably developed completely by David
A. Palmer Productions, I'll reproduce the complete credits found in the manual
to avoid missing anyone:

	Developed by David A. Palmer Productions
	Producer: David A. Palmer
	Associate Producer: James Palmer
	Lead Programmer: Roo
	Lead Artist: Jim Meston
	Support Artists: Martin Turner, Ian Terry
	Music and Sound Effects: Mark Cooksey
	Tester: Neil Palmer
	Special Thanks: David M. Boyles, Gail Oxley, Peter Leonard, Helen Bark

	Id Software is
	Programming: John Carmack, Robert A. Duffy, Jim Dose
	Art: Adrian Carmack, Kevin Cloud, Kenneth Scott, Seneca Menard,
	     Fred Nilsson
	Level Design: Tim Willits, Christian Antkow, Paul Jaquays,
		      Mal Blackwell
	Game Design: Graeme Divine
	CEO: Todd Hollenshead
	Director of Business Development: Marty Stratton
	id mom: Donna Jackson
	Development Assistance: Eric Webb

	Published by Activision
	Associate Producer: Steven Rosenthal
	Executive Producer: Laird M. Malamed
	V.P. of Studio: Mark Lamia
	Production Testing: Brelan Duff
	Director, Global Brand Management: Dusty Welch
	Brand Manager: Kevin Kraff
	Associate Brand Manager: Brad Carraway
	Senior Publicist: Michael James Larson
	V.P., Creative Services: Denise Walsh
	Mgr., Creative Services: Jill Barry

	Manual by Ignited Minds, LLC
	Documentation Manager: Mike Rivera
	Documentation Layout: Belinda M. Van Sickle, Sylvia Orzel

	Packaging Creative by Focus 2
	Designer: Patrick Amann
	President and Creative Director: Todd Hart

	Special Thanks: Matt Morton, Brian Clarke, Larry Goldberg, George Rose,
			Gregory Deutsch, Graham Fuchs, Stacy Sooter,
			Brian Simkin, Kathy Vrabeck

	Activision Quality Assurance
	QA Project Leads: Blaine Christine, Anthony Hatch Korotko
	QA Senior Project Leads: Benjamin-lee DeGuzman, Adam Hartsfield
	QA Manager, Console Testing: Joseph Favazza
	Test Team: Eric Rodriguez, Tim Ogle, Kirk Kosinski, Erin Martel,
		   Jeffry Moxley, Chad Fazzaro, Patrick Hearne
	Customer Support Mgr.: Bob McPherson
	Customer Support Leads.: Rob Lim, Gary Bolduc, Mike Hill
	QA Special Thanks: Jim Summers, Jason Wong, Tim Vanlaw,
			   Nadine Theuzillot, Sam Nouriani, Jeremy Gage,
			   Bob McPherson, Ed Clune, Kragen Lum, Indra Gunawan,
			   Todd Komesu, Tanya Langston, Willie Bolton,
			   Nicholas Favazza, Margarita Umil, Jessica Christine


[1.6] Will there be more Commander Keen games?
	About 10 years ago, Joe Siegler (the 3D Realms webmaster at the time)
had this to say about the future of Commander Keen:

	'If you played Keen 5, there was a screen that said something to the
	effect of "Join us in December 1992 for the greatest Keen adventure
	yet".  There was a picture of Keen smiling, with a Santa Claus hat on.
	At the time, id Software was intending to do a third series of Commander
	Keen, tentatively entitled "Commander Keen: The Universe is Toast".
	However, other projects came up (Wolfenstein 3D, Spear of Destiny, and
	later, Doom).  There are no plans now to do more Keen. The main reason
	for this is that id Software owns the rights to Commander Keen, and any
	new project would have to be either done by them directly (EXTREMELY
	unlikely), or at least approved by them. At this time, there are no Keen
	games under development by Apogee, id, or Monkeystone (where Tom Hall &
	John Romero now work as of 2001).  If and when there ever is more Keen,
	it will be state of the art of whatever technology is current at the
	time.  In December of 1998, Tom Hall has stated his interest in making
	future games based on his character Keen and his universe, but only if
	he owned the rights to Keen, which is also unlikely.'

	A year or two after Joe gave this answer, a new Commander Keen game was
developed for the Game Boy Color.  Titled simply 'Commander Keen', it was
developed without the input of Tom Hall (the creative director of the original
games) by David A. Palmer Productions.  More details, of course, are found in
the other sections of the FAQ.

	So will there be more Commander Keen games?  Though side-scrollers are
enjoying a bit of a renaissance these days, I personally doubt it.  The Game Boy
Color game wasn't a huge financial success, and there really is no reason to
continue a 20 year old franchise that doesn't bring in large amounts of money.
There was at one point informal talks between id and Monkeystone regarding a
compilation of the DOS Keen games for the Pocket PC that was to be called Keen
Chronicles.  The game, however, didn't really go beyond a concept logo that can
still be found floating around the internet.  But enough about the depressing
future, it's time to find out why you should play Commander Keen and where you
can get it.


[1.7] Why play Commander Keen?
	Commander Keen is an in-depth and complex side-scrolling game (well,
that first part might be stretching the truth), in which you control a cute
little eight year old through dozens of levels, to finally complete your goal.
After every game, the plot thickens a little more.  It's also a very fast game,
literally, it runs at around 40 frames per second, compare that to some games
these days.  It is also a tense experience, one hit to keen, and he's dead.
Hilarity is everywhere, as long as you can translate the alien script (good
thing you have this FAQ)!  So what are you waiting for?  Find out where to get
the Commander Keen games!


[1.8] Where can I get Commander Keen?
	Being 20 year old game series, you might think that the Commander Keen
games would be very difficult to find.  In one case you'd be right, but most of
the Keen games are surprisingly easy to legally acquire.  By far the easiest
games to get are Commander Keens 1-5.  The are available in 3D Realms' online
store (http://www.buy3drealms.com) and on Steam (http://store.steampowered.com/)
for even cheaper!  Keen Dreams is available from current distributer Flat Rock
Software at http://www.downloadstore.com.  Please note that in all cases, these
are digital downloads only.  Should you wish to acquire hard copies, Keen 6, or
the Game Boy Color game Commander Keen, things can get a little more difficult
(or expensive).  eBay (http://www.ebay.com) is certainly your best resource for
these items though be warned that copies of the PC Commander Keen games are
generally selling for outrageous prices (usually around $100 USD), though the
Game Boy Color game is usally far more reasonably priced.  Other good places to
search include pawn shops, thrift stores, and flea markets.  Good luck in your
searches!

	Of course, in all this there is good news!  It is perfectly legal to
download the demos of Keen 4 and Keen 6, and the shareware versions of Keen 1,
Keen Dreams, and Keen 4.  Speaking of which...


[1.9] What is Shareware?
	Originally, the term shareware described a full-blown software product
that relied on user's honesty (and pocketbooks) to support the author.
Understandably, most shareware was a commercial failure; why register when you
have the full product already.  Knowing this, Scott Miller came up with a new
shareware strategy to market his game 'Kingdom of Kroz' ('I have this cunning
plan' he said / As he lay upon his bed): He would release an 'episode' of the
game to the unsuspecting gaming public.  If the consumer liked the game, they
could pay a fee to register it, and receive the remaining 'episodes' and
therefore more excellent gameplay.  It was a 'try before you buy' system, if
you will.  Needless to say, Kroz was a commercial success, and it
revolutionized the shareware industry.  This became known as the 'Apogee
Model', and was the precursor to the playable demos that are regularly released
by gaming companies these days to entice players to purchase their games.


[1.10] What's up with id and 3D Realms?
	id Software was the company who developed Commander Keen, Apogee
Software, now known as 3D Realms, published it.  They had something of a falling
out around the time of DOOM, id Software saying Apogee wasn't serious enough
about their business.  Even after this falling out, many employees of id and 3D
Realms continued their amicable relationships.  In a business sense, however, id
and 3D Realms are in no way related.


[1.11] A note on Pirating
	Arr me maties.  With pirating ye are squandering it all.

[1.11.1] What is Pirating?
	Pirating is the unlawful breaking of the copyright of a game, by giving
away, or selling it without removing the original copy from your computer.  So
say I just got Commander Keen 3, and I give it to my friend, than my friend
gives it to three of his friends, who each give it to three of their friends,
and so on and so on.  In the end, 3D Realms will have lost perhaps thousands of
dollars.  Now imagine if everyone does it.  Companies will have to start laying
off workers, which means crap games that take years to complete.  Eventually,
the industry will be no more, and we wouldn't want that, would we?

[1.11.2] What I've accidentally pirated a game?
	Hey, it happens.  However, make sure you buy the game promptly from the
store or company.  Your conscience will be clear, and your favorite game company
will still be able make more great games.  Everybody wins!


[1.12] Who can distribute this FAQ?
	Permission is expressly granted to distribute this FAQ in any way,
shape, or form, provided that the rules set out in section [1.1] are followed.


[1.13] Revision History
	v.0.98b (??/??/??):	Original version, edited by me.
	v.0.99b (??/??/??):	Controlled Release
	v.1.00  (10/12/99):	First Public Release!  It's actually a FAQ!  A
				few minor changes.
	v.1.01  (18/12/99): 	A very minor change.  Unreleased
	v.1.10  (25/01/00): 	Removed some material, updated section [1.6]
				Will there be more Commander Keen games?
	v.1.99  (02/06/03): 	Less is More!  Entire Text Updated and converted
				to .txt file for universal accessibility.
				Removed some superfluous sections.
	v.2.00  (12/01/11):	The final version!  Includes all previously
				promised material and full coverage of the Game
				Boy Color game Commander Keen.  It's a 20th
				Anniversary Extravaganza!
	v.2.01  (17/01/11):	Fixed obvious (but missed) error in section
				[2.3.3], also created game-specific versions
				of the FAQ, listed as 2.01.x, in order to comply
				with GameFAQs' current policies.



------------------------------------------------------
[2] Commander Keen's Universe (Also Known as The Meat)
------------------------------------------------------
Commander Keen's universe is also our universe, everything that is in his
universe is in our universe, and everything that happens in his universe
happens in our universe.  Watch the skies.


[2.1] Who or what is Commander Keen?
	Commander Keen is the alter-ego of eight year old Billy Blaze.  When
Billy dons his brothers' football helmet, he becomes COMMANDER KEEN!  Defender
of Earth with an iron fist.


[2.2] What other games has Commander Keen appeared in?
	In addition to the eight Commander Keen games, Commander Keen has made
cameo appearances in the following places:

	- The super-secret level of Doom II (level 32)
	- As a hostage in Bio Menace
	- In a message in Pickle Wars (originally planned to be an Apogee game)
	- In a dialog box in the original Duke Nukem
	- His helmet is found in three levels of Crystal Caves
	- A character named Commander Keen aids the protagonist in Wolfenstein
	RPG
	- B. Blaze owns an apartment in Tom Hall's Anachronox
	- B. Blaze is again mentioned in the classic Epic Games side-scroller
	Jill of the Jungle.

	Though the Dopefish is a far more popular character for cameos, it is
certain that as long as there are people who remember Keen, there will be
Commander Keen cameos.


[2.3] How do I control Commander Keen?
	Controlling Commander Keen is generally a straight-forward affair, but
just in case you need help, here are the controls for each game.

[2.3.1] Invasion of the Vorticons
	Keyboard:
	Up - UP ARROW
	Down - DOWN ARROW
	Left - LEFT ARROW
	Right - RIGHT ARROW
	Jump - CTRL
	Pogo - ALT
	Shoot - CTRL + ALT
	Push Button/Pull Lever - ALT

	Joystick:
	Up - UP
	Down - DOWN
	Left - LEFT
	Right - RIGHT
	Jump - BUTTON 1
	Pogo - BUTTON 2
	Shoot - BUTTON 1 + BUTTON 2
	Push Button/Pull Lever - BUTTON 2

	Common Controls:
	Status Screen - SPACE
	Help - F1
	Sound Toggle - F2
	Re-map Keyboard - F3
	Joystick Calibration - F4
	Save Game - F5
	Quit - ESC

[2.3.2] Keen Dreams
	Keyboard:
	Up/Climb Pole - UP ARROW
	Down/Duck/Descend Pole - DOWN ARROW
	Left - LEFT ARROW
	Right - RIGHT ARROW
	Jump Up - CTRL
	Jump Down - DOWN ARROW + CTRL
	Throw - ALT

	Joystick:
	Up/Look Up/Climb Pole/Toggle Switch - UP
	Down/Duck/Descend Pole - DOWN
	Left - LEFT
	Right - RIGHT
	Jump Up - BUTTON 1
	Jump Down - DOWN + BUTTON 1
	Throw - BUTTON 2

	Common Controls:
	Status Screen - SPACE
	Help - F1
	Sound Menu - F2
	Keyboard Menu - F3
	Resume Game - F4
	New Game - F5
	Load/Save Game - F6
	Music Menu - F7
	Quit/Cancel - ESC

	*Note that even though a menu option exists, there is no music in Keen
Dreams.

[2.3.3] Goodbye, Galaxy!
	Keyboard:
	Up/Look Up/Climb Pole/Toggle Switch - UP ARROW
	Down/Look Down/Descend Pole - DOWN ARROW
	Left - LEFT ARROW
	Right - RIGHT ARROW
	Jump Up - CTRL
	Jump Down - DOWN ARROW + CTRL
	Pogo - ALT

	Joystick:
	Up/Look Up/Climb Pole/Toggle Switch - UP
	Down/Look Down/Descend Pole - DOWN
	Left - LEFT
	Right - RIGHT
	Jump Up - BUTTON 1
	Jump Down - DOWN + BUTTON 1
	Pogo - BUTTON 2

	*Note that if you choose the Gravis Gamepad control option you can map
the additional joystick buttons to both the Shoot and Status Screen actions.

	Common Controls:
	Shoot - SPACE
	Status Screen - ENTER
	Help - F1
	Go to Control Panel - ESC, F2-F7
	Boss Key - F9
	Quit/Cancel - ESC (from Control Panel)

[2.3.4] Aliens Ate My Baby Sitter!
	Keyboard:
	Up/Look Up/Climb Pole/Toggle Switch - UP ARROW
	Down/Look Down/Descend Pole - DOWN ARROW
	Left - LEFT ARROW
	Right - RIGHT ARROW
	Jump Up - CTRL
	Jump Down - DOWN ARROW + CTRL
	Pogo - ALT

	Joystick:
	Up/Look Up/Climb Pole/Toggle Switch - UP
	Down/Look Down/Descend Pole - DOWN
	Left - LEFT
	Right - RIGHT
	Jump Up - BUTTON 1
	Jump Down - DOWN + BUTTON 1
	Pogo - BUTTON 2

	*Note that if you choose the Gravis Gamepad control option you can map
the additional joystick buttons to both the Shoot and Status Screen actions.

	Common Controls:
	Shoot - SPACE
	Status Screen - ENTER
	Go to Control Panel - ESC, F2-F7
	Boss Key - F9
	Quit/Cancel - ESC (from Control Panel)

[2.3.5] Commander Keen
	Up/Look Up/Climb Pole - UP ARROW
	Down/Look Down/Descend Pole - DOWN ARROW
	Left - LEFT ARROW
	Right - RIGHT ARROW
	Jump - A BUTTON
	Pogo - DOWN + A BUTTON
	Shoot - B BUTTON
	Use Switch/Teleporter/Push Button - SELECT
	Status/Pause - START


[2.4] What is the difference between difficulty levels?
	Starting with the development of Keen Dreams, id began to implement
difficulty levels.  As might be expected there are three levels of difficulty:
Easy, Normal (or Medium, in the case of the game Commander Keen), and Hard.
The following lists the affect difficulty level has on each game.

[2.4.1] Keen Dreams
	In Keen Dreams, the difficulty level only changes how long your Flower
Power will transform an enemy.  In Easy it's about 11 seconds, in Normal about
5 seconds, and in Hard Flower Power lasts a mere 3 seconds!

[2.4.2] Goodbye, Galaxy!
	In Goodbye, Galaxy!, the difficulty level causes a somewhat greater
change.  The harder the difficulty, the greater that gravity affects your jump
height and speed.  In Easy you'll find that Keen is quite floaty, jumping high
and falling slowly whereas in Hard he jumping trajectory is much tighter and he
falls much faster.  In Easy, each Neural Stunner that you grab will give you 8
additional shots, but in Normal and Hard you'll only receive 5 more.  Finally,
the amount of enemies you encounter will increase with the difficulty level.

[2.4.3] Aliens Ate My Baby Sitter!
	The difficulty levels in Aliens Ate My Baby Sitter! have similar
effects as those Goodbye, Galaxy!  You will still find that Keen is a little
floaty on Easy difficulty, but in this game there is no difference in jumping
behaviour between the Normal and Hard difficulty levels.  Once again each
Neural Stunner that you obtain will give you an additional 8 shots in Easy and
an additional 5 shots in Normal and Hard, and once again the number of enemies
will increase will the difficulty level.  You will also find that more or less
platforms will appear to aid you in difficult jumps.  This is especially evident
in the first part of the final level, the Bloog Control Center; in Easy this
part is quite simple to pass whereas in Hard it requires near-perfect jumping
skills.

[2.4.4] Commander Keen
	In Commander Keen, the difficulty level causes various effects.  In
Easy mode you begin the game with 9 lives and 9 continues.  You earn an extra
life for every 1000 points, and an extra continue for every 100 goodies that you
collect.  As well, your Neural Ray Blaster will stun enemies for about 6
seconds.  In Medium difficulty you begin the game with 7 lives and 7 continues.
You earn an extra life for every 1500 points, and an extra continue for every
150 goodies that you collect.  As well, your Neural Ray Blaster will stun
enemies for about 3.5 seconds.  In the Hard difficulty you begin the game with
only 5 lives and 5 continues.  You earn an extra life for every 3000 points, and
an extra continue for every 175 goodies that you collect.  As well, your Neural
Ray Blaster will stun enemies for about 3 seconds.  What's more, enemy behaviour
will change with difficulty level.  On Easy they follow simple patterns and are
easy to shoot, but on Hard they'll move like lightning, dodge your shots, and
shoot with a much higher accuracy.


[2.5] Who are Commander Keen's friends?
	Unfortunately, Commander Keen has very few friends in the universe 
(that would suck, wouldn't it?), but for what it's worth here they are.  An
asterisk (*) denotes that an official name has never been released and that a
common unofficial name is used instead.

[2.5.1] Marooned on Mars
	Yorps: 				These lovable, one-eyed green Martians
					are friendly.  Very friendly.  Too
					friendly.

	Butler "Tin Can" Robots: 	A nice little Martian robot that has
					trouble keeping his hat on.  He is nice
					except for the fact that he usually
					pushes you off a platform to your death.

[2.5.2] The Earth Explodes
	Youths:				These young Vorticons were sent into
					space by the Grand Intellect to grow
					into fierce warriors.  They like to tear
					around and don't much care what gets in
					their way.  These youngsters will most
					likely grow up to be Vorticon Elite.

	Vorticon Elders:		Wise Elders are kept in stasis in the
					living quarters of the ship.  They are
					from what is known as the Before Time,
					before the Grand Intellect.

	Scrubs:				These little red robots perform various
					menial duties around the ship and can
					walk on almost any surface.

[2.5.3] Keen Must Die!
	Youths:				The same spoiled brats that knocked you
					out in the second episode.  Now they
					play a deadly game of jacks.

	Foobs:				These little yellow creatures like to go
					out for strolls, whistling, and enjoy
					the day.  Unfortunately, they are
					completely afraid of almost everything.
					If you touch them, they will grow so
					tense that they will pop.

	Messie:				The great sea serpent of the legendary
					Loch Mess.  Who knows if she even
					exists?

[2.5.4] Keen Dreams
	Carrot Couriers:		These guys have tennis shoes and they
					are in a HURRY!  They won't hurt you but
					they can push you off whatever you're
					standing on.

	Pea Pods: 			They run around and spit out Pea Brains.

	Mosquitoes*: 			Though annoying to most people, these
					mosquitoes don't seem to bother
					Commander Keen.  The blue ones might
					even be helpful somehow.

	Waving Trees*: 			Strange trees that stand beside the
					pathways and wave at Keen.

[2.5.5] Secret of the Oracle
	Bounder:			These red, friendly, bouncing guys can
					be annoying, but they can be helpful,
					too!

	Council Member:			These are the Gnosticenes you are trying
					to rescue.  There are eight of them
					hidden in the depths of the Shadowlands.  

	Inchworm: 			These placid yellow creatures are all
					over.  Watch out where you step or
					they'll be afoot!

	Princess Lindsey:		The Princess is here to help you out.
					If you can find her, she will give you
					valuable information that will help you
					complete your quest. 

	Schoolfish:			These fish are the real follow-the-
					leader types.

	Treasure Eater:			These guys like to take your items and
					disappear.

[2.5.6] The Armageddon Machine
	Korath III Inhabitant*:		The denizens of the planet below the
					Omegamatic, these guys are just trying
					to go on with their day.  Unfortunately,
					the Shikadi are making it very
					difficult. 

[2.5.7] Aliens Ate My Baby Sitter!
	Flect:				These fellows have big teeth, but their
					bite isn't the problem!  Watch where you
					shoot when these guys are around.

	Blooglet:			Baby Bloogs come in four colors: red,
					yellow, green, and blue.  They aren't
					very dangerous, and they might even
					prove helpful sometimes.

	Molly:				The object of your quest.  The Bloogs
					are holding Molly for dinner.

	Viva:				These are probably the most common form
					of life on Fribbulus Xax.  Vivas have a
					wonderful quality -- touching them
					improves your health.  In fact, for
					every 100 you come into contact with,
					you'll gain another life.  Watch
					carefully for Queen Vivas -- touching
					one will give you another life all by
					itself.

[2.5.8] Commander Keen 
	Bounder:			These red, friendly, bouncing guys can
					help you reach high places!

	Little Ampton:			This little fellow slides up and down
					poles and works on his computer
					terminals.  Don't be on the pole he's on
					'cause he slides up and down quickly!


[2.6] Who are Commander Keen's enemies?
	Most of the aliens Commander Keen meets are mean, and hate him, and 
want him dead.  An asterisk (*) denotes that an official name has never been
released and that a common unofficial name is used instead.  Here's the lowdown:

[2.6.1] Marooned on Mars
	Gargs:				These wild-eyed, teeth-gritting Martian
					monsters are angry at you, angry at
					themselves, angry at dirt, angry at
					clouds, just plain angry.  If Freud were
					to see them, he would call them the
					"Id".

	Vorticons:			The Vorticons on Mars are members of a
					Mars outpost and are really on the
					bottom rung of the Vorticon social
					ladder.  Being on an outpost has made
					them kind of tough.  In the second two
					episodes, they are known as "Grunts".

	Tank Robots:			These robots exist to kill any
					intruders.  Even friendly ones.

[2.6.2] The Earth Explodes
	Grunts:				These are the Vorticons from Episode
					One, but they have led a more posh
					lifestyle, so they are weaker.

	Vorticon Elite:			These are Elite warriors.  To show their
					loyalty to the Grand Intellect, they had
					their ears clipped.  They are mean and
					like to shoot a lot.  They wear blue and
					purple suits.

	Guard Robots:			These awful purple robots are basically
					hovering machine guns.

[2.6.3] Keen Must Die!
	Grunts: 			Here they are again, with red suits.

	Vorticon Women:			They are very dangerous.  They have big
					claws and breathe fire.  You've come a
					long way, baby.

	Meeps:				A race of green, egg-shaped,
					horrendously bad singers with sorely
					misplaced operatic intentions.  They
					think they are the greatest singers in
					the world.  They are wrong.

	VortiNinja:			These are the most deadly enemy in this
					episode. Not only do they move and jump
					around very fast, they can also kick
					you! And to top it all off, they take 4
					shots to kill.

	The Grand Intellect:		His scary picture is framed on the wall
					of various Vorticon homes and schools.
					Who is he?  Finish the game and find
					out!

[2.6.4] Keen Dreams
	Tater Trooper:			They are dumb, but they can be
					dangerous! 

	Broccolash:			Watch out or the Broccolashes will do
					their "Broccolash Smash" on you.

	Tomatooth:			Probably the scariest of the vegetables,
					with their scary teeth.

	Asparagusto:			They run fast and they're hard to hit
					with Flower Powers.

	Sour Grape:			They'll fall on top of you, unless you
					can trick them. 

	Frenchy:			These scary potatoes from France will
					throw fearsome french fries at you.

	Squasher:			They look friendly until you get close--
					then they try to squash you!

	Melon Lips:			They spit watermelon seeds at you.

	Apels:				They can climb poles just like you do!

	Pea Brains:			Don't let these little fellows touch
					you! 

	King Boobus Tuber:		Sitting in his Castle atop Mount
					Tuberest, Boobus Tuber brings kids to
					Tuberia to be his slaves.  Defeat him
					with Boobus Bombs.  Then you can turn
					off his Dream Machine and rescue all the
					kids!

[2.6.5] Secret of the Oracle
	Arachnut:			Insane, green, crab-like walking
					creatures with two dangerous mouths!

	Berkeloid:			This fiery fella is not to be toyed
					with.  He throws big fireballs!

	Dopefish:			The second-dumbest creature in the
					universe, this creatures thought
					patterns go "swim swim hungry, swim swim
					hungry."  They'll eat anything alive and
					moving near them, though they prefer
					heroes.

	Lick:				These blue beanbag-like monsters breathe
					a deadly lick of fire.

	Mad Mushroom:			Dangerous plants that hop and are deadly
					to the touch.

	Mimrock:			Little creatures that look exactly like
					rocks, until your back is turned!

	Poison Slug:			The most common inhabitants of the
					Shadowlands, poison slugs mean trouble
					twice - once if you touch them, twice if
					you should land in the puddles of poison
					they leave behind.

	Skypest:			Virtually immune to your shots, these
					guys really are pests.  There must be
					some way to get them, though.

	Sprite:				Dopefish won't mess with these
					problematic underwater creatures: they
					shoot energy blasts at you!

	Wormouth:			Watch out for these green menaces.
					They're a lot bigger than they look.

	Blue Bird*:			These invulnerable birds are only
					temporarily stunned by Commander Keen's
					Neural Stunner, not completely knocked
					out.  In a few seconds they will get up
					and chase after Commander Keen. Don't
					break their eggs!  A new Blue Bird will
					be born!

	Thundercloud*:			These guys look just like regular clouds
					unless you pass too close; these guys
					don't take too kindly to disruptive
					heroes!

[2.6.6] The Armageddon Machine
	Sparky:				This gray guy has a magnetic
					personality.  His presence is
					electrifying.  You'll be shocked when
					you see him!  Watch out when he
					"charges!"

	Little Ampton:			This purple fellow slides up and down
					poles and works on his computer
					terminals.  Don't be on the pole he's
					on, 'cause he slides up and down
					quickly!

	Slicestar:			The Slicestar is a crystalline being
					with razor-sharp points.  Don't get near
					'em!

	Volte-face:			Volte-faces are crazy, insane floating
					creatures that have electronic arcs for
					hair!

	Robo Red:			Robo Red is a nasty guard.  If he hears
					a sound, he shoots first and asks
					questions later.  Avoid, avoid, avoid!

	Shelley:			This tiny darling seems pleasant enough
					until you least expect it, then she goes
					all to pieces!

	Spirogrip:			The Spirogrip spins and launches toward
					walls.  If you're in the way, you'll be
					toast!

	Shikadi Mine:			Woe be the hero that wanders near one of
					these.  They will follow you until you
					are close enough, then they explode!

	Spindred:			Spindred slam angrily at the floor and
					ceiling.  They'll crush you quicker...
					than something quick.

	Shikadi:			These energy beings built the Omegamatic
					and plan to destroy the galaxy.  Watch
					out for them near poles.

	Sphereful:			Frightful plasma orbs with orbiting
					diamond sensors, tread carefully by
					these dangerous denizens. 

	Shockshund:			Three-legged energy dogs of the Shikadi,
					their spark is worse than their bite!

	Shikadi Master:			The most frightful foe aboard the
					Omegamatic, they cast Electrospheres at
					you and teleport around.  Very
					dangerous.

[2.6.7] Aliens Ate My Baby Sitter!
	Bloog:				The Bloogs stole your babysitter.  These
					one-eyed green carnivores are driven by
					their hunger across the galaxy.

	Bip:				Bips are the cogs in the Bloogs'
					machine.  They run platforms, they
					patrol areas in their Bipships, and
					generally cause havoc.  They will fight
					for anyone, but they happened to hook up
					with the Bloogs.

	Babobba:			This little red fellow is a baby Bobba.
					Babobbas are not quite as tough as full-
					grown Bobbas.

	Blorb:				These red gelatin-like beings are deadly
					but slow.  They bounce around and make
					you nervous.

	Gik:				This hard-shelled customer's worst
					points are its points!  Its legs are
					spikes, so it will flip and try to poke
					you.

	Ceilick:			These purple beings hid in holes in the
					ceiling and will try to get you with
					their forked tongues.

	Blooguard:			These burly Bloogs have big clubs to
					bonk their enemies.  Even if they miss,
					their clubs shake the ground so
					violently you might get knocked out!

	Bobba:				Bobbas are nasty indestructible beings
					that hop and fire deadly energy bolts
					from their eyes.

	Nospike:			These blue fellows walk around until
					they find something to charge at.  But
					even charging, their favorite pastime,
					will bore them after a bit.  Watch out
					for their fearsome horn!

	Orbatrix:			These big blue eyeballs will bounce and
					spin at you!  Be careful, they float and
					follow you.
 
	Fleex:				The Fleex are amongst the finest
					engineers in the universe, having
					designed all of the buildings and
					devices on Fribbulus Xax.
					Unfortunately, the Bloogs built them,
					devastating the sleek and elegant
					designs.

					The Fleex have very sensitive
					eyes (a natural consequence of spending
					a lifetime in a basement lab), so
					sensitive that they have to wear dark
					shades when they're out in the light
					(making them nearly blind).  To
					compensate, they've developed an
					oversized ear which allows them to hear
					other creatures as they move around.

[2.6.8] Commander Keen
	Dorp:				The Droidiccus combined their robot
					technology with an organic alien life
					form to create the Dorp.  The Dorp's
					skin is poisonous, so beware!

	Darg:				The Darg is like a Dorp on steroids.
					Don't mess with the Darg!

	Sentry Droid:			You may spot these seemingly mindless
					sentries throughout the Droidican
					cities.  The Emperor uses them to keep
					tabs on his soldiers.  They are
					indestructible, so don't mess with them!

	Droid 1:			This low-flying pest has no real
					personality.  Its presence is less-than
					magnetic.  You won't be shocked when you
					see it.  Don't let it annoy you.

	Droid 2:			This hopping robot's primary function is
					to guard the Hive, but it does other
					menial work during its off-duty hours.
					Don't drop your guard around this
					mechanical menace!

	Droid 3:			This is one of two robots created for
					menial work and guard duties around the
					Robot Hive.  This robot moves fast along
					vertical platforms and may smack into
					you if you don't look out.  Again, no
					serious threat, although they can get
					annoying.

	Droidican Soldier:		These robotic troopers are the Droidican
					Emperor's prime defense--serving to keep
					the Warp Drive technology safe.
					Droidican Soldiers aren't very smart
					though, so they need a lot of
					discipline.

	Droidican Elite:		The Droidican Elite are master soldiers,
					and the Emperor counts on them to keep
					the other troops in line.  Armed with
					deadly lasers, these droids are a
					serious threat!

	Dood:				This tiny guy seems pleasant enough
					until you least expect it, then he goes
					all to pieces!

	Fire Imp:			These fiery creatures think they're
					pretty hot.  They lurk in the rocky
					wasteland between the Imperial Palace
					and the Robot Hive.

	Cyba-Mallow:			One day, when they were bored, the
					Droidiccus created the Cyba-Mallow.
					It's part marshmallow and part cyborg,
					and all trouble!

	Arachnu:			Insane, crab-walking creatures that hold
					their dangerous mouths high in the air.

	Berkeloid:			This fiery fella is not to be toyed
					with.  He throws big fireballs, and is
					tough to kill.

	Poison Slug:			The most common inhabitant of the
					Mushroom Forest, Poison Slugs mean
					trouble twice--once if you touch them,
					twice if they charge at you!

	Badoing:			The Shikadi kidnapped these mutant worms
					from a far away galaxy for reasons
					unknown.  The Badoings mostly hide in
					the floor panels of the Shikadi mother
					ship, waiting to surprise any
					unsuspecting visitors.

	Mad Mushroom:			Dangerous fungi that hop and are deadly
					to touch.  They jump higher every three
					bounces.

	Robo Red:			Robo Red is a nasty guard.  If he hears
					a sound, he shoots first and asks
					questions later.  Avoid, avoid, avoid!

	Shikadi:			These energy beings built the Omegamatic
					and plan to destroy the galaxy.  Watch
					out for them near poles.

	Shikadi Master:			The most frightful foe aboard the
					Omegamatic, they cast Electrospheres at
					you and teleport around.  Very
					dangerous.

	Shikadi Sentry:			Woe be the hero that wanders near one of
					these.  They will move back and forth
					until they hit you!

	Sphereful:			Frightful plasma orbs with orbiting
					razor sensors, tread carefully by these
					dangerous denizens.

	Bobba:				Bobbas are nasty red beings that hop and
					fire deadly energy bolts from their
					eyes.

	Bloog:				The Bloogs stole your babysitter a long
					time ago.  These one-eyed green
					carnivores are driven by their hunger
					across the galaxy.

	Blooguard:			These burly Bloogs have big clubs to
					bonk their enemies.  Avoid these creeps
					at all costs!

	Blooglet:			The little Blooglets are just as hungry
					as their big brothers, but they're not
					quite as frightening, are they?

	Bubba:				Bubba likes to float above the calm
					waters of Blooglet Lake and watch the
					fish swim below.  He's been known to
					mistake heroes for seafood, so watch
					out!

	Dopefish:			The second dumbest creature in the
					universe, this creature's thought
					patterns go "swim swim hungry, swim swim
					hungry."  They'll eat anything alive and
					moving near them, though they prefer
					heroes.

	Casta:				The Fleex designed the floating Casta to
					monitor the high-tech machinery in their
					laboratories.  The Casta won't attack
					you, but it's indestructible, so try not
					to get too close!

	Nospike:			These blue fellows walk around until
					they find something to charge at.  But
					even charging, their favorite pastime,
					will bore them after a bit.  Watch out
					for their fearsome horn!

	Flect:				The Flect is always in a hurry, and has
					nowhere to go.  This terminally worried
					creature has tentacles for hair and a
					reflective plate on its chest.  It's
					best to be sneaky when dealing with a
					Flect.

	Gik:				This hard-shelled customer's worst
					points are its points!  Its legs are
					spikes, so it will jump and try to poke
					you.

	Fleex:				The Fleex are amongst the finest
					engineers in the universe, having
					designed all the buildings and devices
					on Fribbulus Xax.  Unfortunately, the
					Bloogs built them, devastating the sleek
					and elegant designs.  The Fleex have
					very sensitive eyes (a natural
					consequence of spending a lifetime in a
					basement lab).  To compensate, they've
					developed an oversized ear which allows
					them to hear other creatures as they
					move around.

	Hovva:				This robotic centurion is somewhat like
					a flying tank.  The robot itself is
					harmless, but beware!  He carries an
					electric coil to help him float, and
					will run you down without hesitation.

	The Droidican Emperor:		The Droidican Emperor is a poisonous
					foe.  You'll have to face him on his
					home turf: the Royal Chambers, which is
					a strange and unnerving place.  The
					Emperor runs from one side of the
					chamber to the other, alternately
					throwing deadly poison at you and then
					releasing a robot to help him in his
					attack.  Shoot the robot and avoid the
					Emperor's poison.

					If the Emperor is defeated, Commander
					Keen will be awarded a plasma crystal.

	Shikadi Overlord:		The Boss is very simple to defeat, in
					theory.  It's a straight fight--your
					Neural Ray Blaster against his rather
					powerful homing rockets.  But the odds
					are in his favor because he only has to
					hit you once but you must shoot him many
					times.  To make matters worse, he has a
					personal teleporter, so watch your back!

					If the Shikadi Overlord is defeated,
					Commander Keen will be awarded another
					plasma crystal.

	Robo-Bloog:			A Robo-Bloog is essentially a Cyborg
					Bloog.  It's a Bloog with the mind of
					ten super-computers and the body of...
					well, ten super-computers.

					The Robo-Bloog can fire a huge ball of
					energy.  If either the Robo-Bloog or the
					energy ball hits Commander Keen, that's
					it.  Unfortunately, every time the Robo-
					Bloog recharges his energy ball he adds
					one more shot to his attack.  For
					example, after his second recharge,
					he'll have two energy balls.  After the
					third recharge, he will have three
					energy balls, etc.  The more overcharged
					Robo-Bloog becomes, the more erratic his
					behavior is.  It'll be hard to time your
					attacks!

					If the Robo-Bloog is defeated, Commander
					Keen will be awarded the third plasma
					crystal, and the Earth will be saved!

	Mortimer McMire:		Commander Keen's arch-nemesis, school
					rival, and all-around evildoer.  He's
					masterminded your entire adventure and
					wants to see the Universe destroyed!
					You'll never catch him, but he's out
					there!  Waiting to see you fail!


[2.7] What are the worlds Commander Keen visits?
	Keen has visited quite a few places on his journeys, these are the ones
that he's visited most recently:  

	Mars:			Probably the planet the people of Earth	are most
				familiar with, this is where Commander Keen
				begins his legacy.  He will visit both the polar
				ice caps and the dark side of Mars in a quest to
				find the stolen	parts of the Bean-with-Bacon
				Megarocket.

	Vorticon VI:		A strange heavenly body, it is the home planet
				of the Vorticons.  It is very similar to Earth,
				with the exception of the great fortresses
				created by their ruler, the mysterious Grand
				Intellect and the Vorticons.  Commander Keen
				must find the Grand Intellect and stop his plans
				to destroy Earth!

	Tuberia:		Kingdom of Boobus Tuber, the evil Dream Machine
				sends children into captivity when they say
				something negative about vegetables.  Keen must
				destroy it or he'll be sleeping forever!

	Gnosticus IV:		Home planet of the Poison Slugs, Treasure
				Eaters, and Council Members.  The evil Shikadi
				have imprisoned the invulnerable Council Members
				in deepest warrens of this forbidding place.
				Keen must rescue them or he'll have to say
				Goodbye, Galaxy!

	Korath III:		Keen takes a quick trip to Korath III when he
				enters the secret Korath III Base while trying
				to destroy the Omegamatic.

	Fribbulus Xax:		Home of the evil Bloogs, Commander Keen must
				face incredible horrors and impossible odds to
				save his babysitter Molly.  If he doesn't save
				her before his parents get home, Billy will have
				to tell them, "Aliens ate my baby sitter!"

				Keen will make a second visit to this planet in
				search of one of the plasma crystals in his
				quest to destroy the Omegamatic Warp Drive.

	Droidiccus Prime:	Homeworld of the evil Droidiccus, including the
				evil Droidican Emperor.  Commander Keen journeys
				here on his quest for the plasma crystals.

	Shikadi:		The assumed homeworld of the Shikadi, the part
				of it that Commander Keen visits oddly resembles
				the Shadowlands of Gnosticus IV.  Here he will
				find a menagerie of enemies encountered in both
				the Shadowlands and the Omegamatic in his search
				for a plasma crystal.


[2.8] How does Commander Keen get around?
	Commander Keen travels from planet to planet and from ship to ship 
using his interstellar starship made from old soup cans, rubber cement, and 
plastic tubing.  The Bean-with-Bacon Megarocket!  While exploring other worlds 
and ships, Commander Keen can use the Holy Pogo Stick he found on his excursion 
on Mars.  Unfortunately, Commander Keen leaves his pogo stick behind when he is 
sent to Tuberia with the Dream Machine.


[2.9] What goodies can I pick up on my journeys?
	The only thing better than accomplishing your main goal in Commander 
Keen is picking up the candy and items!  Below is the complete list.  Please
note that none of the point items in the Game Boy Color game Commander Keen have
ever been officially named, however most appear to be derived from items in
previous Commander Keen games and have been named such.

[2.9.1] Marooned on Mars
	Lollipop:		      	100   Points

	Soda:				200   Points

	Pizza:				500   Points

	Book:				1000  Points

	Teddy Bear:			5000  Points

	Joystick: 			Manual Flight Control

	Car Battery: 			Electrical Systems Power

	Vacuum Cleaner:			Ion Propulsion Unit (with carpet height 
					adjustment)

	Everclear:			Fuel

	Raygun:				5 Charges

	Holy Pogo Stick: 		Used for jumping higher

	Keycards:			Used to open 4 different doors

[2.9.2] The Earth Explodes
	Candy Bar:			100   Points

	Vorta-Cola:			200   Points

	Hamburger:			500   Points

	Cake (Chocolate):		1000  Points

	Stuffed Toy Vorticon:		5000  Points

	Vorticon HyperPistol: 		5 Charges

	Keycards:			Used to open 4 different doors

[2.9.3] Keen Must Die!
	Zitto Candy Bar: 		500   Points

	Diet Vorta-Cola: 		200   Points

	Big-N-Beefy Burger:		100   Points

	Cake (Double Chocolate): 	1000  Points

	Stuffed Toy VortiNinja:		5000  Points

	Ankh:				A mysterious super powerup, use them 
					wisely.

	Vorticon HyperPistol:		5 Charges

	HyperPistol Reloads:		1 Charge

	Keycards:			Used to open 4 different doors

	*Note that even though the Help Menu specifies that the Candy Bar is
worth 100 Points and the Burger is worth 500, the game is coded so that the
opposite actually occurs.

[2.9.4] Keen Dreams
	Peppermint:	       		100   Points

	Cookie:				200   Points

	Candy Cane:			500   Points

	Candy Bar:			1000  Points

	Lollipop:			2000  Points

	Cotton Candy:			5000  Points

	Flower Power:			1 Shot

	Flower Pot:			5 Shots

	Magic Eyeball:			3 Lives and 8 Shots

	Boobus Bomb:			1 Shot, 12 destroy Boobus Tuber

	Key:				Used to open doors

[2.9.5] Secret of the Oracle
	Shikadi Soda:			100   Points

	Three-Tooth Gum: 		200   Points

	Shikkers Candy Bar:		500   Points

	Jawbreaker:			1000  Points

	Doughnut:			2000  Points

	Ice Cream Cone:			5000  Points

	Neural Stunner:			8 Ammo in Easy, 5 Ammo in Normal or Hard

	Raindrops:			Collect 100 for extra life

	Lifewater Flask			Extra Keen

	Wetsuit: 			Allows you to swim in water

	Gems:				Used to open 4 different doors

[2.9.6] The Armageddon Machine
	Shikadi Gum:			100   Points

	Marshmallow:			200   Points

	Chocolate Milk:			500   Points

	Tart Stix:			1000  Points

	Sugar Stoopies Cereal:		2000  Points

	Bag O' Sugar:			5000  Points

	Neural Stunner:			8 Ammo in Easy, 5 Ammo in Normal or Hard

	Vitalin: 			Collect 100 for extra life

	Keg O' Vitalin:			Extra Keen

	Keycard: 			Opens security doors

	Gems:				Used to open 4 different doors

[2.9.7] Aliens Ate My Baby Sitter!
	Bloog Soda:			100   Points

	Ice Cream Bar:			200   Points

	Pudding: 			500   Points

	Root Beer Float: 		1000  Points

	Banana Split			2000  Points

	Pizza Slice:			5000  Points

	Neural Stunner:			8 Ammo in Easy, 5 Ammo in Normal or Hard

	Grappling Hook and Rope: 	Lets you climb something

	Bloogstar Rocket Passcard:	Lets you get through force field

	Really Big Sandwich:		It's second biggest sandwich Commander 
					Keen has ever seen.

[2.9.8] Commander Keen
	Robot Hive:
	Cotton Candy			5  Points

	Soda				5  Points

	Pizza Slice			5  Points

	Tart Stix			5  Points

	Chocolate Milk			5  Points

	Battery				10 Points


	Fiery Canyon:
	Pudding				10 Points

	Diet Vorta-Cola			10 Points

	Marshmallow			10 Points

	Shikkers Candy Bar		10 Points

	Tart Stix			10 Points

	Fire Extinguisher		25 Points


	The Imperial Palace:
	Unwrapped Candy Bar		25 Points

	Cotton Candy			25 Points

	Pizza Slice			25 Points

	Pudding				25 Points

	Diet Vorta-Cola			25 Points

	Flask				50 Points


	Forest o' Crazy Mushrooms:
	Doughnut			5  Points

	Zitto Candy Bar			5  Points

	Candy Cane			5  Points

	Shikadi Soda			5  Points

	Peppermint			5  Points

	Mushroom			10 Points


	The Plasma Crystal Mines:
	Cookie				10 Points

	Shikadi Gum			10 Points

	Chocolate Cake			10 Points

	Zitto Candy Bar			10 Points

	Peppermint			10 Points

	Small Crystal			25 Points


	Shikadi in Space:
	Ice Cream Bar			25 Points

	Three-Tooth Gum			25 Points

	Sugar Stoopies Cereal		25 Points

	Cookie				25 Points

	Chocolate Cake			25 Points

	Rocket				50 Points


	Blooglet Lake:
	Lollipop			5  Points

	Pizza				5  Points

	Candy Bar			5  Points

	Cola				5  Points

	Ice Cream Cone			5  Points

	Bubble				10 Points


	The Bobba Fortress:
	Flower Pot			10 Points

	Banana Split			10 Points

	Bag O' Sugar			10 Points

	Lollipop			10 Points

	Candy Bar			10 Points

	Key				25 Points


	Techno Lab:
	Root Beer Float			25 Points

	Vorta-Cola			25 Points

	Lollipop			25 Points

	Flower Pot			25 Points

	Banana Split			25 Points

	Computer Chip			50 Points


	Common Items:
	Colored Keys			Used to open 3 different doors

	Commander Keen Icon		A floating icon of Keen's head that's
					worth an extra life.


[2.10] What's the name of Keen's pet Yorp?
	At the end of Marooned on Mars, Commander Keen brings home a Yorp to
keep as a pet (see section [10.1]).  There has, however, been some confusion
about his name.  Some feel that his name is Norp the Yorp.  Others feel that
his name is Spot (as his food bowl suggests).  Tom Hall was asked to set the
record straight:

	'It's Spot, really. Billy was probably trying to give his parents
	something normal to hold onto since they let him keep a one-eyed alien
	as a pet.  :)'

	And the matter is laid to rest.


[2.11] What's this I hear about Billy Blaze's extended family?
	You may have heard that Billy Blaze, a.k.a. Commander Keen, is related 
to B. J. Blazkowicz, hero of the Wolfenstein games.  The following is an excerpt
from the Wolfenstein 3D Official Hint Manual:

	William Joseph Blazkowicz was born August 15, 1911, to Polish
	immigrants.  Blazkowicz was a top spy for the Allied Forces,
	receiving the Congressional Medal of Honor and other accolades
	for heroism.  "B.J.," (as he was called by his friends) married
	after World War II, at age 40, to Julia Marie Peterson.  Their
	son, Arthur Kenneth Blazkowicz, became a television talk show
	personality in Milwaukee.  For show biz purposes, Arthur changed
	his last name to Blaze.  Arthur later married Susan Elizabeth
	McMichaels.  They had one son (which they named after Arthur's
	father), William Joseph Blazkowicz II, or as he signs his grade
	school homework, B. Blaze....

	What's more, the name of the protagonist of the DOOM series is finally
given in the game DOOM II RPG as Sergeant Stan Blazkowicz, descendant of B.J.
Blazkowicz, which means he's also possibly the descendant of Billy Blaze himself
(or at least a distant relative)!


[2.12] What is this 'Dopefish'?
	The following is an excerpt from Joe Siegler's awesome Dopefish website
http://www.dopefish.com:

	What is Dopefish? Dopefish was one of the characters that appeared in
	Commander Keen, Episode IV back in 1991. That's it. All the rest of
	this "Dopefish mania" came later. You can read about it...at
	dopefish.com, the definitive source of info on everyone's favourite
	fish!

	Dopefish is the product of the fertile mind of Tom Hall. It was one of
	24 drawings he did of ideas for characters for Commander Keen: Goodbye,
	Galaxy! while part of id Software. Dopefish was one of the characters
	from these drawings that made the cut. According to Tom, "I just drew
	this stupid little fish," and the rest is history.

	Dopefish is described in the cast of characters for Secret of the
	Oracle as the second dumbest creature in the universe. His thought
	patterns go, "swim swim hungry, swim swim hungry." Dopefish "will eat
	anything alive and moving near them, though they prefer heroes."
	(What's the most dumbest creature in the universe? Why, of course, the
	Ravenous Bugblatter Beast of Traal. It's so stupid that it thinks if
	you can't see it, it can't see you. One way to avoid the BugBlatter
	Beast is to throw a towel over your head.) Dopefish was "adopted" by
	the Tech Support staff at Apogee soon after I came on board. Then Steve
	Quarrella came onboard and it balooned from there. Dopefish was my
	favorite character, and Steve was the resident Keen expert -- Lee
	provided a few vocal effects and some art. We got hold of some screen
	capture software and went to town...

	So why is Dopefish so popular?  Could it be his simple thought patterns
(people always feel sorry for stupid animals)?  His bucked-teeth?  His tendency
to burp?  It beats me.  But it really doesn't matter; everyone loves him.



-------------------------------------------------
[3] The Official Commander Keen Games and Stories
-------------------------------------------------
Every Saga has a story, every story has a beginning.  This is Commander Keen's.


[3.1] What's the Story Behind Invasion of the Vorticons?
	Billy Blaze, eight year-old genius, working diligently in his backyard
clubhouse has created an interstellar starship from old soup cans, rubber
cement and plastic tubing.  While his folks are out on the town and the
babysitter has fallen asleep, Billy travels into his backyard workshop, dons
his brother's football helmet, and transforms into...

	COMMANDER KEEN--defender of Earth!

	In his ship, the Bean-with-Bacon Megarocket, Keen dispenses galactic
justice with an iron hand!

[3.1.1] Marooned on Mars
	In this episode, aliens from the planet Vorticon VI find out about the
eight year-old genius and plan his destruction.  While Keen is out exploring
the mountains of Mars, the Vorticons steal vital parts of his ship and take them
to distant Martian cities!  Can Keen recover all the pieces of his ship and
repel the Vorticon invasion?  Will he make it back before his parents get home?
Stay tuned!

[3.1.2] The Earth Explodes
	His parents think he's asleep, but there's no time for napping--a
Vorticon Mothership is poised above Earth, preparing to destroy every major
city with their deadly Tantalus Ray!  Keen must sneak aboard the ship and stop
each Tantalus team from their terrible task.  If he fails, the Earth Explodes!
Of course, this will mean he won't have to get home in time for school.... The
Earth or no school.  Hmm....

	After much deliberation, Keen decides to save the Earth anyway.  Don't
miss an action-packed second of this exiting episode in the Commander Keen
trilogy!

[3.1.3] Keen Must Die!
	Keen blasts through a hyperspace gate and arrives on Vorticon VI,
landing on the island of Vortiville.  Here he faces mind numbing horrors of
suburban life.  Then he will travel to New Vorticon, where life is a dark,
dangerous enterprise.  He will also have to face the violent forces massed in
the Vorticon military installation.  After this, he will face the impossible
maze of the Caves of Oblivion!  If he passes this barrier, he will finally
reach the Castle of the Grand Intellect, where all his beliefs and fears come
together in a titanic, shocking finale!  Don't miss the incredible shattering
conclusion to the Commander Keen trilogy!


[3.2] What's the Story Behind Keen Dreams?
	Billy Blaze, eight year-old genius, working diligently in his backyard
clubhouse has created an interstellar starship from old soup cans, rubber
cement, and plastic tubing.  While his folks are out on the town and the
babysitter has fallen asleep, Billy travels into his backyard workshop, dons
his brother's football helmet, and transforms into...

	COMMANDER KEEN--defender of Earth!

	In his ship, the Bean-with-Bacon Megarocket, Keen dispenses galactic
justice with an iron hand!

	THIS EPISODE: "Keen Dreams"

	We find young Billy discussing matters of paramount importance with his
mother.

	"I just saved the Earth, Mom," said Billy.  "I don't have to eat
vegetables."

	"Sure, dear," said Billy's mom.  "I bet Neil Armstrong never complained
about HIS mashed potatoes."

	"I bet Neil Armstrong never traveled to Vorticon VI and defeated the
Grand Intellect, either," Billy mumbled at his plate.  He sat there, legs
dangling, staring at his offensive, starch-laden foe.

	After a pointed remark about the quality of the mashed potatoes, Billy
was sent to his room.

	"Stupid vegetables," he grumbled, his eyelids growing heavy.

	Soon Billy was fast asleep.

	Suddenly he woke up, and his bed was atop a hill.  On either side of
his bed were giant potatoes wearing metal helmets and carrying bayonets.

	"Come with us now, Captain Keen," said the first.

	"You've been brought here by the Dream Machine," said the second.

	"Boobus Tuber, our king and boss--"

	"--is now your master, come with us!"

	Billy frowned, grabbed his football helmet off his bedpost, and started
to put it on.

	"First of all, spuds," Billy said, pushing down on the helmet.  "That's
COMMANDER Keen.  Second of all, who do you think you are?"

	"We're Tater Troopers it's plain to see," said the first.

	"So get--"

	Keen reached under his pillow and retrieved his Vorticon Hyperpistol.
He moved it from "Stun," past "Disrupt," all the way up to "Fry to Delicate
Brown."

	"How about a walk on the fried side boys?" Keen said.

	Two BZZAPs later, Keen pouted.

	"Aw, nuts.  My Hyperpistol's empty," he said.

	Just then, a child in chains ran up to him.

	"Keen, oh, Keen, oh, Captain Keen!  Save us from the Dream Machine!" he
said.

	"That's COMMANDER Keen!" the young genius corrected.

	"Whatever.  Save us!" said the child.

	So Billy hopped out of bed and started on his quest to defeat King
Boobus Tuber and destroy the Dream Machine.


[3.3] What's the Story Behind Secret of the Oracle?
	After delivering a crippling blow to the plans of Mortimer McMire and
receiving the praise of the Vorticon race, Commander Keen returned to his home
in the suburbs.

	Here he was forced to go to bed at an early hour, and to eat mashed
potatoes.

	Months later, Billy tinkered around with his latest invention, the
Photachyon Transceiver, or faster-than-light radio.  After picking up a lot of
bad alien sitcoms, he stumbled upon a strange message of terrible importance....

	COMMANDER KEEN in . . . "Goodbye, Galaxy!"
	Keen Episode Four: Secret of the Oracle

	Billy Blaze toils in his backyard workshop, busily constructing his
latest invention: the Photachyon Transceiver.  Put in simple words, it is an
instantaneous radio -- point to anywhere in the galaxy, and you can pick up a
signal as if you were right there.  After picking up a lot of very bad alien
sitcoms, Billy hears a strange message, spoken in the language of Omnispeak
that the Vorticons taught him....

	brrzzz....giggg....oment of great triumph...frzzt....ast the Milky Way
will be...huzzzzz...terly destroyed...pyuneeeeeeg...can stop us now.  We will
remake the galaxy in the name of the Gannalech.  Power to our race!  Power to
the Shikadi!

	Then the radio is silent.

	"So the Shikadi are planning on destroying the Galaxy, huh?" thinks
Billy.  "Sounds like a job for...COMMANDER KEEN!"

	Billy once again dons his brothers football helmet, contemplating three
questions:

	Who the heck ARE the Shikadi?
	Where are they?
	How are they planning to destroy the galaxy?

	Climbing into the Bean-with-Bacon Megarocket's cockpit, Billy sets up
the launch sequence for Gnosticus IV, the home of the Gnosticenes, guardians of
the Oracle.  They owe him a favor, and he needs to get some questions answered.
The launch sequence begins.

	"Suppertime, Billy!" announces his mom as she walks out to the workshop.

	"Aw, nuts!" spouts Billy.  He realizes that there isn't enough time to
stop the sequence and cover the ship!  Thinking quickly, he pulls out his
Neural Stunner, points it at the door, and waits.

	One "Zzzzap!" later and his Mom is frozen in the doorway.

	"Whew," says Keen

	"Honey?  What's the matter?" says Billy's dad, coming out the back door.

	"Double nuts!" mutters Billy.  He peeks past his mom, takes aim and....

	Zap!

	Once at Gnosticus IV, a Council Page runs up to him.

	"Oh, Captain Keen!" he begins.

	"That's Commander Keen," Billy corrects.

	"The Shikadi were here, and they kidnapped the members of the High
Council and took them to the Shadowlands far to the west."

	"They didn't kill them?" Keen asks.

	"Impossible.  They are immortal," says the page.  "So they just made
sure they weren't available to activate the Oracle."

	"Well, I'll just go get them," Keen says, turning with heroic
determination.

	"Um, but Captain Keen, they also left a bunch of horrible creatures and
traps to guard them," says the Council Page.

	"Well, I'll just go get them CAREFULLY, then," Keen says over his
shoulder.

	Keen turns to walk out the door, stops, turns and addresses the page.

	"And if you call me Captain Keen again, I'm taking you with me."

	Keen boldly heads out the door as the page mutters, "Sorry."

	Commander Keen hops in his Bean-with-Bacon Megarocket and heads for the
Shadowlands....


[3.4] What's the Story Behind The Armageddon Machine?
	After learning the location of the secret Shikadi base, Keen jumped in
the trusty Bean-with-Bacon Megarocket and blasted across interstellar space.

	Seventy-five furious games of Paddle War later, Keen dropped out of
lightspeed near the Korath system.

	He flew toward the planet, keeping it between him and the base.

	Pulling up underside and docking at the Ion Ventilation System, Keen
must destroy the Shikadi Armageddon Machine before it explodes and destroys the
Milky Way!  He steps into the dark ventilation duct and begins his most
dangerous adventure yet...

	Keen Episode Five:
	The Armageddon Machine

	Last episode, our hero Billy blasted off in search of the mysterious
Shikadi, who serve "the Gannalech" and plan to destroy the galaxy!  After a
short delay, Keen rocketed to Gnosticus IV, only to find the Council Members
missing.  The Shikadi kidnapped 'em!

	Keen flew to the Shadowlands, faced horrible foes, and rescued the
kidnapped ancients.

	After Keen freed them from their imprisonment, the immortal Council
Members activated their source of galactic wisdom, the Oracle.  The Oracle
informed Keen that the Shikadi had nearly completed a machine to obliterate the
galaxy!

	This episode finds Keen in stealth mode, sneaking his Bean-with-Bacon
Megarocket up to the Omegamatic.  Securing his Attach-O-Ray to an exhaust port,
Keen enters the Omegamatic and begins his most dangerous adventure yet!


[3.5] What's the Story Behind Aliens Ate My Baby Sitter!?
	Billy Blaze, eight year-old genius, working diligently in his backyard
clubhouse has created an interstellar starship from old soup cans, rubber
cement, and plastic tubing.  While his folks are out on the town and the
baby sitter has fallen asleep, Billy travels into his backyard workshop, dons
his brother's football helmet, and transforms into...

	COMMANDER KEEN -- Defender of the Universe!

	In this episode, Billy is out in his clubhouse, busily working on his
handy new ComputerWrist wrist computer.  He hears Molly, his baby sitter,
calling him to supper but he keeps on working.  He hears a strange noise in the
backyard and decides to investigate.  On a patch of scorched grass he finds a
note:

	Keen--

		Thanks for dinner.

			--The Bloogs of Fribbulus Xax.

	P.S. Next time get one with more meat, please.

	He puzzles over this for a moment, then notices the baby sitter has
stopped calling.  Suddenly he realizes that aliens are having her over for
supper - and when they say "for supper" they mean "FOR SUPPER"!  If he doesn't
save her, his parents will be furious.  They'll never believe that "Aliens ate
My Baby Sitter!"

	"This is a job for Commander Keen!" he declares.  Once again, he dons
his brother's football helmet, hops into the trusty Bean-with-Bacon Megarocket
and starts the launch sequence for Fribbulus Xax.  He's got to save Molly from
becoming a snack for creatures from another planet!

	It's great arcade action and hilarious fun in the latest episode in the
Commander Keen saga!


[3.6] What's the Story Behind Commander Keen?
	SAVE THE WORLD!

	It is a normal morning for Billy Blaze.  Half awake, he gets his cereal
and sits in front of the TV, switches it on, and watches...static...

	A sub-space anomaly has mysteriously appeared in the Earth's core--
everything's gone haywire: telephones ring randomly, the clouds have turned
blue, and morning cartoons have ceased to exist.

	With one quick look at his all-new "Computer-Wrist" computer, Billy
Blaze realizes things aren't as they should be.  He must find out who is
responsible!

	Little does he know, his old enemies have joined forces in one last-
ditch attempt to destroy the universe.  The Droidiccus, Shikadi, and Bloogs of
Fribbulus Xax have created the fabled Omegamatic Warp Drive.  Using super
powerful plasma crystals, they can destroy sub-space stability.  Even his old
arch-rival Mortimer McMire may have a hand in the mayhem.  Only Commander Keen
has the ability to re-unite the three plasma crystals at the Omegamatic Warp
Drive and save the world!

	Donning his brother's football helmet, Billy Blaze sets off down the
garden path.  Determined to get to the heart of the matter, he jumps into the
Bean-with-Bacon Megarocket.

	THE EARTH IS IN TROUBLE!!!

	THIS LOOKS LIKE A JOB FOR...
	COMMANDER KEEN!

	After flying for what seems like an eternity, Commander Keen lands in
the strangest place he has ever seen in all his travels.

	Will Commander keen succeed, or will the Earth be turned into sub-space
shambles?



--------------
[4] The Lyrics
--------------
Like all good songs, the songs in Commander Keen, composed by Bobby Prince, have
lyrics.  Only the lyrics for two of the songs have ever been released, here they
are.


[4.1] What are the lyrics to Eat Your Veggies?
	Here's some background.  This song was originally intended for Keen
Dreams, however Softdisk Publishing (who were publishing this "Special Edition"
Keen), decided to get rid of music so the program would fit on one floppy disk.
Anyway, Billy is sitting at the table with his family, refusing to eat dinner.
It starts with his mom pleading with Billy, here goes.

	"You've got eat your vegetables, eat them right up!  You've got to eat
your vegetables, tell him Daddy."

	So his Dad tries to convince his son to eat.

	"You've got to eat your vegetables, NOWWWW!"

	Billy's sister, seeing an opportunity to make fun of him start's
speaking.

	"You've got to eat your vegetables, na-na, na-na, na, na!"

[4.2] What are they lyrics to Aliens Ate My Baby Sitter!?
	This song starts off right when Billy realizes the Bloogs have stolen
his babysitter, and he's going to have to save her.

	"Aliens Ate My babysitter, ate her right down to her toes, worse, they
still look hungry, and are trying now to bite off my nose.  My babysitter might
have deserved it, of that, a Judge I'll not be, but I am a different story, the
Universe dies without me!"

	Now Keen does some rap and here it is:

	"My name is Keen, a fighting machine, helmet on head (except when in
bed), a pogo for height, a ray gun for might, the Bacon-'n-Bean's my flying
machine.

	I never fear whenever I'm near, some critter from space, who's not in
his place, I'll leave them to feed on whatever they need, I'll fill them with
lead after they're fed.

	My Mom and my Dad don't know I'm this BAD!  But when my story's told,
all kids will be bold."



----------------------------------
[5] The Standard Galactic Alphabet
----------------------------------
Unknown to most Earthlings, there is an alphabet standard throughout the
galaxy: The Standard Galactic Alphabet!  I'm proud to say that I figured out the
Standard Galactic Alphabet (with the exception of Z), without any hints, when I
was 8 years old. Using only Commander Keen episodes 1, 4, and 5.


[5.1] What is the Standard Galactic Alphabet?
	The Standard Galactic Alphabet (SGA) is fairly easy to master.  There is
no upper and lower case, and the sign ��-�� is used to signify the end of a
sentence (like a period).

*-----------------------------------------------------------------------*
|   A   |  B    |  C    | DDDD  | E  E  | FFFFF |    G  | HHHHH |   I   |
|  A A  |  B    |       |       | E     |       |    G  |       |   I   |
|  A    |   B   |  C    | DD    | E     | F F F |  GGG  | HHHHH |       |
|  A    |    B  |   C   |   DD  | E     |       |    G  |   H   |   I   |
| AA    | BBBB  |   C   |       | EEEE  |       |    G  |   H   |   I   |
*-----------------------------------------------------------------------*
|   J   |   K   |  L    |  M  M |  N  N |  OOO  | P  P  |   Q   |       |
|       |   K   |  L L  |     M |  N  N |     O |    P  |       |  R R  |
|   J   | K K K |  L    |     M |     N |     O | P  P  |  QQQ  |       |
|       |   K   |  L L  |     M |    N  |    O  | P     |    Q  |  R R  |
|   J   |   K   |  L    |  MMMM |  NN   |  OO   | P  P  |  QQQ  |       |
*-----------------------------------------------------------------------*
|  S    | TTTT  |       |   V   |       | X   X | Y  Y  |   Z   |       |
|  S    |    T  |  U U  | VVVVV |   W   |    X  | Y  Y  | Z   Z |       |
|   S   |    T  |       |       |       |   X   | Y  Y  | Z   Z |. ... .|
|   S   |       | UUUUU | VVVVV | W   W |  X    | Y  Y  | Z   Z |       |
|   S   |    T  |       |       |       |       | Y  Y  | Z   Z |       |
*-----------------------------------------------------------------------*

	The SGA is used in all the Commander Keen game, with the exception of
Keen Dreams (it's the kid in the middle, the one who never really fits in).


[5.2] What do all the Signs Say?
	Too lazy to translate those signs on your own?  Well you're in luck,
because I've gone through the trouble of translating them for you, as well as
the places that you'll commonly find them!  Please note that I haven't bothered
to list any SGA that is directly followed by a translation in-game, such as
those found in the schools of Vorticon VI.  Also note that as no SGA exists in
Keen Dreams, you won't find a section for it here!

[5.2.1] Marooned on Mars
	Sign			Location
	THIS IS NEAT		Found near Rayguns

	DIE			Found near environmental hazards

	EXIT			Located (not surprisingly) next to exits

	BEHOLD THE HOLY		A sign found in the Pogo Shrine
	"POGO" STICK

	HI			Written in Lollipops at the entrance of Emerald
				City

	GO UP			Also found in Emerald City below a hidden Teddy
				Bear

	A, B, C, D		Found on the Keycards and their corresponding
				Doors

[5.2.2] The Earth Explodes
	Sign			Location
	THIS IS NEAT		Found near Vorticon HyperPistols

	EXIT			Located next to exit doors

	VC			Written on various barrels scattered throughout
				the ship

	ON			Found written on lightswitches and near Tantalus
				activation levers

	GO UP			A hint found at the beginning of the London
				Tantalus Ray

	BLUE PRINTS		Printed on the middle-right of the Mothership's
	ACME			blueprints (the World Map)

	GB			Near Galley B

	EA			Outside of Engineering A

	EB			Outside of Engineering B

	LONDON			Outside of London Tantalus Ray

	TANTALUS LONDON		Above the machine that activates London's
				Tantalus Ray

	CAIRO			Outside of Cairo Tantalus Ray

	TANTALUS CAIRO		Above the machine that activates Cairo's
				Tantalus Ray

	RC			Outside of the Reactor Core

	HOME A			Outside of Home A

	NEW YORK		Outside of New York Tantalus Ray

	TANTALUS NEW YORK	Above the machine that activates New York's
				Tantalus Ray

	SYDNEY			Outside of Sydney Tantalus Ray

	TANTALUS SYDNEY		Above the machine that activates Sydney's
				Tantalus Ray

	HOME B			Outside of Home B

	PARIS			Outside of Paris Tantalus Ray

	FUCL			Written with yellow platforms in red platforms
				at the beginning of Paris Tantalus Ray

	TANTALUS PARIS		Above the machine that activates Paris'
				Tantalus Ray

	WA			Outside of Weaponry A

	ROME			Outside of Moscow Tantalus Ray (whoops)

	TANTALUS MOSCOW		Above the machine that activates Moscow's
				Tantalus Ray

	MOSCOW			Outside of Rome Tantalus Ray

	TANTALUS ROME		Above the machine that activates Rome's Tantalus
				Ray	

	WB			Outside of Weaponry B

	DC			Outside of Washington, D.C. Tantalus Ray

	TANTALUS D C		Above the machine that activates Washington,
				D.C.'s Tantalus Ray

	V			Written on the chest of Vorticon Elites

	A, B, C, D		Found on the Keycards and their corresponding
				Doors

[5.2.3] Keen Must Die!
	Sign			Location
	THIS IS NEAT		Found near Pistols

	EXIT			Located next to exits

	BYE NOW			Written on the exits

	GI			Written on the paintings of the Grand Intellect
				and on flags flying throughout Vorticon VI

	CAR			Written on the flying cars

	HI			At the entrance to Vortiville and the title
				screen

	VORTIVILLE		At the entrance to Vortiville and Valden
				Park

	TH			Tom Hall's initials are found above the
				Vortiville sign in Vortiville

	LOWER VORTIVILLE	Found near the entrance to Lower Vortiville

	WEST VORTIVILLE		Found at the top of West Vortiville

	VALDEN PARK		Found in the grassy area of Valden Park

	WATER			Also found in the grassy area of Valden Park

	NEW VORTICON		Found at the entrance to New Vorticon

	CENTRAL PARK		Found near the beginning of New Vorticon

	SUBWAY			Found at the entrance to the underground of

	BEENS			Found at the entrance to Beens

	SCHOOL			Found above a school in Beens

	THE BONKS		Found at the entrance to The Bonks

	NURSERY			Signage on the play pen of a bunch of Youths in
				The Bonks.

	HALS KITCHEN		Found at the beginning of Hal's Kitchen

	FORT VORTICON		Found near the entrance to Fort Vorticon

	POOL			Located deep within Fort Vorticon

	FORT CAVORT		Found at the entrance to Fort Cavort

	FORT VORTA BELLA	Found at the entrance to Fort Vorta Bella

	CAPE CANAVORTA		Found at the entrance to Fort Canavorta

	BARRACKS		Found within Cape Canavorta

	BRIG			Found deep within Cape Canavorta

	GO UP			Found at the entrance of The Caves of Oblivion

	MM			Written on the Mangling Machine of Mortimer
				McMire

	A, B, C, D		Found on the Keycards and their corresponding
				Doors

[5.2.4] Secret of the Oracle
	Sign			Location
	EXIT			Found (not surprisingly) near exits

	WATCH OUT		Found in particularly dangerous parts of the
				Shadowlands

	HIGH LOW		Found near some switches

	HI			Found in Lifewater Oasis and The Perilous Pit

	ACME ORACLE		Written on the Oracle

[5.2.5] The Armageddon Machine
	Sign			Location
	EXIT			Found flipping around near exits

	GO			Appears on switches when they are turned on

	PUSH ME			Found next to a strange machine in the
				background of Defense Tunnel Vlook

	OK			Written on the monitors of the Regulation
				Control Center

	INSERT COIN		Written on the Brownian Motion Inducer

	JUMP DOWN AT ARCH	A hint for getting to the secret Korath III Base
				written on the wall of the Gravitational Damping
				Hub

	ID			Written with Bags O' Sugar in Korath III Base

	WARNING			Misspelled "STRCTURE" in most versions of the
	FUSE STRUCTURE		game, this sign is found next to three of the
	FRAGILE			four machines that protect the main elevator
				shaft

	DT			Found on the outside of each Defense Tunnel

	NBI			Found outside of the Neutrino Burst Injector

	EFS			Found outside of Energy Flow Systems

	RCC			Found outside of the Regulation Control Center

	BMI			Found outside of the Brownian Motion Inducer

	QED			Found outside of the Quantum Explosion Dynamo
				and on the machine itself

	S			Written on the circular red platforms

	V			Found on Kegs O' Vitalin

	A, B, C			Found on each side of the matching doorways of
				the Brownian Motion Inducer, as well as next to
				most buttons and the bridges that they toggle

	D, F			Also found next to some buttons and the bridges
				that they toggle

[5.2.6] Aliens Ate My Baby Sitter!
	Sign			Location
	EXIT			Found hovering near exits

	OK			Found in various places on Fribbulus Xax

	KEY GEM			A hint sign to help you locate difficult-to-find
				Gems

	DIE			Occasionally found near hazards on Fribbulus Xax

	DANGER			Also occasionally found near dangerous places on
				Fribbulus Xax

	THIS IS NEAT		Found next to the three items Keen must collect
				to finish his adventure on Fribbulus Xax

	TO SERVE MAN		A cookbook found next to the Stupendous Sandwich
				of Chungella IV

	ID			Found written in Bloog Soda in the Bloogbase
				Management District

	HI			Also found written in Bloog Soda in the
				Bloogbase Management District

	THE PRIMITIVE TERRAN	Written above the translation of the Standard
	ALPHABET		Galactic Alphabet found in Blooglab Space
				Station

	NO			Found next to a door that will take you almost
				to the beginning of the Bloog Control Center

	BFI			Found outside of Bloogfoods, Inc.

	BMI			Found outside of Bloogton Manufacturing, Inc.

	BT			Found outside of Bloogton Tower

	BASA			Found outside of the Bloog Aeronautics and Space
				Administration

	D, U			Found near switches that need to be flipped Down
				or Up, respectively.

[5.2.7] Commander Keen
	Sign			Location
	THIS WAY		Found right under the teleporter in the Red Key
				area of the Forest o' Crazy mushrooms and at
				the beginning of Blooglet Lake



-------------------------------------------
[6] The Hints, Tips, and Other Funny Things
-------------------------------------------
Sometimes, we need a little helping hand to get on our way.  Or maybe we just
want a few pointers, or just want to exploit some bugs and/or see things we
wouldn't normally see. If you're strange, and not like everyone else, skip this.
Thanks goes out to Snortimer for the Commander Keen 3 flying trick,
KeenCommander for the hovering Robo Red info, Kong33 for the info on the red
flashing hand sign in Commander Keen 6, Dark Hood for the translation of the
Morse code message in the Bloog Control Center in Commander Keen 6, and
GARGapplesauce for the exact alignment needed to access the Bloog Control
Center's secret stash.


[6.1] What are some Hints for Invasion of the Vorticons?
	General Hints: Some places are only reachable by the pogo stick.  It is
wise to practice your pogo skills.  "The Impossible Pogo Trick" is a trick that
makes the game easier.  How it works: walk or run in a direction, then press
the pogo key, release it QUICKLY and press jump.  You will pogo up and over at
an angle that's not possible using any other method.  In Episodes Two and
Three, this technique is very valuable.

	All good Commanders know when to save their progress.  On the World
Map, press F5, and select a save position from 1-9.  You can continue your game
from the title screen, just select Continue Game, and press the number of your
previously saved game.

	Conserve your ammo!  If you can get past an enemy without firing, do
it!  You'll find this technique especially helpful in Episode Three, where
you'll more than likely run out of weapon power if shoot everything that moves.
Another useful technique is getting your enemies in between you and either a
Tank Robot, a Guard Robot, or a Vorticon Women.  More often than not, they'll
get fried in the crossfire.

	You can use your pogo stick to avoid going into the Exit door.  Before
you start leaving, activate your pogo, and you won't get sucked in.  Use this
to get goodies behind the exit.

	You gain an extra life for every 20000 points that you collect.

	Read the Signs, they give you invaluable hints (and a whole bunch of
information you don't need).

	Use your common sense!  If it looks sharp, pokey, or otherwise harmful
to you, it probably is!

	Specific Hints:

[6.1.1] Marooned on Mars
	Look for little white dots, these are the upper-left corners of hidden
bricks, look out for, and use them!  They lead to many secrets.

	After completing the first city, you should go to the Pogo Shrine (it's
the little grey shrine).  There you'll find, surprise, surprise, 'The Holy Pogo
Stick'!  Also look for hidden bricks above the Exit Door.

	They Secret City is accessible through the Red Maze City (the eastern
most city, on the dark side of mars).  At the bottom of this maze city (near the
yellow key card) is a dark area.  Fall past two fire pits, and hold down right.
Next, hop from the hidden brick to the ice cannon area.  Then get into the ice
cannon's line of fire, and finally get launched over and go into the teleporter
(it'll probably take a few tries).

	If there's a sign that says DIE, something nearby will try to
kill you (no kidding).

	Get enemies between you and a Tank Robot, they'll be toast.

	You can get past all of the Vorticons without firing a shot, all it
takes is a little practice:

	Joystick Guard: Go to the farthest right edge of the ledge below the
	exit (the one with a Raygun on it).  The Vorticon will go off the right
	edge, and plummet to his death.

	Car Battery Guard: Get him to follow you, and make him jump off the
	platform.  Getting the Car Battery should now be easy as pie.

	Vacuum Cleaner Guard: Get the Vorticon to jump on the blue cylinders,
	and run underneath him, through the door.

	The Vorticon Commander (Guarding the Everclear): This is REALLY HARD to
	do without cheating, but possible (I've done it before, once).  When
	he's over on the left side of the platform, climb up, and PRAY that he
	jumps high.  If so, run quickly under him and over to the Teddy Bear.
	You may also have success trying jumping over him.  Make sure you
	activate your pogo after getting out of his pit to avoid the exit before
	getting the Everclear!  I only recommend you to do this if you feel the
	need to boost your ego.  Otherwise, use a hidden brick to jump up on the
	huge block, and shoot the chain.

	Now, if you can somehow get past the Vorticon Commander using the above
stated method, run into the exit without getting the Everclear.  You'll truly be
Marooned on Mars (you can't re-enter levels you have beaten)!

[6.1.2] The Earth Explodes
	It's undocumented, but important: To pull switches or push buttons,
press the pogo button when you are near.

	Tantalus Rays are destroyed by using the pogo to hop up, and shooting
the purple sparking cell in the glass bubble.  WARNING: Don't stand too close to
the switch when activating your pogo, you could pull it, and that ends the game
(in a bad way)!

	The little red robots, Scrubs, can be jumped on for a ride up the wall.
You'll find this technique VERY useful.

	The Guard Robots are deadly adversaries: Get an enemy between you and
him.

	You can stand on top of Vorta-Cola cans to get to higher places, and
taking them may change the way the Scrubs walk.

	The wise Vorticon will not jump in the dark.  In fact, even unwise
Vorticons will not jump in darkness.

	Keen can leave Rome's Tantalus Ray still active if he goes as far right
as possible at the beginning, and hopping up the little hole.  If he does that,
though, the game will be left in an unwinnable position!

	On the world map, the SGA labels Rome and Moscow are in the wrong
places!

	On the far right side of the Paris Tantalus level, FUCL is spelled with
the small colored platforms.

[6.1.3] Keen Must Die!
	You need only to complete three levels to finish the game, but what's
the fun in that?

	At the Caves of Oblivion, follow the directions on the entrance sign.

	You can stand on the exit doors!

	When Meeps sing, the sound kills, and can travel through anything.  Even
solid walls!

	You can usually run under the VortiNinjas when they jump high into the
air.

	Line up a foe with a Sentry Gun, or a Vorticon Woman.  They'll die in a
jiffy.

	Remember, some falls are necessary, and some things are hidden in the
heavens (think big clouds).

	Jacks are almost always deadly, don't enter an area with them unless you
have an Ankh, speaking of which...

	All Ankhs can be obtained.

	If you look at the Blue Key in the Status Screen, it has a sky blue aura
around it.  Weird!

	It's possible to fly in the air without using a cheat.  Just press jump
and then fire at almost the same time.  You'll waste a few bullets, but it's
good for getting to tough places when you don't want to cheat.

	On the final level, you can stand on the shoulders. (I don't want to
give away too much, now do I?)


[6.2] What are some Hints for Keen Dreams?
	Get candy for points, which will get you extra lives.

	You get your first extra life at 20000 points, the next at 40000 points,
the third at 80000, and so on, the points needed doubling with each life.

	Search everywhere--there's a LOT of hidden stuff!

	Don't assume anything.

	You can jump through logs by holding Down, and pressing the Jump button.

	If you miss an enemy you are trying to shoot, you can recollect your
Flower Power shots for a short period of time (the same is true for Boobus
Bombs).

	You can stand on the blue Mosquitoes, but not the black ones.

	If you see the message 'Boobus Bombs Near!' when the level is loading,
find and collect them.  You need at least 12 to defeat King Boobus Tuber.

	If there isn't a cement wall in your way, go against the right wall, AND
DIE!  If Commander Keen's head goes through the right edge of the screen, you'll
complete the level (and if you miss, it's your problem).


[6.3] What are some Hints for Goodbye Galaxy!?
	General Hints: Don't use two button firing, it makes it even more
impossible to do the "Impossible Pogo Trick" (which is done by running, and
hitting the pogo and jump keys in rapid succession).

	Sometimes you'll see big arcs of candy.  These are usually set up so
that you can grab them in one Cool Jump.

	You get your first extra life at 20000 points, the next at 40000 points,
the third at 80000, and so on, the points needed doubling with each life.

	To jump through a hole in the ground, look down and hit the jump key
(this is known as the "Down Jump").

	If you just don't make a jump, you can usually grab the edge and hang
on (as long as it's not on a diagonal slope downward).

	You don't have to pull up right away if you grab an edge, take a long
breather if you want.

	To erase the high scores in Commander Keens 4 and 5, delete the 
CONFIG.CK4 and CONFIG.CK5 files respectively.  You'll also have to reselect any
changes to joystick or game settings, as this information is also stored in the 
CONFIG files.

	Save the game often, you'll be glad you did.

	If you're having jerky motion problems, or having "snow" fly across 
your screen, select the Fix Jerky Motion and SVGA Compatibility options on the 
Configure - Options screen.

	Read the Signs!

Specific Hints:

[6.3.1] Secret of the Oracle
	There are many hidden platforms in Commander Keen 4.  You can see them
flash in the sunlight every few seconds (NOTE: These are usually VERY hard to
see, but if a flash catches your eye, be sure to look).

	There are seven free keens available on the first level.

	You can get to the top of the Pyramid of the Moons.  I'm talking the
outside!  And on the subject of Moons...

	If you stand on a shaded moon in the Pyramid of the Moons for a few
seconds, Commander Keen will moon you!

	Princess Lindsey appears twice.

	There's stuff hidden very well in Hillville, all you need is a flash of
insight.

	The way to the Pyramid of the Forbidden is at the bottom of the Pyramid
of the Moons.  (Remember, Inchworms will be afoot, but how many of them?)

	The Dopefish likes to eat the small Schoolfish that follow you.

	The jump button makes you swim faster underwater.

	The Skypests can be squashed by jumping on them with your pogo stick.

	You can only shoot Mimrocks when they are jumping at you.

	If you're running really low on ammo, a trip to The Bean-with-Bacon
Megarocket may be beneficial.

	Mad Mushrooms leap higher on the third bounce.

	If you look up while standing on one of the disappearing ice blocks in
Miragia, you won't fall down...even if it disappears!

[6.3.2] The Armageddon Machine
	There are TEN lives available in the first level (but don't expect them
to be easy to find).

	The names of the two level designers, John Romero the Software Engineer,
and Creative Director Tom Hall, are hidden in two of the levels.

	The enemy name 'Little Hampton' is actually far dirtier than it would
first seem.  Tom Hall says this:

	'Some British TV show referred to a guy with a... um, small... you
	know... as having a "Little Hampton". That stuck in my head when I was
	naming stuff, I guess.'

	In Version 1.0 of The Armageddon Machine, in the Energy Flow Systems,
there is a Swastika above John Romero's name.  However it was removed in the GT
Interactive Version 1.4.  This must be set straight!  Here's what Romero himself
had to say about the incident:

	'Obviously, it was a reference to Wolfenstein... ? Sure, Keen 5 was
	created before Wolfy, but we knew that was our next project.'

	Tom Hall, creator of Commander Keen, further expanded on that point:

	'I think John put that in as a reference to Wolfenstein, not to imply
	anything about any character's ideology.  Same as when he originally had
	the swastika shape in DOOM, that folks go so upset about that took it
	out.  As if that meant anything remotely like condoning the atrocities
	of Hitler.  (Remember kids, Hitler bad.  Hating groups of people for no
	reason, very bad.  Killing people for the same no reason, very very very
	insanely bad.)

	'If Wolfenstein had had a logo, like a big "W" or something, then John
	would've made that shape, I'm sure.'

	There are 30 000 hidden points near the start of Defense Tunnel Sorra.

	You can't destroy the Quantum Explosion Dynamo directly, you'll have to
find something (or someone) to destroy it for you.

	If you look up while standing on the red spinning platforms, you won't
be spun off!

	It's possible to make Robo Red hover off the end of a platform.  The
trick is his attention while he's at the very edge...

	Shelley can be destroy by the sentry guns' shots!

	The way to the secret level is through the Gravitational Damping Hub,
look down and translate.

	To see the real ending of Commander Keen 5, you have to do something
special in the Korath III Base.

	There are problems on Korath III if you're playing in the "Easy"
difficulty level.  In earlier versions of Commander Keen 5, after a few seconds
of play in the secret level, the game would quit and you would get the error
message 'Goplat moved to a bad spot: 2114,1600'.  In Version 1.4, it isn't
possible to see the "Real Ending" because, well, you'll have to find out for
yourself.  

	You probably figured this out, but you break the fuses by using your
pogo stick.

	The Slicestars can be destroyed!  The ones moving on a set path take 20
shots to be destroyed, but the Slicestars that just bounce around take 45 shots
to destroy, and are hardly worth the time, energy, and ammo since they're easier
to avoid then their slow moving counterparts.

	You can duck the nearly invincible Slicestars and the rather vincible
Volte-faces, but not Robo Red.  He's too big and evil!!! 

	You can stand next to Robo Red and not get shot (you can sometimes duck
them too), but then you're next to him and that can't be good.

	Robo Red's hearing is very good, and if he hears a noise, he'll shoot
first, and ask questions later.

	Some levels have areas that are preceded by a "NO HUMANS" sign, these
are places that are especially dangerous, but also have valuable rewards.

	You can stand on the horizontal Sentry Guns to get to higher places.

	You can stand on top of the strange pillar at the beginning of the
Brownian Motion Inducer.


[6.4] What are some Hints for Aliens Ate My Baby Sitter!?
	Don't use two button firing, it makes it even more impossible to do the
"Impossible Pogo Trick" (which is done by running, and hitting the pogo and jump
keys in rapid succession).

	Sometimes you'll see big arcs of candy.  These are usually set up so
that you can grab them in one Cool Jump.

	There's more to do at The Bean-with-Bacon Megarocket than it seems
(notice that you can't exit the level on the right side).

	A Bobba guards the Bean-with-Bacon Megarocket in Hard difficulty.

	You get your first extra life at 20000 points, the next at 40000 points,
the third at 80000, and so on, the points needed doubling with each life.

	There are three very important items that Commander Keen needs to get to
complete his quest.  They are located in The First Dome of Darkness, Bloogfoods,
Inc., and Bloogton Tower.

	You can ride on the back of a Gik (though they like to jump around,
making it difficult sometimes).

	There's a neat little game exploit in this game that's been nicknamed
'The Impossible Bullet Trick'.  It takes a little practice (and bullets) to get
right, but once you have it mastered it's a useful tool for getting around
quick.  First of all jump into the air and begin shooting down.  You want to
time it so that the bullet hit as you are one tile above it.  I find shooting
down twice in quick succession right at the apex of my jump works well.  You'll
know that you've got it when you're hovering one tile in the air.  Next, shoot
upwards.  You'll go rocketing upward with the bullet magically beneath you!
Voila!  The Impossible Bullet Trick!

	The way to the Blooglab Space Station is through the Bloog Control
Center (and I mean THROUGH it).

	There's a secret stash hidden in the Bloog Control Center, unfortunately
trying to access it on a difficulty other than Easy is pure suicide.  The
entrance is located right below the switch in the first room and Easy there is a
platform located right below the switch that you can use to line drop.  You need
pixel-perfect accuracy to make it through alive so listen up: While standing on
the platform below the switch make Keen face to the right and line up the
colorful back edge of his helmet with the light-grey line on the left side of
the pole.  Once you're perfectly aligned Jump Down and you'll slip through the
small gap in the plasma orbs.  Once you've safely passed through, press UP and
you'll enter an invisible door taking you to all the goodies!  Totally worth it
if you can get through.

	The entire Standard Galactic Alphabet is hidden in the Blooglab Space
Station.

	You should feel no remorse for wasting a Blooglet.  They like to hang on
to their corresponding Gem Key Color.

	Like in Commander Keen 5, you can stand on top of the Sentry Guns (just
watch out for their shots).

	You can pogo off of a switch that is flipped "up" to get a higher
bounce.

	If you can get a Nospike to charge off a cliff, he'll fall to his death.
It's almost too easy!

	Watch out for a little tip of a tongue, it's a Ceilick hidden up in the
rafters!  If you find yourself underneath one, shoot up immediately (any later,
and you'll be dead already).

	Jump up as a Blooguard swings his club in the air, you won't be stunned
by the shock wave.

	Some levels have areas with a red flashing hand sign.  This indicates a
dangerous area that isn't necessary to enter to complete the level.

	In the Bloog Control Center you can hear this Morse code playing in the
background: SOS SOS DE KEEN SOS SOS K.

	If you look up while standing on the red spinning platforms, you won't
be spun off!

	If you use the Warp Cheat and go to the High Score screen, you get the
message: 'Keen is in the High Score screen.  Call Id!'  What could this mean?
Who knows?

	This game is quite hard!  Patience and ingenuity is the key.

	The KEY to success in the Blooglab Space Station is to FALL in love with
Molly because she's DROP-dead gorgeous.  Rescue her quickly, before she DECENDS
to the stomach of a Bloog (it seems I'm beating around the bush here).

	Read the signs!


[6.5] What are some Hints for Commander Keen?
	Don't trust your instincts!  Everything's been flipped on its head and
what you think is right could very well be wrong.

	Points are your friend!  Not only do they increase your score and give
you lives and continues, but every time that you've collected at least one point
item you are protected from one enemy hit.  You are still instantly killed by
environmental hazards, but projectiles and direct contact with enemies will
cause you to just take a little bounce backwards.

	You gain an extra life for every 1000 points you collect on Easy, 1500
points on Medium, and 3000 points on Hard.  As well you gain an extra continue
for every 100 goodies you collect on Easy, 150 goodies on Medium, and 175
goodies on Hard.

	If you find yourself teleporting straight into danger (such as a jumping
Gik or an enemy's projectile) start mashing the SELECT button as fast as
possible!  You'll teleport back to safety without getting hit.

	Likewise, if you move the D-pad while teleporting in, you will cancel
the teleport animation and also be able to escape from danger.

	You can walk past stunned enemies without fear.

	Follow the hints that appear!

	Remember that you push buttons on the ground with the SELECT button.

	You can sometimes use stunned enemies to pogo up to Extra Lives and
items that are out of reach.

	If you're finding a level too hard, press SELECT from the Status Screen
to quit back to the World Map.

	Finished levels can be re-entered, if you so desire.

	Record your passwords!  They are the only way that you can save your
progress in the game.

	This game can be quite hard.  It's a good idea to begin with the Easy
difficulty to get used to the game's mechanics and levels in a more forgiving
environment.



-------------------
[7] The Cheat Codes
-------------------
Sometimes we need a few codes to help us out, and that's okay.  KEY+KEY
means hold down both keys at the same time (e.g. F10+G means press and hold
F10, and then press G. If it worked, you'll usually see a confirmation 
message).  In Commander Keen, cheats are entered in the PASSWORD section of the
Main Menu.

[7.1] What are the Cheat Codes for Invasion of the Vorticons?

	Code           		Description
	C+T+SPACE		Gives you a Pogo Stick, all 4 keycards, and 100
				Raygun Charges

	SHIFT+TAB   		Allows Commander Keen to pass through one City
				on the World Map

	G+O+D       		Activates God Mode (Invulnerability) and
				unlimited jumping height with the Pogo Stick


[7.2] What are the Cheat Codes for Keen Dreams?

	Code			Description
	F10+I  			Gives you 99 Keys and 99 Boobus Bombs

	F10+S  			Slow Motion Toggle

	F10+J  			Gives Commander Keen unlimited jump height
				until you hit your head or let go of the jump
				key

	F10+G  			Toggles God Mode

	F10+W  			Warp to Specified Level.  See below for list.

	Level List
	Number  Level
	0       The Land of Tuberia
	1	Horseradish Hill
	2       The Melon Mines
	3       Bridge Bottoms
	4       Rhubarb Rapids
	5       Parsnip Pass
	6       Level 6
	7       Spud City
	8       Level 8
	9       Apple Acres
	10      Grape Grove
	11      Level 11
	12      Brussels Sprout Bay
	13      Level 13
	14      Squash Swamp
	15      Boobus' Chamber
	16      Castle Tuberia


[7.3] What are the Cheat Codes for Goodbye Galaxy!?

	Code                   	Description
	KEEN4 /TEDLEVEL ??	This is a level practice
	or KEEN5 /TEDLEVEL ?? 	mode that gives you infinite lives, type it at
				the DOS prompt.  Where "??" is, insert the
				level number (see below).  Completing the level
				or choosing an option on the Control Panel
				other than Paddle War! or Return to Game will
				lock up the system.

      	B+A+T                  	Cheat Option!  You get all 4 Keys, 99 Shots, and
				an Extra Life

	E+N+D                  	Finishes the game for you!

      	F9                     	Boss Key (causes the screen to look like the DOS
				prompt, just in case the boss comes by while
				you're playing). 

      	A+2+ENTER            	Master cheat.  TYPE THIS FIRST to use the 
				following cheats.

      	F10+E                  	Returns to the World Map, finishing the level

      	F10+T                  	Sprite Test

      	F10+Y                  	Debug Mode, this allows you to see all secret
				areas (the normal looking walls)

      	F10+I                  	3000 Points, all the Keys, 99 Shots and the
				Wetsuit (in Commander Keen 4)

      	F10+P                  	Pause

      	F10+S                  	Slow Motion Toggle

      	F10+G                  	Toggles God Mode

      	F10+J                  	Toggles Jump Cheat (gives Commander Keen
				unlimited jump height)

      	F10+N                  	No Clipping Mode Toggle (allows Commander Keen
				to go through anything)

      	F10+B                  	Change Border Color

      	F10+V                  	Add VBLs

      	F10+C                  	Object Count

      	F10+Z                  	Game Over!

      	F10+M                  	Check Memory Usage

      	F10+D                  	Create a Demo
 
      	F10+W			Warp to specified level (check list below)

	Level List

	Secret of the Oracle
	Number  Level
	1       Border Village
	2       Slug Village
	3       The Perilous Pit
	4       Cave of the Descendents
	5       Chasm of Chills
	6       Crystalus
	7       Hillville
	8       Sand Yego
	9       Miragia
	10      Lifewater Oasis
	11      Pyramid of the Moons
	12      Pyramid of the Shadows
	13      Pyramid of the Gnosticene Ancients
	14      Pyramid of the Forbidden
	15      Isle of Tar
	16      Isle of Fire
	17      Well of Wishes
	18      Bean-with-Bacon Megarocket

	The Armageddon Machine
	Number  Level
	1       Ion Ventilation System
	2       Security Center
	3       Defense Tunnel Vlook
	4       Energy Flow Systems
	5       Defense Tunnel Furrh
	6       Regulation Control Center
	7       Defense Tunnel Sorra
	8       Neutrino Burst Injector
	9       Defense Tunnel Teln
	10      Brownian Motion Inducer
	11      Gravitational Damping Hub
	12      Quantum Explosion Dynamo
	13      Korath III Base
	14      N/A (Causes game crash)
	15      High Scores
	16      N/A (Causes game crash)
	17      N/A (Causes game crash)
	18      N/A (Causes game crash)


[7.4] What are the Cheat Codes for Aliens Ate My Baby Sitter!?

	Code                	Description
      	KEEN6 /TEDLEVEL ??  	This is a level practice mode that gives you
				infinite lives, type it at the DOS prompt.
				Where "??" is, insert the level number (see
				below).  Completing the level or choosing an
				option on the Control Panel other than Paddle
				War! or Return to Game will lock up the system.

      	F9                  	Boss Key (causes the screen to look like the DOS
				prompt, just in case the boss comes by while
				you're playing).

      	B+A+T                  	Cheat Option!  You get all 4 Keys, 99 Shots, and
				an Extra Life. (doesn't work in v1.0)

      	E+N+D               	Finishes the game for you!

      	A+2+ENTER            	Master cheat.  TYPE THIS FIRST to use the
				following cheats.  (Not necessary in v1.0)

	F10+I               	3000 Points, all 3 Items, all 4 Keys and 99
				Shots

	F10+E               	Return to Fribbulus Xax

      	F10+T               	Sprite Test

	F10+Y               	Debug Mode, this allows you to see all secret
				areas (the normal looking walls)

      	F10+P               	Plays Extra Life music, and Freezes the game.
				Press Esc to quit

	F10+S               	Slow Motion Toggle

	F10+D               	Record a Demo

	F10+G               	God mode toggle

	F10+C               	Object Count

	F10+V               	Add VBLs

	F10+B               	Change Border Color

	F10+N               	No Clipping Mode Toggle (allows Commander Keen 
				to go through anything)

	F10+Z               	Game Over!

	F10+M               	Check Memory Usage

	F10+J               	Toggles Jump Cheat (gives Commander Keen
				unlimited jump height)

	F10+W               	Warp to specified level (check list below)

	Level List
	Number  Level
	1       Bloogwaters Crossing
	2       Guard Post One
	3       The First Dome of Darkness
	4       The Second Dome of Darkness
	5       The Bloogdome
	6       Bloogton Manufacturing, Inc.
	7       Bloogton Tower
	8       Bloogfoods, Inc.
	9       Guard Post Two
	10      Bloogville
	11      Bloog Aeronautics and Space Administration
	12      Guard Post Three
	13      Bloogbase Recreational District
	14      Bloogbase Management District
	15      Bloog Control Center
	16      Blooglab Space Station
	17      Bean-with-Bacon Megarocket
	18      High Score


[7.5] What are the Cheat Codes for Commander Keen?

	Password               	Description
	BCDF GHJK LMNP QRST	Gives you infinite lives

	TSRQ PNML KJHG BCDF	Opens up access to all levels



------------
[8] The Maps
------------
Woe unto the gamer who needs to consult this to complete one of the Commander
Keen games.  Below are the world maps for each game with their basic level
layout.  Paths that can only be accessed with a special item are indicated by
an equals sign (=).  Teleporters are listed as TP# with the order in which they
loop listed underneath the map.  In a similar manner, elevators are marked with
EV# with loop order listed underneath the map.  Levels for which no official
name has been given are designated by an asterisk (*).


[8.1] What's the Layout of Marooned on Mars?

				 Map of
				  MARS

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +		   TP1			TP2----Ice City  First Ice   +
 +		    !			     !		 Shrine*     +
 +	     Emerald City*		     !		   !	     +
 +		    !			     !--------------	     +
 +  Second Red	    !		Third Red    !			     +
 +  Rock Shrine*----!		Rock Shrine*-!			     +
 +		    !			     !			     +
 +  Pogo Shrine--   !			     !---Fourth Red	     +
 +	        !----			     !	 Rock Shrine*	     +
 +	        !			     !			     +
 +  Treasury*   !-Capital City*	Fifth Red    !			     +
 +	!       !		Rock Shrine*-!			     +
 +	!--------			     !		  Secret     +
 +	!				     !		   City	     +
 +	!	First Red		     !-Red Maze	    !	     +
 +	!	Rock Shrine*		     !	 City	    !	     +
 +	!	     !			     !		   TP3	     +
 +	-------------!			     !			     +
 +		     !			     !			     +
 +  START--------Border Town*		     !			     +
 +					     !			     +
 +			---------------------!			     +
 +			!		     !			     +
 +		Vorticon Commander's	Second Ice		     +
 +		      Castle		Shrine*			     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Teleporter Loops:	TP1 -> TP2 -> TP1 -> ...
			TP3 -> TP2


[8.2] What's the Layout of The Earth Explodes?

				 Map of
		        THE VORTICON MOTHERSHIP

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +			   Washington, D.C.			     +
 +			    Tantalus Ray*			     +
 +				  !				     +
 +		      Moscow	  !	    Rome		     +
 +  Weaponry A*---Tantalus Ray*--------Tantalus Ray*---Weaponry B*   +
 +		!				     !		     +
 +		--------------------------------------		     +
 +				  !			 Home B      +
 +     New York			  !			    !	     +
 +  Tantalus Ray*-----------------!-------------------------!	     +
 +		       !	  !	       !	    !	     +
 +		       !	  !	       !	  Paris      +
 +		       !	  !	       !      Tantalus Ray*  +
 +		    Home A     Reactor	    Sydney		     +
 +				Core*	 Tantalus Ray*		     +
 +     London			  !			   Cairo     +
 +  Tantalus Ray*-----------------!-------------------Tantalus Ray*  +
 +				  !				     +
 +				  !				     +
 +  Engineering B*----------------!----------------Engineering A*    +
 +				  !				     +
 +			      Galley B*				     +
 +				  !				     +
 +				START				     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


[8.3] What's the Layout of Keen Must Die!?

				 Map of
			      VORTICON VI

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +  		 The Caves	   The Castle of		     +
 +	TP1-----of Oblivion-----the Grand Intellect		     +
 +							Cape	     +
 +	 TP2---TP3			Fort	      Canavorta	     +
 +	     !			       Cavort		  !	     +
 +	    TP4 			 !	      TP5---TP6      +
 +				  TP7----!			     +
 +	 TP8---TP9			 !			     +
 +	     !			  Fort   !     Fort		     +
 +           !    Hal's		Vorticon-!-Vorta Bella		     +
 +  Beens----!---Kitchen		 !		      TP10   +
 +        !  !				 !	   West		!    +
 +	TP11 !				Fort	Vortiville---Valden  +
 +	     !				Vox*		   !  Park*  +
 +	    The						 TP12	     +
 +	   Bonks						     +
 +					Vortiville   TP13	     +
 +	     New			    !	       !    Lower    +
 +  TP14---Vorticon---TP15	START--------------------Vortiville  +
 +							      !	     +
 +							    TP16     +
 +			Hidden					     +
 +			 City*					     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Teleporter Loops:	TP1  -> TP7
			TP2  -> TP7
			TP3  -> TP5
			TP4  -> TP8
			TP5  -> TP16
			TP6  -> TP1
			TP7  -> TP9
			TP8  -> TP10
			TP9  -> TP3
			TP10 -> TP11
			TP11 -> TP12
			TP12 -> TP13 -> TP12 -> ...
			TP14 -> TP16 -> TP14 -> ...
			TP15 -> TP4


[8.4] What's the Layout of Keen Dreams?

			         Map of
			   THE LAND OF TUBERIA

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +                         Boobus' Chamber                           +
 +                               !                                   +
 +             -------------Castle Tuberia--------------             +
 +             !                                       !             +
 +             !                                       !             +
 +  Grape      !            Melon Mines                !             +
 +  Grove      !                 !                     !             +
 +   !         !-----------------!-----Brussels Sprout--             +
 +   !         !                 !           Bay                     +
 +   !         !                 !                Squash Swamp       +
 +   !    Apple Acres       Horseradish                !             +
 +   !         !              Hill ------- START       !             +
 +   !         !                 !                     !             +
 +   !    Spud City              !                Parsnip Pass       +
 +   !                           !                     !             +
 +   Rhubarb Rapids-------------Bridge Bottoms----------             +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


[8.5] What's the Layout of Secret of the Oracle?
                                   
			         Map of
			    THE SHADOWLANDS

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +		Cave of the	Chasm of			     +
 +		Descendents	 Chills	     Crystalus	             +
 +		    !		   !		 !		     +
 +		    -----------------------------!		     +
 +  Lifewater				         !		     +
 +    Oasis			    -------------!		     +
 +	!			    !	 	 !		     +
 +	------			    !	       Slug		     +
 +	     !			    !	      Village		     +
 +	     !---Miragia	    !	 	 !		     +
 +  Sand     !			    !	 	 !-----------	     +
 +  Yego-----!			    !		 !	    !	     +
 +	     !			 Hillville	 !	 Border      +
 +	     !			    !		 !	 Village     +
 +	     ------------------------		 !	    !	     +
 +			  !	       Perilous--!	  START	     +
 +	     Pyramid of---!		 Pit	 !	    !	     +
 +	      the Moons   !--Pyramid of	 	 !  Bean-with-Bacon  +
 +			  !   Shadows	  	 !    Megarocket     +
 +     Pyramid of the	  !		  Isle   !		     +
 +   Gnosticene Ancients---		of Fire--!--Isle of	     +
 +			     Pyramid of		 !    Tar	     +
 +			   the Forbidden      Well of		     +
 +			   		      Wishes		     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


[8.6] What's the Layout of The Armageddon Machine?
                                   
			         Map of
			     THE OMEGAMATIC

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +			   Quantum Explosion			     +
 +				Dynamo				     +
 +				  !				     +
 +			    Gravitational			     +
 +			     Damping Hub			     +
 +				  !				     +
 +			     TP1--!				     +
 +				  !				     +
 +				 EV1				     +
 +								     +
 +								     +
 +			   Brownian Motion			     +
 +			       Inducer				     +
 +				  !				     +
 +			   Defense Tunnel			     +
 +				Teln				     +
 +				  !				     +
 +  Energy Flow--Defense Tunnel---!---Defense Tunnel--Neutrino Burst +
 +    Systems	      Vlook    !  !  !	   Sorra	 Injector    +
 +			      EV2 ! EV3				     +
 +				  !				     +
 +			   Defense Tunnel			     +
 +			        Burrh				     +
 +				  !				     +
 +			 Regulation Control			     +
 +			       Center				     +
 +								     +
 +								     +
 +				 EV4				     +
 +				  !				     +
 +			       Security				     +
 +				Center				     +
 +				  !				     +
 +			   Ion Ventilation			     +
 +			       System				     +
 +				  !				     +
 +				START				     +
 +								     +
 +					Korath III---TP2	     +
 +					   Base			     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Teleporter Loop:	TP2 -> TP1

Elevator Loops:		EV1 -> EV3 -> EV1 -> ...
			EV2 -> EV4 -> EV2 -> ...


[8.7] What's the Layout of Aliens Ate My Baby Sitter!?

			         Map of
			      FRIBBULUS XAX

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +  Bloog Control---Bloogbase Management------=	     Blooglab Space  +
 +     Center	  !	  District	   !  =		 Station     +
 +		  !			   !  =			     +
 +		  --Bloogbase Recreational--  =			     +
 +			  District	      =			     +
 +					      !			     +
 +					      !	   Bloog Aeronautics +
 +					      !		and Space    +
 +					      !	     Administration  +
 +					      !		   !	     +
 +   Bloogton		    Bloogville	 Guard Post---------	     +
 +     Tower		         !	    Three      !	     +
 +	 !		         !		       !	     +
 +	 !	    --Guard Post-------==----------------	     +
 +    Bloogton	    !	Two					     +
 +  Manufacturing,--!					Bloogfoods,  +
 +	Inc.	    !      The				   Inc.	     +
 +		    ----Bloogdome			    !	     +
 +		      !			  TP1	       TP2---	     +
 +		      !			   !			     +
 +		      =	      --------------			     +
 +		      =	      !		 			     +
 +		      !	      !		 			     +
 +		      -----------Bloogwaters--START--Bean-with-Bacon +
 +				  Crossing		Megarocket   +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +							TP3	     +
 +							 !	     +
 +  The First Dome---------------------------Guard Post---	     +
 +   of Darkness		!		 One		     +
 +				!				     +
 +				!-------The Second Dome		     +
 +				!	  of Darkness		     +
 +				!				     +
 +				-------------------------TP4	     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Teleporter Loops:	TP1 -> TP3 -> TP1 -> ...
			TP2 -> TP4 -> TP2 -> ...


[8.8] What's the Layout of Commander Keen?

			         Map of
			THE OMEGAMATIC WARP DRIVE

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +			        FRIBBULUS			     +
 +				   XAX				     +
 +				    !				     +
 +				    !				     +
 +				    !				     +
 +				    !				     +
 +	DROIDICCUS----------------START-----------------SHIKADI	     +
 +	  PRIME							     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

			         Map of
			      FRIBBULUS XAX

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +			       Techno Lab			     +
 +				    !				     +
 +				    !				     +
 +				The Bobba			     +
 +				Fortress			     +
 +				    !				     +
 +				    !				     +
 +				 Blooglet			     +
 +				   Lake				     +
 +				    !				     +
 +				    !				     +
 +			      THE OMEGAMATIC			     +
 +				WARP DRIVE			     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

			         Map of
			    DROIDICCUS PRIME

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +			      The Imperial			     +
 +				 Palace				     +
 +				    !				     +
 +				    !				     +
 +				  Fiery				     +
 +				  Canyon			     +
 +				    !				     +
 +				    !				     +
 +				  Robot				     +
 +				  Hive				     +
 +				    !				     +
 +				    !				     +
 +			      THE OMEGAMATIC			     +
 +				WARP DRIVE			     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

			         Map of
				 SHIKADI

 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +			       Shikadi in			     +
 +				  Space				     +
 +				    !				     +
 +				    !				     +
 +				The Plasma			     +
 +			      Crystal Mines			     +
 +				    !				     +
 +				    !				     +
 +			     Forest o' Crazy			     +
 +				Mushrooms			     +
 +				    !				     +
 +				    !				     +
 +			      THE OMEGAMATIC			     +
 +				WARP DRIVE			     +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



--------------------
[9] The Walkthroughs
--------------------
Wo, wo, wo unto the gamer that requires the use of these walkthroughs!  I,
however, have spent many hours playing and writing so that if it so be that you
need a walkthrough, you can find it right here!  On games with difficulty levels
I have played on the Normal or Medium difficulty.  Remember, if you get lost
consult the maps from the preceding section!  As usual, levels for which no
official name has been given are designated by an asterisk (*).


[9.1] How do I get through Marooned on Mars?
	Your ship is missing these parts:  Go get them!

	Alright, it's time to begin our Marooned on Mars walkthrough so without
any further ado, let's head over to Border Town and begin!

	BORDER TOWN*: So here we are, the first level of the first game.  Border
Town is fairly safe so it's a great place to get acquainted with how Keen
controls.  Practice jumping (and stomping on Yorps) until you've got it down,
you'll need the skills for later!  If you feel adventurous, you can use the blue
platform to head up and to the left to grab the Book, worth a whopping 1000
points!  Once you're ready, grab some Lollipops and head over to the right.
What's this?  A strange sign and a Raygun!  Grab the gun (THIS IS NEAT) and
continue right.  Now there's a sign (DIE) next to some scary looking shell
hazards called Pat-Pats.  Don't touch them!  Continue onward, avoiding the
spikey pit that invokes memories of Super Mario.  You've made it to the exit!
Now you have a couple of choices, you can grab the book underneath, and/or head
up and to the left to grab some more points.  If neither of these ideas appeal
to you, or you've already done them, grab your Soda and leave the level.

	That wasn't so bad, was it?  Our next stop will be straight up to the
grey Pogo Shrine to get a wonderful tool for our adventure.

	POGO SHRINE: I'm liking the ambiance.  BEHOLD THE HOLY "POGO" STICK!
Grab the stick, but don't exit yet.  You see that grey dot above the exit?  It's
a hidden brick!  You can only see a hidden brick's upper-left corner, and it
usually leads to a wonderful secret!  Use your new-found pogo skills to get on
top of it and you'll find yourself next to a fire pit.  If you're feeling
confident leap across the fire and up to get a Teddy Bear (5000 Points!) that's
guarded by a Garg.  If not, or if you've already grabbed it, head down to the
exit.

	Alright!  Now we're motoring along, let's go back down and take a quick
trip to the First Red Rock Shrine.

	FIRST RED ROCK SHRINE*: Hmm, this is a small dark place.  Head straight
up and you'll find a glowing Yorp statue!

		You hear in your mind:

		It is too bad that you cannot read the
		Standard Galactic Alphabet, human.

	Heh, guess this guy didn't realize that you'd have Section [5] to help
you out with that little problem.  Well, let's get out of here!

	Now you find yourself faced with a choice, you can go left to the
Treasury, or right to Capital City.  Both are required, but I'll be going left
first.

	TREASURY*: Alright, it's a good thing that we got the pogo stick, it'll
make going in this level much easier!  So pogo up to the red cylinders above the
green spikes. and keep on leaping up the other stack of cylinders.  If you want
to go for the Teddy Bear on the left, it's reachable by doing the Impossible
Pogo Trick (hitting pogo and jump in quick succession) from the third pair of
left-side cylinders (two tiles above the red platform).  Now pogo up to the
purple platform on the right, jump up until you get to the solid roof of purple
tiles, and then get on top of it through the little Lollipop chamber.  Wait for
the Yorps above you to fall off the platform and then go up and up again,
avoiding the Butler Robot, and jump to the platform on the left (perhaps using
the purple cylinders if you so desire).  What's that there?  A Yellow Keycard!
Grab it and head up and to the right.
	Heading right, you'll get to some Soda in an arrow pattern.  Drop down
and then head left.  If you feel like getting a Teddy Bear, you can jump into
the small opening made of solid purple blocks.  With that out of the way, head
straight down, on the right side of the yellow cylinders.  Heading right past
the Yorp we find the Yellow Door!  Go through and jump over the Garg to get the
Red Keycard.
	Now it's time to head up the little staircase of red cylinders and to
the right past the DIE sign and the Pat-Pats.  Grab the Book and head right down
the little gap, there's a Raygun down there and ammo is precious at this point
in the game!  After getting that gun, head back up as high as you can, grabbing
as many points as desired.  You'll see the blue feet of a Vorticon above you!
Head left, back to the green cylinders, and have your first Vorticon encounter!
You can either lure him to the left, off of his platform, or take him out with
the Raygun!  He's a strong one, so it'll take four shots to finish him off.
Watch out for his jump!  After dealing with him, head for the exit (grabbing the
Book if you want) and claim your well-earned prize: the Car Battery for the
Bean-with-Bacon Megarocket!  One down, three to go!

	Ok, well now that that's finished it's time to head right on over to
Capital City, we've got another ship part to claim!

	CAPITAL CITY*: After the Treasury, this one will be a breeze.  Start off
admiring the flag go and grab some Lollipops!  The one in the top-left corner
can't be collected, so don't waste too much time trying.  After that, head into
the gap and down one level.  See that Yellow Door above you?  We're heading for
its Keycard.  Just a little to the right and...there it is!  It's almost too
easy!
	If you feel like getting some more points, head down below, otherwise
just go back and up to the Yellow Door.  Going through we find a small section
with yellow bricks and SWEET! a Raygun!  Grab it and head down.  Watch out for
the Garg's pit!  Heading right, into the red brick area, jump up to the DIE sign
next to the Pat-Pat.  Him and his friend are guarding your next goal: the Red
Keycard!
	After grabbing it head back and down toward the final part of the level.
It's Pizza time!  Grab the two slices and the Raygun.  Look up!  It's another
Vorticon.  This guy, though, isn't too smart; if you stand on the right of the
Raygun platform he'll probably very quickly head right off the edge of the map.
Problem solved!  Now just head over and up to get to the Red Door.  There are a
couple of Books for the adventurous who'll cross through fire, but more
importantly there's the second ship part: The Joystick!  Grab it and get out of
there!

	Time to head up and take a pitstop in the Second Red Rock Shrine.

	SECOND RED ROCK SHRINE*: Another nice and easy little level.  Just head
up the staircase, and use your pogo stick to jump up to the blocks above the
fire pit, avoiding the hazard altogether.  Head into the light and say hi to
another glowing Yorp statue.

		A message echoes in your head:

		The teleporter in the ice will take you
		to the dark side of Mars.

	Cool beans, I guess we should get there as fast as possible!

	So the goal is the teleporter and Emerald Stands in the way.  Only one
thing to do:  Go through it!

	EMERALD CITY*:  So here we are in the beautiful greenhouse that is
Emerald City.  This level is large and open, and there are many ways to go about
it so feel free to explore on your own!  As you start out you'll find a nice
line of delicious Lollipops heading down.  As Admiral Ackbar might say, "It's a
trap!"  A pit of spikes wait directly below you so make sure if you fall down,
you do so to the right.  An easier thing to do is jump up to the blue bridge
above you.  After collecting the Lollipops that spell HI in the Standard
Galactic Alphabet, head up and to the left.  Once you see the Raygun, collect it
and head right.  Watch out for the green Strangling Vines!  They'll make quick
work of you (as the DIE sign may have implied)!  Once the purple platforms fork,
head on the upper path toward the red platform.  Watch out for the Garg that
guards the platform and...wow!  You're already at the exit.  Head up and to the
left for an easy Teddy Bear guarded by just one Garg.  If you feel like
exploring and grabbing more goodies be my guest, I'll be here when you get back.
Just watch out for both the Garg that hides in the yellow tunnel and the Tank
Robot that patrol the lower path!

	Alright!  We've made it to the teleporter!  It's time to head to the
dark side of Mars, a place where the levels are bigger, more complicated, and
more deadly!  First of all, we still need to collect ship parts so put on your
winter jacket and head right into Ice City.

	ICE CITY: Brr...it's freezing in here, why is Commander Keen still just
wearing a t-shirt?!  No matter, he's a trooper and he has a mission to complete.
Patrolled mostly by robots (and a couple of Book-guarding Gargs), this place may
be the first true test of your platforming skills.  There are two distinct paths
you can take in this city, and we're going to hit both of them.  First of all
head left, mind the slippery bridge!  Grab the slice of Pizza if you're so
inclined.  Oh look!  A Snow Yorp!  Walk past it and jump up on the snowy
platform.  Head straight and up and you'll soon find yourself in a small tower
with Soda on alternating sides (beginning with the right side).  Once you've had
all the Soda that you can handle you'll find two Tank Robots guarding a Red
Keycard.  Now if you're feeling brave you can rush the robots and grab the
Keycard, if not, don't worry, there's an easier way.
	Assuming you've grabbed the Keycard, you can now go left and fall
through the gap, collecting a bevy of Lollipops, or you can go right to finish
the level.  I'm going to assume the former.  If you decided to not yet go for
the Keycard, go back to the Snow Yorp, we'll be there soon!  After falling down
the gap, pogo up to the snow-covered platform and over to the left side of the
Ice Cannon (grab the Pizza if you'd like, but mind the crack in the bridge).
Getting past the Cannon isn't too tricky, you just need to time it so that you
don't accidentally run into one of its shots.  Getting frozen in this case will
mean sure death.  Alright!  We're back at the Snow Yorp!  Go back to the bridge
but this time pogo upwards.  Work your way up (grabbing the Books and Sodas if
you so desire) until you get to the column of blue cylinders and a Lollipop
covered stairway.  If you go down the stairs you can reach a Raygun and Teddy
Bear, but it's a dangerous path guarded by two Ice Cannons and a Tank Robot that
I can't recommend.  Whichever path you choose, work your way up the cylinders
until you reach the top.  If you haven't got the Red Keycard yet, head left and
pick it up (I told you it'd be easier this way!), whilst all Keycard holders
should go right, taking a slippery ice-type conveyer belt down to the Vorticon.
Roast him and get your prize: the Vacuum Cleaner!  After that, it's straight to
the exit.

	So, we've now got three out of four Ship Parts.  If you're a party-
pooper you can now head all the way down and to the left to finish the game at
the Vorticon Commander's Castle, however if you want to savour the game, head
with me now to the First Ice Shrine.

	FIRST ICE SHRINE*: Hey a shrine that starts outside!  Looks like we need
to first head up to get a Yellow Keycard to get inside.  Once you've gotten to
the ice structure, the safest way to go is on the left side (avoiding getting
pushed off by the Butler Robot), staying above the Tank Robot and grabbing the
Yellow Keycard in the upper-right corner of the structure.
	Go back the way you came and get down to the bottom and make your way to
the Yellow Door on the right.  You're now in the shrine proper.  Grab the Book
and work your way up (grabbing another book) until you find yourself at another
glowing Yorp statue.

		You see these words in your head:

		You will need a Raygun in the end, but
		not to shoot the Vorticon...

	Hmm, that's slightly cryptic.  Oh well, we still have a ways to go until
the end so hit the exit and we'll power on through!

	Next on the docket we've got three shrines to hit, so let's get going!

	THIRD RED ROCK SHRINE*: Once again a shrine level that starts outside of
the shrine itself.  Head right and then up the blue blocks, grabbing Lollipops
as you head up.  Once you finally make it to the top it's time to jump left.
Hug the grey block wall as you fall and you'll grab the Yellow Keycard.
	Head through the Yellow Door and work your way through the shrine, past
the tricky fire jump (it'd also be a good idea to take out that Garg to grab the
books that he's guarding), and up to the glowing Yorp statue.

		A voice buzzes in your mind:

		There is a hidden city.  Look in the
		dark area of the city to the south.

	Worried about finding it?  Don't be, I'll lead you right there!  Ok,
time to get going.

	Ok, now that we've finished that shrine, it's time to head right to the
next one!

	FORTH RED ROCK SHRINE*: The only thing to worry about here is a few
tricky jumps.  From the beginning head right, over the Garg's head, into the
structure.  Get past the fire pit and climb up, grabbing first the Book and then
the Teddy Bear.  Work your way to the left, over the fire and up to...what's
this?  A glowing GARG statue?!!!!

		You hear in your mind:

		GAAARRRRRGG!

	Well, that was weird, let's get out of here!

	After escaping that nut house, head to the left again and enter the
final Red Rock Shrine.  The end is near!

	FIFTH RED ROCK SHRINE*: Alright!  Goodies!  If you feel like boosting
your score, head straight up at the beginning and grab some Soda and Lollipops!
Don't worry, nothing up there can hurt you.  Once you've had your fill, head to
the right and into the shrine.  Avoid the Garg and work your way up.  Hey, what
do you know?  It's another glowing Yorp statue!

		A Yorpish whisper says:

		Look for dark, hidden bricks.  You can
		see naught but their upper left corner.

	Sweet!  But we already discussed those hidden bricks.  Well, time to
take the exit on out...

	Well, it's time to take on the craziness of Red Maze City.  We'll
actually be tackling it twice as through here is the entrance to Secret City!
Right and down and hold on tight!

	RED MAZE CITY, FIRST VISIT:  Now this is what I'm talking about!  Head
up and grab the three (!) Rayguns that'll arm you for this adventure.  There are
two things to worry about in this level.  First, as the name implies, it's a
maze, second, there are yellow tunnels that Gargs like to hide in.  If you ever
come upon a yellow tunnel, shoot first and ask questions later!  After grabbing
those Rayguns head right and down the second hole (the one with two cylinders
stacked on top of each other).  Kill the Garg and head up.  Ah!!!  A yellow
tunnel!  (Actually, this one is safe to travel through).  Continue upward and
go through the next yellow tunnel as well (also safe).  Head to the right and
then go up as far as you can.  Head right and drop down two levels, until you
are presented with the choice of dropping left or dropping right.  Go right and
fall down as far as you can, working your way left and right until you hit the
bottom.  You should now be able to see darkness below a layer of red bricks.
Head right.  You see that gap full of fire?  You're going to be dropping in
there.  You'll probably be able to see two levels of fire (though you can
probably only glimpse the tips of the second level of fire).  Jump down, pass
the two levels of fire, then take a hard right while falling to avoid a flame
that awaits straight below.  What the heck?  An Ice Cannon?!  That machine is
the goal.  If you look carefully, there is a hidden brick against the red brick
wall.  Pogo onto it and jump over to the top of the blue brick wall.  Now here's
the hard part, you need to get over to the right side of the Ice Cannon, and
then pogo into its shots at an angle in order to be vaulted over the other blue
brick wall.  Easier said than done, and even if you make it over, there's still
a Tank Robot you need to worry about (though if a robot's shot hits you while
frozen, you'll just be melted out).  If all goes according to plan, get out of
the Tank Robot's little room and head right, grab the Teddy Bear and enter the
mysterious teleporter!

	Whoa, what the?  We're back out on Mars, and there's the Secret City
right in front of us!

	SECRET CITY: Points galore!  It's time to grab some stuff!  This place
is heavy on point items and light on enemies, so it's a good place to stock up
on extra lives!  I'll give a simplified route that skips some of the point
items, so if you feel like exploring on your own just know that you need to get
to the upper-left corner of the map to exit.  Ok, here we go!  First of all,
head over to the right, avoiding the spikey pit and getting past the Yorps.
Jump over the small wall made of red bricks and jump over that fire pit.  Now
you need to head up through that gap and go up the stairway-like set of red
bricks.  Grab the two Soda cans (and go up for some Pizza if you'd like) and
jump up and to the left into the gap.  Follow the path, grabbing some Lollipops,
and once you've made it to the top of the bridge-like structure jump up and out.
Once out of there, head up one level.  You now see that there are three paths.
The right path leads to a Book guarded by a Garg.  Straight up, next to the path
with Lollipops, is a path that is difficult to navigate, but rewards you with 6
Teddy Bears (that's one-and-a-half lives)!  The left path leads to the exit, so
that's where we're headed now (but feel free to grab some points before heading
that way).  Work your way up, grabbing the Lollipops (and a Book in the upper-
right).  Once you make it to the top, jump down on top of the Strangling Vines,
avoid the Yorps, and zap that Garg who is guarding two Teddy Bears.  Now head
left, collecting the two other Teddy Bears above that big fire pit if you wish
(though it can be a little difficult to get out) and stop.  You see three
columns heading down.  The first two lead down back near the beginning so you
probably don't want to fall there.  The third one (with a constant column of
Lollipops) does, but you need to hold LEFT while falling to avoid being killed
by a Garg at the bottom.  If that's too scary for you, you can go as far left as
possible and jump into larger space.  Whichever way you take, as you fall down
toward the exit keep left.  There's a large pile of Teddy Bears to reward your
actions!  Well that was great.  Head into the exit and get out of here!

	Time to head into that teleporter and take our second visit to the Red
Maze City, this time to finish it!

	RED MAZE CITY, SECOND VISIT: Ok, head up and grab those Rayguns again.
We're going to start off much in the same way we did last time, but we have a
few more pitstops on the way.  So head right and drop down the second hole.
Get past that Garg and head up and through the two yellow tunnels, then make
your way up and to the right until you can't go any higher up.  Drop two levels
and you'll find yourself once again at the place where you went right and down
to go to Secret City.  This time, you need to first head left and down.  Make
sure, though, that you hug the wall on the right!  You are now in a small,
circular room with the Blue Keycard.  Grab that Keycard, head back up, and now
go to the right and down, heading back toward the secret teleporter.
	You will soon find yourself back at the fiery hole that leads to both
darkness and the teleporter.  This time jump over the gap and head right.  Watch
out!  There are two Gargs waiting to make a quick meal of you.  After dealing
with them head as far right as you can and snag that Yellow Keycard.
	Now we're rolling along!  Work your way back up to the fork in the road
between the two Keycards.  Instead up heading up and to the left, where you
originally came from, go up and to the right.  Go up as high as you can, and
then head right skipping the first small pit (the one that the Garg probably
just walked into) and heading down the second.  Passing the three red cylinders,
keep left and go back down as far as you can.  Head right and you'll find
another two Gargs guarding a Keycard, this time the Red one!  Grab it and head
back the way you came.
	Going back up, keep right as much as possible.  You should soon run into
two yellow tunnels.  Watch out!  These ones are infested by a Garg!  Take a shot
and then from the tunnels head up and to the right.  The Green Keycard!
	Finally, head down from the Keycard, keeping right.  You'll soon find
yourself at one more yellow tunnel and from there the Doors and exit.  You've
made it through the maze in one piece!

	Alright, from here the only way we can go is down.  Next stop: the
Second Ice Shrine.

	SECOND ICE SHRINE*: Well this is an easy level, you just have to walk...
Oh wait.  It was definitely a trick.  Looks like there's more to do in this one!
Well, the first order of the day would be to grab the Blue Keycard on the left,
it'll be important!  Now head right, past the Green Door.  Oh look, a Book!  Be
warned that below that book is a fall-through brick.  Hold RIGHT after grabbing
it or you'll probably be making a one-way trip into a Garg's mouth!  Continue
right and when presented with the three paths of purple bricks, choose the upper
one (though you might want to wait for the Garg to fall down first).  Walk along
it and right into the Blue Door.  It seems like a simple task grabbing that Red
Keycard but another one of those annoying fall-through bricks sits in front of
it.  Grab the Keycard and fall through to the level below.
	Now, that Teddy Bear there may be tempting but (not surprisingly) there
are fall-through bricks below it as well.  Head up, grabbing the Soda on your
way, and go right.  Snag as many goodies as your heart desires and head up and
right to the Red Door.  Another fall-through brick awaits you next to the Green
Keycard so be careful!  Grab the Keycard and jump up to the blue brick path,
heading left.
	Avoid the Butler Robots and (more importantly) the Tank Robot until
you've gone as far left as possible.  Right now you may be saying, "Hey wait!
What about the Green Door and the Yellow Keycard?"  As with many things in this
level, it's a trick, there is no Yellow Door!  Jump up and head back to the
right, eventually falling down a gap.  Hey!  We've finally made it to the
entrance of the shrine proper!  Make your way up past the fire and touch the
last glowing Yorp statue that we'll see.

		A Yorpy mind-thought bellows:

		You cannot kill the Vorticon Commander
		directly.

	A bit of an exaggeration (he will die after being shot 105 times), but
close enough to the truth.  Time to get out of here and head to the Vorticon
Commander's Castle!

	So here we are, only one level left.  Let's not delay, get in there!

	VORTICON COMMANDER'S CASTLE: Alright, time to get moving!  Head right
past the drawbridge and into the Castle.  As you walk by the grey columns, stop
and take a look at the third one.  Hidden bricks!  If you feel so inclined, head
up and to the left, weaving back and forth, and you will soon come to an
excellent stash of goodies, include ID written in Soda!  After you're done
stocking up, head back down to the bottom and go right.  Head up the icy stair
and keep on going up until you reach the Tank Robot guarding the Blue Keycard.
Grab the Keycard and head back down to the stairs.
	Walk a bit to the right (climb the dark tower for some more Soda) and
the pogo up through the small gap located just before the dark fall (if you miss
it, don't worry, just head right, avoiding the Butler Robots who want to push
you into fire, and up).  Head right and work your way up, through the Blue Door.
Keep moving up, past the little robot and face your adversary: The Vorticon
Commander.  Go up near him, but don't enter that cage (unless you're feeling
incredibly brave)!  Look carefully, you should be able to see a hidden brick in
the column right before the Commander's cage.  Pogo up to it and to the right.
You should now find yourself in the small gap between the roof and a huge slab
that's held up by a weak-looking chain.  Shoot the chain!  SQUISH!  Well, that
takes care of that....  Grab the Everclear (and the Teddy Bear if you want) and
head to the exit to watch the final cutscene.

	You've completed Marooned on Mars!  Congratulations!!!


[9.2] How do I get through The Earth Explodes?
	Well, here we are at the beginning of another exciting walkthrough!  Run
up into the Galley and let's get started!

	GALLEY B*: What happened to Galley A?  No idea!  Grab that HyperPistol
(THIS IS NEAT) and head straight up.  At the top of the map, make your way
right, grabbing some delicious points as you make your way toward the exit.  As
this level is so simple and hazard free, it'd also be a good idea to acquaint
yourself with how Keen moves, jumps, and pogos.  You're going to need those
skills for later!

	Well, that wasn't so hard, now was it?  Now head left and enter
Engineering B!

	ENGINEERING B*: After the long fall, it's time to head right.  Climb on
top of the blue structure and go down into the pit.  Ah!  It's a Vorticon!
Don't worry though, this guy is a Grunt, he only takes one shot before he goes
down.  Take care of him, grab that Yellow Keycard, and head back up.
	To your right there is a bonus area full of goodies protected by a Guard
Robot.  Feel free to head there, but you're on your own!  Now go up and to the
left.  Stand on the upmost red girder and ride the moving platform over to the
Yellow Door.  Pop through it and voila!  You've finished another level!

	We can't just go through Engineering B without tackling Engineering A,
now can we?!  Head right and prepare yourself for another plasma-filled
adventure!

	ENGINEERING A*: The first order of business here is to fall down to the
bottom of the level and head right.  It'd probably also be worth your time to
work your way back up the right side of the girders to grab the HyperPistol and
Stuffed Toy Vorticon.  Go right, jumping up the purple barbells, and into the
top chamber.  Here you'll find the Green Keycard, but how to reach it?  You'll
need to pogo from the right-most blue brick.  You can use the Scrub to get a
little higher (or just shoot him if he's bothering you).  After grabbing the
Keycard, head out of the little chamber and go up to the right.
	After getting to the green barrels you need to head left (taking care of
that Grunt) and then go up a level and work your way back right.  Go through
that Green Door and head out the exit!

	Ok, enough fooling around, it's time to save some cities!  Head up and
to the left.  The first target city that we're going to save will be foggy ol'
London.

	LONDON TANTALUS RAY*: Head right, but before you get the Vorta-Cola,
stand on top of it (that's a neat trick!) and pogo up to grab a HyperPistol that
would otherwise be just out of reach.  Keep going right.  Your goal here is to
release a Scrub (which you can also stand on) in order to make it up the tube at
the beginning of the level (with the white GO UP sign).  The first Scrub that
you encounter would make an excellent candidate so take the first two columns of
Vorta Cola and watch the little red guy make his way to the left.  Once he hits
the edge up the map he'll begin to walk up it and toward the tube.  As he begins
to climb the tube, catch a lift and head right.  Once on top, pop over to the
left and push that lightswitch.  Wise Vorticons don't jump in the dark, so it'll
make your going a little bit easier.  After plunging the station in darkness,
head to the right, working your way down (avoid the pit with the Guard Robot)
into the small gap.  You've reached the first Tantalus Ray!  Avoid the Vorticon
Elite that'll come after you (at least you've gotten rid of his jumping ability)
and go up to the machine.  That purple thing up there is your target (it's
actually part of the Big Purple Space Amoeba).  Activate your pogo (but not too
close to the machine or you'll activate it and destroy the world) and shoot at
that amoeba.  Blammo!  One Tantalus Ray down, seven to go!  Head up and to the
right and work your way down, collecting your Stuffed Toy Vorticon for a job
well done before leaving through the exit.

	No stopping now!  Head right and stop Cairo from being destroyed!

	CAIRO TANTALUS RAY*: This level is fairly linear, it is also fairly
danger free, as long as you can avoid being beat up by the Youths who are
tearing through the place.  Once you make it to the fiery pit, you can go down
and grab some more goodies (guarded by a pair of Grunts), or just skip it and
head to the right.  As you work your way right, make sure that you grab that
HyperPistol!  You're going to need it in your upcoming fight with a Vorticon
Elite!  Head right, there's no darkness to protect you this time!  Avoid the
Elite's shots and hit him three times to take him out.  Once he's been taken
care of, shoot at the Amoeba powering the Tantalus Ray and head out of there.
Cairo has been saved!  Don't forget your Stuffed Toy Vorticon on the way out!

	So far it hasn't been so bad, two Tantalus Rays down and not so much as
a bead of sweat on the brow!  Our work is down here so head back to the middle
and up until...great.  The way is blocked by the doors to the Reactor Core.
Looks like there's no choice but to go through it.

	REACTOR CORE*: Head right and grab that HyperPistol and then make your
way down and...whoa.  Who turned out the lights?  No matter, visibility isn't
too bad down here.  Grab that tempting Stuffed Toy Vorticon and head on down to
the bottom.  Watch out for the Grunt, and flick the switch to make a bridge over
that deadly pool of plasma.  Head up right after the bridge to find a hidden
cache of Stuffed Toy Vorticons.  Sweet!  After having your fun with them, head
back down and to the right.  Now all that's left is a simple (yet annoying)
climb through a scrub-filled tower (if they're really bothering you, you can
take the bridge out from under them, plunging them to a plasma-filled doom) and
finally up past a Grunt into the exit.

	It's time to stock up!  Head left from the core and down into Home A.
Prepare to meet more Vorticons than you've ever before seen!

	HOME A: Grab that HyperPistol and check your trigger finger, there's
some killing to do!  Head right, taking out the two Grunts that stand in your
way.  Work your way down.  You will soon come to the nursery.  It's full of some
incredibly annoying Youths, but it's also full of Stuffed Toy Vorticons.  You're
probably going to waste a lot of shots getting out of there, so it'll be a good
idea to get some more.  Head right from the nursery and you'll find yourself at
a small armory filled with HyperPistols and guarded by three Vorticon Elite.
Take as much ammo as you dare and keep heading right and down.  What's that
strange thing encased in glass?  It's a Vorticon Elder!  Remove his guard and
walk up to him to hear what he has to say.

		The Elder Vorticon in the stasis field
		says:
		The wise Vorticon never jumps in the
		dark.  In fact, even unwise Vorticons
		will not jump in darkness.

	Good to know!  Well, now that we've milked the old guy for information,
head up and to the right.  Pogo from the second-highest blue platform to make it
over and through to the exit.  You'll notice that we skipped a room full of
point items.  Unfortunately it's protected by three Guard Robots and is probably
way more trouble than it's worth, just cut your losses and get out with your
skin!

	Ok, time to save New York (Go Yankees)!  Head up and to the left and
jump in feet-first.

	NEW YORK TANTALUS RAY*: This level can be particularly hard.  Especially
since there is a large group of Vorticon Elite guarding the machine and no
lightswitch to keep them from jumping.  From the entrance head to the right,
staying on the middle path.  Avoid the Scrubs and grab the HyperPistol above the
glass window.  Keep going right until you find yourself above another window.
You see that blue platform right above you just out of reach?  You want to use
the Scrub that's merrily walking along below you as a base to get up there.
Hoping that he doesn't get blasted away by the crazy Vorticon Elite below, get
up there (making sure to avoid the Guard Robot) and fall down the small gap next
to the white sign.  Blast the Space Amoeba and get out of there before the
Elites realize that they've been had!  As usual there's a Stuffed Toy Vorticon
waiting to reward your trouble.

	With that out of the way, head over to the right.  We've got two more
cities to save and another Home to visit before heading up towards the endgame.
First stop: Sydney Tantalus Ray!

	SYDNEY TANTALUS RAY*: This is actually a fairly simple level and it's
chock-full of Vorticon HyperPistols!  Great!  From the entrance, head up to the
level above you and ride the Scrub up the left wall to grab the Red Keycard.
	Be careful not to shoot him or you'll be left in an unwinnable state!
After that, head to the right and ride the other scrub up the girder wall.  Four
HyperPistols?!  Can it get any better?  After grabbing them, work your way over
to the top right where both some Cake, a HyperPistol and the Blue Keycard await
you.  Grab them all and head down to the Doors.
	After heading through the Doors you'll want to use the green blocks to
jump up to the small platform made of red blocks.  What you want to do is wait
for the Guard Robot to just pass you on the left, then jump onto his red blocks
and make a sprint for the small red platform on the right.  Whilst there, shoot
to your right.  You'll take out the Amoeba and shut down the machine.  Escape up
and away from the Vorticons, grab your Stuffed Toy, and head into the exit.

	From Sydney Tantalus Ray (or what's left of it), head up.  Two places
present themselves.  We'll be heading into Home B first.

	HOME B: Oh great, a maze.  Luckily this maze isn't nearly as big as Red
Maze City on Mars.  Start off by heading right, grabbing the HyperPistol, and
making your way up and right.  Take out that Grunt and grab the Green Keycard,
the first of four.
	Get out and walk past the dead Grunt, head down one level and go left.
You'll soon find yourself near some Vorta-Cola and, more importantly, the Yellow
Keycard.
	Go back, drop down another level, and head left for yet another Keycard,
this one the Blue one.
	Also in view is the Red Keycard.  Work your way around and grab it too.
	Excellent!  Now all Keycards are in your possession.  Head on down,
keeping right.  Soon you'll be seeing the Doors.  Head through them and drop
down to the blue platform.  Head left, taking out all Grunts that get in your
way.  Once you get to the yellow blocks, shoot the Grunt who's trapped in the
small cage-like area (he'll cause trouble it you don't) and then climb up the
blocks, descend into the cage, then climb up the other side.  Fall down, keeping
right to get a Stuffed Toy, then drop to the purple blocks above the pit of
acid.  Fall into the gap in the acid pit and head right (as well, there's a
HyperPistol on the left if you're in need of one).  Cut through those who oppose
you and say hello to another Vorticon Elder!

		The Vorticon elder says through the
		stasis field:
		The Grand Intellect is not from
		Vorticon VI--he is from the planet
		Earth.  His evil Mind-Belts control
		their minds.  They are not evil.
		Please do not shoot them, human.

	Oh, whoops.  Guess it wasn't such a good idea to go all trigger happy
on the Grunts...oh well, all's fair in love and war!  With that, we're done
here.  Head out of the pit, to the right, and through the exit.

	I suppose that maze wasn't too bad.  Anyways, it's time to save another
city!  Off to liberate Paris (right below Home B)!

	PARIS TANTALUS RAY*: Whoa, this is a weird layout!  Looks like we're
making a big loop.  Work your way up and to the left.  Look those Stuffed Toy
Vorticons!  Looks like they can't be accessed yet though.  Keep going left.  Two
Grunts guard a HyperPistol and a large string of Candy Bars indicate a drop.
Feel free to follow them, or keep to the right as you drop.  See those weird
grey funnel things in the gaps by the Grunts?  You can fall through them but
can't return that way, so make sure that you're committed before going through
one.  After that wonderful trip, head to the right.  A huge pool of plasma!  If
you want to access those Stuffed Toy Vorticons, you need to use the Scrub as a
base to jump up and to the right.  There are a whopping eight (!) Stuffed Toys
in there guarded by Guard Robot, so it might be worth it to check it out.  After
having your fun up there, you'll need to ride the moving platform to the other
side of the plasma pool (make sure that you time it so that the Scrub doesn't
push you off the platform to your death).  It's time for a showdown!  An Elite
and a Grunt guard the machine aimed at Paris.  Take them out to take it out!

	Alright!  Only three cities left to save!  Head back to the center of
the ship and go up and to the left.  Time to restock again, this time at
Weaponry A.

	WEAPONRY A*: Hmm, another dark level.  Look!  The Yellow Keycard!
Unfortunately it's out of reach, so we're going to need to lure a Scrub over
here to be able to grab it.  Head to the right (grabbing some delicious Vorta-
Cola), and up into the red area.  Make your way up, grab the Red Keycard, and
jump over to the blue area.
	Make your way up and to the left.  There are two Grunts with some Youths
guarding a bunch of HyperPistols and the Blue Keycard.  Take them out and grab
your items!
	If you want, you can go further left for an additional two HyperPistols.
Next stop: the green area.  Head back down into the red area and over to where
the two Vorta-Colas are stacked under the lamp.  Don't grab them!  Jump on top
(or over) them and make your way up to the green area.  Grab the Green Keycard,
and follow a Scrub as he slowly makes his way back to the beginning of the
level.  Grab the last Keycard and head back to that stack of Vorta-Colas.
	Now you can pick them up, and it's a straight course through the colored
Doors to the exit.

	Time to save Moscow.  It's directly to the right of Weaponry A (despite
what the letters above it may say).

	MOSCOW TANTALUS RAY*: First things first, hit that light switch and work
your way left.  Under the cover of darkness grab the Yellow Keycard and make
your way back to the lightswitch.
	Turn it back on and head back to where the Keycards were.  Stand next to
the platform and wait until all the Vorticon Elites have jumped up, away from
the Red Keycard.  Now head back to the lightswitch (last time, I promise!) and
turn off the lights.  With that out of the way, head left and fall straight
through the one-way chute.  Once you hit the bottom, go left and head up to
claim the Red Keycard.
	Work your way back to the right, grab the HyperPistol, and fall down the
next pit, avoiding the acid on either side.  Go to the left, work your way up,
and then down and take out all the Grunts and Youths that stand between you and
the Doors.  After going through, work your way up and over to the machine.  Lure
the Elite over to the left so that he falls into the pit, and take out that
Space Amoeba.  After destroying the machine and claiming your Stuffed Toy
Vorticon, pull out your pogo stick and sneak past the exit door.  There's a
small gap to the right of it!  Fall down that gap while keeping left and you'll
pick up a HyperPistol and some more goodies!  Out the second exit we go!

	Almost there!  Head right to Rome and save the Colosseum!

	ROME TANTALUS RAY*: There are two ways to finish this level.  If you are
very impatient (and skilled) just head left from the beginning, avoid the Guard
Robot, jump up through the gap in the floor into a room full of Vorticon Elites,
and escape up to the exit (make sure that you destroy the Tantalus Ray before
leaving or you'll be stuck in an unwinnable position)!  However, I'm going to
assume you want to go the more reasonable way.  From the entrance head right,
avoid the Vorta-Colas (taking them will slow you down), and ride a Scrub up the
blue wall.  Grab the HyperPistol and points on your right and then get over to
the acid pit on the left.  Ride the moving platform across the pit and then go
up to the next level, heading all the way to the right side of the map.  Once
you've gotten to the other side, head down and to the left.  Avoid pulling the
lever for a moment and head down to turn off the lightswitch.  With that down,
go back to the lever a create a bridge to easily cross the pit of plasma.  Jump
up to grab the Stuffed Toy Vorticon and then make your way a bit farther to the
left to encounter the evil Space Amoeba!  Take it out.  And make your way to the
left, up the blue platform (avoiding the fire above), and out the exit.

	Before we finish saving the world, let's take a pitstop in Weaponry B.

	WEAPONRY B*: Hey, that's a nice change of background!  Too bad that this
is one of the most difficult levels in the game...  Head right, and wait at the
end of the girder.  A moving platform should soon be there to pick you up.  Jump
on it and work your way down and right, from platform to platform.  To the right
of the acid pit you'll find a huge stash of HyperPistols.  Just work your way
over and down, taking out any Grunts that dare stand in your path.  There is
also a Guard Robot protecting four Stuffed Toys if extra lives are your thing.
Once you've finished collecting all you need, head back up and to the left.  You
need to take the moving platform that serves the middle (one tile) platform.
While on it, keep going left until you reach the long string of Candy Bars.
Drop down that pit and then head right.  Follow the Grunt you see down into the
pit, head right and then go over the girder wall.  Drop down until you see the
long horizontal line of Candy Bars and go left (you can go right if you want,
but it'll eventually dead-end into a very angry Vorticon Elite).  Grab the
HyperPistol and drop straight down.  You'll land on the platform that sits
precariously above the plasma pool.  Work your way right (grabbing the
Hamburgers as you go) and you'll very soon find yourself at the exit.

	Well, that's it!  Time to turn this of the Tantalus Rays for good!  Head
left and up into Washington, D.C.

	WASHINGTON, D.C. TANTALUS RAY*: So here we are, the final battle.  Jump
up and turn off those lights!  Grab some HyperPistols and get up onto the red
platforms.  There will be three Vorticon Elites hunting you down, but as long as
you stay above them, you'll be safe.  Head right and eventually you'll get to a
point where there will be another small row of red platforms one tile below the
others.  Don't go down there, but wait right before it and the three Elites will
fall on the right to their doom.  After that, make a tricky jump over to the
right and go up.  You'll find a Stuffed Toy Vorticon and a lever (that you
should pull).  Go across your newly created bridge and wait at the edge.  Soon,
a moving platform will come for you.  Get on that moving platform (don't worry
about the Red Keycard as there's is no Red Door) and get up to the level above
as soon as you can.  Go right and work your way up, avoiding the Guard Robot,
and snagging the Blue Keycard from the Grunt.
	Go back down and jump onto the moving platform as it heads left.  Go
through the Blue Door and pull the switch.  A small bridge has been created!
Get back on that moving platform and head right, again jumping onto the cyan
blocks once you reach them.  Hope your Scrub-riding skills are up to snuff
because they're about to be put to the test!  Ride the Scrub up the wall that
he's walking on, and then leap over to the bridge that you've just created.
From there ride ANOTHER Scrub up THAT wall (avoiding the hazard at the top), and
jump on the small platform that is two tiles wide.  Pogo up to the left and drop
down.  It's the Green Keycard!  Grab it and go back up.
	Get on the moving platform and pogo up through the gap when it reaches
the right wall.  Walk toward the Green Door (make sure that the lights are still
off!) and drop down the gap.  Lure the four Elites into the small pit on the
left.  You're home free!  Take out the last Tantalus Ray and head right.  Once
again there are two exits, this time with two paths to get there!  As the game
will be over, we want points, so activate your pogo, get to the right side of
the exit, and drop down, hold LEFT to grab some wonderful Stuffed Toy Vorticons!
Head out of the exit and into history.

	That's it!  The Earth is saved!  Enjoy the cutscene and write your name
with pride on the High Score list!


[9.3] How do I get through Keen Must Die!?
	Commander Keen begins his adventure on the Island of Vortiville.  You'll
find in this walkthrough that I'll guide you through every city on Vorticon VI.
This generally isn't how you'd play the game, so feel free to use the map from
Section [8.3], plan your route, and use this walkthrough as your adventure
guide.  As it is though, we've got to get going!  Run up to the first city (the
walled one) and let's find out the secret of the Grand Intellect!

	LOWER VORTIVILLE: Welcome to Lower Vortiville!  Scare the Foob half to
death (run into him to finish the job) and grab the chocolate bars and ammo as
you head right.  Take the first elevator up to the third floor.  It contains
more ammo, which is a precious resource at this point in the game.  Go back
down, then head up to the top of the adjacent building, get even more
ammunition, and jump off toward the next one.  You'll now be faced with a
bizarre, green, one-way barrier.  Both you and your shots can only go one way
through it (in the direction indicated by the arrow).  Jump through the barrier
and head over to the next building.  Go up to this fourth building's top level,
grab the Pistol and ammo, and then head out through the first floor and into the
final building, climbing it and going out the exit.

	Right beside Lower Vortiville we have Vortiville, guess where we're
going next?

	VORTIVILLE: What a nice place!  Scare off another Foob, avoid the
stranded fish, and head right.  Pogo up near the waterfall and jump up to the
red platforms.  Grab the Pistol and head right, filling up on Burgers.  Once you
get to the end of the platform, jump off to the right (watch out for the pit
straight below!) and head into the house.  Make your way right, avoiding (or
killing) the Grunt, Woman, and Youths, and if you're so inclined sack it for
loot and out into the garage.  Go out through the loft and into the exit.

	Alright!  Time to go exploring.  Jump into the teleporter right above
you and you'll find yourself in the other part of the Island of Vortiville.
There are two settlements here, and we'll be tackling the smaller one first.

	WEST VORTIVILLE: Cool!  A house built into a hill!  Head to the right
and up as you begin your exploration of West Vortiville.  As you near the big
yellow sign you may notice that the cloud on your left is bigger than some of
the others.  This is a special cloud that you can stand on!  Pogo over to it and
keep going left.  There's a Stuffed Toy VortiNinja!  Grab it and the ammo and
walk back up the hill.  Go into the first entrance on the other side of the hill
and make your way underground.  Once down there, head left to grab a Pistol and
the Green Keycard, and then head right to drop even deeper down.
	Quickly head left through the one-way barrier and make the loop.  Coming
out the one-way barrier at the bottom, you've come face-to-face with a
VortiNinja!  You can choose to take him out with the pistol (which will waste
four shots) or you can pick up the Ankh and be invincible for ten seconds.
Whichever way you choose, get past the VortiNinja and to the exit.

	That leaves just one more city on the island of Vortiville.  We're just
cruising here!

	VALDEN PARK*: Here we are, deep in suburbia.  Make your way to the
right, jumping on top of the first building to stock up on ammo.  Make your way
up the second building but beware the Vorticon Woman!  She takes quite a bit to
take down!  Climb out the roof and into the clouds.  Make your way right through
the clouds over to the tall building, and drop down with all the Candy Bars and
work your way up the right side of the next building.  Jump into the clouds
again and grab some more ammo.  Jump off to the right and take a nice stroll
through the park itself, but watch out for the Meep's singing voice!  It's
deadly!  Keep going right until you reach the waterfall.  Jump INTO the
waterfall and enter the secret base below.  Head left, arm yourself, and the go
right (or keep going left if you want to have the fight of your life with
multiple VortiNinjas) until you can jump up and grab the Red Keycard (watch out
for the shots coming from that pistol).
	Head left again, jump back up the waterfall, through the Red Door, and
out the exit.

	Awesome!  You've completed the Island of Vortiville!  With that done,
head back down into the teleporter that you first used and then jump into the
teleporter that lies next to Lower Vortivile.  You suddenly find yourself on
New Vorticon Island, with the city of New Vorticon lying in front of you.

	NEW VORTICON: Welcome to downtown New Vorticon, the biggest settlement
on the planet.  Head right through the building and into Central Park.  If you
want a huge fight with Grunts and Vorticon Women, head down into the subway.
Otherwise, head right into the apartment complex and try not to get lost as you
make your way through it.  Head up and to the right as much as possible and you
should be able to find the a path through the roof.  Collect all of the items
that you come upon, and watch out for Vorticons!  Once on the roof, either jump
to the top of the next building and pogo over the pool, or fall down between the
buildings and walk right.  The next two buildings are full of goodies but also
full of Vorticons.  Attack them at your own discretion, but beware the Vorticon
Women!  Once you've finished plundering the homes, head out the exit at the
bottom right.

	Well there goes the main city, time to tackle the suburbs!  Head into
the teleporter that you just unlocked, and then teleport again once you reach
your destination.  You'll notice that few of the teleporters loop back and forth
here on Vorticon VI, but it can sometimes be a useful way to get around!  Since
we've just popped out next to Beens, we'll tackle it first.

	BEENS: Head right, past the Grunt and the stranded fish.  If you need
it, you can get some ammo up in the sky above the first building.  Keep heading
right and you'll soon find yourself in the second building.  Rob the place blind
and keep going right.  Now, if you perform the Impossible Pogo Trick from the
exit of the second building you'll be able to get on top of the school, grabbing
some ammo and making your trip life a bit easier by avoiding a Vorticon Woman
and a bunch of Youths.  Fall off of the school (there are a lot of stranded fish
nearby, and you don't want to be landing on any of them) and head to the right.
Eventually you'll get to the city's edge and the only direction you'll be able
to head is down.  Go down there and start making your way left.  At first it'll
be easy, with just a few Grunts guarding some ammo and points but watch out!  As
it opens up to the left you'll encounter both a VortiNinja and a Vorticon Woman!
The brown platform is your warning.  You also have to watch out for a jumping
Grunt below!  Keep your wits about you, and you'll be able to safely make it
through the exit.

	That end bit may have been crazy, but we still have two more suburbs to
visit here on New Vorticon Island!  The next one is down below, The Bonks.

	THE BONKS: Here's a nice small place guarded by a few Grunts.  Make your
way right, going into the guard tower if you only desperately need ammo and
points, and over to the nursery.  Though you won't be killed by anything in the
nursery, if you enter it you're probably going to get beat up pretty bad by the
Youths and Jack Balls.  But hey, sometimes Double Chocolate Cake is worth it,
right?  After passing (through) the nursery, get carefully past the small
volcanoes and pogo up to the exit.

	Only one city remains on this island, so without further ado...

	HAL'S KITCHEN: Prepared for Hell?  (Oh wait, no, it's Hal, isn't it...)
One enormous building is all that awaits you in Hal's Kitchen.  Due to level
design errors, a good chunk of this place isn't accessible.  As such, I'll just
give you a quick route through the building.  First head into the building and
immediately go up until you reach the Burger.  From there, pop down one level
and then head up to the right.  From here you want to work your way downward
while keeping right.  You'll soon find yourself at the elevator shaft.  Take the
elevator up, and then head right over the dangerous spikes and out.  Fall down
and keep right while making your way down as much as possible until you make it
to the desk.  From the desk, take the elevator and begin to go up and to the
right.  Once you see a long string of Candy Bars, you'll know that the exit is
near.  Fall down, grabbing as many as you can, and then fall again to the right,
getting the Cola.  When it comes time to drop into the dark grey area, keep
right to avoid deadly spikes below.  Finally!  We've made it out of the maze!
Head into the exit and get out of this crazy place!

	With the Island of New Vorticon finished, it's time to head to the
Vorticon Military Installation!  Get into the teleporter right above Hal's
Kitchen, and then head to the teleporter on your left after reaching your first
destination.  The Vorticon Military Installation!  Head into the closest fort
and we're off again!

	FORT VORTICON: Head straight down into the waterfall, grab some goodies,
and head into the one-way barrier.  Watch out for the opened radioactive barrels
down here!  Someone has been very careless!  Grab the Stuffed Toy VortiNinja,
go left through the next barrier, and snag the Yellow Keycard down below.
	Now, jump up through the red sealed radioactive barrels, and head back
the way you came, up and to the right.  Jump out of the waterfall and head left.
Skip the first hole in the ground and then fall down the second shaft.  And
fall.  And fall.  Once you finally reach the bottom, it's time to work your way
back up.  Carefully use the elevators and girders to get past the laser grid
that protects the interior of this installation.  Once you finally make it to
the top, head through the one-way barrier and begin to head downward.  Be warned
that those lasers that caused so much trouble while you were heading up will
also cause trouble as you go down!  Avoid the lasers and fall down next to the
pool.  Get your trigger finger ready, because this pool is infested with Youths
who would just love to knock you off the moving platform as you head right to
the other side (though, if you're lucky they won't bother you at all).  Once
you've made it safely over, head through the Yellow Door and into the deep abyss
below.  Head down, take care of the Grunt and head down and to the right, there
you'll find a trove of six Stuffed Toys.  Go back up and head left, working your
way down and to the left (you can ignore the Blue Keycard as you won't be
needing it).  Go through the one-way barrier and grab the Red Keycard, but don't
yet use the Red Door!
	Head right, shooting the Grunts as you go, and you'll soon see the very
necessary Green Key.  Grab it and head to the left and down.
	Make your way through the Red Door and follow the linear path to the
exit, taking out all that might stand in your way.

	Our next target it the walled city to the north, Fort Cavort.

	FORT CAVORT: Get out of that tree and head left until you reach the
shaft.  Drop down into the missile silo and head left, taking care of the two
Grunts.  Climb up the barrels (watch out for the laser shooting onto the top
one!) and grab that Yellow Keycard.
	Drop down and head right and up the elevator.  This time there will be
no avoiding those Youths playing in the water, but you may be able to shoot them
from the other side of the barrier to avoid certain death (though if you wait a
little while they'll probably jump out the Yellow Door to the other side).
After you're done, make your away across the pool and jump down to the right
side.  From here, snipe all the Vorticons that menace you.  Grab the Blue
Keycard, go through the Door, and wait.
	You're going to need perfect timing to get past the next part.  You need
to drop right after the guns fire and run for your life to the right, pogoing up
to the red barrels as soon as possible to avoid the next volley.  If the
VortiNinja has managed to get himself stuck up there, well, it's going to be
impossible going from here.  If not, jump up and take out that VortiNinja.  Take
the elevator up to the Ankh, but don't grab it yet!  The timing is too limited
to waste so you need to grab it as the elevator makes its way back up again.
Get the Ankh and rush past the remaining two VortiNinjas into the exit.

	Back outside in Vorticon VI, head to your right, over to Fort Vorta
Bella.

	FORT VORTA BELLA: This level is fairly difficult and not really worth
your time, but if you insist on finishing every single level here's the easiest
way to do it: First, get the pattern of the guns down.  Keep to the left side of
the map, the only safe spot is the second platform with four Candy Bars stacked
in two rows of two on it.  The Blue Keycard is at the bottom left, right in the
line of fire.
	The Blue Door is located on the opposite side, on the bottom right.  If
you by some miracle survive going across the Youth infested water, head up the
tree, grabbing all the Candy Bars that you can see, up to the exit.

	Finally we have only Fort Vox left on this part of the island.  As you
might imagine, it's no cake-walk.

	FORT VOX*: After entering, wait just one second.  Everything is
shooting!  When you're ready, start sprinting to the right and avoid all the
lasers!  Jump through the one-way barrier and keep left.  Kill the two Grunts
that guard the radioactive barrels, grab the Stuffed Toy above you, then ride
the moving platform to the left.  Grab the ammo above and get the Red Keycard.
	Head back where you came from and drop down to get through the Red Door
(ignore that exit sign, it's lying).  Meep galore!  If you desperately need
ammo, head down to the bottom to get it, though you run the risk of having a
VortiNinja lock you in.  After stocking up, head left over the Meep cages and
down to the exit.  Get out of this crazy place!

	With that finished, head back into the teleporter.  Upon arrival back at
New Vorticon, enter that same teleporter, and upon arrival enter it again.  You
now find yourself near the tip of the Vorticon Military Installation: Cape
Canavorta.

	CAPE CANAVORTA: Ah!  VortiNinja!  Start shooting until you take him out
and head right.  Ignore that Yellow Keycard and Yellow Door.  If you need ammo,
just jump up the small gap through which the laser is shooting.  Keep on right
through to the barracks.  A group of VortiNinjas will try to stop you but a
steady stream of Pistol shots will take care of them.  After passing through the
bathroom, jump up on top and grab the Ankh.  Sprint through the next building
and out to the other side.  Take the moving platform to the right, pogo up and
to the right, grabbing another Ankh in a graceful leap.  Keep going right and
you'll find yourself visiting the brig.  Watch out for the Meeps and VortiNinjas
as you make your way left, up, and around until you finally drop down near the
exit.  This is where we say goodbye to the cape.

	With that done, we're on the homestretch.  Head into the other
teleporter.  You find yourself on the Island of The Grand Intellect.  First we
must make it through The Caves of Oblivion.

	THE CAVES OF OBLIVION: Hmm...does that sign say GO UP?  Ok then, up we
go!  Pogo up and to the right.  When it seems like you can't go any higher, use
the cloud for a little boost.  Go up and over to the right (stick to the clouds
to grab some Stuffed Toy VortiNinjas) until you reach the exit.  If you need to,
go CAREFULLY by the stalagmites and stalactites to grab some more ammo.  The
Caves is a huge labyrinth filled with few points and no way to access the exit.
Up and over, though it may seem like cheating, is the only way to get past this
obstacle!

	Well, that wasn't too hard.  Only now does the Castle of...wait.
There's a small beach here.  Let's go over and wait by the leafy greens.  Hey!
It's the legendary Messie, and she's giving you a ride!  After a while you'll
disembark next to the legendary Hidden City.  Let's check it out!

	HIDDEN CITY*: First of all, just like in The Caves of Oblivion, head up
with your pogo stick.  Head right and you'll see a school full of Youths, a
Vorticon Woman, and a complete translation of the Standard Galactic Alphabet!
Keep going to grab some Stuffed Toys and then head back to the entrance.  Now,
if you're not feeling adventurous you can just go right at the entrance and
perform the Impossible Pogo Trick to get to an early exit, but this city is full
of points and populated only by Foobs (and the Vorticons that we already met up
above)!  I recommend going down and exploring!  On the bottom level alone,
you'll find a whopping sixteen (!!!) Stuffed Toy VortiNinjas.  When you're done
exploring, head to the bottom right to get out of here.

	Once you leave Hidden City, hop back on Messie and straight to The
Castle of the Grand Intellect.  It's time to finish this!

	THE CASTLE OF THE GRAND INTELLECT:  No...  It can't be!  Mortimer
McMire!!!  Well, actually it can be, and it's time to destroy his machine.  The
first thing you need to do is jump up on the Mangling Machine's left shoulder.
The shoulders are one of the few safe spots in the room.  Much like the Tantalus
Rays in The Earth Explodes, the Mangling Machine is powered by bits of the Big
Purple Space Amoeba, and those bits must be destroyed!  From the left shoulder,
shoot the amoeba in front of you and jump up to get the one that looks like the
Machine's eye as well.  Head down to the ground, stop on the bottom-most brown
platform, and take out the lower-left amoeba.  You now have the precarious task
of runner UNDERNEATH the Mangling Machine!  The different colored bricks are
safe spots, so time your sprints to get to each one before you're squished.  On
the right side repeat the process, working your way up from the bottom.  Once
all the amoeba bits are gone, the heart of the machine is vulnerable.  Shoot it
and finish it off!

	Congratulations!  You've completed the Invasion of the Vorticons
trilogy!  Now enjoy the final cutscene and get into the High Scores!


[9.4] How do I get through Keen Dreams?
	Ah, Keen Dreams.  The Keen that never really fit in properly.  It is,
however, a very fun game so let's have at 'er!  Right in front of you is the
first level, so without any further ado, let's head in.

	HORSERADISH HILL: As this is the first level of the game, things are
fairly easy-going to start off.  Use this level to get a handle on how Keen
moves and how he tosses Flower Power.  He may also jump differently than you are
used to (and he lacks his Pogo Stick), so practice jumping too.  once you're
ready, climb up the nearby poles and head up to meet your first Tater Trooper.
Stun him  with a Flower Power and head to the right.  Grab the flower pot and
jump off to the right.  If your head overlaps the right side of the cloud you'll
pick up an extra life on your way down!  Now head as far left as you can go.
Watch out for those Carrot Couriers!  They can be annoying!  Climb up the pole
near the wall and head left over the barrier.  Stun those Tater Troopers and get
that Flower Pot.  Down Jump from the piece of wood on the left and hug the right
wall, you'll pick up a Lollipop.  Sweet!  After that just head right, avoiding
more Couriers, grab some cookies and hit the exit.

	That wasn't so bad, now was it?  From here, head down across the bridge.
Our goal is Boobus Bombs, and that's what I intend to lead you to (with a few
detours, of course).

	BRIDGE BOTTOMS:  Yuck.  Mosquitoes.  They might be useful, however!
Head as far left as you can go, to a Flower Pot.  Now look carefully, there are
two types of mosquitoes: ones with black wings and others with blue wings.  The
ones with blue wings can support your weight!  Carefully make your way up and
over to the right on the backs of the blue-winged mosquitoes.  You'll find a
huge cache of Flower Power and an extra life!  Once you've picked that up, feel
free to drop straight down, or work your way down in order to collect more
goodies.  Once at the bottom you still have a few choices.  There is an exit at
either end and some water in the middle.  If you're feeling adventurous you can
drop into the water and grab another Flower Pot on the left and/or an extra Keen
on the right!  Be careful though, these lower paths are protected by Broccolash
and Melon Lips!  Once you're finished exploring, head out to the exit!

	Alright!  Getting past Bridge Bottoms opened up some more paths!  First
head left, we're going to hit up a water-filled level.

	RHUBARB RAPIDS: Alright!  Boobus Bombs Near!!!  From the entrance head
up, and to the left.  Watch out for the Squasher as you had over the wooden
structure.  Make your way down, and grab the Key.
	Now it's time to double back for Boobus Bombs!  Jump left across the
waterfall and climb the logs.  Get as far right as possible on the log and jump
for it!  It's a bit of a tough jump, but if you don't get it on your first try
you should probably be able to make it on your second.  Stun the Squasher and
work your way down, through the enemies (including a very scary looking
Tomatooth) and grab your first three Boobus Bombs!  Nice!  Make your way back up
and over the structure, and get over to the exit on the bottom-left side of the
waterfall.  Watch out for the water below!

	After leaving the Rapids, it's time to move left and up to visit the
Grape Grove.

	GRAPE GROVE: More Boobus Bombs!  Right on!  Head right, and sprint under
the Sour Grapes.  Holy cow!  They're screaming at you!  Keep on running right
until you get to a platform with a really low Grape.  If you feel confident in
your platforming skills, head right and leap over the gap.  Otherwise, use the
platform to jump up to the left and work your way back, up and around.  This
path has the added benefit of a decent amount of points, so it's definitely the
way I'd recommend.  Eventually though, the upper path will come to an end with a
Cookie arrow pointing down.  Head downward and continue to the right.  Jump over
the first platform that you first run into, and then run to the right past six
more grapes, and wait for them to fall and go back up.  Once that has happened,
sprint back to the left, jump on the platform, and jump across the gap before
the long-falling Sour Grape makes its way all the way back up.  Now you need to
stop and "deke-out" the next Grape.  Take one small step below it but then jump
right back to where you were.  The Sour Grape will fall, and as it begins to
float back up, run underneath it!  Continue to run to the right until you reach
the pole.  Climb it, take care of the Tater Trooper and Asparagusto, and head
right to the other pole and three more Boobus Bombs!  Descend the platforms and
head to the right to exit.

	Ok, so far, so good!  Now work your way down and to the right of Bridge
Bottoms, and head to Parsnip Pass.

	PARSNIP PASS: Oh, no Boobus Bombs this time!  Oh well.  The first order
of business is to jump up on the log to avoid Broccolash.  With that done, head
up and to the right (though collect any points that catch your eye).  When you
get to the long log with multiple enemies on it, shoot up with Flower Power to
clear a path.  Jump onto the concrete tiles and head left, but watch out for
Frenchy!  His fries will make short work of you!  Jump over to the pole that
Frenchy was guarding and grab the Key.
	Work your way right and up.  There is another Frenchy on the right.
Take him out, grab the Lollipop, and then fall on the left side of his platform,
aiming a little to the right.  You'll land on a small concrete platform with a
strange hole to the side of it.  If you wait a few seconds you'll see that a
Pink Owl lives inside!  He only sticks his head out for a second, but if you
time it properly you can use it as a platform to jump up and grab an extra life
and some mega points!  After your visit with Mr. Owl, head back up and to the
left, working your way up as easily as possible.  Get past the three Tater
Troopers and head out the Door to freedom.

	From Parsnip Pass it's a short walk up to Squash Swamp, our next
destination.

	SQUASH SWAMP: Hmm, this tall grass seems dangerous.  Indeed, it's an
excellent hiding place for Squashers, but there are Boobus Bombs to find so we
must continue onward!  Head left, avoiding the angry Squasher that patrols this
part of the swamp.  As you jump the gap, hop onto the lily pad and up past the
Broccolash to climb the pole.  From the top of the pole head right.  A pair of
Asparagusto guard three Boobus Bombs on the top lily pad so be careful!  After
collecting the bombs head left past the pole and climb the lily pads up to some
delicious Cookies!  Grab those cookies and drop down to the exit (collecting the
Flower Pot hidden in the grass before you leave, if you need it).

	Well, that does it for these areas down at the bottom.  Head back to
Bridge Bottoms and work your way up.  Head up and to the right from Horseradish
Hill, there's one more watery level (which looks very much like the last one)
that needs to be visited.

	BRUSSELS SPROUT BAY: Another small level with lily pads, head up and to
the right.  Points are found on the upper lily pads, and the exit is found in
the bottom right.  Head past the evil Broccolash, skipping the pole unless you
absolutely need to collect every available point, and head over the earthen
barrier to the right.  There are some points up high with a Broccolash and an
Asparagusto, or you can play it safe and stay down low, heading for the exit.

	Now it's time to double back and enter the mine that we passed before
and prepare yourself.  This level is a biggie!

	THE MELON MINES: Well here we are, already presented with a choice!  You
can only go right a short distance, but you'll score some Flower Power and get a
glimpse at the mysterious Magic Eyeball.  After exploring that way, head to your
left, work your way down two levels, and go right.  Jump over the gap (and watch
out for the Tater Trooper) and head right.  Stun any Tomatooth that gets too
close, wait for the Melon Lips to spit, and then sprint right to claim the
Magic Eyeball.  Sweet!  Three extra lives and eight Flower Power!  Continue down
and you'll find yourself near some tracks patrolled by some Tater Troopers.
Avoid them and head off the platform to the right.  Work your way down (watch
out for some Asparagustos at the bottom!) and climb the first pole to grab a
Key.
	If you've tired of the mines, head straight up the next pole and you'll
soon find yourself at the exit.  If you want to see where this Key will lead
you, head down the pole, deeper into the mine.  Be careful around the Melon
Carts that run along these tracks.  They'll get you safely over the radiation
but they'll also squish you into walls and push you off of cliffs.  Head to the
left and down.  After you've reached the bottom, head over to the right.  Look
out for the Tomatooths!  Keep going right and you'll find a Door.  Open it and
inside you'll find three more Boobus bombs and an extra life!  Head back the way
you came and up the pole.  Just before reaching the top of the pole, jump left.
A hidden extra life!  With that, climb up the pole and out of the level.

	Great!  We've now got enough Boobus Bombs to take out King Boobus Tuber!
However, let's not end this show early, head left into Apple Acres.

	APPLE ACRES: Boobus Bombs!  Head to your left, and up, but watch out for
Apels, they like to swing down poles and cause trouble.  As you continue left,
climb up trees to find goodies.  Once you make it to the pink pole, climb down
and explore the small cave.  You'll be rewarded with both Flower Power and an
extra life.  Climb back up the pole and jump into the tree tops.  There you'll
find lots of goodies for your enjoyment!  Make your way to the left, jumping
from pole-to-pole across the pit, over to the other side.  If you're feeling
really brave, you can jump from the bottom of the third pole (counting from the
left) over to a secret chamber on the left.  There you'll find three Boobus
Bombs, some Flower Power, and an extra life!  Above the Flower Power is a hidden
pole you can climb to get out of there.  Before you go past the pink pole to the
exit, make sure you climb up the gold one to grab three more Boobus bombs!  Once
you've got them, drop down to the left and exit.

	Just one level left before we tackle Boobus' Castle!  Head down to Spud
City and let's get started.

	SPUD CITY: Not surprisingly, this city is infested with Tater Troopers
and Frenchys.  Head left, stunning all in your path, until you get to a pole.
Climb it, and then jump on the blue mosquitoes on your right to grab some
awesome points!  After that, drop back down and head left until you get to the
pink pole.  Climb down underground, this is where most of the goodies are
hiding!  Head to the right and you'll see two rooms.  Jump up right between them
and you'll find a hidden pole!  Climb it up and you can head left to the
Lollipop.  Even better though, if you jump to the right in the gap where the
pole is, you can find a secret path heading to some very precarious Boobus
Bombs!  The way out is a secret pole on the other side of the fire, so you'd
better get across if you ever want to get out of there!  Head back to the blue
pole and get out of there (there's actually more goodies hidden down here,
including a Magic Eyeball; jump to the left once you've climbed about half-way
up the pole and you'll be on the right track, if you do go for the Eyeball, make
sure that you land only in water that has markings one the roof above).  Once
you've made it out of there, head all the way left.  Just before the exit you'll
find more mosquitoes.  If you want more Boobus Bombs (and why wouldn't you!)
head up the pole and take the upper path to the right.  After grabbing them,
head back to the left and through the exit.

	We now have all 21 Boobus Bombs that were scattered around The Land of
Tuberia!  It's time to head up and attack Boobus' fortress!

	CASTLE TUBERIA: Welcome to the outer fortress.  Head right into Castle
Tuberia, avoid the Tater Troopers, and climb the pole on the right.  Walk a
little to the left and wait underneath the grotesque faces.  They'll stick their
tongues out at you, and you can climb them!  Use the tongues for platforms and
head up the pole into the secretive area.  Stun the Frenchy and go up the right
pole (getting the Tomatooths first, of course) for an extra life and some Flower
Power.  After that, head up the left pole and to the left to get the first of
two Keys.
	Once you've gotten the Key, head back down the way you came and go left
from the tongue faces.  Watch out for the Squasher and Tater Trooper and work
your way up as high as possible, until you get to the fire.  Jump OVER the fire
and outside, falling left.  As you fall you'll snag the second of two Keys.
	Re-enter the Castle and work your way back up to the fire.  Instead of
heading left, go right this time.  There are many enemies so don't let up on
your Flower Power (you won't need it after this anyways).  As you go past the
Tomatooths and the second Door, head up the log ladder before going through the
exit.  On top of the Castle there's a great stash of lives and extra points that
will boost your score before finishing the game (use the 'I' of ID as a pole to
get the extra lives)!  Once you've collected everything up there, head back to
the right and exit.

	This is it!  The final showdown!  Go up and head to the final
confrontation.

	BOOBUS' CHAMBER: Had we only collect 12 Boobus Bombs, we would have to
be very deliberate with our shots.  However, since we have all 21, just go wild!
Begin throwing the moment you enter the chamber and before you know it, King
Boobus Tuber will be nothing more than mashed potatoes!

	Congratulations!  You've beaten Tuber and turned off the evil Dream
Machine!  Read the story's end and get your name on that High Score table!


[9.5] How do I get through Secret of the Oracle?
	Ah, Secret of the Oracle.  This is probably the most-played of all the
Commander Keen games and thus the one for which people have the fondest
memories.  Chances are, if you're reading this FAQ you've finished this Keen
game multiple times and have no need for a walkthrough.  Nevertheless, for your
pleasure and enjoyment, the walkthrough for Commander Keen 4:

	Ah, here we are in the Shadowlands.  First things first, launch into the
Bean-with-Bacon Megarocket and let's get started!

	BEAN-WITH-BACON MEGAROCKET: Wow, not much here, is there?  Spend some
time playing around with the controls, figuring out how Keen run, jumps, and
pogos.  You can come back any time to admire the Bean-with-Bacon Megarocket.  As
well, any time you run low on ammo (4 shots or less), you can return to the
Megarocket for a free Neural Stunner!

	Ok, with our practice out of the way it's time to head up and make a run
for the Border Village!

	BORDER VILLAGE: Alright!  The first real level!  First of all head left,
and practice jumping on the Bounder and using him as a platform to get sweet
candy.  Heck, you can even go for a ride if it tickles your fancy!  Once you're
done with the Bounder head into the first building.  You're in a small room with
some Shikadi Soda.  Not too interesting.  Head out and into the next building
(watch out for the Poison Slug).  This is more like it!  Take the ammo and head
down the pole into...what is this place?  A shrine to the King of the Poison
Slugs?!  Bizarre!  Head to the left, watching out for the bubbling pools of
poison.  Now it's time to head into the super-secret area!  Stand on the left
side of the second (left-most) poison pool, and perform the Impossible Pogo
Trick towards the upper-left.  Before you reach the wall, make sure you
deactivate the pogo but keep holding LEFT (this may take a bit of practice to
get right).  If you've done it right you'll find yourself climbing INTO the roof
of this underground passage!  Above you there will be a floating platform, pogo
onto it and grab the seven extra lives waiting above.  Be warned!  If this
platform drops it won't be coming back so make each jump count!  Once you've
cleaned house just head up to the right and into the exit door!

	Awesome!  We're off to a good start: one level down and a ton of extra
lives in store.  Head upwards and slip into Slug Village

	SLUG VILLAGE: Grab the Raindrops and avoid the Poison Slug as you head
to the left and down into the pit.  Once at the bottom jump right, into the
wall, and head down the secret passage that you've just discovered.  Grab the
goodies that are to be had and then out again to the left.  As you continue left
feel free to drop into the first pit to snag some treats from the evil Mad
Mushroom that guards them, and to head into the secret path in the right wall of
the seemingly-empty second pit.  Head up the pole once you get to it and head
right (or, if you must have every-single point, first follow the path to the
left), going left once you once again reach the surface.  Watch out for the blue
Lick!  He's a nasty character who'll quickly put an end to your adventure with
his fiery breath.  Keep heading left, using the Bounder to grab the goodies that
would be otherwise out of reach, and then sprint out the exit!

	Hmm, almost seems too easy, doesn't it?  Well we still have a lot of
adventuring to do, so no dilly-dallying!  Head up into the frozen wastelands of
the north, but yourself under the blue crystalline structure, and reflect upon
entering Crystalus.

	CRYSTALUS: Here we are, the first big level that we have to tackle.  It
might seem like a huge obstacle, but there's a prize waiting at the end.  What
is it?  Continue on and you'll see!  Head to the right, avoiding the hazards and
jump up onto the first platform that you see.  From here jump to the left until
you get until the diamond of Shikkers Candy Bars.  Wait here until a moving
platform shows up and take it up.  Once at the top of the lift go left (though
there are some optional points to the right, if you so desire) and head up.
Once you get up high enough to see more solid looking ground to your right with
some Three-Tooth Gum above it, head in that direction, avoid the Poison Slugs,
and drop down into the pit, keeping right.  Sweet!  The Green Gem!
	Once you've hit the bottom head to the right (through the ring of
Shikkers Candy Bars) and onto the above platform (watch out for the Mad
Mushroom).  From this platform that is now guarded by the Mushroom you need to
jump over to the left and take the moving platforms up.  If you're having
problems with the platform that keeps dropping, remember that if activate your
pogo you can jump on it without too many problems!  Once you make it to the top,
jump through the small gap above.  Hey it's the Yellow Gem!  That's our next
objective, but it'll take some work to get there.  Head up the poles, jump onto
the little platform, and head to the right and up.  Blow through the Green Door,
head to the left, and follow the path of the Shikadi Soda down to the Yellow
Gem.
	Make your way out of the pit (make sure to follow the trail of Soda
leading out or you might find yourself once again dropping down the pit that
contained the Green Gem!) and head to the left.  Jump up onto the platform once
you reach it and open the Yellow Door to snag the Red Gem!
	From here, if you have the pogo skills, jump ON TOP of the room
containing the Red Gem and follow the precarious path above to get some great
points.  Once you're done getting points, head right and once again fall down
the chute that contained the Green Gem.  Continue heading right and up to the
platform with the jumping Mad Mushroom.  This time instead of heading jumping
left from the platform, jump to the right.  Head upwards, navigating the falling
platforms, and you'll soon find yourself at the Red Door.  Go through it and
head up the pole.  Watch out for the angry Lick that will come attack you for
the intrusion!  Jump up the two falling platforms and snag your prize: the Blue
Gem!
	From getting the Gem, head back the way you came, past the platform that
holds the Mad Mushroom and drop down.  Once you've dropped down to the solid
ground below, head to the right.  Watch out for the Bird!  He'll only be
temporarily stunned by your shots, so scoot by him quickly!  Run into the Blue
Door and through the archway that presents itself.  Head right, avoiding or
stunning all enemies that you see.  Most of all don't touch that egg!  It'll
hatch another Blue Bird at the slightest disturbance!  Finally, you'll see your
first Council Member, walking around, waiting to be rescued.  Run up to him and
finish the level.  No sweat, oh guardian of wisdom!

	Ok, one down, seven to go!  Our next destination should be pretty
obvious, so head left and shiver along the Chasm of Chills.

	CHASM OF CHILLS: This place seems at first glance to be a fairly simple
one to navigate, but it holds great secrets!  First of all, grab the goodies in
front of you and drop down.  Head right, avoiding the Mad Mushroom, and make
your way to the small pits guarded by Poison Slugs.  Jump over the first pit,
but fall into the second pit, make sure you shoot down and kill the Slug before
dropping in there, though!  Jump into the wall on your right and you'll fall
down to a secret door!  Enter it and head right.  Grab some points and watch out
for the Lick, Mimrocks, and Poison Slugs!  Climb down the pole and head into the
door.  After falling and grabbing a bunch of Raindrops, catch the moving
platform back up to the beginning of the level.  This time, work your way right.
Be careful!  Keen won't grab the edge of these platforms so if you miss the jump
you'll have to work your to the left and back up the lift!  You'll eventually
make it to a platform that lets you see the grass and blue sky above.  Jump two
more platforms to the right and you'll see a Lick hopping around on the grass
above.  Shoot up to stun him and then pogo up and onto the grass (you'll have to
use The Impossible Pogo Trick to get enough height).  Continue to pogo into the
cloud above and you'll bounce right into Princess Lindsey!

		Princess Lindsey says:
		The way to the Pyramid of the Forbidden
		lies under the Pyramid of Moons.

	Thanks for the mysterious clue, Princess!  With that out of the way,
head to the right until you reach the Thundercloud at the edge of the screen,
and then jump down to make your way to the exit!

	Thankfully, we're almost out of this freezing-cold area.  Only one more
place to visit in this snow-filled area of the Shadowlands.  Time to plod down
into the Cave of the Descendents.

	CAVE OF THE DESCENDENTS: This is one dangerous cave!  From the entrance
head left and don't stop until you find yourself at the gap.  Drop down the gap
onto the moving platform and continue left to grab the Red Gem.
	There are goodies to be grabbed by continuing on to the poles, but be
warned that a Skypest patrols the area and spikes lay below.  Once you're ready
to move on, go back to the moving platform (which is almost stationary unless
you flick the switch) and drop down to the other moving platform which lies
below.  Once there go through the door and head back to the right and up.  The
gap may seem impassable but as long as you continue to hold RIGHT when you reach
it, you'll cross over with no problems.  Continue to up to the right and you'll
soon come to an evil Mimrock.  Sneak by him and jump up to the right to enter
the Red Door.  Sweet!  It's the Yellow Gem!  Grab it and head all the way back
to the gap where you snagged the Red Gem (if you'd like, continuing to the right
underneath the Red Door leads to a large amount of point-items, though the path
will eventually dead-end).
	This time instead of falling down into the gap, jump across it and head
left, heading into the arched doorway.  You've almost made it to another Council
Member, but you'll first need to navigate a treacherous route patrolled by Mad
Mushrooms!  Ascend the platforms, but make sure that you always look up to make
sure the path is clear before jumping up.  Continue to the top and you'll find
yourself at the Yellow Door and your second Council Member!  Sounds like a plan,
bearded one!

	Time to get out of this frozen wasteland, make your way down out of the
snow and stumble upon Hillville.

	HILLVILLE: Here's a simple, linear level with some secrets in the sky.
Start out by heading to the right, and waiting on the first island that lies
between the two spike pits.  Look between the trees almost directly above the
rock, and you'll see something glinting in the sun.  It's a flash of insight!
Flashes of insight can be stood on just like any normal platform, they're just
hard to see in the light!  Pogo up to it the flash and then wait until you see
the next one, a little bit above and to the left.  Continue up the hidden
flashes and you'll soon make it to a set of platforms being held up in the air
by thrusters.  First head left to collect a bunch of ammo for you Neural
Stunner, and then head to the right as far as you can.  Once you get the
Doughnuts, wait and perform the Impossible Pogo Trick to the right.  You should
land on another flash, and be able to collect the Lifewater Flask for an extra
life!  As you fall, you should land near a hill. Hey it's Princess Lindsey, back
for another visit!

		Princess Lindsey says:
		There's gear to help you swim in Three-
		Tooth Lake.  It is hidden in Miragia.

	Thanks, your highness!  From the Princess, swing down the pole and flick
the switch.  This will activate the moving platforms.  Go across the platforms
and make it to the other side of the fire, spikes, and other danger.  If you
pogo off to the right of the right-most moving platform, you should land on
another flash of insight (it's just above and to the left of the first raindrop
on the right).  Follow the flashes up to more platforms in the sky.  Up there
you'll be able to grab a Jawbreaker and an Ice Cream Cone!  Once you've finished
head right and exit Hillville.

	We're rolling now!  Head down from Hillville into the grove of pyramids.
First on the list?  Back into the Pyramid of the Moons.

	PYRAMID OF THE MOONS: From the beginning, jump over the structure and
head to the right.  Slide down the first pole you see to grab some goodies
below, climb back up, and then repeat at the next pole you come to.  Watch out
for those dart shooters!  They'll make a quick end to your trip!  After coming
out of the second pit head left and go down the first pole into that little area
with a door.  Grab the candy and then stand on the moon for a few seconds.
Hilarious!  With that Easter Egg out of the way, head into the door.  You'll now
find yourself standing on a platform high in the air.  Head to your right and
jump onto the moving platform, from the moving platform jump over to the Yellow
Gem and pogo back up again.
	Return through the door by which you entered and head back up the pole.
Head left, skip the first two poles that you come to, and drop down the third
one.  You should now find yourself in another small chamber with a door.  Enter
that door and you'll find yourself in a big room filled with dart shooters and
Inchworms.  Run over to the right and you'll reach the Yellow Door.  Open it up
and flick the switch inside.  Remember how Princess Lindsey said something about
the way to the Pyramid of the Forbidden being under the Pyramid of the Moons?
Well it turns out that we're in the basement of that very pyramid and it's time
to find the secret path to the Pyramid of the Forbidden!  The secret lies with
the Inchworms; you know how twelve inches make a foot?  Twelve Inchworms make...
well, you'll see!  Make your way to the left at a leisurely pace, allowing all
of the Inchworms you've seen follow you without problem.  Once you get to the
small bridge, sprint across it and pogo up just to the left of the grouping of
four dart shooters.  You notice how you'll go into the roof?  There's a pole
hidden up there so at the apex of your jump, deactivate the pogo stick and hold
UP.  You'll begin climbing, but watch out for the dart shooter directly above
you and the other enemies that patrol the small chamber!  Make your way to the
right and go through the door.  Sweet!  It's an extra life guarded only by a
Poison Slug!  Grab the life, and go back through the door.  But wait, there's
one more secret to be had in this pyramid!  After returning through the door,
pogo straight up and to the left.  Another secret passage!  Continue left to
grab a bunch of Ice Cream Cones.  If you go through the door in front of you,
you'll pop out on top of the pyramid, allowing you to get a view outside and
make a quick exit.  We, however, want to return back down the way we came.
There's a secret pyramid to visit!  Head back to the Inchworms and get them to
cluster at your feet.  BOOM!  Twelve Inchworms have become a foot!  How bizarre!
Jump on the foot and you'll have escaped from the Pyramid of the Moons.

	Oh weird.  This has to be the strangest way Commander Keen has ever
travelled, and seeing how he's ridden the back of a sea monster, that's really
saying something.  You'll soon be dropped off in a clearing, and it's time to
hesitantly cross in the Pyramid of the Forbidden.

	PYRAMID OF THE FORBIDDEN: WATCH OUT!  From the beginning, two Licks will
come flying towards you at high speeds.  This pyramid is by far the hardest
level in the game.  It's fairly linear, but it definitely won't be a cake-walk.
Make your way up and to the right.  If you survive the journey you'll score a
Lifewater Flask.  Awesome!  You've now come to a gap.  As you fall down the gap
make sure that you keep left to avoid spikes at the bottom.  If you miss the
Red Gem on your way down, CAREFULLY jump out to grab it and open the Red Door.
	Run to the left and flick the switch stand over to the gap that you
created and look down.  You're going to have to fall in such a way that you
avoid both the Poison Slug, the dart shooters, and the darts.  As well, you'll
need to duck to avoid the darts at the bottom.  Make your way over to the Yellow
Gem, ducking under every dart that passes, and open up the Yellow Door.
	Sprint through the Yellow Door, smoke the Slug in the pit, and go
through the doorway.  Whew!  And that was only the first section!  From the
door, look down and you'll see a moving platform.  Jump down to it while it
moves right and duck!  You'll make it past the outcropping at head level and can
jump down below onto safer ground.  Kill the Poison Slugs and the Lick that
drops down and flick the switch.  Use the now liberated moving platform to pogo
up and continue on the pathway.  Once you see the Ice Cream Cones, STOP!  There
are an outrageous amount of Skypests guarding this small chamber.  Take them out
carefully, one-by-one, claim your Ice Cream prize, and head through the door.
From the doorway, once again look down.  Drop onto the moving platform as it
heads left and jump up once the gap appears.  Snag the Green Gem on the left and
then head up to unlock the Green Door and get the (second!) Red Gem.
	Be careful around those spears!  Once you have the Red Gem in your
possession, head back onto the moving platform and pogo back up to the door.
From the door, pogo up to the left to get the Neural Stunner, open the Red Door,
and flick the switch.  Go back to the doorway, look down, and jump onto the
moving platform as it heads right.  Immediately duck as you hit the platform,
and ride it to get the Blue Gem.
	As you come back, pogo up through the Red Door and unlock the Blue Door
above you.  Finally, drop down the gap, grab the Doughnuts, and head through the
doorway.  Almost there!  After reaching the bottom of the drop, jump onto the
moving platform and pogo onto the other platform on the right.  Be warned, this
platform will drop so make sure to not deactivate your pogo stick!  Continue
from platform to platform until you make it to safe ground on the right.  From
there, make your way to the up and left using the moving platforms.  Watch out
for the Skypest and Poison Slugs!  Once you've safely crossed over to the other
side, enter the doorway.  You're practically home free!  Oh no, the other side
holds a switch puzzle!  Flick the first switch, watch out for the Lick, and jump
up to the left.  Flick that switch, and drop down the gap you just created to
your right.  Jump across the small gap to your right and flick that switch.
Head back to the left and up, and flick the switch next to the spike pit.  Work
your way back up to the gap that was just created, zap the Lick, and flick the
switch that he was guarding.  Now that there's a platform over the spikes above,
head up and cross them to flick the switch on the other side.  Head back down
and go to the bottom right.  Kill the Poison Slug that guards the switch and
flick it.  Finally, make your way back up across the spikes and drop into the
hole that you just made.  Avoid the Mad Mushroom and push through the arch.
Jump on the moving platform and collect some well-deserved Ice Cream Cones.
Awesome!  A Council Member!  Go save him and...wait....  A janitor!!!  This had
better be a joke.  Oh well, head through the door, grab the extra life, and take
that foot out of here!

	Well, that was absolutely crazy.  It's time to relax a little and head
to the left to reverently enter the Pyramid of the Gnosticene Ancients.

	PYRAMID OF THE GNOSTICENE ANCIENTS: Here's a nice wide open pyramid for
your enjoyment.  The first order of the day is to head right and blast any
Treasure Eater that you see.  They'll eat your goodies!  After the first Eater
takes the two Lifewater Flasks from you, zap him, cross the bridge, toggle the
switch, and jump up to the platform above you.  Take care of any creatures you
may see there and climb the pole.  Flick the switch up top and take the moving
platform up to the pole above you.  From the top of the pole head right and take
the path downward.  Flick the switch and head back up, dropping into the pit on
the right that you just opened.  Follow that path down and you'll find ANOTHER
switch that you need to flick.  After toggling that switch head back up and
continue down the slope, avoiding the Lick and dropping down the gap.  Head to
the left and jump up to the first gap that you find.  Continue up the structure
and flick ANOTHER switch (only two more, I promise).  Go back down to where you
came from and take the path to the left downward to find...the Red Gem!  Grab
the Gem and head back up and to the left, dropping down the now opened bridge
where you encountered your first Treasure Eater.
	From the bottom of the drop, head to your right and cross the very
dangerous tar pit, watch out for the spear and flick the switch that it guards.
Head back to the left, open the Red Door, and watch out for the Lick!  Head
down, and try to pogo into the left side of the outcropping above the arch.
Walking through the secret passage, hop over the little ledge that blocks your
way and collect some ammo and an extra life.  Head back to the arch and go
through it.  You're near your objective!  Jump up to grab the Green Gem and
flick the switch.
	Ride the moving platform to the left, jumping up onto the platforms when
you reach them.  Don't worry about the Licks, they can't hurt you or land on the
moving platform.  Once you get to the left side of the room, open the Green Door
and save the Council Member!  No problemo.

	Only one pyramid remains.  Head to the right and move silently in the
Pyramid of Shadows.

	PYRAMID OF SHADOWS: The first part of this pyramid is very maze-like, so
to avoid getting lost the simplest route will be taken.  However, if you feel
like exploring you'll be rewarded with a multitude of goodies.  Anyways, from
the entrance head right, avoiding the spears and Poison Slug until you get to a
doorway.  Enter the door and immediately drop down the pole next to you to avoid
the Skypest.  At the bottom of the pole, head to the left and drop down.  Walk
right and jump up to take the middle path.  Continue along this path, look down
to avoid landing on a Slug below, and fall down.  Grab the Doughnut on your
right, and then flick the switch and head through the doorway on your left.
Head right, across the newly created bridge, and avoid the hazards to make it
through the doorway.  After exiting the door, head to your right, jumping across
the dangerous falling platform to the safe ground on the other side.  If you
wish to get the extra life that was underneath the bridge, pogo up to the left
to toggle the switch up there and you'll deactivate it, allowing you to
backtrack, if you so desire.  To continue on with the level, however, head right
across the multiple falling platforms.  When you at last meet a Poison Slug,
you'll know that you're on the right side of the room and can take the falling
platform in front of him down to the doorway.  Go through the doorway and flick
the switch.  Carefully avoid the Skypest and dart shooters to get to the other
side.  If you're in the mood for a lot of extra lives and don't mind replaying
the level, you can duck as the moving platform hits the right wall.  You'll
enter a secret area.  If you drop to the right from the platform, you'll find
some seven Lifewater Flasks waiting to be consumed.  However, the only way out
is by being burned by the tar to your left.  If you decide that suicide isn't
the answer, head into the arch.  From the other side of the archway, head right,
grab the Blue Gem, avoid the hazards, and open the Blue Door to save the Council
Member!
	Great.  You know, you look a lot like the last guy I rescued...

	Well, that's it for pyramids!  Head out of the grove of pyramids and to
the left into the desert of the Shadowlands.  After that, grit your teeth and
enter Sand Yego.

	SAND YEGO: What was that?  A flash of insight?!  Indeed it was!  Wait to
see it again and then use it to jump straight up to grab a hidden Ice Cream
Cone!  Drop down and grab the lift up to the first part of the fortress.  Stay
up on the top level and jump to the right, watch out for the Mimrocks that guard
the way!  You'll soon get to a small platform with a cloud in from of it.  From
there pogo up and to the right to grab the ledge of the platform with the pole
running through it.  If you look to your left, you'll see another flash of
insight!  Follow the flashes to get to a floating platform that holds some
goodies, including a Lifewater Flask!  After grabbing them, head back to the
platform with the pole and jump up to get the Green Gem.
	After getting the Gem head down the pole to your right and through the
doorway.  On the other side of the door avoid the urge to pogo up to the Shikadi
Soda above you (a Skypest guards the way) and head to the right and up the path,
stunning any slugs that might bother you.  After a little bit of climbing you'll
soon reach the Green Door!  Go through the door and up the pole.  Grab all the
goodies you can and head right, carefully making your way past the Mad Mushroom.
From the Mushroom, drop down into the pit below the bridge and switches.  Toggle
all of the switches, and then ride the moving platform back up the gap.  From
the top of the gap head right (watch out for Skypests) and back into the
structure.  Ride the moving platform up, avoid any Skypest you see, and watch
out for the Mimrock at the top.  From the top, climb the pole, head right, and
climb back down the other pole.  From there you have no choice but to go right,
and up into the exit!

	Back in the Shadowlands, head up and to the right, until you're able to
disappear into Miragia.
	
	MIRAGIA: Miragia is a unique and interesting place full of goodies and
strange platforms that will disappear and reappear.  From the beginning head to
the right and take the moving platform up to the next level.  Pogo up to the
disappearing platform to grab some Doughnuts and continue to the right.  Jump up
the two disappearing platforms, on top of the dome, and jump into the entrance
on your right, grabbing some Shikadi Soda and Raindrops on your way down.  Climb
down the pole and head right (going up the path of disappearing platforms if you
need more candy).  You will soon come to a pathway leading up.  Make sure you
look up to avoid the Poison Slugs above you and work your way up.  Once you've
made it to the top, you have a choice.  You can head to the left a take a large
roundabout route, collecting a lot of goodies on the way, or you can jump onto
the disappearing platform and up to the right.  Either way, the way out is by
collecting the Wetsuit.  Cool!  You can breathe underwater now!

	Almost out of this desert.  Head up and to the left and crawl into
Lifewater Oasis.

	LIFEWATER OASIS: A nice simple level to finish off the desert levels.
Head to the right, avoiding the Poison Slug, and fall straight down into the
pit.  Hopefully you landed on the platform on the left.  If not, jump up to it
and jump over to the small ledge on the right.  You'll see a sign that says HIGH
LOW and a switch.  Flick the switch and jump back to the platform on the left.
Near the left edge of the platform you're on, jump up and you'll enter the roof.
Climb up to the left and you'll quickly fall to a secret lower pathway.  Admire
all of the Raindrops and Lifewater Flasks that you can't access, and head to the
right.  Hit the switch and ride the moving platform up, jumping to the left at
the top to escape the hidden passage.  Once you've dropped down, head to the
left, watching out for the Poison Slug and Wormouth, and climb up the pole.
From the top of the pole head right, up to the moving platforms.  Take the
moving platforms up and to the left, watch out for the Thundercloud, take the
pole down, and enter the arch.  On the other side of the arch, watch out for the
sneaky Mimrock behind you and drop down on the second falling platform.  Grab
the Green Gem and activate your pogo stick to bring the platform back up.
	Jump over to the right and enter the Green Door.  Through the door, head
right and save the Council Member!  Good idea, Gramps.

	Alright, enough of this desert!  Head all the way back to Slug Village
and go down, passing to the left of Border Village in order to plummet into The
Perilous Pit.

	THE PERILOUS PIT: From the beginning head into the house, stock up on
ammo, and drop into the eponymous pit.  Once reaching the bottom slide down the
pole on your right, jump into the wall to the right of the sign the says HI to
grab some candy, and sneak under the Mad Mushroom to grab the Red Gem.
	Climb back up the pole, head left, jump across the small gap, and climb
up into the room containing the Bounder and the Blue Gem.
	Climb back down and fall into the gap.  Open the Red Door and watch out
for the hazards you encounter.  Use the poles to safely navigate the path above
the Lick, and climb the third one to find the switch that is guarded by a Mad
Mushroom.  Toggle the switch and head back out the way you came, climbing back
out onto the right side of the gap.  If you don't already see it, a moving
platform will soon come down near where you're standing.  Ride it up to its
highest point and head left past the Mad Mushroom into the arch.  On the other
side of the arch you'll find the Blue Door and another Council Member to save!
May the road rise to meet your feet Mr. Member.

	Endgame time!  Enter Three-Tooth Lake and muck along the Isle of Tar.

	ISLE OF TAR: Head to the right, enter the house to grab some goodies,
and carefully make your way across the tar pits until you can fall down into the
pit, collecting Raindrops on your way down.  Ignore the switch for now and head
left, using the falling platform to jump up to the left.  Pogo up to the tar
pits, jump across them, and fall down hugging the right wall.  Flick the switch
in the little chamber that you find yourself in, and head left.  Jump to the
ledge that's parallel to the falling platform and continue left.  Watch out for
the Wormouth!  Jump up to the moving platform (if you miss it just head right,
enter the two doorways, and you'll find yourself back in the hall with the
Wormouth), avoid the Skypest, and grab the Red Gem.
	With Gem in hand, head back down to the hall with the Wormouth and
continue to the right.  Continue to ignore the switch that you come across and
slide down the long pole that you will soon come across.  From the bottom of the
pole head left, drop into the pit, flick the switch, and wait.  Soon a moving
platform will come down to get you.  Take the moving platform up, enter the Red
Gem, and snag the Yellow Gem.
	Head back to the long pole, climb all the way up, and head to the left.
Continue down underneath the hall with the Wormouth and jump across the gap to
open the Yellow Door.  Head down, avoid the Mad Mushroom, flick the switch, and
walk INTO the wall on your right.  After hitting the ground, head right, look
out for the Wormouth, and enter the doorway.  From the doorway head left and
drop down into the pit.  Now prepare yourself, because some crazy stuff is about
to happen.  You're going to jump over the small outcropping, avoid the two
Wormouths that guard the ledge, jump over to the Blue Gem, fall straight down,
and quickly hop across six falling platforms until you can grab the pole above
the sixth, climbing back to safe ground.  Are you ready?  GO AND DO IT!
	With that insanity over, you'll find yourself back near the Red Door.
Go left, use the moving platform to get up to the right, and once again climb
the long pole.  At the top of the pole head right and open the Blue Door.  Head
right, ride the moving platform up, and climb the pole.  Enter the house,
grabbing a well-deserved Lifewater Flask in the top-left corner, and then leave
and make your way up to the right to exit the island.

	Swim down and to the left to blaze across the Isle of Fire.

	ISLE OF FIRE: This level has a very simple layout (a nice change from
the Isle of Tar) but can at times be difficult due to the nasty invincible
Berkeloids that guard the island.  From the beginning head right, avoiding the
fire the gets in your way, and drop into the pit to climb down the pole.  Head
left, watch out for the Poison Slug and multiple Mimrocks that want to end your
adventure, grab the Yellow Gem and flick the switch.
	Make your way back, open the Yellow Door, and climb up the pole above
the Yellow Gem holder.  The switch has activated a moving platform in the sky to
the left.  Jump on it and work your way left to snag a whole bunch of Ice Cream
Cones.  After grabbing the Ice Cream, head back to the right, down the pole, and
go through the Yellow Door.  Grab the Neural Stunner and climb down the pole,
heading right.  Mind the sign and head up using the moving platforms that you
encounter.  Kill those pesky Slugs and fall down to the right.  Head right and
 begin to climb down the pole.  You need to grab the Blue Gem without being
killed by the Berkeloid.
	If you're successful, climb back up the pole and fall down to the right.
Jump over the fire, open the Blue Door, and save the Council Member!  Wise plan
of action, your ancientness.

	Alright!  We've saved the best for last!  Head right and hopefully enter
the Well of Wishes.

	WELL OF WISHES: This level's a complete change of pace from the others.
No pogoing, no shooting, just swimming.  Use the button or key usually used to 
jump in order to swim faster.  The Well of Wishes is a maze infested with
Dopefish and other nasty creatures so I will just take the most direct route to
the exit.  Exploring will net you some good candy, but can be frustrating.  From
the entrance, swim down, collecting the Schoolfish and avoiding the mine.  Keep
going down, avoid the Sprite, and you'll find a Lifewater Flask.  Sweet!  An
extra life!  Continue down and to the right, until you can't go down any
further.  Once at the bottom of the well, head to your right, avoid the first
path up (the one with the Shikkers) and take the second.  Unfortunately this
second path is guarded by a Dopefish; this is where Schoolfish come in handy.
Use the poor little Schoolfish as bait for the Dopefish, and swim away as fast
as possible as he chomps down on them.  Soon, however, you'll reach a branching
path that will free you from the tyranny of the Dopefish (however it also makes
it very difficult to return from where you came).  Continue upwards, avoid the
mines and Sprite, and you'll be forced left.  You're almost there! Continue
around to the left and you'll find a chamber guarded by a Sprite and two
Dopefish.  Do some fancy swimming and you'll be able to head through the arch to
save the last Council Member!  You're the last one, fella.  Let's both get back
to the Oracle chamber!

	You've discovered the Secret of the Oracle!  Not sit back, relax, and
enjoy the final cutscene.


[9.6] How do I get through The Armageddon Machine?
	Ah, Commander Keen 5.  My personal favorite.  In fact this was the final
walkthrough that I wrote as I wanted to save the best for last.  It's unique
among the PC Keen games in that every level (except for the secret level) needs
to be completed to finish the game.   Anyways, you're starting off at the bottom
of the Omegamatic and have to work your way to the top, so go up and investigate
the Ion Ventilation System.

	ION VENTILATION SYSTEM: Ah, a simple vertical level, useful for Keeners
who want to figure out the controls and get a grip on how Keen moves around.  As
this level is so thin, very little instruction is needed.  Once you have a good
understanding of how Keen moves, jumps, and pogos, head right to grab a bunch of
Shikadi Gum, zap the Sparky, and climb up the long pole on the left.  Grab more
Gum on the structure to the right of the pole, try to avoid the Little Ampton
without shooting him as ammo is fairly limited in this first level.  Work your
way up the left and you'll soon find a horizontally-moving purple platform near
a sentry gun that shoots down.  As the platform reaches the left end of its
route (and when it's safe to do so) perform the Impossible Pogo Trick and
deactivate the pogo at the apex of your jump while holding LEFT.  You'll grab
hold to a hidden ledge.  Pull yourself up into the wall, and perform the
Impossible Pogo Trick again, this time holding RIGHT.  Pull yourself up and
continue holding right to pass over the top of the level and dropping down on
the other side.  (If you're having a hard time performing the Impossible Pogo
Trick, just grab the Neural Stunners below the sentry gun, and head right to go
out the exit.)  After the long fall, go to the edge of the platform and look
down.  You should be able to just see the top edge of a Keg O' Vitalin.  Aim for
it as you jump off to the right and snag a whopping ten extra lives!  Lives
received, head right out the exit.

	Well after clearing the ventilation system, it's time to head up and
strut through the Security Center.

	SECURITY CENTER: Head to the left as you listen to the jazzy tune that
plays in the Security Center and slide down the pole you come to.  Jump into the
right wall for some delicious Bags O' Sugar and then continue on to the left.
Climb up the pole and push the button you come to, then fall down to the left
while holding RIGHT to find some more hidden Sugar.  Look out for the Sparky
below and drop down, head left, and climb the next pole you come to.  Zap the
Sparky and grab the Neural Stunner, Gum, and Red Gem.
	With the Gem, head up and to the right, drinking the Chocolate Milk as
you go along and jumping across the gap to go through the arch.  Place the Red
Gem in its socket to open the Door above and climb the pole to grab some
Marshmallows and the Blue Gem.
	Head back over to the left, jumping the gab again and dropping down to
where the Red Gem was.  Jump up to the green platform and into the wall next to
where the bridge used to be to eat some delicious hidden bowls of Sugar
Stoopies Cereal (boy, Keen is going to have a terrible time at the dentist after
all of this sugar).  Climb up the pole and pogo up and to the left into the roof
just to the left of the Blue Gem socket, to grab even MORE Bags O' Sugar and a
Keg O' Vitalin!  Drop down and head through the Blue Door.  Zap any Sparky that
you see, and follow the hint given by the Marshmallows by jumping up onto one
of the moving red platforms to go up.  Use impressive jumping skills to avoid
the fire helixes and land on the safe ground at the upper left.  Time your moves
to avoid the Slicestar, and run through the arch to grab the Chocolate Milk and
Keycard.
	Drop back down, then head right.  Jump through the first hole in the
floor to get some Marshmallows and ammo, and then down the second hole (watching
out for the Sparky) to grab some Chocolate Milk to activate the switch and bring
the moving platform down.  Ride the moving platform up and head left.  Avoid the
Slicestars and stun Sparky and make your way carefully through the strange
phaser hazards that will block your path.  Blast the Sparky on the left of the
phasers, grab the Neural Stunner, and head through the doorway.  Blast the
Sparkys while avoiding the blasts from the sentry guns, and jump into the right
wall of the next doorway to get some more hidden goodies.  Head through that
doorway, blast the last two Sparkys, grab the Tart Stix, jump into the wall to
the right of the exit to feed your Sugar high, and then exit out the security
door.

	Alright, with security out of the way, time to head into the elevator
and into the lower section of the Omegamatic.  After the ride up, head right and
regret entering Defense Tunnel Sorra.

	DEFENSE TUNNEL SORRA: This Defense Tunnel is an extremely linear run
from left to right.  From the entrance, drop down to the Shikadi Gum and head
into the wall to the right.  You will first find some hidden goodies, but if you
jump over a small barrier and keep heading right you'll find some hidden Bags O'
Sugar!  After collecting the points, head all the way back to the left and jump
up to the level above and continue right.  Avoid the Slicestars, Volte-faces,
and Sparky, until you get to the non-functioning sentry gun.  Jump into the wall
above the sentry gun for some goodies and continue to the right, avoiding the
dangers, and drop down to the left to get the Keycard guarded by the Volte-face.
	From the Keycard, continue right and climb up the purple pole.  A mean-
looking Robo Red will hover by, looking for trouble.  Once he passes back along
to the right.  Drop down and quickly slide down the pole in the floor.  Watch
out for a Sparky and first go left to grab some ammo and then right, pogoing up
to the grab Yellow Gem.
	When it's safe to do so, climb back up through the floor and head to the
right and pogo up to the ledge above.  Drop down the other side, grab the ammo,
open the Yellow Door, and zap the Sparky.  Pogo up into the roof on either side
of the exit for goodies, and finally exit out the security door.

	Alright!  That wasn't so bad.  Go right and blow through the Neutrino
Burst Injector.

	NEUTRINO BURST INJECTOR: From the entrance, head right and try to shoot
down at the Shelley as you pass over her, and collect the Shikadi Gum that lies
in your path.  Drop down into the pit to protect yourself from the Slicestar,
keep to the left wall if you didn't manage to destroy Shelley, and head over to
the right once it has passed.  Make sure there's no Shockshund above you, and
climb the pole and continue heading right.  Watch out for the Shelley and
refresh yourself with some delicious Vitalin before dropping into the pit
guarded by the Volte-face (it would probably be a good idea to zap him as well).
Climb up the pole on the right and stun the horrific Shikadi from the safety of
the pole.  Pogo up to the platform above, grab the ammo guarded by the
Slicestar, and then continue up the ramp to the left.  Avoid the Shockshund,
grab more Vitalin, and then blast the Sparky to the left and you jump to his
platform.  Do the same to the Sparky on the platform up to your left, and then
continue right.  Watch out for the Shelley, she's in a very difficult position
to attack.  It's probably safest to attack when she's on top of one of the
"humps" and you're protected behind an adjacent one.  Go through the arch on the
right, and jump onto the purple moving platforms and grab the Blue Gem (jump
straight up to get some hidden Bags O' Sugar as well).
	With the Gem, flip the switch and carefully fall into the wall below for
some points and a quick way down.  Go down the pole you came up, and climb down
the pole below while you're at it.  Drop down the green platforms to your right
to grab some Tart Stix, and the Red Gem!
	Jump back up the green platforms and then head down the pole on your
left for some extra points.  Watch out for the Shikadi that will zap the pole
below and drop down to get the ammo and Cereal that he was guarding.  Climb back
up the poles and once you're in the same area as the Volte-face, jump through
the gap on the left, grab the Bags O' Sugar if you can, and open the Red Door.
Drop down to open the Blue Door as well, and carefully make your way past the
Shikadi and Slicestar into the machine room.  Grab the Sugar Stoopies and pogo
on the fuse to disable the Neutrino Burst Injector.  One of the four machines
protecting the main elevator shaft--toast!

	With the NBI out of the way, purposefully wander to the left and invade
Defense Tunnel Vlook.

	DEFENSE TUNNEL VLOOK: From the entrance grab the ammo on the level below
you and continue left, blast the Sparky, and jump into the wall next to the
Spindred.  Inside the wall, pogo up to the left to grab a few points, and over
to the right to get some monster points and an extra life!  Once you're done in
the wall, head underneath the Spindred and follow the Shikadi Gum to the upper-
left and continue along the upper path.  Watch out for the two Sparkys that will
try and charge you and climb down the pole when you come to it.  Head right from
the bottom of the pole, watch out for the Sparkys and Little Ampton, and climb
down the pole you find to grab the Keycard.
	Carefully grab the Neural Stunner to the right (a Robo Red guards that
chamber) and head over to the left, past the pole that originally brought you
down there, and across the three Spindreds in order to grab the Red Gem.
	With the Gem head to the right, and back up the pole, go left through
the Red Door, make it by the two dangerous Slicestars, and grab the Yellow Gem.
	Now it's time to go back down that pole, and head left back to where you
grabbed the Red Gem in order to open the Yellow Door.  Blast the Sparky and
toggle the switch to start the red platform moving, and use it to get over to
the left.  Pogo up to the left above the arch to get some hidden goodies (and if
you can, even higher up to the right for a hidden Keg O' Vitalin), and then
continue left under the Spindred.  Stay along the upper path, avoid the Sparky
and sentry gun, and head through the security door to exit.

	Another Defense Tunnel down!  Continue left and engage Energy Flow
Systems.

	ENERGY FLOW SYSTEMS: Ah!  Robo Red is watching you!  Don't worry though,
he'll (mostly) stay out of the fight for now.  Head to your left under the
sentry gun and pogo from the edge of the platform to grab the Red Gem.
	With the Gem run right and climb up the silver pole.  Grab the Sugar
Stoopies hanging in the air, and blast the Sparky from the safety of the pole.
Jump off to the right, go up to open the Red Door, zap the Sparky, and grab the
Yellow Gem hiding with the Shikadi Gum.
	Head back down and CAREFULLY climb down the pole.  A Robo Red guards
the area at the bottom, and you need to sneak past him to climb down the next
pole to the level below.  After climbing down, blast the Sparky and any Little
Amptons that may cause you grief, and climb up to the right to snag some
Vitalin.  Climb back down and head left, climbing down the pole, pushing the
button, and heading through the Yellow Door to get the Blue Gem.
	From the Gem, jump right, into the wall and continue a little ways until
you fall.  From there, head left (admiring John Romero's name written in pipes)
and collect the Keg O' Vitalin.  Head back the way you came and begin climbing
up the pole, but don't enter Robo Red's chamber just yet.  Wait for the Robo Red
to pass over to the right, and the carefully climb up and run over to the left,
down into the chamber full of Bags O' Sugar next to the pipe-swastika (or, half-
swastika, depending on the version of the game that you're playing) and then
jump onto the moving purple platforms.  Once you get up to the pipe above, jump
off to the left to grab some Vitalin and jump on the small red platform to get
up to the Blue Door.  Head through the Blue Door, look down to avoid landing on
a Sparky, and climb down the pole.  Look out for the Little Ampton and Sparky on
the landing below, climb down, and then jump over to the left.  Look down, and
you'll see the dangers lying between you and the Green Gem.  Figure out your
preferred method of dealing with them, grab the Green Gem, and head back up to
the Blue Door.
	From the opened Door, jump on a moving purple platform for a ride, and
make your way around to the upper right, heading into the two areas with "NO
HUMANS" if you so desire for extra points, Vitalin, and ammo, and finally
jumping through the arch.  Open the Green Door, grab the points, and destroy the
fuses with your pogo stick.  One of the four machines protecting the main
elevator shaft--toast!

	Back on the Omegamatic, head down and barrel into Defense Tunnel Burrh.

	DEFENSE TUNNEL BURRH: Begin by climbing up the pole and heading over to
the right.  Continue to the right, stunning the Sparkys, and climb down the pole
once you get there.  Push the button and return back to the long pole that
brought you up.  Drop down to the bottom of the long pole, grab the points, and
then climb up the pole and head right along the middle path.  Blast the Sparkys,
climb down the short pole that you come to in order to increase your Vitalin
count, then keep going to the right and drop down the now disabled bridge.  Get
the Vitalin as you continue to the right and pogo up to the left in the roof
above the sentry gun.  Climb up and jump around, and fall down to the left for
an extra life.  With that out of the way, go back under the sentry gun until you
get to the edge of the platform, drop down into the gap on the left, zap the
Sparky, and grab the Red Gem.
	Get back out and climb the fibrous-looking black pole into the roof
above.  Be warned that a Robo Red guards the area, and there are two Little
Amptons that could also ruin your day!  Head to the right in the little chamber
and snag the Yellow Gem.
	After grabbing the Gem, jump into the wall on the right and you'll
safely get on the other side of Robo Red's chamber.  Drop down the hole to get
some Sugar Stoopies and ammo, and then head right through the Red Door.  Perform
the Impossible Pogo Trick up the right to grab the pole and collect a Neural
Stunner and some Bags O' Sugar, and then make your way to the right, through the
phaser, climb up the hill, and drop down the hole that's guarded by a Slicestar.
Head right through the Yellow Door, under the arch, and pogo up into the roof at
the right of the doorway for some hidden Chocolate Milk.  Go through the doorway
and pogo straight up to collect both the Blue Gem and some points hidden up in
the roof above.
	Head back through the doorway and back up through the hole guarded by
the Slicestar.  Jump up into the roof on the right of the sentry gun for some
hidden Tart Stix, and then head to the right and jump down through the cyan
platforms.  Continue to the right.  Jump up through the Blue Door, grab the
Green Gem, and then jump up through Green Door to get the Keycard.
	With Keycard in hand, drop down and run through the exit.

	After getting through the Defense Tunnel, head down and go nuts in the
Regulation Control Center.

	REGULATION CONTROL CENTER: Sparky!  Blast him and climb up the pole.
Zap the other Sparky above, flip the switch, and grab the Red Gem.
	Drop down and continue to the right.  Head through the Red Door, avoid
the Sparky and Sentry Guns, and push the button.  Head back to the left and use
the red moving platform to get up to the yellow poles.  Climb up the pole,
avoiding the Slicestars, and use the stationary red platform to jump up to the
Yellow Gem in the upper-right corner.
	Head over to the left, climbing down the pole to get some Vitalin, blast
the Sparky patrolling the small platform above, and then head right across the
pipe, open the Yellow Door, and drop down to the doorway below.  Fry the Sparky
in the room with you, push the button, and head through the doorway.  On the
other side, drop down the deactivated bridge and try to fall into the gap on
your right (if you miss, just go left, grab the Blue Gem, and open the Blue
Door).  Look down from above and you should see a Robo Red patrolling the area.
Drop down when he heads left and sprint over to the right, running for dear
life, blasting the Sparky, and jumping across the phasers.  Get to the upper-
right and ride the purple moving platforms up.  Jump over to the right after
blasting the Sparky, and then climb the pole.  Shoot the Shikadi on your left
from the safety of the pole and then head up to the left.  You'll now encounter
what can be the most dangerous of all the enemies: a Shikadi Mine.  You need to
get near to the Mine until it starts to light up, and then run off to safety.
Its blast pattern is pretty random, so it can also be a good idea to save before
attempting to destroy one.  With the enemies dealt with, jump up the two right-
most flipping red platforms to get on solid ground.  Grab the Chocolate Milk and
Vitalin, blast the Sparky over to the left, set off the Mine, and then push the
button.  Jump up to the left, grabbing the Shikadi Gum as you fall down to the
green platform below.  Blast the Sparky and grab the goodies in the machine
room, but watch out for the Shikadi Mines!  Once you're done getting filled up
on the good things in life, activate your pogo and destroy those fuses.  One of
the four machines protecting the main elevator shaft--toast!

	Only one more machine left.  Head up and trot through Defense Tunnel
Teln.

	DEFENSE TUNNEL TELN: From the entrance climb the pole, jump over to the
right to stock up on ammo, and then jump over to the left and immediately climb
the black wire to the roof.  A Robo Red guards the Red Gem here.  Carefully make
your way from wire to wire and grab the Red Gem.
	Make your way back the same way you came, then drop down and climb down
the pole for some points, both visible and hidden.  Continue left, make it past
the phasers, blast the Sparky, and climb up the steps to the level above.  Head
through the Red Door, stun another Sparky, lure the Shelley to her own
destruction, and grab the Yellow Gem that she guarded.
	Drop back down, open the Yellow Door, and head left.  Watch out for the
Little Ampton as you climb the pole, let the Shelley attack you as you stay
below ground level, and then climb up to the upper left to grab the Green Gem.
Slide back down to the bottom of the pole and head left into the Slicestar pits.
Though it may not seem like it, you can duck underneath the Slicestars as they
pass by.  Continue to the left and you'll be rewarded with some Tart Stix and,
more importantly, ammo.  Head back to the pole the same way as you came, and
then go left along the middle path.  After passing under the sentry guns, you'll
come to a room above you guarded by a Slicestar containing a lot of Vitalin.  If
you look carefully, you'll also notice a Blue Gem hiding among the decorations!
Jump in there, make your way around the Slicestar, and grab all of the Vitalin
and the Blue Gem.
	Drop back down and continue to the left.  Drop down into the pit to grab
some Tart Stix, then jump up to the upper left.  Grab the Tart Stix in the up
above and then steel yourself and head through the Green Door.  The situation is
similar to the one earlier in the level, with a Robo Red below some black
climbable wires.  Make your way over to the left, and grab the Keycard.
	After getting the Keycard, head back right, drop down, and go left
through the Blue Door.  Zap the Sparky as you continue left, then jump up to the
security door (stunning the Sparky that guards the door, of course).  Leap into
the wall next to the EXIT sign and start slowly pogoing to the right to get some
hidden Sugar Stoopies Cereal and Bags O' Sugar.  Finally, with the rush of
sugar, head out the door.

	Time to toast that machine!  Head up and break into the Brownian Motion
Inducer.

	BROWNIAN MOTION INDUCER: Head left from the entrance, and make your way
across the moving purple platforms.  Climb down the pole, keeping your head
below danger as you go right to collect the goodies, then climb back up the
pole, blasting the two Sparkys and taking the ammo that they guard.  Climb to
the top of the pole and head down the slope on the left.  Watch out for little
Amptons as you slide down the pole that you come to, stun the Sparkys that will
try and charge you, climb the other pole into the roof for some hidden Tart
Stix, and then grab the copious amounts of Vitalin on the right.  After
collecting all of the goodies, head back up the pole, up the ramp, climb the
other pole, and jump on top of the red platform.  Grab the Tart Stix and jump up
the hole in the floor that's right above you.  Head through doorway A and upon
exiting on the other side stun the two Sparkys, grab the Chocolate Milk, and
begin to climb down the pole.  Jump over to the right on top of the non-
functioning sentry gun, then jump down to grab the Sugar Stoopies Cereal below
it.  After that, make your way left across the poles and grab the Blue Gem.
	Climb back up through the floor using the right-most pole and head back
through the doorway.  Drop back down the hole in the floor, head right through
the first arch (watch out for the Sparky that hangs out nearby) and jump up
through the next hole in the floor.  Grab the Shikadi Gum (and the Sugar
Stoopies and Marshmallows, if you dare) and head through doorway B.  Jump onto
the purple moving platform, and grab the Sugar Stoopies and Yellow Gem.
	Ride the purple moving platform to the left and drop down to stock up on
ammo.  Climb into the wall and drop down for some mega points.  Once at the
bottom, head right, climb up the pole, and jump back up on the red platform
above.  Head all the way to the right, passing through the arches, and grabbing
the Shikadi Gum and Bag O' Sugar.  Head back left, jump through the hole in the
floor, and run through doorway C.  Head right, jumping to grab the Vitalin, and
open the two Doors.  Grab the Sugar Stoopies on the right side of the machine,
then activate your pogo and destroy those fuses!  One of the four machines
protecting the main elevator shaft--toast!

	The main elevator shaft is now open!  Head into the doorway of the now
open right elevator and up to the top of The Armageddon Machine.  Run up and
hurry through the Gravitational Damping Hub.

	GRAVITATIONAL DAMPING HUB: Ah, the Gravitational Damping Hub.  A fairly
complex level that hides the way to the secret Korath III Base.  Also the music
rocks.  From the beginning, wait for the Spirogrip to make his first lunge, do
the Impossible Pogo Trick to get the Bags O' Sugar above, and then head to the
right.  Jump down into the Vote-face's chamber to get some more Sugar (and some
hidden ammo above the Bags) and then jump out and climb the pole guarded by a
Sparky.  At the top of the pole, carefully make your way to the upper-right
using the red moving platforms, and flick switch A.  Jump over to the area on
the left that's guarded by Spindreds, run underneath them, and watch out for the
shots coming from the sentry guns as you head left to grab the Keycard and push
button B.
	Continue back to the right on the purple moving platforms and drop back
down to the bottom of the chamber.  Slide down the pole and run left across the
now activated platform, grabbing the Tart Stix as you go.  Climb up the pole
that you come to, and by wary of the Sparky and Sphereful that are nearby.  Pogo
up into the little chamber almost directly above the pole to stock up on some
more ammo.  Lure the Sphereful over to the left, then pogo up to the green
platform above.  What does that sign in the room on the left say?  JUMP DOWN AT
ARCH?  Weird.  Surely that'll become important later.  Anyways, blast the
Sparkys, pogo into the roof on the right of the bridge, and push button C to
fall on the Green Gem.
	Gem in hand, slide down the pole, head right until you reach the end of
the platform, drop down and head left to the beginning of the level.  Open the
Green Door, grab the Shikadi Gum, and push button D.  Head back to the right,
jump up to the platform above, and once again ride the red moving platforms up.
This time, use the red moving platform that came out of the roof when switch A
was toggled to jump through the now deactivated bridge D.  Head right and around
to the top, zapping the three Sparkys that guard the way, and then drop down
when safe to run through the doorway.  Coming out of the other side of the
doorway, jump into the wall on the right for some hidden Bags O' Sugar and then
head left.  Blast the Sparky and, hey look!  An arch!  Jump down while under it
and you'll fall below it.  Head left and you'll drop down for a long time.  When
you hit the bottom, avoid the Slicestar as you use the red moving platforms to
get up to a pole that's guarded by a Volte-face.  Climb up the pole and
carefully time your moves so that you can avoid the sentry guns' shots in order
to grab the Red Gem.
	After getting the Gem, pogo up to the left from the top of the right-
most sentry gun, open the Red Door, grab the Sugar Stoopies, and head up into
the teleporter.

	As you step out onto Korath III, admire the yellow planet and head right
to face danger in the secret Korath III Base.

	KORATH III BASE: Ah...bagpipes...their sound stirs the Scottish blood
that flows deep in my veins.  Anyways, try your best to avoid stunning the
Scottish-looking natives of Korath III, they won't hurt you (though they do tend
to be kind of pushy) and really just want to get on with their day.  There is a
very quick way to end the level, but we're going to spend some time collecting
points.  First of all, follow the arrow and drop into the pit below.  There are
two very long strings of Vitalin, first on the left-side of the pit and then on
the right-side.  After falling for nearly ten seconds, you'll eventually hit the
bottom.  Head to the left and begin the long climb up.  Climb the first pole,
stun or avoid the Volte-face, and climb up the pole that he guards.  Grab the
Chocolate Milk and Neural Stunner in the next room, and avoid the sentry gun as
you pogo up through the hole in the ground to the level above.  Be careful
around the Slicestars and make your way on top of the platforms in order to
climb the pole up into the next room.  This time you only have the inhabitants
of Korath III (Korathians?) to worry about.  Jump to the upper platform and then
climb the cyan platforms up the gap on the right side.  Climb the purple pole,
grab the Sugar Stoopies and Chocolate Milk and work your way up past the non-
functioning sentry gun to climb the other purple pole.  At the top of that pole,
run to the left, grab the Blue Gem, and slide back down the two purple poles to
enter the Blue Door and grab the Yellow Gem that it contains.
	With Yellow Gem in hand, head back up the two purple poles, grab the
Neural Stunners, and go through the Yellow Door.  Work your way up the small
cyan platforms, grabbing the bowls of Sugar Stoopies Cereal and the Keg O'
Vitalin by jumping along the left wall.  Head through the arch at the top of the
platforms and continue working your way up until you get to another pole.  Climb
the pole and grab all the Shikadi Gum as you continue to make your way up using
the platforms.  Finally you'll make it to a purple pole.  Climb the pole into
the bluish room and grab the ammo and the Green Gem.
	Once again prepare yourself for a long drop, grabbing any Vitalin you
missed on the first trip down.  This time, once you hit the bottom head right,
jumping into the roof on the right-side of the arrow for some hidden Tart Stix.
Jump up to the level above, and flick the switch.  This will allow for the red
moving platforms to escape and start moving up the left wall.  Pogo up the small
red platforms and the red falling platforms until you make it up to the arch.
Pass under the arch and continue to work your way up, avoiding the Slicestar at
all costs until you can make it to the pole above.  Climb the pole and work your
way up and around, grabbing all of the Shikadi Gum that you can.  Once you make
it to the poles, it's probably a good idea to stun the Little Amptons to avoid a
frustrating death as you collect the Gum and climb up the middle pole.  At the
top of the pole, head left, watch out for the Slicestar, make your way up the
small red platforms, and grab the Blue Gem up above.
	Drop back down and head right, riding the red moving platform up that
side of the room, and head through the Blue Door.  Jump up the flipping red
platforms and climb the pole up above.  Pogo straight up the red moving
platforms until you make it to the safe ground above, and grab that Keycard.
	Now holding the Keycard, once again take the long drop down.  Keep left,
in case the red moving platforms are moving up, and make your way down until you
hit one of those platforms, or the ground.  If you did miss the red moving
platforms, wait for them at the bottom, and ride them up to the top.  Once
you've made it to the top, jump over to the right (you'll probably end up
opening the Green Door, but don't bother going through it), and pogo up against
the right side of the wall above and deactivate the pogo as you reach the apex
of your jump while holding RIGHT.  You should pull yourself up into a little
alcove.  From there, use the Impossible Pogo Trick to get up to the cyan
platform on the left (it can be tricky), grab all the Bags O' Sugar and ammo,
use the Impossible Pogo Trick to get up to the fuse at the upper-right,
activate your pogo stick, and bust that fuse!  I wonder what that fuse was
for....

	Fuse destroyed, head into the teleporter, and once you pop out the other
side run up and explode into the Quantum Explosion Dynamo.

	QUANTUM EXPLOSION DYNAMO: If "Mars, the Bringer of War" playing in the
background didn't give you a hint, this is the big one, and can be at times very
difficult, but don't give up!  First head to the left wall and perform the
Impossible Pogo Trick up to the left to grab a hidden ledge and move slowly to
the left.  You should drop down a bit, continue left and you'll come out in a
room with some Neural Stunners.  Grab the ammo, and pogo up above the left-most
Neural Stunner for some hidden points.  Head back to the right until you hit a
hidden wall, and then pogo up to the left to grab an edge.  Run left out of the
wall, under the hazards, and grab the points and ammo.  Finally, head back into
the wall, jump while holding RIGHT, and keep right until you fall back down to
the entrance.  From the entrance, pogo up the red platforms and then perform the
Impossible Pogo Trick to get on the sentry gun attached to the right wall above
you (if you're having a hard time doing the Impossible Pogo Trick, you can just
do a normal pogo jump up to the pipe first, but it is a bit more dangerous).
Continue to use the Impossible Pogo Trick to work your way up the sentry guns on
the right wall, jump up to the ledge above, and climb the pole.  Avoid the
sentry gun's shots and flick the switch to the left.  Hope that the Shikadi
Master doesn't teleport his way into the room you're in, and ride the purple
moving platforms to grab the Green Gem above.
	After grabbing the Gem, slide down the pole and continue to the right.
Work your way up the red platforms while avoiding the Slicestars and jump over
to the right.  Jump down through the platform and avoid the Spindreds as you
slide down the poles as far as you can go.  Once at the bottom of the poles,
jump into the roof above the cyan fusebox on your left for some hidden Tart
Stix, and continue right and drop down along the side, collecting the Vitalin as
you go.  Grab all up the ammo on your left, and jump into the chamber filled
with Marshmallows.  Mercilessly massacre the Shockshunds from below, then grab
all of the Marshmallows and pogo up to their platform and over to the right to
grab the Blue Gem.
	Head left under the arch and push the button to open up the bridge.  Run
under the Spindreds when it's safe to do so, and grab the goodies and, of
course, the Red Gem.
	Head out of the pit and continue left across the hazard, which has
always reminded me of a similar, spike-covered hazard from the original Sonic
the Hedgehog (which came out some six months before The Armageddon Machine), up
to the pole on the left.  Climb the pole and head right across the other ones,
but avoid clinging to the silver ones, as they connect to the Shikadi below.
Make sure to grab the Yellow Gem below the second yellow pole, and climb up the
right-most silver one.
	 With all four Gems in hand, it's time to finish this.  Head left
through the Green, Blue, and Yellow Doors, climb the pole, head right across the
phasers, and jump up to the Quantum Explosion Dynamo.  You'll find that trying
to destroy the core with your pogo or Neural Stunner is futile, you need heavier
firepower.  Pogo up to the ledge on the right, grab the ammo, and open the Red
Door.  You need to lure a Shikadi Mine over to the QED and have it explode over
top.  Specifically, you need a piece of shrapnel from the Mine to pierce the
heart of the machine.  Don't worry if you die in the explosion.  As long as the
machine is destroyed, you'll finish the game!

	Congratulations!  You've completed Goodbye, Galaxy!  Now enjoy the end
text, translate the note for some shocking revelations, and get your name in the
High Scores list!


[9.7] How do I get through Aliens Ate My Baby Sitter!?
	Oh no!  The evil Bloogs have kidnapped your babysitter!  Time to get to
work and rescue her!  First off, head right and return to the Bean-with-Bacon
Megarocket.

	BEAN-WITH-BACON MEGAROCKET: At first glance it seems like there's
nothing here, but the Bean-with-Bacon Megarocket holds a secret!  Pogo up to the
right wall and you can grab a secret ledge, what's more, if you perform the
Impossible Pogo Trick up to the left from that ledge, you can get to ANOTHER
secret ledge, enabling you to grab some Pizza Slices up above!  If you're having
trouble getting up there, save your game while Keen is off-screen on the first
ledge, and load it again.  Due to a bug in the program, after loading you'll be
able to see the edges of the level, making it much easier!  After getting the
Pizza, return to the first ledge and head right to drop down to a fairly
hazardous area.  Make your way past all the hazards and claim some more goodies
before heading out the exit.

	You can return to the Bean-with-Bacon Megarocket at any time to stock up
on Pizza Slices.  What's more, if you're low on ammo (4 shots or less) you can
return to the Megarocket to pick up three Neural Stunners (one above ground, and
two in the secret passage below ground)!  As well, it's a great place to
practice jumping, pogoing, moving, and shooting.

	Well, with that out of the way, head to the left and hop across
Bloogwaters Crossing.

	BLOOGWATERS CROSSING:  Here's a nice simple area to start things off.
Head right, collecting candy and Vivas, and avoiding the Bloogs and deadly water
below.  When you reach the switch, flick it up and continue to the right.  After
safely making it across the pillars in the water, climb up the two branches of
the first "tree" that you see and wait.  After some time a moving platform will
come into view, it doesn't get too close so pogo over to it as soon as you feel
like you can make it.  Ride the platform to the left, collecting everything you
can, and you'll soon make it to a Queen Viva!  Grab the extra life and head back
to the tree you jumped from.  Clean out the nearby treetops and then drop down
to the right to exit (watch out for the Babobba)!

	That wasn't too bad!  Now it's time to head straight up and into the
teleporter.  After popping out the other side, head left and fight your way
through Guard Post One.

	GUARD POST ONE: From the entrance, head left, watching out for the
Babobba.  Ignore the area and enemies above and...oh, a trap!  You've dropped
down into a pit.  It's going to take some effort to work our way up to the other
side.  From the bottom of the pit, head to the right and jump into the alcove
containing Neural Stunners.  After stocking up on the ammo, drop down again and
head to the left, dropping down as far as you can.  From the bottom, head left
to grab some goodies (watch out for the Bloog and Babobba) and then head to the
right and flick the switch down.  Go up one level and over to the pit of spikes.
The switch that you just flipped let the platform to your left start moving.
Jump onto that platform and ride it into the roof, jump to the left while in the
roof to grab a ledge and collect some ammo.  After that, get back on the moving
platform and grab the Blue Gem.
	From the Blue Gem, head right and back up the small platforms to reach
the Blue Door.  Go through the Blue Door, watching out for baddies, and ride the
two moving platforms back up out of the underground.  Get on top of the Guard
Post to perform a Cool Jump while collecting all of the Ice Cream Bars, and head
out the exit.

	Alright!  From the Guard Post, head to your left and cross into the
First Dome of Darkness.

	FIRST DOME OF DARKNESS: The First Dome of Darkness is a simple looking
level that contains many secrets.  From the entrance head right into the dome.
There is a path down below, marked by a sign with a flashing red hand.  There
are many rewards to be had there, but the path is fraught with danger.  If you
choose to take that path, you're on your own.  You choose to live, however, head
to the right until you make it to a small platform that leads upwards.  Make
your way up using the small platforms until you reach a switch.  Flick the
switch down and make your way down and back to the dome's entrance.  To the
right of the entrance there is a small platform you can jump to.  Look up from
it and you'll see the Blue Gem above you.  Use the moving platform to grab that
Gem and then head right.
	Jump up to the Blue Door, flick the switch on the other side, and ride
the moving platform up to receive your reward.  Wow!  A rope and grappling hook!
They look useful!

	With Grappling Hook in hand, head right and dare to enter the Second
Dome of Darkness.

	SECOND DOME OF DARKNESS: From the entrance, head to the left, watch out
for the Gik, and jump up the little platform right above the deactivated bridge.
Waste the Bloogs and work your way around to snag the Blue Gem.
	From the Blue Gem, make your way up and to the right (grabbing the
Neural Stunner on your left if you need some ammo) collecting the Bloog Soda
until you reach the Bloog that guards a pole.  Climb down the pole, work your
way down a level, jump through the arch on your left to grab some ammo, then
drop down again to open the Blue Door.  Watch out for the Babobba as you head
left and down, and flick the switch that you come upon.  Make your way back,
past the Blue Door, and jump up to the right.  Head right, dropping down past
the deactivated bridge, and go through the arch and down to the poles to collect
the Yellow Gem (and the Banana Splits, if you're brave enough).
	After grabbing the Yellow Gem, head back up the pole, through the arch,
and jump up the gap above to get to the Yellow Door.  Toggle the switch on the
other side of the Door, and head back down to the now activated bridge above the
arch.  Pogo up to flick the switch above the bridge, and then head back up to
the pole that was guarded by the Bloog.  After climbing the pole, pogo up to the
right and climb over the structure.  Watch out for the Bloog below, and continue
heading right, until you fall into the gap above a small room containing a Bloog
guarding some Ice Cream Bars.  Jump over to the small platform to your left and
look down.  Jump down to the moving platform below, and allow the OK block to
push you off, letting you safely collect the Red Gem and fall below.
	After hitting the ground, head left, cross the now activated bridge
across the spikes, open the Red Door, and head out the exit!

	Ok, this cave is clear.  Go out the other teleporter and head up to
hungrily enter Bloogfoods, Inc.

	BLOOGFOODS, INC.: Here is a somewhat confusing and frustrating level
with a delicious prize waiting at the end.  From the entrance, avoid the pounder
and take the moving platforms up and over to the left.  Climb the platforms and
jump down to grab the Red Gem.
	From the Gem, collect the Bloog Soda with a Cool Jump and upon landing
jump down to the moving platform.  Get on the moving platform that is going
right and jump to the ledge that you come to.  Make your way over from the ledge
and jump down below.  Continue right until you make it to the end of the
platform you're on, fall off, and continue left under the pounders.  Grab the
Ice Cream Bars as you make your way under the pounders, carefully jump over the
exhaust vent, and grab the Blue Gem.
	After grabbing the Gem, head back to the right and ride the moving
platform (operated by a Bip) up to the switch.  Flick the switch, head
through the Blue and Red Doors, and jump up to toggle the other switch.  Pogo up
onto the moving platform above and then over to the small platform.  Pogo into
the wall on your right for some hidden Banana Splits and then go back through
the Doors.  Jump to your left across the two conveyer belts and wait on the
small ledge.  Soon, a moving platform will come down near to where you're
standing.  Ride it up to the top, take out the Blooguard, jump over to the
platform along the right wall.  Jump down and, when safe, head to the left and
take out the Blooguard.  Jump up the platform and wrap around to grab the Green
Gem.
	Once you have the Green Gem in your possession, fall down and head right
back through the Blue and Red Doors.  Run past the switch (avoiding the exhaust
vents, of course) and drop straight down to open the Green Door.  You'll now be
in a room with six switches guarded by a Bloog.  Take out the Bloog and flick
all but the second switch.  Wait for the moving platform to come down near the
first switch and ride it up to the conveyer belt (you may have to pogo off the
slope on the left side).  Grab the goodies in the alcove above the belt, and
then wait for another moving platform to come down the left side.  Zap the
Blooguard on your right, flick the switch he's guarding, grab the goodies above
that switch, and ride the now moving platform up.  Jump to the left and ride the
moving platform to the right.  Take out the Blooguard, head right, and bounce
off the falling platform to grab the Stupendous Sandwich of Chungella IV.  This
is second biggest sandwich I ever saw!

	Pockets full of food, head back through the teleporters to Bloogwaters
Crossing, head left and use the Grappling Hook to climb up the steep cliff and
foolishly enter the Bloogdome.

	THE BLOOGDOME: Ah, the Bloogdome, home of the Nospikes.  As the sign
with the red hand indicates, this level is dangerous and optional, but there are
some goodies to be had so don't lose heart!  Nospikes are tough enemies, each
taking four shots to down, but if you get one to charge off a cliff he'll fall
to his doom.  From the entrance grab the Neural Stunner, zap the Nospike
before he runs you through, and jump up to the Vivas on the ledge above.
Continue upwards and flip the switch on the left to engage the moving platform.
Carefully make your way up the moving platforms while avoiding the plasma orbs.
Watch out for the Gik that guards the platform with the Blooglet.  Ride the
rotating platforms to the upper-right to grab the goodies up there, then ride
them down to the passage in the lower left.  Jump up to the pole and slide down,
grab the goodies below, and then climb back up again.  Jump back up to the
rotating platforms and head to the bottom right.  Jump over to the platform the
Blooglet is running across and pogo up (if you can) to the ledge above for
some Ice Cream Bars and Pizza Slices.  If you've tired of the Bloogdome, avoid
the plasma orb next to the Blooglet's platform and fall against the right side
of the dome's outer wall to quickly reach the exit.  If you want to stock up on
some more points, however, stick close to the red rock wall as you fall.  Look
down from the purple platform that you'll land on, and jump down when it's safe.
Take out the Nospike and avoid the Gik, flip the switch and climb the pole.
This will start you on a linear path to the very dangerous, yet rewarding
underground section full of points, Vivas, and moving platforms.  Once you're
done down there, head back to the Gik and run out the exit on the right.

	Well that was a nice bit of dilly-dallying.  From the Bloogdome, head
down and make your way into Bloogton Manufacturing, Inc.

	BLOOGTON MANUFACTURING, INC.:  From the entrance, watch out for the
Blooguard and head right, flicking the switch and riding the now moving platform
up.  Ignore the Red Gem, we won't be needing it.  Ride the moving platform up,
and jump to the left while grabbing the Ice Cream Bars to reach the tilted
platforms on your left.  Shoot the Blooguard from the conveyer belt, jump over,
and pogo up to the top of the long sloped platform.  Climb up that platform,
grabbing Ice Cream Bars and taking out the Blooguard until you get to the small
platforms slanting up to the left.  Pogo up the small platforms and jump up to
the right using the yellow platform. Pogo up to the little platform supported by
the red girder to get some delicious Pizza Slices and then get up to the sloped
platform above you.  Head left up the platform and jump over to the strange
octagonal structure.  Slide down the pole and flip the switch.  Pogo back to the
sloped platform and ride the now moving platform up to the other octagonal
structures.  Flip the switches and grab the goodies in both, and return to the
entrance.  From the entrance head right, look out for the Ceilick (and jump into
the roof to grab the goodies he was protecting) and ride the moving platform
over to get Queen Viva.  The platform, however, will get too close to the roof
right after getting the extra life, so much sure you jump up to the right to get
it, landing on the other side of the plasma orbs, and then wait for the platform
to make another round before using it to hop back over to the left.  From there,
make your way over to the far left side, avoiding the other Ceilick (and getting
his goodies too), and ride the rotating platform over to the Yellow Gem.  
	After snagging the Gem, reverse your steps all the way back to the top
of the right-most octagonal structure.  From there, jump up to the Yellow Door
on the right and fly through the exit.

	After clearing the factory, run up and ascend Bloogton Tower.

	BLOOGTON TOWER: Kill the Bloogs and run left to grab the first Red Gem,
then head to the right elevator shaft to wait for the moving platform to come
down.
	Jump on the platform and take it to the top.  Eat some delicious Ice
Cream Bars and grab the ammo, and then jump into the right wall to find a secret
passage downwards.  At the bottom of the shaft, jump into the roof at right to
grab some hidden Ice Cream Bars, and then head to the left elevator shaft.  Ride
the moving platform up to its first stop and jump right.  Get the Bloog Soda
below (look out for the Bloog) and the Root Beer Floats above, and then jump
back over to the left side.  Flip the switch and wait for the next floating
platform to lower so you can take it up.  At the top, jump left and head through
the first Red Door.  Drop down the gap, first to the left to grab the Neural
Stunner and the Pudding hidden in the right wall, then jump over to the right to
flick the switch.  Ride the moving platform up to the top of the elevator and
jump left.  Blast the Blue Blooglet and grab the Blue Gem from him.
	Take that Gem and head to the right to head through the Blue Door.  From
the Door get up to the platform above, stun the Blooguard, and flick the switch.
Continue left, pogo up to the ledge above, and up to the pole.  Slide down the
pole, grab the ammo, then jump up to the switch to toggle it.  Drop down two
levels to get to the pole below (watching out for the Ceilick) and flick the
switch down the pole.  Fall down one floor (past the Blue Door), and head right.
Pogo up to grab the second Red Gem.
	Return to the foot of the tower and head left.  There will now be a
moving platform controlled by a Bip, use it to grab the Green Gem and then ride
the moving platforms back up the elevator shaft to the Blue Door.
	Wait next to the switch above, and use the moving platform to go up to
the switch above, and open the Green Door and flick the switch inside.  Grab the
Pizza Slices and Ice Cream Bars, and ride the moving platform up as high it will
go.  Head left, taking out the Fleex that guards the way, then use the moving
platform to jump up to the left.  Open the second Red Door, flick the switch,
and right the moving platform to the left to collect your prize: What's this?
Cool!  A  Passcard for the Bloogstar Rocket!  (It can fly through their force
field.)

	Now that we've collected everything we need for the journey, head up and
smash through Guard Post Two.

	GUARD POST TWO: This Guard Post is a decently sized level containing
many secrets both high above and down below.  From the entrance, pogo up into
the tree above, grabbing Vivas and some ammo, and into the entrance on your
right.  Blast the Blooglet and Blooguard and head right, carefully falling
beside the plasma orb for a Pizza Slice.  If you're confident in your jumping
skills, you can ride the moving platform to the right for additional points, but
it'll soon dead-end and eventually you'll need to make your way back out the
arch and drop down to the Guard Post's main entrance below.  Watch out for the
Blooguard guarding the entrance, and then fall down to the left to flip the
switch in front of the Yellow Blooglet.  Return back to the main entrance, jump
up to the right, and ride the moving platform up to the Red Blooglet.  Stun the
Blooglet and grab the Red Gem and Root Beer Floats that he guards.
	Gem in hand, head back down and to the right this time.  Grab the Root
Beer Float above the Yellow Blooglet, zap the Bloog, and flick the switch.  Head
right and ride the moving platform over to the other side of the deadly chasm.
Make your way through the Red Door on the right and up to the Yellow Blooglet to
get the Yellow Gem that he holds.
	With the Yellow Gem, go back to the chasm's edge and pogo up to the
ledge on the left.  Go left, stun the Blooguard, and head left and right,
working your way up the interior of the structure, avoiding enemies and grabbing
goodies as you go.  You'll soon see the Yellow Gem's socket.  Blast the Red
Blooglet and Blooguard, and place the Yellow Gem to open the Yellow Door below.
Work your way back down, head through the Yellow Door and out the arch on the
other side of the Guard Post.  Once again, jump into the tree for some Vivas and
a Pizza Slice up top, and then jump right, out the exit.

	With another Guard Post out of the way, head up and seek thrills in
Bloogville.

	BLOOGVILLE: From the entrance head right, activate the switch, and ride
the moving platform up the shaft.  Head to the left and down, and begin on a
high note by grabbing the Red Gem (though watch out for the Ceilicks above you).
	Red Gem in hand, head back to the right (you can also jump up to the
left to head towards a hyper-dangerous area full of goodies and death, but I
won't be helping you there) and jump over to the other side of the shaft.  Fall
down the gap for some delicious Banana Splits, and then jump up to the right to
flick the switch above.  Jump back to the moving platform and ride it up top to
the Red Door.  Go through the Door and jump into the right wall for a hidden
Pizza Slice.  Head right, flip the switch down, and double back to grab the
goodies that were behind the electric arc.  Now return to the switch, flip it
back up, and then jump off of it with your pogo stick to get to the platform
above.  Jump onto the rotating platforms and take them around to the right side,
don't forget the Pizza Slices above!  Jump out of the arch onto the branches of
the nearby tree.  Grab all of the goodies that you can around the tree, work
your way down on the right side, and grab the Yellow Gem!
	With the Gem, try using the Impossible Pogo Trick to make your way back
up the way you came.  If you're having a hard time doing that, just head left
and take the moving platform back up to the Red Door.  Take the rotating
platforms to the left, avoid the Ceilick, and hop to the upper platform.  Watch
out for the Gik and head through the Yellow Door.  Flick the switch you've
unlocked, head down to the left, and then run right to grab the Blue Gem.
	Head back to the rotating platforms and take them over to the right once
again.  Jump down past the trees, head left, and drop down to the level below.
Head right, and watch out for the dangerous Gik that will get in your way.  Drop
down once you get to the edge of the platform, open the Blue Door, avoid the
Ceilick and grab the Green Gem.  Now that you have the Gem, drop back down to
ground level and head right through the Green Door and to the exit.

	With that town out of the way, head right.  Put the Grabbiter to sleep
with the Stupendous Sandwich, continue to the right and rocket into the Bloog
Aeronautics and Space Administration.

	BLOOG AERONAUTICS AND SPACE ADMINISTRATION: It's a Fleex infestation!
I hope you like horizontal travel because in BASA you'll be moving mostly from
left to right.  From the entrance head right, jump up to the switch on the upper
right, flick it and ride the moving platform over to the left to collect the Red
Gem.
	Red Gem in hand, drop down to the right, flick the switch you run into,
pogo up above the pole to find some hidden treats in the ceiling, and slide down
the pole to the Red Door.  Go through the Red Door, watch out for the Gik, and
use the moving platform to get the Yellow Gem.
	Climb back up the pole, watch out for the Gik, and head right through
the Yellow Door.  Head right through the electric arcs to grab some good stuff,
and then climb up the pole and head to the right.  Flip the switch and jump on
the moving platform to take a ride on the moving platform into the wall and down
to the left.  Ignore the first switch for now and ride over to the second
switch.  Flip the second switch, run across the newly formed bridge, getting all
the Ice Cream Bars you can, and then pogo up to the first switch to flick it as
well.  Run over to the right and jump up the landing.  Avoid the urge to flip
the switch, and jump onto the Gik's back.  Ride him over all of the radioactive
waste to get some Puddings and Ice Cream Bars, and then jump over to the right
side and climb up the pole.  Kill the Fleex on the left from a safe distance and
then hop over the gap and head left and up.  Up on the next level, head right,
but watch out for the Orbatrix, he's invincible and has a strange attack
pattern.  Get the Green Gem at the very right and then head back over to the
pole.
	Climb down both poles and head right, go through the Green Door.  Work
your way up and around and grab the Blue Gem.
	With Blue Gem in hand, you're ready to escape from BASA.  Climb back up
the pole and head to the right.  Blast the Fleex and unlock the Blue Door.  With
that out of the way, run out the Blue Door and exit!

	Alright, we're almost ready head into space for the final showdown.
First though, head left and boldly assault Guard Post Three.

	GUARD POST THREE: From the beginning, head right, zap the Blooguard, and
drop down to the left to grab the Red Gem.
	With the Gem in hand, jump up to the Red Door, open it, and run through.
Head up and to the right for some goodies, and then back over to the left.  Flip
the switch, then head back to the arched entrance of the Guard Post and jump up
to the moving platform.  Climb up the pole at the top, run left, flip the switch
and grab the goodies nearby, and then drop down into the pit.  Zap the Yellow
Blooglet for the Yellow Gem, flick the switch, and head back up to where the
Blooguard was.
	Run right, through the arch, and wait for the moving platform to come
back up for you.  Ride the moving platform down (or jump up to the Pizza Slices
on the right) and fall down on the left side of the now open pit in the ground.
Flip the switch and grab the goodies, then jump across to the right into the
lower structure of the Guard Post.  Hit the switch and drop off the right side
while hugging the wall to grab some hidden goodies.  Jump back up and ride on
the moving platform to get some Vivas.  Be warned though, it will slide into the
red rocky wall on the right, so make sure you hold RIGHT as you approach it to
avoid death below.  Head back to the left and ride the moving platform back out
of the pit.  (An interesting sidenote: you can fall down along the right side of
the wall into the slot where the moving platform was originally hiding in order
to snag three Queen Vivas.  The only problem is, it's very difficult to get out
without dying, so it's probably not worth the effort to get a couple of extra
lives.)  From the top of the pit, head right, back up through the Red Door, and
up to left to go through the Yellow Door.  Blast the Blooguard and hit the
switch that he was guarding.  Ride the moving platform up to the arch on the
left and stun the second Green Blooglet to get the Green Gem.
	Now that you have the Gem, head back through the Red Door and drop down
to open the Green Door and head over to the right, cross the bridge, grab the
Bloog Soda with a Cool Jump, and head out the exit.

	Guard Post out of the way, jump into the rocket, fly up to the space
platform, the run down to whoop it up at Bloogbase Recreational District.

	BLOOGBASE RECREATIONAL DISTRICT: Eat at Joe's!  From the entrance head
left and flick the switch, but watch out for the Bipship, its shots will make
quick work of you.  Climb down the pole and drop down to the level below.  Blast
the Red Blooglet to get the Red Gem, and head left into the Red Door (watching
out for the Babobba) to get the Yellow Gem.
	With the Yellow Gem, head back up to the pole and go left to open the
Yellow Door.  Go down the slope, flick the switch up, and jump into the right
wall for some monster points.  Head back to the pole, and jump up through the
newly opened hole above.  Head left, watch out for enemies (including the slow-
moving Blorb), and flick the switch, and jump onto the moving platform that
comes down to get you.  As the platform reaches the top of its ascent, perform
the Impossible Pogo Trick into the air on your right.  You'll land on an
invisible platform!  Run to the right and head through the door.  Six extra
lives!!!  Take your reward and head through this hidden exit.

	Alright!  Almost time to save Molly, but we're not done having fun at
the Bloogbase just yet!  Head up and purposefully strut into the Bloogbase
Management District.

	BLOOGBASE MANAGEMENT DISTRICT: From the beginning, grab all the candy
around you and head left.  When you get to the edge of the floor you're on, drop
down to the right, into the wall.  Jump around and continue right and you'll get
some great hidden treats, including Pizza Slices and Banana Splits.  Once done
there, jump left across the dangerously uncooled radioactive fuel rods to the
Bloog Soda spelling out ID in the Standard Galactic Alphabet.  Look down, and
drop to the switch when it's safe to do so.  Ride the moving platform up, pogo
up to the left, and drop down on the other side.  Carefully work your way across
the yellow platforms over to the left, across the bridge, and pogo up to the
ledge above using the falling platform.  Make your way left and up to the ledge
above.  Flip the switch and drop back down to the bridge that you just crossed.
The bridge will be gone, so flip the switch that was underneath it and go up
right back where you came from.  The bridge up top will now be activated, so run
across it and jump off the falling platforms to the right.  Grab the goodies,
flick the switch that you encounter on the other side, and drop down.  Head over
to the left, jump across the electric arcs, and run out the exit.

	With the Districts out of the way, run left THROUGH the Bloog Control
Center and wait against the railing.  Very soon a satellite will come by to take
you to the secret level!  Once there, warily enter Blooglab Space Station.

	BLOOGLAB SPACE STATION: Ah, the secret level.  Head right, grabbing the
goodies, and run through the arch into the station, jumping into the small wall
on the right for some points.  From there, jump up to the left to grab some
goodies, and then head right and start climbing down the pole.  Go through the
arch on the left, zap the Yellow Blooglet for the Yellow Gem, and climb down to
the bottom of the pole.
	Head left through the arch and drop down.  Ride the moving platforms on
the left to grab some Pizza Slices and a Queen Viva, then go through the Yellow
Door on the right.  Climb up, flick the switch above, then drop down and head
right to grab some treats and, more importantly, the Blue Gem.
	After getting the Blue Gem, go back up through the arch and open the
Blue Door.  Ride the moving platform up into the roof and immediately jump to
the right.  You'll drop down into a secret passage head left to find some ammo,
monster points, and a translation of the Standard Galactic Alphabet!  Once
you're done here, flick the switch and ride the moving platform back up to the
Green Gem.
	After grabbing the Gem, climb back up the pole and head right through
the Green Door.  Flip the switch up, take a ride on the moving platform as far
as it will take you, climb down the pole, and head out the exit!

	Finally, it's time for a showdown with the Bloogs.  Jump back on the
satellite to return to the Bloogbase and bravely enter the Bloog Control Center,
looking for Molly.

	BLOOG CONTROL CENTER: From the entrance of this dark place, activate
your pogo stick, bounce off the switch, and land back safely on the right.  Jump
onto the moving platform that will come your way, jump over the plasma orbs, and
land next to the door.  Look down.  You see that Blue Blooglet down there?  He
has the Blue Gem.  Blast him and grab it.
	After grabbing the Blue Gem, pogo up and head through the door.  The
Green Blooglet you see running above you has the Green Gem.  Head right, jump to
the platform above, make your way safely across the pools of radioactive waste,
and zap the Blooglet to get it.
	Green Gem in hand, go back down below and enter the first doorway (the
one you came in through).  What the...?  This room looks exactly the same as the
last!  But wait, there's a Yellow Blooglet above and he has, unsurprisingly, the
Yellow Gem.  Once again make your way up to the Blooglet, stun him, and this
time get the Yellow Gem for your efforts.
	With the Gem in your possession, drop down and enter the third doorway
(that is, third from the left).  You'll now drop down a chute into dangerous
territory.  Ignore the pole (though pogo into the roof above it for some points)
and head right, watching out for the electric arc.  Watch the spinning red
platforms for a moment to get their timing down, and then jump up first to the
Banana Splits on the right, and then over on top of the eyeball on the left.
Jump across the arcs when it's safe to do so, and run through the doorway.  Oh
boy, a room full of Red Blooglets.  Use the poles to safely make it past the
sentry gun, and run into the flood of Blooglets.  Hopefully you have a lot ammo
to spare, or it'll be tough going.  If you are running low, just make sure to
watch out for the Ceilicks along the lower path.  The Red Blooglet you're
looking for is one of the two at the upper-left.  Blast them and you'll gain
possession of the Red Gem.
	With all four Gems, it's now time to save Molly.  Blast the Blooguards
and jump up on the right-most eyeball, blast the Blooglet, and head through the
doorway when it's safe.  Coming out the other side, head right and flip the
switch.  Jump up the claws and take the moving platform over to the left.
Bounce off of the switch over to the eyeball next to it, and blast the Blooguard
guarding the Gem sockets.  Place the Gems in the appropriate sockets and use the
moving platform that passes by to get some last-minute Pizza Slices and ammo at
the very upper-left.  Use that same moving platform to head right get up above
to the Doors.  Ignore the doorway with the big NO sign next to it, head left
through the Doors and save Molly!

	Sit back, relax, enjoy the dialogue, (possibly) learn some shocking new
things, and give yourself a cookie for having completed the final Commander Keen
game for the PC!


[9.8] How do I get through Commander Keen?
	Well, it looks like Mort is at it again, causing trouble in the
universe!  Let's go put a stop to his plan.  As a bonus, each level begins with
the level summary found in the Commander Keen manual!

	You start off on the Omegamatic Warp Drive.  Head down and to the left
and teleport to Droidiccus Prime.  From there enter into the first area.

	ROBOT HIVE: 'A huge factory with high-tech robot construction equipment.
As you'd expect, your main enemies are an assortment of robots with varying
intelligence.  They buzz around like bees and are looking for heroes to sting!'
	Well here we are in the first level of Droidiccus Prime.  Start off by
getting used to the unusual controls.  Practice pogoing, jumping, and shooting.
Once you're comfortable with it head over to the left.  Take out the robots that
stand in your path and jump up to the platform with a tipped toxic barrel.  Wait
a moment and a moving platform should come to you.  Grab it and head right.
After reaching the end of its journey, go up and flick the switch.  Once you've
flicked the switch, head back as far left as you can go and you will see a small
platform.  Jump onto it and it will begin to rise, heading toward the Yellow
Key.  Grab the Key and head right, pogoing up past where you originally
teleported in.  Watch out for the Cyba-Mallow and Droids as you work your way to
the right.  If you're in the mood for points, the path above definitely
provides.  Eventually you'll make it to a pole.  Climb down it and jump over to
the spikes on the right.  Once again, carefully work your way to the right,
avoiding (or eliminating) any opposition. After riding a moving platform, you'll
come to a bizarre hazard of metal shuttles that zip up and down.  After passing
them and going a little farther right, you'll find some platforms that try and
move you into spikes.  Jump past them quickly and you'll find the Yellow Door.
Pass through the Door, head right, and you'll find the teleporter which will
take you to the next part of the level.
	Coming out of the teleporter, head left.  Ignore the hint that points
you in the other direction and go up to flip the switch.  This will activate the
moving platforms that you'll need to use for the rest of the level.  Use these
platforms to work your way to the right, constantly collecting goodies and
avoiding death.  If you find that some yellow boxes are blocking your path,
shoot them!  These Shootable Blocks will fall down and open the way for you.
You'll eventually come to a seemingly impassable pit of spikes (right near the
crazy clock), but if you just wait a moving platform will come to get you.
Take it and pogo to the other side of the pit.  Keep heading right, jump over
the pole, and you'll get to a hint of an Up-arrow.  Shoot at the boxes above
your head and use them to reach the upper path.  Take this upper path to the
right, and ride a movable platform above the chain.  You will now probably see
and extra life just out of reach.  Shoot up while behind the pillar and a
Shootable Block will drop, allowing you to get the life.  Keep heading right and
up, and you'll finally see the exit teleporter, guarded by a Sentry Droid.
Sneak past the Droid and finish the level.

	Head up the path, and it's off to the Fiery Canyon!

	FIERY CANYON: 'This dark and shadowy cavern is full of fire pits,
falling platforms, Fire Imps, and moving platforms.  Be careful where you jump!'
	Hmm, there's a weird tribal theme going on here.  You start off with the
Green Door on your right, so head to the left to begin your exploration.  Make
sure to keep to the upper path, as below is fraught with danger.  If you manage
to make it all the way to the upper left, you'll find a teleporter, take it and
you'll find yourself in the next section of the level.
	Head to the right.  You'll find yourself waiting for a lot of baskets in
this section of the level.  Entertain yourself by collecting all the goodies
scattered about.  Eventually, after many basket trips over fire, you'll find the
Green Key.  Grab it, and head back the way that you came.
	Coming out of the teleporter, head down and to the left and flick that
switch that you come upon.  Now head all the way back to the right, taking care
around the Fire Imps, Doods, Dargs, and Droids, and go through the Green Door.
Head to your right and ride the basket over to the other side.  Go up and ride
the green moving platform for some extra points, and then keep going right.
You'll soon come to a huge pit of fire and a yellow moving platform.  Ride it to
the right, grab the extra life, and then come back and head downward, avoiding
the Droidican Elite, and go through the teleporter.
	Coming out of the teleporter, head left to collect some goodies, and
then go back over to the right.  You'll ride a basket over to the right (watch
out for the Elite!) but it'll stop mid-way!  Get up on the platform and pogo
over to the right, aiming to land between the edges of the big pillar in the
background.  Beware the Fire Imp and then head right.  There's the exit!

	It's time to get a Plasma Crystal!  Head up and attack The Imperial
Palace!

	THE IMPERIAL PALACE: 'It's the third level in the world of Droidiccus
Prime and things are getting tricky.  To complete this level, you'll have to
face the Droidican Emperor.'
	From the entrance, head to the right.  Blast the
Shootable Block to create a platform to jump up to the flasks on the left.  Mega
points!  Climb down the pole and prepare to perform the most difficult jump in
the game.  You need to pogo to the right, over to the flag on the other side.
If you don't launch off the very edge of the platform, however, you probably
won't make it.  Once you get to the Yellow Door, work your way left and up, and
flick the switch.  From there work your way back to the beginning of the level.
Head left, climb the pole, and then head to the right.  You see that small
yellow almost star-shaped platform?  That's your target!  Jump on it and ride it
down between the gap below.  Flick the switch on the right and jump back up.
From here, follow the hint and head left.  Climb the second pole, continue left,
and then flick the switch.  After that you're ready to head right into the
teleporter.
	Coming out, head left, grab the points, and then drop down the gaps in
the middle of the platform structure that you come upon.  It's the Yellow Key!
Grab it and head back to the teleporter.
	Back in the main room, head over to the right again, across that
difficult jump, and through the Yellow Door.  Head right, grabbing the points
and pogoing up for an extra life, shooting at your enemies.  Head into the
teleporter and prepare for your battle with The Droidican Emperor in the Royal
Chambers.
	The Droidican Emperor is a fairly simple boss to beat.  Jump over to the
green button on the left and push it whenever he's underneath the jet in the
middle.  Blast the robots that he teleports in, and stand to the right of the
button when he tries to throw poison at you.  He'll be scrap in no time!  Claim
the Red Plasma Crystal and teleport out.

	Head back to the Omegamatic Warp Drive and take the right teleporter to
Shikadi.  It's time to roast some mushrooms!

	FOREST O' CRAZY MUSHROOMS: 'Oversized alien mushrooms are all over this
level.  Commander Keen must also avoid the deadly slugs that compete with the
mushrooms for the sparse sunlight on this strange planet.'
	From the entrance, make a quick left for some goodies and then head to
the right.  Watch out for the Berkeloids, Poison Slugs, and collapsing ground
as you head toward the twisting trees.  Stand on the large fungal protrusions
and jump over to the teleporter.
	Once you pop out of the teleporter, head left for some goodies and then
head down below the teleporter.  Once you reach the bottom, wait at the hint
arrow that points right.  Eventually a moving platform will come for you.  Jump
on it, avoid the Shikadi Sentries, and grab the Red Key.  Head up, collect the
points up in the trees, and then head back to the teleporter.  (Note: You can
actually pogo from the right edge of these trees over to the right and skip part
of the level, but it's kind of a difficult leap and really doesn't save too much
time.)
	Out of the teleporter continue trekking right, and you'll soon find
yourself at the Green Door.  Climb down the pole, claim the Green Key, and go
through the Door.  Head to the right, grabbing point items and avoiding enemies,
and then jump into the teleporter on the top level (pogo on the Bounder if you
find yourself below it).
	Popping out of the teleporter, head right and into the trees.  Make sure
you always find safe footing on the platforms!  You'll soon find yourself at yet
another platform.  Jump into it and you'll find yourself right above the Red
Door.  Head right while staying on the upper path and you'll soon run into the
teleporter that gets you out of these insane woods!

	After the forest we have to deal with some mines.

	THE PLASMA CRYSTAL MINES: 'The whole place has been littered with robo-
mines, making it tricky to negotiate the maze-like tunnels and inlets where the
Shikadi harvest plasma crystals.'
	Personally, I find this to be the most difficult of all the levels,
mostly due to the fact that the deadly fire chutes blend very nicely into the
background.  But there's no way around it!  We have to go through these mines!
From the entrance head left, always avoiding the fire!  If you want to get the
Small Crystals, hit the Shootable Block and use it to pogo up there.  As you
head left, you'll soon encounter a switch.  Flip it and head up for some points.
Now head back over to the right, grab some Small Crystals and watch out for Robo
Red!  Keep on going until you see some platforms heading up and to the left.
Jump up these platforms and head left to grab the Red Key.  Head right to the
Arachnu and use the moving platform to pogo up to the next level.  Continue
right and you soon find yourself at the Red Door.  Blow through it and keep on
going and you'll soon reach a teleporter.
	On the other side of the teleporter, head right, go up, and grab the
Yellow Key.  Go left, through the Yellow Door, and follow the path to the
switch.  Flip that switch and then run back to the Door.  Jump on the little
platform to get up to the extra life, and then go right and up to where the
Yellow Key was.  The other small platform will now also go up, so jump on it and
head to the right and up.  When you come upon the extra life, knock down the
Shootable Block and pogo from the higher ground towards it.  From there keep
heading right and you'll find yourself at a chasm that can only be crossed by
using the small moving platforms.  Time your jumps carefully, and move your way
to the right.  Once back on safer ground, continue right avoiding the fire pits
and Shikadi Sentries, and you'll soon find the teleporter out of there.

	Only one level remains here on Shikadi.  It's time to go into space!

	SHIKADI IN SPACE: 'Commander Keen is beamed aboard the Shikadi
Spacecraft for a showdown with the Shikadi Overlord.  He'll hunt you down and
blast you to smithereens with his rocket launcher so you'd better be ready for
him.'
	Watch your step as you come aboard!  That dangerous looking beam above
you IS dangerous!  Head right and down into the teleporter that you'll soon
come across.  Collect all the Rockets and jump up to the right to flick a
switch, then head back through the teleporter.  If you want to grab some extra
points, from here head all the way back to the entrance.  If not (or if you've
been there and back again), head down and right from the teleporter, making your
way over and up until you see a Shootable Block.  Knock that sucker down and use
it to jump up there and snag the Yellow Key.  With Key in hand, head back down
and take the moving platforms to the right and up to the teleporter.
	From the teleporter, head right across the dropping green platforms.
Head through the Yellow Door and hit the Shootable Block above you to be able
to pogo on top of the Door and ride a moving platform to an extra life.  With
that done, it's time to head into the teleporter for a Shikadi Showdown.
	The Shikadi Overlord is probably the easiest of the three bosses.  
Touching him won't kill you, he telegraphs his moves, and you have lots of room
to maneuver if he does manage to get a shot off.  Just stay under him and shoot
his eye when it glows.  Without too much of a fight he'll be defeated and the
Blue Plasma Crystal will be yours!

	Only one more world to go!  Head back to the Omegamatic Warp Drive and
up to Fribbulus Xax.  Go up to the lake and we're ready to go!

	BLOOGLET LAKE: 'This swampy lake-land is infested with deadly creatures,
but some are harmless.  The water in this lake contains some nasty surprises, so
you'd better time your jumps right!'
	Ignore the writing on the wall that tell you to go right and head left.
Avoid the enemies and admire the drawing of a Dopefish on the wall.  Continue
onward until you hit the Danger sign.  Stand on the small island next to it and
wait for a small wooden moving platform.  Jump on it and right to the left to
grab the Green Key.  Head up and left for some goodies and an extra life, or
just head back to right to continue on your journey.  After going to the right
for a while, you'll run into a switch.  Flick it, and ride the wooden platform
to the right, making sure to avoid the dangerous solid platform that will push
you off if you're not careful.  Head through the Green Door and over to a pit of
spikes.  If you get to the edge of the pit, you'll notice a Shootable Block.
Knock it down and pogo over to it (make sure to not back up too much, or the
Block will bring itself back up and you'll be pogoing straight into a bed of
spikes).  Head to the right, avoid the leaping Dopefish and jump into the nearby
teleporter.
	If that Gik below is jumping right into you, be sure to mash the SELECT
button to teleport back-and-forth until you find yourself in relative safety.
Head right past the Bloog and Dopefish, and jump onto the moving wooden
platforms.  Keep heading right, and when you get to the Shootable Blocks, hit
the first one and pogo onto the second to snag the life and get across.  Once
you get to the pole, climb up it and continue right and up.  It looks like
you've come to a dead-end!  Look carefully though and you'll see a wiggling
cloud with candy on it.  Jump over to it, and continue on the path of wiggling
clouds until you get on solid ground.  From there, it's a simple task of heading
right and soon finding the exit.

	Almost there!  Head up and into the fortress that lies ahead.

	BOBBA FORTRESS: 'This fortress has so many traps, guards, and intruder
deterrents; it'll be super-hard to get out alive.  Keep your eyes on the
ceilings, walls, as well as the floors, and you might make it through.'
	Welcome to what is easily the most frustrating level in the game.  Begin
the torture by grabbing the goodies around you and heading right.  As you come
toward the second brick structure, notice that there is some candy above two
little green platforms.  This will become important a little bit later.
Continue right, and you'll soon come to a much bigger castle-like structure with
some more little green platforms, along with a little red one that appears out
of the wall.  It'll be these red platforms that will drive you crazy later, so
practice jumping on this one now.  Head to the right and down, watching out for
the Bobba and Nospike.  Continue right, past various enemies, points, and a
pole, and you'll soon find yourself at a castle with some dangerous looking
chained spikes.  Avoid the trap, go right, and head downward, grabbing some keys
as you go.  Once you've made it as far down as you can go, head left and take
the moving platform across the spikes to the Yellow Key.  Armed with the key,
head back up where you came from and head right through the Yellow Door and into
the teleporter.
	From the teleporter, head right and up to the platform that has a left-
facing axe.  Soon enough a moving platform will come towards you.  Take it and
go along the upper path past the Nospikes.  It's the Green Key!  Grab the Key
and wait for another moving platform to come to you.  Get on it, head to the
right, and after grabbing all there is to get up there fall down.  As you move
right you'll run into a big axe, some of those red platforms that go in and out
of the wall, and the most frustrating point in the entire game.  I hope you've
saved up some lives and continues, because you're most likely going to be using
them to get past this part.  The idea is to jump from one red platform to the
next to get to the right side, and then go up and double-back, working your way
up to the top.  As long as you're patient and only jump once your platform has
begun to move into the wall, you should be able to get past this deadly skill
puzzle (all that awaits below you is a bottomless pit).  The hardest part is
jumping up to the last two red platforms, as it requires you to use your pogo
stick, which may throw off your rhythm.  After making it to the top, get onto
safe ground on the right and flick that switch.  Head right and wait at the axe
for a moving platform to take you above the barrier.  Jump over on the right
side of that barrier, hugging the wall to avoid the antenna's shots, and head
right through the Green Door.  Keep going right, taking the upper or lower path
(or both), defeating enemies, collecting goodies, and making your way over
obstacles, and you'll soon find yourself at the teleporter that exits the
Fortress.

	It's time to grab that last Plasma Crystal!  Prepare yourself, and enter
the Techno Lab.

	TECHNO LAB: 'What's worse than the Bloogs you've just defeated? The
ROBO-BLOOG of course!
	'This guy is the last enemy on this world and if you can defeat him you
may just be able to save your planet.  Watch out though, Robo-Bloog has the
brain of an evil super-computer and can outsmart almost any being.'
	This is it!  From the beginning, head to the left, up, and back over to
the right.  Flick the switch that's guarded by a Blooguard and then head down
and to the right.  Keep on going right, and keep on the lookout for the second
strange Keen-like worm thing in a blue tank in the background (not the one
that's above a blue platform).  Right below this abomination you'll find the Red
Key!  Continue to the right, past multiple enemies and goodies.  In time you'll
come to what may appear to be a dead-end with an arrow sign pointing to the
right.  Trust the arrow and pogo off to the right, continue in that direction
(watching out for a collapsing floor that hides an extra Keen directly above it)
and you'll find yourself at the Red Door.  Rush through it, and before entering
the teleporter make sure that you go to the right and up in order to grab the
extra life that's on top of the Red Door.  You may very well need it!  Once
you're ready, prepare yourself, take a deep breath, and jump into the teleporter
to face the Robo-Bloog.
	The Robo-Bloog is undoubtedly the most difficult boss in the game, but
he follows a predictable pattern and can be easily defeated.  He start off,
however, with a cheap-shot.  He will shoot at you as you teleport in, so
immediately move to the right to avoid certain death.  What you need to do with
the Robo-Bloog is avoid the shots he fires and push the big red button up top.
Every time you hit the button, the Robo-Bloog will shoot at you and begin
walking towards you. Both he and his shots will kill you and, as with the other
bosses, dying will reset their hit points, so learning to avoid danger is
crucial to finishing this fight.  As well, every time you hit that button he
adds another shot to his arsenal.  So as you come in, he will shoot at you once.
Hit the button and he we shoot at you twice.  Again, and he'll shoot at you
three times, etc.  After he's fired his shots, though, he has to go back to
recharge at his terminal.  This the time that you need to push that button!
Personally, I find the best way to avoid the shots is by pogoing left and right
in an arch patter around them.  You'll have to find what works best for you, but
continue zapping the Robo-Bloog with that button and he'll soon crumble.  Get
the Yellow Plasma Crystal and teleport out.

	You've saved the Earth and destroyed the Omegamatic Warp Drive!
Congratulations!  Enjoy the end-game cutscene, give yourself a pat on the back
for having finished all of the Commander Keen games, and then head on over to
Section [11] to find out where to go next!



----------------
[10] The Endings
----------------
The Endings!  I strongly suggest you actually experience the endings of each of
the Commander Keen games for yourself, just having the words isn't the same.
Read on, not much more to go!


[10.1] What's the Ending to Marooned on Mars?
	Commander Keen returns to the Bean-with-Bacon Megarocket and quickly
replaces the missing parts.  He must get home before his parents do!

	Keen makes it home and rushes to beat his parents upstairs.

	Shhh, honey...let's see if little Billy is asleep.

	Billy...?  Are you a--WHAT IS THIS ONE-EYED GREEN THING IN YOUR
ROOM!!!!???

	Aw, Mom, can't I keep him?

	Well, we'll talk about it in the morning, son. you get some rest.

	OK, Mom.  Goodnight.

	Goodnight, dear.

	But there is no sleep for Commander Keen!  The Vorticon Mothership
looms above, ready to destroy Earth!

	TO BE CONTINUED....


[10.2] What's the Ending to The Earth Explodes?
	After disabling the weaponry of the Vorticon Mothership, Billy heads
for Earth.  Even great space-heroes need a nap after defeating a vicious horde
of violence-bent aliens!

	The Vorticon ship limps back toward Vorticon VI to tell of their defeat
at the hands of Commander Keen.  The Grand Intellect will not be pleased.

	Wake up, Billy.  It Snowed last night!  There's no school!

	Wonderful, Mother.  That will give me time to rid the Galaxy of the
Vorticon menace and discover the secret of the mysterious Grand Intellect!

	Ok, hon, but you'd better have a nourishing vitamin fortified bowl of
Sugar Stoopies first.

	Ok, Mom...

	TO BE CONTINUED....


[10.3] What's the Ending to Keen Must Die!?
	No...

	It can't be!

	Mortimer McMire!!!

	Mortimer has been a thorn in your side for as long as you can remember.
Your IQ test score was 314--Mortimer's was 315.  He always held that over you,
never letting you forget for one day.

	All the practical jokes, the mental cruelty, the swirlies--each memory
makes your teeth grit harder.  And now he's out to destroy Earth!  You have
had enough!

	"All right Mortimer, what's the problem?  Why destroy Earth?"

	"You and all those mental wimps deserve to die!  I'm the smartest
person in the galaxy.  Aren't I, Mister THREE FOURTEEN!  Ah ha ha!"

	"I'll get you for that, Mortimer!"

	"Come and try!  You'll never get past my hideous Mangling Machine!
Prepare to die, Commander Clown!"

	<Commander Keen then promptly destroys the Mangling Machine>

	With Mortimer McMire out of the picture, and his brain-wave belts no
longer controlling them, the Vorticons are freed from their mental enslavement.

	"Commander Keen, in honor of your meritorious service in freeing us
from the Grand Intellect's mental chains, I and the other Vorticons you haven't
slaughtered want to award you the Big V, our highest honor."

	"Thank you!"

	The End...For now!


[10.4] What's the Ending to Keen Dreams?
	Yes!  Boobus Tuber's hash-brown-like remains rained down from the skies
as Commander Keen walked up to the Dream Machine.  He analyzed all the complex
controls and readouts on it, then pulled down a huge red lever marked "On/Off
Switch."  The machine clanked and rattled, then went silent.  He had freed all
the children from their vegetable-enforced slavery!  Everything around Keen
wobbled in a disconcerting manner, his eyelids grew heavy, and he fell
asleep....

	Billy woke up, squinting at the early morning sun shining in his face
through the bedroom window.  Nothing.  No vegetables to be seen.  Was it all
just a dream?

	Billy's mom entered the room.

	"Good morning, dear.  I heard some news on TV that you'd be interested
in," she said, sitting by him on the bed.

	"What news?" Billy asked, still groggy.

	"The President declared today National 'I Hate Broccoli' Day.  He said
kids are allowed to pick one vegetable today, and they don't have to eat it."

	"Aw, mom, I'm not afraid of any stupid vegetables," Billy said.  "But
if it's okay with you, I'd rather not have any french fries for awhile."

	*"Okay, honey," Billy's mom said.

	*"Uh, Mom, what are we having for supper tonight?" Billy asked.

	*"Oh, we're having liver, dear."
	*"I HATE liver!  I don't have to eat liver.  I saved the earth!"

	THE END

	*(Possibly continued in..."Commander Keen Meets the Meats")

	*Commander Keen will definitely return in...

	*"Goodbye, Galaxy!"

	*Watch for it!

	Note: The lines with * only appear in the first commercial release of
Keen Dreams (v1.0).


[10.5] What's the Ending to Secret of the Oracle?
	Wow, this is really an impressive way to activate this monolith of
ancient wisdom.

	click

	Everyone be silent.  The Oracle is about to speak.

	Hmmm.  Maybe it's got a dead battery or something.

	The Shikadi are a race of shadow beings from the far side of the
galaxy.

	They are building an Armageddon Machine and are planning to blow up
the galaxy with it, then rebuild it to suit their needs.

	They live on the third planet of the Korath system, which is 71,000
light-years from Gnosticus IV.  The Armageddon Machine is almost complete.

	And this is what they look like.

	<Commander Keen makes a number of horrified faces>

	These Shikadi are toast!

	Thanks for the scoop, Oracle.  I'm outta here.

	I hope it doesn't rain on my folks....

	Meanwhile, back on Earth...

	<lightning strikes>

	To be continued...


[10.6] What's the Ending to The Armageddon Machine?
	CONGRATULATIONS

	You have completed "Goodbye, Galaxy!"  Commander Keen has saved the day
once again!

	But things are still in motion . . . .

	With their Quantum Explosion Dynamo in ruins, the Shikadi rush to their
getaway ship and hightail it back to their own galaxy.  *Due to a freak fuse
malfunction, they cannot take off and are arrested by the Korath III Police for
double-parking.

	Keen rummages through the control room of the QED for clues as to why
the Shikadi wanted to blow up the galaxy.  He stumbles upon a note written in
the Standard Galactic Alphabet.

	DEAR BILLY
	YOU FELL FOR MY ANDROID
	DUPLICATE PLOY IN THE MANGLING
	MACHINE AND NOW YOUVE FALLEN
	FOR IT AGAIN
	IM BLOWING UP THE UNIVERSE NOT 
	THE STUPID GALAXY
	THIS WAS JUST A BIG DISTRACTION
	DODO
	TAG YOURE IT
			MORTIMER
	PS GANNALECH IS HOW THESE DUMB
	SHIKADI PRONOUNCE GRAND
	INTELLECT
	OR DIDNT YOU NOTICE THAT MISTER
	THREE FOURTEEN

	Keen takes the note with him to decipher on the long space voyage home,
not seeing anything else of interest . . . .

	<the camera zooms into a football helmet with "MM" on it>

	Back at home after having saved the galaxy, Billy feeds his rain-soaked
parents ice cream and gently shakes them back to consciousness.  Hopefully,
this won't affect his allowance.

	See you Christmas '92 when Commander Keen returns to battle for the
universe!  It'll be the biggest Keen ever!  You won't believe your eyes!

	Thanks for playing!

	*When you do something special in the secret Korath III Base, this
sentence is added.


[10.7] What's the Ending to Aliens Ate My Baby Sitter!?
	"Gee, thanks Billy," said Molly.  "Boy, my brother is gonna get in
trouble for this."

	"Your brother?" Keen asked.  Molly is the older sister of his former
nemesis, Mortimer McMire.  But he was caught in the explosion of his Mangling
Machine . . . wasn't he?  Could he be alive?  "But he's . . . he's . . ."

	"He's in trouble is what he is.  He told the Bloogs to take me hostage.
In exchange, he told them where to find the Stupendous Sandwich of Chungella
IV."

	"Yeah, I've seen it," Keen said.  So, Mortimer's back eh? thought Keen.
"Where IS Mortimer?"

	"Oh," said Molly.  "He said something about blowing up the entire
universe or something.  Well, let's get back before your folks get home."

	"Yeah, we'd better--THE UNIVERSE?!" Keen said.  "Yikes!"

	See you next time, when Commander Keen and Mortimer McMire battle for
the universe!

	Thanks for playing!


[10.8] What's the Ending to Commander Keen?
	<Keen teleports to safety as the Omegamatic Warp Drive is destroyed>

	<Keen runs toward Mortimer McMire near the Bean-with-Bacon Megarocket>

	The Omegamatic Warp-Drive is destroyed for now, but next time you won't
be so lucky Mr. 314!!!  I'll always be one step ahead of you!

	<Mortimer teleports away>

	But I stopped you this time Mortimer.  And I'll still make it home for
Dinner!

	Congratulations

	You have defeated the Droidiccus, Shikadi and Bloogs of Fribbulus Xax
and destroyed the fabled 'Omegamatic Warpdrive'.

	Thanks to you, the world is safe once again.

	But with your arch-enemy 'Mortimer McMire' still at large, who knows
when Commander Keen will be called on again...



--------------
[11] Now What?
--------------
So.  You've finally reached the end.  Congratulations!  You may now be asking
yourself "What should I do next?"  Well the first thing you should do is head
over to the Public Commander Keen Forum (http://www.pckf.com), home of the
Commander Keen community on the net.  Want to find out more in-depth Commander
Keen information, download Keen mods, or access the repository of all current
Commander Keen knowledge?  Then you need to go check out the KeenWiki 
(http://www.shikadi.net/keenwiki)!  And hey, if all else fails just type
'Commander Keen' into your favorite search engine and sees what shows up!



----------------------
[12] The End of it All
----------------------
Well here we are, over ten years since I first started (and published) this FAQ,
and some four weeks after the 20th Anniversary of the Invasion of the Vorticons
trilogy.  It's been a lot of fun going back, writing the walkthroughs, making
minor updates here and there, and finally truly acknowledging the existence of
Commander Keen for the Game Boy Color.  It is, of course, kind of silly that a
grown man should be playing these games and writing these things, but at the
same time Commander Keen was a very important part of my childhood, and the FAQ
has been a small way that I could help others experience the joy that I have.

As it says in section [1.13], this will be the final version of my FAQ.  The
KeenWiki has practically made it obsolete, and to be honest, sharing information
through text documents is way past its prime.  Besides, very few people are
interested in what a twenty-five-year-old man has to say about a twenty-year-old
game to begin with.

So did you like it?  Hate it?  Have questions, comments, or concerns?  Shoot me
an e-mail at flaose@hotmail.com, it should be valid for at least the next ten
years (unless something totally takes the place of e-mail), and I'll always
respond (unless I can't figure out what you're trying to say).  Most of all,
thanks for reading!  I hope that at least in some small way, I've helped you
find more appreciation for this classic side-scrolling series.


	-Dave



---------------------
[13] Acknowledgements
---------------------
These are all the people that have helped me along the way and inspired me.  If
I missed you, I apologize in advance, just don't attack me with a trout for it!

First and Foremost, Tom Hall - How could I not thank this guy?  He's the Big
Brain behind Commander Keen, he created him and his universe!  All I can say is,
thanks Tom.

Everyone Else in Alphabetical Order:

Bill Amon - Bill created the first Commander Keen FAQ, and inspired me to make a
better one :)

Adrian Carmack - He may not like it, but he digitized the entire Commander Keen
Universe on the computer screen.

John Carmack - John has held onto the Commander Keen rights all these years (I
think he secretly still loves Commander Keen).

Ben Cruz - One of my partners in crime with cc314.  You know I love ya buddy!

Andrew Durdin - For creating the best utilities to edit Commander Keen with!

Derek Greentree - Creator of the amazing Rise of the Triad FAQ.  He's who truly
inspired me to create this massive document.

Thea Gregory - Thea's been a good friend, helped me when I was down, gave me
encouragement, and kept me from going crazy.

Adam Nielsen - Host of the KeenWiki (an amazing source of Commander Keen info)
as well as gracious host of the very dormant cc314.

John Romero - Created some really great levels for Commander Keen, he actually
answers questions and fan mail!

Joe Siegler - Joe's put up with me over the years, answering my questions,
explaining to me a million times that the Universe is Toast was cancelled by id,
not Apogee, and not getting too crazy about it.  He's a great supporter of
Commander Keen and has an awesome and funny webpage on the Dopefish from
Commander Keen 4: Secret of the Oracle: http://www.dopefish.com/

Geoff Sims - Geoff may be the sole reason Commander Keen's still around today,
the founder of Cerebral Cortex 314, he has inspired many a people and projects.

Tore Stubhaug - My other partner in (cc314 inspired) crime :D

You - For reading this enormous and comprehensive FAQ.



-----------------
*END OF DOCUMENT*
-----------------



+--------------------------------+---------------------------------+
|       _|\_                     |        |\      _,,,---,,_       |
|   \  /    \   Pisces Swimeatus | ZZZzz  /,`.-'`'    -.  ;-;;,_   |
|   |>< |>  OO    The Dopefish   |       |,4-  ) )-,_..;\ (  `'-'  |
|   /  \___/UU                   |      '---''(_/--'  `-'\_)       |
+--------------------------------+---------------------------------+

'I just drew this stupid little fish.' 
	- Tom Hall