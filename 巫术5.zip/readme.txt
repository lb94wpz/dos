Wizardry V FAQ/Walkthrough
Version 1.3
By:
Bryan Landry
http://bryanlandry.cjb.net
sonofdurell@hotmail.com
PLACES THIS FAQ SHOULD BE FOUND
http://www.gamefaqs.com
http://bryanlandry.cjb.net


Contents:
  1. Intro/Disclaimer/ History
  2. Creating a Party
  3. Walkthrough
  4. EndgameSequence
  5. Armor
  6. Items
  7. Spells
  8. Enemies
  9. NPC's
10. Pools and Swimming
11. Character Classes
12. Game Genie Codes
13. Credits/Thank You's

1 Intro:
Wizardry V, Heart of the Maelstrom is a game for the Super Nintendo
Entertainment System. It was released in 1993 and is based on a PC game
of the same name. This game starts you in a maze called "The Maelstrom"
This maze was created by an evil force referred to as "Sorn". I have
been playing this game off and on for years and i have finally beaten
it. All names and other copyrighted words are the property of their
respective owners. This FAQ is my own work,unless noted. I take no
responsibilities for any damages or injury that result from improper use
of this FAQ. If you want to use it, or want to add something, email me
at the above address. I am awating permission for use of actual game
maps, which will be posted on my site as soon as i get them. ALSO This
FAQ is to remain complete if you use it.

6/2/99:
Completed Table of spells, Added Endgame info. Added Thank You/credit
section
6/1/99:
Started Table of spells
5/31/99:
Corrected/Completed Information on Character Classes
5/15/99:
Added section on Pools and Swimming

2 Creating a Party:

Creating a party is the most crucial step to playing the game. Beginners
should use the following setup:
1.Fighter(Fighter/Lord/Samurai/Ninja)
2.Fighter(Fighter/Lord/Samurai/Ninja)
3.Fighter(Fighter/Lord/Samurai/Ninja)
4.Thief (Thief/Ninja)
5.Magic User (Cleric/Lord)
6.Magic User (Wizard)
-My party consists of 1 ninja, 2 samurai, 2 lord, 1wizard.

Notes on character order:

-First, you should arrange it so that all your characters can attack. An
easy way to do this is to give 3 of your characters long-range weapons
and put these 3 in the back.
-Characters with heavy armor should be placed before those with light
armor.


3. Walkthrough

Quest 1: The Orb and The Statue
The maze is long and difficult to memorize. A map is needed to navigate
the convoluted passageways. There is a magic spell that has the same
effect, but magic is best used for other purposes. Magic points are
scarce in this game. The map is an item called the Solemn Statue. To get
it, you first have to have the orb of Llygamyn. What you need to do is
advance your character's levels by fighting the various monsters in the
maze. Once one of your characters learns the Mage spell Dumnapic, use
this spell to find your current location. It is now time to get the orb.
The orb is located at the coordinates(E18,N9) Get Orb, save your game,
and go back to town to rest up and see if anyone gained any more levels.
Now it is time to get the Statue. There are two things that you need to
get the statue: the orb, and 37500 dollars. The Statue can be found at
(E8, N24)
You must purchase it from G'bli Gedook. He has many wise words for you
as well. If he does not wish to speak, give all your gold to one party
member, save the game, quit the party, and restart just the member with
all the gold. Have him go in alone. It is never a good idea to fight
G'bli Gedook or steal from him. He has spells that can kill off your
party very easily. Buy the statue for 25000 dollars, then go to Boltac's
Trading post and identify it for 12500 dollars. If you're wondering how
to get the gold to do this, go
to the vampire statue at (E20, N27) and repeatedly give the wrong answer
to fight the bats. These are the best sourse of experience on the level.
By the way, the correct answer is "Vampire." The correct answer reveals
a door. In this area, you can meet Ironnose the Dwarf. I met him at
(E16, N28). you need to buy a key from him for $300. Charming him works
well. BEWARE! there is an enemy in this area(E15, N23) known as a
"living rock" He packs quite a punch. If you do beat him, he leaves a
mace. After raising your level high enough that you have 6 uses of
Dumnapic, its time to proceed to the second floor of the maze. The
creatures there should increase your fortune quite a bit. (Make sure you
explore the area behind the vampire statue first.) The next section is
on getting to the second floor of the maze.

Quest 2:
The Purse, the Motor Room, The Hurkle Beast, and Level 2
Before you take up this challenge, go back upstairs to the Adventurer's
inn and see if you gained any levels. Then save the game at the foot of
the stairs. First of all, you need the purse it is at (E4, N4) you have
to search the corpse and fight some undead monsters to get it. To get to
the purse, you must turn off the motor. To do this, you need the Brass
Key from Ironnose. The motor is located at (E6, N4). Use the key to get
in and select the actions in this order to de-actiavte the machine
D,B,C,A. Collect the Bag of Tokens by defeating the monsters. The bag in
in the chest that they leave behind.
The Token Booth is located at (E12, N4). It lowers you to part pf level
two. This sealed area contains a teleporter at (E7, S4) that can take
you to levels 2,3,4,or 5. The corner (W3, S14) has a chest containing
the bottle of soda. Somewhere in the area is the Hurkle Beast. He has
about 38 hit points and his attacks cause poison and paralysis.
He doesn't leave an item. Hang around this area and fight monsters to
your heart's content. If you want to explore more of level 2, there is a
rope leading into another sealed room at(E9. N5). The pit located in the
small room next to (E11, N1) leads to the same room. This is damaging,
though, so its better to take the rope. This small room has pits at
(W17,S1) and (W16,S6) that damage you. The rope to get back up is
located at (W5, N2).

Quest 3:
The Legendary Den of Theives:
The idea of this quest is to build your levels higher. First, go to the
Inn and check your levels. Its also a good idea to buy weapons and
armor. Make sure you got the map before coming here. To get to the den,
go to the shimmering portal on the first floor (E15, N9). You should see
lots of black. Use the map to find your way to the door. This is the
door(E10,S1) to the den of theives. Inside you will find strong enemies
and several bands of roving theives led by NPC's. Busted Brian, Rick the
Pick, and Le Dombo can all be found here. Make sure you charm them and
get their advice sometime during the game. Always save at the room with
the "Den of Theives" sign so you can restart there in case the theives
steal one of your good items. Their hints cost $250 each. Avoid fighting
the Blackblades, Armor Eaters and Assasins if possible.

Quest 4:
Level Three, The Mad Stomper
This is where the enemies begin to get hard. Level threeconsists of
three parts. The first part is the hallway surrounding the maze part.
The maze part is the second part.
The third part is the top area. Until you get the Litofeit spell stick
to the hallway area.
Aviod the gastrap at (E21,S23).
Its a good idea to try fighting the enemies in lovel 5 to speed this
process. Don't enter Manfretti's yet, i believe you cannot leave for
awhile if you do so.

4. Endgame Sequence:
Thanks to Snafaru <eric@iosphere.net> for this info
-Before you can begin the endgame, you must have the following items:
     King of Diamonds                             Staff of Earth
     Queen of Hearts                               Staff of Fire
     Jack of Spades                                 Staff of Air
     Staff of Water                                 Orb of Llygamyn

-Once you begin the endgame, you cannot go up to the castle. If you do
so, you must begin the endgame again.
-Use Silver Mail to heal your characters.

Go to level 7.
Find the Lord of Hearts at (5E,5N). Give him the Queen of hearts. Then
go to the4 blue Flame at (1W,1S). Use the Orb to open the portal and
take the portal to level 8.
Fight the evil clones, have someone equip the staff of water, use the
staff at (0E,4S)
light candles BEH and answer GROWTH. Go back to the portal and go back
to level 7.

Find the Lord of Spades at (6W,5N). Give him the Jack of Spades. Go to
the red flame at (0E,1S) and use the orb to open the portal. Take the
portal, fight the clones. Equip the Staff of Earth, and use it at
(4W,0N). Light candles ADI and answer NATURE.
Go back to level 7.

Find the Lord of Diamonds at (6W,6S) and give him the King of Diamonds.
Go to the yellow flame at (0E,0N) use the orb here and fight some more
clones. You should get the Ace of Clubs for Equip the Staff of Fire and
use it at (4E,0S). Light candles CFG and answer CHANGE.
Go back to level 7.

Find the Lord of Clubs at (5E,5S)and give him the Ace of Clubs. Go to
the white flame and use the orb. Fight the clones. Equip and use the
Staff of Air at (0E,4N). Light all the candles, and answer MAN.
Take the portal back to level 7, give the Queen of Hearts to the Lord of
Hearts once again. Go down to level 8 and find the Sorn at (0E,0N)
During the first round, have your ninja/theives hide and cast a summon
spell to summon the gatekeeper. Once you win, you will get the "Heart of
Abriel" Give this item to a character that can cast mage spells, and
cast Malor and teleport up 7 levels, climb the stairs, and your quest is
complete.



  7. Spells
Spells are divided into two categories: Cleric and Mage
Here are the spells and their descriptions.


Cleric spells:
-----------------------------------------------------------------------------

LEVEL       NAME             USE
-----------------------------------------------------------------------------

1              Dios               Restores 1-8 Hit Points.
1              Badios           Inflicts 1-8 points of damage to 1
monster.
1              Milwa            Lights up more of the maze.
1              Kalki             During combat, lowers party's AC by 1.
1              Porfic            Lowers Caster's AC by 4 during combat.
2              Katu              Charms a group of enemies or a NPC.
2              Calfo             Determines nature of trap on chest.
2              Montino         Prevents 1 group of monsters from casting
spells.
2              Kandi             Gives location of missing person.
3              Latumapic     This spell identifies the enemies you're
facing.
3              Dialko           Cures paralysis, wakes sleeper.
3              Bamatu         Reduces party's AC by 3 for whole battle.
3              Lomilwa       Same as milwa, lasts longer.
3              Hakanido       Drains monster of magic-casting ability.
4              Dial               Restores 2-16 hit points.
4              Badial           Deals 6-30 points of damage to 1
monster.
4              Latumofis     This is the infamous poison cure spell.
4              Maporfic       This spell lowers the whole party's AC by
two.
4              Bariko           Deals 5-15 points of damage to 1 group
of enemies.
5              Dialma          Restores 3-24 hit points.
5              Di                 Attempts to resurrect 1 party member.
5              Bamordi        Summons monsters to aid the party during
combat.
5              Mogato          Attempts fo banish monster.
5              Badi              Attempts to take monster's life.
6              Loktofeit      Teleports party back to castle, must
re-learn spell after.
6              Madi              Recovers all hit points.
6              Labadi           Drains all but 1-8 of monster's HP,
restores caster's HP fully.
6              Kakamen       Deals 7-49 points of damage to 1 enemy
group.
7              Mabariko       Deals 12-72 points of damage to all
monsters.
7              Ihalon           Grants favor to 1 person, must be
re-learned after use.
7              Bakadi           Attempts to slay outright all monsters
in a group.
7              Kadorto         Restores lifeless characters, even those
turned to ashes.
-----------------------------------------------------------------------------



Mage Spells:
-----------------------------------------------------------------------------

LEVEL       NAME             USE
-----------------------------------------------------------------------------

1              Halito            1-8 damage to a monster.
1              Mogref           Reduces Caster's AC by 2.
1              Katino           Causes a group of monsters to sleep.
1              Dumapic        Look at the map.
2              Ponti             Increases 1 person's speed and reduces
AC by 1.
2              Melito           1-8 damage to an enemy group.
2              Desto            Attempts to unlock door.
2              Morlis           Raises monster AC.
2              Bolatu           Tries to turn a monster into stone.
3              Calific          Will Reveal secret doors, if any are
present.
3              Mahalito        4-24 damage to a group.
3              Cortu             Protects party against magic spells and
"breathing" monsters.
3              Kantios         Disrupts actions of1 group of enemies.
4              Tzalik           20-60 damage to 1 monster.
4              Lahalito        6-36 damage to 1 monster group.
4              Litofeito       Lets your party float over pits, shafts,
and other traps.
4              Rodko            Stuns 1 group, harder to recover from.
5              Socordi         Conjures a group of monsters to help you
fight.
5              Madalto         8-64 points of ice damage to a group.
5              Bacortu         Fizzles spells from 1 enemy group.
5              Palios           Reduces monster magic screens, dispells
fizzle fields on party.
5              Vaskrye        Random effects to 1 enemy group.
6              Mamogref     AC-10 wall around 1 person.
6              Zilwan         500-1000 damage to 1 enemy.
6              Lokara          Earth will engulf some monster types.
6              Ladalto        10-100 points of damage to an enemy group.

7              Malor           When cast in combat, teleports party to
random location.
7              Mahaman      Caster must be level 13, performs a great
favor in battle.
7              Tiltowait    10-150 Damage to all monsters.
7              Mawxiwtz   Super-Charged Vaskrye, works on all monsters.
7              Abriel          You get this when you beat the game.
------------------------------------------------------------------------------

 9. NPC's
These are found throughout the game. They offer advice, sell items, or
sometimes steal from you and can even attack.

Level 1 NPC's
G'bli Gedook
He is found at (E8, N24) He should not be attacked and you should not
try to steal from him either. When angered, he calls acolytes and casts
death spells. He is not easily charmed. Buy the Statue from him.

Ironnose
He is found near (E16,N28). He is a tough opponent. Buy the Key from
him. He can be charmed.

Level 4 NPC's
Busted Brian
Rick the Pick
Le Dombo
These Shady Characters are found in the den of theives. They sometimes
steal from you. They can be charmed.
They run when attacked, but their buddies stay.

Level 5 NPC's
La diva Brenda
Lady Lenore
Lucianne Skye
Lady Karena
Lady jane
These ladies wander level five. If you try to talk to them, you have to
pay $250 or they will call the guards. They sell some good stuff, I'll
have a list one of these days. They can be charmed easily.

Big Max:
This guy is located at (E7, S1) he sells tickets to Manfretti's. He
packs quite a punch, so try not to anger him. It may take several times
to charm him.

10. Pools and Swimming:
Swimming is an important skill in this game. Items and gold can be found
in pools, as well as monsters and stat alterations. A Character's swim
rating is show in the status screen. This number is the number of levels
they can swim without drowning. To raise this level, save the game and
make the character dive a level deeper than the rating. If your
character drowns, reset the game, otherwise, save and continue. There is
an item that allows characters to swim as deep as they wish without fear
of drowning. This item is called the rubber duck. You can buy it from
the Mad Stomper on level 3. Once you equip it on a character, he/she
will never drown.

11. Character Classes:
The basic classes are:

Fighter:
You know who these guys are. They're strong and they beat up stuff.
Upgrade these as soon as possible to a Lord, Samurai, or Ninja. Fighters
can be good, neutral , or evil. A character must have 11 Strength to be
a fighter. Gnomes make the best fighters.

Mage:
Mages have low hit points and can only use light armor and weapons.
Thety can cast mage spells, which often come in handy. You should
upgrade these guys to Samurai as soon as possible. Mages need 11 IQ.

Cleric:
Clerics cannot be neutral. They have limited weapon and armor choices.
They cast cleric spells and are  very necessary. THese Characters should
be upgraded to wizards or lords as soon as possible. Clerics need 11
devotion.

Thief:
Thieves are used to open treasure chests and locked doors. They can hide
and ambush as well. They can also steal from NPC's. obviously, theives
cannot be good. Hobbits make good theives. Theives need 11 Agility.

The advanced classes are:

Wizard:
Wizards are master spell-casters. They can use slightly better
equipment. They can identify items found in the maze, which is very
useful. They cannot be neutral. They need 12 IQ and 12 devotion.

Samurai:
Samurai are great warriors. They can use most Fighter weapons and armor.
At level 4, they begin to learn Mage spells. Samurai cannot be evil.
They need 15 strength, 11 IQ, 10 devotion, 14 vitality, and 10 Agility.

Lord:
A Lord must be good. The Lord is basically a fighter with the ability to
cast cleric spells. They can use all Fighter armor and weapons. Lords
can dispell enemies as well. They need 15 strength, 12 IQ, 12 devotion,
15 vitality, 14 agility, 15 luck.

Ninja:
Ninja can use the same armor and weapons as samurai, but work better
without any. They can be used to hold your non-combat items this way.
Their armor class lowers a point evert three levels. They can hide and
ambush enemies during battle do do almost double the damage. They can
identify and disarm traps as well. Ninja must be evil. They need 15
strength, 17 IQ, 15 devotion, 16 vitality, 15 agility, and 16 luck.

13. Credits/Thanks
-Thanks to GAMEFAQS for being the best game info site ever.
-Thanks to Snafaru <eric@iosphere.net
His Wiz V Walkthrough allowed me to beat the game.
my endgame sequence is based on his information.


Copyright 1999 Bryan Landry       <sonofdurell@hotmail.com>