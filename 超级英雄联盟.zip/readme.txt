any Blue Isotop 	= Really Good at Treading Water (walk on Water)
any Black Isotop 	= Put Animals to Sleep (work on Animal only)
any Green Isotop 	= Cause Root rot (work only on Plant)
any Red Isotop 		= Induce Dust (work on Robots only)
any Orange Isotop 	= Increase Opponents Cholestrol (dont work on Robot, Plant and McDonald)

White Isotop		= Beaver Jaw
Silver Isotop		= Power to Confuse (work only on those who has a Brain)

Vegetable		= Health Increase
Fish			= Brains Increase
Meat			= Brawn Increase

Useless Stuff (can be used for Midas Touch):

- Loose Board
- Bust of Pat Buchanan
- Pappy Outfit
- Uprooted Plant
- 98w light bulb
- frosted panel
- Painting
- Mouse Carcass
- Warranty
- Greeting Card
- Cone
- Android Manual
- Pez Dispenser
- Printout

Midas Touch 

01. Item =	Car Muffler (useless)
02. Item =	Scarf
03. Item =	Card Shuffler (useless)
04. Item = 	Fluffer (useless)
05. Item =	Floor Buffer (useless)
06. Item =	Buffalo (disappear)
07. Item =	Cufflink (400-500 Dollar)
08. Item = 	Kevlar Vest (good Armor)
09. Item =	Muffin (eatable)
10. Item =	Muff
11. Item =	Muffler (disappear)
12. Item =	Mufti (disappear)
13. Item =	Guffaw (disappear)
14. Item =	Mafia (disappear)
15. Item = 	Moffette (disappear)


9 Members:

The Crimson Tape
Robomop
Mademoiselle Pepperoni

Tropical Oil Man
Treader Man
Mighty Magnitude

Toastbuster
Zaniac
Caped Cod


Class:

Tenth			0
Ninth	 	    2'500
Eighth	 	    5'000
Seventh		   10'000
Sixth		   20'000
Fifth		   40'000
Fourth  	   80'000
Third   	  160'000
Second		  320'000
First		  640'000
Special	 	1'000'000
Special 2	2'000'000


100th Combat	25'000 Xp
200th Combat	50'000 Xp


Ridding Sector from Enemy:

01. Time	  500 Xp
02. Time	1'000 Xp
03. Time	1'500 Xp
04. Time	2'000 Xp
05. Time	2'500 Xp
06. Time	3'000 Xp
07. Time	3'500 Xp
08. Time	4'000 Xp
09. Time	4'500 Xp
10. Time	5'000 Xp
11. Time	5'500 Xp
12. Time	6'000 Xp
13. Time	6'500 Xp
14. Time	7'000 Xp
15. Time	7'500 Xp
16. Time	8'000 Xp
17. Time	8'500 Xp
18. Time	9'000 Xp
19. Time	9'500 Xp
20. Time       10'000 Xp
21. Time       10'500 Xp
22. Time       11'000 Xp
23. Time       11'500 Xp
24. Time      100'000 Xp	

Uncover Sector

01. Time	  100 Xp
02. Time	  125 Xp
03. Time	  156 Xp
04. Time	  195 Xp
05. Time	  243 Xp
06. Time	  303 Xp
07. Time	  378 Xp
08. Time	  472 Xp
09. Time	  590 Xp
10. Time	  737 Xp
11. Time	  921 Xp
12. Time	1'151 Xp
13. Time	1'438 Xp
14. Time	1'797 Xp
15. Time	2'246 Xp
16. Time	2'807 Xp
17. Time	3'508 Xp
18. Time	4'385 Xp
19. Time	5'481 Xp
20. Time	6'851 Xp
21. Time	8'563 Xp
22. Time       10'703 Xp
23. Time       13'378 Xp
24. Time      100'000 Xp

