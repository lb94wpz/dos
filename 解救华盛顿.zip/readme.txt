Late-breaking News about Free D.C.! from Cineplay Interactive.  11/24/91

Changes from the Reference card:
 Free D.C.! is installed in the directory \CINEPLAY\FREEDC\. If you have
 installed it on your C: drive, type "CD CINEPLAY\FREEDC" at the the DOS
 "> prompt. Then type "FREEDC" to play the game.
 

 The "A" key turns the audio on and off.

 Weapons behave the same against each robot type each time you play.

 
Hints:
 Save often.

Sound:
 A Soundblaster card is required to hear the digitized voices.

Memory:

 Free D.C.! requires lots of free memory for its large and detailed graphics.
 If you are running large TSRs or devices the game will detect the small 
 amount of available memory and exit.  Remove the TSRs and try again.

 We have tested the game on all DOS versions back to 3.30.
 DOS 5.0 generally gives the largest amount of free memory.

 To find out how much memory your computer has available for programs,
 type "MEM" at a DOS prompt.  "Largest executable program size" tells
 you how much free memory your machine has.  Anything above 550000 bytes
 is sufficient, the more the better.  DOS 5.0 can give up to 610000 bytes
 free.

 On machines with close to the minimum memory, saving and restarting
 the game occasionally will improve its performance. We have made it possible
 for you to play the game even if you have a machine with limited free memory.
 The game will detect low memory conditions and allow you to save the game
 and restart at the same position.

