Dreamweb CD Rip
Developed by: Creative Reality
Published by: GameTek/Empire Interactive
Presented by: Home of the Underdogs (http://www.the-underdogs.org)
Repacked by: doowopman

Possibly one of the best cyberpunk games ever made,
Dreamweb is immersive, challenging, and fun.  The 
original archive was full of ARJ files and not pre-
cracked.  This new archive has Dreamweb packed into 
the self-extracting RAR format and the game is pre-
cracked.

Run dweb.exe to begin extraction of the files to the
directory of your choice.  Use Dw.bat to start the game.
Dreamweb ran OK for me under pure DOS and a Win 95/98
DOS box.  If you have trouble, boot into pure DOS or use
a bootdisk for best performance (try the ones listed at 
www.the-underdogs.org/faq.php).  Dreamweb needs at least
590k EMS, which can be solved by trying a boot disk.

The game is not guaranteed to run under Windows NT/2k/XP.
If you have any technical trouble or questions, please post
in the tech help forum at www.the-underdogs.org/forum.

Have fun and enjoy the game 8-)!