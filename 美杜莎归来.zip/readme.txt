Return of Medusa

Cheat Codes:
------------
Press [Alt] + C to display the cheat menu.