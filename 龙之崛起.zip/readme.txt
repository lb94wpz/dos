Rise of the Dragon

Your Apartment

What do I do with my Vid-Phone?
Check all of your  messages on the Vid-Phone. This will allow  you
to travel to many of the areas in the game.  The first message is
from Mayor Vincenzi. After playing back that  message, a picture
will scroll off  of the printer. You will need this picture later,
so be sure to take it.

What should I pick up in my apartment?
Get  your clothes,  trench-coat, bullet  magazine, and  gun, which
is under the pillow, and wire tester from the bedroom.  From the
bathroom, you will need the NaPent and first aid kit.

I'm locked out how can I get in?
If you leave your keycard in the  Vid-Phone, then leave the
apartment, you will be locked out. There  is, however, a way to
get in. You  can short out the door keypad by opening the steam
pipe valve above the door.

How do I get the keys for the cupboard?
Make up with Karyn in order to get the  keys. Go see Karyn at city
hall as soon as you leave your apartment. She will give you the
keys.

How can I avoid being arrested when I leave my apartment.
You will be arrested for indecent  exposure if you leave your
apartment without any clothes on.  You will need to put  your
clothes and trench-coat on  to avoid this.

City Hall

Karyn just yells at me! What should I do?
Show  Karyn that  you are  sorry for  standing her  up last
night. You  should purchase a dozen roses  from the flower vendor
in front of  city hall. Use your ID card to pay for the roses.
Apologise  to Karyn, and give her the roses. When she offers to
make a date for tonight,  take her up on it!  Later in the game,
you must make  a decision to go and meet  her at 7:30, or stand
her  up. If you stand her up, the game is over. If you  have tried
to pick up on any other girl or prostitute earlier in the game,
you will be unable to continue. Karyn's help is crucial to
completion of the game.

How do I deal with Jenni?
Reject all of  Jenni's advances toward you. If you  don't you
could lose Karyn, your key source of information. Jenni will let
you in to see the mayor only if you have the MTZ tape and yell at
her.

How do I get in to see the Mayor?
Yell at Jenni.  Tell her that it is  very important that you get
in to see the mayor. You can only do this after you have obtained
the MTZ tape from Karyn.

What should I say to the Mayor?
Threaten him, but not to the point  of anger. Try the following
sequence: 3, 2, 2.

How do I get into the Police Armoury?
Get the security pass from the mayor. If you threaten the mayor
right up to his limit, he  will give in and  offer you the pass.
Show this pass to  deputy Van Halen, and  he will clear you  to
enter. Once in  the armoury, the rifle  is the only item you can
get.

I can't get into City Hall!
City hall  is only open from  9 am to 5  PM. If the icon  will not
change, city hall is closed. Come back later.

How do I avoid being thrown in jail?
If you negotiate  with the Mayor too harshly,  he will throw you
in  jail. When you speak to him, try the following sequence: 3, 2,
2.

The Warehouse

Where is the warehouse?
On the screen where  the flower vendor is, there is a  small alley
to the right side of the  screen. When you move your  icon over
this area of  the screen, it should change to an EXIT icon. This
alley is the way to the warehouse.

How will the old man help me?
The old man will tell you about the future, and your purpose. When
he gives you time to  speak, tell him you  have something for him
to look at. Show  him the scroll  with  the  Chinese  calligraphy
on  it  that  you  found  at Chen Lu's apartment.  He will
translate it  for you,  and tell  you about  the reservoir strike.

How can I delay Deng Hwang's plans to take over LA?
Blow up his MTZ  production plant. Place a bomb on the  second
power panel from the left, and watch  it blow up. This will blow
up  most of the factory, giving you 2 more days to stop him
completely.

I'm having trouble putting on the bullet-proof vest.
Remove your trench-coat  first. If you do not remove  your trench-
coat first, you will not be able to wear the vest.

The Pleasure Dome

How do I get past the bouncers?
Check all of your  weapons with Martha, the person at the  window.
You will not be able to pass unless you do.

How do I keep from losing my weapon?
When Slen  asks if you  have anything else  for them, give  him
the candy  bar. After giving him the candy bar, he will give you a
claim check for your weapon. This is only necessary the first time
you check in a weapon.

Who can I speak to in here?
You can speak to only 1 person in the  card room, 1 person in the
room with the dancer and stairs, and 4 people in the  bar. The
people in the bar are the only ones that can help you.

Where is "The Jake"?
The Jake is the  small guy in the back of the bar  wearing green.
You will want to go easy on The Jake, since he is your primary
source of hints and addresses.

The Jake won't talk to me, or he says I need proof! What should I
do?
The Jake  needs proof that  Chandra Vincenzi was  killed. Show him
the picture from your Vid-Phone that the mayor sent you. This will
get his attention.

How can I sit in on the card game with Darce?
You won't be able to play cards with  Darce or any of the other
players. She is merely being polite by telling you about the game
they are playing.

How can I get The Jake to give me Chen Lu's address?
When The Jake begins  to talk, he will mention a character  by the
name of Chen Lu. You have the option here to ask  about Chen Lu.
When you ask about Chen Lu, he will say that he has never heard
of him. Ask him if he thinks Chandra would want him covering for
Chen Lu. The Jake will then give you the address.

How can I win over The Jake?
Give  The Jake  a candy  bar after  talking with  him the  first
time.  This is crucial, or he will not warn you about the strikes
later in the game.

Chen Lu's Apartment

How can I get Chen Lu's to show up on the map?
Talk to The Jake in the Pleasure Dome.  If you deal with him
correctly, he will give you the address to Chen Lu's apartment.
Once he gives you the address, the icon will automatically show up
on the map when you travel.

How can I avoid being arrested in Chen Lu's?
The police have already started on their way to the apartment. You
will need to get in, get Chen  Lu's ID card from his Vid-Phone,
and  come back later. If you spend too much time in Chen Lu's
apartment, the police will catch you there.

What should I get from Chen Lu's?
Get Chen Lu's ID  card, the drug patch from the bathroom  sink
counter, and the scroll from Chen Lu's safe in his bedroom.

What should I do with the drug patch?
Give the drug patch to Karyn for her  to work on. She will have it
analysed for you, and give you the MTZ tape which you can use to
bribe the mayor.

What do I do with the Vid-Phone?
Note Chen Lu's  gun permit number and ID  number when you put his
ID card into the Vid-Phone. You will be able to look at one of
Chen Lu's previous messages.

How can I find the safe?
Look over the statue in Chen Lu's bedroom. The right eyeball of
the statue will sparkle on  the screen. Click  on the right
eyeball and the  statue will lower revealing a save on the wall
behind it.

How do I open the safe?
You must  have the gun  permit number and  ID number from  Chen
Lu's Vid-Phone. Look at the  4 numbers that are common  to the
two. This is  the combination to the safe.

What do I do with the scroll?
Give the scroll  to the old man sitting  on the crate in the
warehouse. He can translate it for you.

Johnny Qwong's Residence

How can I get Johnny Qwong's house to show up on the map?
Show Chen Lu's ID card to Karyn at City  Hall. She will run a
trace for you and show that  Johnny Qwong is  a known accomplice
of Chen Lu.  After this, Johnny Qwong's house will show up on the
map.

How do I get into Johnny Qwong's house? What do I do there?
You cannot enter  Johnny Qwong's house. You can, however,  get
below his house. Try clicking on the manhole cover in the lower
section of the screen.

How do I open the Vid-Phone splicing trunk?
Use a  bomb to blow  open the case.  Drop a bomb  on top of  the
lock and stand back.

How do I tap Johnny Qwong's Vid-Phone line?
Use  your  wire  tester.  Attach  the  red  alligator  clip to the
left battery terminal at the top of the screen.  Next, attach the
blue clip to the grounding strap wrapped  around the conduit near
the bottom of the  screen. Lastly, take the yellow clip and clip
it onto the  second terminal up from the bottom of the lower
termination  block. This is a  very difficult sequence, and  will
require much practice. Save your game often!

I am continually being shocked to death at the terminal. Help!
Hook up the alligator clips to the terminals correctly. If the
clip is close to any terminal other than the one you want to drop
it on, you will be shocked. Be extremely precise on where you drop
the clips on the screen.

The sewer rats keep killing me!
The sewer rats are on a timer. If you hurry, you won't see them.
If you spend a considerable amount of time in the sewer, they will
kill you.

The Reservoir

How do I get the reservoir to appear on the map?
Show the old man at the warehouse  the scroll that you obtained
from Chen Lu's. When he translates it for you and  tells you about
the strike at the reservoir, the reservoir will show up.

What should I do at the reservoir?
You will need to ambush the strike unit  that will appear. When
they show up at the reservoir, kill every one of them and steal
their hovercar.

When will the strike units be in position?
The strike units will show up August 4th between 7:00 and 10:00
PM.

I'm running out of time!
If you haven't blown up the power panel next to the warehouse you
will not have enough time. Blowing up the power panel  gives you
two additional days that you need.

How can I defeat the guards at the reservoir?
Be sure to wear the bullet proof  vest. Avoid getting shot as much
as possible. You  can be  shot a  few times  if you  are wearing
the bullet proof vest, but eventually you will die. If you have
the rifle from the armoury, this will also increase your chances
of winning this sequence.

How do I steal the hovercar?
When you move your icon over the car near the door, it should turn
into an EXIT icon. Click on that icon, and you should be able to
enter the car.

What should I do in the hovercar?
Click on the map  in the middle of the car and go  directly to
Deng Hwang's. As soon as you wipe out the guards at the reservoir,
you are on a timer, so hurry!

Deng Hwang Enterprises

How can I get Deng Hwang Enterprises to show up on the map?
Once you get  the message from Deng Hwang  on your Vid-Phone at
home,  you will then be able to travel to Deng Hwang's factory.

How do I get into Deng Hwang Enterprises?
Drive  the  hovercar  to  Deng  Hwang's.  The  hovercar  will land
on the roof, bypassing the first level of security. You can also
show Snake's ID card to the guard at the gate if you travelled
there by Emm-Way.

How can I get past the receptionist?
Lie to  the her. Try  telling her that  you remember her  from
high school, and that you  would like to  go out with   her. Then
tell  her that her  boss is in trouble, and you are there to help.
If all else fails, use NaPent on her.

I'm baffled by security room control panel!
Manually override the security system. There are  many ways to do
this. One way is to  use the colour  sequence found  in  the
fortune cookie.  Press button [I]  (one)  then use  the sequence.
You can  also find  a secret  code in  the game documentation.  If
you  find this  code, you  will be  able to  use button [II]
(two), and the correct sequence of colours.

How do I figure out the manual override code?
Open the fortune  cookie given to you by  the old man on the
crate. Follow the letter abbreviations for the colour codes.

How do I prevent the guards from killing me?
If you forgot to lock the guard break  room when you were at the
control panel, you will need  to do so. If you  did and they find
you  anyway, you wasted time somewhere. After you leave the
control  room, complete everything as quickly as possible.
Eventually, if you are not quick enough, they will find you.

The  receptionist comes  to her  senses and  resets the  security
system.  What should I do?
Once she  resets the security system,  do everything at lightning
speed. It is only a matter of time before the guards track you
down.

What should I do in the Janitor's closet?
Get some wire. Open both circuit breaker  boxes, turn off the main
on top, then disassemble the smaller gang switches below. Use the
screwdriver on the sink in order to do  this. After the switch
panel  has been removed, grab a  handful of wires and put it in
your inventory.

How can I save Karyn?
Take the  wires you got  from the janitor's  closet and lay  them
across Karyn. Move to the close-up view of Karyn, and unplug each
of the 3 wires connected to the neck  strap. Note the  countdown
time  on  the screen behind  her. Save her before the timer
reaches 0!

How can I get past the flame throwers?
The flame throwers work  on a pattern. Sit and watch them  for
awhile. You will learn when it is safe to crawl under them after
learning the pattern.

How can I kill Bahumat?
If you are killed 5  times in a row, the game will ask you  if you
want to skip the arcade sequence.  If you choose to skip it,
program control will take over and show you the ending story
panels of the game.