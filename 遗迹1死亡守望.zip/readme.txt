===============================================================================
Ancients 1: The Deathwatch for the PC
Walkthrough

Created by Desert Gunstar (aka Shadow2099)
desertgunstar@hotmail.com
Completed Jan. 31, 2004
===============================================================================

===============================================================================
Table of Contents
===============================================================================
1. Introduction
2. Getting Started
3. Walkthrough
     a. The City of Locklaven
     b. 1st Floor of the Sewers
     c. 2nd Floor of the Sewers
     d. 3rd Floor of the Sewers
     e. 1st Floor of the Castle
     f. 2nd Floor of the Castle
     g. 3rd Floor of the Castle
4. Experience and Equipment Charts
5. Magic Spells

===============================================================================
1. Introduction
===============================================================================
Ancients 1: The Deathwatch is the first game of 2 created by a company named
Farr-Ware. Like the Wizardry games before it, the majority of Ancients is spent
exploring, mapping, and strengthening the power of your characters. I hope to
help you in your quest to defeat the two evil ones and rescue the fair maiden
(what a story, heh...) by giving detailed information about the game. I've
included some maps to help you along the way, but you might not be able to make
good use of them. There are some things to do before you jump into combat...


===============================================================================
2. Getting Started
===============================================================================
Before you begin your journey, you'll have to select your characters. You don't
have to enter the character creation screen at all, and you can just use the
default party given to you (which includes a rogue, a warrior, a mage and a
priest). But, it's a tad more enjoyable if you create and customize your own.

When creating your characters, you'll have to select the race, class, and roll
the starting stats. As far as I can see, your starting race has no noticeable
effect in the game, except for having an altered line of text in the status
screen. For your 4 characters, you might just want to select all available
classes in order to have a well-balanced party. This works 100% of the time,
but it isn't the best. Nearing the end of the game, warriors and rogues tend
to miss almost all the time, and don't do damage anywhere close to a priest or
a mage. If you want, you can have 3 Priests and 1 Mage, with 2 Priests acting
as front-line warriors until you have access to the later magic spells in the
game.

When rolling a character, I find that you can almost get away with double
digits in each given value. 12/13 is decent enough, but you should spring for
15/16. Don't worry about your starting Draco, as you'll attain enough loot in
the dungeons. Stats max out at 19, and each stat is as follows:

Strength- The physical strength of the character. Determines how hard the
character can hit. If your strength is 16, you will recieve a +1 bonus to
damage. At 17, you get +2, etc.

Dexterity- The character's agility and combat skills. Increases the chance of
making contact with the enemy, while avoiding their blows in turn. If your dex
is over 15, you will get +1 bonuses to your chance to hit for every point over.

Constitution- Ability to recover HP when camping.

Intelligence- Ability to recover MP when camping.

Once you're all set, you will start near the 4 shops of the city. You will only
ever need to go to the Equipment Shop and the Guild on the edge of town; the
Casino, Inn and Temple are fairly useless. You can gather enough gold as it is
without gambling your money (unless you are starting out and just want to save/
reload to get enough money at the start). Resting at the Inn, while only 6
dracos, is pricey for a low-level group, and its purpose is defeated by being
able to rest inside the dungeon. Resurrection at the temple won't prove helpful
at all, since you'll most likely reload a saved game. It's pricey, too: 100
dracos. You should only ever need to resurrect if you saved your game after an
eventful battle.

Begin by pooling your gold to one character. Have that character buy 2
weapons for your frontline fighters (short swords are nice), and then any
cheap pieces of armor you can afford. 

Once you have all your equipment sorted out, head for the dungeon in the north-
west corner.


===============================================================================
3. Walkthrough
===============================================================================
-------------------------------------------------------------------------------
a. The City of Locklaven
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#       Legend:
02 #|D|.| |__d__| |__d___d_d____| |_|d|_|#       D- stairs going down
03 #| |_|  _____   _________________   _|#       d- door of private residence
04 #|  ___|.____| |_________________| |.|#       S- Shop
05 #| |..d.d|  _   _____   _____   _  |d|#       G- Guild
06 #| |d.___| | | |.....| |.....| |.| |.|#
07 #| |.|___  | | |__S__| |__S__| |.| |d|#
08 #| |__d_.| |_|  _____   _____  |.| |d|#
09 #|  _  |_|  _  |..S..| |..S..| |.| |.|#
10 #| |.|_   _|.| |_____| |_____| |.| |d|#
11 #| |d._| |...|  _   ___________|.| |d|#
12 #| |_|  _|..d| |.|_|..d....._____| |.|#
13 #|  _  |__d__| |d.d.....d__|  _____  |#
14 #| |.|_   _    |__d____|  ___|..d .| |#
15 #| |d__| |.|  ___________|......___| |#
16 #|_   ___|.| |....d...d.......d|  _  |#
17 #|.| |..G.d| |__d___d___d___d__| |_| |#
18 #|d| |__d__|  _____________________  |#
19 #|.|_________|..d...d.d...d.d...d..|_|#
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#

Yes...the maps are crude, and personally, I find them hard to read myself. It
would be a lot better if you drew your own maps on graph paper, but these will
have to do. Note that all the maps in-game are 20*20, but I have blown them up
to 40*20. I've included a number-letter border for readability, and I've tried
to use periods to denote that the empty space is a wall.

-------------------------------------------------------------------------------
b. 1st Floor of the Sewers
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|  ______X_M_X__   _______   _   _|_|#    X- Door
03 #| |.._...|.|.|..| |_______|X|.| |.| |#    #- Pathetically-drawn border
04 #| |_| |.........|________X  |.| |.| |#    U- Stairs up
05 #|  ___|.._______ .._____.-| |.| |.| |#    D- Stairs down
06 #|X|_____|U X    |_|  _  |.| |.| |.| |#    M- A well that blocks your
07 #|* _   _|---|____X  | | |_| |.| |_| |#       way. Drop a mace to pass
08 #|_|.|_|..... ____#__|_|  _  |.|  ___|#    *- Fight a group of evil
09 #|.........._|    _|.|___|.| |_| |___ #       priests for a key needed
10 #|....___ .|_   _|___...___|  ___    |#       for the castle
11 #|...|   |___| |.|   |_|  ___|...|_  |#
12 #|...|  __X____|.|____X  |_________|X|#
13 #|___| |..____________-|  ___________|#
14 #|  _  |.|  ____X_____X  |.._________|#
15 #| |.| |_| |___.|.____-| |.|D_X____  |#
16 #|_|_|  _   _  |.|    X  |_________| |#
17 #|_|  _|.| | | |.|  _|-|_________   _|#
18 #|   |___| |_| |_|X|..___________|X|_|#
19 #|_________________|.|_______________|#
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#

Down in the sewers, you should be careful. Save often, and camp near the
entrance to recover HP/MP and fight monsters without moving from your place.
Concentrate on finding bits and pieces of equipment for your party. I shouldn't
need to tell you to cast a Light spell...

On the first floor, the only important task here is to get a key for a later
level of the game. In the north-west corner, you will find a well that asks for
a ball of force that is able to crush bone in order to pass. This item is a
mace, so buy one or fight monsters until you get one. Moving past the well, you
will encounter a band of evil priests, accompanied by a random number of
skeletons. You should try fighting when your characters are at level 2/3. Once
you emerge victorious, you will recieve a key. Save it for later.

Make sure to watch out for better weapons, and always head back to the Guild
when you've enough experience for a level. When you get to the Guild, you could
try saving before you've received the bonuses for your level. The level bonuses
are random, which means you can keep re-loading until you attain a desired
increase. Remember, stats cap at 19.

-------------------------------------------------------------------------------
c. 2nd Floor of the Sewers
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|  _|.| |_|   |_|  ____________X_*  |#
03 #| |___| _X_____X__|.._________..|___|#      X- Door
04 #|___   _|___________|  ___   _|_____|#      U- Staircase up
05 #|___|X|.|  _   ___   _|_..| |.|  _  |#      D- Staircase down
06 #|  _  |.| |_|_|___| |.| |.| |.| |_| |#      T- Tomb of Relnor
07 #| |.| |.|_  |.|  ___|_| |_| |_|_   _|#      *- Encounter with yellow mold
08 #| |.| |___| |.| |.._|  _____  |.| |_|#
09 #|X|.|  ___  |.| |_|  _|_____|X|.|_  |#
10 #|U|_| |.._| |_|  ___|_|  _____|___| |#
11 #|_|  _|_|___   _|___|___|___..|  ___|#
12 #|  _|_| |___| |.|   |.._|_  |.| |.._|#
13 #| |_|  _____  |.|_ T|.| |_| |.|X|.| |#
14 #|  ___|_____| |___|X|_|___  |_| |_| |#
15 #| |...|___   _____   _|_..|  _   _  |#
16 #| |_...___| |.._..| |.| |_| |.| |.| |#
17 #|_  |.|___  |.| |_| |.|_____|.| |.|_|#
18 #|_| |_____| |X|  _  |_________|X|___|#
19 #|    X      |.|_|.|______________X D|#    X D- Ecks Dee (heh...)
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#


If you visit and rest at the Tomb of Relnor, you will have an encounter with
his spirit. He will tell you about a pendant which may be the key to defeating
the evil ones, and then gives you the Sword and Mace of Relnor. These are the
strongest weapons in the game, so don't pass them up.

In the north-east corner, you will encounter a group of yellow molds. If you
win, you will receive a moss, which is what the bartender of the Inn was asking
for. Give this moss to the bartender in order to attain another key, but don't
try to fight the moss until your party reaches level 4/5. At level 5, your
spell-casters will have learned spells which will attack every enemy, making
this battle a breeze.

-------------------------------------------------------------------------------
d. 3rd Floor of the Sewers
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|  _  |.|  ___   ___   ___________  |#
03 #| |.| |.|_|___| |___|_|___________| |#
04 #| |.| |___|_________|_|  _   _   X__|#
05 #| |.|___  |_______..|___|.| |.|X|-._|#
06 #|X|___..|_______  |_______| |.|_|.| |#
07 #|  _  |.._____..|  _______  |_____| |#     *- encounter with stone
08 #| |.| |.|  _  |.|X|.._____|_____ X  |#        golem
09 #|_|.| |.| |.| |.|_|_|  _  |_____|-| |#
10 #|___|X|_| |.| |___|  _|.|_____  |.| |#
11 #|  ___   _|.|_   _  |.._______| |.| |#     3- this door is where you
12 #|X|___| |_____| |.| |.|  _____  |.| |#        finally use your keys
13 #|_______   X__  |_| |.| |___..| |.| |#
14 #|_...___| |-__|_____|_|__X_U|.| |.| |#
15 #|*|.|  _   X  |_____| |_______| |.| |#
16 #|X|_| |.| |-|  ___   ___   ___  |.| |#
17 #|  _  |.| |.|X|_..|X|_..|X|_..| |.|3|#
18 #| |_| |_| |.|   |.|   |.|   |.| |.|X|#
19 #|_________|.|   |.|   |.|   |.| |.|D|#
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
A golem in the south-west of the floor holds the final key to the castle door.
You will find it frozen in a huge chunk of ice, so cast the Level 1 mage spell
Enchanted Flame. Not surprisingly enough, the stone golem will attack you.
There is only one of it, but it attacks multiple times and can resist magic, so
watch out! Also, before you descend to the next floor, you may learn of a red
dragon that rests below. This battle is optional, and the reward is not worth
it. Anyway, prepare yourself and keep moving...

In the middle of this long passageway, the game will tell you that you can feel
a breeze. Once you see this message, examine the wall to the east. You will
find a secret door leading to Kilrah, a red dragon. She is not an easy opponent
for you to handle, but you can emerge the victor at level 6 or so. Your only
chance of harming her is through magical spells, since your warriors will miss
the majority of the time. Instead, have your front lines defend. Keep the party
healthy with your priest, and have your mage cast the strongest spell available
(Blazing Spear, if you have it). If you defeat Kilrah, you will recieve a wand
of Firebolt. Not exactly the best of prizes, but it's better than nothing. Head
south and descend into the castle.

-------------------------------------------------------------------------------
e. 1st Floor of the Castle
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|  _____  |.|  _______   _____  |_| |#
03 #| |..___|X|.| |.._____|X|___..|  X  |#
04 #| |.|  _  |.| |#|  ___   _| |_| |-| |#
05 #| |.|_|.| |.| |#|_|___|_|.|  X  |.\X|#
06 #| |___..| |.| |_..|  _|___| |_| |_.U|#
07 #|  ___|.|_|.|_  |.| |.|  _   _____|_|#
08 #| |___________| |_| |.| |.| |_____| |#
09 #|  X     X   _____  |.| |_|_   _____|#
10 #| |-|___|-| |..___| |.|  _|_|X|..___|#
11 #| |.._____| |.|  ___|_| |.|   |.|  _|#
12 #| |_|  _____|.| |.._|  _|_|___|.| |_|#
13 #|  X _|.._____| |.|  _|_| |..___|_  |#
14 #| |-|___|  _   _|_| |.|  _|.|   |.| |#
15 #| |.|  ___|_|_|_|  _|.| |.._|_  |.| |#
16 #| |_| |___| |_|  _|___| |.| |.|X|_| |#
17 #|  X   _   _____|.|___  |.| |.|___  |#
18 #| |-|X|.| |___________| |_| |_____| |#
19 #| |.|D|.|                           |#
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
There's not much here of interest...you can find a dead warrior and a message
describing a prisoner who has been taken farther down the castle. Level up if
you wish, and then continue on.

-------------------------------------------------------------------------------
f. 2nd Floor of the Castle
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|  ___________   _   ___  |_| |.|   |#
03 #| |.._______..| |_| |_..|___  |_|_ *|#
04 #| |.|  ___  |.|  ___  |___..|_  |_|X|#
05 #| |.| |_..|X|.| |___|___  |___|  _  |#
06 #| |_|  _|.\U/.|  _  |___|  ___  |.| |#     *- Lord Vernon's chamber
07 #|  ___|_______| |.|___   _|___| |.| |#
08 #| |.._|  _   _  |___..| |.|  _  |.| |#
09 #| |_|  _|_| |.|  _  |.| |_| |_| |.| |#
10 #|  ___|_|___|_| |.| |.|    _____|.|X|#
11 #| |___| |___|  _|_| |.|   |_______| |#
12 #|  _   _   X__|.|  _|_|  ___   _____|#
13 #|_|_| |.| |-____| |_|  _|___|X|_____|#
14 #|_|_  |.| |.|  ____X  | |  _______  |#
15 #|D|.| |_| |.| |..___| |_| |_______| |#
16 #|X|_|  X  |_| |.|  ___   _________  |#
17 #|  X  |-|__X__|_| |.._|X|..___..._|X|#
18 #| |-|X|_______|_  |.|   |.|   |.|   |#
19 #| |.|         |.| |.|   |.|   |X|   |#
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
Within this part of the castle lies a most important item to your cause. In the
north-east, you will encounter Lord Vernon, a powerful being who "fought death,
and won." He will be accompanied by a fair amount of vampires that may unleash
balls of fire, damaging your entire party. In addition, Lord Vernon can cast
a Death spell, which instantly kills one of your party members...ouch.

Your front liners should attack the vampires, while your priest and mage cast
Disfiguration and Blazing Spear. Defensive spells like Hall of Heroes may help,
but attempting to keep your party healthy may not be an option; you'll just
have to outlast them. If you win, you will yield the Pendant of Vernon. His
nifty artifact will negate the magic resistance of all enemies, proving very
useful indeed. It can help you in standard battles, as well as the final one.

At this point of the game, you might notice your rogues/warriors may not be
making contact with their weapons most of the time. I recommend giving your
front liners all the magical items usuable in combat, as well as the pendant.
The one with the pendant should switch places with the first person in your
party (who is most likely a mage/priest), but make sure you keep your mage in
the back. Priests have the ability to use the Mace of Relnor and a Metal Shield
as opposed to the lackluster weaponry mages have.

This way, your warrior in the back lines can use the Pendant of Vernon when a
battle starts. Your magic spells will be guaranteed a hit each time you fight,
and you won't have to waste a turn with your spell-caster to use the pendant.
Furthermore, your other warrior can make use of magic items, and since you used
the pendant, these items will hit every time. I find this setup to be more
efficient and effective in leveling up, and it even helps in the final battle.


-------------------------------------------------------------------------------
g. 3rd Floor of the Castle
-------------------------------------------------------------------------------
   a b c d e f g h i j k l m n o p q r s t
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|  ___________  |_|  ___  |_| |_|  _|#
03 #| |.._..._____|_____|_|.|___   X  |_|#
04 #| |.| |_|_   _|_____| |___..| |-|___|#
05 #|X|_|_  |_| |.|  X   ___  |.| |_____|#
06 #|   |_|  X  |.|_|-|_|...| |.|_____  |#
07 #|_  _X__|-| |.__________| |_______| |#
08 #|_|X|_____| |.|  _____   _________  |#      P- magical portal
09 #|  _________|_| |_____| |_________| |#         drop right lever to go
10 #| |_____..._|_   _   _   _________  |#         back to town, or both to
11 #|  X    |.| |_| |_| |_|_|_______..|X|#         go to the keep
12 #| |-|___|_|___   _____|_|  ___  |_| |#
13 #| |..___| |___| |_____|  _|___|  _  |#
14 #| |.|_   _   _   _______|.|___  |.| |#
15 #| |___|X|_|_|.|X|_____________|_|_| |#
16 #|_______  |_..|    X   _____  |_|_  |#
17 #|___....|___|.|___|-| |..___|_  |.| |#
18 #|   |_______________| |_|   |.|X|.|X|#
19 #|    X                 X    |.|P|.|U|#
20 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
The final level before the final battle. When you reach the portal, you will
have the choice of going back to town by pulling down the right lever, or move
to the end by pulling both levers down. It is a good idea to power up as much
as you can, and then head back to the Guild to gain your levels. The bad side
is that you'll have to navigate through the entire dungeon all over again!

In the keep, you will encounter Binatuus and Arulus, the two evil beings who
captured the fairy. Before you fight them, you'll have to deal with their 3 red
dragon flunkies. Use the pendant, then cast your strongest spells available to
you (Disfiguration for priests, Blazing Spear for mages). Once they're out of
the picture, Binatuus and Arulus will attack you. Repeat what you did against
the dragons until you win. You can defeat these guys at a level as low as 9,
but if you still have trouble, go for level 11. At level 11, you will learn
the Level 6 priest and mage spells, and these spells include the Death spell.
With the pendant, you can throw death spells at the enemy for an easy win.

Finally, step forward into the door in front of you and rescue the damsel in
distress. Congrats, you beat Ancients 1! You can venture farther in the world
of Ancients 2, but this quest is completely optional.

===============================================================================
4. Experience and Equipment Charts
===============================================================================
Experience Chart:
Level 2  - 500                Level 8  - 16,000         Level 14 - 128,000
Level 3  - 1,000              Level 9  - 48,000         Level 15 - 144,000
Level 4  - 2,000              Level 10 - 64,000         Level 16 - 160,000
Level 5  - 4,000              Level 11 - 80,000         Level 17 - 176,000
Level 6  - 8,000              Level 12 - 96,000         Level 18 - 192,000
Level 7  - 16,000             Level 13 - 112,000        Level 19 - 208,000


Items denoted with a * are not available in stores.

Weapons:
Name                     Damage                  Value
Bardiche                   9                      75
Battle Axe                 8                      50
Bow                    (arrows: 6)                50
Broad Sword                10                     100
Club                       6                      6
Dagger                     4                      5
*Elven Bow             (arrows: 7)                250
Flail                      7                      35
Halberd                    9                      75
Hand Axe                   4                      5
Lance                      6                      20
Long Sword                 8                      55
Mace                       7                      40
*Mace of Relnor            11                     1000
Morning Star               7                      40
Pike Awl                   7                      45
Scimitar                   8                      53
Short Sword                6                      15
Sling                  (pellets: 4)               25
Spear                      6                      14
Sword of Relnor            13                     1000
Trident                    8                      48
War Hammer                 7                      31


Armor:
Name                   Armor Class               Value
Boots                      1                      20
Chain Mail                 6                      180
Cloth                      1                      20
*Dwarven Boots             2                      200
*Dwarven Helm              1                      200
*Elven Boots               2                      200
*Elven Chainmail           7                      400
Gauntlets                  1                      25
Great Shield               3                      60
Helmet                     1                      40
Leather Armor              2                      40
Leather Gloves             1                      20
Metal Shield               2                      40
*Platemail                 7                      250
Ringmail                   4                      80
Scalemail                  4                      120
Splintmail                 5                      150
Studded Leather            3                      60
*Winged Helm               2                      250
Wooden Shield              1                      25



===============================================================================
5. Magic Spells
===============================================================================
Priest Class spells:
Priest Spells Level 1
Cure Wounds - 3 MP: Heals an ally for around 7 HP.
Bless - 3 MP: Gives one ally an agility boost, increasing the chances of
dodging enemy attacks.
Holy Protection - 3 MP: Protects one ally, lessening the blows of monsters.
Divine Light - 4 MP: Illuminates the dungeon, allowing you to see.

Priest Spells Level 2  -  Gained at Level 3
Divine Protect - 5 MP: One ally gets protected.
Cure Serious - 6 MP: Heals an ally for about 12 HP.
Cause Wounds - 6 MP: Damages a single enemy.
Safeguard Party - 5 MP: Protects the entire party.

Priest Spells Level 3  -  Gained at Level 5
Protection - 7 MP: A party member of your choosing is granted protection.
Cripple - 8 MP: Damages all enemies.
Heroism - 7 MP: One ally gets an agility boost.
Injure Group - 9 MP: Attacks a group of enemies.

Priest Spells Level 4  -  Gained at Level 7
Disfiguration - 12 MP: Attacks all enemies. The best multi-target spell, IMHO.
Hall of Heroes - 11 MP: Grants the party an agility boost.
Revitalize - 10 MP: Heals an ally completely.
Flame Onslaught - 11 MP: Strikes a single target.

Priest Spells Level 5  -  Gained at Level 9
Negate - 12 MP: Negates magic resistance...or at least it should...
Mar Enemies - 13 MP: All enemies are damaged.
Sustain Char - 10 MP: The selected adventurer gains protection.
Quickness - 11 MP: Gives an agility boost to the entire party.

Priest Spells Level 6  -  Gained at Level 11
Resurrect - 20 MP: Revitalizes a fallen ally.
Death - 20 MP: Instant death to one target.
Divine Shield - 14 MP: Upon casting, every party member recieves protection.
Vision of Pain - 15 MP: Deals damage to all targets.


Mage Class spells:
Mage Spells Level 1
Magic Missile - 3 MP: Damages a single target.
Magic Shield - 3 MP: Protects an ally.
Enchanted Flame 4 MP: Rids the surrounding area of darkness.
Minor Heroism - 3 MP: The agility of one ally is increased.

Mage Spells Level 2  -  Gained at Level 3
Fire Brand - 6 MP: Attacks one target.
Flamebolt - 7 MP: A group of enemies are damaged.
Magic Armor - 5 MP: The defensive capabilities of one ally is increased.
Party Shield - 5 MP: A magical defense is bestowed upon the party.

Mage Spells Level 3  -  Gained at Level 5
Cold Bolt - 9 MP: Enemies in a group of your choosing are harmed.
Party Armor - 7 MP: A boost of defense is given to each and every party member.
Shield - 7 MP: Raises a single adventurer's defensive power.
Rain of Fire - 9 MP: All enemy creatures feel pain.

Mage Spells Level 4  -  Gained at Level 7
Lightning Storm - 12 MP: Dishes out damage to every monster.
Wind Rage - 11 MP: Monsters in one group receive damage.
Blazing Spear - 10 MP: A damaging blow of about 35 HP is dealt to one target.
Energy Drain - 11 MP: All allies become more agile (Energy Drain? Huh?).

Mage Spells Level 5  -  Gained at Level 9
Negate - 12 MP: Attempts to negate enemy magic resistance, but does a poor job.
Fire Burst - 14 MP: All enemy beings are damaged.
Lightning Bolt - 13 MP: Damage is given upon casting at an enemy group.
Fortification - 10 MP: After choosing an ally, they get protected.

Mage Spells Level 6  -  Gained at Level 11
Invisibility - 12 MP: Boosts the defensive prowess of a single party member.
Death - 20 MP: Snuffs the life out of a single target.
Disintigrate - 18 MP: Every enemy takes a powerful hit.
Party Waver - 16 MP: Every party member takes a defensive increase.

A note about spells...the protection and agility spells may seem like something
useful to cast, but you can get through the game without casting a single one
of these spells. Also, I've found that Disfiguration is the best all-target
spell, better than Mar Enemies and Vision of Pain. The reason is the consistent
high damage of 16-18 HP. Mar Enemies doesn't get past 10 HP, and Vision of Pain
is just too random. Disfiguration even beats a mage's Disintigrate spell, which
is also random in the damage it causes.

For single target spells, nothing beats the damage of a mage's Blazing Spear.
It can do about 35-40 HP each time it connects. Of course with the pendant,
Death beats everything, if you have it.

The Negate spells of each class are useless in combat. Although it says
'negation of magic is in effect,' enemies are still able to resist magical
attacks. Besides, why cast Negate when you have the Pendant of Vernon...


Well, that's that.

Still stuck after reading my genuine piece of crass literature? Need a
clarification on a certain area? Conjure up a magic e-mailissile at
DesertGunstar@hotmail.com.

This Document is Copyright(c) 2004 by Desert Gunstar