===============================================================================
Ancients 2: Approaching Evil for the PC
Walkthrough

Created by Desert Gunstar (aka Shadow2099)
desertgunstar@hotmail.com
Completed Feb. 9, 2004
===============================================================================

===============================================================================
Table of Contents
===============================================================================
1. Introduction
2. Setting Up and Heading Off
3. Walkthrough
     a. Hidden Cavern below Inar's home
     b. The Great Outdoors
     c. The Wizard's Tower
     d. Ancient Catacombs
4. Experience and Equipment Charts
5. Magic Spells

===============================================================================
1. Introduction
===============================================================================
Ancients 2: Approaching Evil is the second installment of games created by the
company Farr-Ware, and published under Epic Megagames. The game is basically
unchanged, but a few new things here and there have been added, including a
graphical intro (yay!). This time around, you have been called to the city of
Wildron by your old friend Inar. The letter you recieved must be urgent, as he
did not disclose many details within. He warns you of an evil that is slowly
approaching the world, and only you are able to stop it...


===============================================================================
2. Getting Started
===============================================================================
Like any game of this type, we have to start off our by making our characters.
You don't really have to roll your own characters, as the defaults are decent
enough (a ranger, paladin, priest and mage). Of course, it can be a bit more
fun to customize and name your own. The process is the same from Ancients 1,
so you shouldn't have any problems if you've played the previous installment.

Now that we're treated to 2 more classes in Ancients 2, we can ditch the ultra-
useless (IMHO) Rogue and Warrior for the slightly more useful Ranger and
Paladin classes. The Ranger is able to use mage spells, and the Paladin gets
access to the Priest spells. Both classes also act as warriors, and can use any
weapon in the game. However, their rate of learning new spells is very slow;
a new spell level is gained at level 7 first, and then every 4 levels, as
opposed to the Priest/Mage's 2 levels. Again, I find 3 Priests and 1 Mage to be
the best setup possible. With a complement of 4 heavy magic users in the party,
you can cast 3 waves of Disfiguration (renamed Disfigurization in Ancients 2)
followed by a finishing touch of a mage's Blazing Spear. You might find more
fun in using the various classes, though, so keep that in mind. If you do
decide to use 3 Priests and 1 Mage, remember that a Priest is limited to
non-bladed weapons and a Metal Shield when fighting in the front lines.

Ancients 2 also gives us 2 new races: the half-elf and the hobbit. Your choice
of race still has no profound impact in the game as far as I can see, but it's
nice to see that they tried, heh...

Your character's stats should have 15/16 in each of the 4 primary stats when
you roll them up. This ensures that your character will get bonuses from their
stats when they level up. Your life points should at least be in the double
digits range, as well as your magic points (if any). Keep in mind that stats
max out at 19, and you receive a stat when you level up at the Guild. The
stats and bonuses for each character are as follows:

Strength- The physical strength of the character. Determines how hard the
character can hit. If your strength is over 15, you will gain a bonus of +1 to
your damage for every point over.

Dexterity- The character's agility and combat skills. Increases the chance of
making contact with the enemy, while avoiding their blows in turn. If your dex
is over 15, you will get +1 bonuses to your chance to hit for every point over.
In addition, your armor class recieves a +1 bonus.

Constitution- Ability to recover HP when camping.

Intelligence- Ability to recover MP when camping.

Physical and Magical resistance- Ability to lessen the blows caused by physical
or magical means. These numbers NEVER EVER change, and if they do, please tell
me. I've gone through this game so many times, casting magic spells, equipping
items that 'possess strong magic,' and I've turned up with nothing...

If you've saved your characters from Ancients 1, you can import them into 2 by
simply copying the files that end in .KAR (the character files) and placing
them into the folder where Ancients 2 is. When you begin a game with imported
characters, you'll find that they will be totally void of any equipment and
sent back to level 1. Imported characters will only retain their 4 main stats,
their current Draco that they're holding, and nothing else...

...Unless, you imported a character with the Pendant of Vernon. If you import
a character with the pendant in their inventory, they will retain all their
equipment and be sent back only to level 3 instead of level 1. However, the
pendant will disappear from inventory. You might want to load Ancients 1, give
all your good stuff to one character, save the game, and then import that
character to A2. If nothing else, you can bring over the Sword and Mace of
Relnor, 'cause the only way you're going to find it in A2 is from random enemy
encounters. That's not all it, though! You can carry over the pendant if you
place the item into your belt slot. When you import it, it will still be there.
Pretty nice, eh? It works in battles, but it may not serve much purpose to you
in the game, even in the later stages. At least you'll be able to trounce
enemies easily...do this if you feel like it.

Another side note I feel I have to add: you may remember having the ability to
duplicate items in A1 by adding more than one of a person to your party. A2 has
fixed that now...not that there's a great need to duplicate items in both games
anyway.

Now that I've got all of that off my chest, let's start our adventure already!
We will begin...in the city of Wildron, where your old friend Inar resides. He
has something important to tell you, and it doesn't look like the news can wait
for long.


===============================================================================
3. Walkthrough
===============================================================================
-------------------------------------------------------------------------------
a. Hidden Cavern below Inar's home
-------------------------------------------------------------------------------

The City of Wildron:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 #|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#
02 #|.|.|.|.|.|.|.|.|.|X|.|X|.|X|.|.|.|.|.|.|.|.|.|#      Legend:
03 #|.|X|.|  _   _   _____   _   _   _  |.|.|.|.|.|#
04 #|_   _  |.| |.|X|.|.|.|X|.|X|.|X|.|  ___   ___|#
05 #|.| |.|X|.| |.|.|.|.|.|.|.|.|.|.|.| |.|.| |.|.|#      X- private residence
06 #|X| |X|.|X| |.|  _____   _____  |.| |.|.| |.|.|#      S- Shop
07 #|.| |.|X|.| |.| |.|.|.| |.|.|.| |.|_|.|.| |.|.|#      I- Inar's home
08 #|  ___   ___|.| |.|S|.| |.|S|.| |.|.|.|.| |.|.|#      O- gate leading to
09 #| |.|.| |.|.|.|  _   _   _   _  |.|.|  _____  |#         wilderness
10 #| |.|X| |.|.|.| |.|S|.| |.|S|.| |.|.| |.|.|.| |#      .- wall
11 #| |X|.| |.|.|.| |.|.|.| |.|.|.| |.|.| |.|.|I| |#
12 #| |.|.| |.|.|.|_______   _______|.|.| |.|.|.| |#
13 #|  ___  |.|.|.|.|.|.|.| |.|.|.|.|.|.|___   ___|#
14 #| |.|.|  _   _  |.|S|.| |.|.|  _  |.|.|.| |.|.|#
15 #| |.|X| |.|X|.| |.| |.| |.|.| |.|_   ___   _  |#
16 #| |X|.| |X|.|X|  ___   _   _  |.|.| |.|.|X|.| |#
17 #| |.|.| |.|X|.| |.|.| |.|X|.| |X|X| |.|X|.|.| |#
18 #|  _   ___   ___|X|.| |.|X|.| |.|.|  _   ___  |#
19 #| |.|X|.|.| |.|.|.|X|  ___   _   _  |.|X|.|.| |#
20 #| |.|.|X|.| |.|X|.|.| |.|.| |.|X|.| |.|.|X|.| |#
21 #|  _   _   _          |.|X| |.|X|.|  _   ___  |#
22 #| |.|X|.|X|.| |.|X|.| |X|.|  _   _  |.|X|.|.| |#
23 #| |.|X|.|X|.| |.|X|.| |.|.| |.|X|.| |.|.|X|.| |#
24 #|                           |.|.|.|           |#
25 #|#|#|#|#|#|#|#|#|#|#|O|#|#|#|#|#|#|#|#|#|#|#|#|#


If you've read my walkie for A1, you might have noticed a few things with my
ASCII maps... these maps are bigger. A2 uses 25*25 (which I've blown up to
50*25 for readability and presentation :) as opposed to A1's 20*20. Thus,
more space is needed for my horrible, pathetic travesty of a joke of a map.
Also, the format looks a bit more neat than the maps I did for A1...

 _____________________________________________________________________________ 
!Oh yes, I also need to issue a warning for you would-be adventurers. When you!
!descend/ascend nearly any floor of any dungeon, your compass will glitch and !
!point you in the wrong direction. This will fix after you Save/Re-load your  !
!game, or after battle. However, your position on the map will be re-located. !
!This is because when your compass was glitched, the game believes that the   !
!direction given by the compass is the right one. Thus, it will construct the !
!map this way...what a pain, isn't it? You will have to use your surroundings !
!to determine your position. If you're using my maps, keep in mind that I     !
!display the map after the compass glitch has passed away. The darn bug shows !
!up everywhere, except for the first 2 floors in Inar's Home.                 !
!_____________________________________________________________________________!

Okay, let's prepare ourselves and head out! First off, pool all of your gold to
one person and purchase weapons for your characters in the front ranks. Any
gold that you have left over can be used to purchase any pieces of armor that
you need, but don't buy any ranged weapons yet, as you'll need all the money
you have. Your priest should stick to healing spells, while your mage casts
magic missile from the back row.

This time in A2, the casino still sees very little use, but if you're planning
to get all of your equipment in one go, the casino makes it easier. There is a
new game called The Coin. Although not very fun, it is an easy way to make
gold to start off with. You simply pick a character, bet gold (max is 99), and
pick a side of a coin. It's a 50% chance to win, as opposed to the roulette's
25%. If you find yourself getting thrashed in the beginning, you might as well
abuse the casino so that you can get all your equipment at the beginning. Just
a thought...

Head for Inar's home when you believe yourself to be prepared for combat. It
might be rough at first, but it gets easier. If it's too rough, I suggest going
into the wilderness and building your levels to 3, so that you can cast some
stronger magic spells. Inar's home is located in the north east quadrant.

Inside, you will find a note from your old friend, and an opened trap door in
the floor. Descend into the caverns below, and don't forget to cast a Light
spell.


The Caverns below Inar's home, 1st Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.      X- door
02 .|*  |.|    X  |_|    X   __X_________X__  |.|U|.
03 .|____X____|.|__X____|.|X|.|.|.|.|.|.|.|.|X|.| |.      U- stairs going up
04 .|.|.|.|.|.| |.|.|.|.|___  |.|  ______X    |.| |.      D- stairs going down
05 .|  _   _   _______  |.|.|X|.| |.|.|.|.|_  |.| |.
06 .| |.| |.| |.|.|.|.| |.|   |.|___  |.| |.|X|.| |.      !-  picture of a
07 .| |.|.|.|    _____   X____|.|.|.|_   ___   _  |.          lantern
08 .|  _________|.|.|.| |.|.|.|D_X  |.| |.|.|X|.|X|.
09 .| |.|.|.|.|.|  _    |.|   |.|.| |.|   |.| |.| |.
10 .|  _________  |.|  __X_____X____  |.| |.| |.| |.
11 .| |.|.|.|.|.| |.| |.|.|.|.|.|.|.|X|.| |.| |.|.|.      *- Inar's corpse, a
12 .| |.|  ___   _   _   _   ______X  |.| |.| |.| |.         deathwand, and a
13 .| |.| |.|.| |.| |.| |.| |.|.|.|.|.|.|  _______|.         cross
14 .| |.|_  |.| |.| |.| |.| |.| |.|.| |.| |.|.|.|.|.
15 .| |.|.| |.| |.| |.|_   _________________   X  |.
16 .|_   _______   _  |.| |.|.|.|.|.|.|.|.|.|X|.| |.
17 .|.|X|.|.|.|.|X|.|_____|.|  _   ___________|.| |.
18 .|   |.|   |.|   |.|.|.|.| |.|X|.|.|.|.|.|.|.|X|.
19 .|  __X__  |.|_   X    |.|  X   _________   X  |.
20 .|X|.|.|.|X|.|.|X|.|  _|.| |.|X|.|.|.|.|.|X|.| |.
21 .|_   _   ___ X  |.|X|.|.| |.|  _   ___   _|.| |.
22 .|.|X|.|X|.|.|.| |.|___________|.|X|.|.|X|.|.|X|.
23 .|   |.|   |.|.|X|.|.|.|.|.|.|.|   |.|   |.|   |.
24 .|!  |.|    X                 X    |.|   |.|   |.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Don't go splunking around the caverns recklessly, as you have a brittle party
right now. Save often when traversing the darkness. To start off, camp near the
staircase leading outside and fight monsters to gain levels. When you get
enough experience for a level, make sure to head back to the guild to recieve
your level up bonus. If you want to cheat a little, you can save before you
enter the guild house, and then get your level up bonus. If it's too low or if
you don't get a stat increase (you won't get a stat if it's already at 19), you
can reload your game and repeat this until it falls into your favor.

Head for the upper-left corner to find Inar. He has suffered many attacks and
his lifeless body is all that you will discover. Take his deathwand to aid you
on your quest to seal the catacombs, as well as the cross. The cross is one of
the artifacts necessary to close the catacombs, so keep it in your pack. Here's
another abusive defect for you: if you drop the cross and walk over the spot
where Inar's body lies, you will get another deathwand and the cross. Repeat
this for infinite deathwands. Tuun est...it's up to you.

Make sure to keep an eye out for better equipment for your party. It's best to
look for it on the first floor, 'cause you'll need it for the lower levels.


2nd Floor of the caverns:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|  _____  |.|  _______________   ___  |.|  _  |.
03 .| |.|.|.| |.| |.|.|.|.|.|.|.|.| |.|.|  ___|.| |.
04 .|  X_U_X  |.| |.|  _   _   _   _  |.| |.|.|.| |.
05 .| |.|.|.| |.| |.| |.|X|.| |.| |.| |.|    _   _|.
06 .|  _   ___ X  |.| |.| |.|___  |.|_____  |.| |.|.    *- chest containing a
07 .| |.|X|.|.|.| |.| |.| |.|.|.|_|.|.|.|.| |.| |.|.       gem
08 .| |.|   |.|  _|.| |.| |X|   |.|.| |.|  _|.|_  |.
09 .|_|.|    X  |.|  _|.| |.|_  |.|.|     |.| |.| |.    !- description of a
10 .|.|.|X|.|.| |.| |.| |.|.|.|X|.|.|.|.| |.| |.| |.       room with tables and
11 .|  _   _   _______  |.| |.| |.|   |X| |.| |.| |.       chairs
12 .| |.| |.| |.|.|.|.|___   _  |.|.|X|.| |.| |.|X|.
13 .| |.|X|.|  __X    |.|.| |.|_______________|.| |.    @- hanged skeleton
14 .|  X__   _|.|.|___|.|.|_  |.|.|.|.|.|.|.|.|.| |.
15 .| |.|.|X|.|_  |.|.|   |.|  _____   _   _  |.| |.
16 .| |.|   |.|.|X|.|  _  |.| |.|.|.| |.| |.| |.| |.
17 .|  X_!__|.|.| |.| |.| |.| |.| |X|  _  |.| |.|X|.
18 .| |.|.|.|@|X| |.| |.| |.| |.| |.| |.|  _  |.| |.
19 .|_   _  |.|.|X|.|_____|.| |.|X|.|  _  |.|  X  |.
20 .|.|X|.|_____  |.|.|.|.|  _________|.| |.| |.|_|.
21 .|.|   |.|.|.|  _   _____|.|.|.|.|.|.|.|.|X|.|.|.
22 .|.|_  |.|D|.|_|.|X|.|.|.|_______   X________  |.
23 .| |.|X|.|X|.|.|    X    |.|.|.|.| |.|.|.|.|.| |.
24 .|____________X____|.|    X        |.|*_X______|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

You can explore this cavern if you want. There are a few rooms with details of
certain things, but they're not significant to completing the game. In the
south east corner, there lies a locked chest which must be forced open to
obtain the treasure inside. There's nothing special involving the opening of
the chest. Simply click on a character until the chest opens (FYI, a character
with a strength of 18 will always be successful). You will recieve a gem, which
is needed for the ancient catacombs later on in the game.

Be careful when going up or down the staircases on this floor. If you go up the
stairs through the west side, your compass will glitch (see the above boxed
text for an explanation). Also, your compass will glitch no matter what when
you descend to the third floor, so watch out...


3rd Floor of the Caverns:
   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|  _____   _  |.|  _   _   _  |.|__X____   X_U|.
03 .| |.|.|.| |.|  ___|.| |.| |.|_  |.|.|.|.|X|.|.|.
04 .| |.|  _  |.| |.|.|  _|.|_  |.|_________   _  |.
05 .| |.| |.| |.| |.|_  |.| |.| |.|.|.|.|.|.| |.| |.
06 .|  _   _  |.|_  |.| |.|_   _   _____   _____  |.
07 .| |.| |.| |.|.| |.| |.|.|X|.| |.|.|.| |.|.|.| |.
08 .| |.| |.|  X__   X   ______X   _   _   _____  |.  *- door knocker for the
09 .| |.| |.| |.|.| |.| |.|.|.|.| |.| |.| |.|.|.| |.     tower entrance
10 .|X|.|___  |.|  _________   ___|.| |.|  _____  |.
11 .|   |.|.|  X  |.|.|.|.|.|X|.|.|.| |.| |.|.|.| |.
12 .|____X   _|.|  _  |.|  ___|.|  _______   ___  |.
13 .|.|.|.| |.|  _|.| |.|X|.|.|.| |.|.|.|.| |.|.| |.
14 .|    X  |.| |.|  _____   _   _   _   _______  |.
15 .|  _|.| |.|___  |.|.|.| |.| |.| |.| |.|.|.|.| |.
16 .|X|.|.| |.|.|.| |.|  _  |.| |.| |.| |.|  ___  |.
17 .| |.|  _   ___  |.| |.| |.| |.|_______  |.|.| |.
18 .| |.| |.| |.|.| |.| |.| |.| |.|.|.|.|.|X|.|.| |.
19 .|_   _|.|  X__  |.| |.| |.|_______  |.|_  |.| |.
20 .|.|X|.|.| |.|.| |.| |.| |.|.|.|.|.|_  |.| |.| |.
21 .|   |.|  _|.|  ___   _____   X    |.| |.| |.| |.
22 .|  _|.|_|.|  _|.|.| |.|.|.| |.|  _|.| |.| |.| |.
23 .|X|.| |.|.| |.|  _____   _  |.|X|.|  _|.| |.| |.
24 .|* X            |.|.|.| |.| |.|     |.|       |.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Not much to this level...there are 2 things to note. The first is that this is
your first encounter with the compass glitch. As I've said before, remedy it by
saving/loading your game or get into a fight. After you've done that, your
compass will point in the right direction, but your position in the map will
be re-located. Watch out...

The other point of interest is the door knocker in the south west corner.
Before you grab it, though, save your game in front of it and camp until you
are at your maximum HP. Once you grab it, the cavern will start to shake. Rocks
will start to fall from the ceiling, damaging you for a fair amount of HP. Make
your way back to the staircase in the north east before the party is buried six
feet under. Leave the caverns when you're home free.

Your newly found door knocker will allow you to enter the Tower, which contains
the lantern that can light the way inside the Catacombs. In order to get to the
Tower, you'll have to venture through the vast wilderness surrounding it first.
Make preparations and leave Wildron through the door on the south wall of the
city.


-------------------------------------------------------------------------------
b. The Great Outdoors
-------------------------------------------------------------------------------

Wilderness:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|C|.|_____   _   _|.|  ___   ___  |.|.|.| |.| |.
03 .| |.|.|.|.| |.| |.|_  |.|.| |.|.|  _   _  |.| |.
04 .| |.|  ___   _  |.|.|_|.|  T   _  |.| |.|  _  |.
05 .|  _  |.|.| |.| |.| |.|  _   _|.|_|.| |.|_|.|_|.    C- entrance to the
06 .|_|.| |.|  _   _   ___  |.| |.| |.|  _  |.| |.|.       catacombs
07 .|.|.|  _  |.|_|.| |.|.|___   _   _  |.|  _   _|.
08 .|  _  |.|_  |.|.| |.| |.|.| |.|_|.|  _  |.| |.|.    T- entrance to the
09 .| |.|  _|.|  ___   _   _|.| |.|.|  _|.|_   _  |.       tower
10 .|  _  |.|  _|.|.| |.| |.|  _|.|.| |.| |.| |.| |.
11 .|_|.|_   _|.| |.|  _   _  |.|  _   ___   _   _|.    W- city of Wildron
12 .|.| |.| |.|_____  |.| |.|  _  |.| |.|.| |.|_|.|.
13 .|  ___   _|.|.|.|_   _|.|_|.| |.|  _   _  |.| |.    A- city of Arnor
14 .| |.|.| |.|_  |.|.| |.| |.|  _|.| |.| |.|  _  |.
15 .|  _|.|  _|.| |.|  ___   ___|.|  _|.|  _  |.| |.
16 .| |.|.| |.|_   _  |.|.| |.|.|  _|.|  _|.|___  |.
17 .| |.|  _  |.| |.| |.|.|  ___  |.|___|.|.|.|.| |.
18 .|_   _|.|_____   _   _  |.|.|  _|.|.|      _  |.
19 .|.|_|.|.|.|.|.| |.| |.| |.|  _|.|  _   A  |.| |.
20 .| |.|     |.|  _   _   _|.| |.|  _|.|_   _|.| |.
21 .|  _   W   ___|.|_|.| |.|  _   _|.| |.| |.|.| |.
22 .| |.|_   _|.|.| |.|  ___  |.| |.|.|_   _   _  |.
23 .| |.|.| |.|_   _   _|.|.| |.| |.| |.| |.| |.| |.
24 .|_________|.|_|.|_|.|.|_______________________|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Despite being a big, lushious area to explore, there isn't much for you to do
out here in the wilderness. The monsters are easy to defeat and the city of
Arnor contains nothing important (it doesn't even have a guild!). Nope, the
only thing you're out here for is to get to the Tower and the Catacombs later
on. I've included a map of Arnor just in case you want to go there anyway...
Heck, maybe you'll find something I haven't. Whatever the case, enter the Tower
in the northern part of the wilderness. The owner of the tower must be cheap to
not install some well-placed torches for your party, so you'll have to make do
with a Light spell.


The City of Arnor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .| |.|.|  ___   ___   _   ___   ___   _  |.|.| |.     X- private residence
03 .| |.|X  |.|.| |.|.| |.|X|.|.|X|.|.|X|.| |.|.| |.
04 .| |.|.|  X|.| |.|X  |.|.|X|.|.|X|.|.|.|  ___  |.     A- armory
05 .|  ___  |.|X   A|.|  _   ___   _   ___  |.|.| |.
06 .| |.|.| |.|.| |.|X  |.|X|.|.|X|.| |.|.|  X|.| |.     T- temple
07 .|  X|X__   ___|.|.| |.|.|.|X|.|.| |.|T  |.|X  |.
08 .| |.|.|.| |.|.|.|X _   _   _   _   X|.|  X|.| |.     C- casino
09 .|  X|.|.|_  |.|X|.|.| |.|X|.|X|.| |.|.| |.|.| |.
10 .| |.|.|.|.|_   _   _  |.|.|X|.|.|  _   _____  |.     I- inn
11 .|_  |.|X|.|.|X|.|X|.|  ___   ___  |.|X|.|.|.| |.
12 .|.|  _  |.|X|.|X|.|.|X|.|.|X|.|.| |.|.|X|.|.| |.     W- exit to wilderness
13 .|.| |.|_   _   _  |.|X|.|X|.|X|.|  ___   ___  |.
14 .|X   X|.|X|.|X|.|  ___   ___   _  |.|.| |.|.| |.
15 .|.| |.|.|.|.|.|X  |.|.|X|.|.|X|.| |.|X  |.|X  |.
16 .|  ___  |.|X|X|.| |.|X|.|.|.|.|.| |X|.| |.|.| |.
17 .| |.|.|  _   _   ___   _  |.|X|.| |.|.|  X|.| |.
18 .| |.|X  |.|X|.| |.|.|X|.|  _   ___   _  |.|.| |.
19 .|  X|.|  X|.|X  |.|X|.|.| |.|X|.|.|X|.| |.|X  |.
20 .| |.|.| |.|X|.| |.|  ___  |.|.|X|.|.|.| |.|.| |.
21 .|  _   _   _   _    |.|.|  _   ___   ___   _  |.
22 .| |.|X|.|X|.|X|.|X   X|.| |.|X|.|.|X|.|.|I|.| |.
23 .| |.|.|X|.|X|.|X|.| |.|X  |.|.|C|.|.|.|X|.|.| |.
24 .|____________________X|.|  ___________________|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|W|.|.|.|.|.|.|.|.|.|.|.

Welcome to Arnor, the city where absoulutely nothing happens. The armory sells
the same equipment as Wildron, the casino has the same games, and the barflies
at the inn tell you the same thing you may have heard in Wildron. Get out of
here as soon as you complete your business here, whatever it is.

-------------------------------------------------------------------------------
c. The Wizard's Tower
-------------------------------------------------------------------------------

The Wizard's Tower, 1st Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|  ______!______  |.|.|  _____   ___   _____  |.
03 .| |.|.|.|.|.|.|.|_______|.|.|.| |.|.| |.|.|.| |.
04 .| |.|  ____X    |.|.|.|.|_   _____|.| |.|@|.| |.  !- 'you can hear moaning
05 .|  ___|.|.|.|___|.|  _  |.|X|.|.|.|.| |.|X|.| |.      in this area'
06 .| |.|.|  _  |.|.|   |.|  __________X  |.|  X  |.
07 .|  X____|.| |.|  _  |.| |.|.|.|.|.|.|  X  |.| |.  @- humanoid prisoner
08 .| |.|.|.|  _|.| |.| |.|  _______  |.| |.|X|.| |.
09 .| |.|___  |.|___    |.| |.|.|.|.|  ___   ___  |.
10 .|_  |.|.| |.|.|.|_  |.| |.|  ___  |.|.| |.|.| |.
11 .|.|_  |.|  ___  |.|___   _  |.|.|  _________  |.
12 .|.|.| |.| |.|.|_  |.|.|_|.|  ___  |.|.|.|.|.| |.
13 .|D|.| |.|___  |.|___  |.|.| |.|.| |.|  _   _  |.
14 .|X|.| |.|.|.|_  |.|.|_______  |.| |.| |.|X|.| |.
15 .|___  |.|_  |.|___  |.|.|.|.| |.| |.| |.|  X  |.
16 .|.|.|_  |.| |.|.|.|______!__  |.|  ___|.| |.| |.
17 .|   |.| |.|_____  |.|.|.|.|.| |.| |.|.|.|X|.| |.
18 .|_   X    |.|.|.|  _________  |.| |.|  _____  |.
19 .|.|X|.| |X|_   _  |.|.|.|.|.| |.| |.| |.|.|.| |.
20 .|    X  |.|.|X|.|  _   _   _____  |.| |.|  _  |.
21 .|_  |.|X|.|   |.|X|.| |.| |.|.|.| |.| |.| |.| |.
22 .|.|X| | |.|___|.|U|.| |.|___________   ___|.| |.
23 .|   |.| |.|.|.|.|.|.|X|.|.|.|.|.|.|.| |.|.|.| |.
24 .|____X___X____________________________________|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Nothing much of interest on the first floor. You will find an imprisoned
creature in the north east corner, but it doesn't offer much to say. You can
say key words like tower and catacombs to see some tidbits of text, but that's
about it. Power up if you wish, and then climb the stairs to the next floor.


The Wizard's Tower, 2nd Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .| |.|  _   X__   _   _______   _______   _  |.|.
03 .|X|.| |.| |.|.|X|.| |.|.|.|.| |.|.|.|.|_|.|_  |.
04 .| |.| |.|_|.|   |.| |.|   |.| |.|D_X  |.|.|.| |.    @- area where you can
05 .| |.|X|.|.|.|___|.| |.|_ @|.|_  |.|.|_______  |.       summon monsters
06 .|  _______  |.|.|_  |.|.|X|.|.| |.|.|.|.|.|.| |.
07 .| |.|.|.|.|___  |.|_____   _   _________   _  |.    *- enchanted shield
08 .|  X    |.|.|.|_  |.|.|.|X|.|_|.|.|.|.|.| |.| |.
09 .|X|.|___|.| |.|.|_________  |.|_   _   _  |.| |.
10 .|   |.|.|.|X|.|.|.|.|.|.|.|_  |.| |.| |.| |.| |.
11 .|  _|.|  ______X     X    |.|  X  |.| |.| |.| |.
12 .|X|.|.| |.|.|.|.|___|.|  _|.| |.| |.| |.| |.| |.
13 .|   |.| |.| |.| |.|.|.|X|.|  _|.| |.| |.| |.| |.
14 .|____X__   ________X     X__|.|  _|.|X|.| |.| |.
15 .|.|.|.|.|X|.|.|.|.|.|___|.|.|  _|.|   |.| |.| |.
16 .|  _________   _  |.|.|.|_   _|.|.|___|.| |.| |.
17 .| |.|.|.|.|.| |.|  X    |.|X|.|   |.|.|  _|.| |.
18 .|  _________  |.| |.|  _|.| |.|____X____|.|.| |.
19 .| |.|.|.|.|.| |.| |.|X|.|.|_  |.|.|.|.|.|  _  |.
20 .|  ___________|.| |.| |.| |.|_____________|.|X|.
21 .| |.|.|.|.|.|.|.| |.| |.| |.|.|.|.|.|.|.|.|   |.
22 .| |.|_ * _____|.| |.| |.|  _________   _|.|_  |.
23 .|X|.|.|X|.|.|.|.| |.| |.| |.|.|.|.|.| |.| |.|X|.
24 .|U_X__________________________________________|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Again, this floor is bare and uninviting...you can find a room which allows you
to summon monsters if you choose a character to read the runes. I don't see a
difference in selecting other characters to read the runes, and I don't see a
need to summon monsters to fight you for no reason whatsoever.

Near the upper staircase in the south west corner, there is a room that holds
a magic shield. The shield protects you fairly well, despite having a 0 armor
class value. You might notice that when you are attacked by certain monsters,
you will get a message saying that your character has been withered, or 
something of the sort. This shield will lessen the damage that these creatures
cause, so it comes in handy.


The Wizard's Tower, 3rd Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|@|_|.|  _____  |.|_______   _____   _  |.|   |.
03 .|X|.|  _|.|.|.| |.|.|.|.|.| |.|.|.| |.| |.|_ !|.
04 .| |.| |.|  ___   X____   _________  |.| |.|.|X|.
05 .| |.| |.| |.|.| |.|.|.|X|.|.|.|.|.| |.| |.|   |.   !- learn about the word
06 .| |.| |.| |.|  _|.|.|.| |.|  _______|.| |.|_  |.      'Inalsta'
07 .|  _   _   _  |.| |.|  _|.| |.|.|.|.|.|_  |.|X|.
08 .| |.| |.| |.|  _   _  |.|___________  |.| |.| |.
09 .| |.|___  |.| |.| |.| |.|.|.|.|.|.|.| |.| |.| |.   @- crystal ball
10 .| |.|.|.| |.| |.| |.| |.|   |.|  _   _|.|_____|.
11 .|  _____  |.| |.| |.|  X__  |.| |.| |.| |.|.|.|.
12 .| |.|.|.| |.| |.| |.| |.|.|X|.| |.| |.|_____  |.
13 .| |.|  _   _  |.| |.| |.|   |.| |.|  _|.|.|.| |.
14 .| |.| |.| |.|  _   _  |.|   |.| |.| |.|   |.| |.
15 .|_____|.| |.| |.| |.| |.|X|.|.| |.|  X____|.| |.
16 .|.|.|.|  _|.| |.| |.| |.|  ___  |.| |.|.|.|.| |.
17 .|D_X   _|.|  _____|.| |.| |.|.| |.|    _   _  |.
18 .|.|.|X|.|  _|.|.|.|_   _  |.|  _______|.| |.| |.
19 .| |.| |.| |.|  _  |.| |.| |.| |.|.|.|.|.| |.|_|.
20 .| |.| |.| |.| |.| |.| |.| |.|  _________  |.|.|.
21 .| |.| |.| |.| |.| |.| |.| |.| |.|.|.|.|.|X|.|U|.
22 .|  ___|.| |.| |.| |.|_____   _  |.|  _____|.|X|.
23 .| |.|.|.| |.| |.| |.|.|.|.| |.| |.| |.|.|.|.| |.
24 .|_____________|.|___________|.|_|.|___________|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Ugh...yet another floor of emptiness. I wonder if the designers really thought
that bigger maps would be better, regardless of the content. Anyway, you can
find a book in the north east corner that contains the word 'Inalsta.' If you
go to the crystal ball in the north west and speak this word, you can see a
small picture of the evil that is supposedly emanating from the catacombs. Move
to the top floor of the tower, and watch out for the compass glitch...


The Wizard's Tower, 4th floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|   |.| |.|  _____|.|.|_____  |.|   |.|    X  |.
03 .|* _|.|X|.| |.|.|.|   |.|.|.|  X   __X__  |.|X|.
04 .|X|.|.|  _   _   X   __X____  |.|X|.|.|.|X|.| |.
05 .| |.|.| |.| |.|_|.|X|.|.|.|.|_|.|   |.|   |.| |.  *- evil wizard, fight him
06 .|  ___  |.| |.|.|.|_______  |.|.|_  |.|____X  |.     to get the lantern
07 .| |.|.|_____   _  |.|.|.|.| |.| |.|X|.|.|.|.| |.
08 .| |.| |.|.|.| |.|  _______  |.|___   _____|.| |.
09 .| |.|  _____  |.| |.|.|.|.| |.|.|.|X|.|.|.|.|X|.
10 .| |.| |.|.|.| |.|  _______  |.| |.|   |.|.|   |.
11 .|  _______   _|.| |.|.|.|.| |.| |.|___|.|.|_  |.
12 .| |.|.|.|.| |.|.|  _______  |.|_  |.|.| |.|.|X|.
13 .| |.|   |.|  ___  |.|.|.|.| |.|.|___   _  |.| |.
14 .|  X____|.| |.|.| |.| |.|.| |.| |.|.| |.| |.| |.
15 .| |.|.|.|  _|.|  _   _   _   ___  |.| |.| |.| |.
16 .|_   _____|.|.| |.| |.| |.| |.|.|___  |.|_____|.
17 .|.| |.|.|.|.|.| |.| |.| |.| |.|.|.|.| |.|.|.|.|.
18 .|.| |.| |.|D|.| |.| |.|  _|.|  _____________  |.
19 .|.| |.|X|.|X|.| |.|  ___|.|.| |.|.|.|.|.|.|.| |.
20 .|  _   ___________  |.|.|.|.|X|.|  _____  |.| |.
21 .| |.| |.|.|.|.|.|.| |.| |.|   |.| |.|.|.|X|.| |.
22 .| |.|  ___________  |.| |.|  _|.|  _   ___|.| |.
23 .| |.| |.|.|.|.|.|.| |.| |.|X|.|.| |.|X|.|.|.| |.
24 .|______________________________X__|.|______X__|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Yay, the final floor of the blasted wizard's boring tower of Redundancy. The
lantern is the only reason you're here, and in order to get it, you must first
fight the evil wizard for it in the north west corner. He is flanked by a few
Death Knights, but the fight itself shouldn't be hard. A level of 7/8 will
offer a high chance of victory, where you can cast Disfigurization and Blazing
Spear. Once you attain the lantern, get the heck out of there. Watch out for
the compass glitches when you're travelling below...

Now that you're out, make preparations to enter the ancient Catacombs.
Technically, you don't have to do any fightning since there are no bosses at
all (the wizard was the only boss!). If you feel tempted to save/load the rest
of the way from here, you are free to do so, but you might as well continue
levelling up while you're in the home stretch. You should have the cross you
found on Inar's body, and the gem from the chest in the caverns. Keep that
Light spell in handy, too (even though you have a lantern...gah).

-------------------------------------------------------------------------------
a. Ancient Catacombs
-------------------------------------------------------------------------------

Ancient Catacombs, 1st Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|U X   _______   _   _______  |.|  _|.| |.|   |.
03 .|X|.| |.|.|.|.| |.| |.|.|.|.| |.| |.|  _|.|_ *|.
04 .| |.|  _______  |.|  ___  |.| |.| |.| |.| |.|X|.
05 .| |.| |.|.|.|.| |.| |.|.| |.| |.|_   _|.| |.| |.    *- stone golem, play
06 .| |.|  _______  |.|  ___  |.|_  |.|X|.|  __X  |.       his coin game to
07 .| |.| |.|.|.|.| |.| |.|.| |.|.|_________|.|.|X|.       retrive a rune
08 .| |.|      _    |.|  _______  |.|.|.|.|.|  _  |.
09 .|_______  |.|_____  |.|.|.|.|  ___   _|.| |.| |.
10 .|.|.|.|.|_  |.|.|.|  _   X   _|.|.| |.|.| |.| |.
11 .|_____  |.|_   _____|.|_|.|_|.|.|  _|.|  _|.| |.
12 .|.|.|.|_  |.| |.|.|.|.|.|.|.|.|.| |.|.| |.|.| |.
13 .|  _  |.| |.|_____   _   ___   _  |.|  _______|.
14 .| |.| |X|_|.|.|.|.| |.| |.|.| |.| |.| |.|.|.|.|.
15 .| |.| |.|.|  _  |.| |.|  _|.| |.| |.| |.|  _  |.
16 .| |.| |.|_  |.| |.| |.| |.|  _|.| |.| |.| |.| |.
17 .|X|.|_| |.| |.| |.| |.| |.| |.|  _|.| |.| |.| |.
18 .|   |.| |.|_|.| |.| |.|_|.| |.| |.|.| |.| |.| |.
19 .|_  |.| |.|.|.| |.| |.|.|  _|.| |.|_____  |.| |.
20 .|.|X|.|_______  |.|_|.|  _|.|.|_  |.|.|.|_   _|.
21 .|  _  |.|.|.|.|X|.|.|  _|.|   |.| |.|  _|.|X|.|.
22 .| |.|_________   _____|.|.|____X   X__|.|  _  |.
23 .| |.|.|.|.|.|.| |.|.|.|   |.|.|.| |.|.|.| |.|X|.
24 .|____________________X_____X______________|.|D|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

Inside the catacombs, there are three more artifacts that are required to seal
the entrance. The cross is one of them, and you'll find one on each of the 3
floors. The first you'll come across is in the north west corner, where a stone
golem resides. It will ask you to play a coin game. You will bid a quarter of
your life for the dwarf rune the stone golem holds. You have a 50% chance of
winning, so keep playing until you win.

The first floor is also the best place to get the rest of your levels, as the
monsters here give great experience and they don't resist as much magic as the
monsters below. Get to level 11 if you feel like it. Otherwise, use the save
game option heavily.


Ancient Catacombs, 2nd Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|U X______   _____   ________X   _   ____X    |.
03 .|X|.|.|.|.| |.|.|.| |.|.|.|.|.| |.|X|.|.|.|_  |.
04 .|  _________________________|.| |.|_   _|.|.|X|.  *- a pool of water,
05 .|X|.|.|.|.|.|.|.|.|.|.|.|.|.|.| |.|.|X|.|.|   |.     freeze it to get the
06 .| |.| |.|    X     X     X  |.|  ___   _|X|___|.     rune in the middle
07 .| |.|  X____|.|___|.|  _|.| |.| |.|.|X|.|.|.|.|.
08 .| |.| |.|.|.|.|.|.|.|X|.|  _|.| |.|___  |.|   |.
09 .| |.| |.|  ___________   _|.|.| |.|.|.|X|.|_  |.
10 .|_____|.| |.|.|.|.|.|.|X|.| |.|___   _  |.|.|X|.
11 .|.|.|.|.| |.|  _   _   ___  |.|.|.| |.| |.|   |.
12 .|  _________  |.| |.| |.|.|_   _   _|.|  X____|.
13 .| |.|.|.|.|.| |.| |.| |.|.|.|X|.| |.|.| |.|.|.|.
14 .|  X____  |.| |.| |.|  _   _  |.|X|.|  _   _  |.
15 .| |.|.|.|X|.| |.| |.| |.| |.| |.| |.| |.| |.| |.
16 .| |.|  ___|.| |.| |.| |.| |.| |.| |.| |.| |.| |.
17 .| |.| |.|.|.| |.| |.| |.| |.| |.| |.| |.| |.| |.
18 .| |.| |.|  _  |.| |.| |.|  _____  |.|___  |.| |.
19 .| |.|_|.| |.|X|.|  _  |.|_|.|.|.|  _|.|.|_|.|X|.
20 .| |.|.|  _|.| |.| |.| |.|.|.| |.| |.|   |.|   |.
21 .|  _   _|.|___|.| |.|_   ___  |.| |.|_   X   _|.
22 .| |.|_|.|D|.|.|  _|.|.|_|.|.| |.|X|.|.|X|.|X|.|.
23 .| |.|.|.|X|.|   |.|   |.|   |.|   |.|    X *  |.
24 .|________________X_____X____|.|___|.|___|.|___|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

The second floor's artifact is held in the south east. You will find a pool of
water with the rune trapped on an island in the middle of the water. All you
have to do is cast a freezing spell (Bolt of Cold/Freezing Death) and the rune
is yours.


Ancient Catacombs, 3rd Floor:

   a b c d e f g h i j k l m n o p q r s t u v w x y
01 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.
02 .|    X____  |.| |.|  _____  |.| |.| |.|  _|.|.|.
03 .|  _|.|.|.|_______  |.|.|.|___  |.|X|.| |.|   |.
04 .|X|.|_  |.|.|.|.|.|  ___  |.|.|_______   X____|.   *- wall with a gem slot,
05 .|   |.|  _________  |.|.|  _  |.|.|.|.| |.|.|.|.      insert your gem to
06 .|___|.| |.|.|.|.|.|_______|.|_____  |.| |.|   |.      retrieve the ankh
07 .|.|.|  _|.|  _  |.|.|.|.|.|.|.|.|.| |.|  X____|.
08 .|  ___|.|.| |.| |.|  _____________  |.| |.|.|.|.
09 .| |.|.|  _  |.| |.| |.|.|.|.|.|.|.| |.|  X    |.
10 .| |.|  _|.| |.| |.| |.|  _____  |.| |.| |.|_  |.
11 .|  _  |.|.| |.| |.| |.| |.|.|.| |.|X|.|_  |.|X|.
12 .| |.|X|.|  _|.| |.| |.|__X_*|.| |.|   |.| |.| |.
13 .| |.| |.| |.|.| |.| |.|.|.|.|.| |.|___|.| |.| |.
14 .| |.| |.|___|.| |.|_____________|.|.|.|.| |.| |.
15 .| |.| |.|.|.|.|X|.|.|.|.|.|.|.|.|.|  _______  |.
16 .| |.| |.|  _   ___________   _____  |.|.|.|.| |.
17 .| |.| |.|_|.|X|.|.|.|.|.|.| |.|.|.|_________  |.
18 .| |.| |.|.|.|_____________   X__  |.|.|.|.|.| |.
19 .|  ___   _  |.|.|.|.|.|.|.| |.|.|__________X  |.
20 .| |.|.|_|.|_  |.|  X_____X   ___|.|.|.|.|.|.| |.
21 .|  _  |.|.|.| |.|X|.|.|.|.| |.|.|  _   _____  |.
22 .|X|.|_______  |.|U_X______   _____|.| |.|.|.| |.
23 .|   |.|.|.|.| |.|.|.|.|.|.| |.|.|.|.| |.| |.| |.
24 .|____X_________X______________________________|.
25 .|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.|.

The final artifact lies within the middle of the floor. When you get there, you
will find a wall with a gem-sized hole. Here is the place to use your gem that
you saved for a while now. To use it, select the USE option (the icon that
shows a hand gripping a staff), then click the character who has the gem, and
then the gem itself. The ankh will finally be yours. Now that you've attained
all of the 4 pieces to seal the entrance, all you have to do now is get there.
Exit the catacombs, walk one square away from the catacomb entrance, and then
walk right back to it. Congratulations, you've successfully completed Ancients
2! Enjoy your few scant lines of text...you've earned it!


===============================================================================
4. Experience and Equipment Charts
===============================================================================
Experience Chart:
Level 2  - 500                Level 8  - 32,000         Level 14 - 128,000
Level 3  - 1,000              Level 9  - 48,000         Level 15 - 144,000
Level 4  - 2,000              Level 10 - 64,000         Level 16 - 160,000
Level 5  - 4,000              Level 11 - 80,000         Level 17 - 176,000
Level 6  - 8,000              Level 12 - 96,000         Level 18 - 192,000
Level 7  - 16,000             Level 13 - 112,000        Level 19 - 208,000


Items denoted with a * are not available in stores.

Weapons:
Name                     Damage                  Value
Bardiche                   9                      75
Battle Axe                 8                      50
Bow                    (arrows: 6)                50
Broad Sword                10                     100
Club                       6                      6
Dagger                     4                      5
*Elven Bow             (arrows: 7)                1000
Flail                      7                      35
Halberd                    9                      75
Hand Axe                   4                      5
Lance                      6                      20
Long Sword                 8                      55
Mace                       7                      40
*Mace of Relnor            11                     1000
Morning Star               7                      40
Pike Awl                   7                      45
Scimitar                   8                      53
Short Sword                6                      15
Sling                  (pellets: 4)               25
Spear                      6                      14
*Sword of Relnor           13                     1000
Trident                    8                      48
War Hammer                 7                      31


Armor:
Name                   Armor Class               Value
Boots                      1                      20
Chain Mail                 6                      180
Cloth                      1                      20
*Dwarven Boots             2                      200
*Dwarven Helm              1                      200
*Elven Boots               2                      200
*Elven Chainmail           7                      400
Gauntlets                  1                      25
Great Shield               3                      60
Helmet                     1                      40
Leather Armor              2                      40
Leather Gloves             1                      20
Metal Shield               2                      40
*Platemail                 7                      250
Ringmail                   4                      80
Scalemail                  4                      120
*Shield                    0                      0
Splintmail                 5                      150
Studded Leather            3                      60
*Winged Helm               2                      250
Wooden Shield              1                      25


===============================================================================
5. Magic Spells
===============================================================================
Priest Class spells:
Priest Spells Level 1
Cure Wounds - 3 MP: Heals an ally for around 7 HP.
Bless - 3 MP: Gives one ally an agility boost, increasing the chances of
dodging enemy attacks.
Holy Protection - 3 MP: Protects one ally, lessening the blows of monsters.
Divine Light - 4 MP: Illuminates the dungeon, allowing you to see.

Priest Spells Level 2  -  Gained at Level 3 for Priests, Level 7 for Paladins
Heal - 6 MP: Heals an ally for about 12 HP.
Safeguard Party - 5 MP: Protects the entire party.
Injure One - 6 MP: Damages a single enemy.
Divine Protect - 5 MP: One ally gets protected.

Priest Spells Level 3  -  Gained at Level 5 for Priests, Level 11 for Paladins
Protection - 7 MP: A party member of your choosing is granted protection.
Icy Death - 8 MP: Damages all enemies.
Injure - 8 MP: Same thing as Icy Death (huh? nice programming...).
Group - 9 MP: Attacks a group of enemies.

Priest Spells Level 4  -  Gained at Level 7 for Priests, Level 15 for Paladins
Heroism - 7 MP: Grants one ally an agility boost.
Greater Heroism - 11 MP: Grants the party an agility boost.
Disfigurization - 12 MP: Attacks all enemies. Great spell throughout the game.
Revitalize - 10 MP: Heals an ally completely.

Priest Spells Level 5  -  Gained at Level 9 for Priests, Level 19 for Paladins
Flame Touch - 11 MP: Strikes a single target.
Negate - 12 MP: The resistance of all enemies are lowered/possibly eliminated.
Creeping Doom - 13 MP: All enemies are damaged.
Sustain Char - 10 MP: The selected adventurer gains protection.

Priest Spells Level 6  -  Gained at Level 11 for Priests, Level 23 for Paladins
Quickness - 11 MP: Gives an agility boost to the entire party.
Resurrect - 20 MP: Revitalizes a fallen ally.
Death - 20 MP: Instant death to one target.
Psychic Fire - 15 MP: Deals damage to all targets.


Mage Class spells:
Mage Spells Level 1
Magic Missile - 3 MP: Damages a single target.
Magic Shield - 3 MP: Protects an ally.
Enchanted Flame 4 MP: Rids the surrounding area of darkness.
Minor Heroism - 3 MP: The agility of one ally is increased.

Mage Spells Level 2  -  Gained at Level 3 for Mages, Level 7 for Rangers
Magic Arrow - 6 MP: Attacks one target.
Bolt of Cold - 7 MP: A group of enemies are damaged.
Magic Armor - 5 MP: The defensive capabilities of one ally is increased.
Party Shield - 5 MP: A magical defense is bestowed upon the party.

Mage Spells Level 3  -  Gained at Level 5 for Mages, Level 11 for Rangers
Acid Bolt - 9 MP: Enemies in a group of your choosing are harmed.
Party Armor - 7 MP: A boost of defense is given to each and every party member.
Shield - 7 MP: Raises a single adventurer's defensive power.
Rain of Fire - 9 MP: All enemy creatures feel pain.

Mage Spells Level 4  -  Gained at Level 7 for Mages, Level 15 for Rangers
Transmutation - 12 MP: Dishes out damage to every monster.
Wind Rage - 11 MP: Monsters in one group receive damage.
Blazing Spear - 10 MP: A damaging blow of about 35 HP is dealt to one target.
Energy Drain - 11 MP: All allies become more agile (Energy Drain? Huh?).

Mage Spells Level 5  -  Gained at Level 9 for Mages, Level 19 for Rangers
Negate Magic- 12 MP: Lowers the magic resistance of all enemies.
Fire Burst - 14 MP: All enemy beings are damaged.
Hellfire - 13 MP: Damage is given upon casting at an enemy group.
Fortification - 10 MP: After choosing an ally, they get protected.

Mage Spells Level 6  -  Gained at Level 11 for Mages, Level 23 for Rangers
Invisibility - 12 MP: Boosts the defensive prowess of a single party member.
Death - 20 MP: Snuffs the life out of a single target.
Soul Pounding - 18 MP: Every enemy takes a powerful hit.
Party Waver - 16 MP: Every party member takes a defensive increase.

This time in Ancients 2, the spells are a bit more balanced. The agility and
protection spells may not see much use here (as it did in A1), but the higher
tier attack spells deal more damage. The Level 6 Priest spell Psychic Fire hits
all the enemies for 23 to 26 points of damage now (and also replaces the L6
spell Vision of Pain). A mage's Soul Pounding (replaces Disintigrate) can go
into the 30's range, but it can drop into single digits as well.

A mage's Blazing Spear is still the best single target spell. The damage given
to one enemy is around 35-40 HP. Death is great too, especially the deathwand.
You might also find the Hellfire group attack spell useful. It can deal damage
in the 20's range to each enemy, and it's quite consistant.

You don't get to use the Pendant of Vernon unless you import it with a
character holding it in the belt slot. Whether you want to get it or not is up
to you. The Negate spells actually work well now, but the magic resistance of
enemies may not be completely eliminated upon casting. You might want to use it
if you're having problems...


I'm about through here.

Are you lost in my world of indecipherable directions and inane advice? Do you
need some help on decoding this walkie? Let loose your questions, comments and
complaints (possibly 99% of your e-mail messages) at DesertGunstar@hotmail.com.

This Document is Copyright(c) 2004 by Desert Gunstar