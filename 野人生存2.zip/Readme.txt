RedWolf Design
Clonk Advanced Players Edition
Freeware-Version 1.0
                
Allgemeines:

Dies ist die Freeware-Version der Advanced Players Edition von Clonk. Sie 
darf frei kopiert und verbreitet werden, so lange keine �nderungen an den 
zum Spiel geh�rigen Dateien oder deren Zusammenstellung vorgenommen werden. 

Zum Spiel:

Clonk ist ein aktionsreiches Taktik- und Geschicklichkeitsspiel f�r zwei oder
mehr Spieler. Die Advanced Players Edition kann auch alleine gespielt werden,
jedoch erreicht der Spielspa� in keinem Fall den eines Zwei-Spieler-Spiels.
Jeder Spieler steuert getrennt seinen Clonk-Captain und den Rest seiner Clonk-
Mannschaft. Ziel des Spiels ist es, als erster den Captain des Gegners 
unsch�dlich zu machen.

Steuerung:

Hier die Standard-Tastaturbelegung (diese kann mit Hilfe der Option Keyboard
Controls im Options-Men� umdefeniert werden):

               Spieler 1                      Spieler 2

                Q  W  E      (Aktion)          7  8  9
                A  S  D      (Mannschaft)      4  5  6
                Y  X  C      (Captain)         1  2  3

Taste     Bedeutung (Tasten dr�cken und nicht festhalten.)

 Y,1      Captain marschiert nach links.
 X,2      Captain bleibt stehen.
 C,3      Captain marschiert nach rechts.
 A,4      Mannschaft marschiert nach links.
 S,5      Mannschaft versammelt sich und bleibt stehen.
 D,6      Mannschaft marschiert nach rechts.
 Q,7      Alle Clonks springen (in Runden, in denen gegraben werden kann).
 W,8      Alle Clonks werfen einen Stein (wenn sie einen haben).
 E,9      Captain beginnt zu graben (in Runden, in denen es m�glich ist).
 
Mit der Taste E bzw. 9 l��t man seinen Captain schr�g nach unten graben.
Anschlie�end kann er durch die Kommandos "Captain nach links", "Captain nach
rechts" oder "Captain anhalten" dazu gebracht werden, horizontal nach links
bzw. rechts zu graben oder anzuhalten. Um schr�g nach oben zu graben, mu�
das Kommando "nach links" bzw. "nach rechts" mehrfach gegeben werden.

Hilfe:

Innerhalb des Programms kann jederzeit mit F1 das umfangreiche Hilfesystem
aktiviert werden. Dieses enth�lt zahlreiche zus�tzliche Informationen, sowie
Hinweise und Tips.

Einige Hinweise und Tips:

- Mann-zu-Mann-K�mpfe werden automatisch ausgetragen, der St�rkere gewinnnt.
- Immer die �bersicht behalten! H�ufiges Versammeln der Mannschaft wird 
  geraten.
- Nicht den Captain aus den Augen verlieren, er ist nicht von den anderen
  Clonks zu unterscheiden!
- Nicht �berlange im Wasser bleiben.
- Das Katapult kann von jedem Clonk, der einen Stein tr�gt, geladen werden
  und wird automatisch abgefeuert.
- Clonks sind brennbar.
- Die Energie eines jeden Clonks regeneriert sich langsam im Bereich vor
  der Burg des jeweiligen Spielers.
- Vorsicht beim Graben! Viele Clonks sind bereits in ihren Minen ertrunken,
  oder sind aus zu tiefen L�chern nicht mehr herausgekommen.
- Durch einen Gang zum rechten oder linken Bildrand kann ein Abflu� f�r
  st�rende Wassermassen geschaffen werden. 
- Um Steine gegen neue Clonks einzutauschen, mu� man sie einfach in die daf�r
  vorgesehenen Loren werfen.
- Ein Goldklumpen hat den Wert von vier Steinen.
- Alte CLONK-Weisheit: Wer im Tunnel sitzt, sollte nicht mit Flintstones
  werfen.
- Durch geschicktes Graben k�nnen Barrieren f�r Monster geschaffen werden.

Systemanforderungen:

Clonk sollte auf jedem MS-DOS PC (mindestens schneller 386er) mit VGA-Karte
und Mouse laufen. Ein weitaus schnellerer Rechner (z.B. 486er) ist aber sehr 
zu empfehlen, da manche Spielelemente in Clonk �u�erst rechenintensiv sind.

Sound:

Besitzer einer SoundBlaster-Karte kommen in den Genu� von digitalisierten
Soundeffekten. Dazu mu� im Optionsmen� Sound Setup der Sound initialisiert
werden.

In jedem Fall sollten als erstes die Basisadresse und der eingestellte IRQ
auf ihre Richtigkeit hin �berpr�ft werden, da sonst Absturzgefahr besteht.
(Diese Einstellungen wurden automatisch vorgenommen, wenn die SoundBlaster-
Umgebungsvariablen gefunden werden konnten.)

Wer die beim SoundBlaster mitgelieferten Treiber auf seiner Festplatte
installiert hat (z.B. im Verzeichnis C:\SBPRO) sollte als erstes die
CT-VOICE-Methode ausprobieren (Init/Test CT-VOICE). Das Soundkartenver-
zeichnis mu� hierzu korrekt angegeben sein.

Wenn diese Methode versagt, z.B. weil der Treiber CT-VOICE.DRV nicht
gefunden werden konnte, bleibt noch die TIMER-Methode als Alternative.
Diese funktioniert unter Umst�nden sogar auf "nur" kompatiblen Karten, 
w�hrend des Spiels werden die Soundeffekte aber in jedem Fall den
Rechner verlangsamen.

Das Clonk-Sound System konnte bis jetzt leider nicht auf verschiedenen 
Karten getestet werden, ein wenig Gl�ck geh�rt also auch dazu.

Disclaimer:

Der Autor kann keinerlei Garantie daf�r �bernehmen, da� Clonk auf jedem
System l�uft. Weiterhin wird keinerlei Haftung f�r etwaige Sch�den �ber-
nommen, die durch die Benutzung des Programms entstanden sein k�nnten.

Kontakt:

RedWolf Design
Am Barkhof 20
28209 Bremen

http://www.clonk.de
info@clonk.de

Matthes Bender
Mai 1995
Freeware Januar 2001