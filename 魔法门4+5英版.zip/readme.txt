Heroes of Might and Magic V
Walkthrough (using game version 1.4.)

by K.K. Rouhiainen (kullervothecursed@dnainternet.net)

10.2.2007
Version 1.0

Table of Contents

A. Introduction
B. Technical Issues
C. Intro to walkthrough
The Queen
C1M1.The Queen
C1M2.The Rebellion
C1M3.The Siege
C1M4.The Trap
C1M5.The Fall of the King
The Cultist
C2M1. The Betrayal
C2M2. The Promise
C2M3. The Conquest
C2M4. The Ship
C2M5. Agrael's Decision
The Necromancer
C3M1. The Temptation
C3M2. The Attack
C3M3. The Invasion
C3M4. The Regicide
C3M5. The Lord of Heresh
The Warlock
C4M1. The Clanlord
C4M2. The Expansion
C4M3. The Cultists
C4M4. The March
C4M5. Raelag's Offer
The Ranger
C5M1. The Refugees
C5M2. The Emerald Ones
C5M3. The Defence
C5M4. The Archipelago
C5M5. The Vampire Lord
The Mage
C6M1. The Defiant Mage
C6M2. The Liberation
C6M3. The Triumvirate
C6M4. The Alliance
C6M5. Zehir's Hope
D. Some general tips
E. Copyright
F. Credits
G. Personal Notes
H. Version Notes

A. Introduction
---------------

This is a  walkthrough to Ubisoft's game Heroes of Might and Magic
V (HoMMV). You can find a lot of information (maps) about this game
and other games on the same brand from Celestial Heavens www-pages
at www.celestialheavens.com. Why to write a walkthrough to this
game? I searched the different forums and www-pages and found out
that some of the issues I knew were not in a brief (text) form,
giving you, the reader, freedom to adventure the game but still
pointing the crucial points to really enjoy your visit to Heroes of
Might and Magic Universe.

I want to thank Ubisoft Ltd. and Nival Interactive for a fun and
entertaining game. Please keep up the good work in providing this
kind of resource picking and battling game as I have had so much
fun with the series over the years. All the trademarks and other
rights are owned by their respective owners.

B. Technical Issues
-------------------

You may have found from the forums and playing the game that there
can be some difficulties to have fun with the game, when technical
issues with your computer slowing down or the gating crash
happening to you. I thought first it happened to me because I was
playing with a laptop not fulfilling the minimum requirements of
the game. Later I found the same issues with people with much
faster computers. Hopefully some ideas I have found will help you
to better enjoy the game.

First I would suggest you to update the game to version 1.4. and
install the newest DirectX. Some may argue to use other versions
because new bugs coming with later updates. So please try out how
my suggestions work for you, with your risk of course. I played the
game with version 1.4. without any (major) problems :-) Updates can
be found from Ubisoft's pages at: www.ubisoft.com or
www.celestialheavens.com. Ok. Now to some special issues and how I
have been able to deal with them.
-Gating problem. There seems to be a constant crash when you or the
enemy is using gating ability meaning that new creatures are
summoned during battle. First I used game option of automatic
battles for those few battles I could not win without this bug. But
the last mission of the game do not allow you to use automatic
battles so I was screwed. Here was a solution which I found by
accident: use game option "fastest battle speed" and there should
be no problems with this issue. I tried this out many times and it
seems to work (for some reason?). Also now version 1.41 should fix
the problem.
- Game slowing down / graphics. When playing the game it seems that
your graphics slow down to very sticky, without any particular
reason. There can be more solutions but for me it helped to zoom
closely to your character (using mouse wheel) and then you can move
/ end turn. There should be less problems with graphics now (until
next time). Or you can quit and start playing from the latest save.
There seemed to be less problems with the later campaigns...

C. Intro to walkthrough
--------------------

In my walkthrough there is first the general idea what to do and
some special issues what could be interesting to character
development or player further enjoying the game. After that there
are hints which can be special to this campaign / mission or first
introduced in this part of the game - for example use of the tavern
heroes (level 1 heroes). This will help to point average player
some ways to beat the game. There are no big power gamer hints as I
played the game with Normal-difficulty and only on occasion using
harder difficulties for testing. Also sometimes there could be more
than one way of ending the mission not mentioned in this
walkthrough. So this guide is not covering all aspects of the game.
Also details of the skill wheel or character development are not
part of this guide. You can find that kind of information
elsewhere.


The Queen

C1M1. The Queen
---------------
Welcome to the first mission and campaign. Here you will learn how
to move and use the camera. So feel free to look and walk around.
There is no real threat in this map. Remember to pick those troops
and mark those peasant huts etc. to get you some kind of army. When
you have big enough army, you will be given a objective to fight a
garrison to end the scenario. What is important is to think ahead
what kind of skills you will choose as you army will not follow you
to next mission, but you skills, spells and attributes will. So pay
attention what you choose. It would be wise to take some combat
skills and at least one basic magic school to be able later to use
those high level spells. This is not so important during the first
campaign but later strong magic will be your friend from mission
one of the campaign.

Hints
- it is easy to develop Isabel a might character but also remember
at least one basic magic skill like light or summoning magic.


C1M2.The Rebellion
------------------
Another introduction mission where you get your first town and find
your first stat increase tombs (take your time to increase your
stats when it is possible). You may be worried about having only
one week to capture your own town. Well, no panic as you can take
that archers dwelling, hit the Redwood observatory (to see your
target) and take the town. After that you should take the nearby
ore pit to be able to build the archers building to the town as
fast as possible. Still, there are no enemy heroes or other time
limits, so wonder around, develop your town and take the needed
stat increase and creature dwellings. When ready, you can take the
town in NE corner of the map.

Hints
- you can build a structure to buy war machines which are useful
even if you do not have the skill, but it would not be a bad choice
to take that skill
- you will have enough gold in this mission so you can freely take
experience from the treasure chests, but actually you have also
enough neutral stacks to hit the experience cap...


C1M3.The Siege
--------------
This mission offers a good change to learn some of the basic
elements of HoMM5. Now you can recruit more heroes to carry troops
to your main hero Isabel and also mark those resources / wind
mills. The general idea of the map is to develop your town and
troops enough to be able to beat the enemy hero. You should explore
the whole map without panic and when ready attack those archdevils
in the middle E of the map. After this fight you will face the
enemy hero and enjoy the biggest fight so far. End of mission.

Hints
- still no magic for you so develop those might skills but remember
that one magic skill (not essential but without one skill, you are
not able to learn those most powerful spells of that
specialisation)
- out of resources? visit those trading posts which offer best
prices for your resources (you will need ore a lot, also crystals)
- also some advice about the battles. You may want to protect your
archers from melee opponents. So use blockers to circle the troop
needing protection or move blockers to the place where they block
the enemy. You can use for example peasant (only one) for that, or
several one stack peasant.
- experience different battles and you will start to see that
different troops should be in different places and overall tactics
mode is important to prepare for the fight (you may even want to
leave some troop out of some difficult fight)


C1M4.The Trap
-------------
As usual you appear on the corner of the map. Your general
direction is revealed to you. I suggest you to take those peasant
huts and resources as there is no hurry. Just advance N until you
have to choose the path thru mountains or the path to the right. I
would go right as there is a very interesting building on that
path: hill fort. Use it to upgrade your forces. You should be
enough gold to do it if you chose to take gold from the treasure
chests. You can also visit underground if you wish but it is not
obligatory. When you have enough troops, pay a visit to the only
town and take it. Now you will develop the magic guild, also visit
the town with Findan to get those spells (also very useful summon
creatures spell). Now is your time to adventure and take the rest
of neutral stacks and stat bonuses. When ready you will have to
visit the seer near town and after that visit crypt underground.
You will get boots of leviathan which can be used to cross the
nearby broken bridge. Advance a little bit to find a surprise and
end of the mission.

Hints
- when you take peasant huts etc. early you can leave them and
order later low level  hero to visit them to get for free a lot of
troops.
- remember always to visit towns with new magic spells as they will
follow you to next mission
- also archangel near one portal will join you and you will found
that one powerful creature with special abilities is quite strong
compared to a bunch of low level creatures


C1M5.The Fall of the King
-------------------------
This mission is important story wise. Also you will get Godric as a
hero and he is very important. Develop Godric and have him as your
main hero during this mission as he will be participating other
important missions later. I would suggest to take light magic to
Godric also, for later missions. The basic mission is simple, you
must go to the first town as capture it within one week (you may as
well take it on the last day to have a good start on your troops
and resources). After you have taken the town there will be enemy
heroes going to your town from the S path (S and then E). Prepare
for these attacks. You will also have a lack of resources so you
may start to capture resources as fast as possible. Also remember
to develop your magic guild fast to have town portal and summon
creatures spells. After those you have quite a freedom to adventure
without worries about the attacks as you can town portal (Isabel)
to your town as needed. I would also give your main army to Godric
and have Isabel do the backup work like capturing mines etc. You
can also venture to enemy territory SE but you will not be strong
enough to take the garrison, so you may as well clear the road and
go to underground and check there. When you see obelisks, visit
them and you will be give the place where the Tears of Asha is.
Just follow the main plot and when ready get Godric to Nicolai
quest and you will be almost finished. The mission ends to the fall
of the King.

Hints
- Develop Godric, light magic is useful also logistics (but not too
high yet) for later missions
- You can also train your troops to higher tier. I like to use
developing peasants to archers (if you have the money, right hero
and building)
- Cavaliers on the S will join you if you are strong enough
- Imperial griffins can be very effective against ranged or magic
troops


The Cultist

C2M1. The Betrayal
------------------
Some words about Agrael. You should develop Logistics for him (the
S witch hut gives it). If you gave Godric (?) also logistics, you
may have to hurry this mission very fast. Still, I was able to do
it even when developing also Godric. I would suggest you to save
often and try where you can go. I would not pick any resources
during this mission but gold is a different story. First I took the
S path thru witch hut and to demon tower (you can mark it if you
want but no need). Then back to the road again by taking those
friendly imps with you. Now you can take the S road to the red key
master, and from there one way portal. Go underground as fast as
possible. Now if you have time, you can take those creature
dwellings or not. Try at least take those joining troops. Just go
forward until hill fort (which you should use), and to the end of
mission (try not to fight any unnecessary fights). On the surface
you will have to fight to end the mission.

Hints
- Gating is a good skill, develop it to preserve your troops and
block the enemy


C2M2. The Promise
Do you like running? Here is your second change. Well, it will slow
down later. Your task is here to take the road up and to be there
before the enemy hero. You may want to see how your opponent is
doing by hitting those huts of magi (not necessary). Basically you
should move along and take the resources and creature dwellings to
be ready for the end. As earlier, you may want to save your
progress and try some variations to get just in time to the end. At
the there are fights as usual.

Hints
- you should learn more spells now whenever possible
- should you take experience over gold from chests?
- phantom forces is a nice spell but costs a lot, still not a bad
choice


C2M3. The Conquest
You are in a disadvantage on this map as you have only one town
which is quite isolated. Your first task is to capture all the
possible creature dwellings and rush forward, to meet the enemy
hero for the first time. After the initial confrontation it is time
to advance to E to capture the first Sylvan town (best to be done
in the beginning of the second week because of the side effect). It
may be worthwhile to capture the needed resources also before
moving on. There are NE and NW town left. It is up to you which one
you take. I took the NW town, left a small garrison there and
rushed thru the middle road to the last town. Enemy heroes can come
to your NW town or try to sneak from down from the E, so be
prepared to clear the fog of war and to fight. Only Gilrael is
somewhat strong so you Sylvan troops should be able to handle the
situation. I was able to defeat Gilrael near the last town in NE,
after which I left my other hero to block the way to the town and
started to conquest the land, also killing the source of the druid
magic (access is from the N middle of the map). When you are ready,
go to the last town and capture it to win the mission. Remember to
move your troops to the main army (armies) so that you have always
more troops than you enemy. Also remember that your main hero is
the most efficient leading demon army (gating etc.).

Hints
- being fast crushes enemy's plans
- two different strong armies should hold enemy resistance
- secure your lines and watch what enemy is doing or planning
- use hill fort (remember to use chain of low level heroes if
needed)
- handle logistics well to win


C2M4. The Ship
You start again without towns or own resources. So, take hit the
hut of magi to get the general picture, take the first Sylvan town,
mark the nearby resources and hurry up to the demon town
downstairs. I made one demon army and Sylvan army to my new Sylvan
hero to avoid leaving troops. This tactics worked ok. There is two
initial towns left. Town on middle E was more active so I captured
it, following the capture of the town middle W. If you did this
fast, all what is left is to adventure the map, develop your hero
and troops. You can go the target town using shadow dragon's offer
underground, but you can also take the series of garrisons starting
from the NE direction of the map. If you do not capture the target
town but go past it, you can take all the stat bonus and resources
which the shadow dragon route would have given. What is left is the
typical end fight which you should win with your demon army or
mixed army.

Hints
- You can save some initial money if you use hill fort in E to
upgrade your troops
- there are a lot of resources and hunter's cabins which add up if
you take them early


C2M5. Agrael's Decision
The last mission of Agrael can be quite long. Hopefully you picked
logistics as one of your skill (maybe also navigation?). The basic
idea is to clear the sailing route by using different huts of magi
or moving on the ground. The fog of war will not disappear when you
are sailing. Your target is on the middle of the map, but you
cannot go there directly. If you have developed Agrael well, the
end fight should not pose any treat. Generally I used widely the
gating tactics to block and kill any enemies finishing the job with
ranged troops or powerful spells.

Hints
- hill fort
- there are not so many creature dwellings around so you may want
to stay waiting for the end of the week if there is only a few days
left.


The Necromancer

C3M1. The Temptation
If you like to have a massive army, welcome to Necro campaign. I
would suggest to develop Markal early to raise his troops (skeleton
archers) and learn (only) dark magic. Then you should have no
difficulties with this campaign. Mission one is again about
avoiding confrontation against enemy. First you may want to hit the
huts of magi and get some more troops from E. Next it is up to you
to avoid the enemy and to first go up, E and down again and to
underground (visiting hill fort if possible). The end of the
mission is thru underground to the N. What happened to me was that
I captured the underground town from the W, avoided the enemy which
captured the town and garrisoned there. I was able to go to the
surface again and clear the N part of the town. Then back to
underground and N to end of the mission and fight.

Hints
- as said raising skills and dark magic is your friend at least
- hill fort
- remember that every necro troop joins you so take those troops
when possible


C3M2. The Attack
Godric will you again. You can use him or you can develop Markal's
army if you have difficulties with the enemy army. First clear your
island and develop the town. There could be some enemy attacks
which you should counter trying to minimise your losses. When
ready, you should ship with hero(es) and maybe visit that
cartographer to see your enemy. You can go to the E landing point
and take Lorekeep. After that it is just developing Markal and
Godric to be ready to fight the last fight. When Lorekeep is
developed enough, the (easy) way to enemy town is cleared. When
ready, take the enemy town to win the mission.

Hints
- it is not necessary to fight the Titans early, you should come
back and take the exp and artefact when ready
- starting town can have level 5 mage guild (I got Puppet master
from guild which is very useful)
- when you have blindness or other similar spells, you should not
use ballista if not skilled (as uncontrolled ballista wakes blinded
Colossus / Titan for example)
- you may have noticed the importance of the hill fort to save your
money (not upgrading all your buildings).


C3M3. The Invasion
Here you will learn how to build your necro army and towns. You
will have two towns, one necropolis and one haven. I did fine only
using necro units and converting towns and haven troops to necro.
You first task is to explore your island, hitting the hut of magi
as usual to find how your enemies just go mindlessly back and fort.
When ready you should take the three enemy towns. I took the lower
E towns first and left some troops and secondary hero (Isabel)
there as it is possible that NE town will send some troops thru the
one way portal. Also thru middle N is a hill fort which you can
use. Actually after the first (?) town taken elves will send an
army to be you can take and convert to necro troops. It is on ship
coming from the middle of map - the river. You may as well take the
elves with Markal and continue until you see two shipyards. To the
left is the town and some demon land and to the right another town.
Take them and after that explore, make necros to join you as usual.
When ready, you can take go thru those garrisons to the last town.
Take the town and go to the portal which you enemy just took to end
the mission. You should do it this way to avoid any scripting
problems.

Hints
- there are a lot of strong necro troops willing to join Markal
- also use the tools and help to advance your sailing, you will do
it a lot
- there is nothing special in demon land, but on the middle there
are islands which have status boosters


C3M4. The Regicide
You will not see any towns but if you have built your necro hero
right, you will not have any problems to clear this mission. Hit
the hut of magi and follow always the general route opened to you.
It will be complicated route visiting different tents and opening
gates but generally you will do fine following the route. My way to
do the battles was: puppet master (blindness for Titans), raise
dead and phantom forces (you can direct enemy retaliation to these
forces also). When you come back to the middle of map and
underground, it is near the end fight. Actually you can fight the
blocking Titans also, maybe blinding the other stack and using my
tactics to achieve victory. The last fight should be possible to
win if you have enough forces, spells and mana.

Hints
- you have to choose which forces you want to keep. If you take too
many large units, it may be impossible to get them all to the
battle ground
- there is no hill fort so plan your forces according to that
- there is not much to buy so mostly you should take experience
over gold from the treasure chests


C3M5. The Lord of Heresh
The general idea of this mission is as usually to gather a strong
army and attack the enemy. There are some directions to remember. S
of your Necro town there is a hill fort and level up (and possible
enemy army) so clear that area. Also take the resources in the
middle and explore the map. One enemy army can come from the see,
so prepare for that. Also, as Haven troops leave you, you may want
to be evil and turn them to necro or transfer them to other hero
than Isabel. One good way to win the map is acquire angel's wings
by trying to take the prisoner to your necro town. After that you
can fly over mountains to the last fight. Nothing special there if
you have the right spells and a large  necro army. Still, prepare
to fight twice.

Hints
- keep a (slow) secondary army near your resources as they are
captured from time to time
- to get a big necro army, use Markal to fight and turn others
troops to necro
creatures


The Warlock

C4M1. The Clanlord
------------------
A new hero will appear. Raelag will be participating to the last
mission so pay attention to develop him well. Because he has some
weak forces in several missions you may take war machines skill and
also look those handy magic skills. During this mission you only
have about 4 weeks to prepare so use your time well. I used the
tactic to take the weakest stacks first and returning to the town
from time to time for more troops and spells. At some time you
should use the portal to get to the place where there is creature
dwelling and other stuff. Also there is boots of swift journey near
your time which could help you. Before the time ends, try to reach
your town to get the last troops (the time ends in the middle of
the week) and sell all the resources to get maximum of troops. Next
you will be transferred to the fight area. You could a little
clever and take only the weak opponents and let the two strongest
enemy players to fight first for an easy fight with the weakened
last enemy. And also remember to use the magic well before your
first turn in the competition ends. When you win, just go up to the
hallway to take the ring to win the mission.

Hints
- You can spare your Blood Fury troops if you do not place them to
the battlefield every time when playing shooters etc.
- There is an mana well near the portal's other side
- Try if you can rush from the Blood maiden arena to your time in
one turn (near the end)
- Do not panic if you do not clear all the neutral troops, you will
have plenty of time to level up later


C4M2. The Expansion
--------------------
Here is a good map to level up. First you can take the creature
dwellings from the upper path underground and go round this sector
of underground. Finally the seer will give you instructions how to
beat the level. On normal map you can just explore and beat the
enemy heroes when needed. There is an important logistics
crossroads in about middle of the map where different underground
passages etc. cross. You can keep some of your forces here if the
enemy keep attacking you from different directions. Also Shadya
will join you for the end of the campaign. She could for example
support you in acquiring magic skills and a way to transfer them to
other heroes. Also level her up. Just capture the enemy towns and
visit obelisks to get the location of the tears of Asha. It could
be difficult to locate the tears of Asha from the poor picture, but
just keep digging and put your all heroes to work and check what
directions you get from digging. When you bring the tears of Asha
to you starting town, you should win the game.

Hints
- you should try to maximise your heroes magic skills and then
visit to Dragon Utopia in NE corner of the map for some good
artefacts and level 5 spells, and also Mage vault
- Do you have a lot of money? Artefact sellers in different towns
could have something for you
- You can defend the crossroads so that enemy spies do not get
thru, but easier is just to let the enemy get some help and kill
the not so powerful enemy rescue army
- If you teach Shadya how to transfer spells to other heroes, in
campaign 6 mission 4 that can be useful if she is also expert as
many magic skills as possible


C4M3. The Cultists
------------------
This mission means that you can not use the tactic with only one
big army. You have to defend your possessions against attacks
coming from different directions. First I would take the towns from
W and N side of the first island. Also prepare for the first demon
attacks and possibly enemy hero attacks. After defending the enemy
retaliations it is your time to move, take the N or SW portal to
take the battle to enemy island. Here are total of 5 new tows which
you have to take to end the scenario. All depends now on enemy
armies and your movement, so try to take the initiative from the
enemy heroes and use the logistics and slowly developing armies to
beat the enemy heroes and towns. Also pick the needed stat bonuses
all around and from portals. One way of knowing what will happen
next was to clear and spy the map as fast as possible to know where
the enemy is moving. You can also use the load - reload tactic if
all fails. When you are ready and levelled, you can take the last
town to continue.

Hints
- use your tavern heroes for logistics and taking resources
- use also heroes to spy and clear the area
- that hut of the magi will reveal some important parts of the
surface map giving you time to prepare for demon army attacks
- you can level both Shayda and Raelag here when the main attack
force of enemy is cut down
- your defence force could be positioned so that army can reach the
defended
portals or surface gateway without giving towns to your enemies


C4M4. The March
---------------
During the mission you will not see any towns so reserving your
troops is essential. Use the mighty destructive spells to clear the
way. You can also change the troops between Raelag and Shayda
depending on the mana left. There are also some dungeon troops who
can be joining you so try to attack them first to check your luck.
The idea is to check the key master tent and to clear the
underground map using portals (sometimes you have to use the same
several times to get you where you wanted). When ready, just take
the stairs up to meet your enemy. Beat him and go back to the key
master to end the mission.

Hints
- use one big army at the start, later two armies for both of your
heroes if you want
- use your spells to crush the enemy
- there may have been an artefact merchant?


C4M5. Raelag's Offer
-------------------
This mission can wear your huge army or you can skip the large
fights and when hitting the level cap, you can finish. In version
1.4. there were quite a powerful armies all the time on the surface
so I would use both of the underground routes (Raelag and Shayda)
and take those creature dwellings as fast as possible. You can take
the underground passage to your target which is SW of the map,
where you have to beat the enemy hero. One tactic I used was to
crash the enemy towns on surface and just run for safety
underground as the strong patrolling enemy heroes do not follow you
underground (patch 1.4 only?). You do not have to take all the
garrisons as at least I lost some troops in these fights even with
resurrection spell. There is a hill fort close to the exit to E
underground exit and also nice creature dwellings to the SE corner.
Using underground routes (which are connected with portal) and
upgraded troops, you should be able to reach the SW corner of the
map to fight the last enemy.

Hints
-----
- do not be impressed with your starting troops, really reserve
them as the enemies (not neutral stacks) has several times more
strength - do not lose your troops, at last (m)any high level
- you can hide from enemy in underground level
- you can take surface resources and towns but prepare to flee is
the enemy is coming with too much troops - you can come later when
enemy is patrolling somewhere else
- enemy towns give you nothing more than experience - they just
collapse
- there can be creatures to join you
- you can use the other hero (Shayda) to pick those high level
troops to your army at the beginning of week
- there is a trade post where you can change your resources to
gold, as that you need and also resources for dragon upgrade
- in version 1.4, is it supposed to take all the garrisons and
crush enemy heroes? Maybe if you are fast enough to take all the
enemy towns quickly to slow down the enemy heroes but even I took
all the enemy towns, several very strong enemy heroes and garrisons
were too much for me...

The Ranger

C5M1. The Refugees
------------------
Here you must defend your garrison. For me it was enough to leave
them as they were. The early attacks were easy and if (when) you
lose a garrison you can take it or if the demon (red) army have
arrived, you can safely lose one and prepare for the attack in your
home town. The main issue should be rising your attributes and
waiting for demon attack. You can try and explore freely but at
first you may have to take the easiest stacks and next week take
the needed troops to start more serious adventure. There are some
creature dwellings, witch huts and hill fort at the lower S part of
the map, which you can use. You should also develop the town to the
enemy attack. The mission ends when you beat the demon army without
two of your garrisons been on enemy hands at that time.

Hints
-----
- you can use tavern hero for logistic operations
- the skill set is up to you but using ranger's special things like
avenger ability could be useful
- here and later also the ranger skill to be able to attack before
the battle
starts is very useful (later you can easily kill 3000+ skeleton
archers before the battle even starts). For that skill to work you
need ranged Sylvan troops like druids and hunters
- Findan was never for me direct damage expert rather than a light
spells expert using mass haste or resurrection. This made the
ranged attacks even more frequent. Also phantom image worked well
with master hunters. How about dark magic and puppet master? Well,
works well also.


C5M2. The Emerald Ones
----------------------
Here is an interesting mission. It may be a challenging case so I
try to provide more information how I was able to beat the game.
First I mapped the resources to the E but did not attack Subbacus
nor underground entrance. After that I went back to my town for
spells and creatures. Then to the boat and to NE town. You should
be there quite early and should equip yourself before attacking.
When you have taken this strategic town, you may as well go back
and take that gold mine and underground exit and go to the second
town. After capturing these two demon towns, you are in good
position to repel the possible attacks from the last enemy town. If
possible map the sea route before the enemy comes to you so you
know when to wait an attack. You may as well take the last town by
underground route (building a boat in NE island or taking the long
sea voyage. The last town should not be so well prepared as you
will be for your attack. If you have problems, you can
co-ordinate to get your demon and sylvan army to the SW island at
the same time. You had a mission to get 20 emerald dragons...it may
be best to do that mission after you have taken care of the enemy.
Now is your time to visit the obelisks and get those dragons. Also
now your sylvan town can build emerald dragons. When ready, you
must just put at least 20 emerald dragons to Findan's army to win
the mission.

Hints
- If you have problems to take the NE town, try to be faster and
think new logistic solutions such as using summon creatures
(meaning developing your home town magic guild quickly) or using
two boats to get your army to the top condition before taking the
town
- Having problems with the sea attacks from SW town? Well, you may
even recruit troops from the middle town by using summon creatures
(which is overall very useful spell)
- Also before taking SW demon town, you may use summon creatures if
you need more (high level) troops


C5M3. The Defence
-----------------
Your main town is under attack! First you play a fight where you
are supposed to lose and just wear the enemy forces. I like best to
kill enemy ranged units first. If you move your forces a bit
forward but not outside of the wall (?) enemy melee units should
come and stick to your defences next to your wall. After losing
your unknown hero, you gain control of Findan who has a mighty
army. With this army you should wipe the enemy from your city. As
before taking enemy ranged units makes the melee units to do
something they will regret, like trying to harm my troops...By the
way, I tried to save my dragons and other high level creatures but
you may have to sacrifice some troops (as I did not have
resurrection yet). When you own the sylvan town again, it is time
for your next move. As I wanted to upgrade my hero, I went to the E
to clear the road to purple army and during my journey some enemies
wanted to challenge me (and gave me some good experience). After
have mage guild 5 (and resurrection spell) I was ready to sail to
the next town pointed friendly by the hut of the magi. I split my
forces so that the new hero gave me his weak forces and I only took
the emerald dragons and left all other forces to save my only town.
When I went to the next town to the W, I also plundered all the sea
treasures etc. as my town needed the resources badly. Still I
managed to take the second town before the 3rd week. After that it
is time to take the resources and advance to the general direction
of E. The road leads you to some enemy garrisons. You can use
summon creatures if you need more troops or use your other heroes.
When you have gone to the middle S of the map, you can turn to the
W or E. If you turn to W and pick the first needed hero, enemy hero
can go past you. If you turn E, you will get to last enemy town and
underground exit that leads to the second hero. Well, it is up to
you. This road is quite straight forward so adventure forward until
your objectives start to end. At some time you should check if your
first town is hitting the objective (you can stop buying dragons
for example so that you have enough time to check the whole map).

Hints
-----
- You can use tavern heroes to clear the sea and also pick the
hunters cabin near the E landing place (be alert for enemy hero and
go to your ship if in trouble)


C5M4. The Archipelago
---------------------
No towns during this mission so reserve your troops and use
creature dwellings. You can take a boat or go straight underground.
There is nothing special on the sea, but it is up to you. Now the
underground is a way to get to the islands on the surface. There
are some twists and turns and dead ends. Generally you just go
forward and take the neutral stacks as you go, also picking the
many status boosters. You may want to go to the NW corner first and
the NE corner road leads to the end of the mission. During your
exploration, you will finish the objective of finding ancient
artefacts. When you are about to leave underground at the middle of
the map, you are about the meet some small demon armies, which you
will destroy. The mission ends when you kill (or not?) Biara.

Hints
- hunters are quite good forces here. There is a start bonus and
hunters cabin
- also hill fort to upgrade your forces (hunters)
- take your time to level up Findan
- you do not need much gold or resources here so concentrate on
experience and your army
- you wonder if at the end you should sail with your boat to
anywhere else? Well, there is absolutely nothing there so just
finish the mission...
- there are forces who want to join you


C5M5. The Vampire Lord
----------------------
This mission was very joyful as there are many towns to conquer and
some necro troops to kill. It is also mission where you mostly do
not need to worry about many battle frontiers, just go forward and
use the logistics solutions like low level heroes, summon creatures
and town portal spells. First you have your own island with two
towns. You can mop out the stacks and mark resources, after which
you can take the blocking garrison. By now your hero should be so
strong that those troops inside the garrison should not cause any
problem. Using portal you end up on island in S side of the map.
Here you can visit the seer to get the mission to win the game. You
should also take the necro town to the E side of the island,
looking for possible enemy heroes coming from the N portal.
Underground you have a quest to get those dwarfen artefacts, which
are easy to find when adventuring underground. There are two enemy
town in SW corner of the underground and middle of the underground.
You can take them as seems fit. Be careful not to let enemy hero to
slip your defences when taking either town (mapping the route to
the town helps to plan you actions). Also remember that summon
creatures works also underground, taking the nearest town from
underground or surface. In NE corner of the underground is a portal
to the last island of the map, where you can meet powerful necro
heroes or not depending your speed and logistics skills. One way of
winning the mission is to get all the dwarfen artefacts back to the
seer when underground is secured and take the portal to the last
island and look for our last enemy - Nicolai. After beating him
(happened me for the first town), you win the mission if you have
at least one phoenix with you when the fight ends.

Hints
- here are a lot of the intelligent ways to move your troops to the
main fighting hero  (hopefully Findan).
- level up Findan, he will be the only one appearing on the later
missions
- keep your enemies where you want them, in front of your most
powerful hero and army
- there are also uses for your two other powerful heroes like
mapping the not so well defended resources etc.


The Mage

C6M1. The Defiant Mage
----------------------
Welcome to the last campaign. You will have a new hero Zehir. Zehir
can be an efficient mage. I would took only luck as might skill and
concentrated on magic. Summoning magic is good for him, also any
other. You cannot not come wrong with dead magic for example or
light magic. Just develop magic skills fast to expert level and
maybe use intelligence (from enlightment skill set) to boost your
mana pool. Zehir is one of the characters doing the last mission.

First mission can be challenging or easy if you know the tactics.
Usually bonus do not matter but here I would take Djinns to
strengthen your weak army. First you should mark those troop
buildings (horned demons) and skeletons in the middle of map.
Second you can go to the enemy town before hitting level 10 (to
develop it to your benefit) or you can take care of other business
(rising attributes) and hit the town later. Your key to victory is
not to loose much of your army by using efficiently your troops,
skills and summoning.

The town is in the east side of the map. When you win the town and
you are at level 10, you will win the mission.

Hints
- you start with the element summoning spell, so use it in tough
places
- as usual slowly moving enemy troops are much easier than ranged
troops
- your troops turn to elements if the stack (even small one) dies,
use it at the end or as needed
- artefact merchant can have something for you
- did you know that Gremlins can repair your mechanical troops like
golems and gargoyles?
- if you know what to do, you can sprint to enemy town and take it
fast
- do we really want to beat those phoenix out there?


C6M2. The Liberation
--------------------

This is a mission where you can use that Artificer skill, so have
fun and use it. You must build a town structure, make artefacts and
put them on to your troops (only one per troop, sorry) with town's
special ability. Magic guilds end up to level 3 so no fun from that
side.

At the beginning you may guess what to do; take those resources as
fast as possible. Generally direction south do not possess any
threats so you may take some demon stacks and concentrate to moving
north to portal. There will be enemy coming before the end of the
week, but you should be able to beat him. Next you can go after
those other heroes and take the Necro towns from the other island.
I would not suggest you to take your target town at the early stage
of the mission as it is heavily guarded. After rising your
attributes and gathering experience. You do not have to take down
all the neutral stacks if you do not want as it takes quite much
time and there is the experience limit anyway. Are you ready to
meet quite a lot of Cavaliers/Paladins? Go to the middle south of
the map to the town and beat the Cavalier stack. It could be
challenging but just have enough troops and good logistics. You
wonder if the other side of the island would be easier with those
Wrights? You may try yourself if you want challenge. Now taking
those two enemy towns (including Lorekeep) should be easy after
that Cavalier stack. You can go back now if you want to your first
town thru southern demon land and pick the necessary items /
resources. Now you can adventure and when ready go to your target
town. I liked the end fight with strong Academy troops. If you have
dark magic (Puppet Master), it will be easy. I had summoning and
light magic which worked ok also. The fight is normal with large
armies but with no enemy hero!

Hints
- leave resources which you have difficulties to take without
casualties. You can take them later
- you can again use your weak and small stack troops to turn them
to elements to win some battles
- you wonder if you need those Haven troops (they can not be
upgraded) on the second island? Well, I did not have any use for
them as Academy and Necro troops were enough for me
- you should develop Necro towns as you have more than enough of
money. You can use those forces as cannon fodder or backup
- develop Colossus as fast as possible as you will be fighting
those later and you need high level troops
- use for once those amulets to your troops when taking the enemy
Acedemy town
- take care of your logistics (other heroes carrying troops to your
main hero etc) as there are some powerful stacks out there and you
want to be prepared


C6M3. The Triumvirate
---------------------
This mission you start on the road looking for someway to go. I
prefer to go underground to pick Godric as you need him to finish
the mission. You can also capture those peasant huts on the way.
Once underground, just take the upper road to Godric, who is
captured in the upper middle, road starting from the east. One idea
could be that Godric continues with Haven troops to surface as
Zehir takes more time to capture all the mines etc. as you may need
those resources later. With Godric on your side, troops in the
first garrison will join you and you have easy time to capture the
first town after the garrison. There are total of four Haven towns
to capture. I would take next the one S to your first town and then
one in the middle of town, leaving the NE town to the last. I had
some difficulties to take the last town as the enemy heroes and
troops are quite powerful in version 1.4 at least? Well, you can
pick up Findan to help you out or make some of the Colossus neutral
stack to join you. When you are ready with Heaven and levelling up,
you should go to Southern way to enemy necro town. I took it but if
you prefer summon creatures spell or town portal to work with Haven
town, maybe you can leave it. But still I got a good level 5 spell
from that so...After taking what you want, you should go to SW
corner of the map to face Markal. All your heroes must fight the
Markal once so adjust your troops and artefacts accordingly. Findan
needs to take the town so keep that on mind. After this series of
battle, the mission is over.

Hints
- Try to make Colossus to join you and use the hill fort to upgrade
them is needed
- Summon creatures can speed up the process of capturing and moving
your forces as there are no low level heroes to be your troop
carriers
- You may take Findan early to support your plans


C6M4. The Alliance
------------------
Here is a joyful map as you can advance like a attack force from
the south to north. You will be fighting with three of your
previous heroes: Godric, Findan and Zehir. Generally I did well
using method to advance every hero to their natural directions;
Godric to the left, Findan to the middle and Zehir to the right.
There are also three Necro towns for each other. I worked well with
the initial troops for the whole scenario, taking Godric the later
Haven troops and towns. I also took only those resources and made
market places and town structures to Necro towns and rushed to the
Haven territory. There are two gates to the left and middle of the
map, where Godric and Findan should go. Zehir can take a little
longer way to the portal to the key structure and portal to the
right middle. You can use portal several times to get to level up
three. This mission is about capturing towns so just use the hero
who needs the levelling and capture all the towns and do some
character development before going to Raelag. After that you can
just advance to town where Isabel should be.

Hints
- Summon Creatures spell can be handy as no chaining your level 1
heroes to move your troops around
- Any spells you need (Mage Guilds in 8 towns)?
- You can also transfer all the interesting spells if one of your
characters (Shadya) had that skills, very useful as in the last
mission resurrection and summon phoenix spells would be handy
- I managed to do with the creatures from Haven towns, they were
more than enough
- Of course you used those hill fort after the two garrisons before
taking the first towns and later for creature updates?
- after this mission there is no real possibility to get spells or
rise attributes other than rising your level
- This means that in the last mission you should have well balanced
heroes or you have to move the troops between heroes which could
mean problems with morale - so prepare


C6M5. Zehir's Hope
------------------
The last mission. Your party will include Godric, Realeg, Zehir and
Findan with their natural troops. Now almost all of the spells and
levels have been achieved already so it is pure fighting to the
end.

Hopefully your heroes have top attributes, skills and magic (like
summon phoenix and resurrection from magic guilds or learnt from
someone else - remember end of the previous mission).

Before the first castle everyone has an enemy Garrison between them
and enemy castle. You may just rush to the enemies for the first of
series of large fights. Try not to loose much of your troops here.

When everyone has done their job to kill some demonic creatures one
can hit the castle. You may think of arranging your troops between
heroes depending your heroes strengths and weaknesses. I saw no
need to do any changes during the whole mission as every hero was
doing just fine.

I will not spoil the surprise but you may found some additional
enemy creatures coming to play when hitting the right (wrong)
target. Think also when and who will hit the target if needed. You
may have wondered where you should use the Banish skill - here you
found the very satisfying answer. The mission is quite
straightforward always involving every hero to fight in a row.
There is no special tactics rather than spare your troops with
resurrection skills and using clever blocking / fighting / tactics.
If you use a lot of mana points, remember to use the magic well
before taking the other castle. Also remember that you do not need
to put all of your (low level) forces to play if they are fried
during the fight. Just experience and enjoy the always good feeling
of finish something. If you have problems with Gating (computer
crashing), you may use my experience mentioned earlier to avoid the
crash. Hopefully it works also for you.

Hints
- use banish ability for (too) easy victory (Raelag at least)
- enemy is using area damaging spells so think where to position
you weaker and stronger forces to counter the enemy damage or even
spare your weak troops for the next battle
- Raeleg gets all war machines at the beginning of the mission
(hopefully you have that skill developed for him). For other heroes
you can exchange war machines if needed.
- Also troops can be exchanged if needed


D. Some general tips
--------------------

1. Save often and to different places. This is normal but sometimes
overlooked. You may have to come back to your earlier save if
something special happens making the game unbeatable

2. Generally the game can be played as you wish but mostly the
previously selected skills of your characters are worthwhile to be
developed fast

3. What is the purpose of the game really? It is to beat your
enemy; with your stronger army or better use of your skills and
tactics. Logistics and fighting skills are both important.

4. Developing towns or capturing creature dwellings is important. I
try to think for the current week to have optimum troops which can
be recruited / created at the first day of the next week.

5. You can not carry your precious troops to next mission so
developing your attributes, experience / levelling and magic skills
are also important. It could mean that before rushing to the next
mission you could use some time developing your character.

6. Overall tactics is surprisingly important (and the skill is also
not a waste). Where you position your troop before the battle start
quite much decides how the fight will start (computer AI).

7. You do not have to position all of your (weak) troops if
fighting ranged troops or troops with magic skills.

8. I like higher tier troops more than low level as you have more
hit point to cover from retaliation and overall performance is
better. But this depends on situation as for example Necros should
use those skeleton archers and other troops as their main attacking
fist.

9. There are a lot of small details you can do to achieve better
performance with your troops and skills. Many times with careful
planning and tactics you may end of losing no troops at all.

10. Initiative. I love the initiative system as it makes new
tactical things possible. For example you can slower or haste your
troops or cast the next enemy character supposed to move with
puppet master etc. You can also plan when is your time to move and
when not. Sometimes your faster troops can even hit and return
before enemy troops reacting.

11. This can be personal but I prefer mass effects and indirect
ways of damaging more than direct damage. Direct damage is cool on
early on the mission but against 50+ Paladins may not be enough -
but spells like mass slow, confusion, puppet master or Arcane
Shield to your strongest stack could mean more on the long run.

12. Most of skills are really useful if practiced in the right way.
So keep thinking the way to use them in different situations. For
example Phantom Forces spell can be useful to double your ranged
strength, in focusing enemy fire (and hopefully missing the turn
because of the incorporeal nature of the spell), blocking your
enemy to reach your weak ranged force etc.

13. Every battle is different so positioning your troops
remembering the current terrain and to protect your weaker troops,
to think your enemy positioning, using blocking or troops with only
1 unit as blocker or spell users can all be useful. Trying
different things is part of the fun!

14. You usually win if you take the initiative during the mission,
attacking first, be faster capturing resources etc.

15. Remember. In campaigns enemies are the dumb and controlled by
computer, you are the only real heroes of might and magic there!


E. Copyright
------------

This document is copyright 2007 of K.K.Rouhiainen. It is intended
for private use only and no part of it may be posted anywhere else
without my permission. Please contact me by email if you want use
it in some other form or forum than www.gamesfaq.com.

If you have any comments or ideas how to make this walktru even
better, please email me and I will include your effort with proper
credit to this document. I appreciate if you use the same layout
than I have used in hints, or tactics for example.


F. Credits
----------

Thanks to every people who have been involved in creating such a
great games of Heroes of Might and Magic over the years. Thanks to
Ubisoft and Nival Entertaiment for HoMMV.

Thanks to you helping to finish and reading my guide. You know who
you are.


G. Personal Notes
-----------------
Having experience of several decades of computer gaming I still
wonder why the stories or story development have not been more
sophisticated overall. I know a lot of interesting modern stories
from books, movies or theatre, but game industry seem to lack the
ways to make the story the centre of the product. Maybe it is such
a new industry but hopefully it starts to develop also new ways of
making sense of wonder. This do not relate only to HoMM 5, it is a
larger issue. And I do not mean I could make better stories, rather
than there are good stories around. Also some great computer games
with good stories but not too many. Also I may be too old but there
are many of us around.


H. Version Notes
-------------
1.0: Fist version which needs comments from the readers to find
mistakes and misspellings.