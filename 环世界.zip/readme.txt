o=orange
b=blue
g=green
y=yellow
r=red


ringworld codes

page 2
o
b
g
y
r

page 3
y
r
b
g
o

page 4
g
o
r
y
b

page 5
b
y
o
g
r

page 6
r
b
y
g
o

page 7
o
r
y
b
g

page 8
y
o
g
r
b

page 9
g
y
b
o
r

page 10
b
o
y
r
g

page 11
r
y
g
b
o

page 12
o
y
r
b
g

page 13
y
b
r
g
o

page 14
g
b
o
r
y

page 15
b
g
o
y
r

that's it folks