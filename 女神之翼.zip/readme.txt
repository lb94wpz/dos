����Ϸ���ۺܵ� 
������Steve Meretzsky��Ƶĸ��Ӳ���ԭ��
���ǻ��滹��
�����ղ���


Leather Goddesses of Phobos 2
copy protection codes

BARADA 		3711 
FAT MAN 	7677 
GEIGER 		8704 
ENOLA 		7739 
MANHATTAN 	4569 
GORT 		7946 
NIKTO 		8860
TRAJECTORY 	5299 
OSLO 		8696 
COMETS 		6249 
SELFRIDGE 	6786 
HEAVY WATER 	8978 
NEUTRON 	5804 
WATTS UP 	0858 
URANIUM 	2446 
LARSEN 		5686 
BELLEROPHON 	0176 
TRENT 		5789 
FALLOUT 	0595 
LITTLE BOY 	2470 
BEDFORD 	7731 
TIFFANY 	8677 
ELECTRON 	3139 
TRINITY 	6424 
ADLAI 		1961
CECIL B. 	6863 
TRICKORY DICKORY 5856 
BIKINI 		0676 
ANASTASIA 	9376 
KLAATU 		3589
MELBOURNE 	8969 
WHITE SANDS 	5417 
MOTHER'S BREATH 7909 
SASHA 		7873 
U235 		9634



   L E A T H E R   G O D D E S S E S   O F   P H O B O S !   = 2 =

There are three different characters to chose from. Zeke and Lydia are very
similar, but Barth is much different.

ZEKE
~~~~
     You start off in front of your gas station, go into the garage next to the
gas station, get the transmitter from within the car, and get the rubber hose
from under the hood. Next, go over to Lydia's house and talk to his brother and
find out what kind of food a Germanium-based lifeform needs, and how to heal
one. Go into Professor Sandler's room and turn on the machine (rain-making
machine.) Next, go to the bar and get the bottle of bourbon. Then go over to the
Doctor's office, open the cabinet, and get the sulfer from there. Then go over
to the Diner and get the bowl on the table.

     Next, go to the river (beyond the crashed spaceship) and enter the boat.
The boat will take you to the military base. Enter the base through the broken
fence, then enter the barracks. Open the locker there, get the uniform and put
it on. Leave the barracks and enter the General's office. Open the left drawer
and get the key. Leave the office and enter the control room. Look at each of
the round screens in the control room, one of them tells you a 3-digit code,
write that down. And one of them should tell you add x to any 4-digit codes,
write that down as well. Now leave the military base and go over to the
General's house, unlock his desk with the key and get the purple envelope.
Read the letter, it's from one of the prostitutes. Go over to the whorehouse
and ring up the prostitute, she will see that you're holding her letter to the
General and will give you a folder. Look at the folder, and look up the
corresponding number in the manual. Go back to the military base, you will
have to put on the uniform in order to enter it. Go to the lab and open the
safe with the 4-digit code from the manual. (Add any values if necessary.)
Pick up the radioactive isotopes. Then leave the military base. If you've done
everything correctly to this point Lydia and her brother will appear and you
will automatically go over to her house to receive the broadcast from Phobos.

     Now go to Dealer Dan (used cars), Barth should be there, give him the
radioactive isotopes. Next, go into your inventory screen, put the rubber hose
(from the garage) into the bowl, then put the bourbon (from the bar) into the
bowl, and lastly, put the sulfer into the bowl, the mixture should melt. Give
this mixture to Barth and he will be healed. Now you'll be surrounded by an
angry mob. Use the transmitter and enter the 3-digit code from the control
room, the mob will disperse, thinking there's a meltdown. Go back to Barth's
spaceship and enter it. Talk to Barth and he will give you the eight items
necessary to fix the ship. Just fit them into the corresponding holes. You
will take off and head for Planet X.

     There isn't much to do on Planet X, just talk to the High Councel and she
will give you the invisibility belt and the record. Blast off to Phobos, go
into the Leather Goddesses' room with the invisibility belt turned on. If you
didn't do this the first time don't worry, just go back again. When you're in
there use the green record and it will record all their conversations. This
wilil take quite a while, wait until the Leather Goddesses mentions about
invading Earth. When that happens leave them. Go down into the dungeons and
free the slaves from Planet X. Now go out and go over to the invasion fleet.
Enter the flagship and go into the broom closet. Wait for the Leather
Goddesses to board and take you back to Earth. Back on Earth, you're once
again surrounded by an angry mob, go out and go over to KACR (the radio
station), remove the playing record (if there's any) and put the green record
(with the Leather Goddesses' evil plans) on and play it. The mob will then
turn against the invasion force and you're the hero. That's it, the end.


LYDIA
~~~~~
     Playing Lydia is exactly the same as playing Zeke's game, except that you
screw males instead of females. (Obviously.) And all important figures are now
male instead of female. But the main objective is still the same. The game
also starts at a different place.


BARTH
~~~~~
     Playing Barth is quite different, the main objective is the get the eight
items that will fix the ship. You start off next to the damaged spaceship.
First, go left at the street to go the block tunnel and pick up the traffic
cone. Then go into the town. Go into the sheriff's office and enter the cell,
get the bar of soap, then use the blaster to blow a hole in the wall. Next,
find the stop sign near the church, use your blaster and shoot the pole, then
pick up the sign. Go over to the Diner and pick the grapes on the table. Next,
go to Lydia's house and get the iron. Her little brother will want something
to trade, give him the blaster and get the iron. Go into Professor Sandler's
room and turn on the rain-making machine. Leave the house and go over to the
souvenir store next to the Indian preserves, open the trash can and get the
bottle. And push the button on the vending machine to get the dime. Next, go
to the Bar and enter the pool room. Pick up the purple ball and put it into
one of the six holes, all the balls will then appear, get the 8-ball. (The
black one.) Next, go to the grocery store and give the dime to the owner, and
pick up the pumpkin. Now go over to Dealer Dan's place, Zeke and Lydia should
be there. Talk to both of them and get the hide patch and food (radioactive
isotopes), after that the angry mob will appear.

     Wait and eventually the mob will disperse due to a "meltdown". Go back to
your spaceship and fit the eight things you gathered from the town into the
respective holes in the spaceship. You'll blast off to Planet X. Go to the
High Council and listen to them, and pick up the invisible belt and the green
record. Leave Planet X and head for Phobos. After this the game is pretty much
the same as the one for Zeke, see above for more information.