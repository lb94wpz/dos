DAUGHTER OF SERPENTS

AUTHOR: G.K.I.

what follows is a general solution but is not the only way of doing things.

you may do some things in a different order but the outcome will be the same.

only the minimum text is included. You have to sort of read between lines!

DAY ONE

Get message from desk and read. Read Cook's guide to Alexandria.

This contains the map that you point and click on to travel to the various

locations. Go to Museum. Tell Curator you will help. Go to Police Station.

Talk to Cameron. Go to gardens of Paradise Cafe. Sit. Order coffee

and eat cake. Talk to Ariadne. Answers: business, manuscripts. Go to hotel

room and sleep.

DAY TWO

Get message from front desk and read. Go to Cook's. Say help. Go

to hotel bar and sit. Haggle with Ariadne. Choose $350. Go to Cook's.

Tell amount of money for draft. Go to bar. Click clock over bar. Wait

until 6:00 pm. Ariadne arrives. Sit and talk to her. Go to front desk,

get draft and return to table. Talk. Move draft into purse on table.

Ariadne shows scroll to you.

Cameron arrives. Get draft and place in his hand. Go to museum.

Examine case and scroll. Read scroll. Series of clues follow. Phone rings.

Cameron leaves. Statue appears. Go to Catacomb Entrance. Notice Solar

Disk above opening.

THREE MONTHS LATER

At hotel, talk to clerk. Go to bar, sit and talk to Cameron. Exit

bar and talk to clerk. Exit hotel. Reenter hotel. Get message from

Ariadne and read it. Go to cafe. You are taken through a secret door in

the cellar. Talk to Ariadne. Go to hotel, sleep.

NEXT DAY

Go to catacombs. Search. Return to cafe. Talk to Ariadne. Go to

tomb. Add three packets of powder to fire in brazier (red, yellow, black).

Go to Warehouse. Examine office desk. Enter cellar. Examine small piece of

rope in close-up, getting key symbol.

Examine trap door, unlock and open. Get rope coil and tie (put) it

on bottom of left pillar. Climb down rope. Talk to person you encounter.

Go to next room. Go to dig site.

Take jars and look inside (operate) to get powder. In southwest of

screen get peace pipe. Drop it and examine it in close-up. Operate pipe.

Powder goes into it.

Enter next room where the Djinni is. Blow powder at Djinni. Walk

around the right side. Enter path leading to Temple. Pick up clothes, head

symbol (Eye of Thoth) and notebook. Read notebook. Give it to Ariadne.

Enter temple and look around. Return to cafe for more discussion and clues.

Go to hotel and sleep.

FINAL DAY

Go to Catacombs. Operate Eye (key operate it in close-up). Place

eye on Solar disk. Go to Cafe Cellar. Operate loose brick behind shelf on

back wall. Enter room and Talk to Ariadne.

Return to room with Trapped Djinni. Bargain with Djinni. He gives

you a whistle. Release the Djinni. Walk to right and continue along path

leading to temple. Note ritual taking place. Blow whistle.

AUTHOR: G.K.I.