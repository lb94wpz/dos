RedWolf Design
Clonk
Das ultimative Zwei-Spieler-Spiel
Freeware-Version 1.0

Allgemeines:

Hallo Welt! Dies ist die Freeware-Version von Clonk. Sie darf frei kopiert
und verbreitet werden, so lange keine �nderungen an den zum Spiel geh�rigen 
Dateien oder deren Zusammenstellung vorgenommen werden. Ein kostenloser Code
zur Freischaltung des Spiels ist in der Datei Freeware.txt enthalten.

Zum Spiel:

Clonk ist ein aktionsreiches Taktik- und Geschicklichkeitsspiel f�r zwei oder
mehr Spieler. Jeder Spieler steuert getrennt seinen Clonk-Captain und den 
Rest seiner Clonk-Mannschaft. Ziel des Spiels ist es, als erster den Captain 
des Gegners unsch�dlich zu machen.

Steuerung:

Hier die Standard-Tastaturbelegung (diese kann mit Hilfe des SETUP-Programms
umdefeniert werden):

               Spieler 1                      Spieler 2

                Q  W  E      (Aktion)          7  8  9
                A  S  D      (Mannschaft)      4  5  6
                Y  X  C      (Captain)         1  2  3

Taste     Bedeutung (Tasten dr�cken und nicht festhalten.)

 Y,1      Captain marschiert nach links.
 X,2      Captain bleibt stehen.
 C,3      Captain marschiert nach rechts.
 A,4      Mannschaft marschiert nach links.
 S,5      Mannschaft versammelt sich und bleibt stehen.
 D,6      Mannschaft marschiert nach rechts.
 Q,7      Alle Clonks springen (in Runden, in denen gegraben werden kann).
 W,8      Alle Clonks werfen einen Stein (wenn sie einen haben).
 E,9      Captain beginnt zu graben (in Runden, in denen es m�glich ist).
 
Mit der Taste E bzw. 9 l��t man seinen Captain schr�g nach unten graben.
Anschlie�end kann er durch die Kommandos "Captain nach links", "Captain nach
rechts" oder "Captain anhalten" dazu gebracht werden, horizontal nach links
bzw. rechts zu graben oder anzuhalten.

Einige Hinweise und Tips:

- Mann-zu-Mann-K�mpfe werden automatisch ausgetragen, der St�rkere gewinnnt.
- Immer die �bersicht behalten! H�ufiges Versammeln der Mannschaft wird 
  geraten.
- Nicht den Captain aus den Augen verlieren, er ist nicht von den anderen
  Clonks zu unterscheiden!
- Nicht �berlange im Wasser bleiben.
- Das Katapult kann von jedem Clonk, der einen Stein tr�gt, geladen werden
  und wird automatisch abgefeuert.
- Clonks sind brennbar.
- Die Energie eines jeden Clonks regeneriert sich langsam im Bereich vor
  der Burg des jeweiligen Spielers.
- Vorsicht beim Graben! Viele Clonks sind bereits in ihren Minen ertrunken,
  oder sind aus zu tiefen L�chern nicht mehr herausgekommen.
- Durch einen Gang zum rechten oder linken Bildrand kann ein Abflu� f�r
  st�rende Wassermassen geschaffen werden. 
- Um Steine gegen neue Clonks einzutauschen, mu� man sie einfach in die daf�r
  vorgesehenen Loren werfen.
- Ein Goldklumpen hat den Wert von vier Steinen.
- Alte Clonk-Weisheit: Wer im Tunnel sitzt, sollte nicht mit Flintstones
  werfen.
- Durch geschicktes Graben k�nnen Barrieren f�r Monster geschaffen werden.

Systemanforderungen:

Clonk sollte auf jedem MS-DOS PC (mindestens schneller 386er) mit VGA-Karte
laufen. Mouse und SoundBlaster (oder 100% kompatible Karten) werden unter-
st�tzt.

Ich kann leider keine Garantie daf�r �bernehmen, da� Clonk auf jedem System
l�uft. Weiterhin �bernehme ich keinerlei Haftung f�r etwaige Sch�den, die 
durch die Benutzung des Programms entstanden sein k�nnten.

Sound:

Besitzer einer SoundBlaster oder einer kompatiblen Soundkarte kommen in den 
Genu� von digitalisierten Soundeffekten. Dazu m�ssen im SETUP-Programm der 
IRQ und die Port-Adresse der Karte eingestellt und mit dem Button SOUND 
EFFECTS ON der Sound initialisiert werden. Clonk ben�tigt au�erdem das 
Treiberprogramm CT-VOICE.DRV, das zum Lieferumfang einer jeden SoundBlaster
oder kompatiblen Soundkarte geh�rt. Es befindet sich normalerweise im 
C:\SB\VOXKIT bzw. im C:\SBPRO\DRV Verzeichnis. Dem SETUP-Programm mu� der 
richtige Pfad- und Dateiname mitgeteilt werden, damit CLONK auf diesen 
Treiber zugreifen kann. Beispiel: C:\SB\VOXKIT\CT-VOICE.DRV

Kontakt:

RedWolf Design
Am Barkhof 20
28209 Bremen

http://www.clonk.de
info@clonk.de

Matthes Bender
April 1994
Freeware Januar 2001