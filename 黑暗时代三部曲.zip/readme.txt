Dark Ages Freeware Release Notes - March 2009
Dark Ages is (c)1991/2009 Apogee Software, Ltd.
-----------------------------------------------

This game was deleted from Apogee's product line quite some time ago, and has been re-released as freeware in March of 2009.  This game was originally released in February of 1991, and was a trendsetter.   It was the first shareware game to include any kind of ingame music.  Back then, the audio card of choice was the Adlib card, and Dark Ages was the first game in shareware to make use of that.  

However, in 2009 this isn't as big a deal, so keep that in mind when you play this. :)   

1) We offer no support in helping to getting this freeware release running.  YOU'RE ON YOUR OWN HERE.  DON'T ASK US - YOU WILL BE IGNORED. :)

2) This game was released before Windows 2000 & Windows XP (or Vista, or even Windows 95) were released, and as such, these more modern operating systems might have issues in running the game.  A third party program called DOSBox has been known to have been helpful in getting the game running.  You can obtain DOSBox here: http://www.dosbox.com

3) This game is released as freeware.  That's not to be confused with public domain, abandonware (which is illegal), or releasing something under the GPL.   This is a freeware release, which means we retain full legal rights to the title and it's materials.  You are free to play the game as we've released it, but not free to "do whatever you want with it", which includes selling it or otherwise using the materials in other projects.

Below are a few comments by Allen Blum and Keith Schuler when asked about saying something in regards to Dark Ages.  :)

Enjoy Dark Ages!
-- Apogee Software Ltd. Tech Support, March 2009

--------------------------------------------------------------------------------------------

It's Old..  Nah...

(After showing him these notes, he added this...)

I think I wrote the editor for Dark Ages also. .. good times.

Allen H, Blum III
Art / Levels, Dark Ages

-----------------------------------------------------------------------------------------

I made the music using a program that came bundled with the Adlib card. I think it was called "Composer". I'm not a musician. I don't play any instruments, nor have I ever taken any classes. I just happened to be fiddling around with this new "sound card" thing I'd bought, and using the bundled software to create sequences of dots that sounded sort of like music when you played it back. This was while I was working on Paganitzu and dreaming of adding sound card support to that, which never panned out. George told me about this Dark Ages game Al was working on. It had sound card support, but nobody was available to create music for the game. So, I sent him my creations and that was that. I got a music credit in a game.

Keith Schuler
Music / Dark Ages