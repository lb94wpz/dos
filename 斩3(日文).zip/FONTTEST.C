#include <stdio.h>
#include <mbstring.h>
#include <mbctype.h>
#include <process.h>
#include <conio.h>

#include "fontlib.h"
extern unsigned short fontFunc1[2];
extern unsigned short fontFunc2[2];
extern unsigned char  fontFuncErr;
extern unsigned char  fontFunc2Err;

unsigned char codeBuff[100];
int Xdot1=8;	/* 1 byte code */
int Ydot1=16;

int Xdot2=16;	/* 2 byte code */
int Ydot2=16;

void decode_err(unsigned int err)
{
	switch (err)
	{
		case 0: printf("NoErr\n");
			break;
		case 5: printf("Character code Err\n");
			break;
		case 6: printf("Fixed font err\n");
			break;
		default:
			printf("Unknown Err %02XH\n",err);
	}
}

void line(int x)
{
	putchar('+');
	while(x--) putchar('-');
	printf("+\n");
}

void dumpCode(unsigned short c)
{
	int i,j;
	unsigned short testBit;
	int Ydot,Xdot;
	unsigned char *cp;
	
	if( c & 0xFF00 ) Xdot=Xdot2,Ydot=Ydot2;
	else             Xdot=Xdot1,Ydot=Ydot1;
	
	line(Xdot);
	for(i=0,cp=codeBuff; i < Ydot; i++)
	{
		putchar('|');
		for(j=0,testBit=0; j < Xdot; j++,testBit >>= 1)
		{
			if(!testBit)
			{
				testBit = 0x80;
				c = *cp++;
			}
			
			if(c & testBit ) putchar('*');
			else             putchar(' ');
		}
		putchar('|');
		putchar('\n');
	}
	line(Xdot);
}


void fontReadTest(unsigned short c, int wait)
{
	int err;
	
	if(err = readFont(c,codeBuff)) decode_err(err);
	else	dumpCode(c);
	if(wait)
	{
		printf("Read %XH ErrCode=%XH  Push any key !\n",c,err);
		getch();
	}
}

void main()
{
	int err;
	unsigned short c;
	
	fontType1 = (Xdot1<<8)|Ydot1;
	fontType2 = (Xdot2<<8)|Ydot2;
	err = initialize_readFont();

	printf("%dx%d fontFunc=%X:%X Err %XH, %dx%d fontFunc=%X:%X Err %XH\n",
		Xdot1,Ydot1,fontFunc1[1],fontFunc1[0],fontFuncErr,
		Xdot2,Ydot2,fontFunc2[1],fontFunc2[0],fontFunc2Err);
	
	if(err) exit(0);
	
	
	printf("\n\n--- Use JIS CODE of �� ---\n");
	fontReadTest(_mbcjmstojis((unsigned short)'��'),1);

	printf("\n\n--- Use Shift-JIS CODE of �� ---\n");
	fontReadTest((unsigned short)'��',1);

	printf("\n\n--- Use JIS8 CODE of C ---\n");
	fontReadTest('C',1);
	
	while(1)
	{
		printf("Type 'E' for exit, Else read the character's font :");
		c = getch();
		if( toupper(c) == 'E' ) break;

		if(_ismbblead(c)) c = (c<<8)|getch();
		printf("------------\n");
		fontReadTest(c,0);
	}
	exit(0);
}
