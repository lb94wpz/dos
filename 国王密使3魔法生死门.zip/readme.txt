===============================================================================

                              FAQ/Walkthrough for
                       KING'S QUEST III: TO HEIR IS HUMAN

===============================================================================


GUIDE INFORMATION
-----------------

Author:   Tom Hayes
E-mail:   thayesguides(at)gmail(dot)com
System:   PC
Updated:  21st August, 2008
Version:  1.1


CONTENTS
--------

1. Introduction
2. Walkthrough
     2.1. Finding the Magic Items
     2.2. Casting the Spells
     2.3. Leaving Kolyma
     2.4. Route to Daventry
3. Character List
4. Item List
     4.1. Information
     4.2. Descriptions
5. Point List
6. Maps
7. Easter Eggs and Secrets
8. Debug Information
9. Copyright Information


VERSION HISTORY
---------------

1.1:  21st August, 2008  (Format update)
1.0:  4th April, 2003    (First version)


===============================================================================

1.                                Introduction

===============================================================================


In the land of Llewdor, an evil magician once kidnapped a boy from a nearby
kingdom to raise as his slave. The first boy explored away from the house
despite Manannan's strict orders. When the wizard returned one day to find the
boy practicing magic spells, he became so infuriated that he turned the boy
into a pile of ashes. From then on Manannan kept stealing boys, but he kept on
killing them before or on their eighteenth birthday in case they also decided
to try and learn magic spells that could potentially defeat the wizard. Gwydion
is the latest boy to have been kidnapped, and his eighteenth birthday is
drawing near. Manannan is carefully watching over him, so Gwydion must find a
way to defeat the evil magician and escape from Llewdor.


===============================================================================

2.                                Walkthrough

===============================================================================


-------------------------------------------------------------------------------
2.1.                        Finding the Magic Items
-------------------------------------------------------------------------------


The game starts inside the evil wizard Manannan's house. The wizard will appear
frequently in this first part of the game to give Gwydion different tasks. If a
task isn't completed within three minutes, he will cast a spell on Gwydion that
transforms him into a snail for one minute. To avoid this punishment, carry out
each instruction that the wizard gives as quickly as possible. From the entry
hall of the house, here are the five chores that the wizard can give. The fifth
chore only appears after Manannan has returned from his journey.

1: Clean kitchen: Walk east to the dining room and then north to the kitchen.
   GET the BROOM at the top-left corner of the room to sweep the kitchen.

2: Dust office: Walk north to the office. Approach the front of the cabinet at
   the bottom-left corner of the room and GET the DUSTER to clean the office.

3: Empty chamber pot: Walk up the steps and then north into Manannan's bedroom.
   Walk to the bottom-left corner of the bed and EMPTY the chamber POT.

4: Feed chickens: Walk south to exit the house. Walk behind the fence at the
   left side of the chicken hut and FEED the CHICKENS.

5: Feed Manannan: Walk east to the dining room. As this task only appears after
   Manannan has returned from his journey, you should already have the bread,
   fruit and mutton from the kitchen. GIVE one of the items to Manannan.

After completing one of the tasks, return to the entry hall. Walk east to the
dining room and GET the CUP on the table. Walk north to the kitchen and GET the
BREAD, MUTTON and FRUIT on the table, the KNIFE and SPOON on the rack at the
left side of the fireplace, and the clay BOWL on the shelf at the top-left
corner of the room. Walk south and west to the entry hall, then up twice to the
tower at the top of the house. On the numpad, use 7 to walk north-west and 9 to
walk north-east up the steps, as it is quicker than using the arrow keys.

GET the FLY on the floor near the telescope. Nothing can be seen by looking in
the telescope, and only a message appears suggesting that this is how Manannan
can see everything in Llewdor. Walk down the steps and north into Manannan's
bedroom. LOOK ON TOP OF the CLOSET to find a small brass key. OPEN the CLOSET
and LOOK BEHIND the CLOTHES to discover an ancient map. There is currently
nothing on the map, but locations will appear on it as Llewdor is explored.
OPEN the DRESSER DRAWER to get the vial of Rose Petal Essence. OPEN the VANITY
DRAWER below the mirror to collect the hand mirror. Exit Manannan's bedroom.

Open the inventory by pressing the tab key. Manannan will kill Gwydion if he
finds him carrying any of the items with an asterisk next to them, so we need
to hide them before he appears again. Walk east into Gwydion's bedroom and DROP
the INVENTORY under the bed. You could individually drop asterisk items, but
it's quicker just to drop and collect the entire inventory. Go west one screen
and wait for Manannan to appear when the timer is on five minutes. Seeing that
Gwydion is apparently not up to any trouble, he leaves on a journey.

Manannan will leave on his journey for 25 minutes, which gives plenty of time
to collect many of the items needed for magic before he returns. Walk east and
return to Gwydion's bedroom to GET the INVENTORY from under the bed. Walk west,
down and north to Gwydion's study. The cat should be in the room, but if he
isn't there just exit and return to the room until he is. Try to GET the CAT.
Most of the time he will escape, but occasionally Gwydion will catch him. GET
the cat HAIR while holding the cat. Walk south twice to exit the house.

OPEN the chicken coop GATE and GET a CHICKEN. GET a FEATHER from the chicken
and then OPEN the GATE to exit the chicken coop. Walk south to the mountain
path. Manannan must have left on his journey before attempting to walk down the
path, as he will send Gwydion back to the house if he finds him. The path is
quite difficult to walk down, so start by pressing F10 until the game speed is
set to slow. Next save the game by pressing F5. It is very easy to fall off the
edge of the cliff here, so if Gwydion does die just press F7 to restore the
game. Make your way carefully down the path to the next screen.

The bottom half of the mountain path is easier than the top half. Just avoid
the rocks at the side of the path and save along the way. Walk east one screen
from the bottom of the path and GET the MUD from the stream's bank using the
wooden spoon. Walk east one screen and then move onto the beach before walking
south. GET the ocean WATER to fill the empty cup. Walk north one screen and
then west four screens to arrive in the desert. Quickly face east. Medusa will
appear in this area, and she has the power to turn Gwydion into stone if he
faces toward her. Wait until she gets close before typing SHOW MIRROR.

Walk south one screen and GET the CACTUS growing beside the rock. Walk south
two screens and GET the SNAKE SKIN on the sand. Walk east two screens to arrive
in an area with a waterfall. An eagle will occasionally fly through this area,
although it may not happen the first time Gwydion enters the area. Exit the
area and return to it until the eagle flies by and drops a feather. It may take
a long time for the eagle to appear and sometimes it may pass without dropping
a feather at all, so just keep returning until it does. GET the FEATHER.

Walk east one screen and north one screen to see a town in the distance. GET
the MISTLETOE that is growing on the tree. Walk west to the Three Bears house.
Leave and return to the area if any of the bears are visible. OPEN the DOOR to
enter the house. GET the BOWL of porridge on the table. Walk upstairs and OPEN
the DRAWER at the side of the bed with the blue cover. GET the THIMBLE. Walk
downstairs and exit the house. Walk onto the flowerbed and GET the DEW from the
flower with the thimble. Walk one screen west and one screen north. GET the
ACORNS and then REACH INTO the HOLE of the tree to reveal a ladder.

Climb up the ladder to see the bandits' shack. LOOK INTO the SHACK and read the
message that is shown. If somebody is moving around inside the treehouse, climb
down to exit the screen and then climb back up to return to it. Keep looking
into the treehouse until a message appears that there is a figure is sleeping
in a chair. Climb up the ladder until Gwydion's feet are parallel with the
platform at the side of the shack. Walk west into the shack and GET the PURSE
on the table. Exit the shack and climb back down the ladder. Walk east two
screens to the town. OPEN the DOOR to the store. Inside, GET the FUR from Kenny
the dog and BUY the FISH OIL, LARD, POUCH and SALT on the shelves.

Exit the store and walk one screen west and one screen north to the mountain
path. Decrease the speed and save frequently on the way up the path. OPEN the
DOOR to the house at the top of the path. Walk north to the study and OPEN the
CABINET at the bottom-left corner of the room to collect the magic wand. MOVE
the BOOK on the shelf at the right side of the room, and then MOVE the LEVER
that was behind it to reveal stone steps. Walk down the steps. Continue down
the stone steps to arrive in the wizard's laboratory. Approach the shelf at the
north side of the room and GET the MANDRAKE ROOT POWDER, NIGHTSHADE JUICE,
POWDERED FISH BONE, TOAD SPITTLE and TOADSTOOL POWDER.


-------------------------------------------------------------------------------
2.2.                          Casting the Spells
-------------------------------------------------------------------------------


By following the first section of the walkthrough, we should now have enough of
the items to create six of the seven magic spells in the game. This section of
the game can be quite frustrating, as creating the magic can take quite a long
time and no mistakes can be made at all. Every letter has to be typed correctly
and all items that the spell requires must have been collected. For this reason
it's important to save the game before attempting each of the spells.

LOOK at PAGE II of the book on the table. PUT the CHICKEN FEATHER IN the BOWL.
PUT the DOG FUR IN the BOWL. PUT the DRIED SNAKE SKIN IN the BOWL. PUT the
POWDERED FISHBONE IN the BOWL. PUT the THIMBLEFUL OF DEW IN the BOWL. MIX WITH
HANDS. SEPARATE the MIXTURE INTO TWO PIECES. PUT the DOUGH IN EARS.

Enter the verse after correctly adding all of the ingredients.
    FEATHER OF FOWL AND BONE OF FISH
    MOLDED TOGETHER IN THIS DISH
    GIVE ME WISDOM TO UNDERSTAND
    CREATURES OF AIR SEA AND LAND
WAVE the WAND after entering the final line to complete the first spell.

LOOK at PAGE IV. PUT A PINCH OF SAFFRON IN the ESSENCE and enter the verse.
    OH WINGED SPIRITS SET ME FREE
    OF EARTHLY BINDINGS JUST LIKE THEE
    IN THIS ESSENCE BEHOLD THE MIGHT
    TO GRANT THE PRECIOUS GIFT OF FLIGHT
WAVE the WAND to complete the second spell.

LOOK at PAGE XIV. GRIND the DRIED ACORNS IN the MORTAR to make acorn powder.
PUT the ACORN POWDER IN the BOWL. PUT the NIGHTSHADE JUICE IN the BOWL. STIR
the MIXTURE. LIGHT the BRAZIER and HEAT the MIXTURE ON the lit BRAZIER. SPREAD
the MIXTURE ON the TABLE and enter the verse.
    ACORN POWDER GROUND SO FINE
    NIGHTSHADE JUICE LIKE BITTER WINE
    SILENTLY IN DARKNESS YOU CREEP
    TO BRING A SOPORIFIC SLEEP
WAVE the WAND to complete the third spell. PUT the SLEEP POWDER IN the POUCH.

LOOK at PAGE XXV. PUT the MANDRAKE ROOT POWDER IN the BOWL. PUT the CAT HAIR IN
the BOWL. PUT TWO SPOONS OF FISH OIL IN the BOWL. STIR the MIXTURE. PUT the
DOUGH ON the TABLE. PAT the DOUGH INTO a COOKIE and enter the verse.
    MANDRAKE ROOT AND HAIR OF CAT
    MIX OIL OF FISH AND GIVE A PAT
    A FELINE FROM THE ONE WHO EATS
    THIS APPETIZING MAGIC TREAT
WAVE the WAND to complete the fourth spell.

LOOK at PAGE LXXXIV. PUT the CUP OF OCEAN WATER IN the BOWL. The brazier should
still be lit from the spell on page XIV, but LIGHT the BRAZIER anyway just to
be sure. HEAT the BOWL ON the BRAZIER. PUT the MUD IN the BOWL. PUT a PINCH of
TOADSTOOL POWDER IN the BOWL. BLOW the BOWL and enter the verse.
    ELEMENTS FROM THE EARTH AND SEA
    COMBINE TO SET THE HEAVENS FREE
    WHEN I STIR THIS MAGIC BREW
    GREAT GOD THOR I CALL ON YOU
WAVE the WAND to complete the fifth spell. PUT the BREW IN the JAR.

LOOK at PAGE CLXIX. CUT the CACTUS WITH the KNIFE. SQUEEZE the CACTUS on the
SPOON. PUT the CACTUS JUICE IN the BOWL. PUT the LARD IN the BOWL. PUT the TOAD
SPITTLE IN the BOWL. STIR the MIXTURE WITH the SPOON and enter the verse.
    CACTUS PLANT AND HORNY TOAD
    I NOW START DOWN A DANGEROUS ROAD
    COMBINE WITH FIRE AND MIST TO MAKE
    ME DISAPPEAR WITHOUT A TRACE
WAVE the WAND to complete the sixth spell. PUT the OINTMENT IN the JAR.


-------------------------------------------------------------------------------
2.3.                            Leaving Kolyma
-------------------------------------------------------------------------------


Walk up twice to return to Manannan's study. MOVE the LEVER and MOVE the BOOKS
to prevent Manannan from learning of Gwydion's spell making. OPEN the CABINET
to replace the magic wand. Walk south, up and east to Gwydion's bedroom. PUT
the COOKIE IN the PORRIDGE. DROP the INVENTORY under the bed. GET the poisoned
PORRIDGE from under the bed. When Manannan returns, he will see that Gwydion is
carrying a seemingly harmless bowl of porridge. Walk west and down to the entry
hall. Wait for Manannan to appear and complain about being hungry. Walk east to
the dining room and GIVE the bowl of PORRIDGE TO MANANNAN. He eats it and
transforms into a cat, a form that he will remain in for the rest of the game.

Now that Gwydion is safe from Manannan, it's time to get all of his items back.
Walk west, up and east to Gwydion's room and GET the INVENTORY from below the
bed. LOOK at the magic MAP to see all of the locations that have been visited
so far. Gwydion will teleport to any location that is selected, so move the
cursor south one square and east one square, then press F6 to travel to the
tavern. OPEN the tavern DOOR to enter the tavern. Exit and return until two
bandits are sitting at the table. They won't reveal any new information while
Gwydion is near, so DIP the FLY WINGS IN the ESSENCE to transform into a fly,
and then wait for the bandits to talk about their hideout. Exit the tavern.

Move west twice after exiting the tavern to arrive in an area with the walnut
tree. Fly into the hole at the bottom of the tree to see a rope leading up
into a small hole above. Outside the tree, say FLY BEGONE, MYSELF RETURN to
return to normal form. The point of that little expedition into the tree was
to show that there was a rope in the hollow trunk. As Gwydion should have
already climbed up to the bandits' den earlier in the game, we don't need to
worry about climbing up the tree again. LOOK at the MAP and this time move the
cursor two squares north from the tavern. Press F6 to travel to the cave.

It's time to use another magic spell. DIP the EAGLE FEATHER IN ESSENCE. With
Gwydion now in eagle form, fly toward the cave to see the giant spider. Gwydion
picks the spider up in his beak and dumps it in the ocean. Return to the cave
and enter it to talk to the Oracle. The Oracle says that a dragon has chosen
Gwydion's sister Rosella as a sacrifice. He tells Gwydion that he might be able
to help her if he hurries and gives him a stone of amber. Exit the cave and
walk west one screen, then north five screens to return to the house. OPEN the
DOOR to enter the house. Walk north and OPEN the CABINET to retrive the wand.
MOVE the BOOK and MOVE the lever. Walk down twice to return to the laboratory.

LOOK at PAGE VII. GRIND the SALT IN the MORTAR. GRIND the MISTLETOE IN the
MORTAR. RUB the STONE IN the MIXTURE. KISS the STONE and enter the verse.
    WITH THIS KISS I THEE IMPART
    POWER MOST DEAR TO MY HEART
    TAKE ME NOW FROM THIS PLACE HITHER
    TO ANOTHER PLACE FAR THITHER
WAVE the WAND to complete the seventh spell.

With the final spell completed, it's now time to leave Kolyma. LOOK at the MAP
and move the cursor one square east and one square south to the tavern, then
press F6 to teleport to the location. OPEN the tavern DOOR to see a group of
sailors seated around the table. TALK to the SAILORS and the captain will ask
for gold in return for passage on the ship. GIVE the GOLD to the captain and
he will tell Gwydion to board the ship at the wharf. Exit the tavern and walk
east twice along the dock. Walk across the gangplank to board the ship.

After arriving on the ship, the captain orders his men to take Gwydion's items
and to put him in the hold. Walk east one screen and GET the CRATE. Move west
one screen and DROP the small CRATE at the right side of the big crate. JUMP
on the crate twice to stand on the big crate. JUMP again and Gwydion will hang
onto the ladder above the crate. Climb up the ladder and go east at the top.
Quickly exit and return to the room if one of the crew members is here. GET
the SHOVEL in front of the boat. Walk west one screen. Exit and return to the
room if the captain is in his cabin. Enter the cabin and OPEN the CHEST at the
bottom of the bed. GET all of Gwydion's INVENTORY from the chest.

Exit the cabin and climb down the ladder to return to the hold. Walk east one
screen and LOOK at the magic MAP. The destination of the ship is the island at
the bottom-right corner of the map. It can take quite a long time for the ship
to make its way over to the island, so just keep checking the map frequently to
see how much further the ship has to go. Eventually a message will appear that
mentions that land is near. POUR the SLEEP POWDER ON the FLOOR and say SLUMBER
HENCEFORTH to cast the sleep spell over the ship. Walk west one screen and JUMP
on the crate twice, then JUM onto the ladder. Climb up two screens and step
off the left side of the ladder. Walk east one screen and then drop off the
north side of the ship. Swim east to see the island.


-------------------------------------------------------------------------------
2.4.                          Route to Daventry
-------------------------------------------------------------------------------


A shark will appear just before Gwydion reaches the beach. Avoid being attacked
by the shark by swimming toward the bottom-left corner of the beach. The shark
will get very near, but will leave after Gwydion steps onto the island. Walk
east one screen and walk to the right side of the palm tree. Set the game speed
to slow and take five steps east from the palm tree before stopping. DIG in the
sand with the shovel to find a small chest that contains treasure. Walk north
one screen and east one screen to see a mountain path.

Walk on the path and move west one screen. Be careful not to fall off the south
edge, as Gwydion will have to go back to the beginning of the path. Follow the
path along to the left and climb up the rock. Step off the right side of the
rock and walk east to the next screen. Walk north around the corner and then
continue following the path through the forest to see a waterfall. Climb up the
waterfall and walk east two screens. Type PUT FLY WINGS IN ESSENCE but don't
press enter yet. Wait for the abominable snowman to appear, then press enter.
The abombinable snowman becomes confused by the fly and returns to his cave.
Type FLY BEGONE, MYSELF RETURN to change back to normal form.

Walk down the south-west path to start climbing down the icy wall. Enter the
top-left cave to exit the top-right cave. Walk to the left side of the ledge
and climb onto the wall. Climb down the wall and enter the bottom-middle cave
to exit the bottom-left cave. Climb up the wall and enter the middle cave to
exit the bottom-right cave. Walk east two screens and south one screen to fall
into Daventry. Walk east one screen to enter the stair cave that was seen in
King's Quest I. Use the page up key to climb up the first set of stairs, and
the home key to climb up the second set of stairs. Walk west to exit the cave.

The cave leads to the Land of the Clouds, another location seen in the original
King's Quest. Before moving anywhere else, RUB the invisibility OINTMENT ON
SELF. Walk west one screen to see the giant three-headed dragon that the
Oracle mentioned. STIR the STORM BREW WITH FINGER and then say the verse BREW
OF STORMS, CHURN IT UP. Storm clouds gather, and lightning strikes the dragon
and kills it. UNTIE ROSELLA and she will now follow Gwydion where he walks.
Walk east two screens to return to the cave. This time, use the page down key
to walk down the top stairs and the end key to walk down the bottom stairs.
Walk west one screen from the cave exit to see the old well, which is now full
of rocks. Walk north two screens to return to Daventry castle.

In the ending, Gwydion enters the throne room with his sister Rosella. King
Graham and Queen Valanice gladly welcome them back to the castle, and Gwydion
finds out that his real name is Alexander. Graham points out that the magic
mirror had been clouded ever since the night he was stolen from the cradle by
Manannan. The next second the mirror clears, and Valanice rejoices that all of
the curses in Daventry have been lifted. Graham retrieves his adventurer's hat
and decides to give it away to a new companion. He throws it into the air.
Alexander and Rosella both reach for it, but the message The End appears before
the game shows who catches it. A congratulation message appears, followed by a
message that the adventuring will continue in King's Quest IV.


===============================================================================

3.                              Character List

===============================================================================


ABOMINABLE SNOWMAN
  This giant grey monster appears on the snowy mountain range. He kills Gwydion
  if he catches him. The abominable snowman can be confused easily, as he will
  walk back to his cave if he sees Gwydion transform into an eagle or a fly.


BANDIT IN THE HIDEOUT
  Found in hideout at the top of the acorn tree. The bandit guards the purse
  and gold coins in the hideout, but this can only be collected when the bandit
  is sleeping. Items that were stolen can be found in the bin in the shack.


BANDITS IN LLEWDOR
  Two bandits will attempt to catch Gwydion in the areas surrounding the oak
  tree. They will steal any treasures they have and will drop them in the bin
  in their hideout. They will leave Gwydion alone if he holds no treasures.


BANDITS IN THE TAVERN
  Two bandits sit in the tavern drinking ale. They will reveal no information
  to Gwydion while he is in human form, but after he transforms into a fly,
  they will reveal the location of their hideout in the oak tree.


CAT
  The evil cat is a pet of Manannan's and silently walks around the house. He
  will try to trip Gwydion up when he walks down the steps to the laboratory.
  Gwydion can pick the cat up to take some cat hair from it.


CHICKENS
  Two chickens walk about in the chicken coop outside Manannan's house. They
  can be fed with the feed at the north side of the coop. After picking one of
  the chickens up, Gwydion is able to take a feather from it.


DRAGON
  This fire-breathing three-headed dragon lives in the middle of the Land of
  the Clouds. Gwydion must pass the dragon to rescue Rosella from the stake. He
  will need to become invisible and to use the magic storm brew to do this.


EAGLE
  Found one screen south from the three bears' house. The eagle can take a long
  time to appear, but will drop the eagle feather when he flies past. Gwydion
  can also transform into an eagle to scare away the spider in the cave.


FLY
  Gwydion can transform into a fly to listen to the bandits speak about their
  hideout in the tavern, to enter the hole at the base of the oak tree to see
  the rope, and to scare away the abominable snowman on the snowy peak.


GNOME
  Found one screen south from Daventry castle. The old gnome jumps out of his
  chair and runs off to the castle when Gwydion and Rosella arrive in Daventry.
  He resembles Ifnkovhgroghprm, the gnome from the first King's Quest game.


GRAHAM
  Graham sits in throne room of Daventry castle with Valanice, who he rescued
  from an enchanted land at the end of the previous game. Graham was the main
  character in the previous two games. He is the father of Gwydion and Rosella.


GWYDION
  The main character of the game. Gwydion was raised by Manannan, the wizard
  who plans to kill him by his eighteenth birthday. His quest sees him trying
  to escape from the wizard so that he can return to his family in Daventry.


KENNY
  Found in the store. Kenny is the friendly red dog that lies on the floor of
  the shop. Gwydion can pet Kenny to collect some dog hair for use in a magic
  spell. From then on, Kenny will only wag his tail when Gwydion pets him.


MANANNAN
  Found in various areas, Manannan is the evil wizard the kidnapped Gwydion
  from his home when he was only a baby. He keeps a close watch on everything
  that Gwydion does, and kill him if he causes too much trouble.


MEDUSA
  Found in the desert at the left side of Llewdor. Medusa is capable of turning
  anyone that looks at her into stone. Her touch also has the same effect. She
  can only be defeated by being shown a reflection of herself in a mirror.


ORACLE
  The mysterious oracle is found in a cave guarded by a huge spider. He tells
  Gwydion that is sister Rosella was chosen to be the sacrifice for a dragon
  that has invaded Daventry. He gives the stone of amber to Gwydion.


ROSELLA
  Found tied to a stake next to the three-headed dragon in the Land of the
  Clouds. Rosella is Gwydion's sister, and after being rescued she accompanies
  Gwydion back to Daventry where they are reunited with their parents.


SAILORS
  Found in the tavern after Gwydion has completed the final magic spell. They
  initially refuse to let Gwydion board their ship, although they change their
  minds and let him board after being shown the purse and gold coins.


SHARK
  Found in the ocean next to the beach on the island. The shark is faster than
  Gwydion, and will follow him as he makes his way from the ship to the island.
  Gwydion must swim to the correct point on the beach to avoid the shark.


SNAIL
  Manannan will transform Gwydion into a snail if he doesn't complete one of
  his tasks within the time limit. He will move slowly while in this form. It
  is only temporary and he is returned to his normal form after one minute.


SPIDER
  The spider hides in a tree above the entrance to the oracle's cave. Gwydion
  will become stuck in her web if he walks into it. After Gwydion transforms
  into an eagle, he picks up the spider in his beak and drops her in the ocean.


STOREKEEPER
  Found in the store. The storekeeper is the owner of Kenny the dog, and sells
  many items that are essential for creating the magic spells. The fish oil,
  lard, empty pouch and salt can be bought from the storekeeper.


THREE BEARS
  Found one screen south-east from the oak tree. The three bears often leave
  their house to go for a walk, which is the only time Gwydion can enter. They
  will send Graham away if he attempts to enter the house when they are home.


VALANICE
  Found in the throne room of Daventry castle. Valanice was rescued by Graham
  from the enchanted land at the end of the previous game. She is the mother of
  Gwydion and Rosella. Once again she is only featured in the ending.


===============================================================================

4.                                Item List

===============================================================================


ACORNS
  Found on the grass one screen north-west from the three bears house. They are
  used in the mortar when making the spell on page XIV.


AMBER STONE
  Found by talking to the oracle in the spider's cave. After completing the
  spell on page VII, the amber stone changes into the magic stone.


BOWL
  Found on the shelf in the kitchen in Manannan's house. It is used in the
  spells on page II, page XIV, page XXV, page LXXXIV and page CLXIX.


BRASS KEY
  Found on top of the closet in Manannan's bedroom. It is used to open the
  cupboard containing the magic wand in the wizard's study.


BREAD
  Found on the table in the kitchen in Manannan's house. It is one of the items
  that can be given to Manannan in the dining room when he demands food.


CACTUS
  Found one screen south of the location in the desert where Medusa appears. It
  is used in the spell on page CLXIX to make the cactus juice.


CAT COOKIE
  Made after completing the the spell on page XXV. It is put in the bowl of
  porridge to make the bowl of poisoned porridge.


CAT HAIR
  Found by taking the hair while holding the cat in Manannan's house. It is
  put in the bowl while creating the spell on page XXV.


CHICKEN FEATHER
  Found on the chicken outside Manannan's house. It is one of the items that is
  used in the bowl while creating the spell on page II.


DOG HAIR
  Found by petting Kenny the dog in the town store. It is one of the items that
  is used in the bowl while creating the spell on page II.


DOUGH IN EARS
  Made by putting the dough in Gwydion's ears after completing the spell on
  page II. Gwydion can understand animals when he has the dough in his ears.


EAGLE FEATHER
  The eagle drops the feather two screens east of the snake skin. It is one
  of the items that is used in the bowl while creating the spell on page II. It
  is dipped in the essence to transform Gwydion into a eagle.


EMPTY CUP
  Found on the table in the kitchen in Manannan's house. It is used to collect
  the water from the ocean at the right side of Llewdor.


EMPTY LARD JAR
  Found after using the lard in the spell on page CLXIX. After completing the
  spell on page CLXIX, the invisibility ointment is put in the jar.


EMPTY JAR
  Found after using the fish oil in the spell on page XXV. After completing the
  spell on page LXXXIV, the storm brew is put in the jar.


EMPTY POUCH
  Found on the shelf in the town store. The empty pouch is used to hold the
  sleep powder after creating the spell on page XIV.


EMPTY PURSE
  Found after giving the purse and gold coins to the sailors in the tavern
  after completing the spell on page VII. It is not used.


FISH OIL
  Found on the shelf in the town store. Two spoons of fish oil are used in the
  bowl while creating the spell on page XXV.


FLY WINGS
  Found in the telescope tower on the top floor of Manannan's house. They are
  dipped in the essence to transform Gwydion into a fly.


FRUIT
  Found on the table in the kitchen in Manannan's house. It is one of the items
  that can be given to Manannan in the dining room when he demands food.


INVISIBILITY OINTMENT
  Made after completing the spell on page CLXIX. It is rubbed on Gwydion before
  entering the area with the three-headed dragon in the Land of the Clouds.


KNIFE
  Found on the rack in the kitchen in Manannan's house. It is used to cut the
  cactus so that the cactus juice can be made in the spell on page CLXIX.


LARD
  Found on the shelf in the town store. It is one of the items that is used in
  the bowl while creating the spell on page II.


MAGIC MAP
  Found behind the clothes in the closet in Manannan's bedroom. It can be used
  to teleport to areas that have already been visited in the game.


MAGIC ROSE ESSENCE
  Found by completing the spell on page IV. It is used with the eagle feather
  to transform into an eagle, and with the fly wings to transform into a fly.


MAGIC STONE
  After completing the spell on page VII, the amber stone changes into the
  magic stone. The stone can be rubbed to teleport to random locations.


MAGIC WAND
  Found in the cabinet in Manannan's study. It is used to create the seven
  magic spells. The cabinet can be opened again to drop the wand.


MANDRAKE ROOT
  Found on the shelf in Manannan's laboratory. It is one of the items that is
  used in the bowl while creating the spell on page XXV.


MIRROR
  Found by opening the dresser drawer in Manannan's bedroom. It is shown to
  Medusa while Gwydion is facing away from her in the desert.


MISTLETOE
  Found on the tree one screen east of the three bear's house. It is one of
  the items that is used in the mortar while creating the spell on page VII.


MUD
  Found on the bank of the river one screen north from the town. It is one of
  the items that is used in the bowl while creating the spell on page LXXXIV.


MUTTON
  Found on the table in the kitchen in Manannan's house. It is one of the items
  that can be given to Manannan in the dining room when he demands food.


NIGHTSHADE JUICE
  Found on the shelf in Manannan's laboratory. It is one of the items that is
  used in the bowl while creating the spell on page XIV.


OCEAN WATER
  Found in the ocean at the right side of Llewdor. It is one of the items that
  is used in the bowl while creating the spell on page LXXXIV.


POISONED PORRIDGE
  Made by putting the cat cookie in the porridge. It is given to Manannan after
  he returns from his journey to transform him into a cat.


PORRIDGE
  Found on the table on the bottom floor of the three bear's house. It is mixed
  with the cat cookie to make the poisoned porridge.


POWDERED FISH BONE
  Found on the shelf in Manannan's laboratory. It is one of the items that is
  used in the bowl while creating the spell on page II.


PURSE AND GOLD COINS
  Found on the table in the bandits' shack at the top of the tree. It is used
  to buy the oil, lard, pouch and salt from the town store.


ROSE ESSENCE
  Found in the drawer at the right side of Manannan's bedroom. After completing
  the spell on page IV, the rose essence changes into the magic rose essence.


SAFFRON
  Found on the shelf in Manannan's laboratory. A pinch of the saffron is used
  in the essence while creating the spell on page IV.


SALT
  Found on the shelf in the town store. It is one of the items that is used in
  the mortar while creating the spell on page VII.


SHOVEL
  Found outside the crew's quarters on the second deck of the ship. It is used
  to dig in the sand five paces east from the palm tree on the island.


SLEEP POWDER
  Made by creating the spell on page XXV. After the message about the land
  appears, the sleep powder is poured on the floor to make the crew sleep.


SNAKESKIN
  Found on the sand two screens south from the cactus. It is one of the items
  that is used in the bowl while creating the spell on page II.


SPOON
  Found on the rack in Manannan's kitchen. It is used to get the mud from the
  stream. It is also used in the spells on page XXV and page CLXIX.


STORM BREW
  Made by creating the spell on page LXXXIV. It is stirred with Gwydion's
  finger before saying the verse to defeat the dragon.


THIMBLE
  Found in the drawer on the top floor of the bears' house. It is used to get
  the dew from the garden outside the bears' house.


THIMBLE AND DEW
  Found by using the thimble on the flowers outside the bears' house. It is one
  of the items that is used in the bowl while creating the spell on page II.


TOAD SPITTLE
  Found on the shelf in Manannan's laboratory. It is one of the items that is
  used in the bowl while creating the spell on page CLXIX.


TOADSTOOL POWDER
  Found on the shelf in Manannan's laboratory. It is one of the items that is
  used in the bowl while creating the spell on page LXXXIV.


TREASURE CHEST
  Found by walking five paces east from the palm tree on the island and using
  the shovel to dig in the sand. It is not used.


===============================================================================

5.                                Point List

===============================================================================


             FINDING THE MAGIC ITEMS
             -----------------------
1      1     Get the cup in the dining room.
2      1     Get the bread on the table.
3      1     Get the mutton on the table.
4      1     Get the fruit on the table.
5      1     Get the knife on the rack.
6      1     Get the spoon on the rack.
7      1     Get the bowl on the shelf.
8      1     Get the fly wings in the tower.
11     3     Look on top of the closet.
18     7     Look behind the clothes in the closet.
19     1     Open the dresser drawer.
20     1     Open the vanity drawer.
24     4     Drop the inventory under the bed.
25     1     Get the hair from the cat.
26     1     Get the feather from the chicken.
27     1     Get the mud from the river.
28     1     Get the water from the ocean.
33     5     Show the mirror to defeat Medusa.
34     1     Get the cactus from the desert.
35     1     Get the snake skin from the desert.
37     2     Get the eagle feather in the forest.
38     1     Get the mistletoe from the tree.
40     2     Get the bowl of porridge in the bears' house.
41     1     Open the drawer in the bears' bedroom.
42     1     Collect the dew from the flowers.
43     1     Get the acorn on the grass.
46     3     Reach into the hole in the tree.
48     2     Climb the ladder to the bandits' shack.
52     4     Get the purse on the table in the shack.
53     1     Get the fur from the dog.
54     1     Buy the fish oil from the store.
55     1     Buy the lard from the store.
56     1     Buy the pouch from the store.
57     1     Buy the salt from the store.
61     4     Open the cabinet in Manannan's study.
66     5     Move the lever behind the books.
67     1     Get the mandrake root powder.
68     1     Get the nightshade juice.
69     1     Get the powdered fishbone.
70     1     Get the saffron.
71     1     Get the toad spittle.
72     1     Get the toadstool powder.


             CASTING THE SPELLS
             ------------------
82     10    Complete the spell on page II.
92     10    Complete the spell on page IV.
102    10    Complete the spell on page XIV.
112    10    Complete the spell on page XXV.
122    10    Complete the spell on page LXXXIV.
132    10    Complete the spell on page CLXIX.


             LEAVING KOLYMA
             --------------
144    12    Give Manannan the poisoned porridge.
147    3     As a fly, listen to the bandit.
152    5     As a fly, enter hole in the tree.
156    4     As an eagle, defeat the spider.
159    3     Get the amber stone from the oracle.
169    10    Complete the spell on page VII.
172    3     Give the gold to the captain.
174    2     Board the ship.
176    2     Climb the ladder.
177    1     Get the shovel.
180    3     Get the inventory from the chest.
185    5     Swim to the island.


             ROUTE TO DAVENTRY
             -----------------
192    7     Find the chest near the palm tree.
196    4     Avoid the abominable snowman.
203    7     Defeat the dragon with the brew.
206    3     Untie Rosella.
210    4     Enter Daventry castle with Rosella.


===============================================================================

6.                                   Maps

===============================================================================


MAP 1: HOUSE - FIRST FLOOR
--------------------------

 _______*3  _______
|       |  |       |
| Study |  |Kitchen|
|___ ___|  |___ ___|
    |          |
 ___|___*2  ___|___
| Entry |  |Dining |
| Room  |--| Room  |
|___ ___|  |_______|
    |
   *1


*1: Leads to Outside House on map 2.
*2: Go upstairs to the second floor.
*3: MOVE the BOOK and PULL the LEVER to open the trapdoor leading to the lab.


MAP 2: HOUSE - SECOND FLOOR AND ATTIC
-------------------------------------

 _______    _______
|Wizards|  |       |
|Bedroom|  | Attic |
|___ ___|  |_______|
    |    __/
 ___|___/   _______
|       |  |Gwydion|
|Hallway|--|Bedroom|
|___ ___|  |_______|
    |
   *1


*1: Leads to the Entry Room on map 1.


MAP 3: LLEWDOR
--------------


                           *1
                         ___|___
                        |Outside|
                        | House |
                        |___ ___|
                            |
                         ___|___
                        |       |
                        | Path  |
                        |___ ___|
                            |
   _______    _______    ___|___    _______    _______    _______    _______
  |       |  |       |  |       |  |       |  |       |  |       |  |       |
*2|Desert |--|Forest |--| Path  |--|Stream |--| Beach |--| Ocean |--| Ocean |*3
  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
      |          |          |          |          |          |          |
   ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
  |       |  |       |  |       |  |       |  |       |  |       |  |       |
*2|Cactus |--|Walnut |--| Path  |--| Town  |--| Dock  |--| Dock  |--| Dock  |*3
  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
      |          |          |          |          |          |          |
   ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
  |       |  |       |  |       |  |Mistle-|  |       |  |       |  |       |
*2|Desert |--|Forest |--|3 Bears|--|  toe  |--| Beach |--| Ocean |--| Ocean |*3
  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
      |          |          |          |          |          |          |
   ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
  | Snake |  |       |  |       |  |       |  |       |  |       |  |       |
*2| Skin  |--| Ruins |--| Eagle |--| Cave  |--| Beach |--| Ocean |--| Ocean |*3
  |_______|  |_______|  |_______|  |_______|  |_______|  |_______|  |_______|


*1: Leads to the Entry Room on map 1.
*2: Leads to endless desert.
*3: Leads to endless ocean.


MAP 4: ISLAND (WEST SIDE)
-------------------------

                                  _______
                                 | Snow  |
                                 | Peak  |-*1
                                 |___ ___|
                                     |
                       _______    ___|___
                      |Forest |  |Water- |
                      | Path  |--| fall  |
                      |___ ___|  |_______|
                          |
            _______    ___|___
           |Mountn |  |Mountn |
           | Path  |--| Path  |
           |___ ___|  |_______|
               |
 _______    ___|___
|       |  |       |
| Beach |--| Chest |
|_______|  |_______|


MAP 5: ISLAND (EAST SIDE)
-------------------------

    _______    _______
   | Snow  |  | Snow  |
*1-| Peak  |--| Peak  |
   |_______|  |___ ___|
                  |
               ___|___    _______    _______
              | Cave  |  |Mountn |  |Mountn |
              | Maze  |--| Path  |--| Path  |
              |_______|  |_______|  |_______|



MAP 6: DAVENTRY
---------------

 _______    _______    _______
|       |  |       |  |       |
|Dragon |--| Cave  |--| Steps |
|_______|  |_______|  |_______|
                              \__
 _______    _______              \_______
|       |  |       |             |       |
|Castle |--|Castle |             | Steps |
|___ ___|  |_______|             |_______|
    |                          __/
 ___|___               _______/
|       |             |       |
| Gnome |             | Steps |
|___ ___|             |_______|
    |               __/
 ___|___    _______/
|       |  |       |
| Well  |--| Ruins |
|_______|  |_______|


===============================================================================

7.                         Easter Eggs and Secrets

===============================================================================


KING'S QUEST IV REFERENCE
-------------------------

There is a tapestry outside Gwydion's bedroom. Look behind the tapestry to
display a message which says that there are drawings, diagrams and notes to
programmers on the wall with the legend King's Quest IV. The message says that
Gwydion is uninterested in this as he is busy with King's Quest III.


===============================================================================

8.                            Debug Information

===============================================================================


Type "rats ass" to access debug mode. Type "Get object" followed by a number to
collect any item in the game, "Gimme gimme" to collect all items, or "TP"
followed by a number to teleport to a new location.

The wizard can also be effected. "Enchanter status" shows a page filled with
statistics on Manannan. "Bye bye enchanter" makes him leave on a journey,
"sleep enchanter" makes him sleep, and "here enchanter" makes him appear.


ITEMS
-----

1   Chicken Feather       18  Acorns               35  Empty Lard Jar
2   Cat Hair              19  Empty Pouch          36  Invisibility Ointment
3   Dog Hair              20  Sleep Powder         37  Magic Wand
4   Snakeskin             21  Mandrake Root        38  Brass Key
5   Powdered Fish Bone    22  Fish Oil             39  Magic Rose Essence
6   Thimble               23  Cat Cookie           40  Bowl
7   Thimble and Dew       24  Porridge             41  Spoon
8   Dough in Ears         25  Poisoned Porridge    42  Empty Cup
9   Eagle Feather         26  Ocean Water          43  Mirror
10  Fly Wings             27  Mud                  47  Empty Purse
11  Saffron               28  Toadstool Powder     48  Purse and Gold Coins
12  Rose Essence          29  Empty Jar            49  Bread
13  Salt                  30  Storm Brew           50  Fruit
14  Amber Stone           31  Toad Spittle         51  Mutton
15  Mistletoe             32  Lard                 52  Shovel
16  Magic Stone           33  Knife                53  Treasure Chest
17  Nightshade Juice      34  Cactus               54  Magic Map


LOCATIONS
---------

1   Manannan's house telescope tower      48  Beach on west side of island
2   Mannanan's house wizard's bedroom     49  Beach on east side of island
3   Mannanan's house hallway              50  West side of path on island
4   Manannan's house Gwydion's bedroom    51  East side of path on island
5   Mannanan's house study                52  Path through forest on island
6   Manannan's house kitchen              53  Path near waterfall on island
7   Manannan's house entry room           54  West side of mountain on island
8   Manannan's house dining room          55  Outside abominable snowman cave
9   Manannan's house laboratory steps     56  East side of mountain on island
10  Manannan's house laboratory           57  Cave maze
11  Desert west from ruins                58  Mountain path
12  Ruins                                 59  Mountain path
13  Forest                                60  Abominable snowman's cave
14  Outside the spider's cave             61  Daventry ruins
15  Beach east from spider's cave         62  Steps in cave
16  Desert north from cactus              63  Steps in cave
17  Forest north from acorn tree          64  Steps in cave
18  Mountain path                         65  Land of the Clouds west side
19  River with mud                        66  Land of the Clouds dragon
20  Beach east from river                 67  Land of the Clouds east side
21  Desert with cactus                    68  Daventry well
22  Acorn tree                            69  Land of the Clouds gnome house
23  Path west from town                   70  Storm in the ocean
24  Town                                  71  Daventry castle path west side
25  Dock east from town                   72  Daventry castle path east side
26  Desert north from snake skin          73  Daventry castle hall
27  Forest west from bears' house         74  Daventry castle throne room
28  Bears' house exterior                 75  Dock middle
29  Mistletoe                             76  Dock east side
30  Beach south from dock                 77  Ocean with ship in background
31  Ocean                                 78  Pirate ship crow's nest
32  Desert                                79  Pirate ship galley
33  Mountain Path                         80  Pirate ship upper deck
34  Manannan's house exterior             81  Pirate ship lower deck
35  Inside the tree trunk                 82  Pirate ship aft
36  Oracle's cave                         83  Pirate ship captain's cabin
37  Ladder outside bandits' hideout       84  Pirate ship crew's cabin
38  Bandits' hideout interior             85  Pirate ship cargo hold west side
39  Store interior                        86  Pirate ship cargo hold east side
40  Tavern interior                       87  Storm clouds
41  Three bears' house bottom floor       89  Magic map
42  Three bears' house top floor          94  Dock with pirate ship
43  Spell book                            95  East side of path on island


===============================================================================

9.                          Copyright Information

===============================================================================


This file is Copyright 2003-2008 Tom Hayes. As it can be difficult to keep
track of websites that haven't posted the latest version of this file, please
do not distribute it without my permission. Send an e-mail to me if you would
like to post this file on your website and you will likely receive a positive
response. If you do post the file, please keep it in its original form with all
of the sections intact and credit the author (Tom Hayes) as the writer of the
file. The latest version of this file can be found at www.gamefaqs.com.