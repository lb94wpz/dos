=========================================================================
************************* ANOTHER WORLD: WALKTHRU ***********************
=========================================================================

                  Amiga Adventure Game; released 1991 UK
       (Also released on the SNES and Genesis as "Out of this World")

                   WALKTHRU (Final Version) 28/03/2002

Author - falsehead (Sophie Cheshire). Contact me at falsehead@aol.com

Copyright stuff; this is (c) Sophie Cheshire. If you wish to use this FAQ on
your website, feel free to do so under the following conditions. a) You email
me first and let me know where it will be appearing and b) you do not alter the
content in anyway (if you need to change the formatting slightly for display
purposes that's OK).

If I find out that any part of this FAQ has been lifted and used without credit
to me, especially if you use it to earn money, then I will be annoyed. I didn't
type all this up for the good of my health you know.

========================================================================
********************************* CONTENTS *****************************
========================================================================

1) INTRODUCTION

2) WALKTHROUGH
a) SCENE ONE - Alone in the Wilderness
b) SCENE TWO - Escape from Prison
c) SCENE THREE - Pipe Nightmare
d) SCENE FOUR - Break for Freedom
e) SCENE FIVE - In the Caverns
f) SCENE SIX - Stalactite Leap
g) SCENE SEVEN - Water, Water, Everywhere!
h) SCENE EIGHT - Fighting the Guards
i) SCENE NINE - The Underwater Power-line
j) SCENE TEN - Outwitting the Guards
k) SCENE ELEVEN - Rescued Again
l) SCENE TWELVE - Returning the Favour
m) SCENE THIRTEEN - Causing Havoc
n) SCENE FOURTEEN - In the Spaceship	
o) SCENE FIFTEEN - Time to go...

=========================================================================
*************************** 1) INTRODUCTION *****************************
=========================================================================

INTRODUCTION - "Another World" was released on the Commodore Amiga computer in
1991 by developers 'Delphine Software'.  It was also released across several
16bit console formats under the name "Out of This World".  For the time it was
quite a striking looking and thoughtful combination of 2D adventuring and
puzzling.  Some haunting graphics and clever twists made it a very atmospheric
game.

REVISIONS - (28/03/2002). First and Final Version.  Full walkthrough for the
Amiga version written up. Nothing really left to add.

=========================================================================
************************** 2) WALKTHROUGH *******************************
=========================================================================

INTRO - You play the role of Lester, a scientist.  You are conducting
experiments in your lab with a particle accelerator. Then unfortunately a bolt
of lightning strikes it and before you can say "arrgh", Lester is zapped into a
strange, surreal dimension and quickly captured and put in a cage.  The cage is
dropped in a pool and it's now you begin the game proper...

***********************************************************************
a) SCENE ONE

You will appear in a swimming pool, so quickly push up to swim upwards and out
of the pool (before the tentacles get you). Now walk to the right, nasty black
leeches will fall from the top of the screen.  Shuffle forwards and kill them
by kicking them.  Do the same on the next screen and then edge carefully onto
the next one to be confronted by a huge black beast.  Quickly run back across
the previous three screens, the beats will give chase and nearly catch you, but
will stumble at the last minute.

Keep going left and you will reach a chasm.  Jump across and grab the vine. 
Press to the right and you'll swing back and snap dropping you behind the
beast.  Now run rightwards back to where you first met the beast.  A laser
blast will shoot out and kill the still pursuing beast.  You are then
confronted by a sinister black figure who stuns and captures you...

***********************************************************************
b) SCENE TWO

Now you're in a cage with another alien prisoner.  Move left and right to swing
the cage backwards and forwards.  Eventually it will fall and crush the guard
freeing you and the grateful alien who will help you out now.  He will dash
off, but you should step slightly to the right and crouch to pick up the guards
gun.

(USING THE GUN - Tapping fire will shoot off a quick low powered blast for
killing guards etc.  Hold the fire button until a blue and white sphere appears
at the end of the gun.  Release the trigger and this will turn into a shield
that will stay in front of you and stop the red laser beams from the guards. 
You can walk though the shield yourself though.  Finally press and hold fire
and keep holding it until the gun makes a loud humming noise.  Release the
trigger to produce a super blast that will demolish doors.  But this will drain
the gun so don't overuse it).

Now run right to the next screen and fire off a few quick shots to kill the
waiting guard. Run right with your alien pal and he will start trying to open
an electronic door.  You should stay in the centre of the screen and make
shields to protect you both from the guards, as well as firing red laser beams
at them to kill them off.

When your pal opens the door, follow him though and go to the lift.  Press down
and go to the bottom of the shaft.  Enter the room and shoot the guard on the
left, then the blue power-line on the wall.  Now go back to the lift and go
right to the top.  Check the view through the window, now go back to the lift
and travel down to the second opening from the bottom. Use a super laser gun
blast to get though the barrier. Use the transporters (looks like a hole in the
floor) to get to the rooms lower section.  Go left and go to the top section of
the next room.  A guard will appear, but you can ignore him.  Your alien friend
will open a trapdoor and you should jump down it into the big pipe.

***********************************************************************
c) SCENE THREE

(Remember to pause rolling and avoid the steam when necessary).

Roll to the extreme left and drop down.

Roll to the right and drop down.

Roll to the right and drop down.

Roll to the left, drop down and roll to the extreme right

***********************************************************************
d) SCENE FOUR

Recharge the gun in the chamber to the left and blast through the triple door
using three consecutive power blasts.  Recharge the gun again and move into the
room on the right.  Go carefully and kill the guard then head to the right.

Slowly ease your way to the very end of the ledge.  Jump and the screen will
scroll down to show you landing on a ledge further down.  Use a power blast to
get though the wall to the right.

***********************************************************************
e) SCENE FIVE

In these next parts of the game you're in some caverns and you'll need a lot of
patience for the precise jumps that are needed here.

Jump down first hole to your right and again.  You will be on a balancing rock.
 Go right and jump over the spikes/jaws/thingies and then continue going right
dodging the falling rocks.  When you see some tentacles hanging from the
ceiling either shoot them or run quickly past them.  Continue right avoiding
all the stuff that likes to kill you until you get to a wall.  Blast it.

***********************************************************************
f) SCENE SIX

Turn around and go back to where the falling rocks were. Take the road going up
and you'll be on a ledge.  Turn around and go onto the right screen and you'll
see a red bat-bird.  Shoot at it to get it moving and walk to the left, the
bird will follow you.

The bird will become trapped in some tentacles and this will allow you to jump
from the ledge onto the first stalactite.  Climb to the top and jump left onto
the next one.  Keep going until you reach the extreme left, your final jump
will take you off screen.

***********************************************************************
g) SCENE SEVEN

You'll land of a T-Shaped lump of rock.  Step off the left side and super-blast
the rock support, which will topple it over and make a ramp for you to walk up.
 So walk right up the ramp and keep going jumping all the gaps as you go.  Soon
you'll come to a large pool of water being held up by some rock.  Use a
power-blast to cut the rock and release the water, now run very quickly left,
again jumping all the holes as you go.  (It's tough you'll probably have to
make a few goes of this section). The torrent of water will follow you to the
final (discoloured) platform and then propel you upwards.  Now head up and
right and blast open the door.  Go the up the stairs and keep going right.

***********************************************************************
g) SCENE EIGHT

Now as you enter the buildings top floor, your alien pal will pop up through a
pipe in the floor (good to see he got out safely as well!). However he'll get
stuck so leave him for now and run to the right.  Next run down the stairs and
stop when you get halfway across the room.  As soon as the guard walks in,
shoot him.  Now go down the stairs and make use of the teleporter.

Run to the right and kill the guard.  Now continue right and shoot the
chandelier.  This will free up our alien friend.  Go back to the room with the
teleporter and carry on left until a guard knocks you down.  When he picks you
up, kick him between the legs (!) and grab your gun.  Now shoot him and carry
on left.

The next room is tricky.  You should walk carefully into the centre and build
two shields either side of you.  A guard will appear on either side of you and
you should fight them off one at a time.  This can be tricky and again you'll
need some practice to do it, the best way is to erect two shields one left, one
right about 1/3 across the room before the guards appear.  Then move halfway
across and erect tow more one left, one right.  The quickly super-blast the
shields of the guards and shoot them before they can shoot your shields.  But
you have to do it very quickly.  Now carry on right and you'll find a pool of
water.

***********************************************************************
i) SCENE NINE

Jump in it and swim down, swim to the left and go up the second tunnel.  This
will replenish your air supply.  Now swim directly down to the bottom and come
out of the water.  Walk to the left (jump over the nasty little creatures) and
then shoot the blue power-line.  Now swim back up using the same route and
remember to replenish your air as you go up.

***********************************************************************
j) SCENE TEN

Once your back up the top, walk left to use the teleporter and go back up the
stairs.  At the top, walk right until you come to three doors with a guard
behind them.  Build a shield and walk slowly towards the doors, they will open
and the guard will throw a bomb at you.  Now walk away and the doors will close
and the bomb will roll back and kill the guard.

Go through the doors and blast your way though the next one.  Recharge your gun
at the recharging point by using the teleporter.  Then teleport back and go on
right.  Crouch down until you are level with the gap in the ceiling.  Below is
a guard pacing by a pool of water. Watch the green ball hanging from the
ceiling and wait until you see the reflection of the guard below.  As soon as
you see it crouch down and shoot the chain to drop the ball on the guard and
kill him. Go back down to the pit of water and swim across, you'll see the dead
guard surrounded by broken glass.  Carry on right.

***********************************************************************
k) SCENE ELEVEN

You'll fall down a shaft.  Shoot the door on the right.  Keep running right
across four screens.  You'll reach a room with a trapdoor and an air duct above
you.  Stand under the air duct and make shields to the left of you.  Guards
will start kicking open the trapdoor, but a hand will reach down and yank you
up though into the air duct.

***********************************************************************
l) SCENE TWELVE

Walk left behind the rock, then right.  This puts you on a path behind the
building your friend went into (and got himself captured, doh!).  Go in though
the back door and right up to the guard's shield.  Put your gun right through
the shield and shoot him.  Your friend will have taken care of the other guard.

Follow him to the right until you come to a chasm.  Stand close to your friend
and he will pick you up and throw you over to the other side.  He'll try and
jump, but won't make it.  Stand on the edge of the gap and jump.  You'll grab
hold of a canopy that will break your fall to the next level down.  Put up
shields and kill the two guards that come and attack you.

***********************************************************************
m) SCENE THIRTEEN

Run to the left going behind the three guards.  Point your gun at the last
guard and he'll surrender.  Make sure your standing to the right of the door or
you'll get locked in.  Go up the stairs on the screen to your right and block
yourself in with a lot of shields.  Stick your hands out through them and shoot
away at the door.  Let the guard throw about four grenades, which will blow a
hole in the floor, then kill him.

Make your way over to the left, face to the right and teleport down.  As soon
as you're down, create a few shields, shoot the guards shields with a big laser
bolt and then kill him.

Teleport down and shoot the power-line.  Use the teleport to go back up and
then go down the hole the guard made with his grenades.  Go right and the
screen goes dark, keep running right dodging the lasers and walk slowly into
the next screen.  Jump the gap and pull the lever.  Jump over the next gap and
fall down the left side of that hole.

Take a couple of steps to the right and create a shield, then run though it and
don't stop.  Keep running rightwards until you reach a wall and teleport up.
Then go to the left.  You will go through a door and your friend will reappear.
 Follow him to the right.  Follow him after he teleports.  Then follow him
rightwards and into the spaceship.

***********************************************************************
m) SCENE FOURTEEN

Now you're in the spaceship, you need to press a combination of buttons to get
out the top.  In the upper right corner of the screen is the ship's control
panel.  Only two buttons are showing.  Press them both.  Then press the button
on the lower left.  This activates a new panel of buttons to the left.  press
the top four buttons on this new panel.  A flashing button will now appear. 
Press the flashing button and you will eject out of the spaceship.

***********************************************************************
m) SCENE FIFTEEN

When you land, run to the right and kill the four guards who come across then
carry on running to the right. Your alien friend will break through the glass
window so follow him to the right.  A shot will come out of nowhere and send
you tumbling over a ledge.  However someone will reach down and grab your hand,
your friend came though again!

Argh, no he didn't after he hauls you up you see it's an alien guard who starts
to beat you up.  You real friend will leap on top of the guard and knock him
off you and starting fighting with him.  You're in a bad way now and so you
crawl rightwards to the levers.  The alien guard will throw the your friend off
him and stand up and come towards you.  As he walks under the hole in the
ceiling, pull the first lever to kill him. Now pull the second lever and crawl
into the light circle that appears on the floor.  This will teleport you to a
rooftop area and all that's left is for you to watch the closing scene...(see
below if you want to find out what happens)


************************** SPOILER!!!! ********************************

END SEQUENCE - Lester lies injures on the rooftop, a large bird/dragon sit
patiently waiting for him.  Lester painfully crawls towards it, but it looks
like the effort might be too much.  Then the alien who has helped Lester so
much appears again.  Maybe we'll never know why he wanted to help Lester a
stranger who can't even speak his language, but he did, maybe at the expense of
his own freedom.  He gently picks up Lester and places him on the Dragon.  The
Dragon takes off flying far into the distance as the words "THE END" appear on
the screen...

-----------------------------------------------------------------------
***********************************************************************
-----------------------------------------------------------------------
Feel free to email me about any aspect of this guide, any contributions you
would like to make will be fully credited if used and are more than welcome. 
Please inform me of any errors, typos etc so I can rectify them immediately
My email is falsehead@aol.com

(Blatant plug: check out my games website at www.kungfuhamster.cjb.net for
loads of info on Martial Arts, Beat 'em Ups, Kung Fu Movies and Pokemon!)

Thanks to all at www.gamefaqs.com for being such a laugh, and giving me the
push to actually start contributing my own work.

Special thanks go out to: BillyKane, Magus747, Pat Uhler, totalstuff and
Andy78787, fakeplasticmanatree, bloomer, sashanan, ASchultz, MaxH, Vegita and
everyone else on the gamefaqs review board.  Love yah all guys!

=======================================================================
***************************** THE END *********************************
=======================================================================