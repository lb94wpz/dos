Geisha Walkthrough

Do not continue reading this if you want to get through Tomahawk's GEISHA all by yourself. It took me some 15-20 hours to get right to the end. Maybe the fun is in the discovery (in fact the exact goal of this kind of game). Geisha is smaller than Leisure Suit Larry but is more fun especially since there are naked women (animated photo even), and dirty talk. GEISHA is French and it would be fabulous if I could obtain the French version.

After getting through the introduction you will come to your hotel room. First thing you do, before clicking at anything in the picture, is to save the scene into slot #1. Pick up the bottle of oil (with a click) at the lower right of the picture. Next click at the bottom drawer of the closet to open the drawer. There should be an empty box -- take it. Now choose F2 to use Hinoki oil that you have collected followed by the empty box. While the picture of the box is still on the screen, move your cusor to the base of the bonsai stem. Click it when it says "female criket". Never let the criket run away.

Now press F3 and choose "ADS". Press the right arrow button until you get to the last page of the ad, "Tsuki Pastilles", and select it. Then choose F4 "SHEERS" to enable you to go to the next scene. Save this situation over the #1 slot. Choose F1 "Mr O".

 

CHAPTER 1: SEDUCE
~~~~~~~~~~~~
Press ESC to get rid of the talkative Mr O. Pick up the cocktail and position over the back of the girl. Move the glass to and fro and it should tilt over and pour its contents on the girl's back. She should then swear at you and it so doing reveal an access pass. If this doesn't happen, then you got it wrong and have to restart slot #1. You should now have the five items in your inventory to complete the game. Even before proceeding, you should save right now into slot #2.

 

CHAPTER 2: CARESS
~~~~~~~~~~~~
This is one of the most difficult part of the game. It is a variation of MasterMind in which you will have to guess five correct numbers in their correct sequence. Talking about MasterMind, you should try to get hold of MM.EXE, MasterMind for Windows.

 

 

Concentrate on guessing the correct numbers first. Once five numbers are correctly picked, juggle the numbers around each time noting the length of movement made by the girl. The more the girl moves, the closer you are. If the girl doesn't move at all, it is really a very good sign meaning that all five numbers are in their wrong position.

It is probable that you will have to redo this caressing stage many times before you are able to proceed into the card game (The Erotic Fight) stage. Unfortunately you are unable to save before the fight.

You are given five cards and you should logically choose the trump sign of which you have the most because trump cards win any non-trumps. Know that Actors > Samurai > Empresses > Sumotori > Geisha. There is no sure way of winning but maybe you could practice when you were in the hotel room with F3 "Games". Some hints I think helped me is to place a low trump or an Actor card first to exude his trumps. If he wins this set, it is likely to be his highest card. If he loses then he doesn't have trumps. You really have the edge over him by being able to choose the trump signs.

Once you win this stage, you should save immediately into slot #3. While in the hotel room, click at the left door of the closet which should open. Double click at the advertisements and look for the species "OSTREADAE". Note the number. Press F2 and move into "At Oko".

 

CHAPTER 3: SUBMIT
~~~~~~~~~~~~
Oko will speak to you and ask you whether you have information for her. Say "Yes" and give her the number for OSTREADAE. This is so that she know the region of the sea that abounds with black pearls. There is no need to save since you already have in slot #3.

Shoot the white fishes that comes for Oko. When white sparkling pearls drift across, dive for it by continuously pressing space bars. White pearls are useless, but at random, some of these pearls are black ones. All you have to do is collect two. If you don't give Oko the zone number, then you can continue collecting pearls but never finding any black ones.

I find that a good way, while Oko is still filled with air, is to destroy any fish at level two and three while letting them swim at level one while Oko swims at two. This is because the fishes will thus never touch Oko. Becareful the if Oko's lungs are half exhausted, she will want to surface. When this happens, destroy the top level fishes

 

 

and press "E" hurry her to re-surface. Incidentally Oko is allowed to be bitten four times.

When done with this stage and back in the hotel room, save this into slot #4. Choose F3 "White Willow".

 

CHAPTER 4: UNDRESS
~~~~~~~~~~~~~
Know that SWORD > FAN > STATUS > SWORD. You pick the top batch and click the mouse to stop the spin. Everytime you win you click at her clothes. You must be able to win seven times.

When you have undressed the girl, click at her crotch to proceed to the next stage. Save this into slot #5.

 

CHAPTER 5: PENETRATION
~~~~~~~~~~~~~~~
First choose F2 and use "Access pass" and then "Tsuki Lozenge". When you press go into the maze, move right one step (with keypad arrow) and then diagonally top-right through the walls into trap door -- forget about the door on the lower left. You must shoot any of the robots that drains your energy with spacebar.

At the second level, move down some six steps and then turn right. Move right and diagonal into the next level.

At the final level, move down one step and diagnally lower-right to pick up the shield. Notice a trap door to the top-right. You get to this by moving diagonally through the wall somewhere at the kissing lips, then over the biting lips, and then into the trap door.

The next stage is the hardest. You must be very quick, and even on my 8MHz PC, it is too fast. You need all the help you can get to slow down your PC.

The object is to arrange 15 panels into a picture of a dragon. It is difficult to tell you how the picture looks like in ASCII there are some characteristics I can explain:

The dragon has a kangaroo-like body.
There are five panels without the image of a dragon -- all four panels on the left and the top right.
The bottom left of the picture has no panel
A drawing of the picture may be obtained from me. See below for order details.

 

 

CHAPTER 6: CUM
~~~~~~~~~~
Once you get into the last stage, the temple's gate, save into slot #6.

There is one thing that you should have done at the very beginning of the programme. When you first start off, you remember that there is a part where you can move your view-finder around in a room to take a snapshot with a click of the mouse. You should have moved you view-finder to the top-left where the code letter is printed.

Nevermind, if you have not done this, you can quit the game now and restart again. The code letter changes for every session of GEISHA. Before you can position the pot of bonsai on the square, you must get rid of a male cricket living in it. First use the Hinoki oil and then the box with the female cricket. While the picture of the box is still on the screen, move your cursor to the male cricket and click. The two insect will run off.

Now, bring the pot onto the square with the code that appeared in the photograph. The door will open and you will see Napadmi. You must quickly position your cursor at his crotch and click it.

The scene freezes and the clothes of his crotch uncovers. Keep clicking at all parts of his body until his clothes and mask are fully uncovered.

Thus done, you have ended the adventure and is treated to the last animated film.

 