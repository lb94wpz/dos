
Walkthrough solution for BLACK SECT by Lankhor
----------------------------------------------

Your task is to infiltrate the nefarious "Black Sect" and to find a mysterious
spellbook to restore peace to the small village of Hobsdale.


SOME GENERAL HINTS:
- download the complete manual from www.lankhor.net and get used to the controls
- click on the time display at the top right to advance time (clicking on 
  minutes advances 5 minutes, clicking on hours advances one hour, etc.)
- to interact with an object you are carrying (read, smell, etc.) select the
  object from your inventory and click on the object picture that will appear on
  the right icon bar. Click again on the object picture that appears below.
- if you drop an item from your inventory it won't be lost. It will be stored
  in the drawer icon on the right toolbar, so you can pick the item up again
  later.
- there are a few situations where you will have to wait for another character
  to make his/her appearance. Walk around a bit (into another room) if this 
  doesn't seem to work.
- you have only 3 days to solve the adventure!


THE SOLUTION:

1) THE VILLAGE
- Open the shutters of the window on the left
- Search the open window
- Take the cheese
- Take the left metal bar in the open window
- North
- East
- Search the skull (around its right eye)
- Take the ring
- West
- North
- Give the ring to the grinder
- North
- Take the dagger
- North
- Give the cheese to the tramp
- Use the bar on the 3rd paving stone to the right of the tramp
- Search the hole
- Take the gloves (which you will be wearing now)
- Search the bush to the left (where there is something moving)
- Take the small bottle
- Drop the gloves
- North
- West
- Take the coin lying on the ground
- West
- South
- South
- South
- South
- Take the bar of soap lying under the tree
- Give the soap to the washer woman
- She will give you a pin in return
- South
- Open the door to the tavern
- Enter the tavern
- Give the coin to the innkeeper
- He will give you a loaf of bread in return
- Exit the tavern
- East
- Drop the bar
- Take the coin lying on he ground
- West
- Enter the tavern
- Give the coin to the innkeeper
- He will fill your empty bottle with wine in return.
- Exit the tavern
- North
- North
- West
- Search the left opening of the trunk (2 times!!)
- Take the sieve
- Drop the dagger
- Use the sieve on the river
- Take the nugget
- Drop the sieve
- Take the dagger again
- East
- Give the nugget to the grinder
- Give the dagger to the grinder
- You will receive a sharpened dagger
- South
- South
- East
- Use the dagger on the rope
- Search the dead dwarf
- Take the score (ignore the ring)
- West
- Give the score to the musician
- He will give you a page from a missal in return
- Read the page
- Drop the page
- North
- North
- Wait until the grinder has left (click on time display to advance time)
- North
- North
- Give the bread to the tramp
- He will give you a tablet in return
- Read the tablet (2, 1, 3, 8)
- Drop the tablet

2) THE WELL
- North
- Give the wine to the priest
- He will give you the key to the chapel in return
- Open the door to the chapel
- Enter the chapel
- Take the missal
- Read the missal (1, 3, 3, 2, 1)
- Drop the missal
- Push the arm of the statue (this will drain the well) 
- Exit the chapel
- East
- Pull the crank on the well
- Climb down the well
- Turn the bars on the ladder in the order: 2, 1, 3, 8
  (1 being top, 8 being bottom)
- Search the alcove
- Take the key
- East
- Use the crank on the bell
- Drop the crank
- Use the key you found in the alcove on the lock 
- Enter the store
- Turn the right horse shoe
- Use the pin on the small hole that was hidden behind the horse shoe
- Search the alcove
- Take the crucifix
- Drop the pin
- Take the piece of paper lying in the straw
- Read the paper 
- Drop the paper
- Exit the store
- Close the door
- West
- Climb up

3) THE RENDEZVOUS
- West
- West
- Search at the bottom of the cross
- Take the key
- East
- Enter the chapel
- Look at the small cross fixed to the front of the altar
- Fix the crucifix to the small cross
- Press on the cross
- Climb down the stairs
- Search under the locker
- Take the small case
- Press the buttons on the small case in the order: 1, 3, 3, 2, 1
- Search the small case 
- Take the MOLOCH pentacle (ignore the other two pentacles)
- Drop the small case
- Use the key on the right door of the locker
- Drop the key
- Take the cassock (which you will put on automatically)
- Lock the locker
- Climb up the stairs
- Exit the chapel
- South
- South
- South
- South
- East
- Fix the pentacle to the skull
- Wait until 11.00 PM
- Talk to the disciple

4) THE PRISON
- West 
- Take the larva on the left pillar (the little white dot)
- East
- Open the door to the right
- East
- Take the tuft of digitalis on the wall to the right
- East
- Drop the larva
- Drop the tuft of digitalis
- East
- Pull the shield
- Search the alcove
- Take the parchment
- Look at the parchment (cross, circle, square, triangle)
- Drop the parchment
- Turn the candlestick
- Search the drawer
- Take the parchment 
- Read the parchment
- Drop the parchment
- Open the armour
- Search the bottom part of the armour
- Take the key
- Use the key to open the door you are facing
- Enter the prison
- Turn the middle bar in the window
- Search the alcove
- Take the parchment 
- Read the parchment
- Drop the parchment
- Search the heap of straw to the right
- Take the lighter
- Exit the prison
- Drop the key (don't close the door)

5) THE RECIPE
- East
- Use the lighter on the fireplace
- Drop the lighter
- Take the book on the table
- Read the book
- Drop the book
- Take the ring lying on the ground
- Open the long candle stick on the left
- Search the stick
- Take the parchment
- Read the parchment
- Drop the parchment
- Lift the drape on the right
- Take the key that got revealed
- West
- Take the rope
- West
- West
- Wait until you are alone in the room
- Fix the ring to the shield
- West
- Open the trunk (with the key found in the draped hall)
- Search the trunk
- Take the dagger
- Drop the key
- Close the trunk
- West
- Use the rope on the pulley at the top right
- Pull the rope
- Take the shield
- Look at the signs on the wooden beam at the top
- Pull the hams in the order: cross, circle, square, triangle
- East
- East
- Enter the library (now open)
- Look at the big opened book on the right
- Lift the green book on the bottom line of the shelf
- Take the piece of paper
- Read the recipe
- Exit the library
- East
- Drop the recipe

6) THE MASTER'S CHAMBER
- East
- Wait until you are alone in the room
- Hide yourself in the armour
- Wait until a disciple arrives, then wait until he leaves again
- Take the medaillon he left on the ground
- Enter the prison
- Take the paper from the corpse (which seems to be blank)
- Exit the prison
- East
- East
- Give the medaiilon to the disciple
  (you may have to wait until the disciple appears)
- North
- West
- Use the dagger on the cushion on the bed
- Search the cushion
- Take the bottle (which you will drink automatically)
- Take the 2nd bottle
- Use the paper from the corpse on the 2nd bottle
  (letters will appear on the paper)
- Read the paper (C, L, I, N, E)
- Drop the bottle
- Drop the paper
- Drop the dagger
- Fix the shield to the crotchet on the wall to the right
- Search below the bed
- Take the chicken's leg
- Take the sword to the left of the bed
- In front of the bed, take:
  - The pendant
  - The diamond
  - The brooch
- East
- South
- Fix the sword to the armour
- West
- Open the pavement stone, first row, 2nd one from the right
- Search the hole
- Take the black ring
- Close the hole

7) THE MEAL
- West
- West
- Drop the pendant
- Drop the diamond
- East
- Enter the prison
- Take the small dish
- Exit the prison
- West
- Take the recipe
- Give the brooch to the disciple (he will take you to the kitchen)
- In the kitchen, give to the cook:
  - The black ring
  - The recipe
  - The small dish
  - The chicken's leg
- Exit the kitchen
- West
- West
- West
- Look at the letters on the table (to the left and right of the drawer)
- Press the buttons in the order: C, L, I, N, E
- Search the drawer
- Take the box with the powder
- Close the drawer
- East
- East
- East
- Take the tuft of digitalis
- Take the larva
- Take the pendant
- Give the pendant to the disciple (he will take you to the kitchen)
- In the kitchen, give to the cook:
  - The tuft of digitalis
  - The box with the powder
  - The larva
- He will give you a meal
- Talk to the cook
- Exit the kitchen

8) THE SPELLBOOK
- East
- East
- East
- North
- Talk to the disciple (you may have to wait until the disciple appears)
- North
- Give the meal to the disciple dressed in white
- South
- Talk to the disciple
- North
- Search the disciple dressed in white
- Take the small acid bottle
- South
- South
- West
- West
- West
- Take the jug
- West
- Enter the library
- Use the bottle of acid on the lock fixed to the chest
- Open the chest
- Search the chest
- Take the amulet
- Drop the acid bottle
- Exit the library
- West
- West
- Open the sack behind the table
- Use the jug on the open sack to fill it (3 times!)
- East
- East
- East
- East
- East
- East
- Take the loose piece of stone on the left edge of the stairs
- Drop the piece of stone
- Search the spot where you have taken the stone
- Take the key
- North
- Talk to the disciple
- North
- Fix the amulet to the little hole in the right wall
- Enter the room of the spellbook
- Take the spellbook
- Fix the filled jug to the crotchet
- Use the key to open the door to the left
- West
- West
- Open the door to the tavern
- Enter the tavern
- Give the spellbook to the innkeeper

THE END!


Atari Legend 2007
