
                     Earthworm Jim Trouble Shooting
                    �������������������������������

1. - I got Sound effects but no music.

    Check if your CD-ROM is connected to either your sound card or via cable
    to your stereo or headphones.

    If your CD-ROM is connected to your sound card, check the mixer settings
    for your sound card. The CD audio level may be too low (if you got a SB16
    or AWE32 try using "sb16set.exe" or the Windows mixer).

    Under WIN95, some CD-ROM players don't play Audio tracks if you play
    directly from CD. In these cases please do a Harddisk installation.

2. - I got music but no Sound effects.

    Check your IRQ/DMA/PORT settings of your sound card. Default SB16/AWE32
    settings is: IRQ 5, DMA 1, PORT 220. Check out Your manual for the sound
    card.

    Check the mixer settings, maybe the Voice level is too low.

3. - Earthworm Jim Sound effects sounds like a broken record.

    Probably your machine is not fast enough to handle the quality settings
    you specified in SETUP.EXE. Try selecting LOW QUALITY from the menu.
    You can also try selecting plain SoundBlaster instead of SoundBlaster Pro.

4. - Earthworm Jim has an unsteady update freq. under Windows 95 / OS2 etc.

    Maybe You are running some multi-tasking programs in the background.
    Please shut them down, if possible.

    You should try to run the game from DOS mode. Shutdown the Windows 95, and
    reboot in DOS mode.

5. - Earthworm Jim jerks on my 486DX/66 MHZ

    Earthworm Jim should be running pretty smooth on anything above 486/33
    but if you have a VGA graphics card which is not fast enough you may
    experience slow-downs, Try pressing F3 once, during game.

6. - Some of my keys block other keys.

    Some keyboards are not capable of certain key-combinations, which
    means that one key you press down may block for another key. There
    is nothing to do about this except trying different keyboard settings.
    We recommend that you use a joypad for playing EWJ.

7. - My screen looks REALLY weird.

    If you own a Diamond EDGE 3D card or a Diamond Stealth 64 you might
    experience problems with the display. This is because these cards are
    not 100% compatible to standard VGA cards and NOT because of EWJ.
    We suggest you contact your card manufacturer for a solution to this
    problem.

8. - My screen flickers and glitches when I play EWJ.

    If you own an ATI graphics card with the Mach 64 chipset and dynamic RAM
    you might experience disturbing graphic glitches and flickering on the
    screen while playing EWJ. To correct this problem simply press the F1
    button once. This should eliminate the problem. The status of the F1 key
    will be saved into the configuration file so you don't have to do the
    trick again.

    In EWJ1 you will be presented with two options when you start the game
    from DOS :
    * Option 1 is the 320*224 72 Hz screen mode. This is the default mode, but
      also the mode which might cause problems.
    * Option 2 is the 320*240 60 Hz screen mode. Use this option if you
      encounter problems with the default screen mode.

    Under Windows 95 the default setting will be option 1. If you need to
    change this use the Setup95 program located on the CD and press the
    OPTIONS button when the EWJ1 Window appears.

9. - Memory

    EWJ needs 520Kb base memory and approx. 8Mb extended/expanded memory.
    16Mb is recommended especially when playing under Windows 95.
