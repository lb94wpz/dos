WHEN TWO WORLDS WAR -- ADDITIONAL DOCUMENTATION

MEMORY REQUIREMENTS

To run When Two Worlds War on your machine, you will need approximately 
###### bytes of conventional memory.

To run When Two Worlds War with Aria Speech Recognition, you will need 
approximately ###### bytes of conventional memory.

If you have your computer configured to use EXTENDED memory, When Two 
Worlds War can use approximately ONE-HALF MEGABYTE of it to speed certain 
aspects of the game's operations.

Please refer to your Technical Supplement and Tutorial booklet for more 
information on memory.


-------------------------------------------


ADDITIONS TO TECHNICAL SUPPLEMENT

A. Installing and Loading - Sound and Soundcards

   Since the Ad Lib soundcard is not designed to play digitized sound, you 
   may find the digitized speech on an Ad Lib to be unsatisfactory.  If so, 
   you can turn off speech from the SYSTEM-Sound panel.

   Additionally, if you are using your PC's internal speaker for music and 
   sound effects, and you have any problems running the game, you should try 
   running SETUP and selecting "NONE" as your sound source.


C. Communications:  Modem and Null-Modem Play

   The ESC key (which is used to abort two-player connections and game 
   transfers) will sometimes take a few seconds to respond, because of 
   the amount of processor time that modeming takes.  If you wait a 
   while and the computer still does not respond to the ESC key, wait 
   for the computer to time out normally, or restart the machine.

   In some situations, two computers may need more than one attempt 
   before they will connect.  If a connection fails, you might want to 
   try it again before you start changing your modem configuration.

   Regarding Mission Libraries -- Because of the amount of modem time 
   involved, the secondary's mission library is NOT SAVED when the primary 
   player saves a two-player game.  Therefore, the secondary player should 
   always save a mission library before quitting (using the Library commands -
   see sction 5.1.2). When the game is next loaded, the secondary player
   should immediately load his mission library.

   Even if no new missions have been designed, the secondary player should
   ALWAYS save the library. This is because a number of other pieces of data
   relating to the secondary player's game are also tacked onto the library.
   These are not contained in the primary player's save game.
   
   Regarding the Battle Statistics Panel -- In a two-player game, DO NOT use 
   the Alter Space command.


D. How to Use Aria Speech Recognition

   The Aria speech recognition system depends on you to use the same tone of 
   voice for commands.  If you find that the Aria has problems responding to 
   one of your commands, try repeating them using a different tone.

   Also, the Aria expects MU to be pronounced "mew", not "emm-you".  However, 
   you can train the vocabulary to recognize "emm-you" if you wish.


-------------------------------------------


ADDITIONS TO THE MANUAL

1.3.1. Theaters of War: Blue, Red and Space

   To clarify the manual:  Even though you cannot see the Red planet in space 
   when the game begins, your workstation knows where it is.  If you send an 
   MU on a mission that takes it to the Red planet, it will automatically home 
   in on its location in space.  Once one MU "finds" the Red planet, you will 
   be able to see it on your displays.


3. Calibration

   If you find that it takes too long to build items in the beginning of a 
   game, we suggest that you set up your scenarios to give you more than the 
   default number of facilities.  This will give you more resources with 
   which you can work.


3.1.1. Calibration - Easy Setup Panel

   There is an error in this section of the manual; each food farm can only 
   support ONE MU, not four.


3.2.7. Calibration - The Scenario Panel

   Some of the scenario descriptions shown on the SCENARIO panel are 
   inaccurate.  Refer to the BROCHURE included with the game for accurate 
   game statistics.

   Also, you should be aware that some scenario worlds use a defense system 
   called MUTUALLY-ASSURED CONFLICT.  This system assures that if either 
   player lands on the other's planet, the other can instantly attack it 
   from its squad base; it does so by locating both worlds' bases (and 
   therefore their dropzones) in the same locations on each world.  If this 
   defense system isn't to your liking, you can relocate your base without 
   cost using the ORDER SQUAD panel (see section 9.2.1.3. of the manual).


3.3. Calibration - Activate

   If you start a game by pressing the ACTIVATE button without doing anything 
   else, each world will start with one MU called a TEST CRAFT.  This type of 
   an MU has techlevel one in all ten technologies, so that you can 
   experiment with all aspects of MU control.


4.6.1.2. Main Display Map Buttons - Move to or Edit Names

   Be careful when moving base names, as they can be moved independently of 
   their bases.  Try to only edit and move unused names.


5.3. Direct Control

   There is an added feature to the Direct Pursuit command.  After an MU 
   pursues an enemy craft and destroys it, it will automatically seek out the 
   nearest enemy craft and attempt to pursue it as well.  The accuracy of 
   these pursuits is also affected by the distance between the two MU's.


8.1. Schedule

   Your world can only store in total 990 units of each resource type.


8.1.3. Schedule - Base Effort

   If you order your schedule to BUILD IN STRICT ORDER, that command will 
   supercede any base efforts you have set.  For example, if you have a squad 
   base set to build bases, it will not build a base until it reaches the #1 
   position in the schedule.  Therefore, when you select STRICT ORDER you 
   will probably want to have at least one base's effort set to ALL.


10.3.2. Command Icons and Parameters - Goto

   When you select the GOTO command icon, you MUST select a line in a mission 
   to complete the command.


13.5. Changing the Opponent I.Q.

   One thing that Opponent I.Q. will affect is research; enemies with lower 
   I.Q.'s will take longer to develop their technologies.  Smarter opponents 
   can manage their resources well enough to get research done more quickly.


14.1.1. How the System Works - MU Building Costs

   The formulas listed in the manual for building MU's are correct, except 
   for the following two amendments:

      If a design uses any level of AIR SPEED, add 10 lab-units to its cost.
      If a design uses any level of SPACE SPEED, add 15 lab-units to its cost.


14.3.1. How the System Works - Combat Between MU's

   In case this section is unclear, the terrain an MU is on affects its 
   chance TO BE HIT, not its chance to hit another MU.


14.3.2. How the System Works - Bombing Facilities

   Sea MU's are not able to BOMB facilities, because they cannot move into 
   the same map location with them; the same technology that allows 
   facilities to remain stationary in an ocean makes the water directly 
   beneath them unsafe for submarines.  Of course, you can still defend 
   facilities with subs; and sea MU's CAN attack squad bases.


-------------------------------------------


MISCELLANEOUS

This game includes a feature where the game automatically saves your war after
every month of game time to the file AUTOSAVE.SAV.  There is a button to turn
this on and off on the SAVE GAME panel accessible from the Main Display's
SYSTEM menu panel (see section 4.6.10. of the manual).

At the end of the game, you will be presented with the Overall Stats panel, 
so that you may view the results of the war.  Pressing the END button returns 
you to the Calibration screen.

Finally, if you are a fan of boardgame-like strategy games, we recommend that 
you try Turn Based mode, explained in section 13.4.2. of the manual, and move 
each unit using Direct Control (see section 5.3. of the manual).

While playing a turn based game, you may find that turns take a long time to 
be resolved when the Track MU command (section 4.6.4.2.) is turned on.  If 
so, you should turn it off.

------------------------------
This file was downloaded from 
Archivarius BBS !
Copyright (c) 1993 Impressions
END OF DOCUMENTATION.
