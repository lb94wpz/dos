                           Wing Commander Academy 
                       -----------------------------



1.        If You Still Have Trouble...
---------------------------------------

   If you call Customer Service with a problem, please have the following
   information handy:

     - A listing of your CONFIG.SYS (either from the boot disk or your hard
       drive.

     - A listing of your AUTOEXEC.BAT.

     - The information you get when you type the DOS command "mem".


   If you cannot be near your PC when calling Customer Service, please have
   print outs of this information.  Customer Service needs this information
   to properly diagnose and correct the problem you are having. 


=============================================================================

