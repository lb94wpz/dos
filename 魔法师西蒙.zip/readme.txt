           -======================================-
              Enter codes for SIMON THE SORCERER
           -======================================-

		  Translated by WhiteFalcon
        (whitefalcon.cjb.net, whitefalcon@diablo2.com)


ring      broom    purse           pentagram chest   coffin
sun         1      talon           ring       16     hat
candle   mushroom  cat             goblet    wand    purse

broom      RIP     skull           broom     hat     mortar
mortar      2      talon           purse      17     pentagram
spider   mushroom  stars           wand      ring    mushroom

candle    frog     book            bottle    inkpot  claw
figurine    3      sun             figurine   18     necklace
scroll    claw     cat             stars    stones   ring

chest     goblet   ring            RIP       skull   book
purse       4      coffin          goblet     19     ring
stick   pentagram  hat             pavouk  pentagram cat

broom     talon    claw            broom     coffin  chest
mortar      5      figurine        mortar     20     frog
spider    wand     cat             scroll    inkpot  stars

sphere    stones   hour-glass      candle    purse   ring
frog        6      sun             mortar     21     talon
mortar    inkpot   hat             wand     mushroom cat

bat      figurine  skull           cat      spider   hour-glass
frog        7      book            sceptre    22     stick
scroll    wand     stars           skull     RIP     talon

chest     stars    sceptre         wand      claw    hat
purse       8      coffin          mortar     23     stars
wand    pentagram  hat             treasure  pen     ring

broom     wand     book            bat     pentagram  bottle
figurine    9      pen             candle     24      stones
spider    claw     stars           scroll   skull     hat

cat      candle    stones          mushroom  scroll   skull
sceptre    10      scroll          purse      25      bat
book      bat      inkpot          book       RIP     spider

hat     mushroom   wand            coffin    purse    figurine
stars      11      mortar          stick      26      talon
ring   pentagram   treasure        pentagram sphere   stars

spider    sphere   purse           book       sun     wand
coffin     12      purse           hour-glass 27      cat
wand      goblet   hat             spider  pentagram  hat

skull     bottle   wand            inkpot   mortar    frog
pen        13      talon           skull      28      stars
broom     claw     stars           stones   scroll    figurine

mortar    bat      book            candle    book     figurine
pentagram  14      talon           broom      29      mushroom
wand     bottle    cat             scroll   spider    claw

skull  hour-glass  broom           bag       ring     sun
l�hev      15      hv�zdy          purse      30      inkpot
svitek    dr�p     ko�ka           cat       frog     kniha