===================================================
HERA: The Sword of Rhin. Version 1.0 release notes:
===================================================
Thanks for your interest in Hera: The Sword of Rhin.

If you wish to purchase Hera: The Sword of Rhin, send check or
money order for $19 ($15 + $4 S&H) to

Retsel Enterprises
10585 W. 23rd Place
Lakewood, CO. 80215

Make checks payable to "Retsel".

You will receive a registered version of Hera: The Sword of Rhin,
a book of play, and a player reference manual.

Please refer to the text file, (ORDER.FRM) located in your Hera directory.

Also, if you are having problems running this version of Hera
please send e-mail to jeffh@denver.net for
technical assistance.

===================
SYSTEM REQUIREMENTS
===================
Hera(TM) requires an IBM compatible 386 or better with 640k of
RAM, a VGA graphics card, and a hard disk drive. A Sound Blaster
Pro(TM) or 100% compatible sound card is recommended. Because
of the interupts Hera uses for sounds & music, it will not run
under any version of Windows(TM).

===============
GETTING STARTED
===============
1. Install Hera on to your hard drive by copying all the files into
   a directory.
2. Type Hera from the dos prompt.
3. After the startup screen, you will need to create a new character.
4. The F1 key brings up a list of the key commands.

=====
Music
=====
Hera: The Sword of Rhin has the ability to play music. To keep the
development cost down, no music files were included, but you can add
your own music files. Hera will play any standard midi files. For hera
to play midi files, they must reside in the same folder, and have the
following names. (you can have any number or combination)
heram.mid
town.mid
village.mid
ruins.mid
castle.mid
camp.mid
cove.mid
monast.mid
skull.mid

==========
Earn Money
==========
You will be paid $1 for every bug you find, and are the first to report,
in the registered version of Hera: The Sword of Rhin.
You will also be paid $3 for every copy of Hera sold with you as a
referral.

================
Apple II version
================
There is also an apple II version of Hera: The Sword of Rhin available
for the same price. $19 ($15 + $4 S&H). Just write apple II on the invoice.
It's system requirements are: 5 1/4 floppy disk drive, apple II or better,
and 64k ram.

=======
Hera II
=======
There is some consideration for a Hera II. If you would like to see this 
developed, please write and state what features you would like to see
implemented in the sequel.
