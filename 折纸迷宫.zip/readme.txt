Think paper. Think shapes. Think Origami. That's all nice an swell, but how do you play origami on a computer? Well, you actually can't, but you can enter the maze of Origamo! Think of it as a cross between Tetris and a jig-saw puzzle.

You enter the maze of far east, where you need to pass through different stages in order to finish the game. Every room (some rooms consist of more the one stage) has a guardian and to get pass, you need to solve the origami puzzle.

The puzzle itself is the main point of the game!

You get a shape with squares of different types. At the bottom is the conveyer belt, which brings forth pieces you need to place in the puzzle. You pick them up and need to fill the entire shape in order to pass. If the conveyer belt is filled up, you loose the level.

You can��t throw the pieces away, so that might represent a problem, especially if at the end you are waiting for just that one special piece that you��re missing. You can however drop them in the dump. They��ll still come out on the conveyer belt, but this way you can re-arrange them, to make some more room there.

However, if you fill out the squares with the same markings, you��ll finish the part of the shape and all the pieces on the conveyer belt will disappear. This can save you, or start making you course, if there was a piece you were saving for a special location. The game therefore does involve quite some thinking and skill.

The preferred input device is the mouse. You pick up and drop pieces with the left button, and you turn them with the right button.

A big downside is, that you don��t get to see which piece will come out next (unless you dumped it back on the conveyer belt).

You gat three shapes on every stage. Once you finish the first one you can go on through the maze, but be advised, that you��ll need certain objects (you get by solving puzzles) to advance to certain rooms.

The game also can not be saved.

These negative points and the fact that the sound is very basic, caused a great game to loose quite a lot of points, so it only gets a three instead of a high four (possibly even five).