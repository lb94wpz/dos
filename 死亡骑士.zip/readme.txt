Death Knights of Krynn Adventure Journal

Table of Contents

What Has Gone Before............................................1
Important Geographical Features of Ansalon......................2
Character and Parties...........................................2
  The Player Races..............................................2
  Ability Scores................................................4
  Character Classes.............................................5
  Alignment.....................................................8
  Other Attributes..............................................8
  Building a Successn...........................................9
  Why These Guys?...............................................10
  Preparation Tips..............................................11
Combat..........................................................11
  Combat Map....................................................11
  Initiative....................................................11
  Computer Control..............................................12
  Attacking.....................................................12
  Combat Movement...............................................14
  After Combat..................................................15
Magic...........................................................15
  Mages.........................................................15
  Clerics.......................................................16
  Knights and Paladins..........................................17
  Rangers.......................................................17
  Tips on Magic Spells..........................................17
Magical Treasures...............................................18
Spell Descriptions..............................................20
Creatures of Krynn..............................................28
Journal Entries.................................................33
Tables..........................................................52
Glossary of AD&D Game and Computer Terms........................58


WHAT HAS GONE BEFORE

One year ago, the forces of evil were united under the powerful aurak
draconian, Myrtani.  He had once again uncovered the method of
corrupting dragon eggs into draconians.  Aided by his Death Knight
ally, Sir Lebaum, he was able to seize control of central Krynn and to
field a dangerous army of draconians and undead.

As the Solamnic forces converged upon the region, a small band of
stalwart heroes uncovered Myrtani's secret plans: to suddenly generate
a huge army, and ambush the Solamnic forces.  Myrtani hoped to slay
key leaders in one swift action, and then crush the remaining,
disorganized resistance.  Magic rituals discovered in a stolen tome
would allow him to turn stolen dragon eggs into draconians en masse.
The eggs were well hidden and Solamnic scouts had missed them after
the War of the Lance.

A small band of heroes were able to slip into Myrtani's stronghold in
Kernen and slay this foul minion of the evil goddess, Takhiisis,
before the magic could be used.  Without the draconian force, the
Knights of Solamnia were able to rout the evil army and bring peace to
the region again.

You are cordially invited to attend the first anniversary of the
victory at the Battle of Kernen.  Those in attendance will include the
survivors of that battle and those granted the Special Solamnic Order
of the Champions of Krynn.

This will be both a celebration of the great victory and a
commendation of those who fell achieving it.  A special memorial will
be held for the former commander of the Gargath Outpost, Sir Karl, who
was slain defending the Oath and the Measure.  This will be held at
the parade grounds outside of the Gargath Outpose.


<IMG SRC="DKK_AJ01.GIF">
IMPORTANT GEOGRAPHIC FEATURES OF ANSALON

IMPORTANT GEOGRAPHICAL FEATURES

The major cities of the region are Kalaman and Vingaard Keep.  They
loosely administer the large number of small villages in the region.
These include the dwarven village of Turef, the gnonmish village of
Quazle and the human towns of Cerberus and Cekos.  Many wars have been
fought in this region, leaving several ruined old castles and forts.
Many have evil reputations and should be avoided.  Perhaps the most
famous of them is Dargaard Keep.  Once the home of the famous Knight
of the Rose, Lord Soth, it now lies abandoned and decayed.

CHARACTERS AND PARTIES

Individual persons called characters make up your party of
adventurers.  They can be any one of several races and have any number
of different skills.  Some will be warriors, some priests, some mages
and others may be thieves.  Each brings his own skills and talents.

The Player Races

There are seven races for player characters (PCs) in the world of
Krynn.  Each offers unique strengths and weaknesses.  For example,
humans can advance without limits in any class (profession), while
only non-humans can have more than one class at a time.  Kender have
limits to their maximum strength, while elves receive bonuses to their
dexterity.  The following sections describe the races and several
charts beginning on page 52 outline specific bonuses and limitations.

Hill Dwarves are a stubborn and rough race of sturdy workers and
craftsmen.  They are especially resistant to magic and poison.  During
combat, dwarves receive bonuses when attacking goblins or hobgoblins
and are adept at dodging the attacks of ogres and giants.  Dwarves can
be fighters, paladins, thieves, clerics of Reorx or mixed classes.

Mountain Dwarves are somewhat clannish and more refined than their
Hill Dwarf cousins, otherwise they are nearly identical. Mountain
dwarves may be fighters, paladins, thieves, clerics of Reorx or mixed
classes.

Silvanesti Elves (High Elves) are a tall, arrogant and long-lived
race.  They are nearly immune to Sleep and Charm spells and are adept
at finding hidden doors.  During combat, elves receive bonuses when
attacking with long or short swords and bows. They cannot be raised
from the dead. Silvanesti elves can be fighters, paladins, mages,
clerics, rangers and mixed classes.

Qualinesti Elves are slightly smaller and friendlier than their
Silvanesti brethren, but they have identical abilities and bonuses.
Qualinesti elves can be fighters, rangers, mages, thieves, clerics and
mixed classes.

Half-Elves are hybrids, with many of the virtues of both humans and
elves.  They are resistant to Sleep and Charm spells and are adept at
finding hidden doors. Half-elves can be fighters, knights, paladins,
mages, clerics, thieves, rangers and mixed classes.

Kender are a small people characterized by an absolute lack of fear
and an insatiable curiosity. They are especially resistant to magic
and poison and have the special ability to taunt intelligent
opponents. When kender successfully taunt, an opponent will attack in
a mindless rage, suffering a loss of combat effectiveness. The
preferred weapon of the kender is the hoopak, part staff sling part
metal shod staff, which only they can use.  Kender receive bonuses to
hit with hoopaks and are deadly accurate shots.  They can be thieves,
fighters, rangers, clerics or mixed classes.

Humans are the most common player-race in the world of Krynn. They can
be fighters, mages, clerics, thieves, paladins, rangers and Knights
but not mixed classes. Only humans and half-elves can be Knights.


Ability Scores
Every character has six randomly generated ability scores as explained
below. These scores fall within a range determined by the race and
class of the character. The basic values range from 3 (low) to 18
(high) and there are charts of limitations, modifiers and bonuses.

Depending on the character class, one or more of these abilities will
be a prime requisite. A prime requisite is an ability especially
valuable to a given class. For example, strength is key for fighters
and wisdom for clerics. Most characters receive bonus experience
points when their prime requisite scores are 16 or greater.

Non-human characters may receive modifiers to the basic ability scores
to reflect differences between the races. Dwarves for instance, get a
+ 1 constitution bonus and may have a maximum constitution of 19
instead Of 18.  When a character is generated with the CREATE NEW
CHARACTER command, all racial modifiers are calculated automatically.

Strength (STR) is the measure of a character's physical power, muscle
mass and stamina. Fighter-type characters may have exceptional
strengths greater than 18 which are indicated by a percent value (01,
02, 03 . . . 98, 99, 00) following the base strength. High strength
increases a character's combat ability with melee weapons. Strength
also determines how much a character can carry without becoming
encumbered and slowed in combat.

"...finding ourselves low on supplies, we stopped in the local store,
where we found all manner of useful weapons to keep us going..."

Intelligence (INT) is the measure of how well a character can learn.
Intelligence can limit how far mage characters can advance and what
levels of spells they can cast.

Wisdom (WIS) is the measure of a character's ability to understand the
ways of the world and to interact with the world. Clerics receive
bonus spells for high wisdom and it may limit what level spells they
can cast.

Dexterity (DEX) is the measure of a character's manual dexterity and
agility. Thieves especially benefit from high dexterity. Dexterity
affects how well a character can use ranged weapons (bows, dart,
etc.), when he moves in a combat round and how difficult he is to hit
in combat.

Constitution (CON) is the measure of a character's overall health.
Fighters receive one extra hit point per hit die for each point of
constitution above 14. Non-fighters receive similar benefits except
they receive a maximum of two extra hit points per level (no benefits
for constitutions above 16).

"...we heard soft footsteps followed by a low, ominous growl.
Suddenly, the weretiger rounded the corner, running full speed.  We
brandished our weapons, but it was too late.."

These bonuses are only given until characters reach about 10th-level
(depending on class). A character's constitution also determines the
maximum number of times that character can be raised from the dead and
the chance of a resurrection attempt being successful. Every time a
character is successfully resurrected, he loses 1 point of
constitution.

Charisma (CHA) is the measure of how others react to a character.
Charisma is sometimes a factor when encountering NPCs�the higher a
character's charisma, the more that character can persuade others to
do what he wants.  The character with the highest charisma should be
the active character when dealing with NPCs.

Character Classes
A character must belong to at least one character class. Non-human
characters can have more than one class at the same time. A non-human
character with multiple classes has more playing options, but he
increases in level more slowly because his experience points are
divided evenly among all his classes.

Characters receive HP, spells and abilities based on their class,
level and (sometimes) ability scores. Refer to the tables at the back
of the journal to find the number and size of hit dice a character
receives and the number of spells the character can memorize.

Note:  Dice is the term used to describe the range for a randomly
generated number. A d6 die has a range from 1 through 6, a d10 has a
range from 1 through 10.

Clerics have spells bestowed on them by their deities and can fight
wearing armor and using crushing (not edged or pointed) weapons. After
selecting a deity, clerics may only choose alignments appropriate to
their deity. Each of the deities extends special abilities to his
followers. For more information, see the Deities section.

Clerics have the ability to sometimes turn away or even destroy undead
creatures such as skeletons or zombies. This power increases as the
cleric increases in level. The prime requisite for clerics is wisdom.

Fighters can fight with any armor or weapons, but they cannot cast
magic spells. Fighters can have exceptional strength and gain
additional HP bonuses if they have a Constitution of 17+. The prime
requisite for fighters is strength.

Mages have powerful spells, but can use no armor and few weapons. They
can only memorize those spells available in their magical spell books
or use scrolls. In the world of Krynn, the power of mages is moderated
by the three moons and mages are divided into three orders based on
alignment. A mage's power fluctuates with the cycles of the moon that
influences his order. For more information on the orders and moons see
the Magic section. The prime requisite for mages is intelligence.

Paladins can fight with any armor or weapons, are totally immune to
disease and can cast a few clerical spells once they reach
ninth-level. Paladins can have exceptional strength and gain
additional HP bonuses as fighters. They are somewhat resistant to
spells and poison.

Because of their special nature, certain magical abilities are
conferred on them by deities. They can turn undead creatures as if
they were a cleric two levels below their current level and are always
surrounded by the equivalent of a Protection from Evil 10' Radius
spell. Once a day paladins may heal two HP of damage per their level.
They can also Cure Disease once a week at 1st - 5th levels, twice a
week at 6th to 10th and three times a week at 11th to 14th level. At
ninth-level, paladins gain the ability to cast clerical spells, but
they cannot use clerical scrolls.

Paladins must be of lawful good alignment and have ability scores of
at least 9 in intelligence and constitution, at least 12 in strength,
at least 13 in wisdom and at least 17 in charisma. The prime
requisites for paladins are strength and wisdom.

Rangers can fight with any armor or weapons. Rangers can have
exceptional strength and gain additional HP bonuses as fighters. They
do additional damage in combat when fighting giant-class creatures. No
more than three rangers can join one party.

Rangers are very in tune with nature and gain the ability to cast
druidic spells when they reach eighth-level. At ninth-level they gain
the ability to cast mage spells. Rangers can never use scrolls of any
type.

Rangers must be of good alignment and have ability scores of at least
13 in strength and intelligence and at least 14 in wisdom and
constitution. The prime requisites for rangers are strength,
intelligence and wisdom.

Solamnic Knights are the pride of chivalric honor in the world of
Krynn. The knights are divided into three orders: the Knights of the
Crown, the Knights of the Sword and the prestigious Knights of the
Rose. All are renowned for their bravery and skill at arms. Knights
begin the game with Solamnic Plate Mail, long sword +l and a shield.

Knights are valuable for their leadership ability in combat. Whenever
a party with a Knight enters combat, he makes a leadership check. If
the check is successful, all NPCs in the party come under your control
like regular PCs. Chances of success increase dramatically as a Knight
rises through the three orders.

Knights must take a vow of poverty and so they tithe a large part of
their monies and treasures back to the orders. Knights of the Crown
will tithe 10 percent to their order whenever they enter an outpost.
Knights of the Sword and Rose will give up everything except 20 steel
pieces when they tithe.  When Knights of the Sword or the Rose become
sixth-level, they gain the ability to cast some clerical spells.

If a Knight of either of the first two orders (Crown or Sword) is of
sufficient level and has high enough ability scores, he may petition
the next higher order for admission.

Note:  Knights receive experience bonuses for doing knightly deeds and
not for meeting prime requisites minimums.

To join the Knights of the Sword a knight must have the following
minimum ability scores: STR 12, INT 9, WIS 13, DEX 9, CON 10.

To join the Knights of the Rose a knight must have the following
minimum ability scores: STR 15, INT 10, WIS 13, DEX 12, CON 15.

Thieves can fight with swords, short bows and slings and wear leather
armor.  In combat they do additional damage 'back stabbing', which is
described in the Combat section. Thieves also have special skills for
opening locks and removing traps. The prime requisite for thieves is
dexterity.

Multi-class are non-human characters who belong to two or more classes
at the same time. The character's experience points are divided among
each of the classes, even after the character can no longer advance in
one or more of those classes. The character's hit points per level are
averaged among the classes. The multi-class character gains all the
benefits of all classes with regard to weapons and equipment.


ALIGNMENT

Alignment is the philosophy a character lives by and can affect how
NPCs and some magic items in the game react to the character.  The
following alignments are available to Player Characters.

Lawful Good characters believe in the rule of law for the good of all.

Lawful Neutral characters believe the rule of law is more important
than any objective good or evil outcome.

Neutral Good characters believe that the triumph of good is more
important than the rule of either law or chaos.

True Neutral characters believe that there must be a balance between
good and evil and law and chaos.

Chaotic Good characters believe in creating good outcomes unfettered
by the rule of law.

Chaotic Neutral characters believe that the freedom to act is more
important than any objective good or evil outcome.

Note: Due to the nature of this adventure, no evil Player Characters
are permitted.

OTHER ATTRIBUTES

Each character also has three other important values that change as
the game goes on: Hit Points, Experience Points and Levels.

Hit Points (HP) represent the amount of damage a character can take
before he goes unconscious.  To calculate a character's maximum HP,
the computer rolls the character's hit dice and adds any adjustments
for level or constitution.  A character gains a HP bonus to each it
die if his constitution is over 14.  When a character takes enough
damage that his HP reach 0, he is unconscious.  If the character's HP
drop to anything from -1 to -9, he will lose 1 HP per turn from
bleeding until he is bandaged or dies.  A character is dead if he has
-10 HP or less.  When you view a character, his HP on the screen will
never be displayed as less than 0.

Experience Points are a measure of what the character has learned on
his adventures.  Characters receive experience points for actions such
as fighting monsters, finding treasures and successfully completing
quests.  The computer keeps track of experience and when characters
earn enough they may advance in levels.  See the Level Advancement
Tables for each class's experience requirements.

"...the door was open, so I walked in.  There before me stood a high
priest, his robe tattered from years of weathering.  'I've been
expecting you,' he said in a deep voice..."

Levels are a measure of how much a character has learned in his class.
Characters can go to a hall and receive the training required to
increase in level when they have enough experience.  Characters may
only advance one level at a time.  If a character has gained enough
experience to go up two or more levels since the last time he has
trained, he will go up one level and lose all experience in excess of
one point below the next level.

Example:
An 11th level thief enters a training hall with 667,543 experience
points (enough for 13th-level).  He will leave as a 12th-level their
with 660,000 experience points -- one point below the 13th-level.
Once characters have reached their maximum levels for this game, they
cannot train.

New characters start with 210,003 experience points and they will
already have all levels and spells appropriate for that experience.
Characters may advance to a maximum of 14th-level, except thieves who
may advance to 18th-level.

BUILDING A SUCCESSFUL PARTY

Forming a strong and adaptable party is a key to success in Champions
of Krynn.  You may place up to six Player Characters in your party.
It is recommended that you use all six characters.  A smaller party is
less powerful and more likely to be eliminated by your enemies.

In choosing which characters to include in the party, it is wise to
include a variety of classes: clerics, mages, thieves, and fighters.
At least one party member should be a kender, so you may taunt (yell)
in combat.  Some adventures may only be completed if the party
includes a Knight.

Sample party
One Human Knight
One Human Paladin
One Swarf Ranger
One Kender Cleric of Mishakal/Thief
One Qualinesti Elf Clerif of Shinare/Fighter/Red Mage
One Silvanesti Cleric of Majere/Fighter/White Mage


Sample party #2:
One Human Knight
One Silvanesti Elf Cleric of Mishakal/fighter/
White Mage
One Half-Elf Ranger/Cleric of Majere
One Qualinesti Elf Cleric of Shinare/Fighter/
Red Mage
One Kender Cleric of Kiri-Jolith/Thief
One Qualinesti Elf fighter/Red Mage

WHY THESE GUYS?

Cleric/fighter/mages are the ultimate multi-purpose character.  A
cleric/fighter/mage can cast both mage and cleric spells while
wielding the armor and weapons of a fighter.  The main disadvantage of
the cleric/fighter/mage is that, as a triple-class character, he
advances in levels quite slowly.

Fighter/mages may cast spells while wearing armor.  This split class
can fight as well as a fighter and receives more HP than a pure mage.

Cleric/thieves have more HP and a better armor class than pure
thieves.  As a cleric, the cleric/thief can cast healing and support
spells, allowing the character to perform double duty as both the
party thief and additional healer.  The thief status permits the
powerful back stab attack which is described the Combat section.

Clerics are essential for healing the party after engagements.  The
most efficient way to heal is to Encamp and select FIX (you can issue
this command several times while encamped).  FIX works as follows:

If a cleric is in the party, all available cure spells are cast and
automatically rememorized, until all characters are healed.  If the
party has taken more damage than clerics have cure spells, the FIX
option may be used again.  When FIX is used, characters at the tope of
the list will be healed before the characters below them.  If a cleric
is not in the party, HP may be recovered through rest (1 HP per 24
hour period), potions of Temple services.

Rangers normally start the game with more HP than other fighter types.
They do extra damage versus giant type monsters and receive mage and
druidic spells at high level.

Knights are powerful fighters and there are some items that may only
be used by them.  Knights have special leadership abilities and gain
clerical spells at high levels.

Paladins are great warriors.  In addition to their martial prowess,
they have natural protection from evil, healing powers and they gain
clerical spells.


PREPARATION TIPS

The makeup of your party affects your combat strategy throughout the
game.  Loading your party with clerics and mages increases the
importance of spell casting both before and during a battle.  An
emphasis on fighters, Knights, paladins or rangers makes your hand-to
hand combat skills that much more important.

Ready the melee weapons (swords, maces, quarter staffs) at the start
of the game instead of the missile weapons (bows, slings, darts).  Be
sure to keep arrows ready too.

COMBAT

Adventures must battle their way through many dangerous foes to
complete the mission.  Tale's of bravery and heroes ring with the
sounds of combat.  The following sections offer some more information
and tips for combat.

COMBAT MAP

Battle takes place on a tactical combat map that is a more detailed
view of the map terrain (3D or overland) that the party was on when
the combat began.  This map is set up with an invisible square grid
and you will notice that everything moves on the grid from square to
square.  Moving diagonally often costs more movement points than
moving horizontally or vertically.

INITIATIVE

Each round of combat is divided into 10 segments.  Every character and
foe acts on a specific segment based on a random number.  The random
segment number is generated at the start of each combat round and is
modified by dexterity and random factors such as surprise.  In most
cases a character will move and/or aim an attack during his segment.
Casting spells may take extra segments to perform, so often a
spell-caster will begin his spell on his segment and have it go off a
few segments later.

Sometimes a character will act in segment 10 of one round and segment
1 in the next, appearing to act twice in a row.  This is especially
common if you use the DELAY command.  When the DELAY command is given,
that character's action is always delayed until segment 10.


COMPUTER CONTROL

In combat, the player controls the actions of PCs.  The computer
controls the actions of monsters, NPCs and PCs set to computer control
with the QUICK command.  If you have a Knight in your party, he may
take control of NPCs at the start of combat by making a successful
leadership check.  A successful leadership check puts NPCs under
normal control for that combat.

COMBAT ABILITY

Each character's ability in combat is defined by his AC, THAC0 and
damage.

AC
A character or monster's difficulty to be hit is represented by his
armor class or AC.  The lower the AC, the harder it is to hit the
target.  AC is based on armor and a dexterity bonus.  Some magic items
also help a character's AC.

THAC0
The character's THAC0 represents his ability to hit enemies in melee
or with missile fire.  THAC0 stands for To Hit Armor Class 0.  This is
the number a character must "roll" equal to or greater than to do
damage on a target with an ACT of 0.  The lower the THAC0, the better
the chance to hit the target.

Note: the generation of a random number is often referred to as a
"roll".  In determining if an attack hit, the number generated is from
1 through 20.

An attack is successful if the random number is greater than or equal
to the attacker's THAC0 minus the target's AC.  THAC0 may be modified
by range, attacking from the rear, magic weapons and magic spells
among other things.

Example:
A fighter with a THAC0 of 15 attacking a monster with an AC of 3 would
need to roll: (THAC0 15) - (AC 3) = 12+
But to hit a monster with an AC of -2 he would need to roll: (THAC0
15) - (AC -2) = 17+

Damage
When a hit is scored, the attacker does damage.  Damage is the range
of HP loss the attacker inflicts when he hits an opponent in combat
and it depends on the attacker's strength and weapon type.  The damage
each weapon can do is summarized in the Weapon Table on page 53.

Some monsters take only partial or no damage from certain weapon
types.  Skeletons, for example, take only half damage from sharp or
edged weapons, while some other monsters only take damage from magical
weapons.

ATTACKING

Characters generally engage in melee combat, which is face-to-face
fighting with weapons such as swords and maces.  Characters also have
other options, such as ranged combat, with bows and slings, and rear
attacks on engaged foes.  Different options and restrictions apply to
each.

"...the wight attacked with such speed and ferocity that some life
essence was drained from three of our party before we could defeat
it.."

Ranged Weapons
A character with a missile weapon (bow, sling, etc.) may not attack
when adjacent to an enemy.  The exception to this is the kender
hoopak.  Kender may attack adjacent targets with the metal shod end of
their hoopaks or use it as a ranged weapon.

Bows can be used twice per turn.  Three darts can be thrown per turn.

Multiple Attacks
After Seventh level (eighth for rangers), all fighter-type characters
increase the number of attacks they make with melee weapons.  The
first increase is three attacks every two rounds, then two attacks
every round.  See the Bonus Attacks for High Level Fighters table on
page 52.

All of a character's attacks are taken against his first target.  If
the first target goes down with the first attack, he can aim the
remaining attack at another target.  Fighter-types may also sweep
through several weak opponents in one combat round.  When a character
sweeps, he automatically attacks all of the weak opponents.

Back Stabbing
A thief back stabs if he attacks a target from exactly opposite the
first character to attack the target.  The thief may not back stab if
he has readied armor heavier than leather.  A back stab has a better
chance of hitting the defender and does additional damage.

COMBAT STRATEGIES

To succeed in combat, a skilled player deploys his party well, casts
effective spells before and during combat maneuvers his characters
into advantageous positions and attacks using his most powerful
characters and weapons.

Deploying the Party
When a battle begins, your party is automatically positioned based on
the order list of the characters.  Characters near the tope of the
order will be in the front lines and vulnerable to attack.  To change
the starting deployment, change the order from the Alter menu while
encamped.  Shift the heavily-armored fighters up the list and the
vulnerable mages and thieves towards the bottom of the list.  Party
order cannot be changed while in combat, although they are free to
move.

When battle begins, your party may be placed in a bad position.  If
you wish to be defensive move your characters to anchor your flanks on
an obstacle such as a wall or tree.  Setting up behind a doorway that
your enemies have to move through makes for a very strong defensive
position.  Also, keep mages safe behind the front line.

Wounded Characters
Characters who are seriously injured should be moved out of the front
lines if possible.  Remember: if you move away from an adjacent enemy,
he gets a free attack at your back.  Back attacks have an improved
chance to hit.

Stopping Ranged Attacks
Missile weapons cannot be fired if there is an adjacent opponent.  If
you want to fire missiles, make sure you keep away from the enemy.
Hoopaks are the only exception, as they may be used either as a
missile weapon or a melee weapon. to stop enemy missile fire, move
someone next to the opponent.

Exploiting Enemies' Weaknesses
Exploit your opponents' weaknesses by directing attacks against
helpless, wounded or isolated foes.  Concentrate your attacks to
eliminate one opponent rather than injury many (Exception: enemy spell
casters).  A foe with one hit point remaining attacks as powerfully as
an uninjured one.

Spell casters cannot fire spells after they have taken damage in a
round and they will lose any spells they are in the process of casting
when they are hit.  Try to keep enemy spell casters under attack every
round while protecting your own.

COMBAT MOVEMENT

The number of squares a character can move is affected by the weight
he's carrying, his strength and the kind of armor he has readied.  A
character's movement range is displayed on the view screen and when
moving during combat.

Running Away
A character may flee from the battlefield if he can move faster than
all enemies, but not if he moves slower than any enemies.  A character
has a 50% chance to move off the battlefield if he can move as fast as
the fastest enemy monster.  Exception: if a monster or character can
reach the edge of the combat map without any of his opponents being
able to see him, he may then flee successfully even though he is
slower than his opponents.

Returning to the Party
A character that moves off the battlefield returns to the party after
the first is over.  If all active characters flee combat, any dead or
unconscious characters are lost.  If a whole party flees, it will not
receive any experience points for monsters killed before retreating.

AFTER COMBAT

If one or more characters survive on the battlefield at the end of
combat, the bodies of unconscious or dead party members stay with the
party.  If the entire party flees from combat, all unconscious and
dead party members are permanently lost.  If ALL the party members are
slain, go back to your last Saved Game and try again from that point.

MAGIC

Magic is integral to DEATH KNIGHTS OF KRYNN.  Mages and clerics, as
well as high-level Knights, rangers and paladins can cast spells.  A
spell can exist in one of four forms: in a character's memory, in a
character's spell book, in a scroll or in a wand.  A spell-caster with
a memorized spell can cast it using the CAST command.  Spells are
memorized during rest while encamped.

Memorizing a spell takes 15 minutes of game time per spell level, plus
a minimum period of preparation of four hours, plus two hours every
two spell levels.  For example, first and second level spells take a
minimum preparation of four hours, while third and fourth level spells
take six hours.

Example:
To memorize (2) first-level spells, (1) second-level spell and (1)
third-level spell would take: (6 hours preparation) + (2 * 15 min) +
(1 *30 min) + (1 * 45 min) = 7 hours 45min

Spells do not automatically have their full effect on their target.
Each target of a spell may get a saving throw to avoid some or all of
the effect of the spell.  As a character gains levels, his saving
throws improve.

Note: some monsters have magic resistance which decreases the chance
of them being affected by spells.

Mages
There are two orders of mages you can play--White Robes and Red Robes.
All good alignment mages are White Robes and all neutral alignment
mages are Red Robes.

Evil mages are of the Black Robe order.  The few mages in the world
who do not enter an order are called "Rogues," and are attacked on
sight by all of the other orders.  Mages keep spell information in
their personal spell books and may only memorize spells that re
recorded there.

When a mage trains for a new level, he selects a new spell to scribe
into his spell book.  A mage can also scribe spells from identified
scrolls if he is of high enough level to cast them and they are the
correct type for his order.  Red Robe mages may only use or scribe Red
Robe scrolls and White Robe mages may only use or scribe White Robe
scrolls.  A mage must cast the Read Magic spell in order to identify
the spells on the scroll.  A spell disappears after it has been
scribed or cast.

The Moons of Krynn
Since the creation of the world, three moons have governed the powers
of magi in Krynn.  As the moons wax and wane, so do the powers of
magic aligned to them.  Each moon has a different cycle and affects a
different group of mages.  Mages of the White Robes gain their power
from Solinari the white moon, Mages of the Red Robes are governed by
Lunitari the red moon.  The evil Mages of the Black Robes are
empowered by the dark moon Nuitari.  The current position of the moons
is displayed at the tope of your computer screen and their effect are
as follows:

<IMG SRC="DKK_AJ10.GIF">
THE MOONS OF KRYNN

Spheres of Magic
The magic of Krynn operates in spheres, with the different schools of
mages only able to manipulate certain of them; spells castable by one
order may not necessarily be cast by another.  The spell Parametes
Table on page 55 and the Spell Descriptions beginning on page 20
detail which mage orders can cast each spell.

CLERICS
Clerical magic requires no spell books.  All clerical spells of the
appropriate level are always available to a cleric, the character need
only memorize them.  Unlike mages, clerics can cast spells from
scrolls without any preparation.

Deities
Since the earliest days of Krynn, the wisdom of the deities has been
brought to all the races through the efforts of the clerics, the
mortal messengers of the will of the heavens.  As a sign of favor,
deities bestow upon their clerics special bonuses or additional
spells.  The following is a list of the deities of Krynn that are
available to characters, their alignment and clerical bonuses:

"...after night fell, I set up camp and was warming myself by the fire
when I heard it.  It seemed to come from all around..."

Good Aligned Deities:

Paladine
Powers: None
Extra Spells: Protection from evil 10' radius

Majere
Powers: Turn undead as if cleric is two levels higher
Extra Spells: Silence 15' radius

Kiri-Jolith
Powers: +1 THAC0
Extra Spells: Detect Magic

Mishakal
Powers: +1 die on all healing spells
Extra Spells: Charm Person, Remove Curese, Bless

Neutral Aligned Deities:

Sirrion
Powers: None
Extra spells: Burning Hands

Reorx*
Powers: +1 THAC0 (dwarves only)
Extra spells:

Shinare
Powers: None
Extra Spells: Charm Person

* All dwarven clerics must select Reorx and therefore be neutral.

KNIGHTS AND PALADINS
Knights and Paladins use their clerical spells identically to clerics,
except that they can never use clerical scrolls, even if they may cast
the spells.

RANGERS
Rangers use mage and druidic spells.  They us mage spells identically
to mages and the druidic spells as clerics use their magic.  Rangers
can never cast spells from scrolls, even if they can memorize and cast
the scroll spell normally.

TIPS ON MAGIC SPELLS
Both clerics and mages may cast spells which assist the party in
combat.  Preparatory spells cast just before a battle can protect and
strengthen characters.  Spells can be cast to damage foes during
combat or to protect or heal comrades.

Spells should be rememorized as soon as possible after they are used.
This is most likely to happen after combat.  When in camp, have your
spell-caster memorize spells and select REST to allow them to imprint
the spells for later use.  Selecting REST without choosing new spells
has the spell-casters rememorize the spells they have cast since last
resting.

Note: Before resting, it is a good idea to save your game.  We
recommend that you save your game after every tough combat and that
you keep at least two separate saved games at all times and alternate
between them.  This will allow you to go back to a save before that
fatal battle.

MAGICAL TREASURES

As you travel about and encounter the monsters and puzzles that stand
between you and finishing your various quests, you will also find
magical items to help you on your way.  Here are some descriptions of
items that you may find.  Not all of these items may be found in your
adventure.  You can find out if there is a magic item in a treasure by
doing a Detect Magic spell using the DETECT command.  To find out
specifically what an item is, you must take it to a shop and have it
identified.

Some magic items are in reality cursed and can do great harm.  When a
character readies a cursed item, a Remove Curse spell must be cast
before the item can be dropped.  Some magic items may only be used by
certain classes.  Others may not work at all if certain other magic
items are also in use.  You must select the READY command from the
Items Menus to prepare items for use.  Items such as armor, weapons or
adornments are simply readied and you gain their benefit
automatically.  Items like scrolls or potions must be readied before
they can be used.

Wands
Wands are the traditional objects of enchantment.  Wands generally
will cast a set number of a given spell (Fireball or Ice Storm for
instance).  Only experimentation or paying to have them identified
will tell what a wand does.  Generally wands can only be used by
mages, although a few can be used by other classes.

Potions
Potions are the most common sort of magical treasure.  Potions may
heal wounded characters, cause them to become hastened or invisible or
cause any number of other effects.

Scrolls
Scrolls can be either for clerics or one of the mage orders.  They
offer new spells for mages to scribe into their books, spells of a
higher level than the spell-casters can normally cast and extra spells
for emergencies.  A mage may use SCRIBE to transfer a scroll into his
spell book.  Mages and clerics can cast spells directly from scrolls
with the USE command.

Enchanted Armor and Shields
Sometimes you may run across armor or shields that have been created
by skilled craftsmen and then enchanted by mages to imbue them with
protective spells.  The power of the magic on these items may vary a
great deal.  Enchanted armor has the great advantage of offering
improved protection with less encumbrance than the same type of
mundane armor.

Solamnic Plate
These suits of plate mail were originally crafted for some of the
Knights of Solamnia. The armor is of exceptionally high quality and is
very ornate.  Only Knights may use Solamnic Plate.

Enchanted Weapons
Enchanted weapons come in many sizes an shapes and potencies.
Sometimes a weapon will add to your THAC0 and damage.  Other weapons
may have other magical properties including extra bonuses again
specific types of creatures.  Once a magic weapon has been readied
from the Items Menu, the character will have it for all combats.

Enchanted Adornments
Bracers, necklaces, periapts and especially rings are favorite objects
for magical enchantment.  These items may have any number of magical
properties.  Some items will help your AC, others may fire Magic
Missiles or be cursed.  Once one of these items has been readied from
the Items Menus, a character will automatically gain all effects.  The
exception to this rule is that certain magical necklaces require the
USE command to work.

Dragonlances
These powerful enchanted weapons were created for the War of the
Lance, to combat the evil dragons.  They have large bonuses against
any foe, but are deadly when attacking dragons, where they do the
wielder's hit points in damage to the beast.

Enchanted Clothing
Wizards will sometimes cast enchantments on commonplace items of
clothing such as gauntlets or cloaks.  A wide variety of these items
are known to exist.


SPELL DESCRIPTIONS

First Level Clerical Spells
Bless improves the THAC0 of friendly characters by 1.  The bless spell
does not affect characters who are adjacent to monsters when the spell
is cast.  This is a good spell to cast before going into combat.

Cure Light Wounds heals 1-8 HP (up to the target's normal maximum HP).

Detect Magic indicates which equipment or treasure is magical.  View a
character's items or Take treasure items.  Equipment or treasure
preceded by an '*' or a '+' is magical.

Protection from Evil improves the AC and saving throws of the target
by 2 against evil attackers.

Resist Cold halves the damage and improves throws vs. cold attacks by
3

Second Level Clerical Spells
Find Traps indicates the presence of traps in the character's path

Hold Person may paralyze targets of character type (Human, etc.),
goblin or hobgoblin.  You may aim a hold person spell at up to 3
targets.

Resist Fire halves the damage and improves saving throws vs. first
attacks by 3.

Silence 15' Radius must be cast on a character or a monster.  That
character or monster and all adjacent to him, cannot cast spells for
the duration of the spell.

Slow Poison revives a poisoned person for the duration of the spell.

Snake Charm paralyzes as many HP of snakes as the cleric has HP.

Spiritual Hammer creates a temporary magic hammer.  It can strike at
range and does normal hammer damage plus one point for every three
levels the caster has attained.  The hammer appears in the clerics
equipment list and must be readied as any other weapon.  The hammer
will re-conjure itself on the cleric's person if it is thrown.

Third Level Clerical Spells
Cure Blindness removes the effect of the Cause Blindness or Power
Word, Blind spells.

Cure Disease removes the effects of disease caused by some monsters or
by a Cause Disease spell.

Dispel Magic removes the effects of spells that do not have specific
counter spells.  This is recuperation spell for any of the party that
has been held, slowed or made nauseous.

Prayer improves the THAC0 and saving throws of friendly characters by
one and reduces the THAC0 and saving throw of monsters by one.  This
is a good spell to cast before going into combat.

Remove Curse removes the effects of a Bestow Curse spell and allows
the target to unready cursed magic items.

Fourth Level Clerical Spells
Cures Serious Wounds heals 3-17 HP (up to the target's normal maximum
HP).

Neutralize Poison counteracts all toxins and revives a poisoned
person.

Protection from Evil 10' Radius must be cast on a character or a
monster.  It improves the AC and saving throws of the target and all
adjacent friendly characters by two against evil attackers.

Sticks to Snakes causes snakes to harass the target.  The target is
unable to attack or cast spells for the duration of the spell.  Large
creatures may ignore the created snakes.

Fifth Level Clerical Spells
Cure Critical Wounds heals 6-27 HP (up to the target's normal maximum
HP).

Dispel Evil improves the target's AC by seven versus summoned evil
creatures for the duration of the spell or until the target hits a
summoned creature.  The creature must make a saving throw when it is
hit or be dispelled.

Raise Dead can bring back to life one non-elf character.  The chances
for success are based on the target's constitution.  The raised
character returns to life with one hit point.

Sixth Level Clerical Spells
Heal cures all diseases, blindness, feeblemindedness and restores all
except one to four of a character's full hit points.

Seventh Level Clerical Spells
Restoration returns experience levels to characters who have suffered
the draining attacks of undead monsters such as wights.

Resurrection is similar to the Raise Dead spell, except that the
resurrected character has full hit points returned.

First Level Druid Spells
Detect Magic indicates which equipment or treasure is magical.  View a
character's items or take treasure items.  Equipment or treasure
preceded by an '*' or a '+' is magical.

Entangle will cause plants in the area of effect to grow and entwine
around the feet of any creature in the area.  Be careful not to catch
allies in the spell area.  Entangle only works outdoors.

Faerie Fire will ring a targeted creature in magical light.  This
spell will outline otherwise invisible creatures and give a +2 THAC0
bonus to anyone attacking an affected creature.

Invisibility to Animals will make the target invisible to nonmagical,
low or non-intelligent animals.  This spell does not offer protection
against intelligent opponents or magical creatures.

Second Level Druid Spells
Barkskin causes the target's skin to become tougher and harder to
damage.  The effect of this spell is a -1 bonus to AC.  This is a good
spell to cast before combat.

Charm Person or Mammal changes the target's allegiance in a combat.
It affects character types (human, etc.) and other mammals.

Cure Light Wounds heals 1-8 hitpoints (up to the target's normal
maximum hitpoints).

First Level Mage Spells
Burning Hands causes one HP of fire damage per level of the caster.
There is no saving throw.  Usable by both Red and White Robes.

Charm Person changes the target's allegiance in a combat.  It only
affects character types (human, etc.), goblins or hobgobins.  Usable
by both Red and White Robes.

"...long after my encounter with the dread wolf, I had nightmares of
its evil face snarling at me from out of the darkness..."

Detect Magic indicates which equipment or treasure is magical.  View a
character's items or Take treasure items.  Equipment or treasure
preceded by an '*' or a '+' are magical.  Usable by both Red and White
Robes.

Enlarge makes the target larger and stronger.  The higher the caster's
level, the larger and stronger the target gets.  If the caster is
sixth-level or greater, the target becomes as strong as an Ogre.  If
the caster is 10th-level or greater, the target becomes as strong as a
Fire Giant.  A target can only be under the effect of one enlarge
spell at a time.  Unwilling targets get a saving throw against this
effect.  The spell will stay in effect for more than one combat and
should be cast before combat.  Usable by both Red and White Robes.

Friends raises the caster's charisma 2-8 points.  It is often cast
just before an encounter.  Usable by both Red and White Robes.

Magic Missile does 2-5 HP per missile with no saving throw.  A mage
throws one missile at first-second level, two missiles at third-fourth
level, three missiles at firth-sixth level and four missiles at
seventh-eighth level.  This spell will damage any target within its
range unless the target is magic resistant or has certain magical
protection.  Casts instantaneously.  Usable by both Red and White
Robes.

"...when I saw the spectre floating toward me from out of the shadows,
its hateful presence charging the air with tense fear, my first
reaction was just to run like mad..."

Protection from Evil improves the AC and saving throws of the target
by two against evil attackers.  Usable by both Red and White Robes.

Read Magic allows a mage to ready a scroll and read it.  For scrolls,
this works as if they have been identified.  A mage may scribe the
spells from a scroll ( if appropriate for his class and level) after
it has been read.  Usable by both Red and White Robes.

Shield negates the magic missile spell, improves the magi's saving
throw and may increase his AC.  Usable by both Red and White Robes.

Shocking Grasp does electrical damage of 1-8 HP, +1 HP per level of
caster.  Usable by both Red and White Robes.

Sleep puts 1-9 targets to sleep with no saving throw.  Up to 9 one
hit-die targets are affected.  One 4 hit-die target is affected.
Targets of five or more hit-die are unaffected.  Usable by both Red
and White Robes.

Second Level Mage Spells
Detect Invisibility allows the target to spot invisible targets.
Usable by both Red and White Robes.

Invisibility makes the target invisible.  The THAC0 of mellee attacks
against invisible targets is reduced by four.  It is impossible to aim
ranged attacks at invisible targets.  Invisibility is dispelled when
the target attacks or casts a spell.  Usable by both Red and White
Robes.

Knock is used to pen locks.  It can be cast from the door-opening menu
if the active character has a memorized knock spell.  Usable by Red
Robes only.

Mirror Image creates 1-4 illusionary duplicates of the mage.  A
duplicate disappears when it is attacked.  Usable by Red Robes Only.

Ray of Enfeeblement reduces the target's damage by 25% + 2% per level
of the caster.  Usable by White Robes only.

Stinking Cloud paralyzes those in its area for 2-5 rounds.  If the
target saves, it is not paralyzed, but is nauseous and has its AC
reduced for two rounds.  This spell has a very short range and care
should be taken to avoid including party members in the cloud.

Strength raises the strength of the recipient one to eight points.
The effects of the spell are less if the target has 18 strength.
Usable by Red Robes only.

Third Level Mage Spells
Blink protects the mage.  The mage "blinks out" after he acts each
round.  The mage may be physically attacked before he acts each round,
but he may not be physically attacked after he acts.  Usable by Red
Robes only.

Dispel Magic removes the effects of spells that do not have specific
counter spells.  This is a recuperation spell for any of the party
that has been held, slowed or made nauseous.  Usable by White Robes
only.

Fireball does 1d6 HP per level of the caster to all targets within its
area.  If the target make its saving throw, the damage is halved.  A
fireball has a five square diameter outdoors and a seven square
diameter indoors.  Fireball is a slow-casting spell and the spell's
power demands that you target carefully.  Otherwise, you may
inadvertently destroy party characters.  If you target a fireball in
the center of the screen indoors, the only safe areas are the three
squares in each corner.  Be sure to center to determine who will be in
the area of effect.  Usable by both Red and White Robes.

Haste doubles the target's movement and number of melee attacks per
round.  Haste has a short duration an you should wait until a fight is
imminent to cast it.  Warning: each time a haste spell is cast on a
character, that character ages one year.  Usable by Red Robes only.

Hold Person may paralyze targets of character type (human, etc.),
goblin or hobgoblin.  You may aim a hold person spell at up to four
targets (EXIT to target less).  Usable by White Robes only.

Invisibility, 10' Radius makes all targets adjacent to the caster
invisible.  The THAC0 of melee attacks against invisible targets is
reduced by four.  It is impossible to aim ranged attacks at invisible
targets.  Use this spell to set up a battle line while the bad guys
seek you out.  Characters lost invisibility if they do anything but
move.  Some monsters can see invisible creatures.  Usable by Red Robes
only.

Lightning Bolt does 1d6 HP per level of the caster to targets along
its path.  If the target makes its saving throw, the damage is halved.
A lightning bolt is four or eight squares long in a line away from the
caster.  For best results, move the spell caster to send the bolt down
a row of opponents.  It will attack all opponents along the line
within its range.  Target the first creature in the row (closest to
caster).  Lightning bolts will reflect off walls back toward the spell
caster.  This permits targets adjacent or close to a wall to be hit
twice by the same bolt.  Be careful the caster isn't hit by the
reflected bolt.  Usable by both Red and White Robes.

Protection from Evil, 10' Radius protects the target and all
characters adjacent to the target.  The spell improves the AC and
saving throws of those it protects by two against evil attackers.
Usable by White Robes only.

Protection from Normal Missiles makes the target immune to non-magical
missiles.  Usable by White Robes only.

Slow affects one target per level of caster. the spell halves the
target's movement and number of mellee attacks per round.  Slow can be
used to negate a haste spell.  This spell is useful against any
high-damage creature.  Only affects the side opposing the spell
caster.  Usable by Red Robes only.

Fourth Level Mage Spells
Bestow Curse reduces the targets THAC0 and saving throws by four.
Usable by White Robes only.

Charm Monster changes the target's allegiance in combat.  It will work
on any living creature.  The spell affects 2-8 first level targets,
1-4 second level targets, 1-2 third level targets or one target of
fourth-level or above.  Usable by White Robes only.

Confusion affects 2-16 targets.  Each target must make a saving throw
each round or stand confused, became enraged, flee in terror or go
berserk.  Confusion is most effective when used against a large number
of enemies.  Usable by White Robes only.

Dimension Door allows the mage to teleport himself to another point on
the battlefield within his line of sight and the range of the spell.
Mages can use it for quick escapes.  Fighter/mages use the "Door" to
reach the opposition's rear area.  Usable by Red Robes only.

Fear causes all within its area to flee.  Usable by Red Robes only.

Fire Shield protects the mage so that any creature who hits the mage
in melee does normal damage, but takes twice that damage in return.
The shield may beattuned to heat attacks or cold attacks.  The mage
takes half damage (no damage if he makes his saving throw) and has his
saving throw against the opposite form of attack improved by two.  He
takes double damage from the form of attack the shield is attuned to.
Usable by both Red and White Robes.

Fumble causes the target to be unable to move or attack.  If the
target makes his saving throw, he is affected by a slow spell.  Usable
by White Robes only.

Ice Storm does 3-30 HP to all targets within its area.  There is no
saving throw.  This spell will inflict damage on opponents protected
by Minor Globes of Invulnerability.  Usable by both Red and White
Robes.

Minor Globe of Invulnerability protects the caster from incoming
first, second or third-level spells.  The Globe is very effective when
used in combination with Fire Shield.  Usable by White Robes only.

Remove Curse removes the effects of a Bestow Curse spell and allows
the target to unready cursed magic items.  Usable by White Robes only.

Fifth Level Mage Spells
Cloudkill is similar to the Stinking Cloud spell, except that its area
of effect is larger and it will kill weaker monsters.  Stronger
monsters may be immune to the spell.  Usable by both White and Red
Robes.

Cone of Cold fires a withering cone shaped blast of cold.  The spell's
range and damage increases with the caster's level.  Usable by both
White and Red Robes.

"...the chest, when opened, overflowed with treasure, some of it
having magical properties; but one item caused the mage among us to
shudder..."

Feeblemind causes targets who fail their saving throw to drop
dramatically in intelligence and wisdom and become unable to cast
spells.  A Heal spell must be cast on the victim to recover from the
effect.  Usable by White Robes only.

Fire Touch creates a blazing aura around the recipient.  This aura
adds 2-12 points of extra fire damage to all of the recipient's
attacks.  Usable by Red Robes only.

Hold Monster is similar to Hold Person, except it affects a wider
variety of creatures.  Usable by White Robes only.

Iron Skin causes the magi's skin to become extremely tough and damage
resistant.  The mage's AC is reduced by four.  Usable by Red Robes
only.

Sixth Level Mage Spells
Death Spell kills opponents instantly and irrevocably.  The spell will
kill a greater number of weak opponents than strong.  Powerful
opponents may be immune.  Usable by both Red and White Robes.

Disintegrate destroys one target.  Some creatures with an innate magic
resistance may avoid the effects of the spell, while most must make a
saving throw to survive.  Usable by Red Robes only.

Flesh to Stone causes the target to make a saving throw or be turned
into stone.  Usable by Red Robes only.

Globe of Invulnerability protects against first to fourth level
spells.  Usable by White Robes only.

Stone to Flesh counters the effects of a Flesh to Stone spell.
Characters may not survive the shock of being restored to flesh.
System shock survival is based on a character's constitution.  Usable
by Red Robes only.

Seventh Level Mage Spells
Delayed Blast Fireball is a more powerful version of the third level
spell and will penetrate a Minor Clobe of Invulnerability.  Usable by
both White and Red Robes.

Mass Invisibility is identical to the Invisibility spell, except that
it affects several targets at once.  This can be a valuable spell to
cast before a known encounter.  Usable by Red Robes only.

Power Word, Stun causes one creature to be stunned--reeling and unable
to think or act effectively.  The weaker the target, the longer it
will be stunned.  This is a very powerful spell and it automatically
affects any creatures who do not have magical immunities.  Usable by
both White and Red Robes.

Eighth Level Mage Spells
Mass Charm is similar to the fourth-level spell, except it affects a
much larger number of targets.  Usable by White Robes only.

Mind Blank is a powerful protective spell.  The recipient of this
spell is totally protected from spells that attack a character's mind
or will, such as Charm or Feeblemind.  Usable by White Robes only.

Otto's Irresistible Dance is an enchantment that causes the target to
be irresistibly compelled to dance a wild and frenzied jig.  The
target's AC is reduced by four and it fails all saving throws versus
other magical attacks.  Usable by White Robes only.

Power Word, Blind will strike some targets instantly blind.  Usable by
both White and Red Robes.


CREATURES OF KRYNN

The denizens of Krynn are many and varied. This is a list of some
monsters you may encounter in your adventures.

Beast, Undead
The undead beast is a mindless killer of unknown origin, compelled to
destroy the living. It is resistant to pointed or edged weapons and
flame.

Death Knight
A type of powerful undead that cannot be turned, death knights are
dangerous and frightening opponents who are immune to most magical
attacks. They can reflect some magic attacks back on the caster, cause
fear in those around them and cast a massive fireball attack once a
day.

Dragons
These are the most powerful and dangerous of the monsters a party can
encounter. The older and larger the dragon, the more damage it can do
and the harder it is to kill. In addition to their awesome strength,
dragons inspire an insidious terror called Dragon Fear or Awe. Many
times the mere sight of a dragon will cause opponents to panic and
flee.

Dragon, Black
They are noted for spitting a stream of deadly acid as well as
attacking with claws and fangs. Since they are extremely independent
and only obey commands if it suits their purpose, black dragons were
rarely used in direct assaults by the evil Dragon Highlords. They were
more highly valued as guards.

Dragon, Blue
Highly intelligent and greatly feared, they exhale lightning bolts in
addition to attacking with claws and fangs.  Blue dragons are more
gregarious than many of their cousins. They obey orders and can act
and fight together as a cohesive unit. They proved to be loyal allies
of the evil Dragon Highlords.

Dragon, Death
When some highly magical and intelligent dragons die, they become
death dragons. Their will is so powerful that their dead and rotting
bodies remain animated. They breathe a lethal cloud of gas.

Dragon, Red
Perhaps the most feared n of all the evil dragons, these beasts were
the favored assault force of the Dragon Highlord armies during the War
of the Lance. Not usually inclined to obey orders, red dragons enjoy
nothing more than setting cities ablaze, destroying and looting. Red
dragons can exhale great spouts of flame, cast magic spells or attack
with their claws and fangs.

Dragon, Spectral
Spirit form of Evil Dragons brought into the Human planes by the most
powerful priests of Takhisis. Their touch drains life and they are
unaffected by many spells and non-magic weapons.

Dragon, Undead
The animated corpse of a dragon, often of good alignment. It has none
of the intelligence or powers of the original dragon.

Dread Wolf
A wolflike undead creature who taunts budding heroes. The dread wolf
is often found in the service of a powerful evil master. It has the
ability to move great distances in a very short time and is immune to
most magic.

Fire Lizard
Resembles a wingless dragon and is sometimes called a "False Dragon."
It attacks with teeth, claws and a fire breath. It is resistant to
fire-based attacks.

Fire Minion
A fearsome creature from the elemental plane of Fire. Its body is
composed of living flame, most often taking the shape of a large
humanoid. It radiates intense heat and is healed by fire.

Ghast
This creature is nearly indistinguishable from a ghoul, save for a
carrion stench which it exudes. The stench causes retching and nausea.
The ghast is susceptible to cold.

Ghoul
A human transformed into an undead monster which feeds on the decaying
flesh of corpses. Although the transformation from human-form has
deranged and destroyed its mind, it maintains an evil cunning. Its
touch paralyzes humans.

Golems
Magically created automatons of great power. Golems can be constructed
of several materials.

Golem, Flesh
A humanoid formed by the stitched together remains of many corpses.
Its skin is the sickly green and yellow of decomposing flesh. Fire and
cold based attacks only slow it, electrical attacks heal it and they
are only vulnerable to magical weapons.

Golem, Iron
Fashioned in the form of stylized armor, it is affected only by very
powerful magic weapons, magical electrical attacks (which slow them)
and magical fire attacks (which heal them.)

Hatori
Dwelling deep in sandy deserts, this Crocodile of the Sands has a
voracious appetite. Entire caravans have been lost to a single hatori.

Hellhound
A fire-breathing canine summoned to serve evil beings. Their eerie
wail has caused strong men to flee.

Kua-Toa
An ancient race of fish-men dwelling underground and harboring a deep
hatred of surface dwellers. Kua-Toans are only encountered above
ground when they are seeking sacrifices and slaves.

Lich
Though liches are among the most powerful undead, they seek only to
further their own power. They do not seek confrontation, but are
ruthless in defending themselves.

Lycanthrope
Humans who can transform themselves to resemble normal animals and
monsters.

Wereboar
Like the boar it can transform into, the wereboar is ill tempered and
combative.

Weretiger
Weretigers are primarily female and are ferocious solitary hunters.

Nightmare
Commonly the mount of the more powerful undead, it originates in the
lower planes. Often known as hell horses or demon steeds.

Rhino Beetle
An enormous beetle with powerful mandibles, capable of crushing
anything in its path.

Roc, Undead
The animated remains of a gigantic flying bird.

Sivak Draconians
Draconians were the special troops of the Dragon Highlords. They are
created by corrupting the eggs of good dragons with vile sorceries.
Because of their magical origins all draconians are somewhat magic
resistant. Sivaks are created from silver dragon eggs. They are
powerful fighters who get three attacks per combat round.

Skeleton
These are the least powerful of the undead. They are usually
controlled by some powerful evil force.

Skeletal Giant
The animated bones of a giant.

Skeleton Warrior
Undead warriors forced into their nightmarish states by powerful
wizards.  They are used by their controllers as bodyguards, servants
or workers.  Clerics have no power over these undead.

Spectral Minion
These undead are the spirits of humans and demi-humans who died before
they could fulfill powerful vows or quests. Spectral minions are often
not evil -- their unfulfilled obligations are often quite noble. They
can only be hit with magic weapons.

Spectre
Powerful undead that haunt the most desolate and deserted of places,
hating all life. Spectres drain levels when they attack.

Vampire
Vampires prey upon the living during the night hours or deep
underground.  Often indistinguishable from humans, they keep the
abilities they had in life, including spell casting. Vampires drain
levels when they attack.

Vodyanoi
Close aquatic relative of the umber hulk, living in deep bodies of
fresh water. It only has two eyes and lacks the ability to confuse its
enemies.

Whisper Spider
The whisper spider uses lures and misdirection to capture its prey,
slaying them with a deadly poisonous bite.

Wight
An undead creature with cruel, burning eyes set in mummified flesh.
Affected only by magical weapons, it feeds on the life essence of its
prey. Each successful blow drains life from its victims. These
creatures can only be hit by silver or magical weapons.

Wraith
Evil undead spirit that seeks to absorb human life energy. Though
having no substance, it prefers to form into a vaguely human shape.
These creatures can only be hit by silver or magical weapons.

Wyndlass
A tentacled horror that lurks in desolate swamps and gloomy forests. A
powerful predator, it can easily devour an entire horse. Few have
survived a firsthand meeting with a wyndlass.

Zombie
Magically animated corpses under the control of an evil force, they
will fight with mindless rage until turned or destroyed.

Zombie Giant
Formed from the remains of a giant.

Zombie Mastodon
Formed from the remains of a mastodon.

Zombie Minotaur
Formed from the remains of a minotaur.


JOURNAL ENTRIES

Journal Entry 1
Tale of Crook Street
"It's the worst street in town, you know.  And proud of it.  The
Knights have learned to leave it alone.  It winds around a lot.  Real
crooked street.  If a body wanted to do a little private business or
hide out, it's the perfect place.  Strange magics will confuse all but
the natives.

"The Dream Merchant? Yes, he's on Crook Street.  Keep going -- you'll
see the sign.  By the way, nobody trifles with the Merchant --
everybody has to sleep sometime.

Journal Entry 2
The Cleric's Table
The cleric waves you toward a table of food. "Take your pick," he
says. "Your choice will determine your fate."

You study the table.  The choice is almost impossible to make.  A
bottle of clear water.  A pastry decorated with curlicues of frosting.
A cup of cider with a stick of cinnamon steeping within.  A boiled
potato decorated with a sprig of parsley.  Each one could mean death
or victory.  The cleric offers no advice.

Journal Entry 3
An explosion sounds behind you and a splinters rip through the deck of
the Kuo-Toa slave ship.  Another ship sails close and its captain
shouts for the immediate surrender of all Kuo-Toa and their captives.

You don't see the Kuo-Toa captain, but his voice rises over the
commotion to address the attacking ship. "We'll die first, land-faring
infidels!" The clerics and monitors cheer their agreement.

Soon the air is thick with explosions and flying fireballs.  The
battle is joined.

Journal Entry 4
Sprite Meeting
A Sprite flies up to you, "You are not Evil.  Be warned! Evil monsters
have entered Voice Wood.  Even though you would normally be welcome,
it would be safest to leave as quickly as you can."

Journal Entry 5
The Dream Merchant's Request
"Ever since I escaped from Kalaman, there have been creatures haunting
my sleep.  If I look away from the people I meet in dreams, fierce
hounds tear them apart like scare-crows! There are evil men beyond the
hounds and beyond the men, someone more evil still.

"I have the power to bring you into my dreams, to face the terrors I
cannot face.  If you are stout of heart, they cannot kill you.  Will
you help me?"

JOURNAL ENTRY 6
MOUNTAIN DWARF

The name is Skomp, I come from beneath the Dargaard Mountains.  There,
while exploring a new passage, I came upon an echo chamber -- one of
those unusual caverns that somehow amplify sound.  I heard voices
coming from above, from the surface.  Names were mentioned.  Lord
Soth.  Sir Karl.  Sebas Astmoor.  There was talk of a Dragonlance and
something called a Rod of Omniscience.  Conquest, that was the topic.
World conquest.

When I brought this matter before my superiors, they shrugged.  The
fate of the surface world does not concern them.  I went to their
superiors, with the same result.  How shortsighted they are, for if
the surface world falls, would we not be next?

Go to Journal Entry 20.

JOURNAL ENTRY 7
SIR TOM'S DREAM

You and many heroic Knights are a celebration, feasting merrily.  You
see a long-faced man in dark robes who doesn't seem to belong.  As you
try to accost him, he disappears in the crowd.

Suddenly Sir Karl is there before you.  You smile, even though you
know he is dead.  Thom! Give me your sword! he cries and you do so at
once.  He jerkily takes it and you notice silver strands attached to
his arms and legs.  The strands lead up to a monstrous man, whose face
covers the sky.  He laughs like thunder and pulls Sir Karl to him.

All turns black as you plummet into dark catacombs.  You grope in the
darkness, tearing through walls of gossamer spiderwebs, until you see
a speck of light and head for it.  It is a candle held by the
long-faced man.  There is a string around his wrist, but it has been
cut.  As you draw near, a door shuts and the candle is blown out.
This happens again.  On the third try the candle flickers, but stays
lit.  You step past a red door into a small bare room.  The long-faced
man transforms into a young Solamnic Knight, who hands you an ornate
key the color of blood.  For every key, a prisoner, he warns, then you
awake.


JOURNAL ENTRY 8
SIR THOM'S STORY

My name is Thom Govamont and I am Knight Emeritus of the Order of the
Rose.  Listen to me: I tell you, I knew all this would happen! I saw
Sir Karl rise again in a dream.  But wait! There is more! The dream
went on.  There was darkness and a candle and -- oh, I am old, I
cannot remember.

But here! Take this.  He presses a small smooth stone into your hand.
It is strangely warm.  Take care of it.  It is a Sleepstone.  I keep
it under my pillow and it records my dreams.  Often they prove
interesting.  I procured the Sleepstone from the Dream Merchant, a man
with power over dreams.  I think his shop is in Vingaard.  Take him
the stone; he will be able to show my dream to you.  It is most
important.

JOURNAL ENTRY 9
ARRIVAL IN SUDULTO

The hidden city of Sudulto lies before you, nestled in a deep valley
between two cliffs.  A group of playing children transform into
tussling puppies and back into human children as you watch.  It's a
city of lycanthropes,: Kai explains.  Not all werecreatures are evil.
In Sudulto all creatures live in peace.  Soth has no power here.  You
ll find the true Rod of Omniscience in the city.

You turn to question him further, but a powerful stag stands in his
place.  Waving his antlers at you in one final warning, he vanishes
into the woods.

JOURNAL ENTRY 10
DAINE'S GREETING

Welcome to our city.  I am Daine, Commander of the Solamnic Knights
for the city of Kalaman.  And with me you see my second, Major Tems
and the beauteous Ariela, my advisor and consort.

We hear many rumors of the rising power of Lord Soth.  My knights find
his hideous agents even here in center of town.  We are anxious to
learn how his power may be stopped.


JOURNAL ENTRY 11
MAYA SPEAKS

Maya jumps out from a dark cave, blocking your path.  Stop! she cries.
There so much I must explain to you before you continue your mission
against Soth.  He is not the villain you think!

Sir Karl steps out from the shadows behind Maya.  He laughs evilly and
rests his hand on her shoulder.  Yes...Maya serves Soth now!
Surrender, all of you.  You can't defeat Maya in her dragon form!

JOURNAL ENTRY 12
THE DREAM EXPLAINED

The first part of the dream is obvious.  An evil man is gathering
powerful weapons and warriors.  Things look dark for the forces of
good.  There is hope, the tragic man in dark robes has cut his puppet
strings.  You must find him, first by finding the candle and then by
traveling through red doors.  If you go through a gray door he will
disappear.

The man will introduce you somehow to the young Knight, who holds the
key to everything.

JOURNAL ENTRY 14
SPRITE WARNING

The Sprite responds, The Rod of Omniscience will be safe here, all of
Voice Wood will guard it.

Another Sprite chants, The Rod is too powerful and must never be used.
It must be guarded from everyone or the world would be destroyed!
Before you can respond, they fly away into the trees.

JOURNAL ENTRY 15
SLAVES OF THE KUO-TOA

The slaves grimly welcome you into their group.  You have been
captured by an aquatic race, known as the Kuo-Toa.  The Kuo-Toa hate
all landfaring creatures, which they use us as slaves and sacrifices
to their gods.  We must escape and destroy this vessel.

The Kuo-Toa fear fire above all else.  The only flames to be found
aboard the ship are in the temple, where they light holy torches to
represent their trust in their gods.

You are the strongest among us.  Make your way to the temple and set
fire to the boat with the torches.  The Kuo-Toa will panic and we can
all escape.  Whatever you do, don't get in any fights before you reach
the torches! We don't want them on guard.


JOURNAL ENTRY 16
PHILOSOPHER'S ORATORY

The Gnome shakes your hand then begins, You can call me Quartzberkl
...  Did you know that all of reality is subjective! How can we really
exist if we don't create a machine that is constantly aware of the
existence of each and every one of us? It's a great task that some
Gnome is this town must take to task.  The machine would need to ...

JOURNAL ENTRY 17
MAYA IN DISTRESS

You hear a scream from the other side of the graveyard and rush to
assist.  You find Maya surrounded and restrained by hordes of undead.
A Death Knight stands behind her, weaving a complex spell to prevent
her from transforming into her dragon form.

More and more undead appear for the spectacle, making the chance of a
successful rescue remote.  They drag Maya forward and tie her hands
around a wooden stake.  As she screams and struggles, they begin to
heap firewood under her kicking feet.

The Death Knight raises his head and looks squarely at you, as if
defying you to interfere.  Nearby, you see six more stakes fitted with
heavy iron restraints.

JOURNAL ENTRY 18
SAGE GNOME

Welcome to our town! one of the Sage Gnomes says as one of his
companions busily sketches you.  As you may or may not know, our
mission in life, is to record every activity in this village.  Well
recently, a Gnome whom you would call Quax made a machine that would
make some of us obsolete.  It made sketches of anything you pointed it
at.  We told him to make something different and to destroy this
machine, but he is awfully stubborn.  So we asked the Engineering
Guild to make something to make his machine fail.  Unfortunately,
shortly afterwards, the village started being rocked with explosions
loud noises bright lights ...  He stops, realizing he was speaking too
fast.  He calms down and continues, Since then, we ve been at war and
Quax has barricaded himself in his workshop and even put some traps
around to keep anyone from coming

JOURNAL: ENTRY 19
ARIELA'S WARNING

This man, Sebas Astmoor, is Soth's favorite and a potent cleric
worshipping Takhisis, the Dark Queen.  He has been abroad for some
time, doing some dark errand.  He visited Kalaman and left scenes of
incomparable horror.

If you encounter him, use utmost caution.  He is clever and wily.  If
you can take him alive, bring him here at once.  We must find out what
his mission is.

JOURNAL ENTRY 20
MOUNTAIN DWARF CONTINUED

: So that is why I am up here, traveling village to village, warning
the hill and gully dwarves of the impending danger and the need to
unite against his common enemy.  I've been to two villages before
this, where the hill dwarves at least listened to me.  I can't expect
a warm reception from any of them, you know, because of the bad blood
between our kinds.  But here, this village, these hill dwarves,
there's an intense hatred I don't understand.

I'll give up on this village.  But before leaving, I must find my
mount.  You saw that fine wild boar I was knocked from by the hill
dwarves.  He's carried me many a stretch of wilderness and seen me
through countless light spots.  Without his speed beneath me, my
warnings will reach the villages too late.  If you could spare the
time, I could use the help finding him.  He's in the village
somewhere.

JOURNAL ENTRY 21
WEAPON GUILD LEADER

I'm the leader of the Weapons Guild.  Recently, a series of bright
lights, loud noises and explosions rocked this town.  This is not
unusual in our village, except I have never seen so much of it.  I
figured it must be an invasion.  We quickly got together our best
troops and our latest weaponry...  Another Gnome interrupts to say he
hopes the two guards haven't been hurt too badly.  We hope you can
help us find and defeat our enemy, if you are truly the heroes you
appear to be.

JOURNAL ENTRY 22
SERVANTS OF SOTH

We were once citizens of Cereberus, a barmaid begins.  Soth brought us
here to serve his minions.  We don't know if our families even know
what became of us.

Another barmaid interrupts.  One of Soth's head minions keeps us here
under a geas.  He calls himself Commander.  She sneers in disgust.

The first barmaid continues.  The Commander's magic is focused in an
orb he keeps in his chamber.  Break the orb and the geas will be
lifted!

No, The second contradicts.  You must break the orb and kill the four
patrols on this floor.  Only then may we go free.

Anyway, the first finishes, the Commander's quarters are closely
guarded, but we located a secret passage that leads directly to the
orb.  The entrance is directly ahead.  Please, smash the orb and kill
the patrols!

JOURNAL ENTRY 23
THE SIVAK'S PLEA
You believe me to to be your enemy, but I am not.  We too fear the
growing power of Lord Soth.  If we kill you, we only add minions to
his groteque armies.  Therefore I ask that you release me.  We will
then leave this place in peace.  Kill me and my underlings will wreak
havoc upon this town.

JOURNAL ENTRY 24
DURFEY'S QUEST
I ran as fast as I could to catch up with you, pants Durfey.  His arm
grips his side as he doubles over with exertion.  I escorted Lenore
home as I said I would, but when we arrived her children were gone!
She swore it was the work of Soth and took off into the Keep before I
could stop her!

Durfey straightens and lifts his chin.  We must save Lenore,: he says.
It is a matter of honor now.  We must not wait ... she could fall into
Soth's clutches at any moment!

He hesitates, then looks bashful.  I hoped to have the chance to know
her better in the future...

JOURNAL ENTRY 25
ARIELA INSTRUCTS HER SERVANTS
You three -- take our captive at once to our mistress Kitiara.
Perhaps he will tell her his secret.  Do not let Soth's warriors take
him alive.  Hurry, now, begone!

The rest of your -- assume your true forms and teach these meddlers a
lesson.

JOURNAL ENTRY 26
THE HUNTER
The old hunter, Kai, bursts out at you, shaking his fists. : You
scared away my quarry? He points at a wicked looking trap concealed
under some leaves.  You politely ask what he is tracking.  Hunters, of
course! To protect the animals, he explains.

You tell Kai that Sebas sent you to him.  So you want me to guide you
to Sudulto? he makes a face, then nods.  Sebas would only send you
with good reason.  I'll join your party and show you the way.  But be
warned? If you kill any animals, I'll cut your throats!

JOURNAL ENTRY 27
SCHOLAR GNOME
No one is interested in education anymore, says one of the studious
looking Gnomes, as he works on a learning device that occasionally
makes a loud noise.  Ever since the Sage Guild got together with the
Engineering Guild, the entire town has been a mess.  Machines,
Soldiers, Monsters...  He mumbles for a while then continues, As a
result, no one wants to help us find a way to teach our children how
to make things.  Is there any way you can help us?

JOURNAL ENTRY 28
VAGABOUND ON STREET
I used to be a magician's assistant, until the day the dragons came.
They burned half the town and killed all of the powerful mages.  They
forbade any one from practicing magic again and killed or imprisoned
any one who did.  Some say the leader of dragons was nearly killed by
magic when he was young and he has hated magic ever since, Then those
guards came - those guards who became lizards! His eyes widen in
crazed terror, Then the statue spoke to me one night...

JOURNAL ENTRY 29
TALE OF THE DREAM MERCHANT
The Dream Merchant? Aye, I know of him.  I had this dream once -- this
lady -- well, I don't want to speak of it.  One's dreams should stay
one's own.  He was expensive, but what cost can you place on a good
night's sleep? When I saw the Merchant, it was at his shop in
Vingaard.  But I believe this time of year he travels through Cerberus
to Kalaman.

"..."We must save Lenore,"Durfey says.  "It is a matter of honor
now... she could fall into Soth's clutches at any moment!'..."

JOURNAL ENTRY 30
TRAPPED BY SEBAS
You burst into the cell, but Sebas is nowhere in sight.  The cell door
slams shut and you are trapped within! Sebas's face appears on the
other side of a small barred window.  Only heroes could be so stupid,
he says conventionally.  No one else would have believed the story
about me converting to Good.  Thank you for recovering the Rod of
Omniscience.  Lord Soth will reward me well.  He leaves.


JOURNAL ENTRY 31
GARREN'S TALE
I had collected the items tossed down by Sir Karl, when he passed over
Gargath Outpost.  I was trying to determine who Sir Karl had slain.
This one sword was intensely intriguing; it almost seemed to speak to
me.  Soon I became convinced that Sir Karl was right, that the
knighthood was foolishness.  I sought him out and he sent me on to
Lord Soth.

"...The Dream Merchant?  Aye, I know of him.  I had this dream once -
this lady - well, I don't want to speak of it.  One's dreams should
stay one's own..."

Things became hazy after this, but I remember planning an attack on
the High Clerist's Tower in order to steal away the corpses.  Soth
hopes to create Death Knights with them -- band them into an
invincible army.  We must stop them!  Arrgh! the sword has taken my
strength.  I fear I shall be little use in a fight.  Still, we must be
on after Soth!

JOURNAL ENTRY 32
WHAT ARIELA DROPPED
The object is a heavy metal key, embellished with loops and swirls.
The barrel is shiny from long use.  Inset in the key's handle is the
word Denissa, set in flowing feminine script.

JOURNAL ENTRY 33
IGORF
He seats you in plush chairs and arranges his expensive silk robe
around himself as he sits down.  I heard about the treasure hidden in
Cekos long ago.  My family thinks they are the same jewels that were
stolen from my ancestors before the Cataclysm.

His odd copper-colored eyes search your faces as he thinks. Having
made a decision, he continues, I came to Cekos to find and reclaim my
inheritance, but I haven't had any luck finding anything yet, He
pauses for a second and takes a sip from a teacup.  This town is very
confusing.  It is supposed to be a town of magic, but I have yet to
see any.  The people are all very secretive and keep to themselves.  I
have also notice that the town guard has managed to get rid of almost
every visitor they think it too curious about the workings of Cekos.

JOURNAL ENTRY 34
THE FATE OF THE FORTUNE TELLER
The fortune teller's eyes roll back in his head, showing only the
whites.  Incense rises an curls around his body.  I see a far away
city... he intones.  You must talk to the animals ... you must find
your place in this city to find the object you seek ... your quest
will take you far...

The curls of incense form a humanoid shape above the fortune teller.
You reveal too much, idiot! the shape snarls.  The smoke coalesces
around the forturne teller's head, making him choke and gasp.  In
moments, he falls lifeless to the table.  The smoke dissipates
throughout the tent.

JOURNAL ENTRY 35
READING THE TOME
You contemplate the giant tome before you, memorizing the circled
incantation.  Speaking it correctly will mean life or death to the
waiting townspeople.  After another few moments of study, you feel
ready.

You begin the incantation.  The tome seems to grow larger and larger,
surrounding you, blocking your vision of the room.  You try to stop
the spell, but your mouth moves of its own accord.  You are pulled
into a swirling vortex.  When the incantation is finished, you find
yourself in another place...

Curiouser and curiouser! a voice behind you exclaims.

JOURNAL ENTRY 36
THE KNIGHT's STORY
I was following some suspicious men when they suddenly grapped me.
Turns out they were Ariela's spies and they locked me up in the
Commander's House.  Soon they brought another man in, a bleak-looking
chap.  Looked half-dead.  They chained him up too and left us awhile.
The fellow whispered to me, I must trust you to deliver a message for
me.  He specified you by name.

This was the message; that the key to Soth's doom is the Rod of
Omniscience.  This fellow found it and hid it in a place called Voice
Wood.  He said you must go to Dulcimer in order to get there.  I think
he wanted to say more, but then the Sivaks returned and hustled us off
into the bazaar.  Someone was chasing us, so the Sivaks split into two
groups.  I guess the group holding this fellow Sebas managed to
escape.


<IMG SRC="DKK_AJ32.GIF">
JOURNAL ENTRY 37

JOURNAL ENTRY 38
CLERIC'S DIARY
The diary contains mostly routine notes about the upkeep of the
graveyard.  Only the last entry is of interest.

I fear old Loring, the gravedigger, has been stealing from the bodies.
He's started wearing a huge ruby, far beyond his means and refuses to
explain where he obtained it....

Before I speak to Loring, I must check the wards around the fence.  It
may be my imagination, but I sense something is wrong with them.

JOURNAL ENTRY 39
SPIRIT OF VOICE WOODS
Welcome, A greatly rumbling voice calls from all around you.  I have
watched you as you moved through the my trees.  I have watched many
people, but your bravery has impressed me above all others.  The Rod
of Omniscience is a very dangerous artifact.  Even beings of good
might be tempted to use the Rod improperly.  I will release it to you
if you vow to use it only against Lord Soth.  The woods are quiet, as
if waiting for an answer.

JOURNAL ENTRY 40
SIR KARL'S GRAVE
The graveyard is silent except for whispers of wind.  All seems in
order.  You find Sir Karl's grave, heaped in flowers and marked by the
gleaming marble obelisk that Maya had prepared.  Yet something is
amiss; the obelisk leans slightly.  As you put out a hand to correct
it, it suddenly topples.  Crash!  Full on the grave it falls, breaking
through sod and casket to reveal black tunnels that reek of
putrefaction and disease.

JOURNAL ENTRY 41
EVIL MAGE'S SPIRIT
After Myrtani's army was defeated, I fled the battlefield and stumbled
across this village.  His eyes glass over a second, then he sounts,
Gnomes! He shakes his head in disgust, One of them had just invented
something that actually worked, some sort of mechanical picture making
device.  Suddenly, the whole town was up in arms and some of the
villagers were blockading the inventor in his workshop.

A sinister grin appears on his face, Replacing the inventor would
solve all of my problems.  I could hide and become more powerful
without anyone even knowing that I exist.  He rolls his head back in
laughter, I had no trouble sneaking in and killing the unfortunate
Gnome who had created the machine.  Just to make sure, I set up some
traps, so the villagers would think he had become a hermit.  I let my
pets out to create more confusion.  After you are gone, I can get back
to my studies and become the most powerful wizard on Krynn!

JOURNAL: ENTRY 42
SCHOLAR
Those villagnous brutes, they ransacked my study and took what
military texts they could find.  The Proper Care and Feeding of a
Military Campaign.  The Art of Murder and Mayhem.  Advanced Taunts and
Tortures.  One Hundred and One Intimidation Techniques.  They took
them all.  I tried to stop them, but what can an old scholar do?  I
was never a man of the sword.  They just laughed and beat me senseless
with a book titled Brain Traumas in the Severely Pummeled, to give an
idea how twisted their minds are.

The situtation is even worse than I ve described it.  For there is one
other text, a notebook, really, whose contents dare not fall into the
minds of those evil rascals.  Ambush Made Easy , that's what it's
called.  A trival thing, it may seem.  The text barely runs 20 pages.
But, oh, the secrets it reveals about the most fundamental of
strategies; the ambush.  Yes, yes, they took it.  I tell you, you must
recover it.  Otherwise, we are in for a long and difficult campaign
whose end cannot be to our favor.

JOURNAL ENTRY 43
SEBAS IN DESPAIR
You show the Rod of Omniscience to Sebas.  He touches it hesitantly,
then throws it aside with a moan of despair.  I never meant for YOU to
find the decoy! he cries.  I had this one made in Kalaman bazzar.  The
true Rod was moved from Voice Wood to Sudulto days ago.

You must go to Sudulto and recover the true Rod.  Cimb the Eastern
mountains and search for an old hunter named Kai.  He can guide you to
Sudulto.

Take this fate Rod with you and hide it well.  Tell no one that it is
not the true item.


<IMG SRC="DKK_AJ34.GIF">
JOURNAL ENTRY 44

JOURNAL ENTRY 45
SIR VANSWARD'S TALE
This was once a thriving temple to Takhisis.  Corruption bubbled up
from this building and spread across the land.  Other knights had
assaulted the place before, but none survived the altar room.
Finally, we created a necklace which would protect us from the
spectral guardians.  I carried it boldily in, but was slain by a
priest here in the antechamber.

My spirit resides here until the altar can be destroyed.  I believe
that the necklace lies with my body.  I sense it to the north and
downward.  Go forward so that my soul may finally rest.

JOURNAL ENTRY 46
MAJOR TEMS SPEAKS
Thanks Paladine you've come.  Some of us have had suspicions for some
time.  Lately even some Knights have disappeared without trace! But we
lacked proof of dark intent.  She told Diane she had gone to Cerberus
to visit her older sister.  She goes there quite often.  He will be
furious at being deceived.

JOURNAL ENTRY 47
THE INNKEEPER'S STORY
Don't blame me if I am a little suspicious.  This neighborhood is
getting worse.  Something's going on -- creeps are everywhere -- and
the City Knights are nowhere to be seen.

JOURNAL ENTRY 48
ATTACK ON CERBERUS
Never before his this town had such ill-fortune! First the
assassination of our good mayor.  Now this! Legions of undead have
invaded the town.  They desire only our lives and the destruction of
our homes.

Dark shapes peer through the windows before boards are quickly naimed
into place blocking their view.  It was the fortune teller, says a
teenaged girl.  I saw him giving orders to the creatures as I was
running from the market.

Her father interrupts.  The important thing is to save our cleric,
Zakarie.  Only he can open the door to me armory.  With our weapons,
we can destroy these accused invaders!

JOURNAL ENTRY 49
DURFEY'S TALE
I have been a knight since early in life.  I have fought in the
numerous battles against evil's forces.  One by one, each of my
friends have died in battle or ambush.  With Myrtani's forces crushed
I came here to visit with my lost comrades.

Alas, even in the heart of Solamnia's greatest fortress, I am besieged
by evil.  If I can't find peace, then I shall take the battle them!
Quickly now, for my friends crypts are being desecrated.  Onward into
the eternal war.

JOURNAL ENTRY 50
THE SUBTERRANEAN LAKE
The tunnel leads deeper and deeper into the earth.  You stop often to
clear the passage, shoving aside dirt and rocks left by frequent
cave-ins.

It becomes difficult to breathe and you consider turning back if the
tunnel doesn't end soon.

The surface beneath you crumbles and you plummet into the darkness,
splashing into an ice-cold subterranean lake.  You equipment sinks
quckly to the bottom, lost forever.  In the darkness, you can't
discern the nature of the slimy creatures that are entwining your legs
under the surface of the water.

JOURNAL ENTRY 51
THE GRAVEDIGGER'S CONFESSION
I found the ruby on my bed, he cries.  I didn't steal it! I swear to
you, I am no thief, he says, flashing anger.  I thought it was a gift
from a mourner -- for my services.  I thought nothing of it at
first...  He lapses into silence for a moment.  Something happened to
me.  A few days after I found the ruby, my mind must have left me.  I
am afraid I was led to serve some great evil... to do terrible things.
He looks up at you fearfully now, I killed the cleric.  He was such a
kind man ...  I stole the runes he had placed around the graveyard to
ward off evil and buried them outside.  The next morning new runes had
replaced them and the place stunk of Evil.  What have I done?!? He
buries his head in his hands and sobs.

JOURNAL ENTRY 52
PHILOSPHER'S ORATORY
The little Gnome bobs his head in excitement, I am Quizmarxomatix ...
Did you know that if each Gnome is given to according to his ability
and taken from according to his need or wait, is that if each Gnome is
taken from according to his ability or wait, was that, if each
Gnome...

JOURNAL ENTRY 53
THE WRONG ANSWER
The Fairy king fold his arms.  Your words betray you.  You have lied
about your intentions and your good nature.  I must now pass judgement
on you.  Fairies cluster around you, hundreds of their tiny hands
holding you in place.  You are too treacherous to go free, the king
proclaims, and you are too dangerous to remain in our Wood.  He waves
his hand, surrounding you with a magic field.  You will therefore
become a part of our Wood...

Roots spout from your feet, embedding you deeply in the earth.  Leaves
sprout from your hair and fingertips.  The fairies exclaim with
pleasure and perch on your branches...


JOURNAL ENTRY 54
SEBAS's LAST WORDS
My friends... do you have the Rod of Omniscience? You show it to him
and he lowers his head in relief.  Then my suffering hasn't been in
vain.  Listen closely, I must tell you....  He breaks off as pain
washes over him.  His multilated fingers clench and unclench as he
collects himself.

Long ago, when I worked for Soth, he sent me to recover the Rod of
Omniscience.  After searching faithfully for many years, I finally
found it.  When I touched the Rod and felt its power, I knew I must
protect it from Soth at all costs.  I hoped to find a strong and
honest group of adventurers who could be trusted with the Rod... a
group like yourselves.

His voice grows fainter.  I would have escaped if Kitiara hadn't
caught me.  That woman is power hungry and wants the Rod for her own
purposes.  She is cunning and will do anything to get what she
wants... beware of her...

JOURNAL ENTRY 55
THE BLACK PIT
The pit is filled with the bones of countless sacrifices.  Bits of
corroded armor and tattered cloth cover many of the corpses.
Something seems to flicker and move in the distant darkness.  The
wailing sound is strengthening.  Now it is unbearable, soon it may be
deadily.

"..."Never fear," Soth promises.  "Food and water will be lowered to
you daily... just enough to keep you alive! Death won't come
easily..."

JOURNAL ENTRY 56
THE BOAR'S REVENGE
A persistent rustling from the bushes beside your campsite catches
your attention, but poking through the brush reveals nothing.  Just as
you are about to settle down to rest, an undead boar mounted by an
insane dwarf charges through the campsite, scattering your belongings.

You let them murder my boar! the dwarf rages.  If that wasn't enough,
you tried to have him cooked for your revolting dinner! Animals!
Cannibals! He strokes the boar's already-decomposing hide.  I'll cook
YOU over your own campfire! he vows and attacks!


JOURNAL ENTRY 57
LENORE INTRODUCTION
My name is Lenore.  The woman's dress hangs in tatters as she
nervously picks at the threads.  I'm looking for food or money for my
family.  Her jaw stiffens.  I have a right to steal from ths place!
Soth's minions killed my husband and our children need to eat.  Her
anger fades and the hunted expression returns.  I don't dare enter any
further than the first floor.  If you're wise you won't either!

You tell Lenore of your mission.  May I follow your team, just for a
few hours?  she asks hesitantly.  I'll be safe behind you and I can
search the bodies of those you slay for money or rations.  In exchange
I'll help you as much as I can with my knowledge of the Keep.

JOURNAL ENTRY 58
THE MYSTERIOUS LETTER

The letter reads:

Brave adventures.

You have a locked box.  We have the man with the key.  Since we both
seek to stop the Lord Soth from coing to power, why not bring the
Sleepstone and the Dream Merchant together under rules of truce?
Tonight, meet us at the 165th hour in the center of the bazaar.  No
tricks or we shall kill the Dream Merchant.

The Kidnappers

JOURNAL ENTRY 59
BARTENDER
Strangers have been coming to this town for years, the bartender says,
pouring a glass for an impatient customer.  Mostly they come to see
the magic, but some had heard about the treasure some dragon or
dragons hid in this town long ago.  Sincer we no longer practice magic
in Cekos, I suppose you re here to find the treasure.  A princess came
here looking for the same thing a few weeks ago, but I'm sure the town
guard has chased her out of town already.  No one has found the
treasure or if they have, they haven't lived to enjoy it.  You re
always free to tell me how close you came to finding it, I've heard
every story there is.

JOURNAL ENTRY 60
THE SNAKE'S DEMANDS
Snakes rise from each of the three baskets, surrounding you.  One of
them has a human face and it dips close to speak.  It would be easssy
to kill you all, it says.  Our poissson hasss no known cure.  But we
only want the girl.  Leave her with usss and we'll let you leave in
peaccce.

Lenore screams and hides behind Durfey.  Don't leave me here! she
cries.  Please, protect me!

The snake hisses venomously.  Do not lisssten to her, it urges.  Ssshe
isss one of usss, in human form.  Our kind demandsss her return, to
face judgement for her crimesss.

JOURNAL ENTRY 61
FACING THE SNAKE KING
You watch from the shadows as Durfey and Lenore are brought to stand
in front of the king of the snakes.  The king's body is a thick as a
tree trunk and his coils extend far into the shadows behind.
Snakelets slither and play around his body, while adult snakes rise on
either side of him expectantly.  Durfey is not cowed.  I will not let
you hurt Lenore! he insists, putting his arm around her protectively.

Her name isss Erline, the snake king says calmly.  Tell him the truth,
Erline.  Your charade isss over.  Lenore only sobs and clutches
Durfey's arm tighter.  The king looks disgusted.

JOURNAL ENTRY 62
SOTH REVEALED
The commander of the garrison approaches and pokes Ariela's body with
his foot.  You truly are mighty warriors, he says.  Mighty enough to
join my armies.  His visage shimmers and the face of Lord Soth is
revealed.  He laughs at your surprise.  I desire only the best
warriors, he mocks, and the most intelligent.  You identified Ariela
and killed her.  That makes you quite eligible.  Durfey changes and
slashes at Soth with his sword, but it causes no visible damage.  You
think you can hurt me?: Soth mocks.  Perhaps you are not quite as
intelligent as I thought.

JOURNAL ENTRY 63
IN THE OUBLIETTE
Soth watches personally as you are disarmed and chained.  You chose
the wrong door, he gloats.  Once I might have turned you into undead,
to join my army, however, since you have been so much trouble, I will
derive even greater pleasure knowing that you live... in torment!

You are shoved, one by one, through a door in the floor and fall into
a dungeon below.  Never, fear, Soth promises.  Food and water will be
lowered to you daily... just enough to keep you alive! Death won't
come easily...  The door slams shut, submerging you in total darkness.

JOURNAL ENTRY 64
A MYSTERIOUS VISITOR
As you leave Cerberus, a blond man approaches from the woods.  He is
wearing a strange blue uniform, completely unfamiliar to you.

The weapon on his belt is equally mysterious.  I just wanted to
congratulate you on your rescue of Cerberus, he says.  It always pays
to remember that people are more important than orders.  He waves
good-bye and vanishes back into the woods.

JOURNAL ENTRY 65
THE KALAMAN AUCTION

COME ONE, COME ALL TO THE ANNUAL ACTION! the hawker bellows.  UNIQUE
AND VALUABLE ITEMS FOR THE BIDDING!

Most of the display items are junk: broken furniture, chipped mirrors;
moth-eaten clothing.  You are about to leave when the hawker starts
his tirade again.  WHO'LL BID ON MY FIRST ITEM? he demands.

A GENUINE ARTIFACT FROM DARGAARD KEEP ITSELF, OBTAINED AT INCREDIBLE
RISK FOR SALE HERE.  DO I HEAR AN OFFER?

He holds up a glass skull.  Once jewels were mounted in the eyes, but
they were pried loose long ago.  Even so, the skull carriers an aura
of menace and enchangement that you can feel, even at this distance.
WHO WILL START THE BIDDING? the auctioneer looks directly at you.

JOURNAL ENTRY 66
MAN IN THE DARK ROBES
My name is Sebas Astmoor.  Once I was a cleric of Majere, although I
can scarce remember it.  Long ago Lord Soth corrupted me into
worshiping the dark gods.  As his favorite and most powerful cleric,
he sent me on his most pressing quest; to find -- no, no, I shall not
tell you what.

I found it.  And could not resist wielding it just a little.  And it
changed me, curse it! Suddenly I saw Lord Soth's folly and -- my own
unworthiness.  I hid it.  I hid it very well.  My Lord must never find
it, for his own sake and that of all of Krynn.  I will release it only
to those proven strong enough to resist Lord Soth and who can be
trusted to wield power correctly.

Curse that thing! I gave it up, I surrendered my dark powers and now I
hide alone in the dark, waiting to die.  All because it gave me back a
conscience.



STRENGTH TABLE:  ABILITY ADJUSTMENTS
                                          WEIGHT
ABILITY         THACO   DAMAGE            ALLOWANCE
SCORE           BONUS   ADJUSTMENT        (IN STEEL PIECES)
------------------------------------------------------------_
3               -3      -1                      -350
4-5             -2      -1                      -250
6-7             -1      none                    -150
8-9             normal  none                    normal
10-11           normal  none                    normal
12-13           normal  none                    +100
14-15           normal  none                    +200
16              normal  +1                      +350
17              +1      +1                      +500
18              +1      +2                      +750
*18/01-50       +1      +3                      +1000
*18/51-75       +2      +3                      +1,250
*18/76-90       +2      +4                      +1,500
*19/91-99       +2      +5                      +2,000
*18/00          +3      +6                      +3,000

*Bonus available to fighter classess only (fighter, Paladin, Knight,
Ranger)

DEXTERITY TABLE:
ABILITY ADJUSTMENTS

ABILITY         REACTION          AC
SCORE           MISSILE           BONUS
                BONUS
----------------------------------------_
3                 -3                +4
4                 -2                +3
5                 -1                +2
6                  0                +1
7                  0                 0
8                  0                 0
9                  0                 0
10                 0                 0
11                 0                 0
12                 0                 0
13                 0                 0
14                 0                 0
15                 0                 -1
16                 +1                -2
17                 +2                -3
18                 +3                -4

CONSTITUTION
TABLE:  ABILITY

ABILITY     HIT POINT       RESURREC.
SCORE       ADJUSTMENT      SURVIVAL
---------------------------------------
3                -2            40%
4                -1            45%
5                -1            50%
6                -1            55%
7                 0            60%
8                 0            65%
9                 0            70%
10                0            75%
11                0            80%
12                0            85%
13                0            90%
14                0            92%
15               +1            94%
16               +2            96%
17               +2(+3)*       98%
18               +2(+4)*      100%

*Bonus applies only to fighters; all other classes may be given a
maximum hit point bonus adjustment for constitution of +2.



BONUS ATTACKS FOR HIGH LEVEL FIGHTERS
CLASS                   LEVEL           ATTACK/ROUND
--------------------------------------------------_
Fighter                 1-6             1/1
Knight                  1-6             1/1
Paladin                 1-6             1/1
Ranger                  1-7             1/1
Fighter                 7-12            3/2
Knight                  7-12            3/2
Paladin                 7-12            3/2
Ranger                  8-14            3/2
Fighter                 13+             2/1
Knight                  13+             2/1
Paladin                 13+             2/1



RANGE OF ABILITY SCORES BY RACE TABLE

ABILITY SCORE       STR*      INT       WIS     DEX    CON    CHA
--------------------------------------------------------------------
HUMANS              3-18(00)  3-18      3-18    3-18   3-18   3-18
(Females)           3-18(50)  3-18      3-18    3-18   3-18   3-18
Silvanesli Elves    3-18(75)  10-18     6-18    7-19   6-18   12-18
(Females)           3-16      10-18     6-18    7-19   6-18   12-18
Qualinesli Elves    7-18(75)  8-18      6-18    7-19   7-18   8-18
(Females)           3-16      8-18      6-18    7-19   7-18   8-18
Hill Dwarves        9-18(99)  3-18      3-18    3-17   14-19  3-12
(Females)           3-17      3-18      3-18    3-17   14-19  3-12
Min. Dwarves        8-18(99)  3-18      3-18    3-17   12-19  3-16
(Females)           3-17      3-18      3-18    3-17   12-19  3-16
Half-Elves          3-18(90)  4-18      3-18    6-18   6-18   3-18
(Females)           3-17      4-18      3-18    6-18   6-18   3-18
Kender (Both)       6-16      6-18      3-16    8-19   10-18  6-18

*Maximum percentage for 18 strength for fighter type classes only
(fighter, knight, ranger, paladin)



MAXIMUM LEVEL LIMITS BY RACE, CLASS AND PRIME REQUISITE

                             SILV.  QUAL.  HALF   HILL  MTH
CLASS ABILITY   HUMAN ELVES  ELVES  ELVES  DRA    DR    KENDERS
-----------------------------------------------------------------
Cleric  any     14    14     14     14     10     10    8
Fighter Str 16- 14    10     14      9     14     14    5
        Str 17  14    10     14      9     14     14    -
        Str 18+ 14    10     14      9     14     14    -
Ranger  Str 16- 14    14     14     11     8      No    5
        Str 17  14    14     14     11     8      No    -
        Str 18+ 14    14     14     11     8      No    -
Knight  Any     14    No     No     10     No     No    No
Paladin Any     14    12     No     No     No     8     No
Mage    Int 16- 14    14     14     10     No     No    No
        Int 17  14    14     14     10     No     No    No
        Int 18+ 14    14     14     10     No     No    No
Thief   Any     18    No     18     18     10     8     18


WEAPON TABLE
Name              Damage vs.  Damage vs. Larger   Number
                  Man Sized   Than Man Sized      of Hands    Class
---------------------------------------------------------------------
Axe, Battle        1-8              1-8             1           f
Axe, Hand          1-6              1-4             1           f
Bow, Long*         1-6              1-6             2           f
Bow, Short*        1-6              1-6             2           f
Bow, Composite
Long*              1-6              1-6             2           f
Bow, Composite
Short*             1-6              1-6             2           f
Club               1-6              1-3             1           f,cl,th
Dagger             1-4              1-3             1           f,mu,th
Dart               1-3              1-2             1           f,mu,th
Flail              2-7              2-8             1           f,cl
Halberd+           1-10             2-12            2           f
Hammer             2-5              1-4             1           f,cl
Hopak(Melee)       3-8              3-6             2           **
Hoopak(Missle)     2-5              2-7             2           **
Javelin            1-6              1-6             1           f
Light Crossbow     1-4              1-4             2           f
Mace               2-7              1-6             1           f,cl
Morning Star       2-8              2-7             1           f
Pick, Military     2-5              1-4             1           f
Pick, Awl          1-6              1-12            1           f
Quarterstaff       1-6              1-6             2           f,cl,mu
Scimitar           1-8              1-8             1           f,th
Sling              1-4              1-4             1           f,th
Sling,Staff        2-8              3-9             2           f,cl
Spear              1-6              1-8             1           f
Sword,Bastard      2-8              2-7             2           f
Sword,Broad        2-8              2-16            1           f,th
Sword,Long         1-8              1-12            1           f,th
Sword,Short        1-6              1-8             1           f,th
Sword,Two-Handed   1-10             3-18            2           f
Trident            2-7              3-12            1           f

*Must have ready arrows to fire.  Two Attacks per round.
#Must have ready quarrels to fire.  One Attack per round.
** Only usable by kender characters.
f=fighter (includes knight, ranger, paladin), cl=cleric, th=thief,
mu=magic-user



ARMOR TABLE

ARMOR TYPE      WEIGHT                             MAXIMUM
                IN SP.               AC            MOVEMENT*
-----------------------------------------------------------------
None              0                  10              -
Shield            50                 **              -
Leather           150                8               12 squares
Ring              250                7                9 squares
Scale             400                6                6 squares
Chain             300                5                9 squares
Banded            350                4                9 squares
Plate             450                3                6 squares

*In addition to armor, movement may be limited by carried items.
Minimum movement is 3 squares.
** A Shield subtracts 1 AC from any armor it is used with.

LEVEL ADVANCEMENT TABLES
The following charts show the number of experience points a character
must earn in order to gain a level in his character class.    The
charts also list the number of spells that a character can have
memorized at one time.  Fighters and Thieves can never memorize
spells.

Remember:  All experience earned by multiple-class characters is
divided evenly among all classes, even after character has reached
maximum level in a class.


CLERIC OF GOOD
                                  Hit     Clerical Spells per Level
LEVEL        EXPERIENCE           DICE      1  2   3   4   5   6
--------------------------------------------------------------------------
1                2,000-3,999      2d8       1  -   -   -   -   -
2                4,000-7,499      3d8       2  -   -   -   -   -
3                7,500-15,249     4d8       2  1   -   -   -   -
4               15,250-24,999     5d8       2  2   -   -   -   -
5               25,000-39,999     6d8       3  3   1   -   -   -
6               40,000-89,999     7d8       3  3   2   -   -   -
7              90,000-159,999     8d8       3  3   2   1   -   -
8              160,000-249,999    9d8       3  3   3   2   -   -
9              250,000-499,999    9d8+1     4  4   3   2   1   -
10            500,000-749,999     9d8+2     4  4   3   3   2   -
11            750,000-999,999     9d8+3     5  4   4   3   2   1*
12           1,000,000-1,249,999  9d8+4     6  5   5   3   2   2
13           1,250,000-1,499,999  9d8+5     6  6   6   4   2   2
14           1,500,000+           9d8+6     6  6   6   5   3   2

*Usable only by clerics of 17 or greater wisdom


CLERIC OF NEUTRALITY
                             Hit       Clerical   Spells   Per    Level
Level     Experience         Dice      1   2   3    4    5    6    7
-------------------------------------------------------------------------
1           1,500-2,999       1d8      2   -   -    -    -    -    -
2           3,000-5,999       2d8      2   1   -    -    -    -    -
3           6,000-12,999      3d8      3   2   1    -    -    -    -
4          13,000-27,499      4d8      4   2   2    -    -    -    -
5          27,500-54,999      5d8      4   3   2    -    -    -    -
6          55,000-109,999     6d8      4   3   2    1    -    -    -
7         110,000-224,999     7d8      4   4   3    1    -    -    -
8         225,000-449,999     8d8      4   4   3    2    -    -    -
9         450,000-674,999     9d8      5   4   3    2    1    -    -
10        675,000-899,999     9d8+1    5   4   3    3    2    -    -
11        900,000-1,124,999   9d8+2    5   5   3    3    2    1*   -
12      1,125,000-1,349,999   9d8+3    5   5   4    4    3    2    1**
13      1,350,000-1,574,999   9d8+4    6   5   5    4    3    2    1
14      1,575,000+            9d8+5    6   6   6    6    4    2    1
*Usable only by clerics of 17 or greater wisdom
**Usable only by clerics of 18 or greater wisdom


CLERIC WISDOM BONUS
CLERIC'S                         BONUS SPELLS
WISDOM                     1    2     3    4     5
----------------------------------------------------
9-12                       -    -     -    -     -
13                         +1   -     -    -     -
14                         +2   -     -    -     -
15                         +2   +1    -    -     -
16                         +2   +2    -    -     -
17                         +2   +2    +1   -     -
18                         +2   +2    +1   +1    -

Note that these bonus spells are only available when the clerics is
entitled to spells of the applicable level.  For example, an 6th-level
cleric of Good with a Wisdom of 18 can memorize the following spells:

                               NUMBER OF SPELLS PER LEVEL
                           1         2       3        4      5
----------------------------------------------------------------
6th-Level Cleric of
Good with 18 Wisdom        5         5       3        -      -



FIGHTER
LEVEL                  EXPERIENCE                     HIT
                                                      DICE
------------------------------------------------------------
1                       0-2,000                       1d10
2                       2,001-4,000                   2d10
3                       4,001-8,000                   3d10
4                       8,001-18,000                  4d10
5                      18,001-35,000                  5d10
6                      35,001-70,000                  6d10
7                      70,001-125,000                 7d10
8                     125,001-250,000                 8d10
9                     250,001-500,000                 9d10
10                    500,001-750,000                 9d10+3
11                    750,001-1,000,000               9d10+6
12                  1,000,001-1,250,00                9d10+9
13                  1,250,001-1,500,000               9d10+12
14                  1,500,001+                        9d10+15



KNIGHT OF THE CROWN
                                                  HIT
LEVEL            EXPERIENCE                       DICE
--------------------------------------------------------
1                2,500-4,999                      2d10
2                5,000-9,999                      3d10
3                10,000-18,499                    4d10
4                18,500-36,999                    5d10
5                37,000-84,999                    6d10
6                85,000-139,999                   7d10
7                140,000-219,999                  8d10
8                220,000-299,999                  9d10
9                300,000-599,999                  10d10
10               600,000-899,999                  10d10+2
11               900,000-1,199,999                10d10+4
12               1,200,000-1,499,999              10d10+6
13               1,500,000-1,799,999              10d10+8
14               1,800,000+                       10d10+10



KNIGHT OF THE SWORD
                             HIT         Clerical Spells Per Level
LEVEL    EXPERIENCE          DICE      1     2    3     4     5    6
----------------------------------------------------------------------
3        12,000-23,999       4d10      -     -    -     -     -    -
4        24,000-44,999       5d10      -     -    -     -     -    -
5        45,000-94,999       6d10      -     -    -     -     -    -
6        95,000-174,999      7d10      1     -    -     -     -    -
7       175,000-349,999      8d10      2     -    -     -     -    -
8       350,000-699,999      9d10      2     1    -     -     -    -
9       700,000-1,049,999    10d10     3     2    -     -     -    -
10    1,050,000-1,399,999    10d10+2   4     2    -     -     -    -
11    1,400,000-1,749,999    10d10+4   4     2    1     -     -    -
12    1,750,000-2,099,999    10d10+6   5     3    1     1     -    -
13    2,100,000-2,499,999    10d10+8   6     4    1     1     1    -
14    2,450,000+             10d10+10  7     5    2     1     1    1


KNIGHT OF THE ROSE
                              HIT       Clerical Spells Per Level
LEVEL   EXPERIENCE            DICE      1   2   3   4   5   6
----------------------------------------------------------------------_
4          27,000-59,999      5d10      -   -   -   -   -   -
5          60,000-124,999     6d10      -   -   -   -   -   -
6         125,000-199,999     7d10      1   -   -   -   -   -
7         200,000-494,999     8d10      2   -   -   -   -   -
8         425,000-799,999     9d10      2   1   -   -   -   -
9         800,000-1,499,999   10d10     3   2   -   -   -   -
10      1,500,000-1,999,999   10d10+2   4   2   -   -   -   -
11      2,000,000-2,499,999   10d10+4   4   2   1   -   -   -
12      2,500,000-2,999,999   10d10+6   5   3   1   1   -   -
13      3,000,000-3,499,999   10d10+8   6   4   1   1   1   -
14      3,500,000+            10d10+10  7   5   2   1   1   1


WHITE ROBE MAGE
                                 HIT          SPELLS PER LEVEL
LEVEL     EXPERIENCE             DICE     1   2  3  4  5  6  7  8
-------------------------------------------------------------------
1        2,500-4,999        1d4           1   -  -  -  -  -  -  -
2        5,000-9,999        2d4           2   -  -  -  -  -  -  -
3       10,000-17,999       3d4           2   1  -  -  -  -  -  -
4       18,000-35,999       4d4           3   2  -  -  -  -  -  -
5       38,000-54,999       5d4           4   2  1  -  -  -  -  -
6       55,000-99,999       6d4           4   2  2  -  -  -  -  -
7      100,000-199,999      7d4           4   3  2  1  -  -  -  -
8      200,000-399,999      8d4           4   3  3  2  1  -  -  -
9      400,000-599,999      9d4           4   3  3  2  1  -  -  -
10     600,000-799,999      10d4          4   4  3  2  2  1  -  -
11     800,000-999,999      11d4          4   4  4  3  3  2  1  -
12   1,000,000-1,249,999    10d4+1        4   4  4  4  4  3  2  1
13   1,250,000-1,499,999    10d4+3        5   5  5  4  4  3  2  1
14   1,500,000+             10d4+3        5   5  5  4  4  3  2  1


RED ROBE MAGE
                            HIT
LEVEL EXPERIENCE            DICE               SPELLS PER LEVEL
                                          1  2  3  4  5  6  7  8
---------------------------------------------------------------------
1         2,500-4,999         1d4         1  -  -  -  -  -  -  -
2         5,000-9,999         2d4         2  -  -  -  -  -  -  -
3        10,000-17,999        3d4         2  1  -  -  -  -  -  -
4        18,000-35,999        4d4         3  2  1  -  -  -  -  -
5        36,000-49,999        5d4         4  3  1  -  -  -  -  -
6        50,000-89,999        6d4         4  3  2  -  -  -  -  -
7        90,000-179,999       7d4         4  3  2  1  -  -  -  -
8       180,000-349,999       8d4         4  3  3  2  -  -  -  -
9       350,000-499,999       9d4         4  3  3  2  1  -  -  -
10      500,000-699,999       10d4        5  4  3  2  2  1  -  -
11      700,000-899,999       10d4+1      5  4  4  3  3  2  -  -
12      900,000-1,099,999     10d4+2      5  4  4  4  4  2  1  -
13    1,100,000-1,299,999     10d4+3      5  5  5  4  4  2  1  1
14    1,300,000+              10d4+4      5  5  5  4  4  2  2  1



PALADIN
LEVEL       EXPERIENCE      HIT
                            DICE    CLERICAL SPELLS PER LEVEL
                                       1  2   3   4
---------------------------------------------------------------
1               0-2,750     1d10       -  -   -   -
2           2,751-5,500     2d10       -  -   -   -
3           5,501-12,000    3d10       -  -   -   -
4          12,001-24,.000   4d10       -  -   -   -
5          24,001-45,000    5d10       -  -   -   -
6          45,001-95,.000   6d10       -  -   -   -
7          95,001-175,000   7d10       -  -   -   -
8         175,001-350,000   8d10       -  -   -   -
9         350,001-700,000   9d10       1  -   -   -
10        700,001-1,050,000 9d10+3     2  -   -   -
11      1,050,001-1,400,000 9d10+6     2  1   -   -
12      1,400,001-1,750,000 9d10+9     2  2   -   -
13      1,750,001-2,100,000 9d10+12    2  2   1   -
14      2,100,001+          9d10+15    3  2   1   -



RANGER
LEVEL       EXPERIENCE       HIT           SPELLS PER LEVEL
                             DICE          DRUIDIC      MAGIC-USER
                                             1  2          1  2
--------------------------------------------------------------------
1               0-2,250       2d8            -  -          -  -
2           2,251-4,500       3d8            -  -          -  -
3           4,501-10,000      4d8            -  -          -  -
4          10,001-20,000      5d8            -  -          -  -
5          20,001-40,000      6d8            -  -          -  -
6          40,001-90,000      7d8            -  -          -  -
7          90,001-150,000     8d8            -  -          -  -
8         150,001-225,000     9d8            1  -          -  -
9         225,001-325,000     10d8           1  -          1  -
10        325,001-650,000     11d8           2  -          1  -
11        650,001-975,000     11d8+2         2  -          2  -
12        975,001-1.300,000   11d8+4         2  1          2  -
13      1,300,001-1,625,000   11d8+6         2  1          2  1
14      1,625,001+            11d8+8         2  2          2  1


THIEF
LEVEL       EXPERIENCE   HIT DICE
-----------------------------------
1              0-1,250     1d6
2          1,251-2,500     2d6
3          2,501-5,000     3d6
4          5,001-10,000    4d6
5         10,001-20,000    5d6
6         20,001-42,500    6d6
7         42,501-70,000    7d6
8         70,001-110,000   896
9        110,001-160,000   9d6
10       160,001-220,000   10d6
11       220,001-440,000   10d6+2
12       440,001-660,000   10d6+4
13       600,001-880,000   10d6+6
14       880,001-1,100.000 10d6+8
15     1,100,001-1,320,000 10d6+10
16     1,320.001-1,540,000 10d6+12
17     1,540,001-1,760,000 10d6+14
18     1,760,001+          10d6+16


SPELL PARAMETERS TABLE

WHEN:
Cmbt =  Combat only spell
Camp =  Camp only spell
Both =  Camp or Combat spell

RNG:
T = Touch Range
dia = diameter
rad = radius
All  = All characters in combat
#  = Number of targets
#s = number of squares

DURATION:
r = combat rounds
t = turns
/lvl = per level of caster
targets = aim at each target

Robe (Mage spells only):
White = Can only be cast by White Robes
Red = Can only be cast by Red Robes
Both = Can be cast by both


1ST-LEVEL CLERICAL SPELLS
SPELL NAME           When    RNG    AREA    DURATION
-------------------------------------------------------
Bless                Both     6     5 dia      6r
Cure Light Wounds    Both     T     1          -
Detect Magic         Both     3     1          1t
Protection from Evil Both     T     1          3r/lvl
Resist Cold          Both     T     1          1t/lvl


2ND-LEVEL CLERICAL SPELLS
Spell Name        When   RNG  AREA  DURATION
-------------------------------------------------
Find Traps        Camp    3    1      3t
Hold Person       Cmbt    6    1-3    4r+1/;lvl
Resist Fire       Both    T    1      1t/lvl
Silence 15'Radius Combt   12   3dia   2r/lvl
Slow Poison       Camp    T    1      1hour/lvl
Snake Charm       Cmbt    3    All    5-8r
Spiritual Hammer  Cmbt    3    1      tr/lvl


3RD-LEVEL CLERICAL SPELLS
Spell Name       When   Rng   AREA   DURATION
-----------------------------------------------
Cure Blindness   Both    T      1       -
Cure Disease     Camp    T      1       -
Dispel Magic     Both    6      3x3s    -
Prayer           Both    0      All     1r/lvl
Remove Curse     Both    T      1       -


4TH-LEVEL CLERICAL SPELLS
SPELL NAME                       WHEN   RNG   AREA   DURATION
----------------------------------------------------------------
Cure Serious Wounds              Both    T     1        -
Neutralize Poison                Both    T     1        -
Poison                           Cmbt    T     1        -
Protection from Evil 10' Radius  Both    T     2dia     1t/lvl
Sticks to Snakes                 Cmbt    3     1        2r/lvl


5TH-LEVEL CLERICAL SPELLS
SPELL NAME            WHEN RNG AREA DURATION
-----------------------------------------------
Cure Critical Wounds  Both  T   1      -
Dispel Evil           Cmbt  T   1      1r/lvl
Flame Strike          Cmbt  6   1      -
Raise Dead            Camp  3   1      -


6TH-LEVEL CLERICAL SPELLS
SPELL NAME WHEN RNG AREA DURATION
------------------------------------
Heal       Both  T   1   Permanent


7TH-LEVEL CLERICAL SPELLS
SPELL NAME   WHEN  RNG AREA DURATION
---------------------------------------
Restoration  Camp  T    1   Permanent
Resurection  Camp  T    1   Permanent


1ST-LEVEL DRUIDICAL SPELLS
(FOR HIGH LEVEL RANGERS)
SPELL NAME               WHEN RNG AREA DURATION
----------------------------------------------------
Cure light Wounds        Both T    1     -
Detect Magic             Both 4    1     12r
Entangle                 Cmbt 8    4dia  1t
Faerie Fire              Cmbt 8    8dia  4r/lvl
Invisibility to Animals  Both T    1     1t+1r/lvl


2ND-LEVEL DRUIDICAL SPELLS
(FOR HIGH-LEVEL RANGERS)
SPELL NAME          WHEN RNG AREA  DURATION
----------------------------------------------
Barskin             Both  T    1   4r+1r/lvl
Charm person/Mammal Cmbt  12   1   -



1ST-LEVEL MAGE SPELLS
SPELL NAME           WHEN RNG    AREA DURATION ROBE
-----------------------------------------------------
Burning Hands        Cmbt  T      3s    -      Both
Charm Person         Cmbt  12     1     -      Both
Detect Magic         Both  6      1   2r/lvl   Both
Enlarge              Both  .5/lvl 1   1t/lvl   Both
Friends              Cmbt  0      All 1r/lvl   Both
Magic Missle         Cmbt  6+lvl  1     -      Both
Protection from Evil Camp  0      1   2r/lvl   Both
Read Magic           Camp  0      1   2r/lvl   Both
Shield               Cmbt  0      1   5r/lvl   Both
Shocking Grasp       Cmbt  T      1     -      Both
Sleep                Cmbt 3+lvl   1-16 5t/lvl  Both



2ND-LEVEL MAGE SPELLS
SPELL NAME          WHEN RNG   AREA      DURATION ROBE
--------------------------------------------------------
Detect Invisibility Both T/lvl  1        5r/lvl  Both
Invisibility        Both T      1           -    Red
Knock               Camp 6      1s/lvl      -    Red
Mirror Image        Both 0      1        2r/lvl  Red
Ray of Enfeeblement Cmbt T    1+25s/lvl  1r/lvl  White
Slinking Cloud      Cmbt 3     2x2s      1r/lvl  Both
Strength            Camp T      1        6t/lvl  Red


3RD-LEVEL MAGE SPELLS
SPELL NAME                 WHEN RNG    AREA DURATION   ROBE
------------------------------------------------------------_
Blink                      Both  0      1    1r/lvl    Red
Dispel Magic               Both  12    3x3s     -      White
Fireball                   Cmbt 10+lvl 2/3rad   -      Both
Hastle                     Both  6     4x4s  3r+lvl    Red
Hold Person                Cmbt  12    1-4   24/lvl    White
Invisibility 10-' Radius   Both  T      2dia   -       Red
Lightning Bolt             Cmbt 4+lvl  4,8     -       Both
Protection fr. Evil 10'Rad Both  T      2dia 2r/lvl    White
Protection fr. Normal Misl Both  T      1    1t/lvl    White
Slow                       Cmbt 9+lvl  4x4s  3r+1/lvl  Red



4TH-LEVEL MAGE SPELLS
SPELL NAME               WHEN RNG AREA    DURATION   ROBE
-----------------------------------------------------------------
Bestow Curse             Cmbt T     1      1t/lvl    White
Charm Monster            Cmbt 6     1        -       White
Confusion                Cmbt 12   2-16    24+1/lvl  White
Dimension Door           Cmbt 0     1        -       Red
Fear                     Cmbt 0    6x3cone 1r/lvl    Red
Fire Shield (2types)     Both 0     1      2r=1/lvl  Both
Fumble                   Cmbt 1/lvl 4 dia     -      Both
Min Globe of Invlnrblly. Both 0     1      1r/lvl    White
Remove Curse             Both T     1         -      White


5TH-LEVEL MAGE SPELLS
SPELL NAME               WHEN  RNG   AREA       DURATION   ROBE
-----------------------------------------------------------------
Cloudkill                Cmbt  1     3x3s       tr/lvl     White
Cone of Cold             Cmbt  0     .5s/lvl cone   -      Both
Feeblemind               Cmbt 1/lvl  1              -      White
Fire Touch               Both  T     Special    1r/lvl     Red
Hold Monster             Cmbt .5/lvl 1-4        1r/lvl     White
Iron Skin                Both  0     Special    1r/lvl     Red



6TH-LEVEL MAGE SPELLS
SPELL NAME               WHEN RNG     AREA     DURATION   ROBE
--------------------------------------------------------------------
Death Spell              Cmbt  1      .5x/lvl Instantaneous    Both
Disintegrate             Cmbt .5/lvl  Special Instantaneous    Red
Globe of Invulnerability Both  0        1      1r/lvl          White
Stone to Flesh           Both 1/lvl     1     Permanent        Red
Flesh to Stone           Cmbt 1/lvl     1     Permanent        Red


7TH-LEVEL MAGE SPELLS
SPELL NAME               WHEN RNG       AREA  DURATION  ROBE
-----------------------------------------------------------------
Delayed Blast Fire Ball  Cmbt 10+1/lvl  2rad  Special   White
Mass Invisbility         Both 1/lvl Special   Special   Red
Power Word, Stun         Cmbt .5/lvl      1   Special   Both


8TH-LEVEL MAGE SPELLS
SPELL NAME                WHEN   RNG     AREA   DURATION   ROBE
-----------------------------------------------------------------
Mass Charm                Cmbt   .5/lvl Special Special    White
Mind Blank                Both    3       1       1day     White
Otto's Irresistible Dance Cmbt   1t       1       2-5r     White
Power Word, Blind         Cmbt   .5/lvl 3dia    Special    Both


GLOSSARY OF AD&D GAME AND COMPUTER TERMS

Ability Scores. These are numbers that describe the attributes of the
characters. There are six ability scores: Strength, Intelligence,
Wisdom, Dexterity, Constitution and Charisma.

Adventurer. This is a term for one of the characters you play in this
game.

Alignment. This is the basic philosophy of a character. See Alignment
in the Character Classes section.

Armor Class (AC). This is a rating of how difficult a target is to
damage.  The lower the AC number the more difficult it is to hit.

Character. This is another name for one of the persons you play in the
game.  A party consists of up to six characters.

Class. This is a character's occupation. For example mage, fighter or
cleric are classes.

Command. A one or two-word option in a menu. Activating that command
allows you either to view another menu or have your characters perform
an action.

Encounter. This is what happens when a party meets a monster. You are
given a menu of choices of how you want to handle the situation.

Enter. The act of giving a command to the computer. How this is done
varies depending on the computer.

Experience Points. Every encounter the characters have yields
experience points for every character depending on how successful the
encounter was for the party. A character who gains enough experience
can advance a level.

Facing. In combat, a character faces a certain direction. An attack
from the direction he is not facing has a greater chance of doing
damage. A character will always face an opponent if he has only one
opponent.

Hit Points (HP). This is a measure of how healthy a character is.
Damage from weapons subtracts hit points from the character's total.
When he has lost all of his hit points, he is unconscious and dying.
If his wounds are bound by another party member, he is simply
unconscious.

Icon. This is the small picture of a monster or a character seen
during combat. Character icons can be altered using the Alter command
in the Camp Menu.

Initiative. This is a semi-random determination of which character in
a combat acts first. The characters with higher dexterity's have a
better chance for a higher initiative.

Level. This describes the power of a number of different items. The
power of characters, dungeons, monsters and spells are all described
with levels.

Character Level. This is a determination of how much experience a
character has. The higher the level, the more experienced and
important the character is. High-level spellcasters can cast
high-level spells.

Spell Level. Spells come in degrees of difficulty. The higher the
level of the spell, the greater the difficulty. Only very experienced
magic-users and clerics can learn high-level spells.

Magic. This term covers spellcasting, enchanted items and any other
application of the supernatural.

Melee Combat. This is hand-to-hand combat with weapons such as swords,
spears and fists.

Missile Combat. This is ranged combat with weapons such as bows and
arrows, crossbows and quarrels and slings and slingstones.

Monster. This term actually includes human and other player races as
well as ogres and dragons. In general, if it isn't part of your party,
it's a monster. Monsters are not necessarily hostile, some may be
helpful.

Multi-Class Characters. Non-human characters may belong to two or
three classes at the same time. Such multi-class characters split
their experience among all their classes, even if they have reached
their racial maximum class.

Non-Player Character (NPC). This is a member of a player race who is
not controlled by the player. Some NPCs can be brought into a party.

Party. The group of adventurers you form to perform the missions you
are given. A party can be reformed for each adventure and even altered
during the course of an adventure.

Player Character (PC). This is a member of a player race who is
controlled by the player. The characters in your adventuring party are
PCs.

Race. The species characters may belong to in the game. For example
human, elf or dwarf are races.

Spell. This is a magic incantation that can alter the nature of
reality.  Magicusers, clerics and high-level knights, paladins and
rangers can cast spells after memorizing them. If the spell is cast,
it is gone from the user's mind and must be re-memorized.

Spell Book. The book a magic-user carries his spells in. If he doesn't
have a magic book, he has no spells to memorize.

THAC0 (To Hit Armor Class 0). This is the number that a character must
make or exceed to hit an opponent with AC0.