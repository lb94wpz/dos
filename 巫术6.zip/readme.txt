WIZARDRY, BANE OF THE COSMIC FORGE Walkthru
IBM version
This walkthru is copyright (c) 1991 by Wyvern. All rights reserved.
Wyvern@cup.portal.com


     Bane of the Cosmic Forge is the sixth game in the Wizardry Series by
SirTech. As is typical in games of this form there is no straight forward
solution. A lot of your time playing the game will be spend exploring and
fighting while you develop your characters. This walkthru will discuss each
of the major areas that make up the game, pointing out items of importance,
solving puzzles and recommending strategy when appropriate.

STARTING THE GAME:
     I know, you've loaded the game and you are anxious to play. So was I
and I rolled up what I thought were okay characters and blundered on in and
later ended up restarting the game from scratch.
RULE NUMBER ONE: Take you time rolling up your characters! Do not accept
any character with less than an 18 bonus! I realise that this means you
will be spending a lot of boring time just rolling up characters. Believe
me, it is time well spent. Everything that will later happen to your
characters will be greatly influenced by the initial roll up. Be patient
and take your time rolling up your characters. The better the bonus, the
happier will be your game! When you can spare the bonus points, put extras
into strength. Your characters' capacity to carry weight is determined at
the beginning of the game based upon this stat and will not change through
out the rest of the game. Being able to carry heavier loads will prove
useful.
     You are allowed to create six characters for your party. You need to
have a party that is versatile in abilities. As you play the game you will
be able to change professions and further widen your available skills. To
start you need some good fighters, good magic users, thief skills and some
cleric ability. There are numerous combinations that will supply all these
ingredients. Read the manual carefully, especially the description of
classes and races.
     These characters proved useful in my own game as well as that of
friends of mine. The important thing to remember is NEVER take less than a
18 point bonus no matter how long it takes to get it!
     Faerie      -     Valkyrie
     Dracon      -     Ninja
     Rawulf      -     Monk
     Review your characters before starting the game. Equip them at this
point so that they are all armed and armored before you enter dangerous
territory.

NOTE ON ASCII MAPS:
     Ascii maps leave a lot to be desired. There is simply no easy way to
simulate graph paper nicely. I include ascii maps because they will prove
helpful, but do not look for absolute accuracy in this crude medium. Map on
your own with graph paper and my ascii maps will prove more helpful. As
they are they will provide a rough guide in particular areas within this
game. Maps, unless otherwise noted, will always be oriented so that North
is at the top. I will not necessarily include all treasure chests that can
be found within a particular map area, but those of importance will be
included.

LOCKED GATES and DOORS:
     There are lots of locked gates and doors through out this game. Some
of them you will never be able to open. In most cases there will be another
way beyond the gates or doors than opening them. If you find another way
beyond the gate or door, forget about getting it open. If you haven't, keep
trying. Something will turn up later in the game.

TREASURE CHESTS:
     Sometimes what a chest contains is predetermined but often the
treasure is random in nature. If you didn't like what you found in a chest,
or were unable to use any of it given your characters' professions, restore
and try again.

INVENTORY:
     There are a lot of undroppable items in this game. Some of them will
disappear from your inventory when they have been used in the correct
place. Others will stay with you for the whole of the game. The game will
not let you drop an important item. This can cause problems later in the
game when encumbrance capacity or number of items carried is reaching max.
As much as is possible, try to keep the inventory load and number
distributed between all your characters. Pay attention that no one
character is carrying too much. This will slow them down and make them
easier targets. Fortunately the encumbrance number <CC> will change color
making it easy to spot when a character is over loaded.

BEGIN GAME STRATEGY:
     Save your game often! Save before trying to OPEN anything! Save when
all your characters have survived a battle. SAVE SAVE SAVE! This game is
very very tough at the beginning and you will probably have to RESTORE
often. Though it is possible to resurrect characters, decide now that you
will never ever take that option, restore your game instead! This decision
will prove useful in the beginning of the game for reasons that will be
clarified below.

CASTLE:
     After finally completing your party <don't forget to equip them> you
begin the game in a castle. For the sake of reference, we'll call this
level 1. A rough ascii map of this area is below.

CASTLE LEVEL 1:
   a b c d e f g h i j k l m n o p q r s t
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|     U = Stairs UP
02|#|#|#|#|#|#|#|#|#|#|D|#|#|#|#|#|#|#|#|#|     D = Stairs DOWN
03|#|#|#|#|#|#|#|#|#|#|g|#|#|#|#|#|#|#|#|#|     d = door
04|#|#|#|#|#|#|#|#|#|$    |#|#|#|#|#|#|#|#|     g = gate
05|#|#|#|D  |#|#|#|#|     |#|#|#|#|  D|#|#|     F = Fountain
06|#|#|U|#| |#|#|#|#|__g__|#|#|#|#| |#|U|#|     $ = treasure
07|#|#|     _____          ^  _____     |#|     ^ = Button on Wall
08|#|#|#|#| |   |#|#|#| |#|#|#|   | |#|#|#|
09|#|#|#|#| |__d|#|#|U| |U|#|#|__d| |#|#|#|
10|#|#|#|#| |   |#|#       #|#|   | |#|#|#|     You start this game entering
11|#|#|#|#| |   d     |#|     d   | |#|#|#|     through the gates at the
12|#|#|#|#| |__d|#|#   F   #|#|__d| |#|#|#|     south of the map to the left
13|#|#|#|#| |   |#|#       #|#|   | |#|#|#|     From your beginning position
14|#|#|#|#| |___|#|#       #|#|___| |#|#|#|     head north and open the 2
15|#|#|#|#| ___U|#|$       $|#|D__| |#|#|#| <-- chests <identified as "$"s
16|#|#|#|#| |   |#|#       #|#|   | |#|#|#|     on the map. Neither chest is
17|#|#|#|#| |__d|#|#  ___  #|#|d__| |#|#|#|     trapped and the goodies in-
18|#|#|#|#| |   |#|#___ ___#|#|   | |#|#|#|     side will prove useful.
19|#|#|#|#| d                     d |#|#|#|     Among the items you will
20|#|#|#|#| |__d_______g_______d__| |#|#|#|     find is an Amulet of Life
21|#|#|#|#| |     |#|#| |#|#|     | |#|#|#|     which casts Resurrection.
22|#|#|#|#| |_____|#|#| |#|#|_____| |#|#|#|     If you have decided to
23|#|#|          U|#|#|g|#|#|U          |#|     follow my advise an never
a24|#|#|U|#| |#|#|#|#|#| |#|#|#|#|#| |#|U|#|     resurrect a character, you
25|#|#|#|D  |#|#|#|#|#| |#|#|#|#|#|  D|#|#|     will be able to sell this
26|#|#|#|#|#|#|#|#|#|#| |#|#|#|#|#|#|#|#|#|     item and buy stink bombs
27|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|     and fire bombs which will
   a b c d e f g h i j k l m n o p q r s t

prove to be greatly useful in getting the odds evened out a bit until your
characters have a chance to establish themselves. The Fountain on this
level restores stamina which can prove useful.
     Gather up the goodies from the two chest at locations 15i and 15m  and
head for the stairs down at 25r. You will come back later to explore all
the rooms on this level, gathering the experience that will come from
opening the locked doors and fighting the monsters. The other item of
importance on this level at 4j. To get to it, you must press the button at
6m. Search the corner and you will find the KEY OF RAMM. But first, lets go
down those stairs:

CASTLE BASEMENT 1:

   a b c d e f g h i j k l m n o p q r
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   From the stairs head to the room
02g      U|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   with the "QQ" <17i>. In this room
03|#|#|d|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   you will encounter QueeQueg. Don't
04|#|#|d|#|#|G|G|G|G|#|G|G|G|G|#|#|#|#|   kill him, talk and trade with him.
05|#|#|  U|#|__       __      |#|U  |#|   He has lots of items to sell and
06|#|#| |#|D|_g  g    g_|#|#|#|#|#| |#|   will buy items from you. Sell your
07|#|#|     |_g | |___g_|  ___      |#|   Amulet of Life. WIth the profits
08|#|#| |#|#|_g |d|_d 4$| | 5 |#|#|#|#|   invest in stink bombs and cherry
09|#|#| |  $|_g_|d__d___| |__d|#|#|#|#|   bombs. Avoid scrolls at this time
10|#|#| |  _|#|#|         | 6 |#|#|#|#|   since you need skill to use them.
11|#|#| |d|d|d|d|  ___    d___|#|#|#|#|   bombs work skilled or not. QQ's
12|#|#| |  _    | |   |   d 7 |#|#|#|#|   inventory can change everytime
13|#|#| | |_g 3 d d 11|   |___s#|#|#|#|   you enter the room, so if you do
14|#|#| |_______| |___|   F#|#|#|#|#|#|   not see what you need the first
15|#|#|      ___   ___     U|#|#|#|#|#|   time, exit and try him again. Save
16|#|#|#|#| | 2 | |   |   F#|#|#|#|#|#|   your game anytime you have bought
17|#|#|#|#| |   d d QQ|   | 8 |#|#|#|#|   something that you really wanted.
18|#|#|#|#| |d|d| |___|   d___|#|#|#|#|   Invest most of your money into the
19|#|#|#|#| | |_|         d 9 |#|#|#|#|   bombs, but spend some of it on
20|#|#|#|#| |^|#|         |__d|#|#|#|#|   better equipment. This is a good
21|#|#|#|#| | 1 | |#|#|#| |10 |#|#|#|#|   time to pick up extended range
22|#|#|#|#| |__$| |#|#|#| |__$|#|#|#|#|   weapons for those characters in
23|#|#|           |#|#|#|           |#|   the back of the group.
24|#|#| |#|#|#|#|#|#|#|#|#|#|#|#|#| |#|   Once you are well armed with bombs
25|#|#|  U|#|#|#|#|#|#|#|#|#|#|#|U  |#|   and better equipment you are ready
26|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   to really begin exploring. Go back
   a b c d e f g h i j k l m n o p q r
G = unopenable gates

upstairs to Level 1 and begin exploring the rooms there. All the doors are
locked so you will be giving your thief, ninja or bard some experience with
their skulduggery skill. This can be very frustrating as the authors made
the the doors more difficult to open than is appropriate at this early
stage in the game. Keep trying, saving and restoring as needed. In some
encounters you will get iron or copper keys. These are meant to open the
doors on Level 1 or the Basement. Try them if you wish, but picking the
locks will gain you skulduggery experience which will continue to be
valuable through out the whole game. After completely exploring level 1 and
getting the KEY OF RAMM return to the Basement.
     Unlike level 1, the rooms of the basement are much more interesting,
containing treasures, clues and puzzles. To make things a little easier to
explain, I have numbered the rooms. I will only discuss those rooms in
which there is something of interest.
     ROOM 1:  This room is only reachable by pressing a secret button
indicated on the map as a "^". The treasure to be found in this room is
very nice including a Heraldic Shield which will increase strength if you
decide to invoke its powers <which also means the loss of the item> and a
sword of striking.
     ROOM 3: is the PIRATES DEN. You will not be able to enter this room
until you have learned the password. Queequeg can tell you the password but
will only do so after you tell him where the captain's treasure is buried.
You'll be able to find that out later in the game.
     ROOM 4: Searching the northeast corner you will find the JAILORS KEY
which will open the gate at 6h and many of the gates, though not all, that
you find beyond the gate. Searching the area north of 6h you will find the
DEADMAN'S LOG. Unfortunately it is in code, so you cannot translate it at
this time.
     ROOM 5: Here you will find a WINE BOTTLE which will be of use much
later in the game.
     ROOM 7: There is a lot of graffiti written on the walls here. Two of
the messages are of importance. One tells of a reward being offered for
SNOOPCHERI and the other indicates that there is a mouse hole on the East
wall.  See Room 10 below.
     ROOM 10: In the southeast corner of this room you will find some
rotten cheese. Using this cheese at the mouse hole you located in room 7
will cause crazed rats to break down the wall and attack you. This is a
tough battle. Save your game and try it. If you seem to die to easily,
change your tactics and try again. If you're still dying, put this off
until a little later. When you are able to successfully defeat the rats,
you will be able to follow the hallway they opened up to you. At the end of
the hall is another door, another encounter and eventually a chest. Among
the treasures to be found is SNOOPCHERI <stuffed beagle> <see TOWERS to
learn what to do with him>.
     QQ:   Be sure to purchase MYSTERY OIL from QuegQuee!

CASTLE TOWERS:
Corner Towers:
     There are four corner towers in the castle. If you continue up the
stairs in any of the corners <southeast, southwest, northeast, northwest>
you will eventually reach the top. There is something in each of the
towers, but the one of most importance is the SouthEast tower. As you were
climbing these stairs for the first time, you noticed a figure ahead of
you, always just out of range. When you reach the top and locate his door,
he will tell you to go away. You will have an opportunity to "talk" and you
should reply "SNOOPCHERI". GIVE the stuffed beagle to L'Montre and in
return he will give you a SILVER KEY. This key will open a gate inside the
Pirate's Den, room 3 in the basement. You can sell and buy things from
L'Monte.

SPADE KEY TOWER:
     See Room #1 in section on Level 2.

     Move to level 1 to the stairs leading up at 25g <see map for level 1>
and we'll begin exploring Level 2.


CASTLE LEVEL 2:

   a b c d e f g h i j k l m n o p q r s
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| U = stairs up
02|#|#|#|#|#|#|#|  _____  |#|#|#|#|#|#|#| D = stairs down
03|#|#|#|#|#|#|#| |F   F| |#|#|#|#|#|#|#| d = door
04|#|#|     |#|#| |  8  | |#|#|     |#|#| , = door
05|#|#|D|#| |#|#|U|__ __|U|#|#| |#|D|#|#| g = gate
06|#|#|#|U  . G______g______G    U|#|#|#| G = unopenable gate
07|#|#|#|  ___|     | | __g | __|#|#|#|#| F = fountain
08|#|#|#| |$|,| |#|D| |D|   |_d_|#|#|#|#| $ = treasure
09|#|#|#| |10 |__U|#| |g|___|,|,|#|#|#|#| ^ = button on wall
10|#|#|#| |d__d  9  |___^_d     |#|#|#|#|
11|#|#|#| |   |__d__|     |  7  |#|#|#|#| The plot begins to thicken as you
12|#|#|#|G|___  .         d     |#|#|#|#| explore the rooms on Level 2. You
13|#|#|#|  ___d_.    __d__|__d__|#|#|#|#| will pick up some interesting
14|#|#|#|   U#|D.   |  5  |  6  |#|#|#|#| clues and treasure.
15|#|#|#|    _d .   |_____|$___d|#|#|#|#|
16|#|#|#|#|#|         ___,___,|^|#|#|#|#| The door at 10e cannot be opened.
17|#|#|#|#|#|d|____d__| 3   | 4 |#|#|#|#|
18|#|#|#|#|#| 1 |  2  |__d__|   |#|#|#|#|
19|#|#|#|#|#|  $|     d | |#|#|#|#|#|#|#|
20|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m n o p q r s

     It is more difficult to open the doors on this level than it has been
on the previous levels. Trying will gain you skulduggery skill and is worth
the effort. If, however, you find it too frustrating, read the description
of Room #1 to learn where to find the CHROME KEYS which will open some of
the doors on this level.

     ROOM 1: In the Southeast corner of this room you will find two SPADE
KEYS. If you need the CHROME KEYS, return to Level 1 and take the stairs at
9j up. These stairs will lead you up to a door. Use one of the SPADE KEYS
to open the door. This room is guarded by a undead monster. When you defeat
him, you will find a chest. In the chest are the CHROME KEYS.
     ROOM 4: This was the room of Rebecca. You will learn more and more
about her as the game progresses.
     ROOM 6: This is the King's library. Search the Southwest corner to
find the King's Diary and the GOLD KEY. In the closet to the Southeast you
will find a button on the wall which opens up into Rebecca's room #4.
     ROOM 7: This is the King's Suite. Explore the room to the south <room
# 6>. In the closet to the Northwest of this room, you will find a button
that will open up a hall leading to two gates. The KEY OF RAMM will open
these gates. You will need more than just the key to do the Temple but you
can, if you wish, open the chest at 9k to find the GOAT MASK and the DAGGER
OF RAMM. See Castle Temple Below for more.
     ROOM 8: This is the Temple of Ramm. In the center of the room is an
altar. There are two fountains, one in the northwest corner <poisonous> and
one in the northeast corner <healing and stamina>. See TEMPLE OF RAMM.
     ROOM 9: The Queen's bedroom provides the only access to room 10.
     ROOM 10: This is the Queen's boudoir. There is a treasure to be found
in the northwest closet.
     The stairs at 14e lead up to the BELL TOWER which will be discussed
later in this walk thru.
     Having completed as much of this level as is possible at this time
return to the Basement and head for the stairs at 6f leading down.

CASTLE BASEMENT 2:
   a b c d e f g h i j k l m n o p q r
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   Exploring this long hall you will
02|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   find two gates and a door at the
03|#|#|#|#|#|#|#|#|#|#|#|  $  |#|#|#|#|   far east end. The GOLD KEY opens
04|#|#|#|#|#|#|#|#|#|#|#|     |#|#|#|#|   the gate in the middle at 6m. Open
05|#|#|     |#|#|#|#|#|#|_ 1 _|#|#|#|#|   the gate and enter the door you
06|#|#| |#|U|#|#|#|#|g|#|#|g|#|#|#|d|#|   find beyond. You will see three
07|#|#|                             |#|   pits in the floor. If you care to
08|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   try a very difficult encounter
09|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   jump into one of the pits. Save
10|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   your game before you do though!

ROOM 1:
   a b c d e f g h i    In the center of the room is a pressure plate. Step
01|#|#|#|#|#|#|#|#|#|   on it. The square to the north will turn into a
02|#|#| 3 ' $ '   |#|   pit. Go to 2 and SEARCH <push> the button on the
03|#|#|.  . p .  .|#|   south wall. This will fill in the pit on the west
04|#|#|   .   .   |#|   side of the room. Go to 3 and push the button on
05|#|#| p . 1 . p |#|   the west wall. Go to 4 and push the button on the
06|#|#|           |#|   west wall. You now will be able to approach the
07|#|#|         2 |#|   middle north wall. Push the button there to find
08|#|#|#|#|ddd|#|#|#|   the treasure chest. Inside the chest is the BOOK
09|#|#|#|#|4  |#|#|#|   of RAMM and some other treasures. USE the book
10|#|#|#|#|ggg|#|#|#|   while in REVIEW and note carefully what it says.

Now its time to visit the Temple off of the King's Bedroom. Return to Level
2 and to the King's Bedroom.

CASTLE TEMPLE:
     Prepared with the KEY and BOOK OF RAMM, you are ready to do the
temple. Note the description of this room under Level 2, room 8. Save your
game at this point as there are some tough times ahead. Go to the altar in
the middle of the room. <note: it is not visible> You will be presented
with buttons to push. The order was described in the text in the BOOK OF
RAMM: push GOAT GOAT ORB STAVE ORB. The altar will drawback revealing a
pit. Jump into the pit. This puts you into the room on Level 1 in which you
found the KEY OF RAMM. You will be confronted with a large and nasty
serpent. Defeat him and the gate to the north will open. The gate to the
south and to the rest of the castle is locked so you have nowhere to go but
north. Go down the stairs to the north.

HAZARDOUS AREA:

   a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
02|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   |#|#|       |#|#|#|
03|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   |#|   |#| 3$|#|#|#|
04|#|#|       |#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| |#|   |#|#|#|#|#|#|#|
05|#|#| |#|#|   |#|#|#|#|#|#|#|#|#|#|#|#|#|$|#|#|#|#| |#| |#|     |#|#|#|#|
06|#|     |#|#|   |#|#|#|#|#|#|#|$4 |#|#|#|s|#|$  |       |#| |#|   |#|#|#|
07|     |#| |#|#| |#|-|#|#|#|#|#|   |#|#|#| |#| 1   |#|       |#|#| |#|#|#|
08|   |#|    D|#| |# C #|     |#|#| |#|#|#|   |#|#|#|#|   |#|#|#|   |#|#|#|
09|#|     5_|#|#| |# H #| |#|       |#|#|#|#|   |#|     |#|#|#|#|   |#|#|#|
10|#|   |#|   |#|    A    |#|#|#|#|#|#|#|   |#|     |#|#|#|#|#|#|#|#|#|#|#|
11|#|#|       |#|#|# S #| |#|   |#|#|#|#|   |#|   |#|#|#|#|#|#|#|#|#|#|#|#|
12|#|#|#|#|#|#|#|#|# M #| |#|       |#|#|#|         |#|#|#|#|#|#|#|#|#|#|#|
13|#|#|#|#|#|#|#|#|#|-|#|   |#|#|#| |#|#|#|#| |#|   |#|#|#|#|#|#|#|#|#|#|#|
14|#|#|#|#|#|#|#|#|#|#|#|#|              :s  #|#|     |#|#|#|#|   |#|#|#|#|
15|#|#|#|#|#|#|#|#|   |#|#| |#|#|#|#|#|#|#|#|#|       |#|         |#|#|#|#|
16|#|#|#|#|#|#|#|#|         |#|#|#|#|   |#|#|#| |#|#|     |#|#|#|#|#|#|#|#|
17|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|g__|#|#|#| |#|#|#|#|#|#|#|#|#|#|#|#|#|
18|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|                                 |#|#|
19|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| |#|#|#|#|#|#|#|g|#|#|#|U|#|#|#|g|#|#|
20|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|g|#|#|#|#|#|#|#|       |#|$2     |#|#|
21|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   g      U|#|#|G.G.G.G|#|G.G.G.G|#|#|
22|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   |#|#|d|#|#|#|__ JAIL  ________|#|#|
23|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|d|#|#|#|__       __|#|#|#|#|#|
24|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  U|#|#|__ | |_____|
25|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| |#|D|#|__ |d|_d   | |#|#|#|#|
26|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|     |#|__ |dd_d___| |#|#|#|#|
27|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| |#|#|#| BASEMENT    |#|#|#|#|
  a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J
G = unopenable gates         : = rubble

     This area is hazardous, especially if you explore it randomly. I'm
going to make things a little easier on you by telling you the fastest way
to exit this area and return to the main castle. From the stairs which you
went down after defeating the giant serpent <19C on this map> go west to
the first opening to the north 17w. Work your way to the room with the
number 1. In the northwest corner you will find the DUNGEON KEY which will
open the locked gates <g on the map> in this area. Return the way you came
and continue down the hall to the west and then south. Open the gates at
20r and 21s. The doors further along this hall lead back to the BASEMENT 1
level of the castle. Now that you know how to get out, it's time to explore
the rest of this area.
     Explore this area any way you want to, returning to the castle to rest
when necessary but be certain to visit and search the areas listed below:
     Go to the 2 on the map <20E> to find the DECODER RING. In REVIEW mode
use the Decoder Ring on the Deadman's Log to learn that the captain buried
his treasure in the Giant Mountain.
     Go to 3 on the map <3G> to find the MINER'S PICK. Use the pick on the
rubble at 6u and 14t. The first will reveal a chest the second will open up
further areas for exploration.
     Go to 4 to find the BELL KEY.
     You're now ready to do a few more things back in the castle so return
to BASEMENT 1.

PIRATES DEN:
     Visit QuegQuee and ask him about the PASSWORD for the Pirates' Den. He
will ask you where the captain's treasure has been buried. Tell him GIANT
MOUNTAIN. He will tell you that the password is SKELETON CREW. Now go to
the Pirates Den <see the map of Basement 1 if you don't remember where it
is, Room 3 on that map>. You will have to defeat Captain Matey either in
combat or by out drinking him. Once you have defeated him, you can use the
SILVER KEY you got from L'Montes to open the cage in the center of the
room. Inside the cage you will find a number of treasures including a HOOK
and a Green Parrot which will increase the personality stat if used.
     Now it is time to visit the BELL TOWER.

BELL TOWER:
     Go to Level 2 and to the stairs on that map at location 14e. Climb up
to the top. Here you will find a well and the bell rope. Choose to use the
rope to swing across to the far side. Both sides look exactly alike and the
only way to tell if you have made it across is if you find the door locked.
Once you get to the locked door use the BELL KEY. Inside you will find a
chest which contains ROPE. Once you have the ROPE, MERGE the ROPE with the
HOOK you got in the Pirates Den. Return the way you came and return to the
Hazardous Area. You're now ready to cross the CHASM you found in the
HAZARDOUS AREA.

CHASM:
     Use the ROPE & HOOK to cross the Chasm. It works in both directions so
you needn't worry about getting stuck on the far side. Just before you
reach the area on the HAZARDOUS AREA MAP listed as "5", SAVE your game. 5
is a very tough battle with Hydraplant. If you find that this encounter is
just too difficult at this time, spend some additional time improving your
characters in the castle area and try this again a little later.
     Once you defeat the Hydraplant you will find a button <marked as D
near the 5 on the Hazardous Area map> which went pushed opens a chute to
below. <Don't worry, you can return by this route.> Heading to the west you
will come to the MOUNTAIN AREA.

MOUNTAIN AREA:

   a b c d e f g h i j k l m n o p q r s t u v w x y z
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
02|#|#|#|#|       |#|#|       |#|#|#|#|#|#|#|#|#|#|#|#|
03|#|#|     |#|#|   |#| |#|#| |#|   U = leads back to chasm & castle
04|#|   |#|     |#|       |#|     |#|#|#|#|#|#|#|#|#|#|
05|#| |#|   |#| |#|#|#|#|   |#| |#|#|#|#|#|#|#|#|#|#|#|
06|#|#|   |#|   |#|     |#| |#|     |#|#|#|#|#|#|#|#|#|
07|#:   |#|#|#|#|   |#| |#|   |#|#| |#|#|#|#|#|#|#|#|#| : = path from the
08|#| |#|#|#|     |#|     |#|     |#|#|#|#|#|#|#|#|#|#|     pyramid
09|#|         |#|#|   |#| |#|#|#|   |#|#|#|#|#|#|#|#|#|
10|#|#| |#|#|#|     |#|#|     |#|#|       |#|#|    1 #| = Wizard's Cave
11|#|#|   |#|#| |#|     |#|#|     |#|#|#|       |#|#|#|
12|#|#|#|   |#|   |#|#|#|#|   |#|     |#|#| |#|#|#|#|#|
13|#|#|#|#| |#|#|   |#|     |#|#|#|#|   |#|   |#|#|#|#|
14|#|#|#|#|   |#|#|#|     |#|   |#| |#| |#|#|      2 #| = Mines
15|#|#|#|#|#|         |#| |#|#|     |#|     |#|#| |#|#|
16|#|#|#|#|#|#|#|#| |#|#|#|^|#|#|#| |#|#|#|   |#|   |#|
17|#|#|#|#|#|#|#|#|#|#|#|#|   |#|#|     |#|#|   |#|#|#|
18|#|#|   |#|#|#|#|#|#|#|#|#|     |#|#|t    |#|   |#|#| t = Troll Bridge
19|#|   |#|#|  ^|#|#|#|#|#|#| |#| |#|#| |#| |#|#| |#|#|
20|#| |#|#|   |#|#|#|#|#|#|^|#|#|   |#| |#|   |#|  3 #| = Mines
21|#|   |#| |#|#|#| |#|#|   |#| |#|     |#|#| |#|#|#|#|
22|#|#|     |#| |#|       |#|#|   |#|#|   |#| |#|  4 #| = Mines
23|#|   |#|#|#|   |#|#|#|       |#|#| |#| |#|     |#|#|
24|#| |#|#| |#| |#|#| |#|#|#| |#|#|   |#|   |#|#|#|#|#|
25|#| |#|   |#|   |#|   |#|   |#|   |#|   |#|     |#|#|
26|#|     |#|#|#|   |#| |#| |#|#| |#|#|#|#|#|#|#| |#|#|
27|#|#|#|     |#|#| |#| |#|   |#|     |#|     |#|  5 #| = Mines
28|#|   |#|#|   |#|     |#|#|     |#|     |#| |#| |#|#|
29|#|#|  c /    |#|#| |#|#|   |#|#| |#|#|#|#|d|#| |#|#| d = drawbridge
30|#|   |#|#|     |#|     |#|#|     |#|   |#|     |#|#| c = catapult
31|#| |#|#|#|#|#|#|#| |#|       |#|#|   |#|#|#|#|#|#|#|
32|#|   |#|#|#|       |#|#| |#|#|     |#|     |#|#|#|#|
33|#|#|         |#|#|   |#|       |#|     |#|      6 #|
34|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m n o p q r s t u v w x y z

     You enter the Mountain Area from the north at 3k. Head east and make
your way to Mines entrance <# 2 on above map>. If you want to check out the
Wizard's Cave at this time, you will learn that there isn't much that you
can explore at this time due to dead ends and a gate.

MINES:
     There are four levels to the mines and LOTS of stairs, so many that it
is very easy to become confused. I suggest that you print out the maps for
the mines, levels 1-4, and color code the stairs to make things a little
easier for yourself.

MINES LEVEL 1:
   a b c d e f g h i j k l m n o p q r    The numbers 1 - 6 on the west of
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   this map coorespond with the
02|# 1        |#|#|#|#|#|#|#|#|#|#|#|#|   numbers on the east of the Moun-
03|#|#|#|#|#|       |#|#|#|#|#|#|#|#|#|   tain area map.
04|#|#|#|#|#|#|g|#|_|#|#|#|#|#|#|#|#|#|
05|#|#|#|#|  _  |#|#|#|#|#|#|#|#|#|#|#|   D = stairs down
06|# 2  |#| |#|_  |#|#|#|     |     |#|   U = stairs up
07|#|#| |#| |#|#|_ U|#|#|     |     |#|   g = gate
08|#|#| |#|_  |#|#|#|#|#|   __|__g__|#|   ' = dark area
09|#|  _  |#| |#|  ____U|#|       |#|#|   $ = treasure
10|#|_|#| |#| |#| |#|#|#|#| |#|#|#|#|#|
11|#|#|#| |#|_____________g_  |#|#|#|#|   In the dark area in the southeast
12|# 3__  |#|#|#|#|#|#|#|#|#| |#|' '|#|   there is a treasure consisting of
13|#|#|#|  ___  ____  |#|  D|_ '|' '|#|   a night stick, shadow cloak, KEY
14|# 4  |    D| _D|#|____ |  D|'|#|'|#|   OF A-MINER, and a few other items.
15|#|#| |#| |#|____D|#|  _| |' ' ' '|#|   To locate this treasure you must
16|#|#|   |___  ___D|#|  _  |'|#|#|#|#|   SEARCH at 21p.
17|#|#| |___    |#|  D| |#|  _|#|' '|#|
18|#|#|__D|#| |___  |#|__D|___ ' ' '|#|   To make your life much easier,
19|#_5___ |#|____D|_ _   D|#|#|'|#|'|#|   familiarize yourself with the path
20|#| _D|____  _  |#|#| |#|' ' _ ' '|#|   to the stairs at 25i. These stairs
21|#| |  __D| |#|_         '|#|$ ' '|#|   lead to a dark area on level 2.
22|#|   |#|#|__D|#| |#|#|#|#|#|#|#|#|#|   From these stairs go south 2 and
23|#|#|_   _  |#|  _|#|#|#|#|#|#|#|#|#|   west 2. You will find yourself in
24|#|#|  _|#| |#| |#|#|#|#|#|#|#|#|#|#|   a 2x2 room with a fountain. This
25|# 6  |#|#|  D|  D|#|#|#|#|#|#|#|#|#|   fountain will restore EVERYTHING,
26|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   hits, stamina and magic. REMEMBER
   a b c d e f g h i j k l m n o p q r    its location and visit it often!!

MINES LEVEL 2:
   a b c d e f g h i j k l m n o p q r s       U = stairs up
11|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      D = stairs down
12|#|#|  ,d d   |#|#|   |  __D|  _d   |#|      $ = treasure
13|#|#|d| |#|__d|#|#| |_  |U____|#|  R|#|      , = secret door <button>
14|#|#|d|$|#|U_d|U_____D|_  |U__  |#|#|#|      d = door
15|#|#|   |#|   |#|U_____D| |#|#|  D|#|#|      F = fountain
16|#|#|   d |R__|#|U________|  $| |#|#|#|      R = Rubber Monster
17|#|#|#|#|  ___d 1 |U_____D|d__|_  |#|#|      1 = Smitty's
18|#|#|#|U__|  $|___|   |U____|  D| |#|#|      - = dark area
19|#|#|#|#| d___|U__dd__|U__________|#|#|      This map is aligned with the
20|#|#|U____|  _d  $| |#|#|#|#|#|#|#|#|#|      map of Level 1. Stairs down
21|#|#|   |U  |#|___| |#|#|#|#|#|#|#|#|#|      from Level 1 are in the same
22|#|#|,__d_d_|U______|#|#|#|#|#|#|#|#|#|      position on this map but are
23|#|#| |- _-_-_-_-_--|#|#|#|#|#|#|#|#|#|      obviously UP stairs here.
24|#|#|$|-|R  d_d |#|-|#|#|#|#|#|#|#|#|#|
25|#|#|- -|__ |U__|U -|#|#|#|#|#|#|#|#|#|      The FOUNTAIN at 26g should
26|#|#|-|#|- -|F  |#|-|#|#|#|#|#|#|#|#|#|      become your "home base". It
27|#|#|- - - -|____-_-|#|#|#|#|#|#|#|#|#|      will restore hits, stamina
28|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      AND magic!
   a b c d e f g h i j k l m n o p q r s

     There are a number of things to accomplish on Level 2. You need to
defeat the 3 Rubber Monsters <13r, 16f & 24e> to get RUBBER STRANDS. The
treasure at 24c, behind a secret door, includes the MINER'S CHISEL. The
other treasures on this level contain interesting items, but nothing of
great significance. Smitty's shop <#1 on the map> has superior weapons than
those available from QuegQuee or L'Monte in the castle, especially for a
Samurai.

MINES LEVEL 3:

   a b c d e f g h i j k l m n o p q r s       This map is aligned with the
11|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      map of Level 2. Stairs
12|#|#|#|#|#|#|#|#|#|#|$g   |U____d  R|#|      leading from 2 to 3 or 3 to
13|#|#|#|#|#|#|#|#|#|#|#|d__|  D|#|__d|#|      2 are in the same position
14|#|#|#|#|#|#|#|#|#|#|U__|   | _D|#| |#|      on these maps.
15|#|#|#|#|#|#|#|#|#|#|#|U__|_  |#|U__|#|
16|#|#|#|#|#|#|#|#|#|#|  $|#|#|___  |#|#|      On this level you will be
17|#|#|#|#|#|#|#|#|#|#|d__|U_ | _D|__D|#|      able to fight your 4th Rubber
18|#|#|#|#|#|#|#|#|#|#| |#|   | |U  |#|#|      Monster and get a 4th RUBBER
19|#|#|#|#|#|#|#|#|#|#|_____|____D|  D|#|      STRAND. MERGE 1 rubber strand
20|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      with another to get a RUBBER
   a b c d e f g h i j k l m n o p q r s       BRAID. Do this with the other

2 rubber strands. Now MERGE the 2 rubber braids to get 1 RUBBER BAND.
     The gate at 12k is opened with the KEY OF A-MINER.

MINES LEVEL 4:

   a b c d e f g h i j k l m n o p q r s t u v w     This map is aligned
11|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|    with the map of level
12|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| _________d|#|    3. On this level you
13|#|#|#|#|#|#|#|#|#|#|#|#|#|#|U____| d |#|. _|#|    will find another gate
14|#|#|#|#|#|#|#|#|#|#|#|#|#|#|$|U_ | |_:$1 |#|#|    <14o> which opens with
15|#|#|#|#|#|#|#|#|#|#|#|#|#|#|g  d_| |#|. _: |#|    the KEY OF A-MINER.
16|#|#|#|#|#|#|#|#|#|#|#|#|#|#|___|  _|d _|#|d|#|    You do not *need* to
17|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|U__|U__|  R| |#|    fight the rubber mon-
18|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  ___d___| |#|    ster on this level.
19|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|U__|U________|#|
20|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m n o p q r s t u v w

     Exploring this level you will find that there is a entity trapped in
the gem that makes up the squares 14t, 14u, 15t, 15u. Use the MINER'S CHISEL
to fracture the four sides of the gem. You last blow on the gem should come
from the location 16t. The gem should break, if it doesn't, try all four
sides again and again hit the last blow from location 16t.
     Breaking the gem, you will meet the spirit of Xorphitus. Read his long
tale and then search the area at 14t to find the WIZARD'S KEY, WIZARD'S RING
and a number of other interesting items. Return to Level 1 of the Mines.
     The WIZARD'S KEY will open the gates at <map of Level 1> 8p, 11l and
4g. In the 3x3 room north of the gate at 8p you will find Xorphitus'
apprentice. Talking to him will give you the clue that the Wizard's Lair
back in the castle can be opened with the WIZARD'S RING. This will be
discussed after we have completed the Mountain Area. The other two gates
opened by the Wizard's Key lead you to the Wizard's Cave.
     Move to Stairs 4 on the LEVEL 1 map <14b> and exit the mines. Using the
map for the MOUNTAIN AREA, head for the TROLL BRIDGE. SAVE your game before
you reach the bridge <18s>. The Troll will ask if you will pay to pass. He
will take a LOT of money if you decide to pay. He is difficult to fight but
worth a lot of experience points. I recommend fighting him. If you find,
after a couple of attempts, that you are unable to defeat him, consider
returning to the mines for a while to build up your characters. Heading
south from the bridge, head for the "^" at 16m. You will be able to climb up
the mountain at this area. SAVE your game before climbing as you can fall
and take a lot of damage. You will need to climb up 3 times. At the top of
this place you will find large BOULDERS. Take 1 and climb <you can still
fall> back down.
     Return to the Mines and move to stairs 5 on the Level 1 map <19b>.
Heading south and around a corner you will come upon a DRAWBRIDGE control
panel which is rusted. Use the MYSTERY OIL you bought from QuegQuee back in
the castle. You will then be able to open the control panel and read some
very *clear* instructions on how to operate the mechanism. The proper
sequence is: Safety, Pump, Coil, Truss, Safety, Winder. The drawbridge will
lower allowing you to explore the areas beyond. If you move to location 20m
you will find another place where you can climb up <or fall down> the
mountain. Again there are three times you will need to climb and saving your
game is recommended. At the top of this location you will find the Captain's
Chest! Unfortunately, QuegQuee has been there before you and left you naught
but a bag of trinkets. oh well
     Return to the mines and move to stairs 6 on the Level 1 map <25b>. Move
to the c on the Mountain Area map <9d> where you will find a broken
catapult. SEARCH the catapult to find the BROKEN SPOCKET. Take the sprocket
to Smitty in the mines to fix. If you have killed Smitty, you should have
some Liquid Metal. Merging the sprocket and the liquid metal will also fix
the sprocket. Return to the catapult and USE the SPROCKET, RUBBER BAND and
BOULDER on the catapult. SAVE YOUR GAME BEFORE FIRING! Use the latch, wind
up the rubber band and release the latch! Your boulder may not hit the
target. If it doesn't, restore your game and try again until it does.
Hitting the target will cause the pit east of the catapult to be filled in
and allow you to explore further. Moving to location 19g on the Mountain
Area map and you will find the thrid and last area where you can climb up
the mountain. Again, save your game!
     At the top of this area you will find an arch that leads into the home
of the Gryns Twyns. They are a difficult encounter. If you find that you are
not able to defeat them after several tries, return to the mines for further
character development. After you have defeated the Twyns, rest and heal your
party. Take the stairs up. Here you will find the Guardian of the Rock which
you will need to defeat to get the first ruby eye. Cast Missile Shield and
use Acid Splash/Bomb during combat. Once you have won the RUBY EYEBALL, do
back down the stair and take the opening to the northeast. On this ledge you
will find a closet with a button. The button will open a chute and the area
leading to the PYRAMID.

PATH TO PYRAMID:

   a b c d e f g h i j k l m n
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
02|#|#|#|#|#|#|#|#|#|#|#|#|
03|#|#|#|#|#|#|#|#|#|#|     |#|
04|#|#|#|#|#|#|#|#|#|   |#| |#|
05|#|#|#|#|#|#|#|#|#| |#|   |#|
06|#|    U|#|#|#|#|#|#|   |#|#|
07|#|d|#|   |       :   |#|#|#| : = obstruction, use pick. This will open up
08|#|   |__d| |#| |#| |#|#|#|       the path back to the Mountain Area map
09|#|   d   d_|d  |#|         |     and to the castle.
10|#|#|#|d  |   |#|#|#| |#|#|#|
11|#|#|#| |#|  .|#|#|#|   |#|#| . = obstruction, use pick
12|#|     |#|#| |#|#|#|#|   |#|
13|#|S|#|#|#|#|         |#| |#| S = sand
14|#|#|#|#|#|#|#|#|#|#| |#|   |
15|#|#|#|#|#|#|#|#|#|#| |#|#|
16|#|#|#|#|#|#|#|#|#|#|     |#|
17|#|#|#|#|#|#|#|#|#|#|#|#|  C| = CHUTE from TWYN'S Mountain
18|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m n

     Use the MINER'S PICK at 11g and 7i. Move the stairs leading up at 6d.
These stairs will lead to a short hall with more stairs leading up to Level
1 of the Pyramid.

PYRAMID:

     There are lots of stairs in the Pyramid. As in the mines, you sometimes
have to go up and down several in order to reach an area on the same level
from which you started. Color coding the stairs can help reduce the
confusion.

PYRAMID LEVEL 1:

   a b c d e f g h i j k l m       You enter this level of the Pyramid from
01|#|#|#|#|#|#|#|#|#|#|#|#|#|      the stairs at 9h on this map.
02|#| . |#|  _  |#|  _  .#|#|
03|#|   |^|_  | |#|_  |d  |#|      Move to the "G" <9g> on this map. You
04|#| |___  | |___  |U|_| |#|      will have to go up to level 2 and come
05|#|  _  |U| |  $|U|  _  |#|      back down by other stairs to get here.
06|#|#|#|_ d|_d___|  _|#|#|#|      The "G" represents the Gloop Sploch
07|#|  _  | chest |D|#|   |#|      Monster. Defeat it to get some GLOOP.
08|#| |#| |_______|#|U__| |#|
09|#|   |__U|  G|D   ___  |#|      With the GLOOP, move to the large center
10|#|#|_d | d___|U| |U|#|#|#|      room <with the word "chest"> going up and
11|#| . d_| |#|  _| |__ . |#|      down stairs as needed. In this room you
12|#|       |#|           |#|      will find a chest. As you approach it, it
13|#|#|#|#|#|#|#|#|#|#|#|#|#|      jumps to the far side of the room. Use
   a b c d e f g h i j k l m       the GLOOP on any of the east or west

walls. Chase the chest again. It will get stuck in the GLOOP allowing you to
finally catch it. Opening the chest reveals a BONE KEY.
     Next move to the treasure at 5h. In this chest you will find a BAG.
Fill the BAG with SAND that you found on the Path to the Pyramid.
     At 4d and 3d you will find buttons on the wall. Push them.

PYRAMID LEVEL 2:                         PYRAMID LEVEL 3:

   a b c d e f g h i j k l m                a b c d e f g h i j k l m
01|#|#|#|#|#|#|#|#|#|#|#|#|#|            01|#|#|#|#|#|#|#|#|#|#|#|#|#|
02|#|#|#|#|#|#|#|#|#|#|#|#|#|            02|#|#|#|#|#|#|#|#|#|#|#|#|#|
03|#|#| _#|  #|  _   _  |#|#|            03|#|#|#| .  _  |#| . |#|#|#|
04|#|#| |dd_  | |  _|D| |#|#|            04|#|#|#|# dd^| |D|   |#|#|#|
05|#|#|   |D|U|d|U|D|_  |#|#|            05|#|#|#| | |D| |_d_| |#|#|#|
06|#|#|#|_d_|#|   |_  |#|#|#|            06|#|#|#|  _|_d_|U__g |#|#|#|
07|#|#|  _d   |__s|#|_  |#|#|            07|#|#|#| |^|d_D|C|^|#|#|#|#|
08|#|#| |#|___|U_____D| |#|#|            08|#|#|#| .d|_  |_dd. |#|#|#|
09|#|#|   |D__  | d |   |#|#|            09|#|#|#|           |#|#|#|#|
10|#|#|#|_  |#| |D| |D| |#|#|            10|#|#|#|#|#|#|#|#|#|#|#|#|#|
11|#|#|               |#|#|#|            11|#|#|#|#|#|#|#|#|#|#|#|#|#|
12|#|#|#|#|#|#|#|#|#|#|#|#|#|            12|#|#|#|#|#|#|#|#|#|#|#|#|#|
13|#|#|#|#|#|#|#|#|#|#|#|#|#|            13|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m                a b c d e f g h i j k l m

PYRAMID LEVEL 4:

   a b c d e f g h i j k l m       Continue to explore the Pyramid, building
01|#|#|#|#|#|#|#|#|#|#|#|#|#|      up your characters. Pushing buttons <"^"s
02|#|#|#|#|#|#|#|#|#|#|#|#|#|      on the maps where every you find them.
03|#|#|#|#|#|#|#|#|#|#|#|#|#|      When you feel ready to try something more
04|#|#|#|#|         |#|#|#|#|      challenging, fill your BAG with SAND if
05|#|#|#|#| |#| |#| |#|#|#|#|      you have not already done so and head for
06             Q D| |#|#|#|#|      the stairs down at 7i on Pyramid Level 1
07|#|#|#|#| |#| |#| |#|#|#|#|      map. This takes you to the Pharoh's Tomb.
08|#|#|#|#|         |#|#|#|#|
09|#|#|#|#|#|#|#|#|#|#|#|#|#|      You will not be able to open the gate on
10|#|#|#|#|#|#|#|#|#|#|#|#|#|      Pyramid Level 3 until you have completed
11|#|#|#|#|#|#|#|#|#|#|#|#|#|      the Pharoh's Tomb.
12|#|#|#|#|#|#|#|#|#|#|#|#|#|
13|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m

PHAROH'S TOMB:

   a b c d e f g h i j       ^ = button on wall
01|#|#|#|#|#|#|#|#|#|#|      s = secret wall, disappears when correct button
02|#|#|#|#|#|#|#^   |#|          is pushed.
03|#|#|#|#|#|#^ s  d|#|
04|#|#|#|#|#|#|#|#| |#|      The BONE KEY opens the gate to the Pharoh's
05|#|#|#|#|#|#|#|#| |#|      Tomb. As you begin the walk down the long hall
06|#|#|#|#|#|#|#|#| |#|      you will notice the pressure plates on the
07|#|#|#|#|#|#|  ^  |#|      floor. Don't run down this hall. At 14f you
08|#|#|#|#|#|#| |#|#|#|      will step on a pressure plate that will open
09|#|#|#|       |#|#|#|      pits at locations 15f and 12f. Push the button
10|#|#|#| |#|#|#|#|#|#|      at 13f to close these pits.
11|#|#|#| |#|     |#|#|      At locations 15d, pushing the button on the
12|#|#|#| |#| |#| |#|#|      wall will open the wall at 16c/d. Push the
13|#|#|#| |#| ^#| |#|#|      button at 16c. Doing so prevents a giant ball
14|#|#|#| |#| |#| |#|#|      ala Indiana Jones from chasing you down this
15|#|#|#| ^#| |#| |#|#|      section of the hallway.
16|#|#^ s     |#|g|#|#|      Continue down the hall to location 7h and push
17|#|#|#|#|#|#|#| |U|#|      the button on the south wall. A pit will open
18|#|#|#|#|#|#|#|   |#|      just behind you at 7g. Jump/move into this pit.
19|#|#|#|#|#|#|#|#|#|#|      See map of PIT 1 below:
   a b c d e f g h i j

PIT 1:         PIT 2:
   a b c d e     h i j k l m n o p q     PIT 1 is a small pit with buttons
01|#|#|#|#|#|   |#|#|#|#|#|#|#|#|#|#|    on either end. Push/SEARCH the
02|#|#|#|#|#|   |#|#|#|#|#|#|  _  |#|    button at the west end <3b> to
03|#^   |#|#|   |#|#^ ^        _| |#|    move to location 10l in PIT 2.
04|#|#|   ^#|   |#|#|#|g|#|#|     |#|
05|#|#|#|#|#|   |#|#|     |#|#|#|#|#|    In PIT 2 move to the button at
06|#|#|#|#|#|   |#|^|     |#|#|#|#|#|    7k and push it which opens the gate
07|#|#|#|#|#|   |#|d|#| ^#|#|#|#|#|#|    at 4k and fills in the pit at 9j
08|#|#|#|#|#|   |#| |#| |#|#|#|#|#|#|    <"/" on the map>. Go to 6i and push
09|#|#|#|#|#|   |#|  /    |#|#|#|#|#|    the button on the north wall. This
10|#|#|#|#|#|   |#|#|#|#|  /|#|#|#|#|    deactivates an arrow trap. Move to
11|#|#|#|#|#|   |#|#|#|#|#|#|#|#|#|#|    3k and push the button on the west
   a b c d e   g h i j k l m n o p q     wall. Enter the small room just

opened and push the button at 3j. Now head east down the hall. You will have
a major encounter at 3n with AmenTutButt and his friends, so save your game
BEFORE you reach them. Once you have defeated Amen, you can enter the alcove
<3o> where the IDOL is kept. SAVE YOUR GAME! Once your game is saved, you
can attempt to switch the BAG OF SAND for the IDOL. This does not always
work successfully. If it didn't for you, restore and try again.
     Once you have the IDOL, retrace your steps and jump in the pit at 10m.
This places you back in PIT 1. This time push the button on the east wall
which in turn returns you to 7h on the PHAROH'S TOMB MAP. Continue east,
north down the hall on that map and SEARCH for the button at 2h. Now push
the button at 3g which will allow you to return to the stairs back up to the
pyramid.
     Once back in the PYRAMID, make your way to the GATE on LEVEL 3. USE the
IDOL to open the gate. Climbing the stairs at 6h on the Pyramid Level 3 map
you will meet the Queen of the Amazulu on Level 4. She will ask you if you
have come to take the "rock" <another RUBY EYEBALL>, answer "NO". Give the
Queen a gift of mimimal value, healing potion, or something of similar
value. After you have finished talking with the Queen, the High Priestess
will ask if you wish to trade. She has many books and potions for sale, some
of which may prove useful to you inspite of their realatively high price.
She also sells some FOOT POWDER. BUY SOME!
     After you finish talking to the High Priestess, USE THE FOOT POWDER and
continue WEST. <without the use of the foot powder this walk would burn you.
Levitate will also prevent this, but unless you are capable of casting it at
a high level, you could still sustain lots of damage>. At the end of the
west ramp you will encounter MAU-MU-MU. Cast any anti fire spells you have
early in this encounter. Defeat Mau-mu-mu and you will gain the second RUBY
EYEBALL.
     You can, even after taking the RUBY EYEBALL, revisit the Queen and her
High Priestess repeatedly, or you can fight them for the experience points
and a very deadly Spear of Death <it does 1d5+4 damage, adds +1 to Thrust,
and poisons those it hits>.
     You have now completed the Pyramid and the Mountain Area and it is time
to return to the CASTLE BASEMENT 2.

CASTLE:
BASEMENT 2:
   a b c d e f g h i j k l m n o p q r   Using the WIZARD'S RING on the gate
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  at 6j you will be able to enter the
02|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  Wizard's Lair. The Lair is guarded
03|#|#|#|#|#s   d |$   $|  $  |#|#|#|#|  by a Demon Cat from Hell. Cast
04|#|#|#|#|#|   |^s     |     |#|#|#|#|  fire protections spells and defeat
05|#|#|     |#|#|#|$   $|_ 1 _|     |#|  this guardian. There are 4 chests
06|#|#| |#|U|#|#|#|#|g|#|#|g|#|D|#|d|#|  in this room. One contains books,
07|#|#|                             |#|  another potions, a third scrolls,
08|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  and the fourth the WIZARD'S LOG and
09|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  the SPIRE KEY.
10|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  Search the west wall to open a

secret door behind which you will find the Stave of Moons <4h> which does
2d4 damage, +1 Bash and Sleep. Push the button on the North wall to gain
access to another room. In the southwest corner of this room you will find
still more treasure including a Ruby Talisman which can increase
Intelligence. On the north side of the room you will find laboratory
chemicals. Be sure your party is healthy before messing around with the
chemicals. You should not find it very difficult to cause an explosion. This
explosion will open the wall at 3e which leads back to the Wizard's Cave in
the Mountain Area.
     In REVIEW mode, USE the WIZARD'S LOG. You will find that something is
locked up in the Spire. Move to the stairs at 9l on the CASTLE LEVEL 1 MAP
and stair up. On the next level you will find a gate which is opened by the
SPIRE KEY. Continue up to the top where you will find a door which can be
opened by the SPADE KEY. In this room you will meet a spirit who will tell
his tale of woe. At the end of this tale you will get the HORN OF SOULS.
Return to the CASTLE BASEMENT 2 and move to the end of the hall and place
the RUBY EYEBALLS in the door.
     The door is now opened and passing through you will go down a set of
stairs and find yourself on the Castle Pier on the RIVER STYX.


RIVER STYX:
     The RIVER STYX is a huge area that wraps upon itself <that is: if you
travel to the northwest <or southeast> long enough you will eventually
return to where you begain>. This area is really much to large to map
conveniently in ascii form so I will give you a basic lay out instead:

           _            ___________
         _|                        |__
       _|          ______             |
castle|            |isle |            |
pier  |           _| of  |_           |
------           |         |        __|
|                |  the    |       |$  |
|                |  dead   |       |_| |
|                -----------           |
|                                    __|
|_______                            |
stairs___                           |
up to|   |                        __|
swamp    |                      _|
         |__                   |
           |X        ____      |
           |_       |    |     |
             |       Keep|     |
             |_                |
               |_              |
                 |_            |
                   |__         |     ___
                      |_       |____$_  |
                        |           |_| |
                   isle of              |
                   the lost           __|
                       _|            _|
                     _|            _|_
                    |          _  |_| |
                    |         | |___  |
                    |         |_____| |
                    |               |$|
                   _|          sirens |
                  |                 __|
                  |             ___|
                  |             |
                  |             |
               bottle           |
               oracle___        |
                       |         isle of
                       |         the
                       |         damned
                      _|         |______
                      |                |
                      |                |
                      |                |
                      |_               |
                        |              |
                    hook &             |
                    line               |__________
                        _|                        |__
                      _|          ______             |
               castle|            |isle |            |
               pier  |           _| of  |_           |
               ------           |         |        __|
               |                |  the    |       |$  |
               |                |  dead   |       |_| |
               |                -----------           |


     On the CASTLE PIER, you will find a circle in the south center section
of the pier. Stand on this circle and USE the HORN OF SOULS. Charron, the
ferryman, will appear. He will ask if you want passage and if you have any
ashes for him. Passage cost 500gp. You have no ashes at this point, so pay
for passage. Charron will take you to the ISLE OF THE DAMNED.

ISLE OF THE DAMNED LEVEL 1:
   a b c d e f g       g = gate                F = Fountain
01|W|W|#|#|#|#|#|      W = water               D = Stairs down
02|W|W|#|#|#|#|#|      O = circle for summoning Charron
03|W|Wr   |   |#|      r = raft
04|W|W|g.g|g.g|#|
05|W|W|    ___|#|      Move to 7d where you will find the KEY OF THE DAMNED
06|W|   . |  F|#|      and the BOOK OF THE DAMNED. Move to the gate at 10d
07|W|O  .$g  D|#|      and open it with the KEY OF THE DAMNED. Save your
08|W|     |__F|#|      game. Move to 11d where you will have an encounter
09|W|W|       |#|      with Minos. Defeat him and you will gain, among some
10|W|W|g.g|g.g|#|      other interesting items, the KEY OF MINOS and a.
11|W|Wg  $|  g|#|      CYLINDER OF ASH (1).
12|W|W|W|W|W|W|#|
   a b c d e f g       Open the gate at 7d so that you have access to the

FOUNTAINS inside. The fountain on the North restores hits and stamina. The
fountain on the South restores magic points. Use these fountains as often as
you need. You can now open up the rest of the gates on this map with the KEY
OF THE DAMNED. In each of the small rooms you will have an encounter. Use
SILENCE on these monsters! You will find another CYLINDER OF ASH (2). At 3c
you will find a raft. Do NOT use it until you have explored ISLE OF THE
DAMNED LEVEL 2.

ISLE OF THE DAMNED LEVEL 2:

   a b c d e f g h i j       From the stairs take the hall all the way east
01|#|#|#|#|#|#|#|#|#|#|      to the end. You will have an encounter with
02|#|#|             |#|      undead monsters. After defeating them, you will
03|#|#| |*| |*| |*| |#|      be able to get the TOMB KEY from the chest.
04|#|#|             |#|      Open the gates at 8g and 9e with the TOMB KEY.
05|#|#| |*| |*| |*| |#|
06|#|#|             |#|      Explore each of the tombs <* on the map>. At
07|#|#| |*| |*| |*| |#|      some of these tombs you will have encounters
08|#|#|________g____|#|      with undead when you search the bones. SILENCE
09|#|U_____g________$#|      is a useful spell in these encounters though
10|#|#|             |#|      not always effective. Save your game before
11|#|#| |*| |*| |*| |#|      you search any of these tombs just in case.
12|#|#|             |#|
13|#|#| |*| |*| |*| |#|      In the tomb furthest to the northeast you will
14|#|#|             |#|      find the BOOK OF THE SIRENS. In REVIEW mode
15|#|#| |*| |*| |*| |#|      USE this book. Write down the last lines of
16|#|#|             |#|      the Siren's song! After you have completely
17|#|#|#|#|#|#|#|#|#|#|      explored this level, return to Level 1 and go
   a b c d e f g h i j       to the raft at 3c on that map.

     Take the raft. It will take you to the Siren's Cove. Soon the sirens
will gather around you and start singing the song you read in the BOOK OF
THE SIRENS. When they reach the last line, they will ask you to fill in the
words. Type "Tis madness makes us free". Correctly completing the SIren's
Song will get you the WATER WINGS and the sirens will leave. You can take
the raft back to the isle of the dead. Equip one of your characters with the
WATER WINGS. While facing water, USE the WATER WINGS. You will now be able
to "walk" anywhere on the water and begin your exploration of the River
Styx.

NOTE: Once you have the WATER WINGS you are free to explore all the areas of
the River Styx with the exception of the Isle of the Dead and the Swamp.
There is NO particular order in which you should explore though you may find
some areas more difficult to handle than others. Use the fountains on the
Isle of the Damned as your "home base" for these explorations. Do follow the
walls carefully so that you locate the various cubbyholes in which treasure
may be lurking. Making your own map of this area is advisable.

HOOK & LINE:
     Southwest of the Isle of the Damned is square upon which you can land
and a door. Behind the door is a small room with a chest. In the chest is a
HOOK and a LINE and a CORK BOBBER. MERGE the hook and line into a HOOK &
LINE. For what to do with the HOOK & LINE see "X MARKS THE SPOT" below. For
what to do with the CORK BOBBER, see BOTTLE ORACLE below.

LOST & FOUND:
     Northwest of the Isle of the Damned is the Lost and Found. Search the
northwest wall to find a button opening a secret passage. You will find a
message scrawled on the wall saying "Lost at Sea DJ Locker Red X 3e 1n" and
a door. Open the door and then return to the main room and search the
southwest corner to locate the KEY OF THE LOST. This key will open the gate
which was beyond the door. Beyond the gate is a chest containing some random
treasures and a CYLINDER OF ASH (3).

THE KEEP:
     North of the Lost and Found is the Keep. Mai Lai will tell you that the
Keep is a storage facility. You can trade with her and she has some
excellent items for sale. If you do not find what you want in her inventory,
exit and re-enter. Her inventory will change every time providing you with a
wide selection of useful, tempting and expensive equipment. Beyond her is a
locked door which you will not be able to open until you attempt to claim
the hookah pipe <see SWAMP below for details>. Word of warning: Mai Lai will
run off when you try to reclaim the hookah pipe and she will NOT return so
do not reclaim the pipe until you are certain that you no longer wish to
trade with Mai Lai.

X MARKS THE SPOT:
     From the Keep move to the west wall and move north until you locate the
Red X. Recalling the message on the wall of the Lost & Found, go 3 squares
east and 1 north. USE the HOOK & LINE. You will snag a locker in which you
will find a Linx Ring, a Wand of Ghosts and the EAST EXIT KEY.

SWAMP:
     Move to the west wall and continue north, following the wall, until you
find a set of stairs leading up. At the top of the stairs there is a gate
which you can open with the EAST EXIT KEY.

   a b c d e f g h i j k l m n o p q r   C = caterpillar
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
02|#|#|W|W|W|W|W|W|W|W|W|W|W|W|W|W|W|W|  The encounter in the swamp can be
03|#|#|W|     |W|W|#|               |W|  difficult. Casting Silence will be
04|#|#|W| |#|     |W| |W|W|#|#|W|W| |W|  very helpful as will Missile
05|#|#|#| |W|W|W| |W|           |#| |W|  Shield. If the encounters seem too
06|#|#|   |W|     |#|W| |#| |#| |W| |W|  difficult, return to the River Styx
07|#|   |W|#| |W|#|       |#|   |#| |W|  and build up your characters some
08|#|#|W|W|   |W|W| |W|W|#|   |#|#| |W|  more.
09|#|#|W|   |W|     |W|#|   |W|#|   |W|
10|#|#|W| |W|#|W|W| |W|W| |#|W|#|   |W|  Exploring this area thoroughly you
11|#|#|W|           |#|W| |#|W|#|   |W|  will find the Caterpillar <17o>. He
12|#|#|W|W|W|   |W|W| |W| |W|W|W| |#|W|  has some interesting items for sale
13|#|#|#|#|#|#| |#|W|         |W|W|#|W|  which you might wish to buy. Do buy
14|#|#|#|D____g |W|W|W|W|W|#| |#|W|W|W|  some INCENSE from him for use in
15|#|#|#|#|W|   |W|W|#|W|W|W|     |W|W|  the Isle of the Dead. Talk to him
16|#|#|#|#|W|W|   |#| |#|W|#|     |W|W|  about his pipe. You'll soon gather
17|#|#|#|#|#|W|W|       |W|W|#|C|W|W|W|  that he left it at the Keep and say
18|#|#|#|#|#|#|W|W|W|W|   |W|W|W|W|W|W|  the key word to use there is
19|#|#|#|#|#|#|W|W|W|W|W|W|W|W|W|W|W|W|  "reclamation". Ask the caterpillar
   a b c d e f g h i j k l m n o p q r   about "claim number" and he will

recall that he has forgotten the number but that it can be learned by using
the BOTTLE ORACLE. He will give you instructions on how to use the Bottle
Oracle and a MESSAGE. MERGE the message with the wine bottle <you got it way
back in the castle> and then MERGE the message in the bottle with the cork
bobber. Return to the River Styx and head for the Bottle Oracle.

BOTTLE ORACLE:
     At the location of the Bottle Oracle USE the message in the bottle with
the cork stopper and watch it float away. Now head for the LOST & FOUND. On
the shore of the L&F you will find a bottle containing the ANSWER, i.e. the
claim number which happens to be 38-23-36.

HOOKAH PIPE:
     You may claim the hookah pipe from the keep anytime you have pieced
together the information described in the sections on the SWAMP and the
BOTTLE ORACLE by telling Mai Lai at the Keep that you want to make a
"reclamation". As mentioned before, reclaiming the pipe will result in Mai
Lai running off never to be seen again. Once you have the pipe, you GIVE it
to the Caterpillar. He will ask you if you want to "get small", say yes and
you will get some RED MUSHROOMS. The caterpillar will then disappear never
to be seen again. I recommend that you save reclaiming the pipe and giving
it to the caterpillar until after you have completely explored the Isle of
the Dead.

ISLE OF THE DEAD:
     Return to the circle on either the Castle Pier or the Isle of the
Damned. SAVE YOUR GAME. Use the Horn of Souls to call Charron. When he asks
you if you have any ashes for him say yes. GIVE Charron the ashes. One
cylinder of ashes will get you 500gp. Another cylinder of ashes will result
in stat increases <generally 2 per character>. The third cylinder of ash
Charron will say you must return yourselves. He will give you the KEY OF THE
DEAD. Go to the entrance to the Isle of the Dead <north side of the isle>
and open the gate with the KEY OF THE DEAD.

ISLE OF THE DEAD Level 1:

   a b c d e f g h i   There is not much of anything on this level but you
01|W|W|W|W|W|W|W|W|W|  will have an encounter at 7e which will give you a
02|W|W|W|W| |W|W|W|W|  taste of things to come. If you find that this fight
03|W|W|W|d|g|d|W|W|W|  is killing your characters easily you may wish to
04|W|W|  _____  |W|W|  develop them further before trying this again.
05|W|W| |#|D|#| |W|W|
06|W|W| |     | |W|W|  Spells of particular usefullness in this area are
07|W|   |     |   |W|  dispell undead and silence.
08|W| |#|#| |#|#| |W|
09|W|             |W|  When you feel you are really ready, head down the
10|W|W|         |W|W|  stairs at 5e. You will be in a hall with another set
11|W|W|W|     |W|W|W|  of stairs leading down to level 2.
12|W|W|W|W|W|W|W|W|W|
   a b c d e f g h i

ISLE OF THE DEAD Level 2:

   a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
02|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  3  |#|#|#|#|#|#|#|#|#|
03|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|     |#|     |#|     |#|#|#|#|#|
04|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|         |#| |#|         |#|#|#|#|
05|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   |#|             |#|  $|#|#|#|#|
06|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|         |#|#|#|         |#|#|#|#|
07|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|     |#|     |#|     |#|#|#|#|#|
08|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   |#| |#|    _    |#| |#|   |#|#|#|
09|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#| 2 g   |#|   | |   |#|   g 4 |#|#|#|
10|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|   |#| |#|         |#|_|#|^  |#|#|#|
11|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  s  |#|     |#|     |#|s|#|#|#|
12|#|#|#| | | | |#|#|#|#|#|#|#|#|#|#|#|#|        $|#| |#|         | |#|#|#|
13|#|#|_   ___   _|_   _______________g     |#|   |#| g     |#|   | |#|#|#|
14|#|#|_  |#|#|  _|_  |#| | | | | |#|#|#|         |#|g|#|         | |#|#|#|
15|#|#|_   _|_   _|_               _|#|#|#|  s  |#|     |#|     |#|s|#|#|#|
16|#|#|_   _|_   _|#|_|_|_|_|_|#|  _|#|   |#| |#|         |#|s|#|   |#|#|#|
17|#|#|_   _|_  |#| | | | | | |#|  _|#| 1 g   |#|   |_|   |#|   g 5 |#|#|#|
18|#|#|_   _|                       |#|   |#| |#|         |#| |#|^  |#|#|#|
19|#|#|_   _|#| | | | | | | | | | |#|#|#|#|     |#|     |#|     |#|#|#|#|#|
20|#|#|_   _|#|#|#|#|#|#|#|#|#|#|#|#|#|#|         |#|F|#|         |#|#|#|#|
21|#|#|_ |#|  | | |#|#|#|#|#|#|#|#|#|#|#|   |#|             |#|   |#|#|#|#|
22|#|#|_           _|#|#|#|#|#|#|#|#|#|#|$        |#|g|#|         |#|#|#|#|
23|#|#|#|_|_|_|#|  _|#|#|#|#|#|#|#|#|#|#|#|     |#|^    |#|     |#|#|#|#|#|
24|#|  __ |#|#|_   _|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|  6  |#|#|#|#|#|#|#|#|#|
25|#| |     |#|_   _|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
26|#| | |A| |#|#|  _|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
27|#|U|     g      _|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
28|#|#|#|#|#| | | |#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
29|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J

     Coming down the stairs you will find yourself at location 27b on the
map above. Follow the short hall around and you will see ahead of you a
small altar. USE the CYLINDER OF ASH at the altar. If you purchased it, USE
INCENSE at the altar. The use of incense will neutralize some traps that you
would otherwise encounter later on this level. Having used the ashes, the
gate at 27e will now be open and you are ready to explore the Hall of the
Dead.
     This is a difficult area. If the encounters are too difficult for your
group at this time, return to the River Styx and build them up. Don't try to
do too much at a time and return to the fountains on the Isle of the Damned
as often as you need. Some of the cubbyholes will have encounters, but not
all of them <fortunately>. There are also a few encounters in the hallway.
Continue exploring, fighting, returning to the Isle of the Damned, saving
your game until you reach the cubbyhole at 16m. Save your game before
entering this cubbyhole. The encounter here is very difficult but will get
you the SKELETON KEY.
     Once you have successfully obtained the SKELETON KEY, continue
exploring the Hall of the Dead until you reach the gate at 13r which you can
open with the SKELETON KEY. There is an encounter just beyond the gate, so
save your game!
     Once beyond the gate, you can explore the room <fight> and open the
chest at 12x. In it, you will find the KEY OF THE DROW. Next search for the
secret door on the south wall of this room <15v>. Head for the Fountain that
is at location 20z. This fountain restores hits, stamina and magic and will
become your new "home base" while exploring the rest of this area. Return
here often and save your game, especially after the encounters in the
numbered rooms.

ROOM 1:    Drow
     This is the tomb of Robin Windmarne, Highlander Drow, Guardian of the
1st Order. When you enter this tomb, you will have an encounter with Robin
and many of her friends. This will be, as will be all the other encounters
in the numbered rooms, a difficult fight. Defeating her, you will gain an
Elven Bow, Peacemaker Arrows, Chamail Doublet, Chamail Pants and a Forest
Cape.
     Open the chest at 22t to gain the KEY OF KNIGHTS. Head north and find
the secret passage on the north side of the room at 11v.

ROOM 2:    Knight
     This is the tomb of Sir Geoffrey Clayton, the Black Knight, Guardian of
the 2nd Order. When you defeat him and his companions you will gain a sword
called The Avenger, Ebony Plate both upper and lower, and an Ebony Heaume.
     From the knights tomb, head for and open the chest at 5F to obtain the
KEY OF THE VALKYRIES.

ROOM 3:    Bane King
     You can tackle this room now, or wait until you have completed rooms 4
and 5. You will encounter the Bane King <a vampire> and have to fight him.
You will not win this battle but hopefully, you will not die either. The
King will, after a few rounds of battle, disappear. It is likely that some
of your party will be "insane" or hypnotized after this encounter. If you
have the spell Sane Mind, use it <perhaps repeatedly>. The insanity will
eventually wear off. Searching the north wall of this room you will find a
chest that contains the KEY OF QUEENS. Don't try to do too much until your
party is all in sane mind again.

ROOM 4:    Valkyrie
     This is the tomb of Brigerd Danswolten, High Maenad of Rose, Guardian
of the 3rd Order. Defeating her and her companions will gain you Maenad's
Lance, Mantis Boots and Gloves. Search the southwest corner of this room to
locate a button which will open the wall at 10G. The corridor now opened
will lead you to room 5.

Room 5:    Samurai
     You will find a button on the south most wall of the hall from the
Valkyrie tomb. Pushing the button will gain you access to the tomb of Lord
Haiyato Daikuta, Yojimbo Kaishakunin, Guardian of the 4th Order. You thought
the encounters with the Drow, the Knight and the Valkyrie were tough?? This
is what tough is about! You will confront not only Daikuta but samurias
casting spells and some deadly ninjas. Expect to replay this battle often
before you finally are able to defeat them. When you finally do win you will
gain some excellent weapons and armor specific for samurai class, including
a Wakizashi+1. Unfortunately, I forgot to write down the other items. :(

Room 6:    Queen
     This is the tomb of the Queen, Goddess of Aram who died the year of the
snake. Armed? Ready? Relax! There is no battle in this tomb. Instead the
spirit of the dead Queen will come and tell you a long tale some of which
you should not believe whole heartedly. You will gain the SILVER CROSS and
the KEY OF EVIL from the Queen. Search the northwest corner of the room and
push the button which will open the wall at 16D. Give the SILVER CROSS to
the first character in your group!

     This is a good time to change the professions of a couple of characters
and then spend some time wandering around this area building them up in
levels before going on. It is also a good time to take a good look at your
weapons and armor and see that all characters are as well equipped as
possible.
     If you have not returned the Hookah to the Caterpillar yet, do so now
and get the RED MUSHROOMS from him.

SAVE YOUR GAME. BACKUP THE SAVED GAME TO ANOTHER DISK OR DIRECTORY!

     The KEY OF EVIL will open the gate at 13A. You may wish to save you
game at this point and to make back up copies of those saves to another disk
or directory. SOME OF THE ALTERNATE ENDINGS OF THE GAME DEPEND ON WHAT YOU
WILL DO NEXT SO HAVEING YOU GAME SAVED AND BACKED UP AT THIS POINT IS AN
ADVANTAGE. ALTERNATE ENDINGS WILL BE DISCUSSED AT THE END OF THIS WALKTHRU.
Another good reason to backup your save game at this point is that once you
go beyond this point, you will NOT be able to get back to any of the areas
with which you have become familiar. If you proceed and find that the next
area is too difficult for your party you'd be up the creek without a paddle
if not for the backup of your saved game.

     Having saved your game, you are now ready to explore the remaining
rooms of this area. Opening the gate at 13A, move to the altar at 9z. You
will confront Rebecca here and regardless of what you say to her, she is
going to hypnotize your group and lead them south to 17z where you will meet
the Bane King again. After a brief talk, the King will decide to drink your
blood. The SILVER CROSS will repel him, so it is important that the first
member in your party have the cross. The party will black out, have a vision
and awaken in a Jail.

JAIL:
     Once you wake up you will find yourself in a small room, with a gate, a
fountain <poison> and seemingly no way out. Explore the corners of this room
and you will find some mall cracks. USE the RED MUSHROOMS and shades of
Lewis Carol, you will begin shrinking, running through the cracks and
emerge in a small room on the far side. Exiting you will find a hall leading
west and north. There are numerous doors down the north corridor but nothing
of importance. Heading west you will come to stairs leading to the Forest
Area.

FOREST AREA:

   a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|TEMPLE#|#|#|#|#|#|#|#|#|W|W|W|#|#|#|#|#|
02|#|#|#|#|#|#|#|#|#|#|#|#|#|#|W|#|D|g|D|#|W|W|W|W|W|#|#|W|     |#|#|#|#|#|
03|#|#|#|#|#|#|W|W|#|#|#|#|#|#|   . . . .         |W|#|W|W| |#| |#|#|#|#|#|
04|#|#|#|#|#|D|   |#|   |#|W|W|               |#|           |#|     |#|#|#|
05|#|#|#|#|W| | |#|   |#|W|                 |W|W|#|W|W|#| |#| |#|#| |#|#|#|
06|#|#|W|       |W|#| |W|   |#|#|#|#|       |W|#|       |#|W|       |#|#|#|
07|W|W|W|W|#| |#|W|W| |W| |#|       |#|W|W|#|     |W|W| |W|W|W| |W|#|#|#|#|
08|W|a|W|W|       |#|     |W| |W|#| s$|#|W|   |#|W|W|W|R|W|     |W|#|#|#|#|
09|W|   |W|W|W|#| |#| |#|#|W| |W|   |#|       |W|   |#|- - -|#|#|#|#|#|#|#|
10|W|d _|W|W|     |W|     |#| |#| |#|   |W|#| |W| |#|#|-|#|- - - -|-|#|#|#|
11|W| d_|W|   |#|W| |#|W| |#| |#|     |W|     |#|      -|#|-|#|-|#|-|#|#|#|
12|W|dd_|W|   |W|   |#|         |W|W|W|   |#|W|#|W| |#|#|#|-|#|#|- -|#|#|#|
13|W| d       |#|       |#|W|#|   |W|W|#|       |W| |#|#|#|- -|#|-|#|#|#|#|
14|W| |#|W|W| |#|_|#|#| |W|W|W|W| |#| |W|W|#|#| |#| |#|- -|#|#|#|-|#|#|#|#|
15|W| |W|W|#|           |W|       |W|   |W|W|#| |#| |#|#|- - - - -|#|#|#|#|
16|#|#|#|#|#|#|#| |#|W|W|#| |W|W|W| |#|   |#|#|      - -|#|-|#|- - -|#|#|#|
17|#|#|#|W| |W|W| |W|       |W|$    |#|#|   |#|#|- -|#|-|#|-|#|#|#|-|#|#|#|
18|#|#|#|#| |W|#| |W| |W|W|W|#|W|W|    -|#|- - - -|#|#|-|#|- - -|#|#|#|#|#|
19|#|W|W|   |#|   |#| |#|#|W|W|W|W|W|#|- - -|#|#|#|- - -|#|#|#|-|#|#|#|#|#|
20|#|W|   |#| |#| |W|       |W|f|W|W|#|- -|#|- - - -|#|- - - - -|#|#|#|#|#|
21|#|W|W|         |#|W|W|#|     |W|W|#|#|-|#|-|#|#|- -|#|-|#|#|#|#|#|#|#|#|
22|#|#|#|#|   |#|#|W|#|#|#|#|#|W|W|#|- - -|#|- - -|#|- - -|#|     |#|#|#|#|
23|#|#|#|#|#|   |W|W|#|#|#|#|#|W|W|  - -|#|- -|#|-|#|#|#|#| delphi|#|#|#|#|
24|#|#|#|#|_    |W|#|#|#|#|#|#|#|W|W|#|- - -|#|#|- - - - - -|#|#|#|#|#|#|#|
25|#|#|#|#|#g |W|W|#|#|#|#|#|#|#|#|W|W|W|W|W|W|W|W|W|W|W|W|W|#|#|#|#|#|#|#|
26|#|#|#|#|#|W|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
   a b c d e f g h i j k l m n o p q r s t u v w x y z A B C D E F G H I J

a = altar  g = gate    - = dark forest   R = Rock of Truth
D = stairs down        d = door          W = water
f = Fairy Queen Saeren

     The first place to visit in this large area is the .5 ship <squares 8-
15b & 9-13c>. You will have several encounters getting there and once on
board. If they are too difficult for your party, you may wish to consider
restoring your game to back on the Isle of the Dead. If you are ready for
this area, SEARCH 8b <"a" on the map>. At this make shift altar, you will
find HOLY STAKES of wood. You will need them later.
     From the ship head to 8q and SEARCH to open a tomb of a monk. SEARCH
the tomb to find 3 h2o+, 1 jade figurine and haiya bo. Save the h2o+ for the
temple <see below>.
     At location 8A <"R" on the map> you will find the Rock of Truth. USE
the MINER'S PICK to break off ROCKS OF REFLECTION. These you will also need
later in the temple.
     Start exploring the Dark Forest <"-" on the map> and move to 17o where
you will find a treasure chest. Open the chest to find a TINKERBELL. You can
continue to explore the dark forest and even visit the Delphi at this time,
but you will not know how to respond to his questions.

FAIRY QUEEN:
     Heading to 20o you will see glimpses of fairies who always stay at a
safe distance. When you reach 20o USE the TINKERBELL. Queen Saeren of the
Fairies will come to talk and trade with you. Ask her about the DELPHI. Ask
her how to talk to the DELPHI and she will tell you the answers to the
Delphi's questions.
     The queen has a number of interesting items for sale. I recommend that
you invest heavily in Magic Cookies <restore magic points>, Golden Rods
<healing> and Stamina potions. You will need to trade with the Queen, leave,
use the bell and retrade often to really stock up on these items. As long as
your party can carry the weight of what you buy, buy a lot. When you visit
the Delphi and answer his questions correctly, he is going to take all your
money, so spend it now while you have the chance.

DELPHI:
     After stocking up with the fairies, go see the DELPHI at 23E. He will
ask you who you are. Reply: WE ARE FASCINATION  He will ask you what you
want, reply: WE SEEK DIVINATION   He will ask if you will pay, answer YES.
He will take your money and show you a vision in which you will first see
Xorphitus and the Bane King. Pay CLOSE attention to this vision as it
contains clues on how to defeat them. Delphi will then give you the STAFF OF
ARAM.
     You are now ready to head for the Temple.

TEMPLE:
     The temple is located on the north center side of the map at locations
3qrs. If you take the stairs down you will find gates to jail cells and
little else. At 3 r there is a gate for which you have no key. To gain
access to the Temple, have your first character EQUIP the GOATS HEAD MASK.
The temple guards will believe that you are a member and open the gate.
UNEQUIP the mask as it is cursed and you will not need it anymore.
     Save your game in case you find that the temple is too difficult at
this time.

   a b c d e f g h i j k l m n o p q r s t u v       You enter the temple
01|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      at location 28g on this
02|#|#|#|#|#|#|#|g    |#|#|#|#|#|#|#|#|#|#|#|#|      map. What you will see
03|#|#|#|#|#|     |#| |#|#|#|#|#|#|#|#|#|#|#|#|      will not exactly match
04|#|#|#|#|#|     |#| |#|#|#|#|#|#|#|#|#|#|#|#|      what is on this map but
05|#|#|#|#|#|     |#| |#|#|#|#|#|#|#|#|#|#|#|#|      the differences will be
06|#|#|#|#|#|#|g|#|#| |#|#|#|#|#|#|#|#|#|#|#|#|      explained soon.
07|#|#|#|#|#|#|s|#|#| |#|#|#|#|#|#|#|#|#|#|#|#|
08|#|#|#|#|#| B D |#| |#|#|#|#|#|#|#|#|#|#|#|#|      Continuing north you
09|#|#|#|#|#|  d  |#| |#|#|#|#|#|#|#|#|#|#|#|#|      will come to the end of
10|#|#|#|#|#|#|s|#|#|             |#|       |#|      the ramp and meet
11|#|#|#|#|#|     |#|#|#|#|#|#|#| |#| |#|#| |#|      Xorphitus. He'll dis-
12|#|#|#|#|#| |P| |#|#|#|         |#| |#|#| |#|      appear shorty. EQUIP
13|#|#|#|#|#|     |#|#|#| |#|#|#|#|#| |#|#| |#|      the STAFF OF ARAM! You
14|#|#|#|#|#|#| |#|#|#|#| |#|#|#|#|#| |#|#| |#|      will now be able to
15|#|#|#|#|#|#| |#|#|#|#| |#|#|       |#|#| |#|      walk across the pit at
16|#|#|#|#|#|#| |#|#|#|#| |#|#| |#|#|#|#|#| |#|      24g. Don't try to cross
17|#|#|#|#|#|#|g|#|#|#|#|       |#|#|#|#|#|^|#|      any of the other pits
18|#|#|#|#|#|     |#|#|#|#|#|#|#|#|#|#|#|#|#|#|      or you will fall to
19|#|#|#|#|#|     |#|#|#|#|#|#|#|#|#|#|#|#|#|#|      your death.
20|#|#|#|#|#|  d  |#|#|#|#|#|#|#|#|#|#|#|#|#|#|
21|#|#|#|#|#|#|s|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      Once on the far side,
22|#| 6 | 5 g  $  g 1 | 2 |#|#|#|#|#|#|#|#|#|#|      UNEQUIP the staff as it
23|#|_  |_  |     |  _| __|#|#|#|#|#|#|#|#|#|#|      is cursed. Open the
24|#|       |P|P|P|       |#|#|#|#|#|#|#|#|#|#|      chest at 22g to find
25|#|P|P|P|P|P| |P|P|P|P|P|#|#|#|#|#|#|#|#|#|#|      the KEY OF DECISIONS.
26|#|_  __  |P| |P|  __  _|#|#|#|#|#|#|#|#|#|#|      This key will open
27|#|   |   |-- --|   |   |#|#|#|#|#|#|#|#|#|#|      either of the gates
28|#| 3 | 4 g--D--g 8 | 7 |#|#|#|#|#|#|#|#|#|#|      22e or 22i. It does not
29|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|      matter which gate you
   a b c d e f g h i j k l m n o p q r s t u v       choose to open.

     Every room you enter here will have a difficult battle and I do mean
difficult. Don't save your game <unless you did a backup of a save with your
group outside of the temple recently> until you have determined whether or
not your group is ready for the encounters you will find here.

WARNING: DO *NOT* PUSH EVERY BUTTON YOU FIND IN THIS AREA!!!!

     For the sake of convenience, I'm going to describe what happens if you
open the gate to the east. Fight in rooms 1 and 2 and move to the northeast
corner of the room where you will be teleported to room 3. Fight through
room 4 where you will find another chest containing the KEY OF FIRST TEST.
With that key you can open the gate to the east and cross the ramp to the
north <no pit this time>. You will meet Xorphitus on the way, but again,
you will not fight him. On the far side you will find another chest with the
KEY OF QUANDRY. This will open either gate east or west. We're going west
this time. Fight through 5 and 6, teleport to 7, fight through 8, open the
chest for the KEY OF FINALITY which will open the gate to your west. Move to
28g and SAVE YOUR GAME.

BUTTONS:
     You will notice that there is a button at this location. If you push
it, you will have access to the stairs leading out of the temple. If you
push it, you will have to go through all 8 rooms of the temple, fighting all
the way to return to this point. You can gain a lot of experience by going
through the temple repeatedly but what you want to know is how to win the
game so:

END GAME:
     Having NOT pushed the button, head north on the ramp where you will
again meet Xorphitus. This time you will need to fight him and a number of
Greater Demons. Defeat him and his companions. Right after your victory,
Xorphitus' spirit will rise and talk to you. He will ask why you killed him.
His comments are rather humorous and among the jokes will be a hint of what
you need do next. After he disappears, head north. You will find what looks
like a dead end. Walk through the north wall, just walk through it, no
searching, just walk. You will fall down a chute. To the north will be a
door <20g>. To the south is a button. DO NOT TOUCH THE BUTTON UNLESS YOU
WISH TO LEAVE THE TEMPLE AND GO THROUGH IT FROM THE BEGINNING <minus the
Xorphitus encounter>.
     BEFORE going through the north door, EQUIP your party with the HOLY
STAKES OF WOOD, the ROCKS OF REFLECTION and the HOLY H2O+. Through that door
lies the encounter with the Bane King and Rebecca. Hope you're ready. Maybe
you should save your game in case you aren't ready and don't know it.
     Have the character carrying the SILVER CROSS USE it in the 1st round.
The stakes and holy water will not have effect until the cross has been
used. Use the stakes and holy water for offensive attacks and cast all the
defensive spells you can. Cast Silence and Anti-Magic. Good luck!
     If you manage to defeat those two, you will get some very nice
equipment including the RING OF STARS and lots of experience points. Use the
RING OF STARS on the KING'S DIARY while in REVIEW mode. This will give you
the security code to open the gate at 17g. The code is "THE HAND OF
DESTINY".
     Heading north you will find the pen, the bane of the cosmic forge, at
12 g <"P" on the map>.

ENDING 1:  TAKE THE PEN
ENDING 2:  LEAVE THE PEN AND WALK THROUGH THE NORTH WALL. You will find a
           door to the north. Open it with knock-knock spells or pick lock.
           On the other side of the door is Bela the Dragon. He's not easy
           to fight but if you are successful you will get the KEY OF STARS
           and be able to walk through another fake wall to the north, open
           a gate and find a spaceship at 5g. Enter the spaceship to win!

ALTERNATE ENDINGS:
     Way back on the Isle of the Dead you need to drop the SILVER CROSS
before you see Rebecca at 9z <on that map>. Continue as describe before
until you have gone around the temple, down the chute and are ready to open
the door where the Bane King and Rebecca await. The Bane King will appear
first and after explaining the torment of his life, he will kill himself.
Rebecca will then appear. If you respond to her first question with "I LOVE
YOU" she will give you a Diamond Ring. She will tell you more about herself
and the Queen and will give you a key.

ALTERNATE ENDING 1:    TAKE THE PEN
ALTERNATE ENDING 2:    SEE BELA AND JOIN HIM TO CHASE THE COSMIC ENTITY.
ALTERNATE ENDING 3:    SEE BELA AND DON'T JOIN HIM in which case you will
                       find the spaceship gone and you can exit this area
                       of the temple by following the long hallways out.
                       The hallway exits to the Forest Area at location
                       5D on that map.

     After "winning" the game, your characters are returned to the Forest
Area so that you may continue to play for as long as you wish. Save your
characters to another directory or floppy disk to use them in Wiz7.

This walkthru is copyright (c) 1991 by Wyvern. All rights reserved.
Wyvern@cup.portal.com