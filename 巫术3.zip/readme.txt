Wizardry 3 - The Legacy Of Llylgamyn
------------------------------------

Version 3.50
Walkthrough by Mr. Flewin (Kelly Flewin)
E-Mail: Tknomncr@Hotmail.Com


Disclaimer!!

This Guide is for private use only, and may not be reproduced or
altered in anyway. This may not be sold or used in anyway
to earn a profit, such as putting it on a CD and selling it
that way, or ANY Such manner not listed here. I am not associated
nor affiliated with the creators of this game and system, Sega of
America. This Guide was written by me, K. Flewin. I am not associated
nor affiliated with any copyrights not mentioned in this Guide.

TknoMncr is Mr. K. Flewin  [Tknomncr@Hotmail.Com]

This guide is Copyright Mr. Kelly Flewin, 2000-01
              Copyright Time Traveller's Inc. 1999-2001



Revision History
----------------
3.50 - Keeping with my Millenial Updates, here's the new update with
       a few more links and updated copyrights..etc. and that annoying
       spelling error in all 3 faqs.. -_-;;

3.00 - Added a disclaimer and new instructions on distribution! Please
       make note of both. Also added some websites where it is to be
       found. :) Thanks to those who emailed me with links and such.
     - Also added a small FAQ section due to the overwhelming amount
       of questions I have recieved.
     - I believe the item list is now absolutely complete!!

1.0 - The original release. :)


Part 1 - Moving Your Heroes!
Part 2 - The Beginning
Part 3 - The Maze Itself
Part 4 - Item List 
Part 5 - Frequently Asked Questions
Part 6 - End Credits and Stuffage


 This is very different to Wizardry 1 & 2. First off, the fact you can
use "Descendants" of your original characters. The second BIGGEST
difference though... is that IT'S FREAKIN INSANE TO LEVEL UP!!

 Yeah, you read that right! These enemies give you jack squat for
experience! Even on the 6th bloody level!

  With the PC Floppy version... the instructions to move characters are
detailed in your instruction manual and requires you to have the Two
Master Disks  [1 Each for each game].  If you own the "Ultimate Wizardry
Archives" [And even tho I have the disk versions of 1-3, I own this too],
it's very simple.

 Updates can be found at   WWW.GAMEFAQS.COM  and any sites mentioned
at the end of this guide. [If you see it anywhere else, please let me
know so I may personally have a chat with the webmaster, as I wish
permission to be asked before putting it on a site. Please see Guide
End for more information.]

 Maps may be available at the above address, but probably not. I will
email copies of it to those who want them. Unless someone wishes to host
them on their website, which if so, I will then include the link to it
in an immediate update.


Part 1 - Moving Your Heroes! 
============================


 To move your characters, simply load up Wizardry 3, go to the Utilities
menu, select the MOVE characters option and select the Wizardry 1
characters you wish to move and VOILA! They will now be PERMANENTLY moved
to Wizardry 3. Please note that in case you want to wander Wizardry 1 or 2,
use the premades... because when you import, your character has its
descendant gain most of your attributes, 500 gold only and they're Level
1. It's harsh... but.. if you're like me, and have been nurturing your
heroes from Wizardry 1 Day 1, then this wouldn't be a problem :) Since
you know you're going to probably keep on importing them from scenario
to scenario.


Part 2 - The Beginning
======================

 In the beginning, there was darkness, suddenly a burst of light, and
poof! Whoops... wrong beginning!

 To start off, I can not stress this enough! READ THE MANUAL! I MEAN IT!
Get off your butt NOW! And read the whole thing! This is the most
valuable asset a Wizardry Player has at the beginning of a long journey.
Sure this manual's really small, but every little bit helps, right?
Now, if you've already played this game before and know what you're
doing... then hurray! Remember to have the manual nearby though,
especially for the spells! [In the PC Version you have to often type
them out! Type the first letter and hit enter to make the game bring up
a list... the manual helps you by detailing what each spell does.]

 I am NOT going to print out the spells here for you... you can consult
your manuals for that! For shame if you pirated this game! You deserve
to suffer! If you've honestly lost your manual... then your S.O.L....
Interplay has no tech support for any Wizardry game and the old Sir-Tech
lines don't work. Heck the newer ones don't work either :(

 Once you have your characters, go off to Boltac's Trading Post and stock
up on goodies for your gang. 

 Now that you're stocked up... EQUIP YOUR STUFF! You wouldn't imagine how
many people fail to equip their stuff and wonder why they just got
slaughtered for the umpteenth time. When you're ready, go down to the Maze
and prepare yourself for some action.

 Quick note about the dungeons! Beware what you do! Evil characters will
NOT stay with Good characters. And vice versa. Neutral characters don't
give a damn. So... unless your characters are all neutral... If you're
good, let friendly monsters leave on their own way. If you're evil,
ROAST THEM! Otherwise, you may find that your good or evil characters
just switched alignments. Now granted, they will stay with your party,
but the second you reach the surface, they'll ditch you. There IS a way
around it, but it's a bit risky. Take the characters still with you,
heal them and go into the maze. Quit! Then go back into the game and use
the character(s) who ditched you and go into the maze. (I)nspect and pick
up the characters. The one downside to leaving any character in the maze
(especially further down) is that the monsters may rob you.

 One other warning... beware where you Malor... make sure you know the
EXACT CO-ORDINATES! Otherwise you may teleport into rock.. and trust
me people.. that is the worst thing to happen... well next to your
character becoming LOST for ever or turning into permanently dead...
yes... the Temple of Cant is not always 100% perfect. In Wizardry 3..
there doesn't seem to be any places of Solid Rock... but then I'm only
just wandering Level 6 at writing...

 Final Thing before the walkthru! I SWEAR! This is something that the
manual does NOT advise you do (The disk version) and that's suddenly
resetting your computer or shutting it off due to the fact it usually
would happen when the game is writing to the disk... hence your
characters go byebye! [I must admit, I fell prey to the "RESET" spell
once or twice and lost my characters once.]

 BUT! Lo and Behold! There is a way around this that ALLOWS you to reset
the game! No.. not the computer! Go figure Windows 95/98 actually is
useful for a game! If you see your characters decapitated, drained levels,
activate a chest trap [Teleporter] or teleporting into rock.. etc. There
IS a save! This only works with the CD version (Ultimate Wizardry
Archives). It installs the game into a dir ?:\WIZARD15  , where ? is the
drive it's on. If you run it from the MS-Dos Prompt and something happens,
hit the Win95/98 logo key on your Win95/98 Keyboard (104 Key Keyboard
if you didn't know) to bring up the menu, hit esc and then left click the
game in the bar at the bottom and close it. From here, you just simply go
back and load your game, and you should be at the exact square before the
accident happened! The key doesn't affect the game in anyway so!!! :)
There's your failsafe, and trust me... IT IS A LIFESAVER! Unless of course
you happened to do this on a square where it's a forced fight.. then you
end up getting some random enemies right off the bat, and whether you
run or beat them, the forced fight will occur right after... and if you're
weak as heck already... ouchie.

 My apologies for all of this rambling and info, but I hope you can
benefit from it. Anyways, on with the walkthru!


Part 3 - The Maze Itself
========================


Beginning
---------

 ARE YOU READY!?!?! I didn't think so! This ain't like the previous Two
Scenario's I helped you through. [And for those who haven't read my
previous walkthru/solve's for Wizardry 1 & 2, Don't fret. Get them where
you got this :) That and I did put alot of work into making them as
complete as I could...] This Scenario even had me baffled for a while..
not like the horrid 6 years of K.O.D... but bad enough.

 Prepare yourself for hell. I'm assuming you're starting with your
characters fresh from The Knight of Diamonds... but wait! You can't
quite use them... BUT! You can use their descendants! Please understand
that your characters are... oh.. like 50 years older or so in this
Scenario... but! Your descendants will carry on your proud [I Hope] name
and heritage. If you want to use the premade characters though, be my
guest. :) Your descendants will tend to have similar stats to your own
with slight randomizations.. [Hence it's better and more fun to import.]

 Now, the best part of this game is the fact that you can force an
alignment change :) Which means a GOOD Ninja or an EVIL Lord. Get used to
changing your alignment, because you have to constantly do that to
progress higher into the tower/maze. Now... in all honesty, due to this,
I honestly don't know what will happen if you make all your characters
Neutral... [There's not many Alignment specific items in the game]...
I will work on that query a little later on, once I've beaten the game,
and scanned my maps.

 Furthermore, this is also one of the HARDEST Scenarios, compared to
the previous Two, for one simple reason. Experience is almost NIL! That's
right.. you're going to have to fight ever harder and longer for less
experience! This is a real pain in the ass, I assure you, as at writing,
I'm only Level 9.... I want my MALOR!! Heck, I want my Bishop to get
some DECENT spells. Be aware, that although I don't specify what level
of experience you should have when tackling these levels, the enemies
can be a real pain the higher you go. Pray for a Blade of Cusinart for
your fighter-types... this makes things A HELL OF ALOT EASIER! Please
note, with my directions, at all times I wish you to know I give them
as if I was always looking Northwards. Use a DUMAPIC if you run into
problems... hopefully my guiding is pretty straight through.



One Final Word
--------------

 Here we go! The beginning of a brand new Scenario! All your equipment
equipped? You're going to need it! If you thought the First Two Scenario's
were a cakewalk, get ready for a wake up call! And if you though the
first Two were hard... Good luck :) Now keep in mind, that this is going
to be a bit confusing, and for that, I apologize to you the reader. You
will have to CONSTANTLY change Alignments to go further on in the game,
and I know how much of a pain that is. I will guide you as best as I can
though. You will also be a bit confused, because I will have you running
up and down the Floors like crazy at times just to get to a specific
item you need to beat the game. In all honesty, there's still a few
things of which I'm unsure of, such as the Monk who will let you have
the contents of the chest for your soul and the apparition in the pool
on the Third Floor... I haven't been able to get jack squat from them
yet... so...  But without further ado, here-a we-a go-a!


The Maze - Floor 1  [And you thought Switzerland was Neutral]
-------------------------------------------------------------

 Here we go, the start of a brand new adventure... but wait! This isn't
a dungeon! It's a Tower! Climb up those stairs and welcome to [0E, 0N, 1U].
Gotta love the luck of this :) Makes mapping a heck of alot easier. For
the time being, take the time to wander around with me and build a few
levels up. You may wish to be at least Level 3 or 4 before some serious
exploring, as the enemies do tend to gang up alot. When you're ready,
head 2 East and then 1 South. You will come to a sign declaring that
you've just reached the Barracks. Ignore this and continue 1 more South,
1 East and then 1 more South. Now you should be in the long corridor of
doors :) Explore around here for enemies and their treasures and get
ready. Nothing of major importance is here, so we shall go on. From the
door you just came out of, head 2 West. You will come to a sign that
signifies you've reached the Moat :) Now, I'm warning you right now,
this is one of the reasons why you should level build first. The Moat
Monsters tend to come in groups of 3-5, which means your party can be
Moat Monster Chow in a hurry if you're not careful. Anyways, when you're
ready to proceed, Please continue 2 North from the sign and a further
4 Squares West. Heal if you have to, because the next step West you take
is the first Moat Monster square. [Unavoidable Fight]

 Kick a little Serpent butt and heal up, because it's far from over. I
might add, this is a not bad area to fight in when you're leveling up,
as they give you 50 Exp. Each. Ready to go on and kick even more
countless minions asses? If so, head on 8 West till you reach the wall,
and then head 3 South, and 1 East. If you need to heal, now's the time,
and if you need spell points... head back to town by reversing the
directions. If you're ready, go 1 more South and you'll reach the second
batch of Moat Monsters. Much as the first batch, kick some Serpent
ass and heal and head 1 more South. You'll be right beside a door, and
there's a door 1 square South as well. Both end up leading you through
the same rigamarole, the only difference being that for the bottom door,
you simply have to reverse a few North and South directions. They're
virtually identical though, this being a symmetrical fortress.. so just
head 1 East through the first door.

 The good news is, you no longer have to deal with those pesky Moat
Monsters. The downside is, you now have to deal with the even peskier
and annoying Garian Mages and Guards. They give not bad experience, and
they do tend to run away rather often, but they're still a nuisance.
Anyways, enough chatter, you've been waiting at the square behind the
door long enough. Go 1 North through the door and once through, go
another 2 North. You should now be at the junction of 3 doors. Head on
East through the door and another 2 to the next door. Head on through
and go 1 more East. You'll now see a door further on, but 1 to your
immediate South. Go on through and 2 West through the awaiting door.
Now wait a second here. This room only has 2 exits, the one you came
through, and the one in front of you. Heal up, because this is the big
one... When you're confident, go 1 West through the door and you will
run into your first unavoidable encounter with the Garian Bunch. [Insert
cheesy Brady Bunch Theme Song Parody here] Now although it's tempting to
use your KATINO spells a plenty on them, try and be a bit sparing, as
you're going to need it a bit later on.

 Once you've made these foolish Garian's see the error of their ways,
[Trying to fight you] heal up, go through the Southern door and head 1
more South. Take the most Southern, East door and kick some more Garian
butt! Take their treasure if you dare and go yet another door East to
the next awaiting forced fight of Garians. [Just a note: If you happen
to pull the reset trick in this area, get ready to have to fight the
Garian's again... which can be a real pain.] Take a quickie breather and
heal up! The toughest fight of the level is almost upon you! 2 more
East takes you to the door. Take a deep breath and plunge on through to
the other side, right into the hands of Garian Captians and the head
Garian, who is no pushover [Yet.] This is the one where you would
benefit from DIOS's and KATINO's. The guards will run throughout the
battle, especially when their leader is dead.. so don't worry to badly.
When you've won, [I know you will] carefully disarm the chest and take
the fabulous treasures that you've so rightly deserved!

 After you've done celebrating like you just scored the final touchdown
in the Superbowl :) Head on 1 East and 1 more South. The door you want
to go on through is the Eastern door. Once you go through, you will
be entertained with a message from L'kbreth. Consider him... well more
or less of a Neutral Dragon. Heed his message wisely, as he points out
that neither Good or Evil alone can hope to win. IE. You're going to
have to do alot of Alignment switching and such to get far. Now, there
are 4 rooms in this little corridor. The most Southernly one is empty.
The one in front of you will take you to the 3rd Floor if the majority
of your party is Evil. [Excluding Neutral Characters] If the Majority,
or not enough of your party is Evil, it will merely teleport you back
to town. [VERY HANDY!] I would choose to ignore this for now. The next
room just above it is the staircase to the 2nd Floor. Once again, same
principal. If the majority of your party is Good, then they can go up,
otherwise, back to town you go. I would ensure your party is of the
Good persuasion and head on up. The top most room is a teleporter square
right back to town :) If you go back to town, you'll have to do this
all over again... until you get a special item later in the game.

 One point of interest before I go on though. For those who finally get
a Malor spell, and realize that there's 1 place you can't enter any
other way then BY Malor... don't bother. It's a fiendish little trap to
catch adventurers with 1 level 7 Mage spell point and Malor, off guard.
The 2 spaces in question are [5E, 14N & 5E, 15N] respectively. The
programmers have devious minds :)


The Maze - Floor 2  [Good]
--------------------------

 Ah! You made it! Good show! We start the Floor off at [19E, 0N, 2U].
Now, this is the beginning of the constant back and forthing I was
talking about, as you can only currently access half of the Floor
from this Floor alone. The other half can only be reached by Floor 4.
Enough of this babble though, you want to go on and see the world :)

 From the stairs, head on 4 West, 4 North, 4 more West, 1 North and
finally 1 more West. You'll notice there's 2 doors awaiting you. Head
on through the Southern door and go 1 more South, then 4 more East and
1 more South. The wall you see there is really a secret passage, but
it's pointless. The door to the West though, is where you want to go
next. Continue 1 West, 1 South and through the door to the South. Here's
where the fun begins :) Go 1 West and you will travel through a secret
passage. [Just like in Scooby Doo, only you'll have to insert your
clever catchphrase here..] Ignore the door and go 1 more West. Head up
2 North and 1 more West through yet another Secret Passage. [Jinkies!]
Go 1 more North and through yet another Secret Passage, you will enter
another new corridor set. Head on North through the door until you hit
the wall in the next room. Go on 1 West and yet another West through a
1 way secret passage. See that door to the North? Yep! Go on through.

 From here, go 1 West through the door and 1 more for good measure.
Head on 1 North and through the door. Go East 1, 1 South and another
1 East and then through the door. Go 1 North and East on through the
new door :) Go 1 North and yet another East to the next door and now
head on through. 2 East and 1 North will lead you to a Door going
West. Heads up, because this is a 1 way passage! Once you've gone on
through, the door to the West leads to an empty room, so ignore it.
Instead, go North, on through the door, 1 West and 2 North till you
reach the North door. Head on through and relax a second. If you're
the bold type, you can look what's behind the secret passage to your
immediate East ;) or if you just want to go on, go 1 West and 3 South,
right through the OTHER secret passage in this room. You'll now be
standing at a junction, so please head on 4 West to the door and then
step on through. Head up North 1 and then West on through the door.
Continue 1 more West and then 1 North. Take the door out and then
the one to the East and you're almost home :) Head on Northwards till
you get to the riddle square. Here is the first riddle of the game and
The answer is of course, "AIR" [No quotes] and will yield to you, the
end of the Floor. :) Go 4 more East and you'll arrive at [0E, 19N] and
the stairs to Floor 4. Congratulations!


The Maze - Floor 4  [Good]
--------------------------

 Here's where things start to get a whole lot interesting. You start off
at [10E, 2N] and should now proceed 1 South and head on through the door
to the East. Head 1 more South and 1 more East to yet another door, and
go on through. Head North through the next door and heal up. The door
right in front of you [North] has a nasty forced fight of random enemies.
Head on through and whoop their asses and reap their experience points
and treasure :) Go up 2 North and through the door, and then continue on
North through the next door as well. You'll now be at a 2 way corridor,
so next stop is to head West 7 Squares till you reach the next fork in
the road. [If you see a Spoon in the road, you're in the wrong game!]
Head up North again [But not to far North or you'll be in Canada]
another 7 squares and once more through the secret passage :) Go 1
West and 1 more North and then head on East through the secret passage
so convieniently located there. 1 square East and you'll see a door to
the North. Heal up BIGTIME! Get your characters leveled up for this next
part as it's going to be a doozy.

 Enter on through the door and you will be face to face with "The Legend",
ie. DELF!  [Yes, it's FLED spelt backwards... ha ha..] and his evil Stoner
Minions. The minions can simply be annihalated with the DISPELL command
[Where applicable] or good old fashioned ass-whoopin' or MAHALITO's. DELF
on the other hand, is best put to sleep with a KATINO, MONTINO'd, and then
soundly thrashed. His minions will "Stone" characters [And I don't mean in
the Woodstock or Raver sense either]... which is very inconvienient and
costly at the temples [Unless you have a MADI to spare...] For your most
valiant efforts, you will be awarded with some nice Experience and the
Crystal of Evil.

 Leave this horrid lair and back out the secret passage and to the
corridor you came up from. Move to [6E, 15N] and get ready for the next
step. The next item up for grabs is the elusive bottle, which is found
more often then none, on this level. Go South 7 Squares and then head
9 more Eastward till you reach a new Junction. Go North 2 squares to
the door and head on through. Go 1 East and go on North through this
door as well. 1 West and 1 North will lead you to an Eastern door. Go
on through and 1 more East. 2 South through the door will lead you to
a lovely little experience raising/treasure finding area. See all those
tiles that are lit, like message squares? Well they all say the same
thing. "LOOK OUT!" Step on one of these squares and then the next step
you take will yield you a battle with a random group of monsters. Keep
fighting on till you've obtained a bottle. This is going to be the KEY
item for saving yourself alot of time. There's still alot of stuff to
see and do on this floor, but you're probably really needing some
healing so I digress. Once you've gotten a bottle, exit the room the way
you came in and backtrack all the way back to the junction. [From the
door, 1 North, 1 West, 1 South, 1 East, 1 South, 1 West, 1 South through
the door, Then 2 more South.]  From here, go on down 4 more South till
you reach a door to the West. Head on through and defeat what ever
baddies block your path and continue 6 more West through the doors you
encounter and you will arrive at the Second Southern door in this new
corridor. Go on through it, 1 more South and 1 more West and VOILA!
The stairs to Floor 1 await you! Now head on down and get ready for a
little sailing.

 If you haven't realized yet, the bottle is very special. It's a Ship
In A Bottle, and this will allow you to sail over deep water. This is
Key because there's a shortcut on Floor 1 that can only be gotten to
with the ship :) Exit out of the small room, and go on 5 East. You'll
notice those special Message tiles say nothing... that's because if
you didn't have the bottle, they'd say the water is too deep to travel
over and then block your path. Anyways, after you travelled East, head
5 South to the Beach, go 1 more South and you'll go through a nifty
secret passage. 2 More South and 1 West will take you to the stairs to
the town :)


The Maze - Floor 1  [Thank God for Shortcuts!]
----------------------------------------------

 Alright! You still with me? Fantastic!! And if not, don't worry! A
few more levels will make all the difference! Anyways, sell off all
the junk you don't want to Boltac's, heal up in the Inn, raise some
levels, and we'll continue on our Merry Way. Now, because you have
the bottle, you can always use the Island Shortcut to travel to Level
4.. which saves ALOT of time. For those who're in need of directions,
from the stairs at [0E, 0N], go 1 East, and then proceed and 8 North
past the Beach. Now just simply proceed onwards 5 East and you'll be
back at the door to the Stairs to Floor 4. But wait! You just noticed
that there's a door below that, didn't you? The door below leads to
the stairs to Floor 5... but not only do you have to be Evil to use
them properly, but you should complete a few other tasks first. Do
make note of this door and stairs though... in case you got poisoned
and you have no more LATUMOFIS's leftover.. the quickie teleport for
being GOOD helps alot. Anyways, when you're ready to roll, let's head
on through the door and back to Floor 4.


The Maze - Floor 4  [Good Floor with Annoying Twisting Passages]
----------------------------------------------------------------

 Here we are, back on Floor 4, without the hassles of those annoying
Garian's and Floor 2's secret passage fever. From the stairs, head 1
East and 2 North, onwards through the door... but you knew that :) Head
on East 4 through the door and beat up the baddies. When they've given
up to your fast becoming awesome might, go East another 3 spaces through
the door and turn North. Go 7 North through the door, 1 East, 1 More
North through the door, 1 West, 1 North and now for the switch, 1 West!
See that door? Go North through it :) Now comes the annoying part.. the
twisting passages I referred to.

 From here, please Proceed 1 North and 2 West, through the door. 1 West,
1 South and another 2 West will take you on through to the next room.
Once in here, 1 North and 2 West through the next door and another 2
West. See the door to the South? Go on through and an additional South,
before turning East 2 Squares, through the door. Go 1 South and an
additional West and then South once more through the door. 1 West and
2 Further South will take you to another Eastern Door. Head on through
and go 1 North and 1 East, taking care to go 1 South through this new
door. [See what I mean folks... annoying] 1 East, 1 North and a further
2 East brings us to yet another door to wander through. Go for the final
South and 2 more East through the door... leading you to a wall.. THUD!
After composing yourself, go 3 North, right through the door and then
3 West through 2 doors. Go 1 more North and then go 1 East through a
secret passage. A man is standing here and informs you to tell them
"ABDUL SENT YOU". Remember this, as it's a password you're going to be
needing REALLY SOON! Go 1 North and you will go down a chute to the
other half of Level 2. :)


The Maze - Floor 2  Revisited [Good]
------------------------------------

 You land with a THUD at [2E, 11N, 2U]. Dust yourself off and get ready
for a wild ride. With a little luck and skill, you're going to be able
to walk out of this Floor with 2 quest items! :) Anyways, from where you
stand, go 1 East and head North through the door. Head 2 West and then
2 South through the door. Ignoring the door in front of you, go 1 more
West and then 3 more South through the door. Now you'll be in a very
long corridor :) Head South 7 more spaces and you'll go on through a
secret passage. Walk 2 more spaces East and 1 North and you will be
greeted with a lovely warning. It says no Trespassing... but since when
has anyone in an RPG EVER LISTENED TO THAT!

 Heal up and get ready for one heck of a battle though. The second you
step on through that door, you will be confronted with some Fiends and
some Ghosts. The Fiends are hard to kill, will not dispell, avoid magic
and they use some nasty magic themselves. The Ghosts though, are easier
to kill, CAN BE Dispelled, but they drain people levels... :~(. Try to
put the Fiends to sleep and using MANIFO and MAHALITO or LAHALITO when
you can. Once they've been defeated and you reap the benefits of such
a hard fought battle [And stopped cheering :)]  head 4 more squares
East, through the door. Here lays a very dusty old desk... looks like
someone may have stored something in here... so have a quick look. For
your efforts, you will recieve the Staff of Earth! Since there's nothing
more for you here, go back 7 West, past the message and then head 1
North through the door. 5 North, 1 East, 3 More North and an additional
2 East will lead you to a new room with a secret. :) Go 3 more East,
through the secret passage and head 1 North.

 Remember what the man said on Floor 4? That's the password to get past
this woman :) [In case you forgot, it's "ABDUL SENT YOU" without the
quotes.] Once that's done with, head 1 East and then 1 South... and POOF!
You've been mysteriously transported to [11E, 9N, 2U]. Move 5 East and
through the door and you will be in a new little corridor. To go back to
Floor 4, simply go 1 South and then all the way West through the door
and poof! The stairs will take you to [13E, 13N, 4U]. Just remember,
1 East is the chute back to Floor 2.

 If you'd rather collect the other Quest item, ignore going South and
instead go 2 more East and 3 North, through the door. You'll recieve a
message about a Boudoire and banquet hall... nothing to worry about
really. Head 5 North, through the opening, and then proceed 4 West and
1 North. Go 1 West through a secret passage, 1 South, 2 West, 1 North,
1 East and then 1 North. Wine cellar, huh? Don't buy that message for
a minute! Heal up and then go through the Western door. You'll be face
to face with the VERY WICKED PO'LE. This guy knows TILTOWAIT so KATINO
him hard and fast and beat him to a pulp. Your reward for this is
experience and the Air Amulet! Now all you need to do is simply backtrack
and take the stairs back to Floor 4.  [And in case you wanted to know
the directions... hooboy.. here we go. 1 East, 1 South, 1 West, 1 South,
2 East, 1 North, 1 East, 1 South, 4 East, 8 South & 2 West. Then simply
go 1 South and all the way West till you reach the stairs.]


The Maze - Floor 4 AGAIN!  [Good] 
---------------------------------

 Alright! We're now back on Floor 4 at [13E, 13N]. Go 1 South and then
head 1 East through a 1 way secret passage. Head 1 more East, 1 South
and 1 East again to get to the familiar door... then backtrack to Floor
1 if you need healing and such.

 If you don't/want to go on, then ignore this and when you emerge from
the secret passage, continue 4 East through the door. You'll notice a
door to the South. Curious? I bet you are! Go 1 South and you will be
hit with another riddle.. [Yes, you will get sick of them soon enough,
I did.] The answer is "FIRE" [No quotes]... if you haven't noticed yet,
the Elements play a big part in this game. From here, head 1 East and
then 1 South... POOF! You've now been teleported to [17E, 15N, 4U].
Head 1 South and 1 East and voila! A door to the North! Go through and
East 1 and finally 1 South and you will now be at the Stairs to Floor 6.


The Maze - Floor 6 [The Other Neutral Level]
--------------------------------------------

 This is a Neutral level, more or less based upon the fact that you can
reach it from either Floor 4 or Floor 5 [Good or Evil]. The difference is
primarily in which side of the level you start on. This Floor is also a
BITCH to map out as MALOR and DUMAPIC fizzle everytime and LOMILWA is
almost pointless. Not to mention the lovely fog zone...  but I digress.
Please note, all co-ordinates are VERY rough... I mapped this Floor
in almost its entirety.. but you may map it out a bit different.. for
the moment, please try and follow via my co-ordinates if possible. Also,
the enemies don't ALWAYS show up where I mention them, but the majority
of the time they do... so if you don't see em now, they may be there
later.

 Anyways, you start this Floor on the Left hand side at roughly [5E, 0N].
Go 1 East out of the room and be prepared to kick some SERIOUS ass... or
use the RESET spell like a mofo :) Now, albeit alot of these monsters will
give you crap for experience, they have the best treasure in the game!
The monsters to look out for, experience wise, are Xeno's [Slug things],
Cyclops [Pink 1 eyed things] and Ogre Lords. [Large Humanoids who can
decapitate :~(] Alright, once you've defeated, or reseted past, the
enemies, go 2 more East through the door and defeat the next batch of
baddies. 1 East and 2 North will lead you to yet another tough batch
to dispatch, but brave on, for you're half way home. From here, go 1
East and immediately South through the door, ignoring the Northern one
for good reason. 1 more South and a further 2 East will bring you to
another batch of badasses who want to make your life hell. 2 more East
and you'll be at the stairs to Floor 5... but since you're Good, it'll
take you back to town. 


The Maze - Floor 1  [Neutral Haven]
-----------------------------------

 Alright, it's healing and leveling up time! Identify any booty you got
from the adventure, [Dragon's Teeth rule, because they lower your AC
by 2... and that is perfect for a Mage!] and revive any dead members...
if you were unlucky. At this point, you know how to get to Floor 4 and
you know now how to get to Floor 6. If you ever want to refresh the
enemies on Floor 6, simply quit and restart the expedition. I suggest,
if you feel bold, going to Floor 4 or 6 and start whooping some enemies
asses till you're a bit stronger, as you're going to need all the
power you can get for the next assault. When you're a bit more bulked
up, come back to town and we'll make an assault on the next MAJOR quest
item. I'll simply assume you have at LEAST 1 Level 7 spell point and
MALOR handy... it makes things a bit more easier to explain and for you
to deal with the quest.

 First things first! Run around Floor 1 and Fight friendly monsters so
that your party becomes Evil. When they're Evil, go to the town and
heal up. Now, if you wish to run a little sidetrek/want to be a
completist, take the time then, from the stairs to town to MALOR with
these following co-ordinates;   7 East, 7 North, 2 Up.

 This will take you to Floor 3. Oh yes... you'll want to buy a 50 gold
Broadsword... the original! Not a +1 or +2 Broadsword... just a regular
one.


The Maze - Floor 3  [EVIL!!!!!]
-------------------------------

 Now, I warn you...this level is a REAL PAIN! There's gazillions of
1 way passages all over the place and you will walk through a good lot of
them without even realizing. By following these easy instructions though,
you will be able to quickly get the 2 quest items on this floor and be
done with it for good.

 Anyways, if you Malor'd up, you should now be at [7E, 7N, 3U] and
a Monk will wish to exchange the contents of the chest for your soul.
Well forget the soul! With the Broadsword you purchased, [I hope you
did] the character in possession of it will trade it for the contents
of the chest, which is the "Gold Medallion." With Medallion in hand,
go 11 North, 1 East, 1 North and then East through the door. Beat up
your foes and take 1 more step East. Search the Apparition pool and
you will trade the Gold Medallion for Holy Water, the OTHER Quest item.

 Now, in all honesty, I don't know the TRUE significance of the 4
elemental items, but they each do chant a spell... which can come in
handy.

 To get back out of this horrid level, and back to town, you simply go
2 West [Out the door], 2 North, 1 West through the door, beat the foes,
1 more West and you'll automatically be teleported back to the stair
well. Go down to Floor 1, out the door, 1 North and then through the
door to the East and VOILA! You're back in town, ready to heal up.


The Maze - Floor 1  [Thank God For Shortcuts! Part 2]
-----------------------------------------------------

 From the stairs to the town, go 1 East and 7 North! Yes, 7!
Caught you lookin, didn't I? :) Now simply head on 5 East and through
the door and you'll be sitting pretty on Floor 5. [Remember, the stairs
to Floor 4 will now teleport you back to town. Ditto if you try to
MALOR to Floor 2 or 4.]


The Maze - Floor 5  [Evil]
--------------------------

 Wooh!! This is going to be a doozy. Here's where you're going to pick
up 2 Really important Quest items. You start off at [18E, 0N] in a small
little room. Exit to the West and you'll be in a long corridor of doors.
Go on 3 West and then head on South 5 spaces, through the 2 doors. Head
2 West and then 1 North through the door. 2 more West, 2 South, 2 West
and 2 South again with 1 more West and 2 more South for flavour, will
lead us to the 3rd of 3 doors on the Eastern side. Heal up and then go
2 East through the doors. 1 East and 1 South later, go 1 East and you
will go through the first of many 1 way passages. Go another 2 East
through yet another 1 way passage and then 4 North, through another 2
1 way passages. 4 West and 2 1 Way passages later, 2 more South will
lead you to a 1 square room. Go 1 East through the door and you'll see
a tile in the centre of a "Cross" shaped room. Heal up and get ready for
a huge fight. You'll be facing Paralyzing Soul Spinners and a ton of
Crusaders and Crusader Lords [Who have nasty ass Priest Magic!]. Waste
'em where they stand with some KATINO and other spell action and the
prize of the Good Crystal is yours.

 Head back 3 West [Through another 1 way passage] and then 1 more
through the door and you'll now be in the corridor with 3 Eastern doors
again, only you'll have come out of the Second one. Backtrack to the
stairs to Floor 1 and go back to town if you need to. [For those who
need help, from here simply go... 2 North, 1 East, 2 North, 2 East,
4 North, 2 East, 2 North and then all the way East through the secret
passage to the stairs.]  For the curious, at the other end of the hall is
another Secret passage that leads to the stairs to Floor 3.

 Please also note, for this next part, someone must have 25,000 gold
handy.

 From the stairs, use your MALOR power and input the following for your
co-ordinates;  11 North & 15 West.  This will teleport you to [3E, 11N].
From here go 2 South, 1 East and 1 more South, through all doors. This
will lead you to Abdul, who is willing to part with a rare item for a
mere 25,000 Gold. Accept his offer and follow him through a 1 way passage
South. In this room he will now laugh and the item is yours. [The Rod of
Fire :)] Go 1 West through a 1 way passage and heal, because this is going
to be difficult. Go 4 West through the doors, fighting enemies all the
way. Go 1 North and 1 East and heal! 1 more East is a FORCED battle with
a group of "Priests of Fung". They love to use MABADI and the like on you,
and do it very well I might add. Dispatch of them with a nice LAKANITO
spell as you can, head 1 more East and repeat. From this room, go 1 more
North and kill off yet more of these annoying Priests! Move 1 West and
you will fight the final batch of these heretics. Go 2 West through the
door and read the sign and laugh. It means nothing to you now.

 From the sign, head 2 more West, through a secret passage. Continue 2
South and 3 West and head on through the door to the South. Go on 2 West,
1 North, 2 West, 1 North and through the Western door. Move 1 South and
2 more West. Go through the door to the North, and go 5 more North, going
through the other doors as well. Now you'll be in another "Cross" shaped
room. Go 1 West and you'll be queried with a very difficult riddle.
[The only reason I EVEN REMOTELY got this, is because I also constantly
play a Japanese Game called Magical Drop 2... and it uses Tarot cards
as characters.] The answer is "CHARIOT" [No quotes]. Kind of obvious to
a degree.. but if you don't have Tarot cards... it's not really obvious.
Anyways, head 3 more West, passing through 2 more doors on your way. Head
1 South, 3 more West [Going through all doors], 2 North, 1 East and then
1 South and VOILA! The OTHER stairs to Floor 6. Like the Jefferson's,
"We're movin' on up.." :)


The Maze - Floor 6 [Labryinth Even The Minotaur Would Have Problems With]
-------------------------------------------------------------------------

 Yeah, you read that right. As I said before, this was a real pain to
map out. You will now be starting on the Right side of the level at
roughly [14E, 0N]. Head on 1 West through the doors and beat up the
awaiting baddies. Move 3 more West, beating baddies as you go, and then
go 3 North to the door I told you to ignore before. [If you need to heal
though, simply go 2 North, then 1 West, 2 South, and all West till you
reach the stairs to Floor 4.]

 Here's where things get fun! :) I'd quite the game and make up a backup
copy of SAVE3.DSK if I were you... you don't want to lose all this work.
Now make sure a character happens to have both crystals handy. Equip
their items and when it asks if you wish to envoke the power of the Evil
Crystal, say Yes and they will both meld into the Neutral Crystal.
[Please note, my characters were all GOOD and I used the GOOD crystal
to do this... I'm assuming that if they're EVIL and you use the EVIL
crystal, same results.]  Trust me, unless you wish to go head to head
with L'Kbreth [Who's in the next room BTW]... and see every spell you
chant be Neutralized... not be able to scratch him... etc... then just
ignore this step... I dares ya :)

 Alright, clear minds prevail and you now have the Neutral Crystal. Go
North through the door and L'Kbreth will greet you and allow you passage
on for having the Neutral Crystal. 2 More North and you will go through
the other 1 way passage and be in the Labryinth of Annoyance...

 Now I do wholeheartedly apologize for how monotonous this is all going
to sound as I guide you through this part... I will honestly try and
liven it up... but somethings just can't be helped... :~( ALSO! There
are 2 Different Orbs you can get! Which makes me believe that there are
2 different endings available. I know where they both are, but they're
both guarded by tough riddles... and I can't figure out the 2nd one
at all... so until I figure it out [Or someone kindly aids me], I'll
guide you to the one I know of for sure.

 Sit back, hold tight, heal yourself, and get ready to fight!

 From your new position, [Which is roughly, [10E, 6N]] Go 1 North,
4 West, 1 North, 1 East, 3 North, 1 East, 1 North, 2 West, 1 North,
1 West, 1 North, 1 More East and 1 North. You should now be at passage
and in front of a door to the East.  [For those who need to heal bad,
and want to go back to town, go North another 2 spaces through the
secret passage, beat the baddies, go 2 more North and 1 West through
the door to a portal that takes you to [0E, 0N, 1U].

 Heal once more and go East through the door... into the fog, and an
enemy encounter. Beat them, beat them bad! This next part is going to
be a bit tricky... since it's fogged and all. From the encounter space
you should now be standing on... slowly move/count 9 spaces East and
then 5 North, which should lead you back to lit passages once more.
Immediately go 3 East and then 1 South through the secret passage. 2
more South will lead you to the riddle square. The answer to this one
is "DEATH" [No quotes]. Go West through through the door 2 spaces and
search. Your character who had the Neutral Crystal will swap for the
Orb Of Earithin, one of the goals of the scenario. Proceed 2 North
through a 1 way passage and then 2 East before going 1 more North back
through the secret passage. Go 3 West, 5 South [Back into the fog],
9 Spaces back West and 1 more to take you on through the door. Go 2
North through the secret passage, beat the baddies, and then 2 more
North followed by 1 West through the door to the portal. The portal will
take you to [0E, 0N, 1U]. Go down the stairs and the Mages of Llylgamyn
will ask you to hand over the Orb. You can choose to accept or decline,
it's really your choice. If you accept, they will then go to work to
figure out what's causing things to go wrong and the Queen of Llylgamyn
will award you and 6 other heroes with the "Star of Llylgamyn". It will
appear as a "*" in your character stats at the top and in addition,
you'll recieve 150,000 Experience points to boot.


 I'm not sure what happens if you retrieve the Orb of Mahfuuzes and
take it back to them... but oddly enough.. you can go on with the game,
and retrieve another Good and Evil crystal... make another Neutral
Crystal and try to go for that. For those who want to try this, from
the beginning of the Floor 6 Labrinyth, go 1 North, 2 East, 1 South,
1 West, 1 South, 3 East, 1 South and then go 1 West through the secret
passage. Go 2 more West and you'll be at the OTHER riddle square. The
riddle is;


On my roll, you move,
My turn is your turn.
What Am I?


 Now, just hours before I was about to release this... I FINALLY Figured
it out! The answer to the riddle is so OBVIOUS! The answer is of course
"WHEEL"  [No Quotes]. I can't believe the answer escaped me for so long!
Anyways, once you answer, follow along the path and the character with
the Neutral Crystal will trade it for the Orb Of Mhuuzfes. [Yeah, you're
reading that correctly.] Simply then go 1 North, 1 East [Out of the room
and back to the passage], 1 North, 3 West, 1 North, 1 East, 1 North,
2 West and 1 South and you'll be back at the start alcove.

 From your new position, [Which is roughly, [10E, 6N]] Go 1 North,
4 West, 1 North, 1 East, 3 North, 1 East, 1 North, 2 West, 1 North,
1 West, 1 North, 1 More East, 3 North through the secret passage, beat
the baddies, go 2 more North and 1 West through the door to a portal
that takes you to [0E, 0N, 1U].

 Now, nothing happened when I brought it to town... BUT! Due to the fact
I already brought the Earithin Orb, I think this may mean you can only
beat the game once. When I attempt to make my all NEUTRAL party and see
what happens, I'll try taking the Orb Of Mhuuzfes back to the surface
and see what happens. Whatever you do though... DO NOT EQUIP IT! Good,
Neutral OR Evil. It will raise your AC by 10 points. Do not use it's
special power either! It will take away a piety point for every use
and nothing more.


 Anyways, for the time being, congratulations on defeating the 3RD!
Scenario of Wizardry. Since Part 4 isn't really a sequel persay, and
I'm unsure if I'm going to write my own version of a Solve for it,
I guess I'll see you in Part 5 :) And for those of you whom have been
with me from the very beginning, your character records should have the
following at the top for achievements.

" }*DG "   or  " }*KG "


}  Wizardry 1 Scenario Completed
G  Sign of Gnilda [Returned Staff] [Wizardry 2 Scenario Completed]
K  Knight of Gnilda [Aided in Staff Return] [Wizardry 2 Scenario
                                             Completed]
D  Descendant of Heroes from Scenario 1 &/or 2
*  Star of Llylgamyn [Wizardry 3 Scenario Completed]



Part 4 - Item List
==================

 Much like Scenario 1 & 2, there is quite the variety of weapons, armor
and items. Primarily in my vast journeys through this scenario, I've come
across the odd rare item and so I will chronicle them here. This is
virtually complete, but! considering the fact that there's so many things,
and most just don't pop up terribly often, I think it's as good as they
come. The quest items will be added as I find them and their use. All "-"
weapons and armor should obviously be avoided. If you find anything not
on this list, please email me a snapshot of the item, inform me of its
use and how much it sells for at Boltac's. BTW: I've removed the "How
rare is it?" chart for formatting reasons. The more expensive an item
tends to be, the more rare it is. Stuff that SOUNDS Rare, probably
is...  well that and also, what may come up rather often for me.. may not
come up to often for you. If you found an item not in this list, please
email me at  Tknomncr@Hotmail.Com   with the item name, use, type and
price at Boltac's Trading Post. Unless I find more, anyone who adds an
item I don't have on this list will be fully accredited.


Spells                                                            Price?
------                                                            ------

* Of Latumofis         Cure Poison                                   600
% Of Badios            Chants Badios                               1,000
* Of Dios              Restore 1-8 HP                              1,000
* Of Halito            Chants Halito                               1,000
% Of Katino            Chants Katino                               1,000


Weapons                                                           Price?
-------                                                           ------

Dagger                                                                10
Staff                                                                 20
Hand Axe                                                              30
Short Sword                                                           30
Broadsword                                                            50
Mace                                                                  60
Hand Axe                                                             140
Flail                                                                300   
Battle Axe -1                                                      1,000
Broadsword -1                                                      1,000     
Dagger -1                                                          1,000
Margaux's Flail        Good Characters Only                        1,000
Short Sword -1                                                     2,000
Wizard's Staff         [Use] Chants Mogref                         6,000
Broad Sword +1                                                    10,000
Dagger +1                                                         10,000
Mace +1                                                           10,000
Short Sword +1                                                    10,000
Battle Axe +1                                                     12,500
Amber Blade (N)        Neutral Characters Only                    15,000
Blade Cusinart'                                                   15,000
Ebony Blade (E)        Evil Characters Only                       15,000
Ivory Blade (G)        Good Characters Only                       15,000
Flametongue                                                       15,000
Nunchaku                                                          15,000
Rod Of Death                                                      17,500
Battle Axe +2                                                     20,000
Broadsword +2                                                     20,000
Mace +2                                                           20,000
Short Sword +2                                                    20,000
Sheperd's Crook        Good Characters Only                       22,500
Unholy Axe             Evil Characters Only                       22,500
Giant's Club                                                      30,000


Armor                                                             Price?
-----                                                             ------

Mage's Robes                                                          30
Round Shield                                                          40
Heater Shield                                                         80
Cuirass                                                              100
Hauberk                                                              200
Sallet                                                               200
Breast Plate                                                         400
Bascinet                                                           1,000
Plate Armor                                                        1,500
Breast Plate -1                                                    2,000
Cuirass -1                                                         2,000
Hauberk -1                                                         2,000
Plate Armor -1                                                     2,000
Round Shield -1                                                    2,000
Sallet -1                                                          2,000
Wargan Robes           Good Characters Only                        2,000
Gloves Of Iron                                                     2,500
Heater +1                                                          2,500
Cuirass +1                                                         3,000
Hauberk +1                                                         3,500
Breast Plate +1                                                    4,000
Plate Armor +1                                                     5,000
Cuirass +2                                                         6,000
Gloves of Mithril                                                  6,000
Heater +2                                                          6,000
Armet                                                              8,000
Hauberk +2                                                         8,000
Breast Plate +2                                                   10,000
Displacer Robes        Great For Mages                            12,000
Plate Armor +2                                                    14,000
Mantis Gloves                                                     15,000
Gloves of Silver                                                  60,000
Gold Tiara             Equippable by Everyone			     100,000


Misc Items                                                        Price?
----------                                                        ------

Bag Of Gems            Sell For Quick Cash                           100  
Sopic Philtree									 2,500
Amulet Of Dialko       [Use] Casts Dialko    [Handy]               8,000
Blue Pearl                                                         8,000
Bag Of Emeralds        Sell For Lots Of Cash                      10,000
Gold Ring                                                         10,000
Rabbit's Foot          [Use] +1 To your Luck                      10,000
Thief's Pick           [Use] Ninja Maker??                        10,000
Gem Of Exorcism                                                   12,000
Salamander Ring                                                   15,000
Serpent's Tooth        Lowers AC by 1                             15,000
Ruby Slippers          There's No Place Like Home.....            16,000**
Bag Of Garnets         Money, Money, Money... MONEY!              20,000
Necrology Rod          Lowers AC by 1                             20,000
Dragon's Tooth         Lowers AC by 2                             30,000
TrollKing Ring                                                    40,000
Book Of Death          [Use] Casts MABADI   [SWEET!]              50,000
Book Of Life           [Use] Casts Kadorto                        50,000
Book Of Demons         [Use] Lowers Piety!!!                     100,000
Butterfly Knife        Evil Characters Only, Use To Make Ninja   500,000



Quest Items Needed To Complete Game
-----------------------------------

Item                   Location                                   Price?
----                   --------                                   ------

Amulet Of Air          4E, 19N, 2U  [Use] Chants Dalto            25,000
Holy Water             10E, 19N, 3U [Trade Medallion for it]      25,000
                                    [Use] Chants Dial
Rod Of Fire            4E, 7N, 5U  [Use] Chants Mahalito          25,000
Staff Of Earth         7E, 1N, 2U  [Use] Chants Manifo            25,000
Crystal Of Good        12E, 10N, 5U                              300,000
Crystal Of Evil        7E, 17N, 4U                               300,000
Gold Medallion         7E, 7N, 3U  [Trade Broadsword for it]     300,000
Neutral Crystal        Use Good Crystal + Evil Crystal           300,000
Ship In A Bottle       Random Item on Floors 4+                  300,000

Orb Of Mhuuzfes        Trade Neutral Crystal For It              300,000
                       @ 11E, 2N, 6U  [Approx.]

Orb Of Earithin        Trade Neutral Crystal For It              300,000
                       @ 17E, 17N, 6U  [Approx.]


** This item, when used, tends, at least in my version of the Ultimate
   Wizardry Archives, to freeze the game. Now this may just be my copy,
   and maybe not... when I use the "Reset" spell, and go back into the
   game though, I am back in Llylgamyn in Gilgamesh's Tavern, safe and
   sound... just be aware of this... works like Loktofeit... with
   emphasis on the Lok part :)



Part 5 - Frequently Asked Questions
===================================

Q: If one of my characters dies in the game right off the bat, is
   there any way to bring them back to life?  If so how?  

A: Yes there is a way, but you won't like the answer. You get a
   party together, or the remaining party members who didn't die,
   and heal them up. Go to the square where your character died and
   do a search. If you're on the correct square, and the alignment of
   the party members matches the dead character [Or you're all
   Neutral] you can pick them up and take them back to the surface.
   Go to the Temple of Cant and then gawk at the expensive price to
   revive your fallen comrade.

   In all honesty, you're better off pillaging the dead one and then
   making a new character. The Temple can screw up your fallen comrade
   by accident and cost you way more then you need to worry about so
   early in the game.

Q: Where can I find any of these games?

A: For the PC Versions, you can go to any good Computer store and pick
   yourself up a copy of the Wizardry Archives cd-rom at a decent price.
   I believe a Macintosh copy does exist, so Mac Fans, rejoice. If you
   want the old school NES Versions, I would recommend online gaming
   stores dealing in ancient games or pawn/used shops in your area.

   You could alternately go online and... no.. you would NEVER do that..
   considering it's illegal, immoral, carries a hefty fine.. etc.


Q: Where can I find an emulator?

A: Http://www.vintagegaming.com    

   [Note: Since Emulators aren't illegal persay, that is why this
          link is even posted.]


Q: Where can I find the Roms?

A: You want to go the illegal route? Find them yourself as I can't
   help you.


Q: Where can I find maps for the game?

A: I am fairly sure there is at least a site or 2 on the net that has
   maps for this game. I personally have made maps for the First
   Trilogy, but only have Wizardry 1 scanned. I will be more then happy
   to email people them if requested, unless someone wishes to keep
   them up on their site for me. My connect is crap, so apologies for
   any delay in getting them to you.


Q: Can I switch my characters from Part 1 NES to Part 2 NES?

A: Sadly you can't, as there is no way to transfer the data from one
   Cartridge to another that I am aware of.


Q: Can you send me a copy of the Manual? I lost mine.

A: I'd honestly like to help you here... but then there's way too
   many people emailing me about this.. and with the roms floating
   around the net, it's virtually impossible for me to tell if the
   person asking me legitimately owns the game or they pirated the
   rom.


Part 6 - End Credits and Stuffage
=================================

 I hope this has been a great deal of help to anyone who has struggled
through this challenging game. Perhaps in a future revision I may add
a more or less completed items list, but since there isn't as huge a
variety as opposed to part 1, it's kind of doubtful. Anyways, good gaming
and see you in Scenario 5: Heart Of The Maelstrom  [Unless I actually
decide to write my own solve for Scenario 4: The Return Of Werdna]

If you have any questions or comments, please direct them to me at;

Tknomncr@Hotmail.Com
Attn: Wizardry


 This solve/walkthrough and any subsequent updates can always [Hopefully]
be found/available at the following sites: [Updated as often as possible]


Game Faqs  [http://www.gamefaqs.com]

http://www.gamefaqs.com/computer/doswin/file/wizardry_iii.txt


DLH.net  [http://DLH.net]


The Cheat Empire  [http://home.planetinternet.be/~twuyts] 

http://home.planetinternet.be/~twuyts/xdown/wz3.zip


Al Amaloo's Video Game Strategies [http://vgstrategies.about.com]

http://www.gameadvice.com/cgibin/faq.cgi?game=w/Wizardry3-KFlewin.txt


The Spoiler Center  [http://www.the-spoiler.com]

http://www.the-spoiler.com/RPG/Sir-Tech/wizardry.3.1.html


RPG Classics  [http://rpgclassics.com]

http://www.rpgclassics.com/database/wizardry3pc/1.txt


The Spoiler Centre  [www.the-spoiler.com]

http://www.the-spoiler.com/RPG/Sir-Tech/wizardry.3.1.html  


Games Domain  [http://www.gamesdomain.com] [and all mirrors]

http://www.gamesdomain.co.uk/news/images/cheats/5272.html


Cheatsearch.Com  

http://www.cheatsearch.com/PC/unp90_20000501_00275.HTML  


Games Over  [http://www.gamesover.com]
http://www.gamesover.com/walkthroughs/wizardry3.htm



If you want to distro it, be my guest. As long as you don't edit this in
any way, unless permission is granted. You MUST ALSO Inform me of
which website you wish to add it to so I may add the link to future
updates and give my official OK. It MAY be editted to be displayed
on a web page only if my name is intact and I am notified so I may come
and marvel. :)

 Extra special thanks to all those people wonderful enough to have taken
the few seconds time out of their busy schedules to contact me about
wanting to put it on their sites. Your sites will be added to future
updates if they're not already currently included. [And even some updates
specifically to let people know of you fine people and your sites :)]

 It may be printed out... not like I could stop you :) Just please keep it
intact.


Wizardry Copyright 1981-2001
Andrew Greenberg, Inc. and Robert Woodhead, Inc.
All Rights Reserved
Wizardry is a registered trademark of Sir-Tech Software, Inc.;
Reg'd TM Canada


This Walkthrough/Solve is Copyright Mr. Kelly Flewin, 2000-01
                          Copyright Time Traveller's Inc. 1999-2001

The Spoiler Centre