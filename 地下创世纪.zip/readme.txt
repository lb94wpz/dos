              WALK-THROUGH for ULTIMA UNDERWORLD (Ver 1.6)
              --------------------------------------------

                            Mitch Aigner

Yes folks, here it is. It starts with a run through of the highlights of each
of the 8 levels, and goes on from there.

* - indicates what you absolutely gotta have:
% - indicates optional ventures, usually worth the reward

Level 1
-------
* Recipe for Rotworm stew from Lanugo
% Solve the puzzle of the 4 levers
% Raid the treasuries of the Green and Grey goblins

Level 2
-------
* Kill the Gazer in the mines for Goldthirst and collect the reward
* Have Shak repair the Sword of Justice (after you find the pieces later on)
% Get the blueprints for Ironwit. Key is in small room in the same area that you
  must jump to, then follow the yellow brick road. Use Fly potion (green) to
  take you to yet another part of same area (when you see a gap far too far to
  jump). Do not fall off the elevated paths, monsters await below.
% Raid Goldthirst's treasury. Offer him a gift (anything GOLD!) , and he will
  give you the password. Use Fly, Levitate, or Gate Travel spell to get out.

Level 3
-------
* Blade for Sword of Justice - secret door behind vines in SE corner
* Taper of Sacrifice from Zak
* Cup of Wonder - after learning flute tune, and how to use incense
* Free the prisoner (Murgo) held by the lizardmen. Don't do this until the
  prisoner has translated the complete lizard language for you.
% Find the remains of Ossika (bring scroll back to Ishtass)
% Give a red gem to Iss'leek
% Kill all of the bandits, and find their treasury

Level 4
-------
* Give gemcutter to Derek for code to Ring of Humility (used on level 5)
* Kill Roderick and then collect Standard of Honor from Dorna Ironfist
% Give Sethar the Rotworm Stew to get Dragon Scales
% Join the knighthood (allows access to their Armory - great stuff!)
% Find the Writ of Lorne (talk to Lakshi about Rawstag)
% Find the Golden Plate behind secret door in Maze of Silas (door code is shown
  on the two knights tombstones)
% Solve the puzzle of the Bullfrog and find the illusionary wall to secret area

Level 5
-------
* Ring of Humility (using code mentioned above)
* Talk to Eyesnack to learn a flute tune.
* Hilt of Sword of Justice from tombs
* Give Judy the picture of Tom (after you find it below)
* Re-bury Garamons' bones (after you find them below)
% Have Marrowsuck make Dragon-skin boots (Dragon scales and spider thread)
% Offer to fetch "zanite" for Anjor
% Get code for mine dispatch chamber from Kneenibble

Level 6
-------
* Talk to Dr. Owl about location of Wine of Compassion (after freeing Murgo)
* Get book from Bronus to deliver to Morlock
* Talk to Morlock about Book of Honesty (after completing above errand)
* Defeat Golem to obtain the Shield of Valor
* Talk to Fyrgen and Louvnon to get some clues to the six-letter mantra
* Talk to Illomo (both BEFORE and AFTER you find his friend Gurstang below)
% Talk to Gralwart about getting a "Vas" runestone
% Get the book "Properties of Runestones" for Ranthru

Level 7
-------
* Talk to Naruto about a key
* Free the prisoners
* Go down to level 8 (three places): Pick up a piece of Orb Rock in one of them
                                     Get the Crown from the Imp in another
* Use the crown to master the maze and defeat Tyball, then free Arial
* Return to the prison and: get the Picture of Tom from Bolinard
                            get the Key from Smonden
                            talk to Gurstang (tell him Illomo sent you)
* Use the Key on the door in the extreme NW corner. Proceed upward to get the
  Key of Courage.
% Find the Medallion of Passage in the SW quadrant to get through all of the
  guard posts without having to do battle (though I preferred to battle  :-)
% Destroy Tyballs' orb by throwing the Orb Rock you collected at it.
% Raid the imps' treasury by killing the Golems. Make sure that you have a
  few Health potions handy, as some of the items are cursed.
% Find the "Ring of Levitate" in the chasm of fire (real handy on level 8)
% Visit the tombs (lots of secret doors, some good stuff, but must have the
  Crystal Splinter from Kallistan to get in)
% Go back to the prisons and kill all of the &^#$%! guards (just for revenge)

Level 8
-------
* Talk to Carasso about the location of Garamons' bones
* Open the central door with the tri-partite key and do what Garamon told you
  to do when you re-buried his bones.
% Find lots of really awesome weapons, armor, and magic stuff

MoonGate Level
--------------
* Just run like hell, that is all you CAN do!


GAME OBJECTIVES:
---------------
You have two goals in this game:

1) Survival
2) Find all 8 of the magic Talismans of Sir Cabrius

You cannot finish the game until you have all 8 Talismans, and have re-buried
the bones of the wizard Garamon. In addition, you will need to assemble the
Tripartite key.


General tips:
------------

- Don't kill anyone who is not actively trying to kill you (no matter how rude
  they may be)
- If anyone asks you to run an errand for them, do it (the reward is almost
  always worth it)
- Trust the good guys (identified by the Banner of Cabrius at their door). They
  will never steer you wrong.
- Save your game often.
- Talk to people more than once. There are different threads to most of the
  conversations. Try different responses each time.
- Write down what people tell you. It may not make any sense now, but could do
  so in the future.


Other useful stuff:
------------------

1. When using Fly or Levitate: pressing "E" makes you go up, pressing "Q" makes
   you go down.
2. You can make a fishing pole with a Pole and Spider Thread (who says there's
   no such thing as a free lunch! Fresh fish are also great for payoffs and for
   bartering).
3. Make popcorn with corn and a torch.
4. You can make a torch by pouring an oil flask onto a piece of wood.

Undocumented spells:
-------------------

AS  - curse
UP  - long jump
KM  - summon monster
VOG - sheet lightning
ACM - smite undead
IS  - thick skin (medium shield)
YP  - walk on water
VKC - armageddon (do not use, you won't like it)

Documented spells (included primarily for the folks who just have the demo)
----------------- (the demo documentation wasn't so hot IMHO)

To find out which spells you can cast: Take your experience level, divide by 2,
and then round up. This number is the maximum circle of spells you can use.

To find out how much Mana you need: Take the circle number and multiply by 3.

1st Circle:
IMY - create food
IL  - light
OJ  - magic arrow
BIS - resist blows (small shield)
SH  - stealth

2nd circle:
QC  - cause fear
WM  - detect monster
IBM - lesser heal
IJ  - rune of warding
RDP - slow fall

3rd circle:
BSL - conceal (low level invisibility)
OG  - lightning
QL  - night vision
RTP - speed
SJ  - strengthen door (same as using spikes)

4th circle:
IM  - heal
HP  - levitate
NM  - poison
AJ  - remove trap
SF  - resist fire

5th circle:
AN  - cure poison
PF  - fireball
GSP - missile protection
OWY - name enchantment (identify)
EY  - open

6th circle:
VIL - daylight
VRP - gate travel (to moonstone)
VIM - greater heal
AEP - paralyze
OPY - telekinesis

7th circle:
IMR - ally
VAW - confusion
VHP - fly
VSL - invisibility
OAQ - reveal

8th circle:
FH  - flame wind
AT  - freeze time
IVS - iron flesh (major shield)
OPW - roaming sight
VPY - tremor


Mantra chants:
-------------

I have included comments on the relative importance of each. NOTE: this is In
My Humble Opinion (which is bound to be different from your opinion, or anyone
elses).

Chant   Skill      IMHO
----- ---------- -----------------------------------
FAL    Acrobat    Need a little to keep from getting hurt in falls/jumps
HUNN   Appraise   worthless
RA     Attack     Need LOTS!
GAR    Axe        Need LOTS only if you are an Axe-man
SOL    Casting    Need a little to keep from getting hurt when spells 'backfire'
UN     Charm      worthless
ANRA   Defense    Need LOTS!
LAHN   Lore       Need LOTS! (to identify scrolls/potions/armor/wands/etc)
KOH    Mace       Need LOTS only if you are a Mace-man
IMU    Mana       Need LOTS!
FAHM   Missile    Need LOTS only if you are a Missiles-man (bow/crossbow/sling)
AAM    Picklock   Real handy on upper levels, not so handy on the lower ones
LON    Repair     worthless, as Shak works cheap (and as fast as you can)
LU     Search     Need a little to help find secret doors
MUL    Sneak      mostly worthless
ONO    Swimming   mostly worthless
AMO    Sword      Need LOTS only if you are a swordsman
ROMM   Traps      beyond worthless
ORA    Unarmed    Need LOTS if you prefer not to carry around a weapon **

** - The game CAN be won without the use of weapons or armor.

Character Creation:
------------------

     Throw away all the characters in the beginning. For each character class
there are a number of random skills assigned each time that you create a new
character,... except that they aren't random!
      Let's say I want to be a fighter. I create a bunch of fighter characters
and throw them all away, but not after writing down each ones' attributes. Now
I quit the game, and re-start the game. I again create a character. The exact
same sequence of characters will appear in the exact same order, but now I know
exactly which one to keep!!
      Strength is the most important skill of all. Most of the rest can be im-
proved later via shrine chants, but not Strength.
      Fighters, Druids, and Tinkers generally have high Strength factors.
      You will want to have a Strength factor of at least 25 in order to wear
plate armor, and still be able to carry a fair amount of goodies. Your carry
capacity (measured in units of "stones") is exactly twice your Strength rating.

The three primary skills (Strength, Intel., Dexterity) are factored in with the
other skill ratings. The final value used by the game seems to be proportional
to the skill level multiplied by the primary skill level tied to it. These
associations are as follows:

Strength:     Attack Defense Unarmed Sword Mace Missile Axe
Intelligence: Mana Casting Lore
Dexterity:    Sneak Swim Search Lockpick Charm Acrobat Traps Repair Appraise

For example: If you are trying to pick a lock, the game uses a number based on
             your Dexterity TIMES your Lockpick skill.

Maximum Vitality and Mana Capacities: These seem to depend on several factors.
             The present theory is as follows:

         Vitality: Depends on Strength and Experience level
             Mana: Depends on Intelligence, Experience, and Mana skill rating

             The precise equations using these numbers remain a mystery.


Fun things to do:
----------------

On Level 4, NW corner (accessible only from level 7), there are two hostile
mages. Kill one, and leave the other alive. Then get out of his way, as he will
throw fireballs at you. Go find some safe corner in which to hide. The remaining
mage will "summon" a wide variety of nasties for you to kill (hostile lizardmen,
mountainmen, fighters, spiders, headlesses, etc), each with its usual assortment
of goodies. This gives you the chance to sample battle with all of the various
denizons of the abyss, as well as cover the floors with loot. Every once in a
while you may have to go back to the mage and push him around a bit, to keep him
sufficiently pissed off.

Drink lots of Ale and Port all at once - get drunk and pass out! (Just remember
that you need to save at least 1 bottle of Port for rotworm stew.)


Outright spoilers:
-----------------

Level 1 levers puzzle - with 0 being top position, then clockwise: Turn
                        the lever farthest from the door to 1, the next to 2,
                        next one 3, next one 4 (straight down).

Level 2 Goldthirsts' password - "Deco morono"

Level 3 Cup of Wonder - Flute tune is: 3 5 4 2 3 7 8 7 5
                        Mantra for triangulation: "insahn"

Level 4 Maze of Silas - flip the levers in the following order:
                        Silver - Gold - Gold - Silver - Silver - Gold

Level 4 Bullfrog puzzle - The floor area is an 8 by 8 grid of movable tiles.
                          The two levers select the X and Y coordinates of the
                          tile you wish to move. Pushing the upper button on-
                          then-off raises the selected tile. Pushing the lower
                          button on-then-off lowers the selected tile. The wand
                          simply resets the floor to its original state for when
                          you screw up too badly. Build two ramps to get to the
                          two eastern-most corners. Jump through the wall to get
                          into the secret area in the south.

Level 5 Ring of Humility - hit NW lever, then SE, NE, SW. STAY OUT of the center
                           of the room while doing this. Hug the walls.

Level 5 Mine Control Code - with 0 being top position, then clockwise:
                            Left to Right: 7 2 6

Level 5 Garamon - wants you to throw the "talismans" into the "volcano". You
                  CANNOT complete the game unless you have found his bones on
                  level 8 (Garamon was the brother of Tyball, and one heck of a
                  mage. You will find several runestones (one is "Vas") and a
                  magic ring by the right bones). The bones must be buried in
                  the grave in the tombs on level 5 ("use" the bones on the
                  gravestone). After the ghost appears, you must answer the
                  questions correctly.
                       Another way to tell if you have the right set of bones
                  is to try to stack them on top of another set of bones in
                  your inventory. Like coins, bones will stack,.. leaving one
                  "bones" icon with a number next to it to indicate how many
                  are stacked. Garamon's bones will not stack this way.

Talismans:
---------
Taper of Sacrifice - Level 3, trade with Zak (food)

Sword of Justice -   Level 3, Blade is in secret room. Lever to operate is be-
                     hind a vine-covered wall in the extreme SE corner (Note:
                     you must attempt to "pick up" the vines to reveal the
                     secret door, just "looking" won't work).
                     Level 5, Hilt is in the tombs area, accesible from either
                     the Bullfrog area of Level 4, or a secret door on Level 5.
                     Level 2, Shak will make the repairs for 20 coins.

Cup of Wonder -      Level 3, room where Gazer is (that you have to swim to).
                     Stand on the little pedastal in the corner and play your
                     flute. The flute tune is taught by Eyesnack on level 5. The
                     clues to the three-part mantra (and use of incense) are
                     taught by Fyrgen and Louvnon on level 6.

Standard of Honor -  Level 4, from Dorna Ironfist, after slaying the Chaos
                     Knight (aka Sir Roderick).

Ring of Humility -   Level 5, room in NW quadrant with levers. Throw levers in
                     following order: NW SE NE SW. Stay away from the center of
                     the room when doing this. After last lever is thrown, ring
                     will be on the central pedastal. This is told by Derek on
                     level 4 after you give him the Gem-cutter you got from
                     Goldthirst on level 2 after you slew the Gazer in the mine.

Shield of Valor -    Level 6, after defeating the Golem

Wine of Compassion - Level 6, in checkerboard room with 2 headlesses (NW quad-
                     rant of level 6, off room with dozens of worms). Wine is
                     hidden under a floor tile in the SE corner. Try to
                     "pick up" or "use" the tile. Told by dr. Owl on level 6
                     after freeing his servant Murgo from the lizardmen on level
                     3.

Book of Honesty -    Level 6, is in the key behind the hourglass. There is an
                     hour-glass shaped room (NW quadrant of level 6) with a
                     secret door at the end of it. Go through the door and jump
                     across the chasm to get to a key-shaped room. Told by
                     Morlock on level 6 after you deliver the book from Bronus
                     on level 6.

Key of Love -        Level 5, from Judy after giving her the Picture of Tom

Key of Truth -       Level 6, after chanting "fanlo" at a shrine. Found in the
                     title of a book in the Library on Level 6, after talking to
                     Illomo (level 6) after finding Gurstang (level 7) after
                     talking to Illomo the first time.

Key of Courage -     Level 3, NW corner (NW area accessible only from level 7)

Key of Infinity (tri-partite key) - made by assembling the above three pieces.
                                    Just drop them on top of each other in your
                                    inventory, and they will bind.


Assorted Notes:
--------------

There are fountains of healing only on levels 1, 2, and 3

There is one shrine on every level (except level 3 which has three, and level 4
which has two)

Mandolins appear to be completely useless.

Pieces of wood can be used to improvise a torch,.. just douse it with oil.

Spikes are for pinning doors shut. Once a door is spiked, only you can open it.

You cannot defeat Level 7 without making a few trips down to Level 8

You cannot kill the "Slasher of Veils", no matter which side of the moongate
you both happen to be on. (Even with Attack/Defense/and Sword ratings of 250+)
(don't ask). You can get him to the "yellow" state, but not beyond.

When you and the demon are sucked through the moongate, you must run down one of
the three paths (red, green, blue) that go off the central area. That is all you
can do. The Orb you found on Level 1 tells you which path to take.

Maximum skill ratings depend upon the character-type selected (Example: Fighters
can only go to 25 in Mana/Lore/Casting rating, while Druids can go to 30)

Maximum Mana capacity also depends upon the type of character created. Druids
and Mages rate very high.

Trick to get past all the Fire Elementals in the Chasm of Fire on level 7: When
you come up from the NE part of level 8, you will find a Golem and a Key. There
is a secret door leading to the Chasm of Fire. Open the door and familiarize.