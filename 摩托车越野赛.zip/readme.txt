/////////////////////////////////////////////////////////////////////////
//                                                                     //
//                Welcome to Action SuperCross!                        //
//                                                                     //
//     A motorbike simulation game based on a real physical model.     //
//                                                                     //
//                    Registered version 1.2                           //
//                                                                     //
//            Copyright (C) 1997, 1998 Bal�zs R�zsa.                   //
//                    All rights reserved.                             //
//                                                                     //
//                    _______                                          //
//               ____|__     |               (R)                       //
//            --|       |    |-------------------                      //
//              |   ____|__  |  Association of                         //
//              |  |       |_|  Shareware                              //
//              |__|   o   |    Professionals                          //
//            -----|   |   |---------------------                      //
//                 |___|___|    MEMBER                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////


                        Do not distribute!

You may not copy, rent, lease, sell, modify, decompile, disassemble,
otherwise reverse engineer, or transfer this program.


                        LIMITED WARRANTY

The following limited warranty applies to registered copies of the
program. This warranty does not apply to unregistered copies of
the program.

Satisfaction Guarantee. If you are dissatisfied with this product you 
purchased from us for any reason, you may return it at any time up to 30 
days after purchase and we will give you a refund. Refunds will be based 
on the price you paid, with shipping costs excluded. You must contact us 
before returning the product for a refund.


                           INSTALLATION

To install Action SuperCross, simply put the installation floppy disk into
your drive. Type A: or B: depending on your drive letter, then press ENTER.
Type INSTALL and press ENTER.

If you have a 100% SoundBlaster compatible sound card, set your sound up by
going to the subdirectory containing the files, type SETUP, and press ENTER
at the DOS prompt.

To run the game, simply go to the subdirectory containing the files,
type ACROSS, and press ENTER at the DOS prompt.


Here is the list of the files you should see after installation:
  STATE.DAT       10518 bytes
  FILE_ID.DIZ       274 bytes
  ACROSS.EXE     373987 bytes
  DOS4GW.EXE     265396 bytes
  SETUP.EXE       23088 bytes
  ACROSS.RES    1642763 bytes
  SETUP.SND          42 bytes
  EDITOR.TXT       4926 bytes
  OMBUDSMN.TXT      622 bytes
  README.TXT       7428 bytes
  TECH_INF.TXT     2305 bytes
  TIPS.TXT         1596 bytes


                          UNINSTALLING THE GAME

If you ever want to remove Action SuperCross from your computer, you only
need to delete the directory containing the Action SuperCross files. Make
sure you do not have any valuable files in this directory that are not 
related to Action SuperCross.


                          HOW TO PLAY THE GAME

Be sure to read the tips.txt file also, in which you will find two useful
pieces of advice for playing the game.

You have to ride a motorbike and complete the various stages. You can get to
the next level only by completing the previous one successfully. You can skip
five levels in total, but you can go back and complete a previously skipped 
level later. You can choose to play on any of the levels you have previously 
completed.
For all stages the best six times are recorded along with the name of the
player. The levels become progressively more and more difficult to complete.

To control your motorbike while playing, you use the following keys:

UP arrow or A: accelerate (this puts a constant degree of force on the
	rear wheel).
DOWN arrow or Z: block both wheels.
RIGHT arrow or M: turn the bike clock-wise.
LEFT arrow or N: turn the bike anticlock-wise.
SPACE: turns your bike around so you can go in the opposite direction.

During the various stages there are several objects that appear on the screen.
You can contact an object by touching it with your helmet or any of your wheels.
The three different object types are:

FOOD object: You have to touch all of these before you can accomplish a level.
		If you touch it, it will disappear.
KILLER object: You will die if you touch it.
EXIT object: You can finish the level by touching it. (It works only if you
have already collected all of the food objects). The exit object is a flower.

You can read about the built in editor in the file EDITOR.TXT.


                         THE LATEST VERSION

The latest version of Action SuperCross is available from
Pik A Program's WWW site, http://www.pik.com.


You can find Action SuperCross home page at
	http://ourworld.compuserve.com/homepages/balazs/across.htm
Here you can download some additional levels also.


                        CONTACTING THE AUTHOR

You can contact the author by email at the following address:
balazs@compuserve.com

If this address doesn't work (Compuserve goes broke for example), you can
try these addresses instead (I don't check these while the Compuserve
address still works):
rba@freemail.c3.hu
balazsr@hotmail.com



                           ACKNOWLEDGEMENT

I would like to thank the following people for helping to create this game:
Csaba Rozsa, my brother, who designed almost all new levels in version 1.2,
maintains the WWW homepage of the game and the Best Times table.
Dylan Cooper gave me linguistic help for all written text in the game, gave
all the levels their names and tested the game so extensively, that he is 
one of the fastest players in the world.
Imre Barczi, who helped me a lot with technical issues, and with many other
things. He made all the menu pictures and designed the levels 5 and 21.
G�bor Ger�nyi helped me with sound related issues and gave me most of the
sound samples.
�gi Herman and G�za Szab� helped me to draw the motorbiker.
Tam�s and Andris Kristy�n helped me to record some sound effects for the
game.

The following persons tested the levels:
Csaba Fekete, David Hoover, Jennifer Hoover, Andris Kristy�n, Tam�s Kristy�n,
Csaba Limbek, Csaba Magyari, �kos N�meth Buhin, Andr�s T�r�k


                       COPYRIGHT INFORMATION

Action SuperCross and all the file formats the program produces are
Copyright (C) 1997, 1998 Bal�zs R�zsa. All rights reserved.


                           DISCLAIMER

Action SuperCross is supplied as-is. The author disclaims all warranties,
expressed or implied, including, without limitation, the warranties of
merchantability and of fitness for any purpose. The author assumes no
liability for damages, direct or consequential, which may result from the
use of Action SuperCross.


