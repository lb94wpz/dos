KRUSTY
======

If you experience memory problems with KRUSTY it may be necessary to create
a boot disk as follows:

1: First format a blank floppy disk by inserting a disk into the drive 
   and typing:

     FORMAT A: /S


2: Using an editor of your choice create 2(two) files on this disk, one
   called CONFIG.SYS and the other AUTOEXEC.BAT.

   The CONFIG.SYS file should look something like this (the
   first three lines are the most important):

     DEVICE=C:\DOS\HIMEM.SYS
     DEVICE=C:\DOS\EMM386.EXE RAM
     DOS=HIGH,UMB
     STACKS=9,256
     FILES=10


   The only thing in the AUTOEXEC.BAT file should be a
   command to load your mouse driver and should look
   something like this:

     C:\DRIVERS\MOUSE.COM


   You may have your mouse driver stored in a different location on your
   hard drive so you will probably need to alter the path and/or filename
   to suit your particular system.

   Once this is done turn off your PC, insert the newly created boot disk 
   and switch the machine back on. After MSDOS has booted you will now be 
   able to move into the directory where the KRUSTY game is stored. It can be
   loaded by typing:

     KRUSTY


If you still experience difficulties please contact the
Virgin Interactive Entertainment Customer Services
department on (+44) 081 964 8242.
