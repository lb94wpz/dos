From:             Corpeus@aol.com
Date sent:        Sun, 16 Feb 1997 01:30:07 -0500 (EST)
To:               gamefaqs@gamefaqs.com
Subject:          FAQ

                              ____  _   _  ____
                             (_  _)( )_( )( ___)
                               )(   ) _ (  )__)
                              (__) (_) (_)(____)

                     __________      _____
                     ___  ____/_____ __  /_____________
                     __  /_   _  __ `/  __/  _ \_  ___/
                     _  __/   / /_/ // /_ /  __/(__  )
                     /_/      \__,_/ \__/ \___//____/
                                       __
                                 ___  / _|
                                / _ \|  _|
                                \___/|_|
                _____
               (_   _)          _         _
                 | | _   _   _ (_)  ___  (_)   _     ___
                 | |( ) ( ) ( )| |/' _ `\| | /'_`\ /' _ `\
                 | || \_/ \_/ || || ( ) || |( (_) )| ( ) |
                 (_)`\___X___/'(_)(_) (_)(_)`\___/'(_) (_)

                              ___ _   ___
                             | __/_\ / _ \
                             | _/ _ \ (_) |
                             |_/_/ \_\__\_\


              _   __                _               ___    ____   
             | | / /___  ____ ___  (_)___   ___    <  /   |_  /   
             | |/ // -_)/ __/(_-< / // _ \ / _ \   / /_  _/_ <    
             |___/ \__//_/  /___//_/ \___//_//_/  /_/(_)/____/    



                               -=Written By=-
                         , _                 _
                        /|/ \   o           | |
                         |   |      __,  _  | |
                         |   |  |  /  | |/  |/
                         |   |_/|_/\_/|/|__/|__/
                                      |
                                   __/


FAQ release date : January 25, 1997
e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?e=?
                           ����������������������������������������?
                           o Table of Contents o
                           ����������������������������������������?
[1.0] Introduction and information
[1.1] Orientation
[1.2] Getting Started
[1.3] The Gauntlet Quest
[1.4] The Aqueduct
[1.5] The Reservoir
[1.6] Twinion Falls
[1.7] The Coliseum
[1.8] Queen's Palace
[2.1] Night Elf Ingress and the Parchment Map
[2.2] The Statuary, aMAZEing, and the Slate Map
[2.3] Tipekans, the Armory, the Races, and the Leather Map
[2.4] The Graveyard, Snake Pit, and the Snakeskin Map
[2.5] Cartography Shop
[2.6] Loose ends
[3.0] Prelude The Dralkarian Quest
[3.1] Dragon's Ire and the Chessboard
[3.2] Dragon's Flame and Hocus Pocus
[3.3] Hopeless Hallways, Halls of Babble, and Concordia
[3.4] Pandemonium
[4.1] The Dralkarian Quest
[4.1.1] Astelligius
[4.1.2] Malos
[4.1.3] Corpeus
[4.1.4] Pluthros
[4.1.5] Juvalad (X)
[4.2] Aeowyn's Treachery
[4.2.1] Hints and Tips on the Dralks
[5.1] Dissemination
[5.2] The Gateway
[6.1] Choronazar's Demesne and the Funhouse
[6.1.1] Endgame      
[7.1] Keys and Lockpicks
[7.2] Best Equipment
[7.3] Top 10s
[8.1] Epilogue
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.0] Introduction and information
  I created this FAQ to help any players who are stuck or do not understand
any part of the Sierra game Fates of Twinion. For those who wish to mail
me, do so at [Corpeus@aol.com]. Note that here you may find some
grammar/spelling mistakes, which I tried to "reduce" to a minimum via spell
checkers. If you find any mistakes, things that don't belong, etc. that I
made in the walkthru or something seems unclear, just tell me and I will try
and fix it.
                    ��?????????????????????????????????????
                    3 Things upgraded from last versions 3
                    ��????????????????????????????????????��
   1.0 - a TON of grammar mistakes and "gaps" in the walkthru. Nothing
   "major" except one or two sections.

   1.1  - A ton of grammar mistakes fixed, thanks to SEdit
   Major errors fixed in the Chessboard part of the Dralks quest
   Human/Dwarf/Gremlin "matches" added in Rat Race/Race Track section
   Cartography Shop section has been completed
   "Top 10s" section added "for fun"
   Dragon's Flame section has been completely redone
   Problems in [2.6], "Loose ends" all fixed.

   1.2 - More grammar mistakes fixed
   "Rat Race" and "Race Track" completed
   Blanks filled in in Dragon's Flame
   Spaces added to several spots (i.e. Cartography Shop) to avoid confusion
   Concordia section/minor mistakes fixed

   1.3 - Lotsa maps!
   Sections filled in Hopeless Hallways & Concordia
   Grid Map fixed (slight error)
   FINALLY completed - the infamous Dragon's Flame
   
   1.4 - New "Guide to Items" added with explanations for all the
   items in Twinion.
               ��????????????????????????????????????????????
               3 Things to be expected in the next version 3
               ��???????????????????????????????????????????��
  As of now, nothing yet.. However, I doubt this is the final release of 
the FAQ.. next one prob'ly won't come for quite some time.
                            ��???????????????????
                            3 X marks the spot 3
                            ��??????????????????��
The sections marked with an (X) in the table of contents
indicates that they are likely to be changed in the next version. This
doesn't mean that they WILL be changed, but they are likely to be. Most of
these areas will be where I forgot to make the directions clear enough,
didn't finish a section, etc. This was because I mostly charted my chars
offline, and VitaminF didn't let ya "fly" offline.. if you don't know what
that means, go figure it out. Hopefully VitF 5 will be released sometime
soon and I will live up to all the expectations.. hopefully [smirk]

                        ��????????????????????????
                        3 Shorthand/"Slang" Used3
                        ��???????????????????????��
Some of the shorthand I used in the FAQ is listed here.
Dralks = Dralkarians
TW or FoT = Twinion or Fates of Twinion
EGB, or any two = Experience, Gold, Booty (U Won't find it in this release,
I'll use it in the next to save some time & space since I use it a lot
anyway)               
_sample_ - I use it to stress things or words that are really important such
as, for example, _be sure_ to go there-here and get this.. it's not really 
in need of an explanation, but some people might have confused it with the 
other use (see last paragraph of next section)
                       ��?????????????????????????
                       3 Other important things 3
                       ��????????????????????????��
       Here are some other things you might want to know :
 * - This FAQ was typed via a DOS based editor. DO NOT view this file in
 Windows editors or you will get a lot of junk. Use the EDIT command from the
 DOS prompt or press F3/F4 while having the file selected in Norton Commander.
 Why does this happen? I used several DOS based symbols to create the "boxes"
 around several important factors; i.e. the subtitle here. Not surprisingly,
 these symbols do not operate in Windows, and WIN just replaces them with a
 bunch of junky hieroglyphics (or whatever those are  [g])

 * - If you have anything to add to this FAQ, from spelling changes to major
 redirections, be sure to give me a ring. YES I know I've said it a zillion
 times before, but I really do mean it! This FAQ can exist entirely by your
 support; I didn't write it for myself, but for other people to enjoy. If you
 do give me a tip, your name will be listed in the next version of the FAQ,
 and 99.9% of the time, the mistake will be changed (Unless it was meant to
 be that way of course, hopefully not) PLEASE, if you have something to
 contribute to this FAQ, go ahead and write me. Although I know pretty much
 almost everything there is to know about Twinion (almost) I'm always open to
 new suggestions.

 * - Even though, as we all know, INN is gone - I left the "forcing" cheat
 in the back of the FAQ in case FoT will be available on the AOL Games
 Channel online or wherever.

 * - The section on the dralk Juvalad here is, unfortunately, very incomplete.
 I've asked around the INN network long time ago (which no longer exists, as
 of now) and the smart people seem to know very little, like me, about how
 to beat this dralk. Once again, if you know anything that might help me,
 please feel free to send me a note.

 * - This FAQ is for other people's good and not my own. What I mean is that
 if you want to upload it to a network, web page, or pass along a copy to
 your friends, you may without doubt. However - there is a catch, you can't
 change it and then distribute it under your own name, or just distribute it
 under your own name even without changing it. That would be plagiarism, an
 offense to me because I spent hundreds of hours making this FAQ. If you
 want to make a change, mail me - I won't object unless it's something
 either completely ridiculous or not having to do anything with this FAQ or
 what I intend to do with it.  Also of note : I count on people's honesty to
 make sure that they do not gain profit from my work. There is absolutely no
 way for me to know whether someone has uploaded it against my standards,
 and I never make false accusations.

* - In the previous releases, you probably have noticed some blank or
unfilled squares, mainly for coordinates (_,_, ______, etc.) - these were 
for my own reference while creating the FAQ. Since when I had to find a 
coordinate, I had to refer back to the game, while writing a section I'd 
fill it in with one of the _'s and come back to it later; but now all of
these were filled in - not only because I skipped over them, but also 
because I didn't know some at that particular time and could not figure the 
coordinates out. In other words, since I'm mostly done with the major 
sections, these will be rare in the future.

     ��????????????????????????????????????????????????????????????????
     3 List of people I'd like to thank for helping me with this FAQ.3
     ��???????????????????????????????????????????????????????????????��
 Ouch, long list now.. all of the people here deserve a thanks for their
help, big or small...
                        Kudos to :

Yuglooc, Rath, GreatOne, Fleming, and Pug for helping me get through the
game in the first place.

Xenther for influencing me to write this FAQ and uploading it to his page,
and all other sorts of great help.
Visit his homepage at [http://members.gnn.com/xenther/xen.htm]

Lyam for pointing out a lot of mistakes.

Several INN hosts for telling me the rules on cheats/macros.

The creators of FigLET for helping me do the ASCII lettering.

Ryan266199@AOL.com for pointing out several certain mistakes.

Thanks to Walker for proofreading the entire FAQ.

J.E. Smith for SEDIT, the editing program I used to write and spell check
this FAQ.

Lady Anne for VitaminF, without which my job would be a whole lot harder.

An anonymous programmer for creating TWEdit (for Twinion Edit)

Everybody who ever was involved in the Fates of Twinion one way or another,
for giving me the whole purpose to write this FAQ 

My cacti for giving me nice clean air around th' workplace ;)

=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.1] Orientation

Q: Psst.. What's that I hear about maps?
A: I went through the game and took screenshots of the maps, and pasted them
in BMP files, for people's references.. I also filled in a lot of the
unmapped areas such as Queen's Palace, Hopeless Hallways, and the
ever-so-infamous Graveyard (I spend an hour, in verity, on that section
alone). I'll try to distribute them along with the FAQ.., they're pretty
good for references, and they use the real colors, as seen in the game.

Q: How do I get around the dungeon with these directions?
A: The four cardinal directions are as follows : If you're in a mappable area
(which makes up roughly 95% of the game) then west, for example, means west
on the MAP. Since the map never moves, the four directions in a mappable area
always remain the same. However, "forward" means clicking on the forward
arrow or pressing the 8 on the numeric keypad, "back" is the back button or
2 arrow on the numeric keypad, and the such. In an unmappable area, such as
the Graveyard, west, east, north, and south means YOUR west, east, north, or
south. Think of the directions in unmappable areas (west, east, north, and
south) just as "fancy" names for left, right, forward, and backward
directions. So in an unmappable area, "turn west" means turn left and the
such. These directions will change every time you step. In other words, if
you turn left (west) your [previous] south become your [new] west, your
[previous] north becomes your [new] east, etc., etc., etc. I tried not to use
these terms in unmappable areas, however, there might be a few mistakes, and
that's why this section is here.

Q: How do the map coordinates work?
A: The basic FoT map is a 16 by 16 square. Each square has a letter0 and a
number assigned to it. The lower left corner, for example is A,1. From south
to north the coordinates are letters, from west to east, they are numbers.
For example - here is the basic Fates of Twinion map :
                                              1   1   1   1   1   1   1
          1   2   3   4   5   6   7   8   9   0   1   2   3   4   5   6
        ��????????????????????????????????????????????????????????????????
      P 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 P
        ????????????????????????????????????????????????????????????????��
      O 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 O
        ????????????????????????????????????????????????????????????????��
      N 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 N
        ????????????????????????????????????????????????????????????????��
      M 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 M
        ????????????????????????????????????????????????????????????????��
      L 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 L
        ????????????????????????????????????????????????????????????????��
      K 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 K
        ????????????????????????????????????????????????????????????????��
      J 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 J
        ????????????????????????????????????????????????????????????????��
      I 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 I
        ????????????????????????????????????????????????????????????????��
      H 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 H
        ????????????????????????????????????????????????????????????????��
      G 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 G
        ????????????????????????????????????????????????????????????????��
      F 3   3   3   3   3   3   3   3 4 3   3   3   3   3   3   3   3   3 F
        ????????????????????????????????????????????????????????????????��
      E 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 E
        ????????????????????????????????????????????????????????????????��
      D 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 D
        ????????????????????????????????????????????????????????????????��
      C 3   3   3   3   3   3   3   3   3   3   3   3 K 3   3   3   3   3 C
        ????????????????????????????????????????????????????????????????��
      B 3 * 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 B
        ????????????????????????????????????????????????????????????????��
      A 3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3   3 A
        ��???��???��???��???��???��???��???��???��???��???��???��???��???��???��???��???��
          1   2   3   4   5   6   7   8   9   1   1   1   1   1   1   1
                                              0   1   2   3   4   5   6

In this map, the asterisk (*) is located at B,1, the K at C,12, and the 4 at
F,8. It's a good idea to keep a printout of this map at hand when playing
so that you can tell the coordinates. Since there is no "grid" in the actual
game to help you with this, you'll have to count off the numbers of "squares"
to your destination. Walls and doors will help, as they can "divide up" the
map. Once you get an eye of about how tall and how wide each square is, you
will be able to find coordinates on maps easily.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.2] Getting Started

Q: First of all, what are "quests"?
A: Quests are the base of experience points. The majority of levels you get
will be actually because you're on a quest. You may not know it, but every
step you take is a step towards a new spell, skill, or level. Basically, all
Quests are are different parts of the game. Once you progress through one
part, you'll receive a certain number of experience points and possibly gold,
skills and spells, and booty that you might need.

Q: Where should I explore first in the dungeon?
A: First, map out the entire DE (dungeon entrance). You'll pick up a few
clues. Don't go anywhere just yet. Out of the Dungeon Entrance, there are
8 possible exits. at the beginning of the game, you can only access 4
(Aqueduct, Gauntlet Droit, Gauntlet Gauche, and DE exit). Later in the game,
you will be given certain items to progress to the other exits. After you map
out the DE (you'll notice there are *no* monsters whatsoever in here), equip
your items. Consult the documents for information on how. Once you've got
everything equipped, head off to the door on the middle left - the Gauntlet
Gauche. Here - just fight a few battles to gain a few exp. points - you are
still very weak, remember? After a few battles, you should progress to level
3 or 4, and get a few gold pieces. Buy some better armor and possibly a
better weapon with these. Be sure not to waste all you gold though - you may
need it.

Q: Ok, I gained a few levels. How should I distribute my points?
A: As for your attributes, try to max out your Agility and Initiative
the first. For spells, distribute your points evenly instead of just making
one spell very powerful - perhaps so powerful you may not have the MP to
cast it. Remember, "defense" spells such as Shield may be critical to your
survival at this point, such as you - no matter what guild or race - won't
have very much HP. The monsters also won't be particularly tough, so the
spells won't have to be at a very high level to kill them or injure the
greatly. As for skills - max your character's "weapon" skills (i.e. Martial
Arts) first, then go for your guild skills. Particularly useful are the
skills Berserker, Athletics (Barbarian) Leadership, Binding (at the beginning
of the game - these skills usually become more and more useless as you learn
more spells) (Knight) Stamina, Read Tracks (Ranger) Detect, Lockpick (Thief)
Medic (Cleric) Rune Reading, Deep Trance, Channel (Wizard).
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.3] The Gauntlet Quest (a.k.a. Lava glove Quest)

Q: OK, I've got a better character now. Where do I go in Gauntlet Gauche?
A: Before you head back to the dungeon, be sure to purchase some heal
potions, and maybe a mana potion or two. In Gauntlet Gauche, there are several
specific areas : the Bat Cave to the NE will fetch you some booty : a Green
Lockpick, Leather Cap, Cloth Jacket, and a heal potion. Sell the Leather
Cap and Cloth Jacket as you already have them ; they won't bring much, but
every gold piece counts. Next important areas are the "skill" rooms ; they
are located at D,6 and K,9. For one of these rooms, you will need to use
a weapon, any weapon will do (even a sling :-) for the other one, you must
use a Scroll of Fire, which can be purchased in the Guild Hall. (if you are
a Wizard, you will already have it at the beginning  of the game - saves
you 350 GP, but nothing more :). You will gain some Experience Points and
Gold pieces for both of these rooms. There are also two rooms at F,16 and
B,7 that only "masterful" thieves can access. They'll fetch you some booty,
gold, and EXP. The 6th significant place in the Gauntlet Gauche is in the
SE - the Snake River which will take you to Gauntlet Droit, where the magical
Lava Glove is located.

Q: I got to Gauntlet Droit from the Gauche. What now?
A: First, you will need to get the Lava Glove. With it, you may complete
the quest. Be sure to have one or two Scrolls of Protection, and a Scroll
of Fire might come in handy. The Scroll of Protection throws up an energy
field around your party, which absorbs damage from enemy attacks. On this
level, these scrolls may be the key to survival. The Scroll of Fire casts
a deadly fireball at a group of monsters. This does 180 damage to the whole
group, killing them or damaging them horribly. At this level, they're a nice
touch if you want to win a battle. First, you exit the room with the pool
of water, then head East. You'll enter the Coil Maze - don't let the name
fool you - it's not much of a maze, just a single - square pathway winding
up and down. There are 5 battles in this maze, plus a final battle that fetches
you the Lava Glove. In these battles, the best strategy is to use the Scroll
of Protection first, then cast a Fireball at the particularly tough monsters.
If they aren't killed by THAT, finish them off with a spell or just break
out with a weapon. In the battle for the Lava Glove, use the same strategy.
However, your energy field will run out, so be sure to use your Scroll of
Protection every 5-6 turns. Once you defeat the monsters and have the Lava
Glove, feel free to explore and gain a few experience points as well as gold
pieces. You'll learn a bit more about your quest, and the tasks Aeowyn has
assigned you with. Later, much later, you will come back here... As one of
the ancient stained glass windows tells you. You might want to map this entire
place out, as this will give you a chance to earn experience points, gold,
and booty. Anything that you don't need - sell, as every gold piece counts.
The real finishing point to this quest is at K,7. Be sure to have a lockpick
with you. Pick the lock (facing south)at J,10 to get to a two - path corridor.
Take the path to the west and you will receive your "promised" reward - as
new skill, spell, and 1000 experience points, which will aid you in reaching
the next level.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.4] The Aqueduct

Q: What is the Aqueduct?
A: It's the base testing area for new adventurers who seek Aeowyn's rewards...
the Queen, in her search for Immortality, built this as a way of controlling
the waters that flow in and out of her palace. She then modified it to be
just one of the steps, the first step towards her - and your - victory...
Q: What do I need to do first?
A: Once you first enter, go through the door on the left, the north. Go
through the door on the east, and you will be in the center portion of the
Aqueduct. This is where all the magic starts. First thing you need to do
once you're on the bridge is get the rope. It is located at I,3. The water
takes away 1/7 of your life every time you step forward (turning doesn't
count), so be sure to drop on a platform when you can reach one. Note that
you can't heal in the water. Once you have found the Rope, stick it in your
chest or quest bag and head to G,1. Pick the lock, turn west and go through
the teleport. This leads to the Reservoir, which houses Lord Aqueus, who must
be defeated to progress (remember that locked door North of the bridge? Also,
once you defeat Lord Aqueus, you will be able to travel through the waters of
the aqueduct without taking damage. (But be on the lookout for some
particularly nasty whirlpools!)
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.5] The Reservoir

Q: Alrighty, I made it to the Reservoir. What now?
A: The goal here is to kill the Lord Aqueus. Once he is defeated you can
progress further in the Aqueduct. There will be a door in the very first
room, and 3 teleports on the SW wall. Be sure to talk to Kilam, the thief
at A,16. He'll tell you how to open a certain door. Take the teleporter
labeled "one of three" in runes. You'll be in a small room with a door to
the south. Go through the door and to the west. You'll make a loop back to
where you started, A,5. Now, go take the other path, to the east. Here,
fight all the battles, and sip from the two fountains. Wizards will learn 2
spells here, Curse and Storm Wind, while others just get "refreshed". Now
that that's done, take the teleporter labeled "to two of three". You will
arrive at H,3. Take the door directly to the west you you, then go 1 south,
through the door at the west, and then make your way to I,3. Talk to the
thief there. After that, fight the battle at K,1, face north, and use the
Detect spell or a Crystal Ball to find a hidden door there. Go through the
door, turn right, and go through to talk to Sartiq the Giant. Turn south,
then pick the lock and go back to I,3. The thief will mark you. Repeat the
process to talk to Sartiq the Giant again, and he will teach you the true
chant you need to know to succeed in opening the door to Lord Aqueus, giving
his last life energy to you in burning the chant through into your mind.
After that, go to K,3, face north, and Detect (or use a crystal ball). Make
your way to L,9 (you should only have to step into the water once), and go
south 2 steps. Use the Rope (right click) to get some experience, gold, a
Long Sword, and a Silver Bar. You might equip the Long Sword, or sell it if
you have one or if it's not as good as the weapon you have now. Go back to
dry land (2 steps back north) and heal up. From there, go 2 steps east and
make your way to O,15. The door should now be open. Go through and defeat
Lord Aqueus. After you defeat him, go through the teleport at P,16 to the
beginning of the level, and then back to the Aqueduct.

Q: I keep getting killed by Aqueus in the Reservoir. Is there a simple
strategy to beat him?
A: The easiest way to defeat him is not to gain a dozen levels or press
your luck trying to hit him with a 5,000 damage wound. It's to purchase a
Basalt scroll from the Guild Hall, then use it on him. 9/10 times, you can
petrify him before he knocks you out. If you're a thief, rob him (pickpocket)
before killing him, it *might* be worth it! If you have the Petrify spell
maxed, use it instead, as it will be more powerful. Most of the time, unless
you are unusually strong, you have two chances to petrify him before you get
killed. Another strategy is to use a Shaman Scroll, which will kill him in 2
rounds for sure, but a Shaman Scroll is expensive, and if you want to save
money, you can always use the previous strategy.

Q: Are there any peculiar spots in the Reservoir I should be on the lookout
for?
A: Certain guilds will get the Curse, Storm Wind, and Energy Field spell.
As soon as I discover WHAT guild specifically, I'll put it here. The "spell"
fountains are located at N,8, A,11, and the end of the passage way after
going to the teleport "to one of three"

Q: One more thing. How do I get into the square at A,3?
A: Nobody I know or me has figured this one out yet.

Q: That was a tough one. I'm back at the Aqueduct. What's my next
destination?
A: Next place you will have to complete is the Twinion Falls. This is
not as tough as the Reservoir.

Q: First, should I explore the northern region of the Aqueduct?
A: It would be a good idea. First thing, go to K,1, face north, and follow
the path of doors. One door should say "continue northward through the rest
of this corner, my heroes". Follow the simple maze of doors  until you get
the message "Ah, a simple task, but necessary all the same". Go back to
the entrance and go through again. The locked door will be open. It will
teleport you to P,1, where you go 1 step south to receive experience points,
gold pieces, and booty. The second "maze" starts at O,8. Face westward and
go through the door. You'll be at a place with 2 doors, one to the south
and one to the east. Take either one, they're both the same, and follow the
path to the teleport, which will grant you gold pieces and experience points.
After going trough one of the paths, take the other one and repeat to get
a second load of experience points. That's about it in the Aqueduct.. for
now.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.6] Twinion Falls

Q: How do I get to Twinion Falls?
A: In the Aqueduct, make your way to P,16, face south and detect (or use
a crystal ball, which is a substitute for Detect). Go through the hidden
door, make your way to O,14,face south, and detect. Go through the door,
make your way to M,12, face east, and detect. Go through the hidden door,
make your way to L,13, face east, and detect. Go through the hidden door,
make your way to K,14, face east, and detect. Go through the hidden door,
make your way to E,16. To the east will be the door to the Falls.

Q: What do I need to do in here?
A: Well, point is to get the Cross Key, and complete the Sluice Quest.
To do this, from the entrance point turn north and go 5 steps forward. from
there, turn east and go 4 steps forward. From there, turn north again and
go 3 steps. Go through the door on your west and follow the maze of doors.
In the center of this area you will get the Cross Key. From there, make your
way to the locked door in the "bridge" running along the eastern wall. Unlock
it with the Cross Key, and go 2 steps to the Wizard who tells you not to
"play" with the switches, which is exactly what you must do. Turn west to
hit the switch, then head back out of the bridge area. Make your way to the
teleport at G,12 and walk through. Go through the door in the south area
of where you are now, where you will have a choice between two doors. Take
the western door to the Sluice area, which you couldn't access. From there,
take the southern door which will give you experience points and gold pieces.
From the SE corner of the Aqueduct, fight all the battles and go through the
teleporter, to a new area that you haven't been able to get through to
before.

Q: Are there any peculiar points I should be on the lookout for?
A: At N,13 there is a wizard who will give you his drink in exchange for
some gold, if you are the right guild. The drink will give you the Petrify
spell. Also, there is a ranger looking for his companion cleric in the
northern area of Twinion Falls. If you meet up with the ranger, then find the
cleric which is in the area you get to from TPing from G,12 then you will get
an Elixir of Health.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.7] The Coliseum

Q: What IS the Coliseum?
A: The Coliseum connects the Queen's Palace and the Aqueduct. It is the
ultimate test to your battle skills...so far.

Q: What do I do here?
A: There are 4 different arenas in the Coliseum. They are all about the
same difficulty. "Solving" an arena means getting out of it alive. In other
words, you must fight your way through to the exit of an arena, then go through
to the double doors at the eastern wall to get your reward of experience.

Q: Do I have to do all four?
A: No, but it sure helps. The experience points here will be greater than
any you've earned so far, so it's a practical place for gaining levels. You
will have to do at least *one* arena to get through to the Queen's palace.

Q: Are there any peculiar spots here I should be on the lookout for?
A: There are several places where you can push aside the columns and find
some useful items. Other than that, there aren't too much special spots.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[1.8] Queen's Palace

Q: Well, I've made it here. What do I need to do here?
A: The Queen's Palace is the last stage of her Proving Grounds. Your point
here is to get the Queen's Key and talk to Aeowyn herself about your quest.

Q: What path do I need to take?
A: There are 6 different paths. Each has its own reward of experience
(20,000 points each.), but only once will you get to talk to Aeowyn
and get her Key. The Queen's Key is used to open up the door in the SE of
the Dungeon Entrance, granting you access to the Night Elf Ingress - where
the fun begins :)

Q: In the dark room that I'm not able to map, there seems to be no exit.
A: Think again. The actual exit is in the NE of the room - the easiest
way to beat it is to take the path that leads from the south of the dark
room to the North instead of the path that goes north to east. Keep the
fact that the exit is on a NE wall in mind, and you should have no trouble
getting past it.

Q: The battles in the middle Arena got me down. What am I supposed to
do?
A: The battles here are the toughest yet. You will have to cast Energy
Field at the max level for the most protection, then Resist if you have it.
If you don't have either of these, purchase a Scroll of Protection from the
Guild Hall. You'll need lots of these to conquer the Palace.

Q: I'm stuck in the southern path. There is a strange looking rock that
I tried detecting, but nothing works. I'm certain that the path is here,
but how do I get to it?
A: Go around and see the old thief 1 north of where the rock is. You'll
have to take a long path with several battles, but you'll eventually get
to her, and she will tell you what to do.

Q: What do I have to do once I have the Queen's key and know about my
quest?
A: You can either take the teleport on the northern wall of her throne
room and go to complete more pathways, with more experience, or you can take
the southern teleport in the Throne Room to go back to the DE and start off
to the Night Elf Ingress. Congratulations, hero - you are worthy of Aeowyn's
Map Quest!
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[2.1] Night Elf Ingress and the Parchment Map

Q: How about a review of what I accomplished so far?
A: You gained levels, experience, and gold as well as learned new spells and
skills. You proved yourself worthy of being one of the Heroes who will solve
the numerous quests and step through to Immortality... Aeowyn has informed
you of four ancient map pieces that, when combined - create the ticket to
the ultimate challenge - the mighty beasts, the Dralkarians! Corpeus,
Astelligius, Malos, Pluthros, and Juvalad all await you... But you're
nowhere near to getting to the Guardians... for now...

Q: What should I do after I've gotten the Queen's Key and returned to the DE?
A: Use the Queen's Key on the SE door in the Dungeon Entrance. The key will
set and the door will remain unlocked forever. There are two paths in all
through here, but only one to the Night Elf Kingdom is now accessible.

Q: Once I'm in the Night Elf ingress, where do I go?
A: There are many different paths through the Ingress, which is the "base"
stage for the Map Quest. The first thing you'll want to do is talk to Snicker,
the thief at F,14. You'll find out he has three brothers, Sneer, Smug, and
Smirk, who run different shops. After that, exit the room and enter again.
You'll get an Iron Crown, which can be useful if you lack a piece of headgear.
Finally, exit and re-enter once more, and he will lift some more of your gold
- but give you a Thieves Ring. This is an extremely useful object - it casts a
detect spell equal to Detect at level 12. When worn on your right or left
hand, it also increases Agility. If you lack the Detect skill, this item is
of great use to you. It does have limited charges, but it can be "refreshed"
by exiting and re-entering the dungeon, via the Teleport spell. Another
important thing is that Wizards can get their Skeleton Key here. If you're a
wizard, go to F,10 and face west. The door will open automatically for you.
There are also several other exits here - one to the Statuary, one to the
Vault (a pit in which you must jump. It is located at G,8) and an exit to
the Lake Despair - which is deadly if you have the Life Jacket and even
deadlier if you don't! This exit to Lake Despair is just for the "view"
however - and has nothing to do with regards to progressing through the game.
It can be accessed via two secret doors, the first one at D,4 and the second
one at J,6.

Q: What is the Skeleton Key for?
A: Every guild can obtain their Skeleton Key quite easily. The key is to
reach inaccessible areas in the dungeon, which have a "skull and crossbones"
painted on them.

Q: I've located some really weird scrambled words in the place called
"clueless" in the Ingress. What are they supposed to mean?
A: Together, they reveal a special hint. This doesn't mean anything now,
but it will make great sense later.

Q: Where is the first place I should go now? The Vault or the Statuary?
A: The logical place to go would be the Vault. From here 3 more exits are
available : one to the Carriage house (go 1 north of where you arrive and
drop into the pit west of you), the Stables (from the place you enter the
Vault, turn west and drop into the pit. However the one you should take
now is to the north, the one to the entrance of Twinion Keep.

Q: There's a weird chest in the Vault that has a diamond shaped lock on it.
What do you do here?
A: Once you have the Diamond Lockpick you can come back here to get some
treasure and a 100,000 gold piece reward.

Q: What do I do in the Twinion Keep?
A: There is a hidden door 1 south and 1 east of where you will arrive. Face
east and use the detect skill, or the Ring of Thieves Snicker gave you. Pick
the lock, the head through to the "teleport" square 1 north and 1 east of
where you are. You'll be teleported to a long hallway. Here there is
another teleport which leads to the Thieves town, Tipekans. Leave it for
now - you won't be able to get in anyway, and continue west throughout the
hall. You'll run into a wall at the end of the hall with a left turn. Simply
walk through the wall here - it's only an illusion - and continue south.
Walk through the teleport and you'll land in another part of the Twinion Keep.
Keeping along the walls (don't go into the center just yet) go along the
walls to your east, south, and west. Once you are in the SW corner of the
room, go 1 step north and you'll be teleported to the Wine Cellar. Make your
way to A,1 and fight the battle to receive the Life Jacket. After that, take
the easternmost door to Cliffhanger.

Q: I can't pick the lock at the secret door near the beginning of Twinion
Keep. What should I do?
A: A Blue Lockpick (the best in the game) can be found in the Stables,
accessible from the Vault.

Q: What do I do here in Cliffhanger?
A: You are given an opportunity to get the Front Door key. There is also a
teleporter to the Infirmary. The "falling rocks" at O,13 will take you to the
Infirmary. The Key is located at L,16.

Q: Should I go to the Infirmary?
A: Yes. Drop down to it from the "falling rocks". You need now to get to the
Cloister. When in the Infirmary, instead of going through the doors, take
this path to avoid being thrown off track : go 2 steps west, 1 step north,
1 step east through wall, 2 steps north, 1 step west, turn north, teleport.

Q: What do I do in the Cloister?
A: Simply follow the path to the teleporter that takes you to the Gallery.

Q: I'm in the Gallery. What now?
A: The main part of the Gallery will be to read the plaques here. The
information your race's plaque gives you is extremely important. Read all
the plaques until one gives you a hint on your quest. There are three clues
in all in the Map Quest, and you must know all 3 to survive (later) in the
Cartography Shop. Each race's clues are different. What they mean is : once
you've collected all four of the map pieces, you can access the Cartography
shop, where you will be given different "tokens", or gems that will each
open a door at the end of the Shop. If you use the wrong token on a wrong
door you are instantly killed and brought back to the DE, so jot down the
clues as they will be vital to your survival.

Q: I got my clue. What now?
A: If you're a barbarian, you can get your Skeleton Key here. Go to L,4 and
face north. The door will automatically open up for you. If you're of any
other guild, go through the teleport in the NE to the Vineyard.

Q: What do I do here in the Vineyard?
A: You can get the Maze Key, which is for use in retrieving one of the map
pieces from aMAZEing, accessible from the Statuary. Knight can also get their
Skeleton Key here. Go to K,14, and face south. The door will automatically
open for you. You'll need to detect a secret door here - go to I,11, face
west and Detect (or use a Ring of Thieves). Go to the easternmost door and go
through it, where you will find the Maze Key. After you get the key, DON'T go
back to the southern part of the Night Elf Ingress. Instead, jump into the
pit at H,12 to get to the Fringe of Madness.

Q: Is there a way out of here? I'm trapped!
A: Yes, there's a way out - just follow these directions very carefully from
the exact place you drop into the Fringe : Go 1 step forward, turn right,
go 2 steps forward, turn left, 1 step forward, turn left, 2 steps forward,
turn right two times, two steps forward, turn left two times, two steps
forward, turn left, 1 step forward, turn right, and then walk through the
illusionary wall right in front of you.

Q: Phew. I'm out of THAT mess. Now where do I go?
A: This is the first Map you'll get - the Parchment map, plus 200,000
experience points. from the exit of the Fringe, take the path to the east
and follow along the path, fighting several battles. At the end of the path,
you'll receive the Parchment Map.

Q: Alright, now what?
A: Now that you have one of the legendary map pieces, teleport out and level
up. After that, you can either take the top entrance to the DE, or the bottom
entrance back to the Fringe. It is wiser to take the top entrance back to the
DE as it's quicker, and you'll be automatically healed and your mana will be
restored.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[2.2] aMAZEing, The Statuary, and the Slate Map

Q: How do I first get into the Statuary?
A: The portal to the Statuary part of the Enclave can be located in the Night
Elf Ingress, on the eastern wall.

Q: Once I'm in the Statuary, what do I do?
A: There are 3 portals available from here now, one to the graveyard (only
if you have the skeleton key) one to aMAZEing, which is your next
destination, and one to the Ballroom, which will only appear once you've done
the Lockpick quest. Clerics can also obtain their Skeleton Key here. Go to
B,8, face east and the door will automatically open for you. The portal you
want to take is the one to aMAZEing, which can be located in the far NW
corner of the Statuary.

Q: It would be aMAZEing to get out of here. Any tips?
A: First thing you'll want to do here is take the path to the east once you
arrive. Follow the path along until you come across two doors : Harmony and
Chaos. Enter the door that has your alignment's name on it, and you will
receive a Guardian that protects you from the hazardous areas of this map,
and also serves as a good shield, plus the Harmonic Guardian casts Resist in
battle, and the Chaotic Guardian casts Backfire. Do NOT go into the door that
is opposite your alignment. You'll lose many experience points and gold
pieces for not following directions. Once you have the you Guardian equipped,
head back to the start of the level. Note that throughout the level there are
certain "teleport squares" that warp you to different points on the map, and
even back to the Statuary or the Night Elf Ingress. These are to throw you
off, and more often than not, it's wise to use your True Seeing spell or a
Crystal Ball to detect any that might be around. After you make it back to
the start of the level, make your way to M,1, face north, and use the Detect
skill (or a Crystal Ball or whatever). Go through the hidden door. Make sure
that before stepping on "suspicious spots" that they are not teleport
squares, or you'll have to do the whole thing over again. From there, make
your way through the hallway. Be sure to read the plaques, when you find
which one is written in your race's language, be sure to jot down the clue it
gives you. It will be vital to your survival later in the Cartography Shop.
After you do that, make your way to L,13, face south and detect. Go through
the hidden door, avoiding any teleports. Go 1 step south, 1 step east, 1 step
south, face east and detect. Go through the hidden door, then go 1 step
north, 1 step east, 2 steps south, face south, and detect. Go through the
hidden door, then go 1 step south and 1 step west, fight the battle and you
will receive the Stone of Awareness. From there, make your way back to M,1
(using a teleport square *might* help). From there, go east, following along
the path and avoiding any teleports, until you reach L,9. Face south and use
the Maze Key which you got at the Vineyard. Take the following path : 1 step
west, 3 steps south, 4 steps east, 1 step north, turn west. The Stone of
Awareness will make a door visible. Go through the door, face north, and
detect. Walk through the door, and you will get the Slate Map, plus 200,000
experience points.

Q: Is there anything else in this maze?
A: Yes. First, make your way back to the beginning of the maze. Once there,
take the northern path again, and then turn east when you have the
opportunity. Here you will find another path, with two doors that appear when
you turn to look at them. One is the Tool Shed, and the other is the
Gardener's Shed. Harmonics should go to the Gardener's Shed and Chaotics
should go to the Tool Shed for rewards of gold and booty. Don't enter another
alignment's room however, or you will lose 20,000 gold pieces. The second
thing here is along the path from the tool and Gardener's Sheds. After
getting your reward from the shed, continue east along the path, and make
your way to E,7. Fight the battle here to receive the Tnerpes Key, which will
grant you a lifetime path to Tipekans.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[2.3] Tipekans, The Armory, the Races, and the Leather Map

Q: Why do I need to complete The Armory?
A: You will receive a Luminous Lantern, which will ensure that you are
successful later in the Graveyard. Also, you will have the opportunity to
get the Reforged Skeleton Key, which will be required in the Rat Race and the
Race Track. You can also receive your Guild Armor here ; Barbarians get a
Barbarian's Plate, Knights receive a Knight's Breastplate, Rangers will get a
Ranger's Chainmail, Thieves will snatch a Thief's Cloak, Clerics will
discover a Cleric's Chainmail, and Wizards will find a Wizard's Sash.

Q: Now that I know why, how?
A: You can get to the Armory from the Stables. The easiest path to take would
be to drop to the Vault from Night Elf Ingress and take the pit to your west
immediately after you drop in. From the Stables, you can go to the Breezeway
via a teleport in the western section of where you arrive. Follow the
passageway along to the teleport to the Armory.

Q: I'm lost in The Armory. All around, shields smack me on my head, I get hit
with poisonous darts, and seem to be stuck in the middle of nowhere. What's
the point here?
A: When you first arrive in the Armory, be sure to have the Fellowship key,
which can be found in Lake Despair, and the Skeleton Key (see Keys &
Lockpicks section). From there, the first thing you must do is disable the
traps in the NE section so you can go through. Make your way from the
entrance to L,5, face north, and detect. Go through the hidden door and
follow the path along to M,7, where you will face north and detect once again.
From there, follow along the hallway and make your way to L,4. Face east to
disable the traps. Now that you've done that, take the hallway back out and
into the main room. Go to M,12, face east, and detect. Go through the hidden
door, follow along the path to the east, then turn to the west and go through
the western door. Follow along this path to north, then to the east. You'll
come across a door and a teleport. Go through the door, NOT the teleport, and
go through the teleport beyond. You will arrive at A,7. From here, go west to
B,3, face east, and detect. From here, take the hallway around to D,2, where
you will receive the Spidersilk Helm. Be sure to keep the helm; you will need
it for a purpose other than headgear. From this room, go back into the main
room. From the main room, make your way to M,11, face south, and detect.
Follow the passageway to the door at the end, where the guard will let you in
IF you have the Spidersilk Helm. Go through the door, go 1 step north, and
detect. Go through the hidden door, where you will hit against a wand on the
door, which opens a door in the middle of the room. Go back to the main room
and go to L,8. Face north and unlock the door with your Fellowship Key. Take
the teleporter beyond this door, which will lead you to another hallway. Take
the southern path, pick the lock of the door that is locked, and follow
through to the teleporter at the end of the passageway. From this new area,
head north through the door and follow north until you reach a wall. From
there, go east, and then south. The door will now be open. Take the path
along to B,12, where there is a teleport. Step through the teleport, then
follow the next path along to yet another teleport. Go through this teleport,
make SURE you have the Spidersilk helm, as the poisonous darts here will kill
even the strongest character in 2 steps. Walk through to E,14, where you will
receive the Luminous Lantern. Keep it, as you will need it in the Graveyard.
From there, go back to where the "fork" in the road was and take the path to
the east and then the north. From here, take the teleporter to the Vault.
From here, go back to the Stables, the Breezeway, and then back to the Armory.
From the main section, go back to L,8, face north, and unlock the door with
your Fellowship Key. Once again, go through the door, and then through the
teleporter. Go exactly the way you did to get the Luminous Lantern, except
this time, in the area right after the second teleporter, take the path
BEHIND you, to a series of doors. Walk south, looking at each of the doors
until you find the one for your guild. To tell which one is for your guild,
look at them, and the one that has the message "there is a skull and
crossbones scratched into the door" is the one. Unlock it with the Skeleton
Key and go through the teleporter beyond. From there, you will be teleported
to 1 of 6 different 4-square areas in the corners and middle of the Armory.
Before going through the teleport (this is important) make sure to go through
the doors. You will be given your Guild Armor, and both the Skeleton and
Fellowship Keys will be taken from you. However this is necessary. From
there, take the teleporter out. To receive your "reforged" Skeleton Key,
simply go back to the area where you originally found yours (see Keys and
Lockpicks). Note that your new Skeleton Key will look exactly like the
original, even having the same name, but it is really reforged. Plus, this
"new" key will be required in the Rat Race and the Race Track.

Q: I'm back at the start of the Ingress now. What should I do next?
A: Your next move is to snatch the Leather Map and a clue from the Rat Race
and the Race Track. Don't let the name fool you - Race in these stages means
what species you are (orc, troll, elf, human, etc.) First thing you will
need to do from the Ingress is get the Emerald Lockpick out of Dark Alley.
To get to the Dark Alley, you must first get to the Carriage House. Do this
by going to the Vault, going 1 step north of where you arrive, and then then
falling into the western pit. From the Carriage House, follow along the path
to the north. Ignore the first teleporter to Lake Despair - you'll get there
later, and follow along the path to the second teleporter. Go through the
teleporter to the Dark Alley. From there, follow along the path, not going
through any doors or teleports until you reach a fork in the road. From
there, go up against the wall, and go 1 east, 1 north, and through the door
in front of you. Fight the battle to get the Emerald Lockpick. Note: Thieves
can also get their Skeleton Key here. From the entrance, follow the path
along to the very first door which will appear on your right. Go through the
wall, turn opposite the other door in the corridor, and the door will
automatically appear.

Q: What do I do once I have the Emerald Lockpick?
A: You must trade lockpicks at the thief town Tipekans to gain access to the
Ballroom. Make your way to the Vault from the Night Elf Ingress, then once
there, take the teleporter at the northern end of it. From the Cellar, go 1
step south and 1 step east and detect the eastern door. Pick the lock on the
secret door, and then head 1 step east, 1 step north, and 1 step east to
teleport yourself to the next portion. From here, go along the hallway until
you see a teleporter to the south. Walk through this teleporter, and you will
be at Tipekans. From here, take either the eastern or the southern passageway.
The guard will take your Tnerpes key, and grant you lifetime access plus a
Pummel Scroll. From here, make your way to A,12, face east, and detect. Go
through the door, and make your way to C,14. Face north and detect. Go
through the secret door and make your way to D,16, where a cleric will trade
you your Emerald Lockpick for a Diamond Lockpick.

Q: What do I do with the Diamond Lockpick?
A: It's a wise idea to first go back to the Vault and go through to I,10,
where you will unlock the safe with several treasures and 100,000 gold
pieces. After that, head back to Tipekans. Make your way to H,15, face north,
and detect. From there, go through the secret door, 1 east, and face south.
Open the door with the Diamond Lockpick and make your way to F,14, where you
will trade the Diamond Lockpick for the Sapphire Lockpick.

Q: Now that I've got the Sapphire Lockpick, where do I go?
A: To get to the Ballroom, you have to use your Sapphire Lockpick to open a
door. Go to M,15 and face east. The door will reveal itself. Follow along the
path until you reach the teleporter to the Ballroom. Note : when the thieves
tie you up at G,4, keep the rope. It can be used at Cliffhanger to swing over
the pit to visit a fountain and get a skill.

Q: Now I'm at the Ballroom. Where should I go first?
A: You'll have to detect your way out of the room where you arrive. Go 1 step
south and 1 step east, face east, and detect. From there, go to D,9, face
west, and detect. From here, you may enter the Rat Race via the teleporter at
D,7. If you have the Key of C, you can open the door at C,6, where you will
find 2 fountains. One will give you knowledge, and the other will poison you.


Q: What do I do in the Rat Race?
A: In here, you will be able to obtain a map piece, and a clue to your
"tokens". This room is paired with the Race Track. It's very frustrating,
as you must find your race's door. There is a hint on these rooms however -
the locations of the doors. The doors are as follows : In the Rat Race -

E,4, face west (Halfling)
K,3, face south (Elf)
C,15, face west (Orc)
C,5, face east (Troll)
K,6, face east (Dwarf)
P,8, face south (Gremlin)
N,12, face south (Human)
I,10, face south (Gnome)
        Race Track
P,3, face south (Gnome)
O,8, face west (Halfling)
M,15, face north (Human)
J,12, face north (Troll)
H,5, face north (Gremlin)
D,8, face east (Dwarf)
E,12, face east (Elf)
G,3, face east (Orc)

To find the door for your race, make sure that you get the message "there is
a skull and crossbones scratched into the door". Then, use your (reforged)
Skeleton Key, and go through the door. In the Rat Race you will get your
clue, and in the Race Track you will receive the Leather Map - the third of
four.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[2.4] The Graveyard, Snake Pit, and the Snakeskin Map

Q: Now, how do I get the fourth map piece?
A: To get the last map piece, you must first have the following items: your
Skeleton Key, and the Luminous Lantern from the Armory. This will make sure
you are successful in the quest.

Q: Okay, where do I go from the entrance of the Night Elf Ingress?
A: Take the eastern portal to the Statuary. From there, go through the portal
in the SW corner to the Graveyard. Note: this portal will *only* appear if
you have the Skeleton Key. The Graveyard is a very tough area as it cannot be
mapped. However, you can have a slight orientation of where you are if you
run into a room that has a torch; then you can get a glimpse of the dark
graveyard before the winds douse your flame. The first thing you will need to
do is get the Snake Charm from the crypt. This magical medallion will prevent
you from being killed instantly by the fearful Giant Asp, and turn him into a
weakling snake. From the entrance of the graveyard, take the gated designated
the "NorthEast Gate" on your right. From there, go forward until you run into
a wall. Fight the battle there and turn west. Walk forward until you reach
another wall. Go 1 step west, 1 step north, 1 step east, and unlock the door
in front of you. Go through the door and detect the 3rd wall on your left. Go
through the hidden door and follow along the passageway to your west. When
you come up to the locked door at the end of the passageway, use the Luminous
Lantern. The door will now be unlocked. Go through the door and take the
passageway to your right. When you run into the first door, go through it. Go
1 step north, turn left, go 1 step north, turn left, go 1 step north, and you
will end up at the Crypt.

Q: What do I do here in the Crypt?
A: In the Crypt, your main goal is to get the Snake Charm to be used in the
Snake Pit. From the entrance, make your way east to A,16, face north, and
detect. Go through the hidden door, make your way to D,11, face north, and
detect. Go through the hidden door, go 1 step west and you will get the Snake
Charm. Your Luminous Lantern will fade and dissipate when this happens, but
you won't need it anymore anyway.

Q: What do I do next?
A: With the Snake Charm, go back to the entrance of the Graveyard via the
Statuary or the Carriage House. From the entrance of the Graveyard, once
again go through the same way as you did for the Snake Charm _except_ this
time don't go through the locked door to the old tomb. Instead, ignore it,
turn east (assuming you are facing the door) and walk along the passageway
until you run into a wall with a torch. From there, turn east and go along
the path, not taking any turns until you fall into and open grave. From the
grave, go 1 step forward and 1 step east, then walk through the door. Take
the door beyond it to the Snake Pit (termed Sn k P t in the game).

Q: What is my goal in the Snake Pit?
A: To get the Ruby Lockpick. From the entrance, simply go along the path,
fighting the numerous snake battles until you reach the door on the other
side of the room. Be sure that you have the Snake Charm when you go through
this door, or otherwise, you'll be dead before you realize it. Go through the
door, and the Giant Asp will retreat, fearing your magical talisman. Follow
it, and you'll eventually come to fight it. Kill all the enemies, then step 1
step south to the Ruby Lockpick and some other treasures. From there, take
the door to the south to return to Night Elf Ingress.

Q: Now that I've got the Ruby Lockpick, what do I do with it?
A: The Ruby Lockpick is used to open the shops of the Snicker's three
brothers, Sneer, Smug, and Smirk. Smirk is the only honest brother who will
lead you to the path to the Snakeskin Map, the others will merely throw you
off track. The good thing is you don't lose your lockpick when you take the
wrong path. The bad thing is, not surprisingly, the path to Smirk's Emporium
is a tough one.

Q: How do I get to Smirk's Emporium?
A: If you have the Rope from Tipekans, you can go to the Infirmary, and swing
your rope over a rock by going through one of the doors instead of going
through the teleporter, however, if you don't have the Rope, you will have to
go through the Fringe of Madness to get to the Library section of Twinion
Keep. The easiest path to take to the Fringe is through the Ballroom ; the
easiest path to take to the Ballroom is through the Statuary. From the
entrance of the Statuary, go through and face the statue of Lord Zzuf. It
will move aside and you can go through the eastern teleporter to the Ballroom.
From the Ballroom, take the teleporter to the Gallery, from which you can get
to the Vineyard, where you drop into the easternmost pit to the Fringe of
Madness. Once you get through the Fringe (for directions, see the Parchment
Map quest), take the pit to the west of where you emerge. You will be dropped
into the Library. Walk to I,13, face south, and detect. Go through the door
and make your way to F,5. Face south and use the Ruby Lockpick. Smirk's will
be open for business. Go through the door and follow the path to the east.
Walk through the teleport and you will be at Tipekans. Take this path to the
teleporter at the end, then walk through. You will be teleported to the
center of Tipekans. Walk around and through the door at the end and you will
receive the fourth and final piece, the Snakeskin Map!

Q: Alright! Now what...?
A: Go and level up in the Guild Hall. You've reached the final point of the
Map Quest. Your next destination - the Cartography shop.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[2.5] Cartography Shop

Q: How do I get to the Cartography Shop?
A: Before you can actually enter the Cartography Shop, be sure to have the
following items :

(1) All four map pieces (Parchment, Leather, Slate, Snakeskin)
(2) All 3 clues as to your tokens. They will be critical here, so be sure to
have them. Also note the names of the adventurers who give you the gems. If
you don't have three clues down, they are located in aMAZEing, the Gallery,
and the Rat Race. If you're lazy and don't want to search for them, look to
the end of this part for information for your race.

If you have the items, you may enter the Cartography Shop. From the Night Elf
Ingress, go to the Statuary. From there, enter the Graveyard. Now, go through
the NorthEast gate, and follow until you hit a wall and fight a battle. From
there, turn west. Follow along until you fight a battle and reach a wall.
From there, go 1 step west, 1 step north, and turn east. Follow along until
you reach a wall with a torch. Go along this passageway, not taking any turns
until you fall into an open grave. From that point, go 2 steps forward, turn
west, go two more steps forward (walking through wall). Then follow the path
and take the first east turn. Follow the passageway here until you reach the
end door. Walk through it, and then, at the end - take the portal to the
Cartography Shop.

Q: I didn't know there was going to be a test. These questions are getting me
down.
A: Here are all the answers to the True/False questions.
(1) Unity Fountain is found in Rat Race - True, walk east.

(2) Fellowship Fountain is located in the Armory - False, walk north.

(3) Harmonics should visit the Tool Shed for a reward - False, walk east.

(4) Smug owns a Pawn Shop - False, walk south.
From here, make your way to C,15, face south, and detect. Go 2 steps south,
face west, and detect. Hit the fountain in the western square of this room,
to get an attribute boost. From there, go back out the secret door and
through the teleport. From here, go 1 step south and 1 step west. Go through
the door to the south and follow along the passageway to meet Kalydor, who
gives you a token. From there, follow along to the next riddle.

(5) The Vault is found in the Twinion Keep - False, walk west.

(6) Angel Fountain is found in Cliffhanger - False, walk north.
In the next area, take the eastern path to the teleport. Follow along this
path until you reach a small room where you seem to be stuck. From the
entrance of this room, go 2 steps east, 1 step south, face west and detect.
Follow this path to meet Syrene, who gives you a token. Go through the
teleporter.

(7) The Emerald Lockpick is exchanged for the Diamond Lockpick - True, take
the door to the south.
Take the teleport, follow along the path again, and you will meet Dabealis,
who gives you a token.

(8) The only way to Race Track is from the Rat Race - True, walk north.

(9) A bard sings his tale in the Cloister - False, walk east.
From here, you will meet Syrene, who gives you your final token. Go through
the teleport. This is where you will use your clues. If you have pieced your
clues together and know in which order to use them, go ahead through the door
for your Race. If you haven't figured your clues out yet, see the next
section.

Q: I can't piece my clues together. How about telling me what goes with what
race?
A: If you lost your clues regarding to your tokens, or didn't find them in
the first place, or can't figure them out, here is the order of tokens for
each race:

Human : Coral, Topaz, Pearl, Ebony
Orc : Pearl, Opal, Coral, Topaz
Elf : Ebony, Opal, Coral, Topaz
Troll : Opal, Coral, Topaz, Pearl
Gnome : Ebony, Coral, Opal, Pearl
Dwarf : Opal, Topaz, Ebony, Coral
Hafling : Topaz, Pearl, Ebony, Opal
Gremlin : Pearl, Ebony, Opal, Coral

Q: What do I get now?
A: Walk through the doors with the correct tokens and you will meet the Queen
and receive a Whole Map. Plus, you'll get 2,745,000 experience points, which
should boost your level. Once you have the whole map, proceed to the Dungeon
Entrance and go through the door that you originally opened with the Queen's
Key. Face the plaque that is on the northern wall, opposite the teleport to
the Night Elves' Ingress, and the map will let you pass. From here, go into
the teleport beyond to ultimately meet your Fate...
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[2.6]  Loose Ends

Q: What loose ends?
A: There are several spots in the Night Elf Ingress where you can get a
special reward for visiting. So far, I've only found a handful of these
spots.

Q: Where can I find them?
A: Here they are. Simply visit these fountains to get a skill/spell:

(1) Cliffhanger. If you access this area from the Wine Cellar in Twinion Keep,
you'll find there is a pit with a boulder protruding over it and a fountain
that you appear not to be able to reach. You'll need the rope from Tipekans
here, which is accessible when you do the "lockpick quest" or exchange
lockpicks to get to the Ballroom. Once you have the Rope, simply go to that
point and step into the pit. Walk around the ledge to gain a skill.

(2) The Carriage House - There is an unsightly pit in the southeast corner of
here (when you access it from the Vault). Walk into this pit, which isn't a
real pit, just some hole that you'll injure your ankle in, face east, and
walk through the wall. Visit the fountain there.

(3) The Ballroom - In here, there are two fountains. You'll need the Key of C
to open the door to them. The southern one blesses you and the northern one
poisons you, or so I believe, but the poison isn't deadly, so you can visit
both without getting killed.

(4) Race Track - Access Race Track from any TP in the Rat Race. Once at the
"official" entrance, which is about 2 steps south of the northwest corner,
make your way to B,6, face north, detect and pick the lock to open the
secret door, and once you're done with that, go 2 steps north to get the
Poison Cloud spell, or so I believe it is the same for all races/guilds.

(5) In the Rat Race, there is a fountain located at O,16. Visiting this
fountain will either get you a spell, or it may fetch you nothing at all -
once again, unfortunately, I don't know which races/guilds get what here.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[3.0] Prelude to the Dralkarian Quest

Q: Clue me in on what I've accomplished so far.
A: Before you get to the Dragon's Ire, you will be explained to that the
dralks require extreme measures before you can reach them. Each one posses a
unique ring that allows the five to control and guard the Portal of Time. You
are not told this, but each of the dralks resides in their unique home, but
their throne rooms are located in Spheres Asunder. However, the Dragon's Ire
is just the first step towards the mighty beasts... you will be required to
explore a maze of areas deep inside Yserbius and under Twinion before you are
gained access to the five portals that lead to them.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[3.1] Dragon's Ire and the Chessboard quest

Q: How do I get started in here?
A: The Dragon's Ire is proof to the civil war between the Praxis and Erebus
fiends that dominate the domain. The crumbling walls and crushed floors here
act as the testimony. The wars here have carved out long series of pits and
tunnels, rivers of lava and ancient teleports. First off, you will need to
complete the Chessboard quest. For this, you will first need the Lava Glove.
This fulfills the words of the carving in Gauntlet Droit, which states that
you will come back here much later, when you are stronger and more
experienced. For now, just go and get the Lava Glove from Gauntlet Droit. You
should have no trouble with it at all.

Q: What do I do once I have the Lava Glove?
A: Then, you must reach the Chessboard. Doing this requires a series of steps
on fake pits, so watch your way and make your way to the pit at O,5. Step
forth and into it, as it is illusionary. From there, make your way to the
door to the east. From here, you will need the Lava Glove. Face each one of
the lava spots until your lava glove starts "glowing with white-hot intensity,
pulling you in this direction". This signifies that the lava square in front
of you is illusionary. Step through the lava river in this manner until you
reach the double doors at K,13, and L,13.

Q: I'm in the Chessboard. What do I do?
A: Here's how it works ; this chessboard is a more interesting version of the
one that Arnakkian built so many moons ago. Each time you step on a square,
you will fight a monster. It will be either a knight, rook, or bishop.
Knights, as in chess, go 2 steps forward and 1 to the side. Rooks and bishops
however, respectively move 1 step either up and down and side to side, or
diagonally. Every time you defeat one of these monsters, you will gain its
powers. Simply, what this means that if you defeat a rook, you will be able
to move up/down/sideways, and if you defeat a bishop you will be able to move
1 step diagonally. I haven't found the pattern to how you can judge whether
you move clockwise or counterclockwise, but the answer to the riddle is below.
You MUST follow these instructions VERY carefully. One wrong step and you
could be dead. From the entrance, go to the first square (past the entrance
water) and fight the Bishop there. Now, go 1 step east into the water, and
walk 1 step forward again. You will fight a Dark Knight. Defeat him and walk
1 step east again. Walk back into the square and you will fight a Lava Rook.
Defeat him and face north. Take 1 step forward, and you will fight a Bishop.
Defeat him and face south. Take 1 step and you will fight a Dark Knight.
Fight him and face south. Take 1 step and the Chessmaster will turn you away,
claiming you are not powerful enough. Walk back to the entrance of the
chessboard and repeat the procedure. This time, when you get to the
chessmaster, he will get angry and fight you. Defeat him, then walk 1 step
south. Don't go in the teleport yet, however - you have yet another master
to defeat. From that spot, teleport out. Go into the Guild hall to gain any
levels you might have gotten and use the TOP DE to get back to the very
first level, the Dungeon Entrance. From there, walk to Dragon's Ire and go
back to the Chessboard. Before this step, you may have noticed that the
chessboard is perfectly symmetrical - except for the battles. This solves
your next step. Simply put, you will have to walk to the west side of the
Chessboard, in the small square of water that is "looking out" of the west
side to the actual Chessboard. Once you are there, follow these steps :
from the water on the west, go 1 step east and fight whatever enemy is there.
Repeat until you defeat the rook. After defeating him, go face north, walk 1
step forward, and fight the bishop. After defeating the bishop, face east and
go 1 step forward. Fight the knight there and defeat him. From there, face
south, and take 1 step. The Master Praxis will turn you away at first, but
bug him a second time and he will rise to your challenge. Defeat him, then
go 1 step south to your reward. It is wise to defeat both masters for the
experience; however it is not required.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[3.2] Dragon's Flame and Hocus Pocus

Q: That wasn't so hard. What's next?
A: Next is the Dragon's Flame quest. This quest is not very simple, but it
is still not as hard as some of the ones you still have to face. Still, it
forms a formidable challenge. From the Dragon's Ire, you must defeat at
least one of the Chess Masters to gain access to the Dragon's Flame. If you
defeat both, you will have a choice of which Dragon (Osterog or Gambril) to
help. Sadly, you can only do one of the Dragons' quests, but however they
will give you the exact same treasure and rewards, so even if it was able to
help both of them, it would earn you nothing more than a double load of
treasure. With that out of the way - here is the description: the Dragon's
Flame is mostly a roughly circular layout on the outside walls, where you
have to go around and find 4 different wizards. As either Dragon tells you,
your success may depend on greater magic than you know, or in other words,
you will need to visit the wizard for additional magic protection. Both of
the Dragons would tell you that they are fighting with their rival dragon
(Osterog and Gambril are rivals, as you may remember) and will reward anyone
greatly if they bring them proof of the kill. Now, on to another explanation:
the wizards can cast spells that you are not aware of and will never get:
the Chariasmic Aura, Invisibility, Vapor Cloud, and Chameleon Shroud.
The easiest way to describe the steps needed to complete this quest are the
following: You must visit all 4 wizards, no matter if they give you
protection against the dragons or not, you must take all 4 teleports at
least once each, and you must visit all 4 "companions" in the center of the
stage. The best way to do it is the following: Go to any of the wizards, and
then take a teleport. Continue this, visiting different wizards until you've
gone to all four, and match each one up with a teleport. The teleports will
take you to the south, west, east, and north parts of the center, but not
respectively. the order changes with race and guild. However, the first
thing you need to figure out is which teleport takes you to the southern
part of the center. Follow north and around the bend there; you will see a
small alcove with a lava pit 1 step south of it. Go into the alcove and
you will find a Troll Knight. Visiting him is the easiest way to figure if
your magic protects you well enough; if he says that you appear to be well
protected, you have the right wizard, but if he tells you otherwise, try
another wizard. Regardless of what he says, go to all four wizards, even if
you find the right one before you go to all four. Once you've visited the
four, go back to the one that protected you (remember, you must visit the
wounded troll knight to find out) and take any of the teleports. Now, walk
around and you will find the four companions at I,6, I,9, O,8, and K,9.
Repeat the procedure until you have found and talked to all four companions;
once you have done so, go back and see the wizard that protected you. Take
the teleport to the troll knight. He will say you are well protected,
assuming you were at the right wizard, and send you off with thanks for
healing his wounds. Once you've completed this task, go back to the outside
"walkway" around the center area and visit "your" wizard. Now your task is
to find the dragon you are seeking. It is relatively easy; if you visited
Gambril and are seeking Osterog, go to the teleport of the four that gets
you to the Troll Knight, and one step west of the troll knight will be
another alcove. Enter this one and face west; the door to Osterog should
appear. BE SURE that you have the right magic, but if you are not sure then
visit the Troll Knight first. If you do not have the right magic, the Dragon
will sight and kill you before you get to him, therefore - you will have to
start over again.  If you are helping Osterog and seeking Gambril, take the
teleport to the north section of the center (you SHOULD know which one it is)
and from there go to L,6, and face west. The same rule about magic goes
for Gambril. The door will appear. If it doesn't, be sure that you did not
leave the map in any way while doing this quest; otherwise, you'll have to
try it again. Good luck ;)

Q: Should I go to Hocus Pocus?
A: Yes. The passageway to Hocus Pocus can be found in the southeastern
section of Dragon's Flame, or you can get there from the Hopeless Hallways
later if you wish. For now, take the teleport from the Dragon's Flame.
Important note : when you get to Hocus Pocus it is important that you DO NOT
leave the map or teleport after you start your quest, as all the items will
"reset" and you will need to start over.

Q: Once I get to Hocus Pocus, what should I do?
A: Hocus Pocus is a village of wizards. This quest is easier than the
Dragon's Flame quest, but not quite as rewarding. The goal here is to show
that you are worthy of using magics to weaken and destroy evil spawn. Your
first move is to go to the four "shops" at C,9, C,11, E,9, and E,11. At each
of the shops you will purchase some items (NO, you don't get a choice of
which items you want to buy), but they are not very expensive and at least
most of them are useful. Once you've done that, you will need to visit
Faerlun the Magician. He dwells at A,15. You'll need to detect a secret door
in the east wall at A,13. Faerlun tells you that he seeks two items to
complete his tests and experiments for new spells; you must bring him the
ingredients, which are the bat wings and the eye of newt. After speaking to
Faerlun, walk back to B,12, face north, and walk through the illusionary
wall and follow to the north, where the door should be open. The mayor will
say that word has been sent to the Training Area guard, where you will be
allowed access. Walk to F,11, face west, and go through the illusionary wall.
Follow along the path, NOT taking the door in the west, until you reach a
teleport. Go through it and you will be teleported to A,1. Face north and go
4 steps forward, walking through the illusionary wall. Then, go 1 step east,
2 steps north, 1 step east, and then walk north trough the door, not taking
any turns to the left or right until you reach a second door. The guard will
nod and let you pass through. Now, go to K,6. fight the battle and face east.
Walk through the wall and head north until you run up against a wall. From
that point, walk to the east. Do *not* take the teleporter. Instead, follow
the passageway to the point where there are two doors to the north and to
your south. Take both of them and your abilities will increase due to the two
magicians who live there. Once you've done that, walk back to K,6. Face east
and take 1 step, then go 1 step north, and 1 step east through the wall.
Follow the path east to L,11, where a wizard will give you the Eye of Newt.
From there, go to K,4. Face west and go through the wall. Then, follow along
the passageway to the teleporter. Walk through the teleport. From where you
arrive, face north and detect. Walk through the secret door and face east.
Walk through the wall and follow along the path to P,11, where you will get
the Bat Wings. Once you have then, walk along the paths way back to A,15 and
talk to Faerlun. He will thank you for the ingredients and reveal a door to
the east. Walk through the door to A,16 and a teleport. Walk through the
teleport and you will be at P,16. From there, walk 3 steps south, 3 steps
west, 3 steps south, and 3 steps west. From there, take the door to the west
and follow along the path to receive a reward of EGB.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e
[3.3] Hopeless Hallways, Halls of Babble, and Concordia

Q: After I complete Hocus Pocus, where should I go?
A: After completing Hocus Pocus, go back to the Dragon's Ire. Your next step
will be the Hopeless Hallways. This room MUST be completed if you want to
progress further through the game. There is another room, the Halls of Babble,
that seems optional, but it is really required to complete Concordia, which
is required to complete your quest. The Hopeless Hallways are a maze, with
lots of pits that change as you progress. Many are illusions, some drag you
way back into the game by dropping you off at the Queen's Palace, for example,
and some teleport you to different spots in the map of Hopeless Hallways.
Concordia is the place where Chaos and Harmony are joined to attain the
ultimate power of Unity, one that owerpowers even the mighty Dralkarians.

Q: How do I get through to Hopeless Hallways?
A: The portal there is in Dragon's Ire. From the entrance of the Dragon's Ire
go 1 step east, 1 step south, and 1 step west and through the portal.

Q: How do I complete this quest?
A: You have to go "South to North four times". In other words, you must
progress through the pits to the south, where a doors will appear at the
right time. The southernmost area is unmappable, and you must find several
teleporters that will teleport you to the northernmost row. Your goal is to
sip from the Fountain of the Better End. But first, you must find the clerics
that are hiding out here. One will tell you about what you need to do,
another open the first door to the south, and the last one give you access to
the two bottom rows. The first thing you need to do is find the Cleric who
grants you access to the bottom rows. He is located at M,14. To get there
from the very spot that you enter the Hopeless Hallways, go 1 step north, 1
step east, 1 step north, 2 steps east, and walk 1 step south into the pit.
From there, make your way to M,16 (you should be able to get there without
going through any more pits). From there, face west and walk through the door.
Follow this path and you will meet up with the cleric. After exiting the
4-square room, walk back to the very first pit you went through. Go through
it again and this time, follow these directions: From the place that you got
"teleported" to from the pit, go 2 steps south, 3 steps west, and walk south
to step on a pit, which is an illusion. From the pit, walk south until you
hit a wall. From there, turn west and walk west to the next pit. Step on it
as it is an illusion. From this pit, go 4 steps west, and turn north. Go
through the wall, which is also an illusion. From there, go north to the next
pit. Step on it and go 2 steps north. From that point, walk west until you
hit a wall. From that point, walk south to the next pit, which is once again
an illusion. From that pit, go 3 steps south, 1 step east through the door,
and follow this path to the second Cleric. He will open the very first door
in the southern area for you. Exit the small room and walk east to the next
pit. from that pit, go 2 steps east, and walk north trough the wall and to
the next pit. From that pit, go 2 steps north, and west to the wall. From
there, go south to the next pit, step on it, and go 4 steps south. Face south
and you will see a door. Walk through the door, then follow these directions:
Turn left, go 2 steps forward, turn right, go 1 step forward, turn left, go 1
step forward, turn left, go 1 step forward, turn right and go through the
teleport. You will be teleported to A,1. Turn around and read the plaque.
Then, go 3 steps east and face north. Read the plaque there and take the
teleport to your east. You will be teleported to the heart of the maze. From
there, go 3 steps south, walk east and step on the next pit. Go 1 step east,
then face south and walk until you reach a wall. Then, walk west and step on
the next pit. From that pit, go 4 steps west, then go through the northern
wall and walk 3 steps north to then next pit. From that pit, go 2 steps north,
face west, and walk until you hit a wall. From there, face south and go to
the next pit. Step on the pit and walk south until you reach the door again.
Go through the door, turn left, and go through that door. Go 1 step forward,
turn right, and go another step forward. Then, turn left and go 2 steps
forward. Turn left, go 1 step forward, turn right, and go 4 steps forward to
wall. Turn right, go 1 step forward, turn right, and walk through the door.
Go 2 steps forward, turn right, and walk through the teleport. You will be
teleported to E,1. Turn around and read the plaque behind you, then go 3
steps east and face north to read the plaque. It will tell you then next
door will be open. Go through the eastern teleport. You will be teleported to
the center of the maze. Take the same path, stepping on the illusionary pits
back to the doorway in the SW area of the Hopeless Hallways. Go through this
"star-shaped keyhole" door. Turn left and go 2 steps forward, turn right and
go 1 step forward, turn left and go 2 steps forward, turn left and go 1 step
forward, turn right and go 4 steps forward, turn right and go 1 step forward,
turn right and go 1 step forward, turn left and walk through the teleport,
then go 2 steps forward, turn completely around, and teleport. You will be
teleported to I,1. Turn around and read the plaque behind you. Then, go 3
steps east, and face north to read the plaque. Go through the teleport to
your east. You'll be teleported to the center of the maze again. From that
point, go 2 steps west, 2 steps north, 1 step west, and south to step into
the pit. From that point, go 2 steps south, 3 steps east, 3 steps north, 3
steps east, and south into the pit. From that pit, go 7 steps south, 1 step
west through the wall and into the pit, then walk west and step on the next
pit that you encounter. From that pit, go 2 steps west, south to the next
pit, south to the next wall, 3 steps west, then walk through the wall to the
north and walk to the next northern pit. Then go 2 steps north, 3 steps west,
south to the pit, 2 step south, then 3 steps west, 3 steps south and walk
south to the door. Turn left and go 2 steps forward, turn right and go 1
step forward, turn left and go 2 steps forward, turn left and go 1 step
forward, turn right and go 4 steps forward, turn right and go 1 step forward,
turn right and go 1 step forward, turn left and walk through the teleport,
then go 1 step forward, turn right, go 1 step forward, turn left, go 2 steps
forward, turn left, go 1 step forward, turn right, go 3 steps forward, turn
right, go 1 step forward, turn right, go 2 steps forward, and then teleport.
You will be teleported to L,1. Turn around and read the plaque, then proceed
east and through the door to sip from the Fountain of the Better End. You
will receive a stat boost, plus a load of experience and gold. Your next step
will be the Halls of Babble, where you will learn the different languages of
each race to proceed and set the clues.

Q: Where is the portal to the Halls of Babble?
A: The portal is in Hopeless Hallways at D,11. Note that to get through to
this teleport, you'll need to step on a series of pits. Once you've completed
Hopeless Hallways, the pits "reset" themselves to the same as before you
started the quest.

Q: In the Halls of Babble, what should I do?
A: The Halls of Babble provide you with knowledge in all the languages of all
the races. You will also be given clues on how to set the switches, listen
carefully! The first thing you should do here is walk to the spot that has
your race's language on it. These are the spots for the languages: Human -
K,4 ; Orc - A,1 ; Dwarf - G,4 ; Gnome - J,1 ; Elf - F,1 ; Troll - K,2 ;
Halfling - H,6 ; Gremlin - M,3. After doing that, walk to O,4 and go through
the door to your east. After walking through this door, find the teleport
square for your race and go through the teleport. Here are the directions :
Orc - O,12, Human - B,15, Dwarf - M,6, Gnome - K,14, Elf - H,12, Troll - I,8,
Halfling - G,6, Gremlin - A,11. Once you find your teleport and walk through,
you will learn a new language. Then, you will need to go back to the
northwestern part of the map and talk to the Race member. In other words, if
you are a human and just learned Dwarf, you will have to go back to G,4, and
talk to the Dwarf wizard, then walk to M,6 and step through the Dwarven
teleport. You will then, for example, learn Troll; you will have to go to
I,8 to talk to the Troll Knight, then to K,2 to teleport. Repeat this until
you have learned all the languages; then go back to the northwest part and
talk to the member of your Race again. After doing that, go northeast to the
door and walk through. You will be in an area with eight switches that you
will have to set and a plaque in the northeastern corner. Here's the scoop on
setting the switches right : to set them, walk switch to switch, using the
_second_ letter of each word to spell out "Yserbius" - or Erebus, Asp,
Island, Guild, Myth, Abyss, Legend, and Wizard. After setting the switches,
walk to the northeast plaque and read it. You'll get "a taste" experience,
gold, and a little initiative. After doing this, walk back to the first
switch. NOW, use the _last_ letter of each word to spell out Aeowyn - or
Magma, Longbow, -off-, Harmony, -off-, Volcano, Twinion, Palace. After doing
that, read the northeastern plaque again and you will get experience, gold,
and a boost to your Strength! After you do this, a pit will appear to your
west. Jump into the pit to Concordia, one of the last stages before the
Dralkarians!

Q: What is the purpose of Concordia?
A: Concordia is where the two alignments, Chaos and Harmony, are joined
together against the Dralkarians. Once you have Unity, the combined power of
the two alignments, you will be able to hunt down the dralks, and
annihilate them one by one...

Q: What do I do from the start of Concordia?
A: You'll need to pass several stages before you reach Unity. Once you are
at the start of Concordia, you will have several paths to take. Take the one
to the east. Note that every time you take a step here, the walls block in
behind you. Take the east path and follow it, fighting several battles,
until you finally reach a door near the SE region. Walk through the door
(since you did the Hopeless Hallways quest, it will be open), and follow the
simple path until you reach a plaque, which informs you that you have taken
the first step toward Unity. Then take the door to your north and follow
north, until you reach F,9. Go through the northern door at that spot and go
2 steps north, 2 steps east, and 1 step north through the door. Then face
east and read the plaque, which informs you that you have taken the second
step toward Unity. Then (this is important) "bump" the plaque by facing it
and hitting forward. It will show a message in runes, "Continue,
Adventurer". Then, take the teleport. It will warp you to the back of the
stage. Take the eastern path again, avoiding the door this time, until you
reach F,11. Walk through the door to your north and go 2 steps north, 3
steps west, and take the door to your north. Then face west, and it will
show that you have completed the third step towards Unity, and that you will
need the Unity Ring to proceed further in the quest. The Ring can be found
in Hopeless Hallways, beyond a lamp. Teleport back to the Hopeless Hallways,
and from the point you arrive, face south and detect the stained-glass
window. It will reveal a door. Go through this secret door and follow to a
teleporter. Go through this teleporter and follow through the next area to a
plaque. Read it, then go through the exit door to your west. Then, walk
through the pits to G,13, and face west. Go through the door and follow the
path. After reading the second plaque, go through the exit door and walk to
E,14, and face south. Go through this door and follow along again. Then,
walk to H,1, and face east.  Walk through this door and read the plaque that
follows. Then, walk to L,15, face south and walk through the teleport that
follows to receive the Unity Ring.  Then go back to Concordia via a
teleporter in Hopeless Hallways. Now, take the NORTHERN path through and
follow it to F,8. Face north and use the Unity Ring to unlock this door. Go
through the door and then go 2 steps north. For your fourth and final step,
you will need to take the doors of either Harmony, or Chaos, whichever you
are. For Harmony, go 2 steps east and take the northern door, and for Chaos,
go 1 step east and take the door to your north. If you're a harmonic, be
sure to detect a secret door at P,13, facing south, or you will miss your
chance to finish the quest and have to start all over again. Also if you're
harmonic you will encounter a north-west fork after going through the secret
door. Go west and then use the Unity Ring on the next door. If you're
chaotic, simply walk along until you reach a door that is locked, then pick
the lock to unlock it and proceed to P,3 - face east and detect a secret
door there - then follow the path to a door that does not budge. Use the
Unity Ring on it. At the end of the quest, you will be granted 4 million
experience, gold and a boost to your stats, plus a portal to Pandemonium,
the last stage before the Dralkarians.
=============================================================================
[3.4] Pandemonium

Q: What is in the Pandemonium for me to do?
A: The Pandemonium is where you get the Starburst ring that allows you to
gain access to the Dralkarians. Also, it houses the five portals that take
you to the five dralks.

Q: How do I get the StarBurst?
A: Pandemonium has many invisible walls and boundaries that you can't see and
can't walk through. However, here are the directions that will ensure that
you get to the Starburst : from the beginning, go 2 steps south, 1 step west,
1 steps south, 3 steps west, 1 step north, 2 steps east, 1 step north, 1 step
east, 3 steps north, 1 step east, and then walk north until you reach a wall.
From the wall (P,16) go 5 steps west, 2 steps south, 2 steps west, 3 steps
south into the hardened lava, and then follow south through the lava to the
invisible teleporter. After teleporting, go 3 steps north, 3 steps west, 1
steps south, 1 step west, 1 step south, 1 step west, 1 step south, 1 step
west, 2 step south, 1 step east, 1 step south, and then walk 1 step south to
teleport. From the point that you are teleported to, go 1 step east, 2 steps
south, 2 steps west, 1 step south, 2 steps east, 2 steps south, 2 steps east,
1 step north, 1 step west, and go 1 step north to teleport again. In the next
area, simply follow the water along to a teleport at the end. From the spot
you are teleported to, go 2 steps south, 2 steps east, 1 step north, 1 step
east, 1 step south, and walk west until you hit a wall. From there, go 1 step
south, 6 step east, and go 1 step east to teleport. From that point, simply
follow the lava to get the magical Starburst.

Q: Once I have the Starburst, what do I do?
A: Now your goal will be to find the five portals that lead you to the five
Dralkarians. To do this, teleport out and take the top dungeon entrance. From

there, make your way back to Pandemonium (There is a shortcut it Hopeless
Hallways to it, the second door beyond the door with the star-shaped
keyhole). Once you are there (at Pandemonium) go 4 steps south, 3 steps west,
1 step north, 2 steps west, and 2 steps south. Here you will reach a section
with several large boulders blocking your way. If one blocks your way, use
the Starburst; if it is the right stone, it will shatter, if it is not the
right one, simply continue, turning to all sides until you find one that
you can shatter, then jump into it. You will be taken to the northwestern
part of Pandemonium, the final phase... Walk along the path and you will be
presented with five portals that take you to the five Dralkarians. Guard your
Starburst well, as you will need to repeat the process 4 more times, and it
will get you to the portals!
=============================================================================
[4.1] The Dralkarian Quest

Q: Tell me a bit more about my quest here.
A: Your goal, your ultimate goal that you have been waiting so long for is
here. You will make your choice of the five portals in Pandemonium to the 5
Dralkarian Guardians of the Portal. These dralks are smarter and tougher than
any other single monster you have fought so far.. But not quite as strong as
some of the monsters you will encounter later. Luckily, the dralks will fight
you one at a time, alone. In other words, you will find one and fight him,
one on one, to the death. Each of the dralks requires an item to be found
before he considers you worthy of challenging him. Each of them also has a
magical Dralkarian Ring, which you promised to return to the Queen. Not
surprisingly, you will have to get the Dralkarian Rings over their owners'
dead bodies. Their rings allow them to control the Portal of Time, not making
any of them completely immortal, but rather making all of them strong enough
to defend the Portal against any invaders... almost (hint, hint, hint).
Aeowyn wants these rings so that she and her Heroes could control the world
in Immortality. The reward for this quest is given out to you in fragments.
For every dralk you will get 3 million exp. (one for reaching him, one for
defeating him, and one for giving his ring to Aeowyn), which for all 5 dralks
adds up to 15 million experience points! :)

Q: Which Dralk should I go after first?
A: The five Portals lead to the five guardians of the Portal of Time. The
Dralkarians are all strong in combat, but they should be approached in this
order: Astelligius, as he is not only easy to get to but he also holds an
item, the Eye of Circinus, that will aid you when you set out for Corpeus.
Then, go after Malos. He is slightly harder to find, but still, the pathway
is easy. When you get his ring, go after Corpeus, who is moderately easy to
get to, but still some of his puzzles are brain-numbing. Then go after the
Dralkarian Pluthros, who is easy to find and defeat. Finally, try and find
Juvalad - who will definitely give you a headache.
=============================================================================
[4.1.2] Astelligius

Q: First of all, I need to defeat Astelligius. How do I get through to him?
A: Take the teleport to Astelligius from the Pandemonium.
Once you are in the southern section of the Celestial Boundary, make your way
through the astral material (which indeed looks like a giant pit) to the east
section. Located at the east is a battle. Fight the battle to get the Eye of
Circinus. This magical object will act as a compass to show you the way
through the gates here. Once you have the Eye, notice four teleports to your
southwest. Take the southeastern teleporter to access a maze of doors that
cannot be mapped.  On each of these doors is one of the four cardinal
directions; west, east, north, and south. Take the first letters of these and
spell out SEEN (south, east, east, north). Notice that in other words, it is
what the wraith told you, "see in the past", or the past tense of "see". Once
you have completed the cycle, you will step into a fountain and get poisoned.
Cure and head back to the teleports at the south. Take the same teleport
again, and this time use the first letters of the directions to spell out
WENS (west, east, north, south). Notice that IF you played the Shadow of
Yserbius and remember the Wind Knights' quest, this is the opposite of the
direction you defeat the Winds, SNEW, or as the wraith said, "The Wind
Knights have no direction in this domain. The four Winds are reversed!".
After you complete this step, you will run into a battle. Defeat the Erebi
and turn to face the stained glass window. You will receive the Nimbus of the
Fates. Keep it, as you will need it to defeat Astelligius. Don't throw away
your old helmet if it is not as good however, as the Nimbus will disappear
once you are through with it. Once you have the Nimbus, walk out of the
square you are in and back to the teleports. Use the first letters to spell
out SEEN again, and take the teleport to Astelligius. Find your way through
this astral material to the center of Spheres Asunder, where he is laired. He
will see your Nimbus and beckon you forward. Come to him, and you will fight
him. If and after you win, be sure to keep his ring. Important note: don't
use the Pickpocket skill when fighting him or you won't get the ring. Once
you have the ring, turn to face the stained-glass window behind you to
receive 1 million experience points. After that, turn around and walk through
the teleport to the Queen.  She will take the ring and reward you with
another 1 million experience points, which will aid you in reaching the next
level.
=============================================================================
[4.1.2] Malos

Q: How do I get to and defeat Malos?
A: Malos is harder to find and is a little tougher that Astelligius. You
must first walk back to Pandemonium and to the five Portals. Take the one to
Malos. He resides in Trials and Tribulations.  To defeat him, you need the
Ice Flame, which will allow you to challenge him.  To get the Ice Flame, you
will have to walk through a series of different locations. The bad thing here
is that the paths vary with guild and race.  There are three paths to the Ice
Flame, and only one will work for you. There are also three paths to Malos,
and not surprisingly, only one is right for you. Plus you have to avoid all
of the tricks and traps he set for you and other adventurers. From the
entrance, get out of the small 4 square room by going through the wall 2
steps north of where you begin. From there, make your way through the waters,
avoiding any traps. To tell whether a "death trap" is in front of you, check
the text box. If it says anything about a party "being destroyed" or anything
of the kind, then the same thing will happen to you if you step into the
square in front of you. Make your way through the waters until you hit an
underwater trapdoor (there are two, one in the northwest corner and one in
the northeast corner of the room), which will take you to Tribulations. Once
there, make your way to the trapdoor at the north, which will take you to the
"main area" of Malos' home. There are different pathways out of this area.
Since you first need to get the Ice Flame, you will need to know the
directions. From there, make your way through the water to G,4, and face
west. The rocks will move aside and you can go through this area. From here,
walk through the waters and get to the trapdoor beyond. You will get to an
area far south in Tribulations. Walk through the water and lava, being sure
not to get killed by the nasty traps Malos has waiting for you. Make your way
to A,14, face north, and walk through the wall. This is the first location
for the Ice Flame. If you get it, all you will need to do is find the exit to
your Fate. If you don't get it, walk through the teleport and follow the
paths again to the "main area". Now, take one of the other trapdoors here,
which should take you back to Tribulations, west of the area that you
originally went through to get to the "main area". There will be a portal
through the first door to your east. Take it only if you have the Ice Flame.
If you _can't_ go through it, then walk back out of the square. Make your way
north to the trapdoor, which takes you back to the northern area of Trials.
If you have the Ice Flame and are trying to find your way out, walk to the
east, where there will be another portal to Spheres Asunder. If you don't
have the Ice Flame or the portal doesn't take you to Spheres Asunder, walk 1
step south to be teleported to another area in the northern region of
Tribulations. Once you get there, walk to the east, not taking any turns
until you reach O,11. Face south and walk through the wall. If you didn't
have the Ice Flame before and just got it, walk through the teleport and try
the other portals "to your fate". If you had the Ice Flame, simply walk
through the teleport. If you didn't have the Ice Flame before and didn't get
it now, walk through the teleport. From here, walk back to the "main area".
Take the easternmost trapdoor and walk west, south, and east, except in the
south-north fork where you originally went south to get to the Ice Flame,
take the north path. Follow the lava to a trapdoor at the end. Go through
here to get to the final area, where there is a third portal to Spheres
Asunder at D,12 and another area to get the Ice Flame at D,14.  Once you find
the portal to Spheres Asunder, walk through the "elemental plane" until you
reach an object that looks like a small throne. Step into it, and you will be
taken to Malos. Repeat the procedure as you did with Astelligius. Your Ice
Flame will be taken from you, and you will get another Dralkarian Ring. You
will receive another 3 million experience points after defeating Malos to
help you advance to the next levels.
=============================================================================
[4.1.3] Corpeus

Q: How do I find and defeat Corpeus?
A: From the Pandemonium, take the teleporter to Corpeus. You will be at the
northern section of the Celestial Boundary. From here is the path to the
Dralk Corpeus. Along the pathway, a wizard will encounter you several times
to tell you about your path here and give you clues as how to get to Corpeus
himself. You will need first the Reality's Rampart, which is the best shield
in the game. However, even though any guild can use it, it's wise to forget
about equpping it until you have defeated all five Dralkarians. Then, you can
go back and get it again. From the beginning of the level, head south along
the path. When you reach the fork to the west, take it. There is also a stat-
boosting fountain here which you should visit as it will increase your
Agility. You will also encounter a wizard along the way who will tell you
that he was once an agent of Corpeus but turned against him and is now
helping adventurers to find him and defeat him once and for all. From the
west-south fork, walk west until you reach a north-south fork. Go south here
and you will find that the pathway bends at the end. Walk to the end of the
hallway, bust a U-turn and face west. Walk through the teleport here. After
doing so, you will be teleported to the northern section. Follow this path up
to the pool of water. Walk to the center door, the one labeled "torch room".
Here, you will need to set certain switches to progress further. It doesn't
matter which ORDER you set the words in, as long as you set them right. The
first thing you must do is set the switches to "Time Follows Death From
Life".  After doing so, walk through the teleport (note that one of the
switches was unused; leave it in the "off" position). You will be teleported
to the beginning of the level again. Follow the same path you did last time,
except this time - when you turn the corner, _don't_ take the first
teleporter on the wall. Instead, from the square in which the teleporter is,
go 1 step north and face east. A new portal should appear here. Go through it
and follow the given path around to L,16. From the lava, there will be an
east-west fork. Take the eastern path and follow it to P,13. Face south and
walk through the door. Fight the battle there, face west and walk through the
door. You will fight a battle.  Defeat all the enemies and you will receive
the Reality's Rampart. Be sure to keep it as you will need it to fight
Corpeus. From there, walk 1 step north, 1 step west, 1 step south, and
another step west into the Torch Room. As the wizard tells you, you will need
to set the switches again, except this time, set them to "Water Leads to
Magic Sands". (Notice one switch won't be used, so set it into the "off"
position). Walk through the teleport and follow the path again, except this
time, don't take the 2nd teleporter around the bend. Walk 1 step north of the
square with the teleporter and face west. Go through the portal that appears
and you will be teleported to a long, twisting hallway that you cannot map.
Here are the directions. Be _VERY_ sure to follow them precisely, no matter
what happens! Be sure that the NumLock is off, and using your numeric
keypad, "type": 7,7,8,8,7,7,8,4,9,7,7,8,8,9,8,7,7,8,7,8,7,8,8,9,8,7,8,8,7,7,
8,7,8,7,8. After doing this, go 1 step west and 2 steps south to get your
next instructions. After doing that, go 1 step north and 1 step east. Go
through the teleport to your north to the Torch Room. Set the switches to
"Magic Lava Leads to Death" (Once again, a switch won't be used; leave it in
the "off" position). Go through the teleport once again, and follow the path,
but instead of taking the third teleporter around the turn, go 1 step north
of the square with the 3rd teleporter and face east. Go through this new
portal to be teleported to the last hallway to Corpeus. Defeat all the
monsters and enter the portal at the end to get to the Dralkarian Corpeus.
Repeat the movement as you did for the other dralks and you will get another
Dralkarian Ring and 1 million experience points. Return the ring to the Queen
to get another million.
===============================================================================
[4.1.4] Pluthros

Q: How do I find and defeat Pluthros?
A: Pluthros is very easy to find and defeat. Either there was some sort of
bug in the program files or this was supposed to be so, but there seems to be
a "shortcut" to get to Pluthros. From the Pandemonium, take the portal
labeled "Pluthros". The directions will tell you that you need to find and
set 3 switches to unlock the cell to a prisoner that will give you what you
need to defeat the Dralkarian Pluthros - the Hope's Fury. However, you don't
seem to need to set any switches! You can simply find the portal to Juvalad,
which is located in Trials.  Then, simply make your way to the small
"throne" in the resemblance to the plane Ashakkar. Pluthros will get angry
and fling you to a long hall in Tribulations where Celestia is imprisoned.
Since you did not make the effort to rescue her, however, she will still be
locked in and you will reach around and yank the Hope's Fury from her neck.
Then, take the portal back to Pluthros' throne room in Spheres Asunder and
find the "throne" again. Since you now are worthy of fighting him, he says,
you can destroy him to get another Dralkarian Ring. Follow the procedures to
give his ring to the Queen. Once you've done so, go back to the Guild Hall to
earn your levels.
==============================================================================
[4.1.5] Juvalad

Q: How do I find and defeat Juvalad?
A: Juvalad is definitely the toughest of all the dralks to defeat. Getting
to him requires an elaborated sequence of visiting around the stages,
finding fountains, and the such. Since I lack lots of information on this
one, I will not be able to explain in detail, in fact it is very hard to
understand how this system of fountains even works.
                         ��??????????????
                         3 Directions: 3
                         ��?????????????��
1. First, visit all the fountains in the small southwestern section of
Trials, where you arrive.
2. Go through the teleporter in Trials that will take you to the western part
of Tribulations. When there, take the teleport at L,1.
3. You will be teleported to the eastern section of Tribulations. Take the
teleport on the east wall.
4. Once here, go west and north. You should encounter a wizard around this
place but if you don't, just keep on going further.
5. In the next area, walk until you are in a spot with two forks, north and
south. Take the south one and then walk through the door and teleport to be
teleported to the beginning of the stage. Once there, take the teleport to
Tribulations. Walk along, except take the other teleporter, the one to the
east, this time. You will be teleported to an area with a north-south fork;
if you didn't encounter the wizard earlier you'll meet her here. Go through
the teleporter to the south. In the next area, follow along to a teleporter.
Walk through the teleporter and you will be teleported back to Trials. Once
here, make your way to E,8. If you have visited the Wizard, the fountain will
open up a new fountain in Tribulations, but for now, simply go through the
northern teleport in this area.
6. Once you're back in Tribulations, walk along the path and you will
encounter Thorzil. He will mark you, then get away. After doing this, take
the southern teleporter of the two in the north-south fork. You will be back
at the beginning of the stage. Take the teleporter back to Tribulations.
7. Once you're there, walk to L,1, and go through the teleport. You will be
teleporter to the eastern area of Tribulations. From that point, go 3 steps
west, 1 step north, and you will find Thorzil - but he won't escape this
time... You'll tie him to the fountain, then begin your search for the portal.
All you have to go now is go through all the teleporters in the stage; one
will take you to a secret area on the northern row of Tribulations. Fight the
battle in the middle of the secret poison cache and keep the Flask of
Shadowfall, which will let you defeat Juvalad. Then, enter the teleport to
meet your Fate! Repeat the process with Juvalad as you did with the other
dralks to get his ring. Return his ring to the Queen to find out...
===========================================================================
[4.2] Aeowyn's Treachery

Q: What happened?
A: When you returned the last ring to the Queen you find out the truth:
she's been using you to kill the dralkarians for her and give her the
rings. She calls you a fool and takes everything you have gained in the
Dralkarian Quest; namely, your stats. She hovers above you, mad with power,
throwing you to the ground with powerful magic. You notice an opening
behind you and escape with your life... barely.

Q: I knew this was coming. What now?
A: Now, you have to follow the mad Queen into The Gateway, to defeat her
and prevent her from becoming immortal and conquering the entire Universe
and all the different dimensions. For now, go and level up in the Guild
Hall. After, you will need to take the portal from the Dungeon Entrance to
Dissemination, where you will blast your way through to the Gateway, where
the queen awaits.
===========================================================================
[4.2.1] Hints and Tips

Q: I'm having trouble fighting and defeating the dralks, what should I do?
A: The best fighting tactic to defeat them is by using the Channel skill,
which decreases their "agility" against magic. Then cast Backfire, then try
and control. If you are fighting Juvalad and are Chaotic, then when you
attempt to fight him you won't be able to use spells - only don't tell him
that! He will spend most of his time trying to attack you with spells that
won't work, so just beat the crud out of him with your weapons. This also
applies to Pluthros if you are Harmonic; otherwise, everything will stay the
same. You should have at least 1 heal amphora and 1 mana amphora (or the Heal
spell maxed) with you when fighting the dralks. Curse is also a good spell as
it drops their defenses. Most of the time, your most lethal weapon will be
simply attacking them. If you can get them controlled or at least petrified,
then it will be rather easy. The Shield spell will also be useful, and if you
are fighting a dralk who uses magic, Resist won't hurt either. It's also a
good idea to use the special weapons against the dralks; the Hope's Fury is
the most powerful talisman in the game; it boosts your stats greatly. Sadly,
however, you can only get it once - and that's to fight Pluthros. Juvalad is
also weak to the poison from the Flask of Shadowfall, even though it still
only does 200 damage. The Reality's Rampart is a power shield to use against
Corpeus, and most of the time, the Ice Flame and Nimbus of the Fates will
boost your stats high enough so that you can defeat the Dralks you are
fighting.
=============================================================================
[5.1] Dissemination
 Note : Before you start Dissemination and after you defeat the Dralks, it is
very highly suggested that you back up your AUTOMAPS.DAT and MYCHARS.DAT
files as in this stage, the game may begin to get weird. Walls may dissapear
and there may be trash on the screen, unfortunately. This bug will not cause
you any real trouble, but if it totally messes up, it's good to have a
backup copy of the character data files. This bug seems to vanish after you
defeat Aeowyn and do Finals.. however, it's better to be safe than sorry.

Q: How do I get into Dissemination?
A: The portal to this stage is in the Dungeon Entrance. Simply go to the
northeastern corner of the DE and face north; a portal will open, allowing
you to access Dissemination and later, The Gateway.

Q: What is the goal here?
A: This stage's purpose, mainly, is to provide adventurers with a portal to
The Gateway. Many walls and statues here shimmer and shake, even though they
appear solid. You'll have to dispel them with the Rod of Dissemination to
proceed. To get the Rod of Dissemination, you must fight the Dissimenator,
which you will get to later.

Q: Once I'm at the start of Dissemination, what do I do?
A: You must repeatedly visit the two Kaalroth brothers, Aoei and Ieoa. First,
go to Aoei, who is located at F,15. Then go to C,4, face north and go through
the door, then face west and go through the other door. Make your way to E,2,
face north, and go through the door to Ieoa. He will teach you a part of a
spell; now, go back to Aoei and he will teach you the rest of it. Now, go to
F,13 and face south. Walk through the new door here, and from that point go 1
step south and 1 step west to fight the Dissimenator. You will receive the
Rod of Dissemination. Use it to dispel all the "shimmerring" walls and
statues and blast your way to L,4, where a wizard stands. Talk to him, then
face north and teleport. Go 2 steps north, 1 step east, face south and dispel
the wall. Then go through the dispelled wall, and then the teleport. Go 1
step south, 1 step west, and 1 step north, then go through the teleporter. In
the next area, face east and dispel the wall, go through, face north and
dispel the wall, go through, and take the teleport beyond to the ultimate
challenge, The Gateway!
=============================================================================
[5.2] The Gateway

Q: What is the purpose of this Gateway?
A: The Gateway is the huge portal that leads to different dimensions, which
used to be guarded by the five Dralkarians. Now, the mad queen is trying to
take over the Gateway and become immortal. You will be the only one with
enough power to stop her; you defeated all five Dralkarians and made your
way here...

Q: How do I get through?
A: First of all, you must get the Statue of Storm Giant. It is located 1 step
north and 1 step west of the entrance. Then take the stained-glass window
portal; you will be teleported to the ancient Gods' treasure room. Here you
will choose a legendary weapon to fight Aeowyn with; the Sword of Ares, Bow
of Eos, Neptune's Trident and Gaea's Flail. Pick your weapon, then head
through the teleport. After doing this, go out of the 2-square "cubicle" you
are teleported to, and head south. When you encounter the lava pit, use your
new weapon to harden the lava. Then, head south and into an unmappable area,
which is rather easy. Once you get out of the area via a stained-glass
window, and you will be teleported to the very heart of the gateway. There
are a lot of tough battles here, so cheat save often (see Tricks and Cheats).
Follow this path, fighting all the battles, until you reach a stained-glass
window on the other end. Take it into the last, ultimate pathway where you
will finally meet your Fate. Simply follow this unmappable area to the
Queen. Defeat her to win the ultimate prize...

Q: What do I get after defeating the Queen?
A: Step one step forward to the actual Gateway, the one that allows you to
travel into different dimensions and different worlds. This was the goal that
Aeowyn longed for; to become immortal using the Gateway and the five
Dralkarian rings. You will get 8 million experience points, 3 points to each
of your stats, a new spell, and a ticket into Choronozar's Demesne, which is
your next destination. Congrats! You've defeated the evil queen and restored
peace to Twinion and the Gateway once more. But there is another errand to
do... you must go into Choronozar's lair and destroy him.

Q: I'm having trouble defeating the Queen. What should I do?
A: The reborn Dralkarians are your greatest threat here. They can hit very
hard, even harder if they attack you at the same time. On the first round,
cast Control and cross your fingers; luckily, (at least) one of the dralks
will get controlled and you will not have to face so much damage. On the
second round, Channel the dralks to greatly decrease their resistance against
the Control spell; then cast control over and over until you get all 5
dralks, which you should usually get with 2 to 3 rounds of Control; if you
have to heal, stop and do so. When you get the 5 of them controlled, cast
Resist to defend yourself against Aeowyn's magic, the head for the Queen's
Guards, which are even tougher to control than that dralks. Simply cast Curse
on them and hack away with your weapon; 2 or 3 rounds should take care of
them, if the controlled dralks hadn't killed them already. The Draco Lich is
hardly any threat at all to you as it doesn't hit hard and has less than
average magic. If it lasts, attack it, if it has already been killed by the
dralks, go after Aeowyn. She can take quite a lot of punishment before going
down; try casting Curse and then attacking. Backfire won't hurt as she has
maximum healing ability. The dralks will kill a few of their own; finish them
off with Curse and hack through them.
=============================================================================
[6.1] Choronozar's Demesne and the Funhouse

Q; What is the meaning here?
A: The Choronozar's Demesne stage has no known end, but it's a little added
"bonus" after beating the game. The monsters here are the toughest you'll
encounter, most of them Imperial (Imperial Kaalroths, Imperial Fiends, etc.)
and very, very tough. The point here, basically, is to receive the Jester's
Cap, which is without doubt the best helmet in the game. It increases every
one of your stats, and adds a 300+ boost to your Dexterity when worn. You can
also get the Easter Egg, which might've been a gag or joke from the creators
(or maybe not) as it has no discovered use.

Q: How do I get into Choronozar's Demesne?
A: The teleport is at P,1 in the Dragon's Ire. Once you enter this new
dimension, you will be challenged by Shaddax the Keeper. Defeat him, as he is
very easy to beat, and you will be in Choronozar's Demesne.

Q: What do I do once here?
A: Once in the Choronozar's Demesne, head to D,15. There you will discover a
long forgotten password. Once you have it, go to A,10 and face west. The
Gaoler, the prison guard, will let you in. Once you are through, he'll say
something about being tricked and challenge you. Defeat him, then go 1 step
north and 2 steps west to discover Lady Naomi arguing with Choronozar's
servants. Once you've done this, you will need to get Naomi's Key. First,
however, you will need the "juicy dragon steaks" to get across the pool of
piranhas. Go to L,2 and face north. Use your weapon to bash the lock off the
door. Go 1 step north and 1 step east to obtain two steaks. Then, go to H,5.
Face south and use a dragon steak. Then go 1 step west, face south, and use
the other steak. The pirahnas will continue to feed, not noticing you. Follow
to the end of the passageway and you will see an island in the middle of the
water. Walk to this island and you will find Naomi. She will tell you that if
you expect her to trust you, you have to recover her lost Spirit Bottle. She
will also give you Naomi's Key. Now, go to K,4 and fight Chiss the
Snakewoman. After doing this you will get the Funhouse key. Go to J,8 and
face west. Jump into the pit and you will be taken to the Funhouse.

Q: What do I do in the Funhouse?
A: Your point here is to get Lady Naomi's Spirit Bottle. The battles for the
Spirit Bottle are the toughest in the entire game; the Pit Serpents are vile
creatures, and they have extremely tough poison. Fro the entrance of the
Funhouse you will be at the Hall of Mirrors. The right "mirror" to teleport
to is at F,12, facing south. From where you are teleported to, go 2 steps
south and then face east. You will throw the rusty switch. Go back up to the
teleporter to be teleported back to the Hall of Mirrors. Now, walk to the
throne looking object at E,16, and step on it, which will give you the Brass
Ring. Keep it, then walk back to the mirror. Teleport with it and go along
the path to the door at the end. Use Naomi's Key to open it, and go through
to be teleported to the "Halfway House". Walk along to "chat" with Major
Domo and walk to the stained-glass windows at the end. Go through either of
them and you will be teleported to an unmappable maze. Here, go through the
door in front of you, turn left, walk through the door, turn right, go 1 step
forward, turn left, go through the door, turn completely around and take the
door behind you, turn left, go 1 step forward, turn right, walk through the
door, go 1 step forward, turn right, walk through the door and take the
stained-glass window portal behind you. From that point, go 2 steps north and
1 step west to fight the Ogress. Defeat her and take the gate. Fight the
battle here and proceed east to D,10, where there is a pit. Jump into the
pit, and you will fight Choronozar. Defeat him and go 1 step south and 1 step
west onto the throne. Use the Brass Ring and go 1 step west. Then, go 1 step
south and take 1 platinum bar. Go 1 step west and take a Priceless Bar. Go 2
steps north and take a Silver Bar. Go 1 step east and take a Gold bar. DON'T
sell any of the bars you've got right now however. Now, go 2 steps west to
start the Tower of Annoy.

Q: How do I raise the Tower of Annoy?
A: This is a computer simulation of a simple riddle game that used to be
played. Here's how it goes : you have three wooden disks to control, a large
one, medium one, and small one. Each one can be moved via the Funhouse key.
However there are rules: a disk can only land on an empty space or a larger
disk; in other words, a small disk can land on an empty peg or a large or
medium disk, a medium disk can land on an empty peg or on a large disk, a
large disk can only land on an empty space. You must build the Tower of
Annoy by one of the three doors in the east; the right door to build it by is
the northernmost one. The only fly in the ointment is the sequence of disks
to use. Not to worry, however - here is the sequence of the moves : Go to the
northernmost spot and face south. Use the funhouse key to make the small disk
jump on top of the medium disk, go 1 step south, face south and use the
Funhouse key again to make the small disk jump on the large disk, then stay
on that spot and face north; use the Funhouse key to make the medium disk
jump onto the empty spot at the top. The go 1 step south, face north and use
the Funhouse key to make the small disk jump on the empty spot in the middle,
then go 1 step north, face north, and use the Funhouse key to make the small
disk jump on the middle disk. Then go 1 step south, face north, and use the
Funhouse key to make the large disk jump on the empty space in the middle. Go
1 step north, face south, and use the Funhouse Key to make the small disk
jump on the large disk in the middle. Go 1 step south and use the Funhouse
key to make the small disk jump on the empty space in the southern spot. Go 1
step north, face south, and use the Funhouse key to make the medium disk jump
on the large disk. Now, go 2 steps south, face north, and use the Funhouse
key to make the small disk jump on the middle disk in the middle. Now, go 1
step north, face north, and use the Funhouse key to make the small disk jump
on the empty space at the northern spot. Now, stay where you are, face south,
and use the Funhouse key to make the middle disk jump onto the empty space in
the southernmost spot. Now, go 1 step north, face south, and use the Funhouse
key to make the small disk jump onto the large disk in the middle spot. Now,
go 1 step south, face south, and use the Funhouse key to make the small disk
jump on the middle disk in the southernmost spot. Now, stay where you are,
face north, and use the Funhouse Key to make the large disk jump on the empty
space on the northernmost spot. Now, go 1 step south, face north, and use the
Funhouse Key to make the small disk jump onto the spot in the middle. Now, go
1 step north, face north, and use the Funhouse Key to make the small disk
jump on the large disk on the northernmost spot. Now, go 1 step south, face
north, and use the Funhouse Key to make the middle disk jump onto the empty
spot in the middle. Now, go 2 steps north, face south, and use the Funhouse
key to make the small disk jump onto the middle disk in the middle spot. Now,
go 1 step south, face south, and use the Funhouse key to make the small disk
jump on the empty space in the southernmost spot. Now, stay where you are,
face north, and use the Funhouse Key to make the medium disk jump on the
large disk in the northernmost spot. Go 1 step south, face north, and use the
Funhouse key to make the small disk jump on the empty spot in the middle.
Now, go 1 step north, face north, and use the Funhouse key to finish the
puzzle. Go 1 step north and through the gateway to your west. You will be
teleported.

Q: How do I finish The Funhouse?
A: From the spot you are teleported to, follow south and you will see
Choronozar. He will talk to you, then disappear. Follow south where you will
spot another gateway. Go through it to the Riddle Room. After getting the
riddle, take the door labeled "Ennui". Follow along this path to The Vortex.
Here is where you will find the Spirit Bottle. Fight 8 consecutive battles
in The Vortex to receive the Spirit Bottle. It looks like a cure potion, so
don't confuse the two!

Q: I'm having trouble with the Pit Serpents, they keep killing me!
A: The Pit Serpents are definately the toughest creatures you will face here.
Their power lies actually not in their strengh or magic but their poison. Try
casting Control on the first round and cross your fingers. IF you get
poisoned, cure _immediately_! Their poison shoves off 3000 hit points a round
and as an added bonus - if you are poisoned, they each will do thrice as much
damage to you as before, so 3 of them can hit for 12,000 points. Be sure to
Cure or apply the Medic spell. Cheat save after every battle, and with a lot
of luck, you'll get through.

Q: How do I return the Spirit Bottle to Naomi?
A: To return her Spirit Bottle, repeat the process with giving the Dragon
Steaks to the pirahnas. Once you are across the island to Naomi, use the
spirit bottle. Naomi will thank you and inform you that Choronozar has a
secret passageway in the back of his labs to the throne. Then she will
disappear in a mist, never to be seen again...

Q: How do I get into Choronozar's labs?
A: You will need to figure out to the correct combinations in the lever maze,
east of the pit to the Funhouse. First, go to K,8 and flip the lever, then go
to J,12 and flip the lever there, then go to G,10 and flip the lever, finally,
go to I,10 and flip the lever to finish the sequence. You'll hear a rumbling
sound the the east. This opens a door at I,16. Go through it and head to O,14.
Face north and use a Silver Bar. Go 1 step east, face north, and use a Gold
Bar. From that spot, turn east and use a Platinum Bar. Go 1 step south, face
east, and use a Priceless Bar. The tortured spirits that Choronozar had
imprisoned will be released, giving you their strengh in the battle with
Choronozar. Now, go to P,13 and face west. Take the door here and follow the
passageway to behind the throne, and you will fight the real Choronozar.
Defeat the madman and you will get the Jester's Cap! This is the best helmet
in the game, and it can be used by all guilds.

Q: How do I get the Easter Egg?
A: I have no idea.. haven't figured it out yet, unfortunately.
=============================================================================
[6.1.1] The Endgame
Q: Is there anything to do after I've completed the game, got the Jester's
Cap and the Easter Egg, and defeated Choronozar?
A: Unfortunately, no. The designers, for some reason, didn't finish that part
of the game - the Easter Egg might have been some sort of token somewhere or
whatever. But for now, you've completed every nook and cranny of the game,
and hopefully - there will be a sequel. Congratulations, brave Hero! You've
defeated the evil Queen Aeowyn and restored peace to Twinion once more. And
even though you have not stepped into immortality yet, it will be soon to
come... maybe ;)

                    ______ _            ___
                   (_) |  | |          / (_)           |
                       |  | |     _    \__   _  _    __|
                     _ |  |/ \   |/    /    / |/ |  /  |
                    (_/   |   |_/|__/  \___/  |  |_/\_/|_/


=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[7.1] Keys and Lockpicks
Q: Where can I find the Cross Key?
A: The Cross Key can be found in the Twinion Falls at M,3. Fight the battle
there to receive the key.

Q: Where can I find the Queen's Key?
A: The Queen's Key can be found in the Queen's Palace; take any of the 6
paths to the Throne Room and talk to her on the throne, the Queen will give
you the key.

Q: Where can I find the Maze Key?
A: The Maze Key can be found in the Vineyard in Night Elf Ingress. You can get
there from the Gallery. You will need to detect the opening to this key -
detect the west wall at I,11. Then go through and enter the westernmost door,
where you will find the Maze Key.

Q: Where can I find the Tnerpes Key?
A: The Tnerpes key can be found in aMAZEing. Make your way to E,7, fight the
battle, and the key will be yours.

Q: Where can I find the Key of C?
A: The Key of C can be found in Clueless, in the Night Elf Ingress. Detect
the northern wall at D,4, and make your way to I,5 A bard will give you the
key.

Q: Where can I find the Emerald Lockpick?
A: The Emerald Lockpick can be found in the Dark Alley. From where you arrive,
follow the long hallway until you reach a fork in the road. Face toward the
wall in front of you, go 1 step west, 1 step north, and go through the door
in front of you.

Q: Where can I find the Diamond Lockpick?
A: The Diamond Lockpick can be found in the thief town Tipekans. Detect the
wall at A,12, then the northern wall at C,14, then make your way through to
D,16, where a cleric will trade the Diamond Lockpick for your Emerald
Lockpick. Note : you MUST have the Emerald Lockpick to trade.

Q: Where can I find the Sapphire Lockpick?
A: The Sapphire lockpick can be found in the town of Tipekans. Detect the
wall at H,15, then make your way to F,14, where you will use the Diamond
Lockpick to open the door. The adventurer at the end will give you the
Sapphire Lockpick for your Diamond Lockpick. Note : you MUST have the Diamond
Lockpick to make the trade.

Q: Where can I find the Ruby Lockpick?
A: The Ruby Lockpick can be found in the Snake Pit, accessible from the
Graveyard. Fight the Giant Asp, then step forward to receive it. Note: You
MUST have the Snake Charm to avoid getting instantly killed by the Giant Asp.

Q: Where can I find the Fellowship Key?
A: The Fellowship key can be found across Lake Despair. You will only be able
to get there if you access it from the Carriage House. Make SURE you have the
Life Jacket equipped! The Life Jacket will let you step on 1 platform without
being killed. Go 1 north from the teleport, go 1 step east, 1 step south, and
3 steps east to the platform at O,5. Heal fully, go 3 steps east, and 2 steps
south to the platform at M,8. Go through the door and head north through the
hallway, where you will receive some booty and the Fellowship Key.

Q: Where can I find the Front Door Key?
A: The key can be located in Cliffhanger, accessible from the Wine Cellar in
Twinion Keep or the Dark Alley. There, the key is located at L,16.

Q: Where can I find the Skeleton Key?
A: The key is in a different location for each guild. The locations are as
follows : Barbarian - Gallery, Face north at L,4. Knight - Vineyard. Face
south at K,14. Ranger - Stables, face west at G,3. Thief - Dark Alley, follow
pathway until 1st door, go through door, go 1 step forward, turn east.
Cleric - The Statuary. Go to B,8, face east. Wizard - Night Elf Ingress. Go
to E,10 turn west.

Q: Where can I find the Funhouse Key?
A: The Funhouse Key can be found in Choronozar's Demesne. Fight Chiss, the
Snake Woman at J,3. You will receive the key after the battle.

Q: Where can I find Naomi's Key?
A: Naomi's Key can be found. In Choronozar' Demesne. First you must get the
Juicy Dragon Steaks which can be located at N,3. From there, go to H,5. Face
south and use one Dragon Steak. Go 1 step west, face south, and use the other
Dragon Steak. From there, west along the passageway to the end of the bridge.
From there, go 1 step east, 1 step south, 1 step east, and 1 step south. Talk
to Naomi and get her Key.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
[7.2] Best Equipment
Well, here's what all those weapons and armor come down to. This is the best
equipment for your guild, and the overall best equipment, if you "force". My
characters had to be used as gunea pigs for this, so be grateful! :P

                    Best Equipment for your Guild

This is the best equipment your current guild has. Note that Thieves don't
have a special "weapon" skill (e.g. Fencing), so for the weapon you should go
for what you want to have for your weapon. Note that if you have Fencing,
Archery, Staff, and Clubs/Axes at the same level, 12, for example, all the
weapons of the Gods (Sword of Ares, Bow of Eos, Gaea's Flail, and Neptune's
Trident) will be exactly the same, but the Bow of Eos and Neptune's Trident
will have an advantage as they can hit the enemies both in the front row and
the back row in battle, while the Sword and Flail can hit only the enemies in
the front row. Also note that even though Clerics have the Martial Arts skill
there is no weapon designed for it, so you will have to go with choosing any
one of the four. The weapons listed here are originally the ones more fit for
you Guild Skill, but if you have all the weapon skills, you may pick any 1 of
the 4 weapons. Note that the Jester's Cap is the best Helmet, period, because
it not only boosts your defense and agility, but also your Strength and
Dexterity by tons, and is useable by ALL guilds without forcing.
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
                      Best Equipment Without Forcing

Barbarian - Gaea's Flail (Weapon) Jester's Cap (Helmet) Gloves of Protection
(Shield) Shadow Cloak (Armor)

Knight - Sword of Ares (Weapon) Jester's Cap (Helmet) Gloves of Protection
(Shield) Shadow Cloak (Armor)

Ranger - Bow of Eos (Weapon) Jester's Cap (Helmet) Shadow Cloak (Armor)
Reality's Rampart (Shield)

Thief - Sword of Ares/Bow of Eos/Gaea's Flail/Neptune's Trident (Weapon)
Jester's Cap (Helmet) Reality's Rampart (Shield) Shadow Cloak (Armor)

Cleric - Sword of Ares/Bow of Eos/Gaea's Flail/Neptune's Trident (Weapon)
Jester's Cap (Helmet) Reality's Rampart (Shield) Priestly Guard (Armor)

Wizard - Neptune's Trident (Weapon) Jester's Cap (Helmet) Reality's Rampart
(Shield) Etheric Vestment (Armor)

                    Best Equipment for all Guilds
This is the total best equipment for all guilds. You'll need to force it in
some cases. For information on how to force, refer to the "Tricks and cheats"
section of this FAQ. Once (or should I say "if"?) Twinion is back online, in
case it is, you will be able to force again. For now, I'm still listing them
here. Here they are! You can see there are 4 different weapons because
they all have the same effectiveness. The weapons are the "definite" best;
in other words, I am totally, positively, 100% sure that they are the best,
and so is that way about the Jester's Cap. The shield and armor, however,
I'm only so-so sure about and I may need further testing to make it totally
clear.

(I) Sword of Ares/Bow of Eos/Gaea's Flail/Neptune's Trident (Weapon)
(II) Jester's Cap (Helmet)
(III) Gloves of Protection (Shield)
(IV) Shadow Cloak (Armor)
=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=-=e=?=e=
                          ��????????????????????
                          3 Tricks and Cheats 3
                          ��???????????????????��
This a list of all the cheats, tricks, etc. that can be used in the
game. So far, I've found only 2 actual "tricks" to be used in FoT - yes, they
are the same ones, cheat saving and forcing. Unfortunately, I haven't been
able to find any other tricks that do not require macros or hack programs.

(1) Cheat Saving - Simply save your game from the options menu, then click on
Quit to Dos. Click on "Cancel". Now, IF you die, you can simply use the
bottom dungeon entrance. It will return you to the spot where you last "cheat
saved". This cheat has its use mostly before large battles that you are not
sure you can win, or if you want to take your chance at blindly jumping into
a pit to see if it leads you anywhere. It is, in fact a very useful trick.

(2) Forcing - Forcing an item is simply a way to equip an item that your
guild originally cannot use. First, be sure that you are in a party and
_not_ leading. Also be sure that the party leader knows that you are forcing,
as you will NOT be able to talk while doing so.

1. "Fill up" all spots around your body, (armor, weapon, shield, helmet, and
the 2 spaces by your legs _don't_ place any items in the spot between).
2. Place the item to be forced (I'll use the Spiked Shield for an example)
in the spot between your legs. Be sure to still have the original shield on
your shield spot.
3. Click the left mouse button on the original shield (I'll use a Buckler for
an example) and hold. Drag the shield down to the Spiked Shield and release
the left mouse button. The Buckler and Spiked Shield will switch, so you will
have the Buckler in the spot between your legs and you will be "dragging" the
Spiked Shield.
4. Place the Spiked Shield on the shield spot. Note that it still will say
"That item is not usable by your guild". Ignore it. Once you have the Spiked
Shield over your shield spot, click and hold the left mouse button. Now, you
will need your party leader to take you into a battle. Unfortunately, you
will not be able to talk to him. You'll need some other way to communicate
with only him talking.. Such as having him give you a 10 count after each
step (for example : step 1, then he will wait ten seconds, counting off with
a number each second).
5. Once he takes you into a battle, the Spiked Shield will be "Forced on" for
the battle. It will stay on as long as you don't left click on it; if you do,
then you will have to start the process all over again.

[7.3] Top "Tens"

I just put this in here to give people a little info. Note that these aren't
all top tens. (Some are top 5's or others). Here they are :

10 Toughest places in the game :
     10. Cartography Shop
      9. The Graveyard
      8. Hopeless Hallways
      7. Concordia
      6. Dissemination
      5. Choronozar's Demesne
      4. Funhouse
      3. Race Track
      2. Rat Race
      1. Juvalad's "Plane of Ennakar"
10 Toughest Monsters (Excluding Boss chars i.e. Aeowyn/any Dralk/Choronozar)
      1. Champion of Chaos
      2. Pit Serpent
      3. Imperial Wraith
      4. Imperial Fiend
      5. Imperial Golem
      6. Imperial Kaalroth
      7. Crazed Erebus Fiend
      8. Really Big Dragon
      9. Death Shade
      10. Imperial Ghoul
 5 Toughest Boss Characters (Excluding Dralks)
      1. Queen Aeowyn
      2. Choronozar's "Ghost" (in the Funhouse)
      3. Shaddax & Chiss
      4. Gaoler
      5. The Ogress
 5 Toughest Dralks
      5. Astelligius
      4. Pluthros
      3. Malos
      2. Juvalad
      1. Corpeus
 3 Best Experience Point-gaining Quests
      3. Concordia
      2. Map Quest
      1. Final Quest
=============================================================================
[8.1] Epilogue

 Well, I hope that this FAQ has helped you get through the game in one way or
another. I spent a lot of time writing this, and I hope it is appreciated.
Look for later releases and versions!

                             _  __ _             __
                            / |/ /(_)___ _ ___  / /
                           /    // // _ `// -_)/ /
                          /_/|_//_/ \_, / \__//_/
                                   /___/

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=