The Solve For Hook.
-------------------

ok, ive been stuck on this game for several times but when looking back
it seems i was just a little stupid. so here goes nothing.

go behind pirate square
get line pole
get anchor
go to dead mans pier
get rope
use rope with achor
go to the crossed swords
get two empty mugs.
go to bait and tackle
get empty mug and go up to open door
use anchor with rope three times on top ot croc to get to other side.
u should get a hat now, if u dont just keep on going back and forth until u do.
know on door. u will get a wait a minute and im comming responde and then ull be able to run away back before she opens door.
now u should go back to behind pirate quare and use pole on blue jacket
look at jacket to find gold coin.
now go to muggers alley
go to dr chop
take roller blind from window.
ask how to earn money twice and give two tetth to get two coins.
go out to alley and get into jolliiest rogers place
give 3 mugs and then 3 coing (one at a time, first all mugs)
give full mugs to fake jake(sitting near bar)
get pants.
go back to behind pirate square.
use roller blind.
now go to good form pier
get on hooks ship and go right and get gold from near bars.
go to ye pirates tailors ang buy from him the magnet(talk to him and ask him about magnet)
go to good form beach 
use magnet on x spot
go back to ship
go left

now u will find yourself talking to hook and finaly ull be in the ocean.

use pole on pulley system.
look at clam
use clam


now u get up
ure now in the observation point where u can look at neverlands.
go right until u come to start of forest.
now go up,right,up,left,up,right,right
u will be caught in a trap and tink will appear. now go into tree

ure now in the camp.

go to workshop
get arrow
go to jogging area
use both toos there
go to the avanger and take net
look at net
go to four seasons and get big yellow flower for tink
get eggs by using shell.
go to workshop
give eggs.
to to round pong
give flower
get branch from good tree
(there is also a dead branch in four seasons but i havent found good use for it)
use branch with string to get a bow
go to workshop
use bow on pan pipe
get pipe
go to slingshot
fix it with elastics from workshop(u got the for getting the eggs)
go to cliff and jump(u jump by going to end of cliff and using yourself)
do it three times and after each time ask the boy how was it
when he sais u should try the slingshot now go and use the slingshot
then talk to him again. ask him about his happy thought and ull get marbles.
go to dining area
talk to rufio
insult him(u can do it the hard way by choosing all of the insults one at atime)
(or by just going to the oh rufio! option)
go to round pong again.
go to middle of screen and something throws u over to the other side.
look at all things(fire place beds etc..)
talk to tink
she will give u your teddy and ull remember your mother and all of the story
then u find yourself flying.

Now there is a little animation scene and when it finishes u find yourself with hook on his ship
fight him and push him to the left by choosing the right talk option
(dont worry, if u choose the wrong one u get back but can fix it by the right option)
finaly hooks falls down and thats the end.

congratulations. You have just finished hook (with a little help from your friends)