
			                       RedWolf Design

                   CLONK 3.4 Radikal - Documentation

                       Matthes Bender, March 1997

	 ____________________________________________________


CLONK is a multiplayer game of action, tactics and skill. This version can
be played by up to three players at a time. The game will be played in real
time. Each player will be able to control his crew of clonks in the randomly
generated or user defined worlds, fighting his human opponents and/or the
forces of nature. There are numerous modes and options to provide an almost
unlimited variety of rounds to be challenged.

This is the first English language international shareware release.
Major parts of the documentation have been omitted during the translation
process. This file contains the german documentation and has not been
translated as well as some sections of the game.

Check the on-line help system of Clonk for more information.
Start out by playing the tutorial missions to learn how to play the game.

DISCLAIMER: 

In absolutely no case is the author responsible for any kind of damage or
whatsoever effect that might be caused by the use of this program. There
is also no warranty that the program will function correctly on every system.

                          http://www.clonk.de