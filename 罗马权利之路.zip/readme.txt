Strategy Guide for Rome, Pathway to Power

Thank you for your interest in Maxis Software Toys?. The following document
is the ultimate, step-by-step guide for "winning" Rome: Pathway to Power. If
you want to be challenged by the game, do not read the rest of this
document. On the other hand, if you just want to win, keep on going!

Level 1: Herculaneum...

The objective is to escape from Herculaneum, before being engulfed by lava
from the volcano which is about to explode. The plot is fairly easy, as an
introduction.

Travel to the villa on the west edge of the map ({Up Arrow}{Left Arrow}) and
deliver the message (USE:MESSAGE) to Fellonius the Consul. Wait while he
tips you. Go to the baths (a good time is while en route to the villa) and
wait for a bather to undress on the poolside. Steal his toga
(DO:STEAL:toga). Go to the east end of the quay, put on your toga (USE:TOGA)
so as to look like a citizen, then buy a dagger from the stallholder
(DO:PAY:stallholder).

Roam around town robbing people (DO:THREATEN). Don't try robbing the knife
seller, Fellonius, or Fellonius' slave. The amount of money people have on
them depends on who they are. If you rob more than three people, they'll
band together and attack you.

When you have enough money, go to the west end of the quay, and buy a lucky
die from the stallholder. Immediately threaten him to get your money back!
If you can afford it and the lava isn't a risk, it's a good idea to go to
the temple and pay the priest, who'll make a sacrifice? this will improve
your luck later in the game.

When you're ready (and before he panics and sets sail), go to the quay and
pay the boatman (DO:PAY:boatman); he will take you to Rome.

Level 2: Rome...

On arrival, note that Fellonius the Consul is there also, and appears to be
up to no good. Follow him if you wish, and you'll realize that he is
plotting something (if you wait long enough ((30 minutes), you'll discover
what, as the Emperor gets assassinated and Fellonius takes control).

The main objective in this level is to warn the Emperor of the plot. To do
this, you'll have to get into the palace. This involves getting past the
guards, who'll kick you out if you just try to pass. To get in, you'll have
to bribe them with at least 80 sesterces, so making money is going to be
your main occupation. Some people have managed to pass the guards by
preoccupying them with the expulsion of one of your slaves? this is pretty
neat and perfectly acceptable, but very hard to do.

There is no way to earn money unless you already have some to invest
(robbery doesn't succeed in the big city? try it), so if you arrived
penniless after paying the boatman, you'll have to borrow some. A little way
north of the entrance sits a moneylender (for a minute or two? if you don't
go there straight away, he'll leave, and you'll have to discover him
elsewhere). DO:INQUIRE of him and he'll offer to lend you some money at high
interest. Choose how much to borrow (DO:NONE, DO:10 SEST., etc.). You'll
have to pay him back in level 4, unless you want to risk being publicly
vilified.

Also near the moneylender is the Hostel. For a sesterce paid to the
hosteller, you can get a room for the night? this makes night time pass
swiftly and also protects you from assassins, who roam the dark streets.

The place to start earning money is the southern tavern, playing dice (games
are held frequently)? reply DO:AGREE when asked, try DO:PAY:innkeeper or
USE:DIE to play with your crooked die. You are certain to win the first
game, but after that, normal probability applies. Crooked dice improve your
chances a lot, but if you use them more than three times, you'll be
discovered and lose all your money. A sacrifice at the temple at Herculaneum
will have increased your chances too, as would paying a priest in Rome to
make a prayer for you. Stick with the dice until you have made at least 20
sesterces, preferably more.

As soon as you hear a slave auction announced, go to the Forum and invest
your money in a good gladiator (ignore slave girls unless you have spare
cash? they are no use in this level). Gladiators vary in quality and price?
try to buy a good one (Lecherus is the best of all, but expensive; use WHO
to get info on each candidate). To bid in the auction, use DO:BID when
appropriate. Take note of how much money you have? bids go up in 5 sesterce
lots, so if you have an even number of sesterces, it's rarely worth bidding
first, as you'll just push up the price. The way the bidding goes depends on
the value of the slave and the identity and wealth of the customers.

Your new slave(s) will follow you around for a while, then may go elsewhere.
However, they'll return as soon as you need them.

Slaves can be played in the Coliseum whenever a Games is on (there are two
Games before the Emperor's demise). Go to the arena when the even is
announced, and choose when to play your slave (do USE:SLAVENAME when the
centurion asks for an entrant). A gladiator's chances in battle depend on
the relative strengths of the two opponents, how many fights each has had
recently, and the particular combination of weapons (shortswords rarely beat
a trident, for example). The fight is automatic, and if your slave loses, he
dies and you no longer own him (all slaves are actually reincarnated, to
keep the numbers up). Hopefully, your winnings will be enough to bribe the
guards (DO:PAY:guard) and you'll get through to the Emperor before he snuffs
it. Use DO:WARN to win the level.

Level 3: Britain...

The objective here is to capture the British War Standard, which is kept in
the big village at the north of the map. You lose if you die, or if the
Britons capture the Roman Standard, which you carry with you. There is no
certain way to complete this level, but the following are useful hints:

Watch out for the strength of your men (use WHO)? they tire easily,
especially during a forced march (ORDERS:ADVANCE). You may be able to win by
a single onslaught, but a careful campaigning is more likely to be
successful. Ensure the men get plenty of rest, but don't leave them exposed
to danger unnecessarily.

At first, the Brits don't know you're there, but sooner or later, you'll
stumble across a sentry and the alarm will be raised. Take advantage of this
breathing space to position your men, or pick off a small British
contingent.

The Brits comprise four units of men, three mobile and one defending the
town. When under threat, the Brits' main defensive position is just north of
the bridge over the river (in the west of the map). If they perceive a lower
level of threat, they have a number of strategies, including ganging up on
your main body of troops (especially if they are not war-ready), picking off
an isolated unit, besieging a fort, and capturing your unprotected standard.

Initially, several Brits are ensconced in the two small villages at the east
and west of the map? a useful ploy is to attack them unawares, early in the
game. While in the villages, visit their huts, as some contain valuables,
which Hector can convert to wealth on his return to Rome.

A good strategy is to build a fort, preferably close to the bridge. The men
will build a fort around the place where you were standing when you gave the
order, so choose a clear area, so as not to cut off their retreat. Builders
are very unprepared for battle, so you may wish to keep one or more units on
guard. However, the more men, the quicker the fort gets built. When a fort
is built, plant your standard in it (STD). It is safe there, and you can use
it to get your men back to safety quickly (ORDERS:RALLY makes them return to
the standard). Rest your men at the fort, but to prevent a siege, keep one
unit on watch outside (ORDERS:WATCH).

While one or more units are on watch, the map view will show blips for any
Brits within a reasonable distance of the watchers. Positioning a unit on
watch near the bridge is risky, but a good way to keep an eye on
developments. Note that the cloud covering the map view recedes as you move
further up the map. If you want a good look at the layout, travel up the
east side of the map to the far north; this will clear the cloud but leave
you save.

When you call an attack (ORDERS:ATTACK) the selected unit(s) will run in the
direction they are currently facing, then fight the first Brit they see.
It's therefore important to have your men properly formed up (FORM) before
an attack, else they'll run uselessly off in the wrong direction.

Level 4: Rome (again)...

The objective in this level soon becomes apparent, as the Emperor shortly
gives a speech announcing an election to replace Fellonius. Your first job
is to become an official candidate. Simply DO:PAY a citizen, and he'll go to
the Senate and nominate you (unless he's seriously corrupt, or already a
candidate himself). The other candidates are Laborius the Slaver and
Unscrupulus the Moneylender. Actually, Unscrupulus is a no-hoper, so you
should pay most attention to Laborius.

The rest of the level involves ingratiating yourself with the populous.
There are several tactics available.

Giving people money is a good move, but not necessarily most efficient. Take
care to DO:ENQUIRE of them first? there's no point paying someone who's
already going to vote for you. People's bribeability depends on who they
are. You may have to pay them more than once, and again later if their
allegiance has shifted away from you.

Watch out for the Satirist, who stands at the north gate to the Forum and
denounces you. Any who hear him will be swayed somewhat by his diatribe. Pay
him, and he'll start to denounce your opponents instead, but only for a
while.

If you own a slave girl, give her away (USE:SLAVENAME)? such a gift is
certain to win a friend.

Sponsoring a play has a very good influence on those who go to it. Find a
poet and pay him. Time this carefully, you don't want them to play to an
empty house because it conflicted with an auction or games.

Paying the priest to pray for you is helpful, but don't overdo it!

A success in the Games, especially against one of your opponents is a really
good way to sway the audience. Failure, on the other hand, or even just
letting your opponents be the victors against others, is not a good idea.

If you borrowed money earlier, then the moneylender (an opponent) will ask
for it back now. If you decide not to pay him, he'll stand outside the
Baths, denouncing you to all who listen.

Finally, you should choose the right moment to go to the Emperor and call
for the election (DO:ELECTION). If you leave it to Laborius, he'll do it at
a moment that suits him; you may want to call it while you're ahead. Go to
the Senate and watch the votes being cast.

Level 5: Egypt...

The object of this level is to protect Cleopatra from attack. Many of the
hints for Britain apply here, too, but there are differences.

Your men consist of one crack unit of Romans, and three of less potent
Egyptians. Use the Egyptians as cannon-fodder and keep your Romans as an
elite.

There are three units of enemy troops, who'll arrive in one or two groups
from somewhere at the west of the map. The enemy are always visible on the
map view? no need to put people on watch. The enemy will follow one of
several routs towards the palace; some fast, some slower, with more places
to rest. They may well attack on two fronts, so watch your back.

The most important element in your strategy should be to be aggressive, to
go out and meet the enemy as far from town as possible. Once the enemy are
inside the walls of the town, they are very hard to catch, and it only takes
them a few seconds to slip past you and attack the palace. You may, however,
want to place a unit of two in strategic locations in and around the town;
put them on guard (ORDERS:GUARD) and they'll attack on sight. The main
strategic points are the three bridges across the Nile. You may be able to
beat the opposition across the correct bridge and use it as a point of
defense, or you may meet them as they cross it. The enemy will not attack
you unless provoked; they'll simply walk past you. Try to attack them when
they are tired or resting or both. Try to second-guess their route.
Attacking them inside buildings isn't much use, as your men tend to spill
around the outside, rather than go in (a failing of the system that can't be
helped). If you must attack inside a building, get your men to follow you in
before calling the attack.

Perhaps plant your standard near the Palace, then you can RALLY the troops
as a quick way of returning to defend the palace if things start to go bad.
If you can dishearten the opposition enough, they'll tend to retreat to
previous positions, and you'll find it easier to pick them off.

This level tends to be hard; this is intentional.

Level 6: Rome (one more time)...

This level is short and straightforward, as a reward for getting through
Egypt. All you have to do here is assassinate the Emperor (who's gone mad)
and grab power. There are a couple of new things to watch, e.g., the Emperor
takes part in games, but mostly this is just a short section.

You can kill the Emperor yourself, using the dagger you bought in level one,
or you can employ an assassin to do it for you.

If you kill the Emperor straight away, however, then Gaius, the other
consul, will compete with you for power, and win (try it). Therefore, you
will need to dispatch Gaius first. Be careful doing this, as any witnesses
will run for the guards and have you arrested (unless they are on your
side). You may prefer to use an assassin to kill Gaius, and leave the
pleasure of killing the Emperor to Hector.

To use the assassin, find one, then pay him 100 sesterces (DO:PAY:assassin)
and he will follow you around. Show him who you want him to kill by using
USE:ASSASSIN:target, then watch from a safe distance.

Once you've assassinated everyone you need to do in, the people will gather
you onto their shoulders and proclaim you emperor. At this point, after a
short interlude, the game is over and you've won!

