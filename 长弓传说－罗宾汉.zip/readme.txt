

THE KING'S QUEST COLLECTION


Thank you for your purchase of The King's Quest Collection.
We hope you will find it an enjoyable addition to your
software library.


RUNNING FROM WINDOWS (and who hasn't wanted to at some
point!):

You should have at least 3 megabytes of hard disk space free
to setup the King's Quest Collection.

WINDOWS INSTALLATION:
 1. Place the King's Quest CD into your computer's CD drive
 2. Start Windows
 3. Click on "FILE" and select "RUN".
 4. At the command bar, type the letter of your CD drive,
    followed by "\SETUP.EXE", press "OK". For example, if the
    letter of your CD drive is "D", type "D:\SETUP.EXE", press
    "OK".
 5. Follow the on-screen installation instructions.

You will be able to play all the adventures, peruse video
interviews, explore archives and collections we've put
together for your viewing pleasure. We have also included
some information about the history of Sierra, and some of the 
people who have been so large a part of this little place
in the foothills of Yosemite.

All of the adventures in Windows must be installed to the same
drive and directory as the CD has been installed to. All game
installations should be made to the same drive you selected
during the initial setup process. For example, if the KQ
Collection CD was installed to C:\ when you install KQ1, it
also should be installed to C:\. If the games are placed on a 
different drive than the one selected during the initial setup 
the program will not be able to locate the game files.

If you need to exit during the Windows Installation process,
click on the exit button located on the bottom right side of 
the screen.

 
DOS:

For those hearty souls who enjoy the freedom, not to mention
the lack of Windows overhead, of operating from the DOS
command line and wish to play the adventures or arcades,
insert your CD into your computer's CD-ROM drive and at the
prompt type the letter of your CD drive, followed by a colon.
Example, if your CD-ROM drive letter is "D", you would
type: d: and then press [Enter].
At the prompt type: INSTALL and press [Enter]

To play the trivia games type:  TRIVIA [Enter].
To view the archive of magazine articles type:  CHEST [Enter].
To view the archive of developer's doco type:  SHIELD [Enter].

The video sections and hypertext history of King's Quest can
only be run from Windows.  Please consult the documentation
for running the various King's Quest games.

If you have problems running some programs from DOS, go to the
root directory of the CD by typing CD D:\ (where d: is the letter of
your CD drive) and try again.


INN
On this CD you will also find an introductory ImagiNation
Network offer in the INN directory. Type INN from the main
directory for more information.  It will take approximately
14.8 meg of hard disk space to install.


TECHNICAL NOTES

You may not have more than ONE of the King's Quest CD Programs
activated at the same time.  The CD cannot look at 2 places at
the same time.




SOUND CARDS
Because many of the sound cards sold today weren't developed
when the original products were made, not all sound cards will work
with all games on the Kings Quest Collection CD.  The older games
only have PC Internal Speaker support, if you do not want to listen
to the internal speaker sound you can turn off the music by using the
games menu bar or by pressing F2.


MEMORY

Some of the games require a pretty good chunk of memory to
run properly. The more memory you free up, the better the game will
run. If a particular game is having memory problems, you may need to
use a Bootdisk. Some of the King's Quest games have this option in
the DOS Install program.  Signs of low memory or overtaxed hardware
include slow animation and/or sound breakups, these problems may be
solved by increasing memory (its worth a try).  If you need to create
a boot disk and the boot disk maker supplied with the game does not
function properly you will need to consult the owners manual that was
supplied with your computer system.
We also recommend that you not run this product while attached to a
network, especially from within Windows.


Some DOS 6 and above users may experience problems with bootdisks made
from the install program. In that event, we recommend they use the
bootdisk program in the root directory of Disk 1.
Type BOOTDISK -C.


If you need technical help, please refer to the back pages
of your game documentation for the Customer Support contact numbers.

IMPORTANT INFORMATION
ON THE CARE AND HANDLING
OF DIGITAL ANTIQUES


Dear Customer;

This is a collection of software spanning the first 10 years
of the King's Quest series, the pinnacle of adventure games.
This anthology not only presents the compiled tales of the
King's Quest saga, but also provides an example of the
evolution of computer entertainment software over the last
decade..

As you review early works of the King's Quest series, please
remember that you are looking at what might be described as
"digital antiques" from the early days of personal
computing. Innovations such as mice and music cards, which
are widely used today were not yet available in the early
and mid 1980's. Thus early King's Quest games will not
support them.  We hope that you will enjoy them in the same
nostalgic spirit as you would a classic black and white
movie. While they may lack some modern day technological
flair, we think you'll agree that they do have a unique
quality all their own.

It is also important to note that the Windows operating
system was not in homes during the 80's. While we have
attempted to adjust our software so that it may be accessed
within Windows, some of the early games simply cannot run in
Windows on some computer system configurations.  If you are
experiencing trouble with any adventure game while running
within the windows environment, we recommend that you exit
Windows and instead access the adventure game from MS-DOS.

We sincerely hope you enjoy the enchanted land of Daventry
and beyond as you explore the King's Quest collection.

Sincerely.


John Williams
Resident Historian
Sierra On-Line, Inc.







THE EPIC ADVENTURES
OF THE KING'S QUEST SAGA





 KQ I          The Original King's Quest                 July 1983
(DOS COMMAND)

The first game to fully support the newly introduced EGA color card,
King's Quest clearly demonstrated its superior 16-color capabilities
on this $400 optional video card.The player directs game action by
way of text based commands (example:"OPEN DOOR") and use of the
keyboard arrows keys to control the heros onscreen movements. Please
note that sound cards and mice are not supported, as they did not
exist.


King's Quest VGA    King's Quest I: VGA               September 1990
(DOS COMMAND)

This 1990 project to revamp the original King's Quest was widely
viewed by many reviewers and gamers as an attempt to "destroy the
classics", and the project was often compared to the controversial
practice of "colorization" of classic movies. In comparing this version
to the original, it is interesting to note how much the addition of
the music soundtrack adds to the "mood" of the game. Also, the
addition of the mouse-based player interface provides an interesting
comparison to the original design.


King's Quest II   King's Quest II: Romancing The Throne     May 1985
(DOS COMMAND)

This extension of the original King's Quest game provided not just a
second look at the life of King (formerly Sir) Graham of Daventry, it
also began a tradition of using King's Quest as a training ground for
future designers. Future Space Quest series designer Scott Murphy
joins the development team, and co-Space Quest designer Mark Crowe
acts as art director on the games packaging. This game does not support
sound cards or mice as they did not yet exist at the time of the
products introduction.


King's Quest III   King's Quest III: To Heir Is Human      October 1986
(DOS COMMAND)

It was as a programmer for this project that Al Lowe, future designer
of Sierra's Leisure Suit Larry series, learned the internals of
adventure game programming. Note the "automagic mapping feature" of
the game. This feature was widely promoted on introduction of King's
Quest III, but was not included in future "Quest" games as feedback
from players was that it reduced challenge of play. This mapping feature
was later built into Roberta Williams "Mixed-Up Mother Goose" adventure
game for children, where it was better appreciated. Sound cards and
mice are still not supported in this release.


King's Quest IV   King's Quest IV: The Perils of Rosella September 1988
(DOS COMMAND)

From a technical standpoint, King's Quest IV scored big as the first
commercial entertainment product to support optional music cards.
Successful Hollywood composer William Goldstein (Fame) provided the
stereo soundtrack which added new dimension and emotion to the presen-
tation. One game scene, which placed young Rosella at what might be the
deathbed of her aging father Graham, featured music so touching and
soulful that it reduced more than a few players to tears when it was
shown at a prominent industry tradeshow.  Future advertising for the
product would feature headlines asking "Can a computer game make you
cry?"


King's Quest V    King's Quest V: Absence Makes The      November 1990
(DOS COMMAND)                     Heart Go Yonder

Led by Emmy award-winning producer Bill Davis, "King's Quest V" made
a leap in graphics resolution to full 256 color VGA, and animations
and backgrounds advanced from "computer art" to true handpainted, 
lifelike scenes inhabited by life-like and fluid animated characters.
Over 50, different actors provided voices to the effort, making it the
most elaborate and cinematic game in history.


King's Quest VI  King's Quest VI: Heir Today Gone Tomorrow  Oct. 1992
(DOS COMMAND)

Continuing in a long tradition,  Jane Jensen, who would go on to
design the industry bestselling "Gabriel Knight: Sins of the Father"
assisted Roberta Williams in game design of this epic. The state-of-
the-art "floating camera" sequence that opened the game gave gamers
the world over a real view of what the new age of multimedia computers
could bring to classic storytelling.




 THE COMPLETE HISTORY OF
 THE KING'S QUEST SERIES
 (and Other Fun Stuff)


The Royal Scribe

Through the wee hours of the night, The Royal Scribe's pen
scratches out a chronicle of Sierra On-Line and the King's
Quest series. Read her words with pleasure but be foretold
that a mere touch on text of a different hue will transport
you to another domain.
In more modern terms,  this is a hypertext document. You will
be able to click on highlighted text, thus accessing additional 
material about that particular topic. Use the icon menu to move
from topic to topic and back again.


Behind The Developers Shield

This archive "slide show" holds a treasure-trove of original
King's Quest pencil sketches, background and game art, as well as
a few surprises. The button interface allows you to go between
different screens and sections.


Inside The Chest

This archive contains an assortment of reprints of magazine
articles published during the King's Quest years. Topics range
from King's Quest game reviews to designer interviews to in depth
studies of the game development process. Click the button icons to
move from page to page or from article to article.


A View From Inside The Mirror

Step through the looking glass for a unique View From Inside
The Mirror. In this "made for the computer" video, Roberta Williams
reflects upon her role as the designer of the award winning King's
Quest series.


Hold On To Your Adventurers Cap

What will Roberta Williams think up next? Hold On to Your Adventurers 
Cap and prepare yourself for a video sneak preview of the amazing
and enchanting experiences that are awaiting you in the near future.


King's Questions

Put on your thinking cap and play this trivia game based on the King's
Quest series. You'll be challenged, intrigued, enlightened, and amused
by this grab bag of profound, esoteric, and just plain silly multible
choice King's Questions. Each game consists of twelve randomly selected
questions so that it's never the same game twice! The rules are
explained at the start of the game, so sharpen up your wits and test
your knowledge of King's Quest trivia.


Nick's Picks

Presented for your additional entertainment, herein lies a collection
of computerized board games hand picked as King Grahams personal
favorites.

To run Nick's Picks from DOS, go to the \SIERRA\ARCADES directory on 
your hard disk and enter PLAY.

