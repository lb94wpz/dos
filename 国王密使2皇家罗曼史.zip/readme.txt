===============================================================================

                              FAQ/Walkthrough for
                      KING'S QUEST II: ROMANCING THE THRONE

===============================================================================


GUIDE INFORMATION
-----------------

Author:   Tom Hayes
E-mail:   thayesguides(at)gmail(dot)com
System:   PC
Updated:  21st August, 2008
Version:  1.1


CONTENTS
--------

1. Introduction
2. Walkthrough
     2.1. The First Door
     2.2. The Second Door
     2.3. The Third Door
3. Character List
4. Item List
5. Point List
6. Maps
7. Easter Eggs and Secrets
8. Debug Information
9. Copyright Information


VERSION HISTORY
---------------

1.1:  21st August, 2008  (Format update)
1.0:  27th March, 2000   (First version)


===============================================================================

1.                                Introduction

===============================================================================


It had been one year since Graham recovered the three stolen treasures and was
made King of Daventry. Deciding to hold a celebration, he invited all of the
maidens in the Kingdom to his castle in the hopes of finding a wife. And though
everyone came to the celebration and stayed for days, none of them interested
Graham. He returned to his room and mournfully asked where he would ever find
the maiden that he is looking for. At this question, the mirror changes to show
an image of a beautiful woman in a tower. Graham asks the mirror more questions
and discovers that the woman is from Kolyma, and was imprisoned in the tower of
an enchanted land by the witch Hagatha. The only way of entering the enchanted
land is to find three keys hidden in the kingdom of Kolyma. Knowing that this
is the maiden who will be his wife, Graham sets off to Kolyma to find her.


===============================================================================

2.                                Walkthrough

===============================================================================


-------------------------------------------------------------------------------
2.1.                             The First Door
-------------------------------------------------------------------------------


The game starts in the land of Kolyma, where Graham begins his quest to find a
queen. The arrow keys control movement in the game, so use the up arrow key to
walk north to the next screen. A group of rocks seem to block the way to the
next area, but there is a small gap hidden between the rocks at the top-right
corner of the area. Walk through the gap and continue north to the next area. A
trident lies on the grass here, but Graham has to be close by to this item to
do anything with it. Stop moving north by pressing up the up arrow key again.

GET the TRIDENT on the grass and it will be added to Graham's inventory. Walk
north two screens to see a white shell on the beach. GET the SHELL and also GET
the diamond BRACELET that was hidden under it. Walk east one screen and GET the
STAKE leaning up against the bottom of the tree. Walk south to an area with
lots of trees. You can view one of the game's easter eggs by taking a LOOK at
the SIGN on the back of one of the trees. Walk east one screen but be careful
not to walk too far into the area as Graham will fall into the poisoned lake.

While standing at the side of the poisoned lake, it is a good idea to save the
game by pressing F5 as Hagatha the witch can appear around this area. If she
does catch Graham and takes him back to her cave, then restore the game by
pressing F7. Walk south two screens to see a log at the bottom-right corner of
the area. LOOK IN the LOG to see a necklace made of diamonds and sapphires.
GET the NECKLACE to add it to the inventory. By now you should have five items
in the inventory, and these can all be examined more closely by pressing F4.

Walk south two screens from the log and then walk west one screen to arrive in
an area where various flowers are growing. Little Red Riding Hood should enter
the area. If she doesn't appear, exit the area and return to it until she does.
TALK to the GIRL and she will tearfully explain that her basket of goodies were
stolen while she was picking flowers. She asks Graham to help her find them.
Walk east one screen and OPEN the MAILBOX outside the cottage. GET the BASKET
of goodies from the mailbox and walk west to the previous area.

Little Red Riding Hood may not be in the area, so again just exit and return to
the area until she appears. GIVE the BASKET of goodies TO RED RIDING HOOD and
she will give Graham her bouquet of flowers in return. Walk north one screen
and then walk east two screens to an area with a door built into a tree. OPEN
the DOOR and walk onto the ladder. Climb down to the bottom of the ladder and
walk east to enter the home of a dwarf. If the dwarf is there, exit and return
to the room until he has gone. All the dwarf will do if he catches Graham is
take him outside his house, so just return to his room if he does this.

GET the bubbling pot of chicken SOUP from the fireplace. OPEN the CHEST and GET
the EARRINGS. Walk west to the previous screen and climb back up the ladder.
Exit the tree and walk south one screen and west one screen to return to the
area with the mailbox outside the cottage. OPEN the DOOR and enter the cottage.
If there is a wolf in the room, quickly exit and return to the cottage until
there is an old woman in the bed. GIVE the SOUP TO the WOMAN, and in return for
his kindness she will tell Graham to look under the bed. LOOK under the BED and
Graham will find a large ruby ring and a black cloak. Exit the cottage.

Walk east two screen and north two screens. Walk to the top of the rocks and
GET the MALLET from the hole in the tree. Walk south two screens and east one
screen to the monastery entrance. OPEN the DOOR to enter the monastery where a
monk is praying at an altar. Walk to the altar and PRAY to gain the attention
of the monk. He will stand and ask Graham his name, so answer GRAHAM. The monk
says that he has heard of his quest, and he gives Graham a silver cross to
protect him from evil. WEAR the CROSS and then exit the monastery.

Walk south one screen to see a rock with a hole in it. LOOK IN the HOLE and GET
the BROOCH. Walk north two screens and cross over the bridge. The ropes on the
bridge prevent Graham from falling into the chasm. Walk north one screen on the
other side of the bridge to see a magical door in the middle of the area. READ
the inscription on the DOOR and it will mention that the seeker of the key will
make a splash. Walk south one screen and west one screen. Cross the bridge and
go west five screens and south three screens to see a mermaid on a rock.

Walk into the water and swim over to the mermaid. GIVE the FLOWERS TO the
MERMAID and she will summon a seahorse. RIDE the SEAHORSE and it will take
Graham down to King Neptune. GIVE the TRIDENT TO the KING and he will give a
bottle to Graham. He also uses his trident to open the clam, which shows a gold
key. Swim over to the open clam and GET the KEY from it. Move east one screen
and the seahorse will return Graham to the surface. Walk north three screens,
east six screens and north one screen. UNLOCK the DOOR using the gold key.


-------------------------------------------------------------------------------
2.2.                             The Second Door
-------------------------------------------------------------------------------


With the first door unlocked, a new blue door is revealed behind it. READ the
inscription on the DOOR, which mentions that the seeker of the key should set
their sights high. Walk south one screen and west five screens to see the cave
that Hagatha the witch lives in. Enter the cave to see Hagatha standing by her
cauldron, stirring her brew with a stick. She cannot see Graham, but will be
able to locate him if he talks or scares the bird in the cage. GET the CLOTH
from the bottle given by King Neptune, and then PUT the CLOTH OVER the CAGE to
prevent the nightingale from being scared. GET the CAGE and exit the cave.

Walk east four screens, south two screens, east one screen, south one screen
and then west one screen to see an shop. Be careful of an evil enchanter that
appears in this area, as he will kill Graham if he catches him. Stay close to
the edge of the area so that you can quickly exit if he does appear. OPEN the
DOOR to enter the shop. Walk over to the counter and GIVE the bird CAGE TO the
WOMAN. Grateful to have her nightingale back, she gives Graham an oil lamp and
closes the shop. RUB the LAMP and a genie will appear to give Graham a magic
carpet. RIDE the CARPET to travel through the clouds to a mountain top.

Walk east one screen and RUB the LAMP to receive a sword from the genie. Now
while this could be used to kill the snake that is blocking the path, less
points are awarded so RUB the LAMP again to receive a bridle from the genie.
PUT the BRIDLE ON the SNAKE and it will transform into a horse. TALK to the
HORSE and he will explain that the evil enchanter transformed him into a snake.
He gives Graham a sugar cube that protects against poisonous brambles. Walk
east two screens and GET the gold KEY from the rock in the cave.

Exit the cave to see a small hole at the bottom of a rock. LOOK in the HOLE to
reveal another easter egg, this one an advertisement for the original Space
Quest. It is a long scene and there is no way of skipping it. After the scene
has finished, RIDE the CARPET to return to the antique shop at the bottom of
the mountain. Walk north one screen, east one screen, north one screen, west
one screen, north one screen, east one screen and north one screen to return to
the area with the door. UNLOCK the DOOR using the gold key.


-------------------------------------------------------------------------------
2.3.                             The Third Door
-------------------------------------------------------------------------------


With the second door unlocked, a new green door is revealed behind it. READ the
inscription on the DOOR, which mentions that the seeker of the key should have
a stout heart. Walk south one screen, west three screens and north two screens
to see a shrouded ghoul on a boat in the poisoned lake. WEAR the RING and WEAR
the CLOAK. ENTER the BOAT and the ghoul will mistake Graham for someone else.
If you don't have the ring or the cloak, then for less points you could give
him any of the treasures that have been found so far. Either way, the ghoul
will row over to the island in the middle of the poisoned lake.

EXIT the BOAT and EAT the sugar CUBE given by the horse up on the mountain top.
Graham will now not be harmed if he touches the poisonous brambles growing from
the ground. If you killed the snake with the sword before it turned into the
horse, then carefully follow the path while avoiding the brambles. Walk north
one screen at the top of the path to see two ghosts flying around in front of
the castle door. They will fly away once they see that Graham is wearing the
cloak and the ring. OPEN the DOOR to enter the castle.

Walk west one screen and climb up the spiral steps to the room at the top. OPEN
the DRAWER and GET the wax CANDLE. Walk back down the spiral steps and stop at
the torch on the wall to LIGHT the CANDLE. Continue down to the bottom of the
steps and walk east two screens to the dining room. GET the MEAT on the table
and then walk east one screen. The lit candle will illuminate the room, so walk
carefully down the steps to the empty room at the bottom. For a small shortcut,
you can safely drop off the ledge and avoid the last two sets of steps.

From the empty room, walk west one screen into the coffin room. Exit and return
to the room until the coffin is closed. OPEN the COFFIN and KILL DRACULA using
the mallet and the stake. Dracula crumbles to dust, leaving a shiny silver key
in the coffin. GET the silver KEY, GET the PILLOW and GET the gold KEY from the
coffin. Walk east one screen, up two screens, north one screen and up one
screen. In the tower at the top of the spiral steps, UNLOCK the CHEST using the
silver key. OPEN the CHEST and GET the TIARA. Walk down one screen, south one
screen, west one screen and south one screen to exit the castle.

Walk south down the path between the brambles. If the effects of the sugar
cube have worn off by this point, the brambles will be deadly so be sure to
save frequently when walking down the path. ENTER the BOAT at the bottom of
the path to return to the other side of the poisoned lake. With the final gold
key now in the inventory, walk east one screen, south two screens, east two
screens and north one screen to return to the door. UNLOCK the DOOR using the
gold key. This time, unlocking the door leads Graham to a new world.

Walk north one screen and GET the fishing NET on the ground. Walk south one
screen and stand near the ocean to FISH. Keep fishing until Graham catches a
big golden fish. GET the FISH and THROW the FISH back into the water, where it
offers Graham a lift across the ocean in return for his kindness. RIDE the FISH
across to the small island. The water surrounding the island is turbulent, so
swimming back is not an option. Walk north two screens and east one screen to
GET the AMULET on the ground. Walk south one screen and OPEN the tower DOOR.

Climb carefully up the spiral steps and GIVE the MEAT TO the LION at the top.
You could use the sword to kill the lion, but less points are given this way.
OPEN the DOOR to see Valanice, the woman that Graham saw in the mirror. Say the
word HOME, and Graham will return with Valanice to the monastery in the land of
Kolyma. In the ending, friends and enemies from Daventry and Kolyma watch as
Graham marries Valanice. Together, they return to Daventry castle.


===============================================================================

3.                              Character List

===============================================================================


ANTIQUES SHOP OWNER
  Found in the antiques shop. Her nightingale was stolen by Hagatha the witch.
  Although she will accept two treasures in exchange for her oil lamp, she will
  gladly hand over the oil lamp for free in return for her nightingale.


DRACULA
  Found in the coffin in the basement of the castle. Dracula can be killed if
  Graham quickly uses the mallet and the stake on him. If Graham waits too
  long, Dracula wakes from his sleep and runs toward Graham. He is afraid of
  the cross given by the monk in the monastery and will leave if he sees it.


DWARF
  Found outside the dwarf house and in the living room of the dwarf house. The
  dwarf will steal any treasure that Graham is carrying. If no treasures are
  being carried, the dwarf will leave Graham alone. If he catches Graham in his
  house, he will take him outside without stealing any treasure.


ENCHANTER
  Found outside the antiques shop and also one screen south from the shop. The
  evil enchanter was responsible for transforming the horse into the snake on
  the mountaintop. He can cast a spell that changes Graham into a frog.


FAIRY
  Found outside the monastery and also one screen south from the monastery. The
  fairy casts a spell that will temporarily protect Graham from enemies.


FISH
  Found by fishing on the beach at the enchanted land. The golden fish takes
  Graham across the ocean to the island when it is thrown back into the water.


GENIE
  Found by rubbing the oil lamp. The genie grants Graham a different item each
  time the oil lamp is rubbed. One time for the carpet, two times for the sword
  and three times for the bridle. The genie disappears after giving the bridle.


GHOSTS
  Found outside the entrance to Dracula's castle. The two ghosts possess Graham
  if they touch him, making him walk into the poisoned brambles. If he wears
  the black cloak and the ring the ghosts will think he is Dracula, and will
  leave him alone. They will also fly away if Graham wears the monk's cross.


GRAHAM
  The main character of the game. Graham has travelled to the land of Kolyma to
  find the entrance to an enchanted land where a maiden is trapped.


GRANDMA
  Found in her bed in the cottage. When given the chicken soup, she will allow
  Graham to take the black cloak and the ruby ring from under her bed.


HAGATHA
  Found in the cave one screen south-east from the trident. Hagatha is a witch
  who imprisoned Valanice at the top of the tower on the enchanted land. She
  has a nightingale in her cave that belongs to the antiques shop owner.


HORSE
  Found on the mountaintop if Graham uses the bridle instead of the sword on
  the snake. The horse was transformed into the snake by the enchanter when he
  refused to be his steed. He will give Graham the sugar cube.


KING NEPTUNE
  Found by riding the seahorse in the ocean after giving the flowers to the
  mermaid. He will give Graham the first gold key when his trident is returned.


LITTLE RED RIDING HOOD
  Found one screen west from the cottage. She has lost her basket of goodies.
  When Graham finds the basket for her, she gives him a bouquet of flowers.


LION
  Found at the top of the tower on the enchanted land. The lion can be given
  the ham, or can be killed with the sword for less points.


MERMAID
  Found on a rock on the beach after the inscription on the first magic door
  has been read. When she has been given the bouquet of flowers, a seahorse
  appears that will takes Graham to King Neptune under the ocean.


MONK
  Found in the monastery. The monk will say nothing until Graham prays. When he
  does, the monk asks Graham for his name and gives him a cross.


NIGHTINGALE
  Found in Hagatha's cave. The bird is scared of Graham, and can be taken only
  when its cage has been covered with the cloth from the bottle. The bird can
  be returned to the antiques shop owner, who rewards Graham with an oil lamp.


ROGER WILCO
  Found by looking in the hole in the rock one screen west from the cave on the
  mountain top. Roger Wilco is a janitor from the Space Quest series of games,
  although he appears in a lengthy easter egg advertisement in this game.


SEAHORSE
  Found by giving the bouquet of flowers to the mermaid on the rock at the
  beach. Graham rides the seahorse down to King Neptune under the ocean.


SHROUDED GHOUL
  Found at the south side of the poisoned lake after the inscription on the
  third door has been read. The ghoul will take Graham across the lake for free
  if he is wearing the black cloak and the ring, or he can be given one of the
  treasures and will take Graham across the lake for less points.


VALANICE
  Found at the top of the tower in the enchanted land. Valanice is the maiden
  that Graham viewed in the magic mirror and the one he set out to save.


VIPER
  The snake up on the mountaintop used to be a horse before a spell was cast on
  him by the evil enchanter. The snake will attack Graham if he gets too close.
  Graham can either choose to deal with the snake by force or by using a kinder
  method that may return the snake to his original form.


WOLF
  Although Grandma appears most frequently inside the cottage, the wolf will
  sometimes be sitting in the bed. After a quick pause, the wolf will jump out
  of the bed and run toward Graham. Exit quickly if the wolf is present.


===============================================================================

4.                                Item List

===============================================================================


AMULET
  Found on the sand at the north side of the enchanted island. The amulet has
  the power to teleport Graham back to Daventry when he says the word 'home'.


BASKET OF GOODIES
  Found in the mail box outside the cottage. They are given to Red Riding Hood
  in the area one screen west from the cottage for the bouquet of flowers.


BLACK CLOAK
  Found under the bed in the cottage after the woman has been given the chicken
  soup. It is worn by Graham to pass the shrouded ghoul on the boat at the
  south side of the poisoned lake and the ghosts outside Dracula's castle.


BOTTLE
  Found by giving the trident to King Neptune under the ocean. The bottle holds
  a cloth, and changes into the empty bottle item when the cloth is taken.


BOUQUET OF FLOWERS
  Found by giving the basket of goodies to Red Riding Hood. They are given to
  the mermaid at the beach after the second door inscription has been read.


BRACELET
  Found under the clamshell on the beach one screen west from the stake. It is
  one of the five diamond and sapphire treasures.


BRIDLE
  Found by rubbing the oil lamp for the third time. It can be used on the snake
  one screen east from the mountain top landing point.


BROOCH
  Found in the hole in the rock one screen north from the antiques shop
  entrance. It is one of the five diamond and sapphire treasures.


CAGED NIGHTINGALE
  Found in Hagatha's cave after the cage has been covered with a cloth. It is
  given to the woman in the antiques shop for the oil lamp.


CANDLE
  Found in the drawer at the top of the west tower in Dracula's castle. It is
  lit on the torch above the steps in the west tower, and is used to illuminate
  the steps and the basement area at the east side of the castle.


CARPET
  Found by rubbing the oil lamp for the first time. It is used to fly from the
  entrance of the antiques shop to the mountain top and back again.


CHICKEN SOUP
  Found in the pot above the fire in the dwarf house. It is given to the woman
  in the cottage, who will then allow Graham to look under her bed.


CLAMSHELL
  Found on the beach one screen west from the stake. The bracelet can be found
  on the beach when the clamshell is taken. It is not used.


CLOTH
  Found in the bottle. It is put over the cage in Hagatha's cave to prevent the
  nightingale from being scared of Graham.


CROSS
  Found by answering the monk's question after praying in the monastery. It can
  be worn by Graham to pass the ghosts outside Dracula's castle.


EARRINGS
  Found in the chest at the right side of the dwarf house. It is one of the
  five diamond and sapphire treasures.


EMPTY BASKET
  Found by eating the basket of goodies from the mailbox outside the cottage.
  This reduces the total score by 2 and the flowers can no longer be collected.


EMPTY BIRDCAGE
  Found by opening the cage containing the nightingale. This reduces the total
  score by 2 and the nightingale can no longer be given to the woman.


EMPTY BOTTLE
  Found by removing the cloth from the bottle. It is not used.


FISHING NET
  Found on the beach one screen north from the start point on the enchanted
  land. It is cast into the sea until the golden fish is found.


GASPING FISH
  Found by picking up the golden fish after catching it on the enchanted land.
  It is thrown back into the ocean so it can take Graham to the island.


GOLD KEY
  Found by giving the trident to King Neptune, in the cave on the mountain top
  and under the pillow in Dracula's coffin. The three gold keys are used to
  open the three locked doors on the east side of the Kolyma chasm.


HAM
  Found on the table one screen east from the lobby in Dracula's castle. It is
  given to the lion at the top of the tower in the enchanted land.


MALLET
  Found in the hole in the tree one screen north-east from the dwarf house. The
  mallet and the stake are used to kill Dracula in his coffin in the castle.


NECKLACE
  Found in the hollow log one screen north-east from Hagatha's cave. It is one
  of the five diamond and sapphire treasures.


OIL LAMP
  Found by giving the caged nightingale or two of the diamond and sapphire
  treasures to the woman in the antiques shop. The lamp is rubbed once for a
  carpet, twice for the sword and three times for the bridle.


PILLOW
  Found in the coffin in Dracula's castle. The silver key can be found in the
  coffin when the pillow is taken. It is not used.


RUBY RING
  Found under the bed in the cottage after the woman has been given the chicken
  soup. It is worn by Graham to pass the shrouded ghoul on the boat at the
  south side of the poisoned lake and the ghosts outside Dracula's castle.


SILVER KEY
  Found under the pillow in Dracula's coffin. It is used to unlock the chest
  containing the tiara at the top of the north tower in Dracula's castle.


STAKE
  Found one screen east from the clamshell on the beach. The stake and the
  mallet are used to kill Dracula in his coffin in the castle.


SUGAR CUBE
  Found by talking to the horse on the mountain top. It is eaten to prevent
  Graham from being poisoned by the brambles outside Dracula's castle.


SWORD
  Found by rubbing the oil lamp once. It can be used to kill the snake on the
  mountaintop, the golden fish on the beach and the lion at the top of the
  enchanted land tower. Less points are given when the sword is used.


TIARA
  Found in the chest at the top of the north tower in Dracula's castle. It is
  one of the five diamond and sapphire treasures.


TRIDENT
  Found on the grass one screen north-west from Hagatha's cave. It is given to
  King Neptune after Graham rides on the seahorse in the ocean.


===============================================================================

5.                                Point List

===============================================================================


            THE FIRST DOOR
            --------------
3      3    Get the trident on the beach.
10     7    Get the bracelet below the clamshell.
12     2    Get the stake leaning against the tree.
19     7    Get the necklace from the log.
20     1    Open the mailbox outside the cottage.
22     2    Get the goodies from the mailbox.
26     4    Give the goodies to little red riding hood.
28     2    Get the soup from the dwarf house.
35     7    Get the earrings from the dwarf house.
37     2    Give the soup to grandma in the cottage.
41     4    Look under the bed in the cottage.
43     2    Get the mallet from the hole in the tree.
45     2    Pray at the monastery.
47     2    Answer the monk's question.
49     2    Wear the cross given by the monk.
50     1    Look in the hole in the rock.
57     7    Get the brooch from the hole in the rock.
58     1    Cross the bridge over the chasm for the first time.
59     1    Cross the bridge over the chasm for the second time.
61     2    Give the flowers to the mermaid on the rock.
63     2    Ride the seahorse in the ocean.
67     4    Give the trident to King Neptune.
72     5    Get the first gold key from the clam.
73     1    Cross the bridge over the chasm for the third time.
80     7    Unlock the first door using the gold key.


            THE SECOND DOOR
            ---------------
81     1    Cross the bridge over the chasm for the fourth time.
83     2    Get the cloth from the bottle.
85     2    Put the cloth over the nightingale cage.
87     2    Get the cage from Hagatha's cave.
93     6    Give the nightingale to the antiques shop owner.
95     2    Rub the lamp once for the carpet.
99     4    Ride the carpet to the mountain top.
101    2    Rub the lamp twice for the sword.
103    2    Rub the lamp three times for the bridle.
108    5    Put the bridle on the snake.
110    2    Talk to the horse.
115    5    Get the second gold key from the cave.
116    1    Cross the bridge over the chasm for the fifth time.
123    7    Unlock the second door using the gold key.


            THE THIRD DOOR
            --------------
124    1    Cross the bridge over the chasm for the sixth time.
127    3    Wear the black cloak and the ruby ring.
128    1    Eat the sugar cube outside Dracula's castle.
130    2    Get the candle from the drawer.
131    1    Light the candle on the west tower torch.
133    2    Get the ham on the dining room table.
140    7    Kill dracula in his coffin.
142    2    Get the silver key from the coffin.
147    5    Get the third gold key below the pillow.
148    1    Unlock the chest in the north tower.
155    7    Get the tiara from the chest.
156    1    Cross the bridge over the chasm for the seventh time.
163    7    Unlock the third door using the gold key.
164    1    Get the net from the beach.
166    2    Catch the golden fish.
169    3    Throw the fish back into the water.
170    1    Ride the fish across to the island.
173    3    Get the amulet from the island.
177    4    Give the ham to the lion in the tower.
182    5    Open the door in the tower.
185    3    Say the word on the amulet to return to Daventry.


===============================================================================

6.                                   Maps

===============================================================================


MAP 1: KOLYMA
-------------

   *1         *2         *3         *4         *5         *6         *7
 ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
| Beach |  | Lake  |  |Poison |  |Poison |  |Poison |  |       |  | Lake  |
|  (1)  |--|  (1)  |--|Lake(1)|--|Lake(2)|--|Lake(3)|--|Brooch |--|  (2)  |
|___ ___|  |___ ___|  |___ ___|  |_______|  |___ ___|  |___ ___|  |___ ___|
    |          |          |                     |          |          |
 ___|___    ___|___    ___|___               ___|___    ___|___    ___|___
|       |  |       |  |Poison |             |Poison |  |Antique|  |Antique|
|Mermaid|--| Trees |--|Lake(4)|             |Lake(5)|--|Shop(1)|--|Shop(2)|
|___ ___|  |___ ___|  |___ ___|             |___ ___|  |___ ___|  |___ ___|
    |          |          |                     |          |          |
 ___|___    ___|___    ___|___               ___|___    ___|___    ___|___
|       |  |       |  |Poison |             |Poison |  | Field |  |       |
| Shell |--| Stake |--|Lake(6)|             |Lake(7)|--|  (1)  |--| Cliff |
|___ ___|  |___ ___|  |___ ___|             |___ ___|  |___ ___|  |___ ___|
    |          |          |         *15         |          |          |
 ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
| Beach |  |       |  |Poison |  |Castle |  |Poison |  | Lake  |  | Chasm |
|  (2)  |--| Sign  |--|Lake(8)|--| Boat  |--|Lake(9)|--|  (3)  |--|  (1)  |
|___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
    |          |          |          |          |          |          |
 ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
|       |  | Lake  |  |       |  | Field |  |       |  | Chasm |  |       |
|Trident|--|  (4)  |--|Necklce|--|  (2)  |--|Mallet |--|  (2)  |--| Door  |
|___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
    |          |          |          |          |          |          |
 ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
| Beach |  | Witch |  | Field |  | Dwarf |  | Field |  |       |  | Chasm |
|  (3)  |--| Cave  |--|  (3)  |--| House |--|  (4)  |--|Bridge |--|  (3)  |
|___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
    |          |          |          |          |          |          |
 ___|___    ___|___    ___|___    ___|___    ___|___    ___|___    ___|___
| Beach |  |Riding |  |       |  | Field |  |Church |  |Church |  | Chasm |
|  (4)  |--| Hood  |--|Cottage|--|  (5)  |--|  (1)  |--|  (2)  |--|  (4)  |
|___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
    |          |          |          |          |          |          |
   *8         *9         *10        *11        *12        *13        *14


*1: Leads to the Beach (4) on map 1.
*2: Leads to the Red Riding Hood area on map 1.
*3: Leads to the Cottage on map 1.
*4: Leads to the Field (5) on map 1.
*5: Leads to the Church (1) on map 1.
*6: Leads to the Church (2) on map 1.
*7: Leads to the Chasm (4) on map 1.
*8: Leads to the Beach (1) on map 1.
*9: Leads to the Lake (1) on map 1.
*10: Leads to the Poison Lake (1) on map 1.
*11: Leads to the Poison Lake (2) on map 1.
*12: Leads to the Poison Lake (3) on map 1.
*13: Leads to the Brooch area on map 1.
*14: Leads to the Lake (2) on map 1.
*15: Leads to the Brambles on map 2.


MAP 2: DRACULA'S CASTLE
-----------------------

                       _______
                      |       |
                      | Tiara |
                      |___ ___|
                          |
 _______               ___|___
|       |             |Spiral |
|Candle |             |Stairs |
|___ ___|             |___ ___|
    |                     |
 ___|___    _______    ___|___    _______
|Spiral |  |       |  |       |  |       |
|Stairs |--| Lobby |--|  Ham  |--|Stairs |
|_______|  |___ ___|  |_______|  |_______|
               |                         \__
            ___|___                         \_______
           |       |                        |       |
           |Ghosts |                        |Basemnt|
           |___ ___|                        |_______|
               |                          __/
            ___|___               _______/
           |       |             |       |
           |Bramble|             |Coffin |
           |___ ___|             |_______|
               |
              *1


*1: Leads to the Castle Boat on map 1.


MAP 3: UNDER THE OCEAN
----------------------

 _______    _______    _______    _______
|       |  |       |  |       |  |       |
|Neptune|--| Ocean |--| Ocean |--| Ocean |-*1
|_______|  |_______|  |_______|  |_______|


*1: Leads to the Mermaid on map 1.


MAP 4: MOUNTAIN TOP
-------------------

    _______    _______    _______*2  _______
   |Mountn |  |       |  |       |  | Gold  |
*1-|  Top  |--| Viper |--| Hole  |--|  Key  |
   |_______|  |_______|  |_______|  |_______|


*1: RIDE the CARPET to travel to the Antiques Shop (1) on map 1.
*2: LOOK IN the HOLE for the Space Quest easter egg.



MAP 5: ENCHANTED LAND
---------------------

 _______    _______    _______    _______    _______
| Fish  |  |       |  |       |  |       |  |       |
|  Net  |--| Ocean |--|Island |--|Amulet |--|Island |
|___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
    |          |          |          |          |
 ___|___    ___|___    ___|___    ___|___*1  ___|___
|       |  |       |  |       |  |       |  |       |
| Beach |--| Ocean |--|Island |--| Tower |--|Island |
|___ ___|  |___ ___|  |___ ___|  |___ ___|  |___ ___|
    |          |          |          |          |
 ___|___    ___|___    ___|___    ___|___    ___|___
|       |  |       |  |       |  |       |  |       |
| Beach |--| Ocean |--|Island |--|Island |--|Island |
|_______|  |_______|  |_______|  |_______|  |_______|


*1: Leads to the bottom Steps on map 6.


MAP 6: ISLAND TOWER
-------------------

 _______
|       |
|Vlanice|
|___ ___|
    |
 ___|___
|       |
| Lion  |
|___ ___|
    |
 ___|___
|       |
| Steps |
|___ ___|
    |
 ___|___
|       |
| Steps |
|___ ___|
    |
   *1


*1: Leads to the Tower on map 5.


===============================================================================

7.                         Easter Eggs and Secrets

===============================================================================


ALTERNATE ENDING
----------------

It is possible to return to Daventry without Valanice by saying "home" when
Graham gets the amulet. Graham returns to Daventry and enters the castle
without a bride, and the ending credits then appear on the screen.


BATMOBILE
---------

Walk south from the entrance to Hagatha's cave to exit the area, then walk
north again to return to the area. Keep exiting and returning to the area and
eventually the batmobile will drive out of the cave.


SECRET SIGN
-----------

Walk one screen south from the stake to see a group of trees. One tree has a
sign on the back which advertises Space Quest I and King's Quest III.


SPACE QUEST I ADVERTISEMENT
---------------------------

Look in the hole in the rock on the mountaintop one screen west from the cave.
An advertisement for Space Quest I: The Sarien Encounter appears. It shows
Wilco on the Arcada, being squashed by a rock in the desert on Kerona, being
chased by the spider droid in the desert, entering the bar in Ulence Flats and
dodging asteroids on the way to the Sarien ship.


===============================================================================

8.                            Debug Information

===============================================================================


Hold Alt + D to access debug mode. Type "Get object" followed by a number to
collect any item in the game, or "TP" followed by a number to teleport to a
new location. "Pos" can be used to move Graham around in a room.


ITEMS
-----

50  Sword                      62  Empty Basket               74  Pillow
51  Trident                    63  Basket of Goodies          75  Fishing Net
52  Bouquet of Flowers         64  Bottle                     76  Carpet
53  Bracelet                   65  Empty Bottle               77  Bridle
54  Stake                      66  Ham                        78  Candle
55  Ruby Ring                  67  Chicken Soup               79  Sugar Cube
56  Tiara                      68  Black Cloak                80  Gasping Fish
57  Necklace                   69  Cross                      81  Amulet
58  Earrings                   70  Caged Nightingale          82  Clamshell
59  Brooch                     71  Empty Birdcage             83  Silver Key
60  Mallet                     72  Oil Lamp                   84  Dead Fish
61  Gold Key                   73  Cloth


LOCATIONS
---------

1   Beach                                 48  Bridge over chasm
2   Little Red Riding Hood                49  Cliffs east from chasm bridge
3   Cottage                               50  Ocean west from the beach
4   East from cottage                     51  King Neptune
5   Monastery west side                   52  Ocean east from Neptune
6   Monastery entrance                    53  Two screens east from Neptune
7   Chasm south side                      54  Three screens east from Neptune
8   Beach                                 55  Mountain top
9   Lake south-west from cottage          56  Mountain top snake
10  Poisoned lake north-west corner       57  Mountain top cave entrance
11  Poisoned lake north side              58  Mountain top gold key cave
12  Poisoned lake north-east corner       59  Dracula's castle west tower
13  Brooch                                60  Dracula's castle spiral steps
14  Lake south from chasm                 61  Dracula's castle lobby
15  Beach mermaid rock                    62  Dracula's castle north tower
16  Field north from stake                63  Dracula's castle torch
17  Poisoned lake west side               64  Dracula's castle dining room
18  Dracula's castle entrance             65  Dracula's castle basement steps
19  Poisoned lake east side               66  Dracula's castle basement
20  Antique shop entrance                 67  Dracula's castle coffin room
21  Antique shop east side                68  Antique shop interior
22  Clamshell                             69  Hagatha's cave interior
23  Stake                                 70  Cottage interior
24  Poisoned lake west side               71  Monastery interior
25  Brambles outside Dracula's castle     72  Dwarf house ladder top
26  Poisoned lake east side               73  Dwarf house ladder bottom
27  Field south from antique shop         74  Dwarf house chest
28  Cliff south-east from antique shop    75  Enchanted land north beach
29  Beach                                 76  Enchanted land north ocean
30  Tree with sign                        77  Island north-west corner
31  Poisoned lake south-west corner       78  Island amulet
32  Poisoned lake south side              79  Island north-east corner
33  Poisoned lake south-east corner       80  Enchanted land middle beach
34  Lake north-east from mallet           81  Enchanted land middle ocean
35  Lake north from magic door            82  Island west side
36  Trident                               83  Island tower
37  Lake north from Hagatha's cave        84  Island east side
38  Necklace                              85  Enchanted land south beach
39  Field north from dwarf house          86  Enchanted land south ocean
40  Mallet                                87  Island south-west corner
41  Chasm east from magic door            88  Island south side
42  Magic door                            89  Island south-east corner
43  Beach west from Hagatha's cave        90  Island tower Valanice
44  Hagatha's cave entrance               91  Island tower lion
45  Field East from Hagatha's cave        92  Island tower spiral steps middle
46  Dwarf house entrance                  93  Island tower spiral steps bottom
47  Field west from chasm bridge


===============================================================================

9.                           Copyright Information

===============================================================================


This file is Copyright 2000-2008 Tom Hayes. As it can be difficult to keep
track of websites that haven't posted the latest version of this file, please
do not distribute it without my permission. Send an e-mail to me if you would
like to post this file on your website and you will likely receive a positive
response. If you do post the file, please keep it in its original form with all
of the sections intact and credit the author (Tom Hayes) as the writer of the
file. The latest version of this file can be found at www.gamefaqs.com.