This is a modified version of Aliens Abuse. I tinkered with it until
it was compact, and the objects that I wanted with fRaBs were intact
and the extraneous stuff was gone.

Aliens Abuse was originally created by Michael Moss in 1997. This
slimmed down version can be copied and added to any registered 
version of Abuse by simply editing Abuse.lsp to:

'load addon/aliens/astartup.lsp

and, of course, copying the /addon/aliens folder. If anyone wants to
run the original Aliens addon with fRaBs then you'll have to rename
this folder and unzip the new archive into /addon/aliens. I haven't
tested this, so fRaBs may/may not work with the original Aliens
addon without undoing some of the LISP changes I made.

Justin
6/1/00