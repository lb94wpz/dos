==============================================================================
		    "STRIKE SQUAD" Manual Additions/Changes
		  --------------------------------------------
	       To print this file, copy "README.TXT" to printer!
------------------------------------------------------------------------------
			      Machine Requirements

    IBM and 100% Compatibles

    Required:   IBM-PC/AT 16 Mhz '386 or faster
		2 MB Memory
		Hard Drive
		256 Color VGA graphics
		Mouse, 100% Microsoft (or Logitech) Compatible
 
    Supported:  XMS Memory
		Music & Digitized Sound Effects with 2 MB available XMS memory
		on Adlib, Disney Sound Source, Sound Blaster and Compatibles

    Recommended: 20 Mhz '386 or faster
		 DOS 5.0
		 3 MB memory (at least 2 MB XMS)

===============================================================================
		    
		    MANUAL ADDITIONS/CLARIFICATION/CHANGES
		   ----------------------------------------

	 Explosive Devices: Demo Charges, Blister Charges, and Explosive 
   Charges all explode with the same radius, though they all do different 
   amounts of damage. Also, all the explosive devices act on a timed 
   detonation process, where they automatically count down once dropped.

   	 To determine the name of the mercs' current location, hit hot key
  "L" when on a location and the information will appear in the LCD message
  screen. Knowing where you're at and where to go next is important for
  a successful completion of "Strike Squad."	  

			Hints For Staying Alive
   
  - You should constantly keep check on the mercs' pool of credits. 
    Things like deploying mercs, buying weapons, betting, and interacting 
    with hookers, can take up credit points rather fast. That's why it
    is smart to snag weapons off of dead bodies and sell them to the
    handful of gun salesmen throughout the game. They will give you a fair
    deal for the used items, and in turn will sell you some high quality new 
    and rebuilt weapons. Look for the salesmen on Rogonde of planet Trindor, 
    Jalaak of planet Lusios, and Vos Legas of planet Apatos. Keep in mind
    that when your mercs run out of credits, you lose the game.
     
  - When a merc is wearing a Ghost Cloak he is theoretically invisble
    to any and all enemies on the screen. These enemies, however, can 
    sense when a merc's gun is drawn and will appropriately try to take
    him out if he is a threat. Click on the Engage/Ignore icon and set 
    this invisible merc to "Ignore." This way the enemies will not detect
    his presence and the merc will not start a fight without your order.

  - "Strike Squad" comes with its own built-in list of help screens to aid
    you in performing the most common of functions throughout the game. 
    Type "H" anytime during gameplay to bring up these screens.

  - When playing on a slow machine (386 33mhz or lower) you may find that
    the game runs a lot faster when taking only one or two mercs down to 
    a location at a time. The more mercs you use, the more information
    the program has to process, and thus the slower the execution.

==============================================================================
			    
			    ADDITIONAL INFORMATION
			   ------------------------

				 Virtual Memory

	 The "Strike Squad" program uses a process called Virtual Memory
     to access and execute code. In order for VM to function properly
     there must be an adequate amount of space on the hard drive for
     swapping files. Having at least 4 megabytes of reserved space on the 
     hard drive during gameplay will guarantee a smoothly functioning game.

				  Help Program
    
	 Type HELP for help with memory problems, soundcards, and making 
     a boot disk.  See the troubleshooting section of the Strike Squad manual
     for other information.
				 
				 Saving Games
	 
	 Because of the numerous amount of files that are used during
     game play, saved games in "Strike Squad" can take up to 1.5 megabytes
     of room on the hard drive. If your hard drive is low on space, you
     may want to use only one or two save game slots when saving.

			     Deleting Saved Games

	 Located in the "Strike Squad" directory is a batch file called
     DELSAVE.BAT which deletes specific saved game files filling a particular
     saved game slot. To delete a saved game type "DELSAVE " and then the
     saved game slot number. For example: DELSAVE 3 will delete all the 
     saved files in slot 3.

				Sound Boards

	 Use the SETD.EXE program to select sound boards and to configure 
     the sound driver for that board if not using default values.  The
     SETD.EXE program is automatically loaded the first time that you start
     the Strike Squad game.  If your sound board changes then run the
     SETD.EXE program from the DOS prompt inside the Strike Squad subdirectory. 

	  If you do not see your sound board listed and it is Sound Blaster
     compatible then choose the option for "Sound Blaster and compatibles".


			    Music/SFX Switches

	 To turn off the music and/or sound effects during the game, you
     must do this from the DOS prompt before entering the game. To play
     the game with the music off type "SS MOFF". To play the game with
     sound effects off type "SS SOFF". To play the game with the music and
     sound effects off type "SS MSOFF". (Note: when using an Adlib sound 
     card, the sound effects have trouble initializing properly. The
     game must be played with the sound effects off to avoid a crash.)

---------------------------------------------------------------------------
			     
			  -- Troubleshooting  --

    Error messages during the game are displayed to be self explanatory,
    for example "Mouse driver not detected" would tell you that you forgot
    to the load the 100% Microsoft or Logitech compatible mouse driver
    before running Strike Squad.

    Error messages related to memory problems will display what type of
    memory is insufficient such as "insufficient XMS memory" and what
    the results are, such as "Sound effects not available".  You will
    need to read the "Troubleshooting" section of the manual or run the
    HELP program to get help in clearing memory.

    Please see the "Troubleshooting" section of the manual and/or the
    options on HELP program for Sound Board, memory, and boot disk help.

---------------------------------------------------------------------------
			  
			  MANUAL INSTALL INSTRUCTIONS    

	In some rare cases it is possible that the Strike Squad game may have 
    a problem installing to your specific hard drive setup.  If problems 
    occur be sure to clear TSRs from memory. You may also try creating a 
    boot disk to see if that fixes the problem (refer to the section 
    "Troubleshooting" for information on TSRs and creating a boot disk or 
    use the included HELP program).

	To manually install the game:

    1) On the hard drive build a subdirectory for Strike Squad:

       C:
       CD \
       MKDIR SS

    2) Change directory to the Strike Squad directory:

       CD \SS

    3) Copy all files from each of the game disks into the Strike Squad 
       directory.

       COPY  A:*.*  C:\SS

       Repeat this step for each game disk until all files are copied.

    4) The game is shipped on several disks, each disk contains a 
       compressed file (STRIKEx.CMP - x being the disk number) that
       must be uncompressed before game play by typing:
    
       DCMP STRIKE1.CMP
       DCMP STRIKE2.CMP

       Repeat this for each .CMP file, 
       STRIKE1.CMP,
       STRIKE2.CMP, etc depending on the number of disks in your boxed game.

    5) Delete the original compressed files from hard drive when Step 4 is 
       completed:

       DEL *.CMP

    6) Type SS to start the game.
---------------------------------------------------------------------------
		 
		 INFORMATION ON OTHER MINDCRAFT PRODUCTS:       

 - Type PREVIEW to access Mindcraft online text information catalog.
   View descriptions of games currently available, upcoming game descriptions, 
   information on Mindcraft's BBS, and The Mind's Eye - Mindcraft's very own
   Newsletter. 

================================================================================
			       
			       - END OF FILE -                    

