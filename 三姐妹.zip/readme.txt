=========================^============================^========================

                            Three Sisters' Story (PC)
                        Copyright by Jast and Sakura Soft
                                  Walkthrough

                                      by

                                 Ben Woodhouse
                         shaky_mercury(at)yahoo<dot>com
                                 Oct. 27, 2003
                                 Version  1.41

=========================^============================^========================

******************************CONTENT DISCLAIMER*******************************
Three Sisters' Story is an adult bishoujo game, meaning it contains sex.
Therefore it is intended solely for people over the age of 18.  If you are of
age and still find such material objectionable, then you probably have no
interest in playing this game or reading this FAQ.
*******************************************************************************

Jast USA sells great adult bishoujo games!
Check them out at www.jastusa.com

=---==-=--==--==-=-=-
 TABLE OF CONTENTS
=-=-=-=-=-=-=-=-=-=-=
                            Easy Navigation System
                            ......................
                    To quickly jump to the desired section,
              hit CTRL+F and type in the section's shorthand code.

  i.    Introduction....................................................IN01
  ii.   System Requirements.............................................SR02
  iii.  Characters......................................................CH03
  iv.   Walkthrough - Main Story........................................MS04
  v.    Walkthrough - Side Story(Junko-sensei's favor)..................SS05
  vi.   Endings.........................................................EN06
  vii.  Version History.................................................VH07
  viii. Copyright Information...........................................CI08

-=------=--=-=---=----=--==-=--==-==-=-=--=-==-=-=-=-=-=-=-=-=-==-=-=-===-=-==
                              i. INTRODUCTION                     CODE : IN01
---===-==-==-----------==-=---=-==-=-=--=-===--=-==-=--==--==-=-=--==-====-=-=

Koichi Sanada had the perfect family :  a great older brother,
a loving mother, and a successful father.  However, with his father's
success came many enemies.  These enemies relentlessly attacked his
father until he had no money, no pride, and no options....  After the
father was gone, Koichi's mother tried to support the family.  She
worked hard, too hard, and soon followed her husband in death.  Koichi
and his brother Eiichi were both still children; they couldn't take
care of each other.  As a result, they were split up and passed around
to whatever family memebers would take them, unsure if they would see
each other again...

After almost a decade, Eiichi suddenly showed up at his brother's
door.  He had found the man responsible for his father's death and
everything that followed.  Both of the brothers wanted revenge against
this man, Shoji Okamura.  It was easy for Koichi to insinuate himself
into Okamura's life.  You see, Okamura had three daughters, and Koichi
quickly befriended each of them.  Through them, he had unlimited
opportunities to spy on Shoji and give the information to his
brother....

Koichi didn't know his brother's plot or if Eiichi was using the
information he had gathered.  Meanwhile, he was growing closer and
closer to the three sisters.  Then, one day, Shoji Okamura
disappeared; it had to be part of Eiichi's plan.  However, instead of
feeling vindicated, Koichi felt nothing but shame when he realized
what he had done to the Okamura sisters.  However, while Koichi's need
for revenge was over, Eiichi was just getting started...

Thus begins Three Sisters' Story.  The player takes control of the
main character, Koichi, as he struggles to stop his brother from
harming the innocent sisters.  The interface for the game is simple.
Any characters you're talking to will appear on the screen, along with
a text box containing dialogue and your personal thoughts.  You decide
on Koichi's actions through a menu.  By making the right choices, you
can save the three sisters.

=--=-=-=-=--===---=-==-=-=-=-=--=-=-=-=-=-=-=-==--==--===-=-=-=-=-=-=--=-=--==-
                          ii. SYSTEM REQUIREMENTS                  CODE : SR02
-==-=-=-=--==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-==-=-=-=-=-=--==-=

Requirements for the first release of Three Sisters' Story:

Operating System....MS-DOS or Windows 95/(98)
Processor...........Pentium
Memory..............16 MB RAM
CD-ROM..............Any Microsoft compatible CD-ROM drive
Sound Card..........Any Microsoft compatible sound card
Mouse...............Any Microsoft compatible mouse

A new updated version was released in March of 2003 as part of the Jast USA
Memorial Collection(Runaway City+Season of the Sakura+Three Sisters' Story).

Operating System....Windows 95/98/Me/2000/XP
Processor...........Pentium(II recommended) 200 MHz or faster
Disk space..........350 MB hard drive space

-=--==-=---------=--=-=--==-=-=-=-=-=-=-=-===-=-=-=-=--==--==-=-=-=--=-==-=-=-
                             iii. CHARACTERS                      CODE : CH03
=--==---=---==-------=-=-==--=-=-=-=-=--=-=-==-=-=-=-=-=-=-=-=-=-====-=-=-=-==

  Koichi Sanada - Our protagonist.  Conflicted by his loyalty to his
                  brother, he must somehow find a way to stop Eiichi
                  from harming the Okamura sisters.

  Eiichi Sanada - Koichi's older brother.  He appeared one day with
                  money and a plan for revenge against Shoji Okamura.
                  Nothing else is known about him.

  Shoji Okamura - The man responsible for your father's death.  While
                  you hate him, you love his daughters.  He disappers
                  before the game begins.

  Yuki Okamura  - The oldest of the sisters.  Once her father
                  disappeared, she dropped out of the university to
                  support the family.  She's kind, considerate, and
                  takes care of everyone, including you.

  Emi Okamura   - The middle daughter, she's actually your girlfriend.
                  While she's very moody(she hits you a lot!), you
                  have seen her gentler side.  In fact, you're in love
                  with her.

  Risa Okamura  - The youngest sister.  She's a little immature; she
                  always speaks in the third person.  She's young and
                  innocent, but she has a slight crush on you.

  Keiko-sensei  - Your teacher.  Every guy in school lusts after her;
                  she's very attractive.  She also comes from a rather
                  prestigious family.  Wonder if she has a boyfriend?

  Junko-sensei  - The school nurse, she's notorious for giving sexual
                  favors to the boys at school, whether they like it
                  or not.  Maybe she'll do something for you?

  Kumi Akimoto  - A freshman at your school, she's an up and coming
                  gymnast, except she gets so nervous she can't
                  perform in front of guys.  Its up to you to help her
                  out.

  Chie Makino   - An introverted girl who likes to read.  Apparently
                  she doesn't like people due to some trauma in her
                  past.  Can you help her come out of her shell?

  Yuko Uchimura - She's the captain of the track team and also a world
                  class bitch.  In fact, all the girls on the track
                  team are considering quitting because she's so mean.
                  Someone has to change her attitude.

  Chisato Fujimura - A former model student, Chisato has become a
                     delinquent due to some problems at home.
                     However, if anyone knows about family tragedy,
                     its you.  Perhaps you can make her see things in
                     a different light.

  Mana ?????    - A waitress in a lingerie pub, she takes an immediate
                  liking to you.

  Aki ?????     - You don't know much about her, except that she has
                  some connection to your brother.  If you can get
                  some information from her...


-=-=-=-=-=--------=--=------=---=--=-=-=-=-=-=-=-=-=-=-=-=-=--=-==--==-=-=-=-=-
                       iv. WALKTHROUGH - MAIN STORY                CODE : MS04
-=-=-=------------===---------=----=-=--==-=-=-=-=-=-=-=-=-=-=====---==-=-=-=-=

In this walkthrough, I'm only including the menu steps necessary to
move the story along.  Most of the menus will have additional options,
such as LOOK, which you almost never have to do.  If you want to
go through these steps, which you might(just for completeness), you
should do them ~before~ the options I tell you to take.  Once you
follow my directions, the story will move on whether you like it or
not.

When the directions say to "Exhaust" certain options, this means
that you should select an option until the text repeats, and then
move onto the next choice in the list.

I include location markers; these are just to make it easier to know
what's supposed to be happening. Instructions designated by an * are
optional, either save points or references to the side story section.

Enjoy!
                                   ___________
                                  |           |
|---------------------------------|   Day 1   |-------------------------------|
|                                 |___________|                               |

____________________________________
      \In Front of the Okamura House\

     Exhaust - LOOK
               TALK
               ASK
               THINK

     TALK again

____________________________________
                        \Yuki leaves\

     Exhaust - THINK

____________________________________
                        \Emi appears\

     Exhaust - TALK
               ASK
               THINK - Emi
____________________________________
                       \Risa appears\

     Exhaust - LOOK
               THINK
               TALK (Talk to Risa last)

____________________________________
                      \End of School\

(This part can be a pain. You must search the entire school grounds)


     *Do the stuff in the room*(Optional)
     Exit

     GO to 4th floor
     SEARCH Rooms 3-A,B,C,E
     SEARCH Room 3-D(You'll get an h-scene)

     GO to room 2-A
        CHECK OTHER ROOMS

     GO to 2nd Floor
        GO to Room 1-A, TALK to Risa
        GO to Room 1-B, CHECK OTHER ROOMS

     GO to the Library
        LOOK FOR
        ASK(You meet Chie)
        EXIT

     GO to 1st Floor
        GO to the Teachers' Office
           Exhaust - TALK
                     ASK
                     THINK(Until you get the option to EXIT)
        GO to Nurses's Office
           Exhaust - TALK
                     ASK
                     THINK
                     GO - HALLWAY

     GO to School Yard
        THINK - Emi
                Sports Clubs
                Track Team
        TALK - Track Team(You meet Yuko)

     GO to Gym
        Exhaust - TALK(You meet Kumi)

     Return to classroom 2-B(This is your classroom)

____________________________________
                \See Emi in the Park\

     "Yes its Cold"   ___\   Okay, you can choose whatever,
     Go to Emi           /   but its sweeter this way.

____________________________________________________________
         \After Eiichi and Yuki-san, you return to your room\

     Exhaust - THINK

____________________________________
                     \Park w/ Eiichi\

     Exhaust - TALK

____________________________________
                     \Return to room\

     Exhaust - THINK

____________________________________
                    \Yuki-san's room\

 *Save here! - unless you want to skip Yuki's h-scene*
 *Just choose the Bad Ending, and then reload from this point*

     Good Ending - Refuse
     Bad Ending - Take Yuki
|_____________________________________________________________________________|

                                   ___________
                                  |           |
|---------------------------------|   Day 2   |-------------------------------|
|                                 |___________|                               |

____________________________________
          \In Front of Okamura House\

     Exhaust - TALK
               ASK
               THINK
____________________________________
                       \After School\

      Search the school building from the 4th floor down
       (Just like yesterday)

      (Once you reach the 1st Floor)
      TALK to Keiko-sensei

      GO to Nurse's Office(if its locked, go outside and come
                           back in until you can enter)

            Exhaust - TALK
                      ASK - request
                      OKAY - (You have to pick it)
                      TALK - Junko-sensei gives you the details

      *Side Story Actions - Reference Day 2*(All optional)

      ~If you're not doing the side story, still go outside and to
         the gym, as in day 1~

      When your ready to leave, return to 2-B and GO HOME
____________________________________
                      \Okamura House\

      Peek at Emi -> It doesn't affect the story, but you WANT to!

      GO - DOWNTOWN
____________________________________
     \Downtown - in the Lingerie Pub\

      Exhaust - TALK
                ASK

      Exhaust - TALK
____________________________________
                        \In the Park\

      Exhaust - APPROACH
                THINK
                LOOK
____________________________________
                       \Aki shows Up\

      CHASE
      DON'T RUN AWAY
      CHASE
____________________________________
                          \Back Home\

      Exhaust - THINK
|_____________________________________________________________________________|

                                   ___________
                                  |           |
|---------------------------------|   Day 3   |-------------------------------|
|                                 |___________|                               |

____________________________________
      \In Front of the Okamura House\

      Exhaust - TALK - Emi
                       Risa

      Exhaust - TALK
                THINK
____________________________________
                       \After School\

      *Side Story Actions - Reference Day 3*

      Go talk to Keiko-sensei
         Exhaust - TALK
         Exhaust - TALK
                   ASK
                   THINK

      Go back to 2-B, GO HOME
____________________________________
             \At School w/ Risa-chan\

     GO to NIGHT OFFICE
     Exhaust - PEEK

 *Save here! - unless you want to skip Risa's h-scene*
 *Just choose the Bad Ending, and then reload from this point*

     Good Ending - Refuse
     Bad Ending - Take
____________________________________
                  \Back in Your Room\

     Exhaust - THINK
|_____________________________________________________________________________|

                                   ___________
                                  |           |
|---------------------------------|   Day 4   |-------------------------------|
|                                 |___________|                               |

____________________________________
               \Risa-chan's birthday\

     Exhaust - TALK

     ANSWER PHONE ____\ Again, doesn't affect the ending,
     YES              / but this is the "best" way.
____________________________________
                       \In your room\

     Exhaust - THINK
____________________________________
                 \Risa-chan shows up\

 *Save here! - unless you want to skip Risa's h-scene*
 *Just choose the Bad Ending, and then reload from this point*
 (Note: If you already ****ed you can't refuse here)

     Good Ending - Refuse
     Bad Ending - Take her(Choices in her h-scene are easy)
|_____________________________________________________________________________|

                                   ___________
                                  |           |
|---------------------------------|   Day 5   |-------------------------------|
|                                 |___________|                               |

____________________________________
      \In Front of the Okamura House\

     Exhaust - SPEAK
               ASK

     Exhaust - SPEAK
               ASK
____________________________________
                       \After School\

     *Side Story Actions - Reference Day 4*(Only for Scenario 2)

     Go speak to Keiko-sensei
     Exhaust - TALK

     Return to 2-B, GO HOME
____________________________________
                          \Back Home\

     Exhaust - GET READY
               LOOK - Picture Album
               THINK
____________________________________
                           \Downtown\

     GO - FASHION HEALTH
        Choose AKI
           Exhaust - SPEAK
           Exhaust - KISS
                     TOUCH
           Exhaust - ASK
                     TELL ALL
                     ASK - ONE OTHER THING

         *For a bonus h-scene, you can choose Yumi*

     GO - LINGERIE PUB
        Exhaust - SPEAK - Mana

     GO - TELEPHONE CLUB
        *Side Story Actions - Reference Chisato*
        If you haven't done the previous steps,
           Chisato won't call.  Just leave.

     GO - PARK

        Exhaust - WAIT
        <Keiko & Eiichi show up>
        Exhaust - USE MICROPHONE
                  LOOK - Eiichi
                  FOLLOW
        Exhaust - USE
____________________________________
                \At the Lingerie Pub\

     Hell, Yes
     Sit Back and Relax  ____\  Choose these or you won't
     Do as she wants         /  get the help you need.

     Exhaust - ASK
____________________________________
            \In the Park w/ Yuki-san\

     TELL THE TRUTH -> Choose either but this is nicer.
____________________________________
                 \In your Room w/Emi\

     Exhaust - SPEAK
               TELL HER EVERYTHING
               TAKE HER (You have to, is that bad?)

     Exhaust - CARESS
               SPEAK
               UNDRESS HER

     Do everything in the next menu(Do I have to tell you?)
|_____________________________________________________________________________|

                                   ___________
                                  |           |
|---------------------------------|   Day 6   |-------------------------------|
|                                 |___________|                               |

____________________________________
                       \After School\

     Go talk to Keiko-sensei:
        SLAP HER - No h-scene ___\  No effect on ending.
        EMBRACE - (H)            /  Your call.

     Go to 2-B, GO HOME
____________________________________
                        \At the Park\

      Alternate : WAIT, THINK
____________________________________
                    \At Kaisan Corp.\

      ENTER - GO OUTSIDE
      CALL MANA

      (The most annoying part of the game)
      SEARCH the guard until you get the baton(6 times)

      GO to NEAR RIGHT ROOM
         Save the girl
         Exhaust - ASK
                   SEARCH

      GO to THE FLOOR ABOVE
      GO to FAR LEFT ROOM
         Exhaust - SEARCH - COMPUTER SCREEN

      LOOK - AKIKO (3 times) -> Do this or LOSE!
      Exhaust - THINK
                SEARCH
                TORTURE
      Exhaust - ASK
                SEARCH

      GO to THE FLOOR ABOVE
      GO to STORAGE ROOM A
      GO to STORAGE ROOM B
      GO to CONTROL ROOM
         OPERATE
         EXIT
____________________________________
                 \Showdown w/ Eiichi\

 *You might want to save here, the other endings are interesting.*

     EXPLAIN
____________________________________
                           \Escaping\

     Going after Eiichi will give some extra dialogue, but
        the outcome is the same.
____________________________________
                       \Sex with Emi\

     If you chose to get the good end, you'll now get it on with Emi.
     Enjoy!
|_____________________________________________________________________________|


Everyone lives happily ever after!(Except those who die!)  Fin.


-=-=---=--=------------=--------==-=-=-=-=-=-=-=-----==--=-===--==-=-=-=-==-=--
                        v. WALKTHROUGH - SIDE STORY                CODE : SS05
-==-=--=-==-=-=----=====-------=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=---==-=-==-=-=-=-

Here's how to get the 4 optional girls.  Execute these instructions
in the appropriate place in the WALKTHOUGH.

                              _____________________
                             |                     |
|----------------------------|   Day 2 Reference   |--------------------------|
|                            |_____________________|                          |


________________________
             \   Kumi   \

     Go to the GYM
        Exhaust - TALK - KUMI
                  THINK - HOW TO CURE HER
                  Pick Method 3
                  FORBIDDEN DRILL
                  GO IN
                  WEAR CONDOM(Unless you're going for the bad ending)

     Go to Nurse's Office
        PRESENT
        (Go back in)
        ASK - CONDOM

     *Note that you can be with Kumi as often as you want, basically
      everyday after school*

________________________
       \  Yuko & Chie   \

 ~You have a choice of 2 scenarios for Yuko and Chie.
  It depends on the order you "help" them.~

     Scenario 1 - You'll sleep with both Chie and Yuko
     ----------
     Go to Library
        LOOK FOR - Chie(if you just talk to her, you'll have to exit
                        and look for her again.  Repeat until you
                        catch her in the corner.)
        Exhaust - SPEAK
                  ASK

     ~Done for Day 2~

     ****************************************************************

     Scenario 2 - Amazingly, you can help Chie without ****ing her.
     ----------
     ~Don't do anything today~

|_____________________________________________________________________________|

                              _____________________
                             |                     |
|----------------------------|   Day 3 Reference   |--------------------------|
|                            |_____________________|                          |

________________________
       \  Yuko & Chie   \

     Scenario 1
     ----------
     Go to Library
        LOOK FOR - Chie
        WEAR CONDOM(Unless you are going for the bad ending)

     Go to Nurse's Office
        PRESENT
        (Go back in)
        ASK - CONDOM

     Go to School Yard
        TALK - Track Team(if you talk to Yuko, enter the school and
                          return.  Repeat the step until Yuko isn't
                          there.)
        Exhaust - LOOK FOR - Yuko
        BE KIND
        MASSAGE HER
        WEAR CONDOM(despite what she says)

     Go to Nurse's Office
        PRESENT

     ~Done for Day 3~

     ***************************************************************

     Scenario 2
     ----------

     Go to School Yard
        TALK - Track Team(if you talk to Yuko, enter the school and
                          return.  Repeat the step until Yuko isn't
                          there.)
        BE KIND
        MASSAGE HER
        WEAR CONDOM(despite what she says)

     Go to Nurse's Office
        PRESENT

     Go to Library
        LOOK FOR - Chie(if you just talk to her, you'll have to exit
                        and look for her again.  Repeat until you
                        catch her in the corner.)
        Exhaust - SPEAK
                  ASK

     ~Done for Day 3~
|_____________________________________________________________________________|

                              _____________________
                             |                     |
|----------------------------|   Day 4 Reference   |--------------------------|
|                            |_____________________|                          |

________________________
       \  Yuko & Chie   \

     Scenario 2
     ----------

     Go to Library
        TALK - Chie

     Go to Nurse's Office
        PRESENT

     ~Done for Day 4~
|_____________________________________________________________________________|

                              _____________________
                             |                     |
|----------------------------|  Chisato Reference  |--------------------------|
|                            |_____________________|                          |

     THINK
     GO IN
     WAIT FOR CALL(5 times)   ___\  If you mess these up just go back in
     WAIT PATIENTLY(7 times)     /  and begin the steps again.
     <You meet her in the park>
     Exhaust - SPEAK
               Choose Either - I would choose TALK TO HER
|_____________________________________________________________________________|


-=-=-=-=-=-=-=--=--=-=-=-=-==--=-==-=-=--=-=-=-=-==-=--=-==-=-=-=-=-=-=-=-=-=-=
                                vi. ENDINGS                        CODE : EN06
-=-=-==---=-=-==-=-=-=--=-=-=-=----------=-==--=-=-=-=-==--=-==-=-=-=-=-=-=-===

Three Sisters' Story has a few possible endings, although only one of
them can be considered a "good" ending.  Here is a list of how to
obtain each one :

The Best Ending
---------------
Don't sleep with either Yuki or Risa.  Make sure to use a condom if
you have sex with Kumi, Yuko, or Chie.  What you do with Chisato
doesn't matter.  Koichi and Emi end up happily together.

The Cheater
-----------
Get this ending by sleeping with Yuki and/or Risa.  Regardless of
whether you only slept with one, they will both show up at the end and
lay their claim to Koichi.  This scenario only has one possible ending :
Emi beats the crap out of Koichi.

Safe Sex
--------
Children, learn that your actions do indeed have consequences.  If you
don't use a condom with Kumi, Yuko, and/or Chie, then Junko-sensei
will show up at the end and inform you that you've impregnated one of
them.  Koichi's only choice is to take responsibility; any chance of
reconciling with Emi flies out the window.

Total and Complete Irresponsibility
-----------------------------------
This is a combination of "The Cheater" and "Safe Sex."  If Koichi
sleeps with a sister and has unprotected sex with any of the random
girls, then the sisters will fight for him AND Junko-sensei will
appear at the end.

Bad Ending
----------
Koichi somehow fails to stop his brother.  There are several ways this
can happen : raping Chie in the library, Akiko stopping you at Kaisan
Corp., and choosing incorrectly among Eiichi's options at the end.

-=-=-=-=-=-=-=--=--=-=-=-=-==--=-==-=-=--=-=-=-=-==-=--=-==-=-=-=-=-=-=-=-=-=-=
                           vii. VERSION HISTORY                    CODE : VH07
-=-=-==---=-=-==-=-=-=--=-=-=-=----------=-==--=-=-=-=-==--=-==-=-=-=-=-=-=-===

vFinal - Walkthrough completed.

v1.10 - Note to self - never call something version "Final" again.
        Corrected a typo in the Day 1 School Search.(Rm. 3A to 2A)
        Reformatted paragraphs.

v1.20 - Reformatted the walkthrough section, as it was ugly and
        therefore hard to follow.  No new real content added.

v1.21 - More reformatting.

v1.30 - Added the system requirements.

v1.40 - Added a section detailing the possible endings.
        Corrected the system requirements for the older version.
        Added navigation system.

v1.41 - A little while ago, I told IGN.com I would get around to submitting
        my FAQs to them, but I guess someone got impatient.  Two weeks ago,
        five of my FAQs, including this one, were posted there without my
        knowledge.  While this irked me a little, I suppose I might as
        well officially give them permission to post it.  So, congratulations
        IGN, you're now listed as an authorized host for a copy of this FAQ.

-=-=-=-=-=---=--=---=-==-=--=-==-=--==-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=--=-==
                       viii. COPYRIGHT INFORMATION                 CODE : CI08
=--=-=-=-=--===---=-==-=-=-=-=--=-=-=-=-=-=-=-==--==--===-=-=-=-=-=-=--=-=--==-

All information and work in this document is copyright 2002-2003 by
Ben Woodhouse unless otherwise stated and may be not be reproduced under
any circumstances except for personal, private use. It may not be placed on
any web site or otherwise distributed publicly without advance written
permission. Use of this guide on any other web site or as a part of any public
display is strictly prohibited, and a violation of copyright.

Thanks for your cooperation.

         -----------===-------=-=-=-=-------------------------------=-
                 This FAQ is approved for posting on websites:
 
                      GameFAQs - www.gamefaqs.com

                      HonestGamers - www.honestgamers.com

                      IGN.com  - www.ign.com

         Any other site or publication posting it has ripped this FAQ.  
                  React according to your own moral standards.
         ------------------------------------------------------------=

===============================================================================
===============================================================================
If you have any additions or corrections that you feel belong in this
document, feel free to let me know!
===============================================================================
===============================================================================
                                   -<-EoF->-
